-- Phase 2a: blockers as a first-class DB surface (replaces blockers/blockers.md
-- as the canonical source — the markdown becomes a frozen archive after the
-- one-time import).
--
-- Why: the task_blockers join table stored a blocker_ref (markdown anchor)
-- pointing at prose in blockers/blockers.md. When Lars resolved a blocker
-- (e.g., "GitHub OAuth credentials provided"), the only thing that updated
-- was the markdown — the linked tasks stayed in 'blocked' status until a
-- human remembered to flip them. This migration makes blockers a real row,
-- and a trigger automatically promotes blocked tasks to 'ready' the moment
-- the blocker is resolved.
--
-- Schema design follows the pattern of cost_log / learnings / idea_inbox:
-- (source, source_ref) UNIQUE for idempotent re-runs of the import script.

CREATE TABLE IF NOT EXISTS blockers (
  id          BIGSERIAL PRIMARY KEY,
  title       TEXT NOT NULL,
  body_md     TEXT NOT NULL DEFAULT '',
  status      TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'resolved')),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at TIMESTAMPTZ,
  resolved_by BIGINT REFERENCES builders(id),
  resolution_note TEXT,
  source      TEXT,                              -- 'imported-markdown' | 'manual' | ...
  source_ref  TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS uniq_blockers_source_ref
  ON blockers (source, source_ref)
  WHERE source IS NOT NULL AND source_ref IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_blockers_status ON blockers (status) WHERE status = 'open';

-- Add a structured link from task_blockers to the new blockers table.
-- The legacy blocker_ref TEXT column stays for backwards compatibility with
-- existing rows pointing at markdown anchors; new rows should use blocker_id.
ALTER TABLE task_blockers
  ADD COLUMN IF NOT EXISTS blocker_id BIGINT REFERENCES blockers(id) ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS idx_task_blockers_blocker_id
  ON task_blockers (blocker_id) WHERE blocker_id IS NOT NULL;

-- Trigger: when a blocker flips to 'resolved', auto-promote every task
-- linked via task_blockers from 'blocked' → 'ready'. Captures resolved_at if
-- not already set so /me, /tasks, etc. all see the same timestamp.
CREATE OR REPLACE FUNCTION trg_promote_tasks_on_blocker_resolve()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'resolved' AND (OLD.status IS NULL OR OLD.status <> 'resolved') THEN
    IF NEW.resolved_at IS NULL THEN
      NEW.resolved_at := now();
    END IF;

    UPDATE tasks
       SET status = 'ready', updated_at = now()
     WHERE id IN (SELECT task_id FROM task_blockers WHERE blocker_id = NEW.id)
       AND status = 'blocked';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS promote_tasks_on_blocker_resolve ON blockers;
CREATE TRIGGER promote_tasks_on_blocker_resolve
  BEFORE UPDATE OF status ON blockers
  FOR EACH ROW
  EXECUTE FUNCTION trg_promote_tasks_on_blocker_resolve();
