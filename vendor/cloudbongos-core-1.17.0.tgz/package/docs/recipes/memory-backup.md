# Recipe — Builder memory backup + restore drill

> **Filed by:** task [#281](https://example.com/builders#/task/281) (V3.R62), GDS-V3 criterion C8 ("memory is local-first, server-canonical on ship"). Depends on the server-side memory store ([#273](https://example.com/builders#/task/273) R54) and the DB backup pipeline ([#412](https://example.com/builders#/task/412) local nightly + [#415](https://example.com/builders#/task/415) weekly offsite). Companion to [`gds-db-backup.md`](gds-db-backup.md); vendor choice in [ADR 0025](../adr/<redacted>.md).

## Key decision — memory is backed up *as part of the full-DB backup*, not separately

C8 makes each builder's local memory dir **server-canonical on ship**: `/builder-ship` upserts the builder's memory files into the `builder_memory` Postgres table ([#274](https://example.com/builders#/task/274) R55). Because that table lives in the same `example` database as everything else, **it is already captured by the full-DB backup pipeline** — there is deliberately **no separate `backup-memory.sh`**. A memory-only dump would duplicate what `pg_dump` already writes nightly and ship offsite weekly, and would be a second thing to keep in sync. One backup story, not two (same principle as [ADR 0025](../adr/<redacted>.md)'s retirement of the redundant [#7](https://example.com/builders#/task/7) cron).

So builder memory inherits both layers:

| Layer | Mechanism | Cadence | Retention |
|---|---|---|---|
| Local | `gds-db-backup.timer` → `pg_dump` → `/var/backups/gds/` ([#412](https://example.com/builders#/task/412)) | daily 04:00 UTC | 30 days |
| Offsite | `gds-db-offsite.timer` → latest dump → DO Space `gds-offsite/` ([#415](https://example.com/builders#/task/415)) | weekly Sun 05:00 UTC | 4 weeks |

The `builder_memory` table is in every dump. No extra moving parts.

## The `builder_memory` table

```
builder_memory(builder_id, path, content, mtime, sha256, byte_len, created_at, updated_at)
  PK (builder_id, path)
```

Each row is one memory file for one builder. The `sha256` + `byte_len` columns are the integrity fingerprint — which is what lets the restore drill below verify a restore **without ever reading the private `content`** (builder memory is per-builder private + isolated; see [#276](https://example.com/builders#/task/276) R57).

## Restore drill — verify a builder's memory survives a restore

Cadence: **quarterly** (alongside the general restore drill in [`gds-db-backup.md`](gds-db-backup.md)). The drill restores the latest dump into a throwaway sandbox DB and confirms a chosen builder's memory rows are byte-identical to production — by fingerprint, so no private content is printed.

```bash
# 1. Restore the latest local dump into a sandbox DB.
DUMP=$(ls -1t /var/backups/gds/example-*.sql.gz | head -1)
sudo -u postgres dropdb --if-exists example_mem_restore_test
sudo -u postgres createdb example_mem_restore_test
set -o pipefail
gunzip -c "$DUMP" | sudo -u postgres psql -q -d example_mem_restore_test

# 2. Pick a builder with memory (builder_id=1 here) and compare a
#    privacy-preserving fingerprint: count + md5 over (path, sha256, byte_len).
#    Never selects `content`.
FP="SELECT builder_id, count(*),
       md5(string_agg(path||':'||sha256||':'||byte_len, ',' ORDER BY path))
    FROM builder_memory WHERE builder_id=1 GROUP BY builder_id;"
psql -d example                         -tAc "$FP"   # production
sudo -u postgres psql -d example_mem_restore_test -tAc "$FP"   # restored

# 3. The two lines must be identical. Then clean up.
sudo -u postgres dropdb example_mem_restore_test
```

### Last run

- **2026-05-30** (task [#281](https://example.com/builders#/task/281), claim `#349`): builder 1, **3 files**, prod and restored fingerprints **MATCH** (`…<redacted>`). Restore completed with zero errors.

## Caveat the drill caught — point-in-time vs. the data

The first drill run **failed correctly**: the most recent nightly dump (04:02 UTC) predated migration 054 and the memory rows (which synced at 08:47 UTC that day), so the table wasn't in it. Two lessons baked in here:

1. **A dump only contains what existed when it ran.** Memory synced since the last 04:00 UTC nightly is not in any backup until the next nightly; and not *offsite* until the next weekly run. Worst-case memory-loss window on whole-droplet loss is ~1 week (the offsite cadence). Tighten the offsite timer to daily if that ever matters.
2. **After a migration that adds/relocates memory data, take a one-shot dump** rather than waiting for the nightly, if you want it backed up immediately:
   ```bash
   sudo systemctl start gds-db-backup.service   # fresh local dump now
   sudo systemctl start gds-db-offsite.service  # push it offsite now
   ```

## See also

- [`gds-db-backup.md`](gds-db-backup.md) — the full backup pipeline, install steps, and the general (non-memory-specific) restore drills.
- [ADR 0025](../adr/<redacted>.md) — offsite vendor decision.
- [ADR 0024](../adr/<redacted>.md) — the local-first / server-canonical memory model this backs up.
