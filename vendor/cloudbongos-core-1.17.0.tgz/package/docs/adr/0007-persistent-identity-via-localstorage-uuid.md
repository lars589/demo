# 0007 — Per-browser persistent player identity via localStorage UUID

- **Status:** Accepted
- **Date:** 2026-05-08
- **Deciders:** Lars

## Context

Without persistent identity, every browser reload respawned the player at the world's spawn tile. That made the project's tagline — *"the world is permanent"* — actively misleading on the first reconnect. We needed identity stable enough that "I walked here, refreshed, and I'm still where I left off" works.

Stripe-backed account login is the long-term identity story (see V1 scope), but it depends on Stripe integration that hadn't been built yet. We needed an identity primitive **before** auth was wired.

## Decision

On first load, the client generates a UUID (`crypto.randomUUID()` with a fallback for older browsers) and stores it in `localStorage`. That UUID is sent as a join option to the WorldRoom on every connect.

The server keys position and facing by that UUID. A `players` table holds `(id, current_grid_x, current_grid_y, current_facing, first_seen_at, last_seen_at)`. On join, the server upserts the row and rehydrates the player at their last-known position. On every move, the row is updated.

## Alternatives considered

- **Defer identity until Stripe auth is built.** Means broken UX (every reload respawns) for the entire pre-Stripe development window. Rejected — that's months of "the demo doesn't work right."
- **Server-issued session cookie.** Marginally more secure than localStorage but requires more wiring (cookie middleware, CORS handling for the WS upgrade) for the same effective identity. Rejected as over-engineering for the V1 stage.
- **Browser fingerprint as identity.** Brittle — fingerprint changes silently with browser updates. Rejected.

## Consequences

- **Clear localStorage = lose your position.** This is real. Documented as a current-version limitation. When Stripe auth lands, identity binds to the Stripe customer and survives any browser-side wipe.
- **No cross-browser identity.** Open the site in Safari + Chrome from the same Mac and you are two different players. Same V1 limitation; same fix path (Stripe).
- **One user per browser is enforced naturally** — there is one localStorage UUID per browser profile. Aligns with the V1 scope decision.
- **No PII in V1.** The UUID is opaque and not tied to a person. When Stripe auth lands, the linkage is `players.id ↔ stripe_customer_id` — Stripe is the system of record for the personal-data side; we never store email or payment info.
- **`world_events` already carries `actor_session_id`** — events are linkable to a player via the join record. Post-auth events will be linkable to a Stripe customer transitively.
