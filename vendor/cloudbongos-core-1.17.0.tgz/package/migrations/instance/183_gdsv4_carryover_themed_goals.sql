-- Migration 183 — Five themed goals for the GDS-V4 carryover (BONGOS-V1)
-- ============================================================================
-- Follow-up to ADR 0103 (migration 182): the ~72 still-relevant GDS-V4 tasks
-- carried into BONGOS-V1 were left goal-less. This gives the platform debt a
-- spine — five OUTCOME goals (ADR 0086 goal tier), each with done-when criteria,
-- and reparents the tasks under them. Evergreen chores + grader/economy/misc +
-- recent non-debt work are deliberately LEFT goal-less (they are not carryover
-- outcomes). Owner-directed 2026-07-02 (with Lars).
--
-- Goals are Archon-owned (created_by = 1), scope_modules empty (grouping goals,
-- not scope-walled; tasks attach here via this migration, not the API route).
-- Criteria start satisfied=false, so each goal stays 'open' until its work lands.
--
-- REVERSIBLE: only INSERTs (goals + criteria) and task goal_id UPDATEs. To undo,
-- NULL the goal_id on the affected tasks and DELETE the 5 goals + their criteria.
-- Idempotent: goal INSERTs are title-guarded, criteria use ON CONFLICT DO NOTHING,
-- task UPDATEs only touch still-goal-less rows.
-- ============================================================================

BEGIN;

DO $$
DECLARE gid bigint;
BEGIN
  -- ---- G1: Build-pipeline integrity --------------------------------------
  SELECT id INTO gid FROM goals WHERE version_id='BONGOS-V1' AND title='Build-pipeline integrity' LIMIT 1;
  IF gid IS NULL THEN
    INSERT INTO goals (version_id, title, description, scope_modules, created_by, status)
    VALUES ('BONGOS-V1', 'Build-pipeline integrity',
      'GDS-V4 carryover (ADR 0103): the system that builds Cloud Bongos never fails silently or carries known integrity holes — ship/merge/deploy, CI, the nightly backup, and the SEC-863 deploy-gate.',
      '{}', 1, 'open')
    RETURNING id INTO gid;
  END IF;
  INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, goal_id, sort_order) VALUES
    ('BONGOS-V1','gcarry-pipe-loud','Every stage of ship->merge->deploy and the nightly DB backup fails LOUDLY (surfaces in CI or journald), never silently.',gid,10),
    ('BONGOS-V1','gcarry-pipe-sec863','The SEC-863 deploy-gate has no known bypass: audit range anchored to last-successful-deploy, sub-Metic protected-path claims blocked at claim time, and each protected-path commit tied to a task in the main audit.',gid,20),
    ('BONGOS-V1','gcarry-pipe-smoke','A full-stack integration smoke (server + Postgres) runs as a required PR check, and the flaky unit harness is isolated so a green run is trustworthy.',gid,30)
  ON CONFLICT (version_id, criterion_id) DO NOTHING;
  UPDATE tasks SET goal_id=gid, updated_at=now()
   WHERE version_id='BONGOS-V1' AND goal_id IS NULL
     AND id IN (1426,1427,1429,1431,1432,1433,1435,1436,1462,1479,1641,1703,1219,861,862,1140,1437,1440,1461,1434,723);

  -- ---- G2: Builder experience — hall, dev box, and skills ----------------
  SELECT id INTO gid FROM goals WHERE version_id='BONGOS-V1' AND title='Builder experience — hall, dev box, and skills' LIMIT 1;
  IF gid IS NULL THEN
    INSERT INTO goals (version_id, title, description, scope_modules, created_by, status)
    VALUES ('BONGOS-V1', 'Builder experience — hall, dev box, and skills',
      'GDS-V4 carryover (ADR 0103): everything a builder directly touches — the builders hall UI, the dev box + sandbox, and the day-to-day skills — works without needing Claude for routine actions.',
      '{}', 1, 'open')
    RETURNING id INTO gid;
  END IF;
  INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, goal_id, sort_order) VALUES
    ('BONGOS-V1','gcarry-bx-hall','Core task actions (claim, release, ship-trigger, triage) and a task board work in the builders hall WITHOUT invoking the LLM.',gid,10),
    ('BONGOS-V1','gcarry-bx-identity','A builder can view and edit their own profile, see works-completed, and read an efficiency-aware leaderboard.',gid,20),
    ('BONGOS-V1','gcarry-bx-onramp','Newcomers never dead-end: auth/re-auth is browser-clickable and self-explanatory, and the dev box + sandbox are discoverable.',gid,30),
    ('BONGOS-V1','gcarry-bx-box','A builder dev box + sandbox is robust: uncommitted work is not lost on reclaim, host-keys survive rebuilds, and staging is cross-platform.',gid,40)
  ON CONFLICT (version_id, criterion_id) DO NOTHING;
  UPDATE tasks SET goal_id=gid, updated_at=now()
   WHERE version_id='BONGOS-V1' AND goal_id IS NULL
     AND id IN (758,751,759,424,1466,1467,1468,1469,1471,1473,1474,1475,1476,1481,1482,594,1472,1715,1696,1650,1470,1391,1165,837,843,885,1477,1493,1430,1665);

  -- ---- G3: Cloud Bongos productization and self-host ---------------------
  SELECT id INTO gid FROM goals WHERE version_id='BONGOS-V1' AND title='Cloud Bongos productization and self-host' LIMIT 1;
  IF gid IS NULL THEN
    INSERT INTO goals (version_id, title, description, scope_modules, created_by, status)
    VALUES ('BONGOS-V1', 'Cloud Bongos productization and self-host',
      'GDS-V4 carryover (ADR 0103): someone other than the owner can run Cloud Bongos — a second instance, a real update channel, a clean vanilla boot, and hosting as a module.',
      '{}', 1, 'open')
    RETURNING id INTO gid;
  END IF;
  INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, goal_id, sort_order) VALUES
    ('BONGOS-V1','gcarry-prod-customer2','A second instance (Mercury) runs live on a pinned Cloud Bongos core, with its own repo and GDS.',gid,10),
    ('BONGOS-V1','gcarry-prod-upgrade','bongos upgrade is a real update-consumption channel for a two-repo consumer (not a stub).',gid,20),
    ('BONGOS-V1','gcarry-prod-vanilla','A vanilla docker compose up boots clean: no instance/product seed data runs and no host-brand leaks, both gated in CI.',gid,30),
    ('BONGOS-V1','gcarry-prod-hosting','Instance hosting (provision, manage, cost read-out) is available as a Cloud Bongos module.',gid,40)
  ON CONFLICT (version_id, criterion_id) DO NOTHING;
  UPDATE tasks SET goal_id=gid, updated_at=now()
   WHERE version_id='BONGOS-V1' AND goal_id IS NULL
     AND id IN (1689,1690,1326,1704,1706,1485,1619,1620,1621,1388,1439);

  -- ---- G4: Findability — the grep path (ADR 0095) ------------------------
  SELECT id INTO gid FROM goals WHERE version_id='BONGOS-V1' AND title='Findability — the grep path (ADR 0095)' LIMIT 1;
  IF gid IS NULL THEN
    INSERT INTO goals (version_id, title, description, scope_modules, created_by, status)
    VALUES ('BONGOS-V1', 'Findability — the grep path (ADR 0095)',
      'GDS-V4 carryover (ADR 0103 / ADR 0095): a repo agents navigate by literal search, with meaning written into the source rather than an embedding index.',
      '{}', 1, 'open')
    RETURNING id INTO gid;
  END IF;
  INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, goal_id, sort_order) VALUES
    ('BONGOS-V1','gcarry-find-docstrings','The docstring / module-header convention is rolled out across the codebase and guarded by a fitness/density check so it cannot rot.',gid,10),
    ('BONGOS-V1','gcarry-find-why','Code rationale (the why) is surfaced forward-facing, and the AST/tree-sitter repo-map upgrade is decided.',gid,20)
  ON CONFLICT (version_id, criterion_id) DO NOTHING;
  UPDATE tasks SET goal_id=gid, updated_at=now()
   WHERE version_id='BONGOS-V1' AND goal_id IS NULL
     AND id IN (1654,1655,1656,1657,1659,848);

  -- ---- G5: Autonomy groundwork -------------------------------------------
  SELECT id INTO gid FROM goals WHERE version_id='BONGOS-V1' AND title='Autonomy groundwork' LIMIT 1;
  IF gid IS NULL THEN
    INSERT INTO goals (version_id, title, description, scope_modules, created_by, status)
    VALUES ('BONGOS-V1', 'Autonomy groundwork',
      'GDS-V4 carryover (ADR 0103): safe unattended routines — guardrails first, then arm the safe set.',
      '{}', 1, 'open')
    RETURNING id INTO gid;
  END IF;
  INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, goal_id, sort_order) VALUES
    ('BONGOS-V1','gcarry-auto-guardrails','An off-droplet spend ceiling, a scoped file-only automation token, and a hall kill-switch all exist.',gid,10),
    ('BONGOS-V1','gcarry-auto-armed','The cloud-routine execution environment is verified and the safe routine set is armed behind the autonomy flag.',gid,20)
  ON CONFLICT (version_id, criterion_id) DO NOTHING;
  UPDATE tasks SET goal_id=gid, updated_at=now()
   WHERE version_id='BONGOS-V1' AND goal_id IS NULL
     AND id IN (1393,1394,1395,1396);
END $$;

COMMIT;
