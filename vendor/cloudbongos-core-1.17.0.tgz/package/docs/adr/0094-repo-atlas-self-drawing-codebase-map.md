# ADR 0094 — Repo Atlas: a self-drawing map of the codebase

**Status:** Accepted (2026-06-27)
**Track:** internal
**Builds on:** [ADR 0061](<redacted>.md) (context layers), [ADR 0063](<redacted>.md) (generate-don't-narrate), [ADR 0062 §8](<redacted>.md) (generated artifacts), [ADR 0083](<redacted>.md) / [ADR 0091](<redacted>.md) (module system), [ADR 0056](<redacted>.md) (hand-installed deploy script), the world-snapshot precedent (`scripts/snapshots/maybe-render-on-deploy.sh`).
**Promotes:** [idea #457](https://example.com/builders#/idea/457). **Tasks:** [#1640](https://example.com/builders#/task/1640) (this), [#1641](https://example.com/builders#/task/1641) (doc-generator migration).

## Context

[Idea #457](https://example.com/builders#/idea/457) (owner, from Discord): *"A visual and navigable map which allows a non-technical and technical user to understand the codebase of their project and the modules that make it up. Starting with Cloud Bongos, this map should be generated directly off of the code so it also clearly shows what is spaghetti and what is well structured."*

The owner's framing in session: the single most important thing to make legible is **how `.md` files are positioned and how context is managed** in the repo; and, for the module system, to see **the TRUTH — exactly how modules are separated as files and function calls**, not the aspirational doc version. Visual reference: Langfuse's hover-connective boxes, in an isometric (but less-slanted, more-readable) layout, in the Cloud Bongos art style.

Two pre-existing facts shape the design:
- The repo already runs a **"generate self-knowledge on deploy"** pipeline (`gen-repo-map`, `gen-diagrams`, `gen-session-index`, `gen-file-map`) — but those run on the **shipping builder's machine** during `/builder-ship` and are committed into the PR. The owner explicitly wants the **server** to do this regeneration, not the local instance.
- The world-snapshot renderer already regenerates an artifact **server-side on the droplet at deploy**, writes it to a served directory, and never commits it. That is the exact shape this needs.

## Decision

Build the **Repo Atlas**: a Builders' Hall page rendering an isometric, hover-connective, click-for-detail map of the repository, in **two views over one engine**:

1. **Context Layer** — the always-loaded root `CLAUDE.md` (with its live line/char budget gauge) vs the on-demand nested guides, the docs library (ADRs / recipes / audits / session logs, real counts), the database as live-state (never a file), the self-generating artifacts, and broken-link **drift**.
2. **Module Truth** — the real modules carved into `modules/<key>/` (clean boundary, green) vs the `src/bongos` **core blob** (with `db.js` the monolith, red) vs the planned-but-still-fused **ghosts** (the `module-scope-map` roster with no `modules/<key>/` dir yet). Edges are real dependency + boundary facts; a module flips to a violation colour if a require reaches a sibling or deep core.

**Data pipeline (the load-bearing decision):**
- A single generator, `scripts/gds/gen-atlas.js`, emits `public-builders/atlas.json`. It is **pure file-reads — no network, no GDS session** — so it runs headless on the droplet.
- It **reuses the existing truth sources** rather than re-deriving them: `src/bongos/module-scope-map.js` (the MOVED-vs-FUSED roster), `scripts/gds/fitness.js --json` (the kernel-leak count + the boundary rule it applies), `scripts/gds/docs-entropy.js --json` (the stale-link count), the `CLAUDE.md` budget constants, and real `readdir`/LOC counts. The map can't disagree with the gates because it reads the same facts they do.
- **Regeneration is SERVER-SIDE on every deploy**: a non-blocking step in `scripts/deploy/deploy-prod.sh` runs the generator and writes `atlas.json` into the served dir — copying the world-snapshot precedent exactly. Because prod auto-deploys on every merge to `main`, **every ship → fresh map**, regardless of who shipped or from what machine.
- `atlas.json` is a **gitignored build artifact** — never committed, never hand-edited (so it can't drift), and not subject to a CI freshness gate. The page degrades gracefully (a "being drawn" notice) when it is absent.

**Page:** a vanilla `public-builders/atlas.html` + `atlas.js` (no framework, the hall convention), **self-contained Cloud Bongos styling** (its own `--ab-*` tokens so the instance's injected theme never recolours it), auto-laid-out (ring-by-group seed + a relaxation pass so **no two islands touch**, the owner's requirement), hover lights an island's links, **click opens a popup** with that file/module's detail. Gated to **any signed-in builder** (`serve-internal.js`). Built to port to Cloud Bongos.

## Consequences

- **The existing doc generators should migrate to the same server-side trigger** (the owner's "do the same for documentation" ask) — task [#1641](https://example.com/builders#/task/1641). `gen-repo-map` / `gen-session-index` / `gen-file-map` are pure file-reads and move cleanly **once their `fitness.js` `--check` freshness gate is retired and the outputs are gitignored** (otherwise every PR fails the staleness check). **`gen-diagrams` is the exception** — it needs a headless browser (the droplet has none) and an authenticated GDS session for its conceptual slices, so it does NOT migrate cleanly; documented, left as-is.
- **One-time operator step:** `scripts/deploy/deploy-prod.sh` is the hand-installed mirror of the droplet's `~/deploy.sh` (ADR 0056) — the new step goes live only when an operator `scp`s the updated script to the droplet. Until then prod shows the "being drawn" notice.
- `atlas.json` is **public static** (non-sensitive repo-structure facts; the repo gains a public mirror per V4.R71 anyway). It can move behind an authenticated route later if a future instance needs it.
- The map **surfaces drift and spaghetti honestly** — the live stale-link count, the kernel leaks, the 26k-line blob, the `db.js` monolith, the ghosts — which is the point of [#457](https://example.com/builders#/task/457), not a blemish to hide.

## Amendment (2026-07-03 — task 1737)

The "self-contained Cloud Bongos styling" clause is narrowed after the hall redesign (task 1723): the page **chrome** (card, view toggle, caption, legend, popup, badges) now rides the hall's design-token system, so it follows the instance pack and dark mode like every other hall page. What remains isolated — the actual invariant — is the **semantic node/edge palette**: it stays a fixed set (never pack-driven) so an instance's colors can never scramble the map's color-coded meaning. Non-semantic scene values (label ink/halo, ambient wash, hub glow, badge fills) are scoped `--ab-*` vars with dark variants that the renderer reads at draw time and re-reads on `html[data-theme]` flips.

## Alternatives considered

- **A live `/api/gds/*` endpoint** computing the graph per request — rejected: the file structure only changes at deploy, so a live route would repeatedly query disk/DB to serve data that never changes between deploys. Build-time static JSON is the right tool (the same reasoning that keeps the world snapshots static).
- **A committed generated file** (like today's repo-map) — rejected: it reintroduces the builder-machine dependency the owner is explicitly removing, and a committed-but-server-regenerated file goes stale between the commit and the next deploy.
- **Extending the Mermaid diagram pipeline** (`gen-diagrams`) — rejected: those diagrams are conceptual (lifecycle, ranks), not structural, and rendering them needs a headless browser the droplet lacks.
- **A flat force-directed node-graph or a treemap** — rejected for the audience: a force graph tends to a hairball, a treemap hides connections. The isometric "islands + flight-paths" reads for a non-technical builder and matches the owner's Langfuse reference and the Cloud Bongos (sky-whale) brand.
