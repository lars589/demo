# `autonomy` module — the Multi-Agent System (conductor · architect · gate · routine timers)

> A CORE-domain carve (BV1.R83, [ADR 0093](../../docs/adr/<redacted>.md) §1) — the eighth tranche-2 domain extracted from the GDS core, after sessions (R82). `default: true` — the autonomy machinery + the durable in-process routine timer ship to every instance (both inert/no-op until armed or the pool is reachable), so it mounts unconditionally unless an instance disables it.

Owns the **Multi-Agent System** surfaces ([ADR 0024](../../docs/adr/<redacted>.md)):
- the **autonomy gate** (System 3, task 1351) — the $0 deterministic precheck that decides go/no-go before any model boots; a precheck HTTP route + the gate CLI, **inert until `OTB_AUTONOMY_ENABLED=1`**;
- the **routine timers** (System 4 / [ADR 0078](../../docs/adr/<redacted>.md) amendment, task 1382) — the in-process weekly **peer-vote-tally** poller (no model, no external cron);
- the **Conductor** mid-flight dispatch CLI (Phase 4, task 439) and the **Architect** bounded first-principles `--scope` audit CLI (Phase 5, task 459) — domain commands.

## The boundary (the one rule)

The module's `src/`-scanned files (`db.js`, `pollers/`, `routes/`) reach core **only** through the published doorway `../../src/module-api.js` (`coreVersion ^1.11.0`). They must **never** `require()` a core internal (`../../src/bongos/db`, `../../src/bongos/auth`, …) directly, and **never** another module. Core, in turn, must never `require()` a file in here — the route mount + the timer-start both left `src/bongos/`/`server.js`; the loader (`mountModuleRoutes` + `startModulePollers`) wires them now. Both directions are enforced by the BV1.R44/R45 fitness checks.

## Cross-cutting: it OBSERVES lifecycle (the seams)

This is the cross-cutting domain the carve sequence flagged. Two inbound core→autonomy edges existed; each was inverted so the module is wired, not imported:

1. **The routine timer** (was `routineTimers.start()` in `server.js`) → now a **POLLER** (`contributes.pollers:["routine-timers"]`). The loader's `startModulePollers` requires `pollers/routine-timers.js` and calls `start()` at boot / `stop()` at shutdown — the module-agnostic successor to the hardcoded block (the Discord-bot-poller pattern, BV1.R47). server.js is the only `startModulePollers` caller (not `src/platform-server.js`), so a second always-on instance can't double-run. The timer's work is the lifecycle **`tallyPeerVotes`** capability (the SAME transaction `POST /tasks/peer-votes/tally` runs — route + timer share ONE path), reached through the **doorway** (`api.tallyPeerVotes`, a tracked lifecycle leak — it writes karma_log/peer_votes/tasks, all core-owned; relocates behind a `lifecycle.*` port at R86), never a core require.
2. **The autonomy precheck route** (was mounted in `src/bongos/routes.js`) → now a **module route** (`contributes.routes:["autonomy"]`, mounted by `mountModuleRoutes`). `GET /autonomy/precheck` (Archon-gated) calls the gate's `precheck`.

## No port (the sessions/memory shape)

Like `sessions`/`memory`, autonomy registers **no kernel port** (`provides: []`) — **core never calls back into it.** The timer is a loader-started poller, the precheck a module route, and the gate/conductor/architect are CLIs. There is nothing for a port to expose. (`consumes: []` too — `tallyPeerVotes` is a doorway export, not a seam port.)

## Files

| File | What |
|---|---|
| `db.js` | the `autonomy_runs` db slice — `recordAutonomyRun` (audit each precheck decision) + `lastAutonomyHead` (the stored last-`go` head the no-signal check compares origin/main against). Reaches Postgres through the doorway `pool`. |
| `pollers/routine-timers.js` | the in-process weekly **peer-vote-tally** timer (the loader's poller entry — `start`/`stop`). `runPeerVoteTally` resolves the lifecycle `tallyPeerVotes` via the doorway; pure w.r.t. injected `deps` (tests pass `deps.db`). Kill-switch `ROUTINE_TIMERS_DISABLED`; unref'd, best-effort. |
| `routes/autonomy.js` | `GET /autonomy/precheck` (Archon-gated) — the autonomy precheck over HTTP; wraps the gate CLI's `precheck`. Inert (always `go`) until `OTB_AUTONOMY_ENABLED=1`. |

## NOT in this module (the domain CLIs travel with the domain but stay under `scripts/`)

A command travels with its domain but stays a CLI (design 02§1; the sessions/memory precedent). These live under `scripts/gds/` — **outside** the kernel boundary (fitness scans `src/` + `modules/`, not `scripts/`), so they may still read the ideas/economy/lifecycle signals + the grader directly, which a `modules/` file may not:

- **`scripts/gds/autonomy-gate.js`** — the gate CLI (Step 0 of the nightly routines). Its pure decision logic (`decide`, `autofixAllowed`) is `$0`; its `gatherSignals` reads claimable tasks (core db), open ideas (`modules/ideas`), autonomous MTD spend (`modules/economy`), and the autonomy_runs head/record (**this module's `db.js`**). The precheck route + scheduled tasks invoke it.
- **`scripts/gds/conductor-dispatch.js`** — the Conductor mid-flight dispatch (runs grader specialists on the current diff; reuses `modules/grading/grader` + `src/bongos/sensitive-surfaces` + `src/bongos/path-match`).
- **`scripts/gds/architect-audit.js`** — the Architect's bounded `--scope` audit → `docs/audits/` + seed ideas (reuses the grader + `src/bongos/llm-cache`).
- **`scripts/gds/run-routine.js`** — the deterministic-first cron dispatcher (parses a routine's SKILL.md, runs steps at the cheapest sufficient tier).
- **`.claude/scheduled-tasks/`** — the cron routine SKILL.md files that invoke these CLIs (re-pointed at the moved gate; the scripts they call are unchanged paths).

## Tables (owned, not moved)

`autonomy_runs` (migration 126) was created before the module system and stays in core `migrations/` (the shared-schema additive rule the sessions/onboarding carves established). The module owns the *queries*; any **new** autonomy migration belongs in `modules/autonomy/migrations/` namespaced `autonomy_*`.

## Tests

`tests/autonomy_gate.mjs` (the pure gate decision — DB-free), `tests/routine_timers.mjs` (the peer-vote timer — pure w.r.t. injected deps), `tests/conductor.mjs`, `tests/architect.mjs`, `tests/run_routine.mjs` exercise the CLIs (which import from `scripts/gds/…`). The carve discovery-key membership is asserted in `tests/fitness.mjs` / `tests/module_loader.mjs` / `tests/modules.mjs`; the doorway `tallyPeerVotes` export in `tests/module_api.mjs`.
