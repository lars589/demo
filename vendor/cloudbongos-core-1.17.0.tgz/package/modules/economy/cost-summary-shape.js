// src/bongos/cost-summary-shape.js — pure shapers for the cost-summary dimensions
// added by System 1 / task 1345 (by_source, by_tier, savings). Kept pure (no DB,
// no I/O) so db.costSummary() stays a thin SQL+shape layer and the aggregation
// math is unit-testable DB-free (tests/cost_summary_shape.mjs). The audit
// (cost.js, task 1346) reuses these shapes.

function num(n) {
  return Number(n) || 0;
}
function round2(n) {
  return Math.round(num(n) * 100) / 100;
}

// by_source: cost_log rows grouped by source. NULL/empty source → '(unattributed)'
// so the dimension always reconciles to total_usd. Rows arrive pre-sorted by SQL.
function shapeBySource(rows) {
  return (rows || []).map((r) => ({
    source: r.source == null || r.source === '' ? '(unattributed)' : String(r.source),
    total_usd: round2(r.total_usd),
  }));
}

// by_tier: a single SUM row over the four per-tier columns (migration 123).
// Returns the four tiers + their total + the cache_read share of total (the
// marathon cost sink — the headline number System 2 must move). Tiers only sum
// to total over rows that HAVE the split (session/cron rows); legacy/manual rows
// are NULL and contribute 0, so tier_total ≤ overall cost_log total — expected.
function shapeByTier(row) {
  const r = row || {};
  const fresh = round2(r.fresh_input_usd);
  const cacheRead = round2(r.cache_read_usd);
  const cacheWrite = round2(r.cache_write_usd);
  const output = round2(r.output_usd);
  const total = round2(fresh + cacheRead + cacheWrite + output);
  return {
    fresh_input_usd: fresh,
    cache_read_usd: cacheRead,
    cache_write_usd: cacheWrite,
    output_usd: output,
    tier_total_usd: total,
    cache_read_pct: total > 0 ? round2((cacheRead / total) * 100) : 0,
  };
}

// savings: cost_baseline grouped by system tag. saved = baseline - amount.
// Returns per-system rows + roll-up totals. Negative saved (a system that cost
// MORE than its counterfactual) is preserved, not clamped — that's a real signal.
function shapeSavings(rows) {
  const bySystem = (rows || []).map((r) => {
    const baseline = round2(r.baseline_usd);
    const amount = round2(r.amount_usd);
    return {
      system: String(r.system),
      baseline_usd: baseline,
      amount_usd: amount,
      saved_usd: round2(baseline - amount),
      events: r.events == null ? undefined : Number(r.events),
    };
  });
  return {
    by_system: bySystem,
    total_baseline_usd: round2(bySystem.reduce((s, r) => s + r.baseline_usd, 0)),
    total_amount_usd: round2(bySystem.reduce((s, r) => s + r.amount_usd, 0)),
    total_saved_usd: round2(bySystem.reduce((s, r) => s + r.saved_usd, 0)),
  };
}

// cost_calibration: rows from cost_calibration_summary() (migration 143) — one
// per task kind plus an overall '(all)' row. The SQL already ROUNDs to 4dp; we
// normalize numeric strings to numbers and preserve a NULL median_cost_per_credit
// (a kind with no credit-bearing samples) as null rather than coercing it to 0,
// so the dashboard can tell "0 cost per credit" from "no data". The overall row
// (kind '(all)') is also surfaced separately for convenience.
function num4(n) {
  return n == null ? null : Math.round(Number(n) * 10000) / 10000;
}
function shapeCostCalibration(rows) {
  const by_kind = (rows || []).map((r) => ({
    kind: String(r.kind),
    median_cost_per_task: num4(r.median_cost_per_task),
    median_cost_per_credit: num4(r.median_cost_per_credit),
    sample_size: Number(r.sample_size) || 0,
  }));
  return {
    by_kind,
    overall: by_kind.find((r) => r.kind === '(all)') || null,
  };
}

module.exports = { shapeBySource, shapeByTier, shapeSavings, shapeCostCalibration };
