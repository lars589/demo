// Shared helpers for scripts/gds/ship.js — extracted so the guards have unit
// tests instead of only being exercised via the CLI.
// (task 1155 / ADR 0058: needs_trust gate-surface change — e2e proof that a
//  trusted author's PR auto-merges under the enforcing gatekeeper.)
//
// Two concerns live here:
//
//   1. parsePorcelain + trackedDirty  — the working-tree guard that caught the
//      2026-05-10 "phantom ship" bug (agents ran ship.js without ever
//      committing their actual work; the committed-diff scanner reported clean
//      and credits were awarded for zero code change). The guard refuses the
//      ship when the working tree has ANY uncommitted tracked modification or
//      staged change. (touches[] cleanup [2/8], task 877: replaced the old
//      touches[]-scoped dirtyTouchMatches — which was skipped entirely when
//      touches[] was empty, leaving empty-touches tasks unprotected — with this
//      plain clean-tree check. Strictly stronger; untracked / .gitignored files
//      are ignored so autonomous sessions with scratch files aren't refused.)
//
//   2. cleanupMacFinderDupRefs  — find + delete `.git/refs/.../FOO 2` files
//      that macOS Finder / iCloud creates when it duplicates a regular file
//      while syncing. These break `git fetch` with:
//        fatal: bad object refs/heads/<name> 2
//      The fix is to delete them before fetching. /merge-mode already does
//      this; ship.js's autoMerge did not, so every auto-merge bailed today.

const { execSync } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');

function parsePorcelain(out) {
  // `git status --porcelain` lines: "XY path" or "XY orig -> path" for renames.
  // Untracked files come as "?? path". The first 2 chars are status codes,
  // then a space, then the path. Quoted paths (with spaces or non-ASCII) are
  // surrounded by "..." — strip those.
  if (!out) return [];
  const files = [];
  for (const raw of out.split('\n')) {
    if (!raw) continue;
    const rest = raw.slice(3);
    const arrow = rest.indexOf(' -> ');
    const file = arrow >= 0 ? rest.slice(arrow + 4) : rest;
    if (file) files.push(file.replace(/^"|"$/g, ''));
  }
  return files;
}

function trackedDirty(porcelainOut) {
  // Pure: given the raw `git status --porcelain` output, return every file with
  // an uncommitted TRACKED change (modified, staged, deleted, renamed, or
  // unmerged). Untracked files ('?? path') are ignored so autonomous sessions
  // with scratch files aren't false-refused; .gitignored files never appear in
  // porcelain without --ignored, so they're excluded too. Any non-empty result
  // means the builder has work that isn't committed — the ship must refuse.
  if (!porcelainOut) return [];
  const dirty = [];
  for (const raw of porcelainOut.split('\n')) {
    if (!raw) continue;
    if (raw.slice(0, 2) === '??') continue; // untracked — not a phantom-ship risk
    const rest = raw.slice(3);
    const arrow = rest.indexOf(' -> ');
    const file = arrow >= 0 ? rest.slice(arrow + 4) : rest;
    if (file) dirty.push(file.replace(/^"|"$/g, ''));
  }
  return dirty;
}

function classifyEmptyShip(porcelainOut, { allowEmpty = false } = {}) {
  // Decide what an EMPTY committed diff means. Called by ship.js ONLY when the
  // committed diff vs the grader baseline is empty (nothing committed on this
  // branch). Splits the phantom-ship bug from the legitimate no-artifact ship:
  //
  //   - 'uncommitted-work': the working tree carries uncommitted changes
  //     (tracked-dirty OR untracked, .gitignored excluded — parsePorcelain). The
  //     deliverable exists but was never committed → REFUSE. This holds even with
  //     --allow-empty: that flag asserts "there is no artifact", but a dirty tree
  //     proves there is one. This is the 2026-06-21 task-1363 case: a new file
  //     left UNTRACKED, ship.js run without committing, HEAD never moved, yet the
  //     task confirmed + reconciler-shipped → "shipped" with no artifact on main
  //     (the ledger lied — CLAUDE.md §8). The old trackedDirty preflight ignored
  //     untracked files, and the old empty-diff guard was skipped under
  //     --skip-grade, so this slipped through both.
  //   - 'allow-empty': clean tree + the builder explicitly passed --allow-empty →
  //     a genuine no-artifact / DB-only ship. ALLOW.
  //   - 'nothing-to-ship': clean tree, no committed work, no --allow-empty →
  //     nothing happened. REFUSE (the original empty-diff-guard behavior, now
  //     independent of --skip-grade).
  //
  // Pure + DB-free so it's unit-testable (tests/ship_preflight.mjs).
  const uncommitted = parsePorcelain(porcelainOut);
  if (uncommitted.length > 0) {
    return { refuse: true, reason: 'uncommitted-work', uncommitted };
  }
  if (allowEmpty) {
    return { refuse: false, reason: 'allow-empty', uncommitted: [] };
  }
  return { refuse: true, reason: 'nothing-to-ship', uncommitted: [] };
}

function gitDirFor(cwd) {
  // Resolve the *actual* refs directory for a given worktree. In a linked
  // worktree, `.git` is a file containing `gitdir: <path>` that points at
  // the main repo's `.git/worktrees/<name>` directory. Refs (heads/) live in
  // the parent .git, not the per-worktree gitdir. We need the parent.
  //
  // `git rev-parse --git-common-dir` returns a relative path (`.git`) in a
  // top-level repo and an absolute path in a linked worktree. Resolve here
  // so callers always get an absolute path regardless of where they invoke.
  try {
    const out = execSync('git rev-parse --git-common-dir', {
      cwd,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
    }).trim();
    return path.isAbsolute(out) ? out : path.resolve(cwd, out);
  } catch (_) {
    return null;
  }
}

function cleanupMacFinderDupRefs(cwd) {
  // Delete any `.git/refs/**/FOO 2` files left by macOS Finder/iCloud. These
  // are bad refs that break `git fetch` with the "did not send all necessary
  // objects" / "bad object" error we saw all day on 2026-05-10.
  //
  // We touch only the refs/ subtree — packing/unpacking concerns elsewhere
  // aren't this function's job. Returns a list of files deleted (mostly for
  // tests + telemetry).
  const gitDir = gitDirFor(cwd);
  if (!gitDir) return [];
  const refsRoot = path.join(gitDir, 'refs');
  if (!fs.existsSync(refsRoot)) return [];

  const deleted = [];
  const walk = (dir) => {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (_) {
      return;
    }
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        walk(full);
      } else if (/ \d+$/.test(e.name)) {
        // Matches " 2", " 3", etc. — the pattern Finder uses for duplicates.
        try {
          fs.unlinkSync(full);
          deleted.push(full);
        } catch (_) {
          // Permission glitch; non-blocking — git will surface its own error.
        }
      }
    }
  };
  walk(refsRoot);
  return deleted;
}

function findMainWorktree(cwd) {
  // The auto-merge in ship.js runs git on the worktree that has `main`
  // checked out. Feature work happens in linked worktrees under
  // .claude/worktrees/*; the bare top-level checkout is where `main` lives.
  //
  // `git worktree list --porcelain` emits blocks like:
  //   worktree /path/to/main
  //   HEAD <sha>
  //   branch refs/heads/main
  //
  //   worktree /path/to/feature
  //   HEAD <sha>
  //   branch refs/heads/claude/feature
  //
  // Returns the worktree path whose branch is `main`, or null if none.
  try {
    const out = execSync('git worktree list --porcelain', {
      cwd,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    const blocks = out.split('\n\n').filter(Boolean);
    for (const block of blocks) {
      let dir = null;
      let branch = null;
      for (const line of block.split('\n')) {
        if (line.startsWith('worktree ')) dir = line.slice('worktree '.length);
        else if (line.startsWith('branch refs/heads/')) {
          branch = line.slice('branch refs/heads/'.length);
        }
      }
      if (branch === 'main' && dir) return dir;
    }
  } catch (_) {
    // Not a git repo or git not available — caller will fall back.
  }
  return null;
}

// task 932: post-ship working-tree CLOSE-OUT plan (pure). The mirror image of
// the preflight guard above — preflight refuses to START a ship over a dirty
// tree; this decides, AFTER a ship has SUCCEEDED, whether the tree is already
// archive-clean or still carries leftover scratch (untracked files the preflight
// lets through, generated artifacts, post-commit edits) worth stashing so the
// session archives cleanly. Pure + tested here; ship.js does the actual `git
// stash` based on this. Uses parsePorcelain so tracked AND untracked paths count
// (untracked scratch is the common post-ship leftover, since preflight ignores
// it). `taskId` only shapes the recoverable stash label.
function closeoutPlan(porcelainOut, taskId) {
  const leftover = parsePorcelain(porcelainOut);
  return {
    clean: leftover.length === 0,
    leftover,
    stashLabel: `otb-postship-${taskId}`,
  };
}

module.exports = {
  parsePorcelain,
  trackedDirty,
  classifyEmptyShip,
  cleanupMacFinderDupRefs,
  gitDirFor,
  findMainWorktree,
  closeoutPlan,
};
