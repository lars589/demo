# ADR 0052 — Sandbox for everyone: a game-only preview entrypoint + the game in the starter clone

**Date:** 2026-06-13
**Context:** GDS-V3, task [#1001](https://example.com/builders#/task/1001) (clone-scope + ungate) and task [#1002](https://example.com/builders#/task/1002) (hardware-verify). Builds on [ADR 0044](<redacted>.md) (the per-box live game preview / "sandbox") and [ADR 0031](<redacted>.md) (cloud dev boxes + rank-scoped source). Companion to [ADR 0046](<redacted>.md) (sandbox-first review) and [ADR 0016](<redacted>.md) (authority is server-enforced — source visibility grants nothing). **Reverses the full-clone gate from task [#903](https://example.com/builders#/task/903).** Decision by Lars, 2026-06-13.
**Status:** Accepted. Mechanism implemented under task [#1001](https://example.com/builders#/task/1001) (game-only entry `src/preview-server.js` + shared `registerGameRooms()` helper, `STARTER_SPARSE_PATHS` widened by `src/world`/`src/rooms`/`public`, `box-game-preview.service` repointed at the game-only entry, `box-source-fetch.sh` ungated); **hardware-verified under task [#1002](https://example.com/builders#/task/1002) (2026-06-14)** — a fresh **Xenos starter-scope** box (`LarsCode`) served the playable game over the public tunnel at `sandbox-<login>.example.com` (HTTP 200, Phaser client + `/game/*` assets) while **(b)** `/api/gds/*` returned 404 through that host (game-only entry does not mount the internal API) and **(c)** `migrations/` was absent on the box (the game paths `src/world`/`src/rooms`/`public` were present). Box deprovisioned after the run.
**Track:** `internal` (dev boxes / builder experience).

## Problem

ADR 0044's sandbox (`sandbox-<login>.example.com`) only works on a Metic+ **full-clone** box. A starter (Xenos/Thetes) box can't serve it, for two reasons found in the code:

1. **The game isn't on the box.** `STARTER_SPARSE_PATHS` in `src/bongos/box-access.js` deliberately *excludes* the game — `src/world`, `src/rooms`, and the `public/` client are the "crown jewels" it protects.
2. **`server.js` can't boot game-only.** `server.js` top-level-requires `./src/bongos/routes` and `./src/rooms/*` and mounts `/api/gds` — so `box-game-preview.service` (which runs `node /workspace/server.js`) cannot start without the full internal stack present.

Task 903 therefore gated the preview on full-clone source. The concrete symptom (2026-06-13): builder `IAMMASTERQUA` (Thetes) — `curl localhost:3000` and the sandbox come up empty, with no explanation. Lars's directive: **the sandbox must work for all ranks.**

## The finding that shaped the design

Investigating the clone scope flipped our initial framing. A starter box **already carries the build tooling** — `scripts/`, `.claude/`, `src/bongos` (the GDS lib + API client; no secrets), `infra/`, `docs/`, `art/` — by deliberate choice (a 2026-06-07 note in `box-access.js`: *"usability wins so newcomers can actually interface with the builder skills"*; they need that tooling to run `/builder-*` at all). What a newcomer box lacks is the **game**. And per ADR 0016 authority is server-enforced, so reading source grants no privilege.

So the privacy boundary that actually matters for a **public** per-box URL is **runtime, not source**: `server.js` also serves `/api/gds`, and the sandbox tunnel points at the whole server — so today `sandbox-<login>.../api/gds/*` is reachable (degraded) on full boxes. Lars's decision (2026-06-13): **runtime-only gating** — add the game everywhere, serve the sandbox game-only, and leave the existing source posture as-is (source-tightening, idea [#213](https://example.com/builders#/idea/213), stays deferred).

## Decision

Make the sandbox available on every box via two changes, keeping the source posture unchanged.

### 1. Game in the starter clone
Add the product/game paths the preview needs — `src/world`, `src/rooms`, `public/` — to `STARTER_SPARSE_PATHS` (`src/bongos/box-access.js`). `migrations/` stays excluded (DB schema; a degraded-DB preview doesn't need it). Every box can now materialize the game.

### 2. A game-only preview entrypoint (the heart of "keep internals private")
Add a dedicated, minimal game-only server entry (e.g. `src/preview-server.js`) that serves **only**:
- `express.static(public/)` — the game client, and
- the **game** Colyseus rooms (`WorldRoom` + `QueueRoom`) over the WS transport, plus
- the minimal **game** HTTP endpoints the client needs to bootstrap (identity/queue/world — the implementer ports these from `server.js`'s non-`/api/gds`, non-`/builders` wiring).

It explicitly does **not** mount `/api/gds`, the `BuildersHallRoom`, the Discord bot, the uptime poller, or the status-host routing. `box-game-preview.service` runs **this** entry instead of `server.js`. To avoid the two entrypoints drifting on the room list, factor the game-room registration into a shared `registerGameRooms(gameServer)` helper that both `server.js` and the preview entry call.

Consequences of this split:
- A box never needs to boot the full stack to show the game; the game-only entry has no `src/bongos` dependency, so the public sandbox never serves the internal API even though `src/bongos` is present on the box.
- It **closes the current runtime exposure** where `sandbox-<login>.../api/gds/*` is reachable on full boxes — a net security improvement.
- `server.js` (the prod, full-stack entry) is left untouched — no rank-conditional behavior bolted onto the sensitive shared file.

### 3. Ungate the preview (reverse task 903)
`infra/box-source-fetch.sh` enables `box-game-preview.service` on **every** box, not only full-clone ones, now that the game paths are in the starter clone and the game-only entry boots without `src/bongos`.

## Why game-only entrypoint over a conditional mount

The alternative was to make `server.js` lazily/conditionally mount `/api/gds` (guard the `require`, skip on a box). **Rejected:** `server.js` is sensitive shared infra; adding rank-conditional runtime behavior there is the riskier path — a wrong guard mounts the internal API on a public per-box URL — and it ships `server.js`'s full wiring to every box. A separate, minimal, auditable game-only entry has a tiny fixed surface that *cannot* expose `/api/gds`. The only cost — keeping two game-room registrations in sync — is neutralized by the shared `registerGameRooms()` helper.

## Security posture

- **Source unchanged.** Newcomers keep the tooling source they already have, plus the game. The game client already ships to every browser; the game server (`src/world`/`src/rooms`) is product code, not permission/secret code. Authority stays server-enforced (ADR 0016) — a starter box reading game source gains nothing.
- **Runtime tightened.** The public sandbox serves game-only on every box; `/api/gds` and the BuildersHall are no longer reachable via `sandbox-<login>`. This is strictly safer than today.
- **Degraded-DB unchanged** (ADR 0044): no Postgres on the box; the game-only entry runs DB-less exactly as the preview does today.

## Consequences

- Every builder, any rank, gets a working live sandbox — fixes the `IAMMASTERQUA` dead-end and lets newcomers actually see their work.
- New small artifact (the game-only entry) + a shared room-registration helper to prevent drift; `box-game-preview.service` `ExecStart` changes; `STARTER_SPARSE_PATHS` widens by three game paths; task 903's gate is removed.
- **Verification (task 1002):** provision a real starter-scope (Xenos/Thetes) box and confirm (a) `sandbox-<login>` serves the playable game, (b) `sandbox-<login>.../api/gds/*` is **not** reachable, and (c) `migrations/` (and anything else still gated) is absent on the box.

## Alternatives considered

- **Conditional `/api/gds` mount in `server.js`** — rejected (above): riskier on a sensitive shared file.
- **Prebuilt game artifact, no source** — rejected per Lars's "just the game" choice; also breaks edit-then-preview.
- **Full clone for every box** — rejected: pulls `migrations/` and everything with no benefit; source-privacy is moot given server-enforced authority, so there's no reason to widen beyond the game.

## Follow-up (out of scope here)

Finer-grained source tightening — removing `scripts`/`.claude`/`src/bongos` from newcomer boxes (idea [#213](https://example.com/builders#/idea/213)) — remains deferred. Lars chose runtime-only gating for this change; tightening source would require a separate tooling-delivery design so newcomers can still run `/builder-*`.
