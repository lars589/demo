-- 179 search_chunks usefulness signal — record whether a recalled chunk was
-- actually USED, and let that signal drive ranking (ADR 0095 C3, task 1660).
--
-- search_chunks is a CORE-owned table (migration 103_search_chunks.sql), so the
-- usefulness columns land as a CORE migration here, NOT a module-owned one — a
-- module migration may only touch its own memory_-namespaced tables (ADR 0083
-- §Decision #5, enforced by fitness.js). The memory module owns the *queries*
-- over search_chunks (modules/memory/search.js); core owns the table's schema.
--
-- WHY (ADR 0095 C3): nothing tracked whether recalled knowledge actually helped.
-- A usefulness signal lets high-value chunks rise and dead weight fade, keeping
-- the recall corpus high-signal as it grows. The signal is two monotonic counters
-- (a 'useful'/'not_useful' vote — claude-mem's save-result shape: useful vs
-- dead_end) plus the last-useful timestamp. The recall ranker reads them to apply
-- a small, bounded multiplicative boost to the RRF fusion score (search.js).
--
-- Additive + idempotent: ADD COLUMN IF NOT EXISTS is safe to re-run.

BEGIN;

ALTER TABLE search_chunks
  -- Times a recall caller marked this chunk as having helped (the 'useful' vote).
  ADD COLUMN IF NOT EXISTS useful_count     integer     NOT NULL DEFAULT 0,
  -- Times a caller marked it as NOT helpful / a dead end (the decay vote).
  ADD COLUMN IF NOT EXISTS not_useful_count integer     NOT NULL DEFAULT 0,
  -- When the chunk was last marked useful (carried for future time-decay /
  -- observability; not yet weighted in the ranker).
  ADD COLUMN IF NOT EXISTS last_useful_at   timestamptz;

INSERT INTO schema_migrations (version) VALUES ('179_search_chunk_usefulness')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
