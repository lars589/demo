-- migration 104: per-builder dev-box provisioning block (task 1163, idea 257)
--
-- Idea 257 ("Dev Box management"): an Archon needs to bar a specific builder
-- from opening dev boxes (abuse, runaway cost, a departed teammate). This adds
-- the block flag + a small audit trail to `builders`, parallel to the budget
-- ceiling (migration 089).
--
-- It is a builder-LEVEL capability flag, NOT a per-box row, deliberately:
--   * it must apply BEFORE the builder ever has a builder_boxes row (block a
--     newcomer pre-emptively), and
--   * it must SURVIVE box teardown (a destroyed box leaves a state='destroyed'
--     row; the block must outlive it), so it cannot hang off builder_boxes.
--
-- Enforced server-side in boxes.decideEnsureAction / POST /box/ensure
-- (BOX_PROVISION_BLOCKED, fail-closed) — the block bars the "open" actions
-- (provision a new box, wake a parked one) but does NOT by itself tear down a
-- box that is already running (that stays the Archon's explicit, separate
-- choice). The markdown/UI only describes this; the server is the authority
-- (ADR 0016 trust boundary). Toggled by PATCH /boxes/:builderId/block (archon);
-- the same call can optionally also enqueue a deprovision intent ("close the
-- box they have running too").

ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS box_blocked        boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS box_blocked_reason text,
  ADD COLUMN IF NOT EXISTS box_blocked_at     timestamptz,
  ADD COLUMN IF NOT EXISTS box_blocked_by     bigint REFERENCES builders(id);

-- Counter hygiene: keep the migration-number allocator above this file so the
-- next reservation can't collide with 104 (mirrors migration 089's tail).
UPDATE migration_counter SET next_number = GREATEST(next_number, 105) WHERE id = 1;

INSERT INTO schema_migrations (version) VALUES ('104_builder_box_blocked')
  ON CONFLICT DO NOTHING;
