# The branding contract (`config/branding.*`)

The branding contract is how a **Cloud Bongos instance** supplies its identity. It is the keystone of the Cloud Bongos decoupling (ADR [0062](adr/<redacted>.md) §3; task [#1192](https://example.com/builders#/task/1192) / V4.R53). One config, read through one resolver (`src/branding.js`), so brand strings live in **one place** instead of the ~90 hardcoded sites they occupy today.

> Generalizes the single-config rule of [ADR 0004](adr/0004-example-name-and-trademark-acceptance.md) (the civ name must be one string, never baked into code) from one string to the whole identity surface. Code reads `branding().identity.worldName`, never `"Example"`.

## Resolution precedence (highest wins)

```
env override   →   instance config (config/branding.json)   →   neutral starter (config/branding.neutral.json)
```

- A fresh instance with **no** `config/branding.json` resolves to the **plain neutral identity** — never to a host's brand (fail-to-vanilla).
- `config/branding.neutral.json` is **customer 0** (vanilla Cloud Bongos). `config/branding.json` is the host instance — here, **customer 1** (Example / OTB).
- **Configurable-root ([ADR 0108](adr/<redacted>.md) §1, task 1881/W1 shipped):** `NEUTRAL_PATH` resolves off `resolveCoreRoot()` (the neutral starter ships WITH the core package) and `INSTANCE_PATH` off `resolveInstanceRoot()` (the instance pack is host content) — [`src/instance-config.js`](../src/instance-config.js). Both resolvers return the repo root today, so resolution is unchanged; the split only diverges once a consumer installs the core as a package.
- Env overrides apply only to the operationally-swapped fields (origins + cookie domain) for dev/staging, keyed `<envPrefix>_<FIELD>` (e.g. `OTB_PUBLIC_ORIGIN`). Everything else comes from the committed pack.

## Fields

| Path | Meaning |
|---|---|
| `identity.productName` | The product name (e.g. "Off the Boats"). **Required.** |
| `identity.worldName` | The in-world / civilization name rendered at runtime (e.g. "Example"). **Required.** |
| `identity.company` | `{ name, site }` of the operating company (may be empty). |
| `llmProjectName` | The project name injected into grader / architect / onboarding **LLM prompts**, so a non-OTB instance is graded against its own identity. **Required.** |
| `domains.publicOrigin` | Public game/app origin. **Required.** |
| `domains.buildersOrigin` / `statusOrigin` | Hall + status origins. **These three (`publicOrigin`/`buildersOrigin`/`statusOrigin`) are the docs-discovery contract** ([ADR 0114](adr/<redacted>.md)): the hall is the canonical doc-reading surface, `/docs` on `publicOrigin` renders the API reference, the status page is the outage fallback. `GET <publicOrigin>/api/bongos` re-advertises them (`hall`/`status`/`public`) so an agent resolves the surfaces with no hard-coded host. |
| `domains.cookieDomain` | Session cookie domain (`""` = host-only — the safe default; never widen to a parent domain by accident). |
| `domains.oauthOrigin` | Canonical sign-in origin. |
| `domains.devBoxBase` | Apex zone the **proxied** browser-terminal + sandbox hosts ride (`term-<login>.<devBoxBase>`, `sandbox-<login>.<devBoxBase>`). Must be a one-label-under-apex zone so free edge TLS (`*.<apex>`) covers it — a two-label host fails edge TLS (the [#771](https://example.com/builders#/task/771) lesson). Empty ⇒ no managed boxes. |
| `domains.sshBoxBase` | Zone for the **legacy direct-IP SSH** box host (`box-<login>.<sshBoxBase>`, unproxied). Deliberately distinct from `devBoxBase` (one proxied/edge-TLS, one direct-IP). |
| `domains.sandboxPrefix` / `termPrefix` | Subdomain prefixes for the sandbox-preview + browser-terminal hosts. |
| `repo` | `{ owner, name }` GitHub binding. |
| `db.database` | DB name the GDS pool connects to when neither `DATABASE_URL` nor `PGHOST`/`PGDATABASE` is set (`src/bongos/pool.js`, ADR 0062 §5). `null` in the neutral starter = **fail loud** rather than silently target a host DB. |
| `currency` | `{ label, symbol }` — the reward unit label (e.g. "drachmae"). Display only. |
| `reward` | `{ marginPct, usdPeg }` — the per-instance reward POLICY the economy module reads ([ADR 0054](adr/<redacted>.md), task 2009): the cost-plus margin percent (default `20`) and the drachmae-per-USD peg (default `1`). A committed, code-reviewed change — not a live UI knob. Omit ⇒ code defaults (20% margin, 1:1 peg). |
| `models` | `{ main, subagentDefault, subagentRoutine }` — the per-instance subagent model-allocation DEFAULT the builder-settings module reads (task 2011): the tier for the main session, subagent-default work, and routine plumbing (tiers: `haiku`/`sonnet`/`opus`/`fable`). A per-builder override resolves over this. Omit ⇒ code defaults (`opus`/`opus`/`haiku`). |
| `tracks` | The configurable version-track set (replaces the hardcoded `product\|internal`). |
| `theme` | `{ palette, mode }` — palette file ref + theme mode. |
| `copy` | Instance copy keys (tagline, hallName, notFound, …). Full copy pack adoption = task [#1196](https://example.com/builders#/task/1196). |
| `envPrefix` | Env-var namespace for overrides (`OTB`, `CLOUDBONGOS`, …). |

**Not here:** feature-module on/off flags (game, art, discord, dev-box) are a sibling config owned by R54 (task [#1193](https://example.com/builders#/task/1193)).

## Using it

```js
const { branding } = require('./src/branding');
const b = branding();              // resolved singleton (env → config → neutral)
res.send(`Welcome to ${b.identity.worldName}`);
```

Tests drive the pure resolver with injected objects (no I/O): `resolveBranding({ neutral, instance, env })`. See `tests/branding.mjs`.

### On the client (R56 task [#1195](https://example.com/builders#/task/1195) + R57 task [#1196](https://example.com/builders#/task/1196))

The browser never sees the full pack — only the **client-safe projection** `clientBranding()` (a small allow-list — `{ identity, currency, theme, copy, rankLabels }`; origins, repo, db name, `llmProjectName`, and env prefix stay server-side). It reaches the front-end two ways:

- **On-box (hall + status served from the droplet):** injected synchronously by `mountInternalSurfaces` (`src/bongos/serve-internal.js` → `injectBrandingGlobal`) into the page `<head>` as **`window.__BRANDING__`** (the strings) **plus theme markup** (`themeMarkup` → a `:root` palette/font-var override `<style>`, the web-font `<link>`s, and the favicon `<link>`). The `<style>` lands after the page's own stylesheet so the pack wins. No fetch, no flash-of-default.
- **Off-box (the GitHub-Pages status page):** read cross-origin from **`GET /api/gds/public/branding`**.

R56 seeded the projection with the configurable **currency label** (`public-builders/brand-apply.js` fills `[data-currency-label]` / `[data-currency-tmpl]` markup + `window.OTBBranding.currencyLabel()`). R57 widens it to the **LOOK** — `theme.ui` (palette + fonts + favicon; note this is the WEB theme, distinct from the server-only `theme.palette` game pixel-art path) — and the **rank display-label map** (`window.OTB.rankLabel()` reads `rankLabels`; the rank ENUM stays Greek by decision, only the label is presentation). The remaining archaic **page copy + identity strings** (titles, ledes, "washed ashore" flavor) are tracked as the R57 copy-pack follow-up.

## Branding a new instance

Copy `config/branding.neutral.json` → `config/branding.json` and fill it in. The fastest path is to hand your own LLM the prompt in [`branding-fill-prompt.md`](branding-fill-prompt.md), which interviews you and emits a valid pack.
