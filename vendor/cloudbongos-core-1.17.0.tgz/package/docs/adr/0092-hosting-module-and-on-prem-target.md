# 0092 — Hosting module + on-prem (warehouse) hosting target

- **Status:** Accepted (direction decided with the owner 2026-06-27; build is task-pending — see Implementation)
- **Date:** 2026-06-27
- **Deciders:** Lars (Archon), Claude

**Builds on:** [ADR 0083](<redacted>.md) (modular architecture — the module this capability ships as), [ADR 0089](<redacted>.md) (the `ModelProvider` `openai-compatible` adapter the on-prem inference target reuses, and its decisive hosting-cost finding), [ADR 0062](<redacted>.md) (core↔host decoupling — the warehouse box is host-instance config, not portable core), [ADR 0081](<redacted>.md) (swappable adapters against a neutral contract), [ADR 0031](<redacted>.md) (cloud dev boxes — a workload a later phase may partly displace), [ADR 0060](0060-gds-retrieval-layer.md) (recall/embeddings — a consumer), [ADR 0088](<redacted>.md) (the per-character LoRA deferred as "needs GPU training + an open model" — a workload this enables), [ADR 0016](<redacted>.md) / [ADR 0043](<redacted>.md) (server-enforced trust boundary the box must never weaken), [ADR 0033](<redacted>.md) (the precedent for a useful service that sits *outside* the trust boundary).

**Track:** `internal` (a portable Cloud Bongos platform capability).

---

## Context

Example wants to stand up a physical server inside the warehouse to (a) cut software-hosting cost, (b) get cheaper access to open-weight LLMs and code, and (c) capture other on-prem advantages. OTB runs on a <$5K/yr budget ([CLAUDE.md §4](../../CLAUDE.md)): a ~$14/mo DigitalOcean droplet for prod, cloud LLM APIs (Claude for code, Gemini for art), and per-builder cloud dev boxes ([ADR 0031](<redacted>.md)). The largest *variable* cost is LLM spend.

This ADR records the **scope-of-use** decision — the first of the four phases the owner set: *scope use → scope build → hardware setup → software use* — and the shape the capability ships in. The build, hardware, and software phases are task-pending.

### The reframe: a portable module + a host-specific target

A warehouse server is *hardware*; a Cloud Bongos module is *software that mounts into a running instance* ([ADR 0083](<redacted>.md)). So "the hosting module" is **not** "the server in a folder." Following the core↔host split already used for branding ([ADR 0062](<redacted>.md)) and design tools ([ADR 0081](<redacted>.md)):

- **The `hosting` module (portable core):** a broker, default-**OFF**, that exposes labeled compute/storage **seams** and resolves each to a configured **target**. The default target is today's cloud/APIs, so a vanilla instance behaves exactly as it does now (fail-to-vanilla, like the loader with no `modules/`).
- **The warehouse box (host-instance config):** one **on-prem target** an adapter points at, declared in OTB's instance config — not in portable code. Another Cloud Bongos instance declares none and stays all-cloud.

Two properties fall straight out, and they answer the two standing objections to on-prem:

1. **Nothing depends on the box.** Each seam resolves through `resolveOptional(port, cloudDefaultFn)` ([ADR 0083](<redacted>.md)); a target marked unreachable falls back to cloud per-call. The box is an opportunistic cost-saver, never a single point of failure. (This is also why public, real-time prod — the game's Colyseus rooms — stays in the cloud: you can't fail a live socket over mid-session.)
2. **Every Example instance shares it.** The owner chose to size and abstract the box as a shared backend across all Example Cloud Bongos instances — one GPU amortized across projects is what raises utilization enough to matter.

### Honest economics — what the GPU is and isn't good for

[ADR 0089](<redacted>.md)'s market sweep is decisive and we adopt it rather than relitigate: **at low volume, pay-per-call open-model APIs (DeepInfra / OpenRouter) beat self-hosting** — a few-thousand-calls/month workload is ~$1–5/mo on API, and a fixed, cached prompt crushes the bill. A self-hosted GPU only wins when it is *kept busy* or when per-call cloud pricing is high.

So the warehouse GPU earns its keep on a **narrower** set than "all inference":

- **GPU-bound batch generation** — art image-gen at volume across instances (priced per-image in the cloud).
- **Model fine-tuning / training** — the per-character LoRA [ADR 0088](<redacted>.md) deferred as "level-2 (needs GPU training + an open model)"; cloud charges steep per-GPU-hour, an owned card amortizes.
- **Always-busy bulk jobs** — overnight eval/analysis at a scale that saturates the card.

The **non-GPU wins** stand on their own:

- **Backups + bulk storage** — today our secrets live only on the droplet, *unbacked-up*; a NAS role closes a real gap.
- **An unmetered experimentation sandbox** — run pipelines and model evals without metering every token.
- **An always-on cron host** for the ~17 scheduled routines.

Conversely — correcting an earlier hand-wave in this session — **embeddings and low-volume grading are cheaper on pay-per-call APIs** and are *not* a GPU justification by themselves; they move on-prem only opportunistically once the box exists, or for data-locality. **Code that ships stays on Claude regardless** (the quality-first rule, [CLAUDE.md §2](../../CLAUDE.md)).

### Owner decisions (2026-06-27)

1. **Who it serves:** all Example Cloud Bongos instances (shared backend; build the cross-instance abstraction now).
2. **Quality posture:** **conservative** — local open-weight models do NON-SHIPPING work only (batch gen, training, eval, opportunistic embeddings, storage); shipping code stays on Claude. Expanding posture later is a config change, not a rebuild.
3. **Proceed:** the capability is worth building — justified by the cross-instance multiplier + the owned-asset/training optionality + the storage/sandbox wins, **not** by near-term API savings alone.

---

## Decision

**Ship a portable `hosting` module (default-OFF, fail-to-vanilla) that brokers compute and storage workloads to configured hosting targets through kernel seams, reusing the [ADR 0089](<redacted>.md) `ModelProvider` adapter contract for inference. A GPU box in the Example warehouse is OTB's first on-prem target — one adapter backend declared in host-instance config, shared across Example instances, with automatic cloud fallback so nothing ever depends on the box.**

### 1. The module shape

```
modules/hosting/
  module.json                       # key "hosting"; default false; coreVersion ^1.x
  routes/hosting.js                  # Archon-gated admin: register/inspect targets, health, routing policy
  pollers/target-health.js          # heartbeat each target; flip healthy/unreachable (drives fallback)
  adapters/                         # cloud (default) + on-prem (openai-compatible, per ADR 0089) backends
  migrations/001_hosting_targets.sql # hosting_targets, hosting_jobs (namespaced hosting_*)
  CLAUDE.md                          # per-module reference
```

### 2. Seams it provides (ports)

The module registers providers; consumers resolve via `resolveOptional(port, cloudDefaultFn)`, so a box-less or module-off instance degrades to cloud automatically.

| Seam | Consumer(s) | Conservative-posture target |
|---|---|---|
| `inference.run` | grader ([ADR 0089](<redacted>.md)), eval cron | API by default; on-prem only when saturated / data-local |
| `imagegen.run` | art-pipeline | **on-prem GPU** (batch) when up, else Gemini |
| `embeddings.embed` | recall ([ADR 0060](0060-gds-retrieval-layer.md)) | API (cheap) by default; on-prem opportunistic |
| `training.run` | art-pipeline (LoRA, [ADR 0088](<redacted>.md) L2) | **on-prem GPU** |
| `storage.put/get` | backups, art assets | **on-prem NAS** + offsite copy |

Inference does **not** reinvent [ADR 0089](<redacted>.md): the on-prem target is just one more `openai-compatible` `ModelProvider` endpoint (vLLM / Ollama) alongside the hosted ones. The hosting module adds the *target selection + health/fallback + sharing config* around it.

### 3. Network + trust boundary

- **Ingress:** the cloud instance reaches the warehouse box over an **outbound tunnel the box initiates** (e.g. Cloudflare Tunnel or WireGuard) — no open inbound ports, no static-IP requirement, no DDoS exposure at the warehouse. This sidesteps the whole residential/commercial-internet problem.
- **Trust boundary ([ADR 0016](<redacted>.md) / [ADR 0043](<redacted>.md)):** the box runs jobs and holds model weights, but authority stays server-enforced in the cloud GDS. The box sits **outside** the trust boundary — like Discord ([ADR 0033](<redacted>.md)): it can compute, it can never grant rank or land code. A compromised box can degrade or poison *non-shipping* outputs (hence the conservative posture, and the grader staying authoritative), never escalate permissions.

### 4. How this subproject is filed (the durable home)

- **This ADR** — the decision + shape + phased plan; the pickup point a future session reads.
- **GDS DB (live state)** — the scoping task [#1618](https://example.com/builders#/task/1618) (shipped with this ADR), and the follow-ons [#1619](https://example.com/builders#/task/1619) (build-scope), [#1620](https://example.com/builders#/task/1620) (hardware), [#1621](https://example.com/builders#/task/1621) (cost read-out).
- **`modules/hosting/` + its nested `CLAUDE.md`** — created in Phase 2 via `bongos module new hosting`.
- **Session log** — this session's record under `docs/session-logs/`.

---

## Consequences

- A vanilla Cloud Bongos instance stays **byte-identical to today** (module off → every seam resolves to cloud).
- OTB gains an owned compute/storage asset and an unmetered sandbox, and closes the secrets-backup gap.
- **New surface to maintain:** the module, the tunnel, the box. Mitigated by fail-to-vanilla + conservative posture — no shipping path depends on it.
- Near-term dollar savings are **modest**; the bet is on utilization (training + batch gen, pooled across instances) and optionality. Revisit at the build phase against real spend (task [#1621](https://example.com/builders#/task/1621)).

## Implementation

Owner-set phased arc — scope use ✅ (this ADR, task [#1618](https://example.com/builders#/task/1618)) → scope build (task [#1619](https://example.com/builders#/task/1619)) → hardware (task [#1620](https://example.com/builders#/task/1620)) → software use. The cost read-out (task [#1621](https://example.com/builders#/task/1621)) is an independent prerequisite input. A full done-when criterion + build task tree gets seeded at the build phase (likely via `/planning-session`).

### Open questions (deferred to the build phase)

- **Warehouse realities** (internet class, static IP, upload bandwidth, ISP terms on servers, power/cooling/space, on-site hands) — Lars to confirm; they gate the hardware spec (task [#1620](https://example.com/builders#/task/1620)).
- GPU / VRAM class, and whether one card serves both inference and training.
- Tunnel technology + secret handling for the box (it must never hold a credential that can land code).
- Final module key (`hosting` vs `compute`) and whether storage is a separate module.
