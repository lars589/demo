# ADR 0049 — The split parallel-safety contract (detect-at-merge for humans, gate for the autonomous runner)

**Date:** 2026-06-13
**Context:** GDS-V3, task [#881](https://example.com/builders#/task/881), step [6/8] of the `touches[]` simplification cluster ([#875](https://example.com/builders#/task/875)–[#883](https://example.com/builders#/task/883)). Records the parallel-safety model that the cluster's code changes established — see the architect audit [`docs/audits/<redacted>.md`](../audits/<redacted>.md). Supersedes the *predictive* framing implicit in [ADR 0010](0010-pms-architecture.md) (GDS architecture) and [ADR 0015](<redacted>.md); complements [ADR 0017](<redacted>.md) (the "a hard block turned correct work into deferred backlog" lesson).
**Status:** Accepted.
**Track:** `internal` (development system / methodology).

## Problem

For most of GDS's life, parallel-safety rested on a **prediction**: every task declared a `touches[]` file list up front, and a stack of machinery tried to prove — *before any code existed* — that two claims wouldn't collide. The audit found this stack was three disagreeing matchers across a claim-time 409, a ship-time drift scanner, and a CI gate, mis-documented as a "warning" when it actually withheld credits. It was the felt source of "slowed builders": code legitimately wanders into files nobody predicted, and a wrong prediction blocked or de-credited correct, mergeable work.

The audit's adversarial review (multi-builder, autonomous-runner, merge-reality lenses) reached a split verdict, **not** a blanket "delete prediction, detect at merge." A blanket pivot was REFUTED by two lenses: the autonomous `--parallel` runner pushes to `main` with **no human to resolve a conflict**, and `git` is blind to *semantic* clobbers between two edits that don't textually overlap. So the honest contract is conditional on **who** is building.

## Decision

Parallel-safety is a **split contract**, keyed on the build path:

### (a) Interactive, single-human path — detect at merge

The ground-truth collision detector is **`git merge`** at land time (`/builder-ship`'s auto-merge and `/merge-mode`). A real overlap surfaces as a merge conflict, resolved by a human at the authoritative moment — *after* the code exists.

- **Single-task atomicity** is guaranteed by the `uniq_active_claim_per_task` partial unique index (`migrations/003_pms.sql:130-131`): two sessions cannot both hold an active claim on the same task. This is the one hard invariant that always holds.
- The **claim-time `touches[]` overlap signal is advisory** (task [#880](https://example.com/builders#/task/880)): on overlap, `claimTask` returns an `overlap_warning` and the claim **succeeds**. `touches[]` is an advisory hint at the expected blast radius — not an editing fence (the ADR 0017 lesson).
- The predictive **drift scanner + CI gate + expand-on-drift flow were deleted** (task [#879](https://example.com/builders#/task/879), ~737 LOC). The subagent grader reads the **real committed diff** (touches-independent since [#536](https://example.com/builders#/task/536)) and flags genuinely out-of-scope writes there.

### (b) Autonomous `--parallel N` path — keep a mechanical disjointness gate

The overnight runner fans concurrent, unsupervised sub-agents and direct-pushes to `main`. Here a **file-footprint disjointness precondition is retained as a HARD gate**, alongside `parallel_safe = true`:

- `claim.js --enforce-touches` (which the `overnight-builder` routine always passes) sets `enforce_touches`, so `claimTask` / `claimTasksBatch` **refuse** with `TOUCHES_CONFLICT` on prefix-aware overlap rather than merely warning.
- **`parallel_safe` and footprint-disjointness are orthogonal and both required.** `parallel_safe` covers *non-file* hazards the runner can't see in a diff — a server restart, a shared mutable DB row, a long deploy. Footprint-disjointness covers file adjacency. Neither subsumes the other; the runner needs both true.

### Shared mechanics

- One **prefix-aware matcher** (`src/bongos/path-match.touchesOverlap`) is the single definition of "adjacent" across `claimTask`, `claimTasksBatch`, and the session optimizer — so the planner, the advisory warning, and the parallel gate all agree.
- The `claimable_tasks` **view stays on the permissive Postgres `&&` (exact-element) operator** by design: making the *display* filter prefix-strict would over-serialize the visible queue given V3's coarse top-level-dir `touches[]`. The view is a soft hint; the authoritative prefix-aware check lives in code.

## Consequences

- **Interactive builders are never blocked by a prediction.** They may be warned; they decide. Wrong predictions cost nothing.
- **The autonomous runner stays safe** — it still refuses to fan two same-footprint tasks into concurrent agents.
- The asymmetry is deliberate and must be preserved: do not "simplify" the autonomous path down to advisory, and do not promote the interactive path back to a hard block.

## The future-review trigger (deferred, conditional)

The full removal of the footprint gate — replacing it with **merge-time auto-park detection** (a `confirmed→shipped` `git merge` conflict auto-parks the task with a "rebase against main" note) **plus a runner-side post-fan-out footprint diff check** — was deliberately **deferred**. Revisit it **only when 2+ distinct human builders regularly edit concurrently** (today there is one human builder running many sessions under one identity — see the `feedback_parallel_sessions_not_anomaly` memory). At that point: either stand up the merge-time-detection + runner-footprint-check pair and drop the advisory column entirely, or keep the matcher-fixed advisory. Until then, the advisory signal + `parallel_safe` + the `uniq_active_claim_per_task` index are sufficient. Zero occurrences of the protected concurrent-human-edit scenario are documented at current scale.
