-- 021_v3_renumber_and_deps.sql
-- GDS-V3 / task 309 / V3.R01b — Renumber the V3.R## prefix on every non-shipped
-- task to match topological dependency order, and write the dependency edges
-- into task_dependencies.
--
-- Idempotent: title rename is guarded by checking against the new prefix;
-- dep inserts use ON CONFLICT DO NOTHING.
--
-- After this migration applies, the auto-promotion trigger created in 020
-- is fully wired — when a task ships, its non-spike dependents auto-promote.
BEGIN;

-- ============================================================================
-- 1. Renumber V3.R## title prefix (topologically sorted)
--    Pattern: 'V3.R<old> — <rest>' becomes 'V3.R<new> — <rest>'
--    Idempotent: only updates if the prefix doesn't already match the new value.
-- ============================================================================
UPDATE tasks SET title = regexp_replace(title, '^V3\.R01b ', 'V3.R02 ') WHERE id = 309 AND title LIKE 'V3.R01b %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R02 ', 'V3.R03 ') WHERE id = 229 AND title LIKE 'V3.R02 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R03 ', 'V3.R04 ') WHERE id = 230 AND title LIKE 'V3.R03 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R04 ', 'V3.R05 ') WHERE id = 106 AND title LIKE 'V3.R04 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R05 ', 'V3.R06 ') WHERE id = 231 AND title LIKE 'V3.R05 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R06 ', 'V3.R07 ') WHERE id = 232 AND title LIKE 'V3.R06 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R07 ', 'V3.R08 ') WHERE id = 233 AND title LIKE 'V3.R07 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R08 ', 'V3.R09 ') WHERE id = 234 AND title LIKE 'V3.R08 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R09 ', 'V3.R10 ') WHERE id = 235 AND title LIKE 'V3.R09 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R10 ', 'V3.R11 ') WHERE id = 91 AND title LIKE 'V3.R10 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R11 ', 'V3.R12 ') WHERE id = 236 AND title LIKE 'V3.R11 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R12 ', 'V3.R13 ') WHERE id = 237 AND title LIKE 'V3.R12 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R13 ', 'V3.R14 ') WHERE id = 238 AND title LIKE 'V3.R13 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R14 ', 'V3.R15 ') WHERE id = 239 AND title LIKE 'V3.R14 %';
-- R16 → R16: no change (task id=240)
-- R17 → R17: no change (task id=241)
UPDATE tasks SET title = regexp_replace(title, '^V3\.R15 ', 'V3.R18 ') WHERE id = 222 AND title LIKE 'V3.R15 %';
-- R19 → R19: no change (task id=201)
-- R20 → R20: no change (task id=202)
-- R21 → R21: no change (task id=98)
-- R22 → R22: no change (task id=242)
-- R23 → R23: no change (task id=243)
-- R24 → R24: no change (task id=244)
-- R25 → R25: no change (task id=245)
-- R26 → R26: no change (task id=246)
-- R27 → R27: no change (task id=247)
UPDATE tasks SET title = regexp_replace(title, '^V3\.R29 ', 'V3.R28 ') WHERE id = 249 AND title LIKE 'V3.R29 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R30 ', 'V3.R29 ') WHERE id = 250 AND title LIKE 'V3.R30 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R31 ', 'V3.R30 ') WHERE id = 251 AND title LIKE 'V3.R31 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R32 ', 'V3.R31 ') WHERE id = 252 AND title LIKE 'V3.R32 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R28 ', 'V3.R32 ') WHERE id = 248 AND title LIKE 'V3.R28 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R34 ', 'V3.R33 ') WHERE id = 254 AND title LIKE 'V3.R34 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R35 ', 'V3.R34 ') WHERE id = 255 AND title LIKE 'V3.R35 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R36 ', 'V3.R35 ') WHERE id = 256 AND title LIKE 'V3.R36 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R37 ', 'V3.R36 ') WHERE id = 257 AND title LIKE 'V3.R37 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R38 ', 'V3.R37 ') WHERE id = 258 AND title LIKE 'V3.R38 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R39 ', 'V3.R38 ') WHERE id = 259 AND title LIKE 'V3.R39 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R40 ', 'V3.R39 ') WHERE id = 260 AND title LIKE 'V3.R40 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R41 ', 'V3.R40 ') WHERE id = 261 AND title LIKE 'V3.R41 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R42 ', 'V3.R41 ') WHERE id = 262 AND title LIKE 'V3.R42 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R43 ', 'V3.R42 ') WHERE id = 263 AND title LIKE 'V3.R43 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R44 ', 'V3.R43 ') WHERE id = 264 AND title LIKE 'V3.R44 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R33 ', 'V3.R44 ') WHERE id = 253 AND title LIKE 'V3.R33 %';
-- R45 → R45: no change (task id=265)
-- R46 → R46: no change (task id=224)
UPDATE tasks SET title = regexp_replace(title, '^V3\.R48 ', 'V3.R47 ') WHERE id = 266 AND title LIKE 'V3.R48 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R49 ', 'V3.R48 ') WHERE id = 267 AND title LIKE 'V3.R49 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R50 ', 'V3.R49 ') WHERE id = 268 AND title LIKE 'V3.R50 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R51 ', 'V3.R50 ') WHERE id = 269 AND title LIKE 'V3.R51 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R52 ', 'V3.R51 ') WHERE id = 270 AND title LIKE 'V3.R52 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R53 ', 'V3.R52 ') WHERE id = 271 AND title LIKE 'V3.R53 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R54 ', 'V3.R53 ') WHERE id = 272 AND title LIKE 'V3.R54 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R55 ', 'V3.R54 ') WHERE id = 273 AND title LIKE 'V3.R55 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R56 ', 'V3.R55 ') WHERE id = 274 AND title LIKE 'V3.R56 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R57 ', 'V3.R56 ') WHERE id = 275 AND title LIKE 'V3.R57 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R58 ', 'V3.R57 ') WHERE id = 276 AND title LIKE 'V3.R58 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R59 ', 'V3.R58 ') WHERE id = 277 AND title LIKE 'V3.R59 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R60 ', 'V3.R59 ') WHERE id = 278 AND title LIKE 'V3.R60 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R61 ', 'V3.R60 ') WHERE id = 279 AND title LIKE 'V3.R61 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R62 ', 'V3.R61 ') WHERE id = 280 AND title LIKE 'V3.R62 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R63 ', 'V3.R62 ') WHERE id = 281 AND title LIKE 'V3.R63 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R64 ', 'V3.R63 ') WHERE id = 282 AND title LIKE 'V3.R64 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R65 ', 'V3.R64 ') WHERE id = 283 AND title LIKE 'V3.R65 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R66 ', 'V3.R65 ') WHERE id = 284 AND title LIKE 'V3.R66 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R67 ', 'V3.R66 ') WHERE id = 285 AND title LIKE 'V3.R67 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R68 ', 'V3.R67 ') WHERE id = 286 AND title LIKE 'V3.R68 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R69 ', 'V3.R68 ') WHERE id = 287 AND title LIKE 'V3.R69 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R70 ', 'V3.R69 ') WHERE id = 288 AND title LIKE 'V3.R70 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R71 ', 'V3.R70 ') WHERE id = 289 AND title LIKE 'V3.R71 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R72 ', 'V3.R71 ') WHERE id = 290 AND title LIKE 'V3.R72 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R73 ', 'V3.R72 ') WHERE id = 291 AND title LIKE 'V3.R73 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R74 ', 'V3.R73 ') WHERE id = 292 AND title LIKE 'V3.R74 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R75 ', 'V3.R74 ') WHERE id = 293 AND title LIKE 'V3.R75 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R76 ', 'V3.R75 ') WHERE id = 294 AND title LIKE 'V3.R76 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R77 ', 'V3.R76 ') WHERE id = 295 AND title LIKE 'V3.R77 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R78 ', 'V3.R77 ') WHERE id = 296 AND title LIKE 'V3.R78 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R79 ', 'V3.R78 ') WHERE id = 297 AND title LIKE 'V3.R79 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R80 ', 'V3.R79 ') WHERE id = 298 AND title LIKE 'V3.R80 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R82 ', 'V3.R80 ') WHERE id = 300 AND title LIKE 'V3.R82 %';
-- R81 → R81: no change (task id=299)
UPDATE tasks SET title = regexp_replace(title, '^V3\.R83 ', 'V3.R82 ') WHERE id = 301 AND title LIKE 'V3.R83 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R85 ', 'V3.R83 ') WHERE id = 303 AND title LIKE 'V3.R85 %';
-- R84 → R84: no change (task id=302)
UPDATE tasks SET title = regexp_replace(title, '^V3\.R86 ', 'V3.R85 ') WHERE id = 304 AND title LIKE 'V3.R86 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R87 ', 'V3.R86 ') WHERE id = 305 AND title LIKE 'V3.R87 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R88 ', 'V3.R87 ') WHERE id = 306 AND title LIKE 'V3.R88 %';
UPDATE tasks SET title = regexp_replace(title, '^V3\.R89 ', 'V3.R88 ') WHERE id = 307 AND title LIKE 'V3.R89 %';

-- ============================================================================
-- 2. Insert task_dependencies rows
--    Each task gets one INSERT per dep edge. ON CONFLICT DO NOTHING makes the
--    migration safe to re-run.
--
--    FRESH-DB GUARD (task 1238 / ADR 0062 §5 + §8): the 86 edges below reference
--    THIS instance's V3 task rows, which are seeded by scripts/pms/seed-v3-tasks.js
--    (a JS seed run on prod AFTER migration 018) — NOT by any SQL migration. On a
--    fresh / empty instance DB those task rows don't exist, so the INSERTs would
--    violate task_dependencies' FK to tasks(id) — and ON CONFLICT does NOT suppress
--    an FK violation. This block is OTB-instance prod data, so skip it wholesale when
--    `tasks` is empty; the core migration history then replays cleanly on an empty DB
--    (the C8 customer-0 bringup). On prod the rows exist AND this migration is already
--    recorded in schema_migrations, so it never re-runs there regardless.
-- ============================================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM tasks) THEN
    RAISE NOTICE 'task 1238: tasks table empty — skipping the V3 dependency seed (fresh-DB replay)';
    RETURN;
  END IF;
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (106, 229) ON CONFLICT DO NOTHING; -- R04->R02
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (231, 229) ON CONFLICT DO NOTHING; -- R05->R02
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (231, 106) ON CONFLICT DO NOTHING; -- R05->R04
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (232, 106) ON CONFLICT DO NOTHING; -- R06->R04
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (232, 231) ON CONFLICT DO NOTHING; -- R06->R05
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (234, 233) ON CONFLICT DO NOTHING; -- R08->R07
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (235, 234) ON CONFLICT DO NOTHING; -- R09->R08
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (91, 234) ON CONFLICT DO NOTHING; -- R10->R08
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (238, 231) ON CONFLICT DO NOTHING; -- R13->R05
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (238, 232) ON CONFLICT DO NOTHING; -- R13->R06
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (239, 106) ON CONFLICT DO NOTHING; -- R14->R04
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (240, 106) ON CONFLICT DO NOTHING; -- R16->R04
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (241, 233) ON CONFLICT DO NOTHING; -- R17->R07
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (241, 234) ON CONFLICT DO NOTHING; -- R17->R08
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (241, 237) ON CONFLICT DO NOTHING; -- R17->R12
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (241, 238) ON CONFLICT DO NOTHING; -- R17->R13
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (241, 239) ON CONFLICT DO NOTHING; -- R17->R14
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (241, 240) ON CONFLICT DO NOTHING; -- R17->R16
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (222, 241) ON CONFLICT DO NOTHING; -- R15->R17
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (202, 201) ON CONFLICT DO NOTHING; -- R20->R19
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (98, 201) ON CONFLICT DO NOTHING; -- R21->R19
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (98, 202) ON CONFLICT DO NOTHING; -- R21->R20
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (242, 201) ON CONFLICT DO NOTHING; -- R22->R19
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (242, 202) ON CONFLICT DO NOTHING; -- R22->R20
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (245, 244) ON CONFLICT DO NOTHING; -- R25->R24
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (246, 244) ON CONFLICT DO NOTHING; -- R26->R24
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (249, 232) ON CONFLICT DO NOTHING; -- R29->R06
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (250, 231) ON CONFLICT DO NOTHING; -- R30->R05
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (251, 231) ON CONFLICT DO NOTHING; -- R31->R05
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (252, 229) ON CONFLICT DO NOTHING; -- R32->R02
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (248, 244) ON CONFLICT DO NOTHING; -- R28->R24
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (248, 252) ON CONFLICT DO NOTHING; -- R28->R32
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (255, 254) ON CONFLICT DO NOTHING; -- R35->R34
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (261, 260) ON CONFLICT DO NOTHING; -- R41->R40
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (262, 260) ON CONFLICT DO NOTHING; -- R42->R40
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (262, 261) ON CONFLICT DO NOTHING; -- R42->R41
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (263, 256) ON CONFLICT DO NOTHING; -- R43->R36
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (264, 229) ON CONFLICT DO NOTHING; -- R44->R02
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (264, 231) ON CONFLICT DO NOTHING; -- R44->R05
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (253, 254) ON CONFLICT DO NOTHING; -- R33->R34
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (253, 264) ON CONFLICT DO NOTHING; -- R33->R44
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (265, 264) ON CONFLICT DO NOTHING; -- R45->R44
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (271, 256) ON CONFLICT DO NOTHING; -- R53->R36
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (272, 260) ON CONFLICT DO NOTHING; -- R54->R40
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (272, 262) ON CONFLICT DO NOTHING; -- R54->R42
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (273, 230) ON CONFLICT DO NOTHING; -- R55->R03
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (274, 273) ON CONFLICT DO NOTHING; -- R56->R55
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (275, 273) ON CONFLICT DO NOTHING; -- R57->R55
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (275, 274) ON CONFLICT DO NOTHING; -- R57->R56
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (276, 273) ON CONFLICT DO NOTHING; -- R58->R55
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (277, 230) ON CONFLICT DO NOTHING; -- R59->R03
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (279, 257) ON CONFLICT DO NOTHING; -- R61->R37
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (280, 273) ON CONFLICT DO NOTHING; -- R62->R55
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (280, 275) ON CONFLICT DO NOTHING; -- R62->R57
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (281, 273) ON CONFLICT DO NOTHING; -- R63->R55
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (283, 254) ON CONFLICT DO NOTHING; -- R65->R34
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (283, 282) ON CONFLICT DO NOTHING; -- R65->R64
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (285, 256) ON CONFLICT DO NOTHING; -- R67->R36
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (285, 258) ON CONFLICT DO NOTHING; -- R67->R38
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (285, 282) ON CONFLICT DO NOTHING; -- R67->R64
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (286, 260) ON CONFLICT DO NOTHING; -- R68->R40
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (286, 262) ON CONFLICT DO NOTHING; -- R68->R42
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (286, 282) ON CONFLICT DO NOTHING; -- R68->R64
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (286, 284) ON CONFLICT DO NOTHING; -- R68->R66
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (286, 285) ON CONFLICT DO NOTHING; -- R68->R67
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (288, 282) ON CONFLICT DO NOTHING; -- R70->R64
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (288, 285) ON CONFLICT DO NOTHING; -- R70->R67
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (291, 202) ON CONFLICT DO NOTHING; -- R73->R20
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (292, 202) ON CONFLICT DO NOTHING; -- R74->R20
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (292, 242) ON CONFLICT DO NOTHING; -- R74->R22
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (292, 263) ON CONFLICT DO NOTHING; -- R74->R43
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (293, 285) ON CONFLICT DO NOTHING; -- R75->R67
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (294, 106) ON CONFLICT DO NOTHING; -- R76->R04
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (294, 238) ON CONFLICT DO NOTHING; -- R76->R13
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (296, 238) ON CONFLICT DO NOTHING; -- R78->R13
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (296, 294) ON CONFLICT DO NOTHING; -- R78->R76
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (297, 239) ON CONFLICT DO NOTHING; -- R79->R14
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (299, 300) ON CONFLICT DO NOTHING; -- R81->R82
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (301, 106) ON CONFLICT DO NOTHING; -- R83->R04
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (301, 239) ON CONFLICT DO NOTHING; -- R83->R14
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (303, 236) ON CONFLICT DO NOTHING; -- R85->R11
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (302, 303) ON CONFLICT DO NOTHING; -- R84->R85
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (305, 229) ON CONFLICT DO NOTHING; -- R87->R02
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (306, 231) ON CONFLICT DO NOTHING; -- R88->R05
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (306, 250) ON CONFLICT DO NOTHING; -- R88->R30
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (306, 251) ON CONFLICT DO NOTHING; -- R88->R31
END $$;

-- Total dependency edges inserted: 86

-- ============================================================================
-- 3. Bump migration counter + register migration
-- ============================================================================
UPDATE migration_counter SET next_number = GREATEST(next_number, 22) WHERE id = 1;
INSERT INTO schema_migrations (version) VALUES ('021_v3_renumber_and_deps')
  ON CONFLICT (version) DO NOTHING;

COMMIT;