-- PMS-V2 task 197: quality grader for task output.
--
-- One row per task. Inserted when a task transitions completed → confirmed
-- (or when verification passes and the grade fails — see grader.js).
-- The grade gates the lifecycle transition: passed=true → confirmed +
-- credits, passed=false → task stays at completed, no credits.
--
-- The threshold + grader_version are captured PER ROW so historical grades
-- stay interpretable when either moves. V2 ships with threshold=5.0 and
-- grader_version='v1'; rubric weights live in src/pms/grader-rubric.json.

CREATE TABLE IF NOT EXISTS task_grades (
  id              BIGSERIAL PRIMARY KEY,
  task_id         BIGINT NOT NULL UNIQUE REFERENCES tasks(id) ON DELETE CASCADE,
  score           NUMERIC(3,1) NOT NULL CHECK (score >= 0 AND score <= 10),
  passed          BOOLEAN NOT NULL,
  threshold       NUMERIC(3,1) NOT NULL,
  grader_kind     TEXT NOT NULL CHECK (grader_kind IN ('auto', 'subagent', 'lars')),
  grader_version  TEXT NOT NULL,
  rubric_scores   JSONB NOT NULL DEFAULT '{}'::jsonb,
  signals         JSONB NOT NULL DEFAULT '{}'::jsonb,
  notes_md        TEXT,
  graded_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_task_grades_graded_at ON task_grades(graded_at DESC);
CREATE INDEX IF NOT EXISTS idx_task_grades_passed_grade ON task_grades(passed, graded_at DESC);

-- View: grades joined with task + claim + cost. Powers the V4 optimizer
-- (quality-per-dollar) and the public dashboard tile.
CREATE OR REPLACE VIEW task_grades_with_context AS
SELECT
  g.id              AS grade_id,
  g.task_id,
  g.score,
  g.passed,
  g.threshold,
  g.grader_kind,
  g.grader_version,
  g.rubric_scores,
  g.signals,
  g.graded_at,
  t.title           AS task_title,
  t.kind            AS task_kind,
  t.discipline      AS task_discipline,
  t.version_id,
  t.est_minutes,
  t.actual_minutes,
  t.shipped_by      AS builder_id,
  b.github_login,
  b.display_name,
  (SELECT COALESCE(SUM(amount_usd), 0)
     FROM cost_log cl WHERE cl.task_id = g.task_id)  AS total_cost_usd
FROM task_grades g
JOIN tasks t      ON t.id = g.task_id
LEFT JOIN builders b ON b.id = t.shipped_by;

-- Bump the migration counter past 016 so the next claim that includes
-- 'migrations/' allocates 017.
UPDATE migration_counter SET next_number = GREATEST(next_number, 17) WHERE id = 1;
