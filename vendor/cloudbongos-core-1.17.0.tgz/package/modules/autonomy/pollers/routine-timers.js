'use strict';

// modules/autonomy/pollers/routine-timers.js — server-internal routine timers
// (System 4 / ADR 0078 amendment, task 1382; carved into modules/autonomy/ at
// BV1.R83 / ADR 0093 §1).
//
// THE POLLER SEAM. The autonomy module manifest declares
// contributes.pollers:["routine-timers"]; the loader (src/module-loader/loader.js
// startModulePollers) requires THIS file and calls start(deps) at boot, stop() at
// shutdown — the module-agnostic successor to the hardcoded `routineTimers.start()`
// block server.js used to carry. server.js (the game/droplet entrypoint) is the
// ONLY caller of startModulePollers, never src/platform-server.js, so a future
// second always-on instance on the same DB can't double-run (and the FOR UPDATE
// row lock in tallyPeerVotes is the hard guard if one ever does).
//
// WHY THIS EXISTS
// ADR 0078 demoted peer-vote-tally to `mode: deterministic` and built an EXTERNAL
// dispatcher (scripts/gds/run-routine.js) the operator was meant to wire into
// cron. But nothing was ever durably scheduled — every scheduler layer (the
// local app tasks, the session cron, the claude.ai cloud routines) was empty, so
// the realized run count was ZERO. A deterministic routine that never fires saves
// nothing. The routine's real work is server-side and needs no model, so the
// durable realization is an in-process timer inside the always-on Node process —
// the SAME pattern as the publish-reconciler / uptime-poller. No external cron, no
// `claude -p`, no token spend.
//
//   - peer-vote-tally (weekly): folds matured peer votes into karma. The work is
//     the `tallyPeerVotes` doorway capability — the exact transaction
//     POST /tasks/peer-votes/tally runs, so route + timer share one path. It
//     writes karma_log/peer_votes/tasks (all lifecycle/core-owned), so it can't be
//     autonomy-owned; the module reaches it through the published doorway
//     (src/module-api.js), never a core require (BV1.R83 / ADR 0093 §1). The
//     route's Archon gate is an HTTP-auth concern; an in-process call has no
//     requester and the SQL writes karma_log with granted_by = NULL. No identity
//     needed. Idempotent (only matured, untallied votes) + a FOR UPDATE row lock,
//     so over-/under-firing is harmless and a second instance can't double-fold.
//
// (diagram-drift was intentionally NOT made a timer: all five onboarding diagrams
// already auto-regenerate from live facts on every deploy, so a daily drift check
// is near-redundant; the manual `node scripts/gds/run-routine.js diagram-drift`
// remains for on-demand use. See the ADR 0078 amendment.)
//
// Mirrors the publish-reconciler contract: env-overridable interval, an UNREF'd
// timer (never holds the process open across a systemd restart), best-effort (a
// throw logs `[routine-timers]` + waits for the next tick — NEVER crashes the
// server), and a run function pure w.r.t. injected deps so it unit-tests with no
// DB. A no-op anywhere the pool is unreachable (builder laptops/boxes): the run
// catches the connection error and returns a skip summary, so it is safe to
// start unconditionally on the game boot.

// The published doorway — the autonomy module reaches the `tallyPeerVotes`
// lifecycle capability through the `lifecycle` kernel PORT here (the doorway leak
// retired at BV1.R86), never a core require (the one-way boundary, ADR 0083).
// Resolved lazily inside runPeerVoteTally so requiring this poller never forces a
// core load at module-discovery time, and so tests that pass deps.db bypass it.
const api = require('../../../src/module-api');

const WEEK_MS = 7 * 24 * 60 * 60_000;

const PEER_VOTE_INTERVAL_MS = Number(process.env.ROUTINE_PEER_VOTE_MS) || WEEK_MS;
// First-fire delay: let the server finish binding + the other in-process pollers
// settle before the first tally. Jitter spreads first-fire across a minute so a
// crash-loop / deploy storm doesn't synchronize every restart's first run.
const PEER_VOTE_FIRST_MS = Number(process.env.ROUTINE_PEER_VOTE_FIRST_MS) || 90_000;
const JITTER_MS = 60_000;

let peerVoteFirst = null;
let peerVoteInterval = null;

// One peer-vote tally run. Pure w.r.t. injected deps. Returns the same shape the
// HTTP route returns (votes_tallied / builders_credited / karma / lag_days) for
// tests + observability. Idempotent: db.tallyPeerVotes only folds matured,
// untallied votes and then stamps them, so a re-run within the week finds nothing.
// NEVER throws: a DB-unreachable error (e.g. on a builder machine) degrades to a
// logged skip — the timer must never take the server down.
async function runPeerVoteTally(deps = {}) {
  // Default to the `lifecycle` port (the peer-vote→karma fold-in lives there now);
  // tests inject deps.db to drive the run with no DB. resolveOptional → null when
  // lifecycle is somehow off → the typeof guard below returns a clean skip.
  const db = deps.db || api.resolveOptional('lifecycle') || {};
  const logFn = deps.log || console.log;
  const errFn = deps.error || console.error;
  if (typeof db.tallyPeerVotes !== 'function') {
    return { skipped: 'unsupported' };
  }
  try {
    const r = await db.tallyPeerVotes();
    if (r && r.votes_tallied > 0) {
      logFn(
        `[routine-timers] peer-vote-tally: ${r.votes_tallied} vote(s) folded into karma across ` +
        `${r.builders_credited} builder(s) (lag ${r.lag_days}d).`
      );
    }
    return r;
  } catch (e) {
    errFn(`[routine-timers] peer-vote-tally (non-blocking): ${e && e.message}`);
    return { skipped: 'error', error: e && e.message };
  }
}

// Start the timer(s). Idempotent. Kill-switched by ROUTINE_TIMERS_DISABLED=1.
// Unref'd so it never holds the process open on a systemd restart. Started by the
// loader's startModulePollers ONLY on the game/droplet entrypoint (server.js),
// never in src/platform-server.js, so a future second always-on instance on the
// same DB can't double-run (and the FOR UPDATE row lock in tallyPeerVotes is the
// hard guard if one ever does).
function start(deps = {}) {
  if (process.env.ROUTINE_TIMERS_DISABLED === '1') {
    console.log('[routine-timers] disabled (ROUTINE_TIMERS_DISABLED=1)');
    return;
  }
  // Idempotent: guard on the FIRST-fire timer too, not just the interval — the
  // interval is only set once the first-fire setTimeout fires (~90s later), so a
  // second start() before then would otherwise schedule a duplicate first run.
  if (peerVoteFirst || peerVoteInterval) return; // already started
  const jitter = () => Math.floor(Math.random() * JITTER_MS);

  const peerTick = () =>
    runPeerVoteTally(deps).catch((e) =>
      console.error(`[routine-timers] peer-vote tick crashed: ${e && e.message}`));

  peerVoteFirst = setTimeout(() => {
    peerTick();
    peerVoteInterval = setInterval(peerTick, PEER_VOTE_INTERVAL_MS);
    if (peerVoteInterval.unref) peerVoteInterval.unref();
  }, PEER_VOTE_FIRST_MS + jitter());
  if (peerVoteFirst.unref) peerVoteFirst.unref();

  console.log(
    `[routine-timers] started — peer-vote-tally every ${Math.round(PEER_VOTE_INTERVAL_MS / 3600_000)}h ` +
    `(first run ~${Math.round(PEER_VOTE_FIRST_MS / 1000)}s after boot, then boot-anchored weekly)`
  );
}

function stop() {
  if (peerVoteFirst) clearTimeout(peerVoteFirst);
  if (peerVoteInterval) clearInterval(peerVoteInterval);
  peerVoteFirst = peerVoteInterval = null;
}

module.exports = {
  start,
  stop,
  runPeerVoteTally,
  PEER_VOTE_INTERVAL_MS,
};
