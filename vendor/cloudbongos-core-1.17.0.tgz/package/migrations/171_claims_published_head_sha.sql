-- Task 1547 — record the tip sha the SERVER actually pushed for a claim's
-- server-mediated publish (ADR 0055), so the confirmed->shipped reconcile can
-- prove the land from THIS task's own commit instead of from a branch-name match.
--
-- WHY. claims.head_sha is the claim-TIME base (the worktree HEAD when the task was
-- claimed), NOT the graded/published tip. ship.js sends the real tip to
-- POST /tasks/:id/publish-branch, but it was discarded after the push. The
-- reconcile-on-read (routes/tasks.js) and the publish-reconciler therefore had no
-- reliable per-task commit to verify against, so a reused worktree branch could
-- match an OLDER task's already-merged PR and false-flip confirmed->shipped (the
-- BV1.R04/R05 strand: branch claude/jovial-rosalind-84d6c3 had earlier been
-- PR #386 / task 1297). This column holds the pushed tip; the reconcile gates on
-- isAncestorOfDefaultBranch(published_head_sha) before shipping. Additive + nullable
-- so legacy rows (no recorded publish) are simply un-provable via the tip path and
-- fall back to the PR-references-this-task check.

BEGIN;

ALTER TABLE claims ADD COLUMN IF NOT EXISTS published_head_sha TEXT;

COMMENT ON COLUMN claims.published_head_sha IS
  'Tip sha the server pushed for this claim via POST /tasks/:id/publish-branch (ADR 0055). NULL until a server-mediated publish succeeds. The confirmed->shipped reconcile proves a per-task land from this commit (task 1547).';

COMMIT;
