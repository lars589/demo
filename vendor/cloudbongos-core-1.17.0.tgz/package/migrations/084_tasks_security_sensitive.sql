-- migration 084: tasks.security_sensitive — explicit Archon-only-broadcast flag
--
-- task 990 (owner requirement): "Security updates should only be posted to
-- Archons and live in a separate Discord ship-feed channel." When a task with
-- this flag set ships, ship.js routes its broadcast ONLY to the Archon-only
-- #security-ship-feed channel — never the public #ship-news or the builder
-- #ship-feed.
--
-- This is an EXPLICIT flag, NOT a heuristic. A title/description classifier here
-- would be the wrong tool: a single misfire (a security fix mis-classified as
-- routine) leaks the existence — and often the shape — of an unpatched exploit
-- to a public channel before the fix is even live. The cost of a false negative
-- is a disclosed vulnerability, so the flag is set deliberately by the director
-- on the specific tasks that warrant it, never inferred.
--
-- No backfill: the director sets security_sensitive on specific tasks
-- separately. Every task defaults to false (the safe-loud public broadcast).

ALTER TABLE tasks
  ADD COLUMN IF NOT EXISTS security_sensitive boolean NOT NULL DEFAULT false;

-- Counter hygiene: keep the migration-number allocator above this file so the
-- next reservation can't collide with 084.
UPDATE migration_counter SET next_number = GREATEST(next_number, 85) WHERE id = 1;
