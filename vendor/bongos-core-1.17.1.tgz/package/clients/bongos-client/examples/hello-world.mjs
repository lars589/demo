// clients/bongos-client/examples/hello-world.mjs
//
// The external-consumer PROOF (BONGOS-V1 goal 36, R10 / task 1997): a runnable
// "hello world" that an outside program (a self-hoster's script, a CI job, a
// teammate's laptop) can copy and run against a live Bongos instance using the
// PUBLISHED typed client — no vendoring, no hand-rolled fetch, no secret baked in.
//
// It makes two calls:
//   1. A PUBLIC, no-auth read (GET /public/versions) — proves connectivity + the
//      v1 surface + the R14 pagination contract (a `page` block, a capped list).
//   2. An AUTHENTICATED read (GET /me) — only when BONGOS_TOKEN is set. See how to
//      get a token in docs/api-onramp.md (Device Flow, or a portal-issued bearer).
//
// Run:
//   node clients/bongos-client/examples/hello-world.mjs
//   BONGOS_TOKEN=<your-token> node clients/bongos-client/examples/hello-world.mjs
//   BONGOS_BASE_URL=https://your-instance/api/bongos/v1 node …/hello-world.mjs
//
// Zero dependencies — it imports the generated client directly. From an installed
// package the import is `@cloudbongos/client` instead of this relative path.

import { createClient, ApiError, API_VERSION } from '../index.mjs';

// baseUrl defaults to this instance's public v1 surface; override for a self-host.
const baseUrl = process.env.BONGOS_BASE_URL || 'https://amazonprimea.com/api/bongos/v1';
const token = process.env.BONGOS_TOKEN; // optional — only needed for the /me call

const api = createClient({ baseUrl, token });

async function main() {
  console.log(`→ Bongos client ${API_VERSION} against ${baseUrl}\n`);

  // 1) PUBLIC read — no token required. Pages via the R14 contract (?limit=).
  const versions = await api.public.getPublicVersions({ query: { limit: 5 } });
  const names = (versions.versions || []).map((v) => v.id || v.name).join(', ');
  console.log(`[public] GET /public/versions → ${(versions.versions || []).length} version(s): ${names}`);
  console.log(`[public] page:`, versions.page, '\n');

  // 2) AUTHENTICATED read — only if a token is provided.
  if (token) {
    const me = await api.me.getMe();
    console.log(`[auth]   GET /me → signed in as @${me.github_login} (rank: ${me.rank})`);
  } else {
    console.log('[auth]   set BONGOS_TOKEN to also make an authenticated call.');
    console.log('         Get a token: docs/api-onramp.md (§ Authenticate).');
  }
  console.log('\n✓ hello-world complete.');
}

main().catch((e) => {
  // Every non-2xx is an ApiError carrying the ADR-0116 envelope.
  if (e instanceof ApiError) {
    console.error(`\n✗ ApiError ${e.status} [${e.code}]: ${e.message}`);
    if (e.details) console.error('  details:', JSON.stringify(e.details));
    if (e.code === 'unauthenticated') {
      console.error('  → your BONGOS_TOKEN is missing/expired. See docs/api-onramp.md.');
    }
    process.exit(1);
  }
  console.error('\n✗ network/other error:', e && e.message);
  process.exit(1);
});
