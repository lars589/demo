# 0088 — Consistent-character generative animation (grade-and-audit, on the family pipeline)

- **Status:** Accepted; **amended 2026-06-30** — generation mechanism revised **again** to **Veo image-to-video → keyed transparent sprite** (the owner rejected *both* the per-frame edit-the-hero redraw *and* the 2026-06-27 rig; see the 2026-06-30 Amendment at the end). The grade-and-audit philosophy and the **sprite + manifest output contract** still stand; the *generator* is now a video model, not the family/edit/rig path. (Prior amendment 2026-06-27: edit-the-hero + reference-kit + surgical loop + rigged motion — now itself superseded as the mechanism.)
- **Date:** 2026-06-26
- **Deciders:** Lars (Archon), Claude

**Builds on:** [ADR 0008](<redacted>.md) (family-based multi-frame generation — the grader/loop we extend), [ADR 0083](<redacted>.md) (modular architecture — this ships as a module), [ADR 0062](<redacted>.md) / [ADR 0081](<redacted>.md) (neutral-contract adapter pattern — the pluggable generator backend), [ADR 0024](<redacted>.md) (grade-before-ship pattern).

**Track:** `internal` (a Cloud Bongos platform capability — the art pipeline).

---

## Context

We need **animation**: many frames of the *same* character in *different* poses, frame-to-frame consistent. Building the Bongo Buddha mascot widget ([#1523](https://example.com/builders#/task/1523)) we hit the wall that defines this ADR — **generative image models drift between independent generations.** Concretely observed this session:

- **Identity/proportion drift** between frames.
- **Anatomy failures** — a frame with *four hands* when asked to raise both arms.
- **Spurious auras/rings** the model adds despite "no glow," which the matte keeps.
- **Size + framing variance** — the same pose drawn at different scales / zoom.
- **Sparse motion** — a still-image model packs "12 frames" into one sheet as ~6 distinct poses then near-duplicates; it does not understand motion.

External practice confirms the cause: plain reference-prompting (what closed Gemini offers) **biases attention but does not lock identity, so it drifts after a few shots**. The gold standard for a recurring character is a trained **LoRA** (85–95% feature retention), but that requires GPU training and an **open** model — not closed Gemini. Automated consistency is a measurable thing (subject embedding similarity, vision-judge, geometric checks).

Two empirical wins this session shaped the decision: (1) a **recursive "draw the frame halfway between these two" inbetween** request *does* produce a coherent intermediate pose with Gemini; (2) **the platform already has the right machinery** — the family pipeline.

**The key finding:** the existing **family pipeline** ([ADR 0008](<redacted>.md); `art/pipeline/family_*.py` + `art/template/families.json`) is already a consistent-character, multi-frame **grade-and-audit loop**. `family_orchestrator.run_family()` generates N frames of one individual in a single sheet, slices them, runs **cross-frame deterministic coherence** (`family_checks.run_all` — silhouette area/height variance = "same size", palette/luminance coherence = "same look"), then a **Gemini family review** that already scores a **`character_identity`** criterion ("do ALL frames depict the SAME individual?"), and **loops with `t5_anchor_refine`** which re-feeds the strongest prior cell as a locked anchor. Walk cycles (`player_walk`, 6 frames) and a peck cycle (`chickens`) already ship through it. It is tuned for **32×32 pixel-art tiles** (palette-snap, fixed size) — not our full-res painterly mascot — but the *architecture, loop, cost-ledger, regression-guard, and Gemini-review flow* are exactly what we need.

The owner's directive (2026-06-26): **don't reinvent the loop — use existing infrastructure and flows; keep the per-frame grader criteria proposed below.** And build it **correctly, as a reusable Cloud Bongos module**, since consistent generative animation is a general platform capability, not a one-off.

---

## Decision

**Produce frame-consistent character animation with a `generate → grade → audit → regenerate` loop, implemented by *extending the existing family pipeline* (not building a new grader or loop), with a *pluggable* generator backend. Ship it as a Cloud Bongos module. Use Gemini now; the durable asset is the grader/audit, which is backend-agnostic.**

### 1. Approach: Gemini + grade-and-audit, pluggable backend (option A)

Closed Gemini caps raw consistency at "reference-conditioning" (it drifts). We compensate with the **grader/audit loop**: every candidate frame is scored against the character's model sheet, and failures are regenerated with the failure fed back as a fix-hint, escalating only when stuck. The **generator backend is an adapter** (the [ADR 0062](<redacted>.md)/[0081](<redacted>.md) neutral-contract pattern): Gemini today; a future **LoRA-on-open-model** ("level 2") or an **image-to-video** model can slot in *without touching the grader*. LoRA is explicitly **deferred**, not chosen — it needs training infra and an open model; we adopt it only if the Gemini pass-rate proves too low.

### 2. Reuse the family pipeline as the grader + loop

The grade-and-audit loop **is** `family_orchestrator.run_family()`. We reuse, verbatim where possible: the attempt loop, `t5_anchor_refine` (lock-the-character-and-re-pose), `family_checks.run_all` (deterministic gate before spending a Gemini call), `family_review.review_family` (the vision grader, including `character_identity`), `cost_ledger` gating, and `regression_detector` (don't overwrite a better existing frame). Animation frames are **family members**.

### 3. A painterly `character_anim` family kind

Add a new family `kind` (and `slice_strategy`) for **full-res painterly characters**, configured in `families.json` like any other family. It **drops the pixel-art-specific deterministic checks** (palette-snap to `palette.json`, 32×32 size, anti-grid) which do not apply to painterly art, and **keeps** the size-coherence check (`silhouette_area`/`silhouette_height` variance). Identity, for now, leans on the existing **`character_identity` vision criterion** + perceptual-hash/anchor similarity (`regression_detector` pHash/dHash) + palette/luminance coherence — **no new heavy ML dependency** (the pipeline deliberately avoids even `imagehash`). A learned **embedding** identity scorer (DINOv2/CLIP) is captured as an optional future enhancement, not core.

### 4. Close the genuine gaps: pose-match + transition coherence

The existing family checks enforce **sameness** (low variance across the set) and are **order-agnostic** — they would pass a *shuffled* animation. Animation needs the opposite-but-complementary checks:

- **`pose_match`** (vision criterion) — does each frame match its *intended* pose? (controlled difference)
- **transition coherence** (deterministic, order-aware) — is frame *N+1* a plausible small step from frame *N*? (neighbor-delta within a band → catches both jumps *and* dead/duplicate frames)

These are the only genuinely new grader criteria; everything else is reuse.

### 5. A recursive inbetween layer (for smoothness)

A single sheet reliably yields only ~4–6 *distinct* keyframes. Animation wants ~12–24 drawings (anime/ATLA convention: "on twos" ≈ 12/sec, "on ones" ≈ 24/sec). So: the family pipeline produces the consistent **keyframes**; a new **inbetween step** generates the frames between them by feeding two adjacent (approved) frames and asking Gemini for the midpoint, **recursively halving** to any target count. Each generated inbetween is graded by the same per-frame criteria; failures regenerate. (If/when a video/interpolation backend is plugged in per §1, it replaces this step behind the same contract.)

### 6. Painterly cutout + registration post-process

A non-pixel-art post-process: background removal (`rembg`) + warm-fringe despill + magenta/halo cleanup + **registration** (scale to a locked body size, align the seat/anchor) so frames composite over the separately-rendered glow/cloud and never change size. This is distinct from the tile `post_process.process` (which palette-snaps + downscales) and was prototyped this session.

### 7. Package as a Cloud Bongos module

Per [ADR 0083](<redacted>.md) + [`docs/modules-contract.md`](../modules-contract.md). **Contract — input:** a character *model sheet* (canonical reference image(s) + identity prose + style + size/anchor spec + per-criterion tolerances) + an *action spec* (key poses + frame budget + fps). **Output:** a graded, consistent, registered frame set + a manifest (frame order, fps, anchors). The rubric/tolerances and the generator backend are **config-driven** so any instance can animate its own characters.

### 8. The grader criteria (owner-approved)

Per frame, scored within the reused grader machinery (reusing the existing `pass / retry / escalate_tier` + `fix_hint` verdict shape):

| Criterion | Mechanism | Status |
|---|---|---|
| Same character | `character_identity` (vision) + pHash/dHash + palette/luminance coherence | **reuse** |
| Correct anatomy (exactly 2 hands, no malformations) | vision judge | new criterion (reuse machinery) |
| Right size + framing | `silhouette_area`/`silhouette_height` variance + registration | **reuse** |
| Clean (no aura/ring/bg-bleed) | alpha/halo analysis + vision | new deterministic + vision |
| Matches intended pose | vision judge (`pose_match`) | **new** |
| No flicker / smooth transition | order-aware neighbor-delta | **new** |

---

## Consequences

- **Minimal net-new code.** The loop, cost-ledger, anchor-refine, regression-guard, and the `character_identity` grader already exist. Net-new ≈ a painterly family kind, two criteria (`pose_match` + transition), the inbetween layer, and the painterly post-process.
- **Cheap.** Gemini image gen ≈ $0.04/frame; a full action ≈ <$1 even with retries.
- **Pluggable + reusable.** The grader is the durable asset; backends swap behind a contract; any Cloud Bongos instance can animate its characters.
- **Accepted limitation.** Gemini drift means some frames take multiple attempts (cost/time); the audit loop is what makes that acceptable. If the pass-rate is too low, escalate to the deferred LoRA "level 2."
- **Two deterministic-check sets** to maintain (pixel-art vs painterly) — contained behind the family `kind` dispatch.
- **No blocking.** The widget ([#1523](https://example.com/builders#/task/1523)) interactions (tickle, scruff-pickup, drop, whale-catch) ship now with the static poses; smooth animation swaps in per-action as this module delivers.

## Alternatives considered

- **Per-character LoRA on an open model (B).** Gold-standard consistency, but GPU training infra + off-Gemini. **Deferred** as "level 2" behind the pluggable backend.
- **Build a new grader + loop.** Rejected — the family pipeline already does it; reuse per the owner's directive.
- **Image-to-video / interpolation model for motion.** Orthogonal and promising; slots in later as a generator backend replacing the inbetween layer (§5) behind the same contract.
- **One dense sprite sheet for all frames.** Rejected — empirically caps at ~6 distinct frames then degenerates to near-duplicates (a still model has no motion model).

---

## Implementation — the engineering epic

Created as GDS tasks under **BONGOS-V1**, in the **"Cloud Bongos animation module" goal** (goal [#9](https://example.com/builders#/task/9), scope `art-pipeline`) — the platform-version home for this module. Task IDs: 1 = [#1548](https://example.com/builders#/task/1548) (this ADR/scope), 2 = [#1549](https://example.com/builders#/task/1549), 3 = [#1550](https://example.com/builders#/task/1550), 4 = [#1552](https://example.com/builders#/task/1552), 5 = [#1553](https://example.com/builders#/task/1553), 6 = [#1555](https://example.com/builders#/task/1555), 7 = [#1554](https://example.com/builders#/task/1554), 8 = [#1556](https://example.com/builders#/task/1556), 9 = [#1558](https://example.com/builders#/task/1558), 10 = [#1559](https://example.com/builders#/task/1559), 11 = [#1557](https://example.com/builders#/task/1557), 12 = [#1551](https://example.com/builders#/task/1551). Dependencies in parentheses:

1. **(this ADR)** decision + scope — `0088`.
2. **Painterly cutout/register post-process** — `rembg` + despill + halo-zap + registration; the non-tile cutout path (productionize this session's prototype).
3. **`character_anim` family kind** — `slice_strategy` + `families.json` config + `family_loader`; painterly (no palette-snap/32×32).
4. **Painterly cross-frame deterministic checks** — adapt `family_checks.run_all` for the new kind: reuse silhouette-size coherence; add clean-edge/halo; pHash/anchor identity *(dep 3)*.
5. **Character vision criteria** — extend `family_review._criteria_for`: reuse `character_identity`; add `anatomy_correct` + `pose_match` *(dep 3)*.
6. **Pose-match + transition coherence** — order-aware neighbor-delta deterministic check + the `pose_match` criterion (the genuine gap) *(dep 4, 5)*.
7. **Recursive inbetween layer** — keyframes → recursive Gemini midpoints to target count; each graded by the per-frame checks *(dep 2, 3)*.
8. **Sequence assembly + manifest** — order, fps (on twos/ones), anchors → sprite set + manifest *(dep 7)*.
9. **Package as a Cloud Bongos module** — manifest/seam per [ADR 0083](<redacted>.md); config-driven rubric + pluggable backend *(dep 4, 5, 6, 8)*.
10. **First consumer: Bongo Buddha — 8 actions** — produce idle/laugh/yawn/sleep/kick/docile/reach/fall via the module; finish widget [#1523](https://example.com/builders#/task/1523) *(dep 9)*.
11. **`character-review` skill** — human wrapper over `run_family` for the painterly path (sibling to `otb-design-review`) *(dep 5)*.
12. **(future / spike)** learned-embedding identity scorer (DINOv2/CLIP) — "level 2" if vision-identity + pHash prove insufficient.

---

## Amendment — generation strategy: reference-kit + edit-the-hero + surgical loop + rigged motion (2026-06-27)

- **Date:** 2026-06-27 · **Deciders:** Lars (Archon), Claude · **Tasks:** [#1559](https://example.com/builders#/task/1559) (acceptance trial) + [#1622](https://example.com/builders#/task/1622)–[#1626](https://example.com/builders#/task/1626) (this fix). Supersedes the §3/§6 *generation* mechanism only; the grade-and-audit loop, the family pipeline, and the criteria (§4/§8) stand.

**What we hit.** Per-frame painterly generation (task [#1616](https://example.com/builders#/task/1616)) fixed the *structural* problem (still-image models ignore an N×M sheet grid — learning `#102`) but the live Bongo Buddha idle still **drifted** frame-to-frame (vision grader `character_identity=2`, `pose_match=1`); the owner rejected it. **Root cause:** each keyframe was drawn *independently from one reference*. A reference biases attention but does **not lock** identity, so every fresh draw reinterprets the character. (HANDOFF: [`docs/handoffs/character-anim-1559/HANDOFF.md`](../handoffs/character-anim-1559/HANDOFF.md).)

**The strategy evolution:** single sheet → per-frame → **edit-the-hero from a locked reference kit**, with motion split off to a rig.

1. **Reference kit + a locked hero (the closed-model substitute for a trained character model).** A small, locked model sheet — `brand/cloud-bongos/assets/mascot/kit/` (`kit.json` + hero + component crops) built deterministically by `kit_build.py`. Everything downstream conditions on it. (Owner-approved layer model: the animated frames are **figure + bongos only**; the cloud and the golden glow are **separate static composited layers**, not in the frames.)
2. **Edit-the-hero generation.** nano-banana (`gemini-2.5-flash-image`) is fundamentally an **edit** model: editing the locked hero's *pixels* preserves identity far better than redraw-from-reference. Each keyframe is an EDIT of the hero into the target pose, **multi-shot** conditioned on the kit (hero first = edit base; face + bongos crops = detail refs) + the nearest approved neighbour. `family_generator.build_frame_prompt` emits EDIT framing (lock identity / change only pose+expression) using the kit's identity prose. **Result: `character_identity` 2 → 9–10.**
3. **Surgical per-frame loop + chaining.** `run_family_painterly` keeps the frames that pass and regenerates **only** the failures, feeding each the grader's **per-frame** complaint (`family_review` now returns `per_frame`); frames chain from the nearest *approved* neighbour so drift can't accumulate; a **plateau early-stop** halts a systemic miss instead of burning attempts.
4. **Per-action edit-base (`kit_hero`).** Identity-lock is so strong that editing the *grinning* hero keeps the grin — `pose_match` stayed low because the idle's calm closed-eye expression never appeared. Fix: a **calm-faced hero** (`gen_idle_hero.py`, one edit) that the idle family selects via a `kit_hero` override; action families keep the grinning hero. **Result: expression fixed, total 8.0.**
5. **Rigged motion for subtle/repetitive actions (the new fallback, replacing "level 2 = LoRA" as the *first* fallback).** Generative editing locks identity + expression but **cannot calibrate subtle, repetitive idle motion** (the grader read taps as either a dead frame or a "wave"). A **2D puppet rig** (`puppet_rig.py`) animates *one approved hero* by geometric transforms (breath squash/stretch + alternating hand-tap layer moves) — identity perfect by construction, clears the deterministic gate 8/8, **zero per-frame model spend**. **Decision: generative for identity + expression (and expressive one-shots like laugh/fall); rig for simple repetitive motion (idle breathe/tap).** Per action, pick generative vs rigged.

**Consequences / guidance.**
- The durable asset is still the grader/audit; the *generator* is now "edit the locked hero," and **motion may be rigged rather than generated** for simple cycles.
- **Spend:** identity+expression cost ~$1.64 across the idle trials; the rig is free per frame. Every live run is owner-approved per round (≈$0.04/frame).
- **Known check limitation (learning):** `transition_no_dead` via coarse dHash can't see sub-perceptual motion (real in pixels, invisible to the hash) — rig amplitudes are tuned above that floor; a pixel-MAD motion signal is a candidate improvement.
- **Open:** the LoRA "level 2" (§"Alternatives") remains the deferred path *only if* identity ever proves insufficient — edit-the-hero made it unnecessary for now. Remaining [#1559](https://example.com/builders#/task/1559) scope (widget wiring + the other 7 actions, applying generative-or-rig per action) is released to `ready`.

---

## Amendment — generation mechanism: Veo image-to-video → keyed transparent sprite (2026-06-30)

- **Date:** 2026-06-30 · **Deciders:** Lars (Archon), Claude · **Task:** [#1559](https://example.com/builders#/task/1559). Supersedes the *generation mechanism* of both the original (§3/§6, per-frame) and the 2026-06-27 amendment (edit-the-hero + rig). **What still stands:** the grade-and-audit philosophy, and the **registered sprite + `manifest.json` output contract** a consumer plays (§7) — unchanged; the widget doesn't care how the frames were made.

**What we hit (the owner rejected both prior mechanisms on sight).**
- **The 2026-06-27 rig** — "the bongos play themselves" (a translated region dragged the drums with the hand) and "the buddha squeezes in and out" (whole-image vertical scale). A rig distorts one flat image; it cannot pose a hand or hold the drums still.
- **Per-frame edit-the-hero** — identity held (9–10), but in motion the **outline and ears boil** frame-to-frame, because every frame is still an *independent redraw*. A still-image model cannot hold an exact silhouette across frames.

**The insight.** A **video model maintains temporal consistency for free** — the one thing neither a rig nor per-frame redraw can give. So use video as the **motion source**, then convert its frames into a transparent sprite we own (which restores interactivity + lets every action share one background).

**The method (committed: [`brand/cloud-bongos/anim/`](../../brand/cloud-bongos/anim/README.md)).**
1. **Shoot on a PLAIN background** (`shoot.py`) — a flat-grey "green screen" seed from the locked hero → **Veo 3** (`veo-3.0-generate-001`) image-to-video. Veo bakes its background into the clip, so shooting figure-only is what lets rembg key cleanly **and** what keeps all 8 actions on one consistent (our) background. ~$3/clip on the owner's Gemini key.
2. **Spritify** (`spritify.py`) — decode → **auto-detect the zoom-free stretch** → pick the latest clean loop → **rembg** key each frame → align on **one union crop** → webp sprite + `manifest.json`.
3. **Build the widget** (`build_widget.py`) — composite the transparent sprite on **our** cloud + golden glow; drag / scrub / poke / play. Seed of the full interactive widget ([#1523](https://example.com/builders#/task/1523)).

**Gotchas (each cost real iteration on the idle — captured as a learning).**
- **Veo dollies in** even when told "static camera" → `spritify` auto-trims the zoomed tail by watching the figure's head-to-base height (the zoom was a *sampling* problem, not a registration one).
- **Use the whole stable stretch, not the first cycle** — the second hand only acts later in the clip, so a short loop reads as "one hand."
- **Align on ONE fixed crop, never per-frame** — a raised hand fools per-frame centering and slides the body; the body is static, only the hands move.
- **Veo under-animates calm prompts** → prompt for energetic, clearly two-handed motion; re-roll (~$3) if thin. **This is the method's main cost/reliability tax.**
- **Motion blur** on fast hands is baked into Veo frames — sharpened, not fully removable (the one cosmetic compromise).

**Consequences.**
- The durable asset is the **keyed sprite + manifest** (contract unchanged); the *generator* is now a video model. The family painterly generator + the puppet rig stay in the repo but are **off the mascot path**.
- **Spend:** ~$3/action (Veo) + free keying; the idle proof ran **~$6.31** total (2 Veo clips + early image trials).
- **idle delivered** ([`brand/cloud-bongos/assets/anim/idle/`](../../brand/cloud-bongos/assets/anim/idle/)); blocker [#51](https://example.com/builders#/blocker/51) cleared (spend approved, mascot reviewed, path built). The other 7 actions + the full interactive widget are the follow-up.
