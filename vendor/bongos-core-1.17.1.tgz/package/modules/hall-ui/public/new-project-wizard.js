// new-project-wizard.js — the "Start a project" hall widget (provisioning module,
// ADR 0111 / BONGOS-V1 goal 35, task 1983).
//
// The most ACCESSIBLE form of the canonical onboarding runbook (the /new-project skill,
// task 1981; the `bongos onboard` CLI, task 1982) — a point-and-click wizard for a
// non-technical owner. It files the provisioning REQUEST (the web tier only ENQUEUES —
// POST /provisioning/instances; the control-plane runner does the real standup, trust
// boundary intact, ADR 0111 §2) as a STANDALONE instance (ADR 0108), then renders the
// four irreducibly-human steps UI-first (create the repo, the OAuth app + secret, first
// sign-in) with the exact pinned values, and points at the Instances panel for status.
//
// GATED on the provisioning module (module:'provisioning'), like instances-panel.js —
// contributeHallWidget drops it entirely when the module is off (ADR 0062 §4).
(function () {
  'use strict';
  if (!window.OTB || typeof window.OTB.contributeHallWidget !== 'function') return;
  const { escapeHtml } = window.OTB;
  const API = '/api/bongos';

  // Mirror provisioning.isValidSlug (DNS/db-safe): 2–40 of [a-z0-9-], starts+ends
  // alnum, no double dash. Client-side pre-check; the server re-validates.
  function validSlug(s) {
    const v = String(s || '');
    return v.length >= 2 && v.length <= 40 && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(v) && !v.includes('--');
  }

  // The pinned GitHub OAuth-app values for a domain (auth.js WEB_REDIRECT_ORIGIN —
  // callback is the apex /api/gds/auth/web/callback). Mirrors onboard.oauthAppInstructions.
  function oauthAppValues(domain) {
    const origin = `https://${domain}`;
    return { homepageUrl: origin, callbackUrl: `${origin}/api/gds/auth/web/callback` };
  }

  let host = null;

  async function postJSON(path, body) {
    const res = await fetch(path, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (res.status === 401) { window.location.assign(`${API}/auth/web/start`); throw new Error('redirecting to auth'); }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) { const e = new Error((data.error && (data.error.message || data.error.code)) || `HTTP ${res.status}`); e.data = data; throw e; }
    return data;
  }

  // File a GitHub-App-Manifest onboarding link for the just-created instance (task 2080,
  // ADR 0133) and NAVIGATE the browser to GitHub's pre-filled "create App" screen. The
  // manifest rides a hidden form field; GitHub echoes our one-time `state`. After the
  // owner approves, GitHub redirects to the mothership callback and the control-plane
  // runner places the creds automatically — no secret is ever pasted. `account` is
  // 'personal' | 'org'.
  async function launchGithubApp(instanceId, account) {
    const data = await postJSON(`${API}/provisioning/instances/${instanceId}/github-app`, account ? { account } : {});
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = data.post_url; // https://github.com/…/settings/apps/new?state=<one-time>
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'manifest';
    input.value = JSON.stringify(data.manifest);
    form.appendChild(input);
    document.body.appendChild(form);
    form.submit(); // navigates away to GitHub
  }

  // After the request is filed, render the human-only next steps + a pointer to the
  // Instances panel for status. The FIRST step branches on greenfield vs adopt (ADR
  // 0121 §Decision 1 / task 2046). GitHub sign-in is now ONE CLICK via the App Manifest
  // flow (task 2080) — the manual OAuth-app path is kept as a collapsible fallback.
  function renderNextSteps(instanceId, slug, domain, mode) {
    const adopt = mode === 'adopt';
    const oa = domain ? oauthAppValues(domain) : null;
    const dnsNote = domain ? '' : '<li>Add a domain you own, then re-run to wire the address (a domain is needed before sign-in works).</li>';
    const repoStep = adopt
      ? `<li data-onboard-step="github-repo"><strong>Layer onto your existing repo</strong> — in your repo run <code>bongos init --adopt</code>. It shows a conflict pre-flight (migrations, CI, protected paths) and writes <em>nothing</em> until you accept; it never overwrites your files, and it imports your existing backlog (GitHub issues / a TODO/ROADMAP file). Commit + push.</li>`
      : '<li data-onboard-step="github-repo"><strong>Create the empty GitHub repo</strong> — github.com → New repository, leave it empty.</li>';
    // The one-click GitHub sign-in step + a collapsible manual fallback (only when a
    // domain is set — the App needs a real callback host).
    const signInStep = oa ? `<li data-onboard-step="oauth-app"><strong>Set up GitHub sign-in — one click</strong>. We’ll open GitHub with a pre-filled app; approve it, and we place the credentials on your instance automatically (no secret to copy).
        <div class="np-signin-actions">
          <button id="np-github-app" type="button" class="np-create-btn" data-instance="${escapeHtml(String(instanceId))}">Set up GitHub sign-in</button>
          <span id="np-github-app-msg" class="ledger__note"></span>
        </div>
        <details class="np-manual"><summary class="ledger__note">Prefer to do it by hand?</summary>
          <ol class="np-steps">
            <li><strong>Create the GitHub OAuth app</strong> — GitHub → <em>your account's</em> Settings → Developer settings → OAuth Apps → New OAuth App.
              <div class="np-kv"><span>Homepage URL</span><code>${escapeHtml(oa.homepageUrl)}</code></div>
              <div class="np-kv"><span>Authorization callback URL</span><code>${escapeHtml(oa.callbackUrl)}</code></div>
              <div class="np-kv"><span>Enable Device Flow</span><code>✅ required — the terminal login uses it (off by default)</code></div>
            </li>
            <li><strong>Place the secret — verified</strong> (never hand-edit the env file): on the control plane run
              <code>bongos … oauth-secret place ${escapeHtml(slug)} --client-id &lt;id&gt; --client-secret &lt;secret&gt; --apply</code>.</li>
          </ol>
        </details>
      </li>` : '';
    return `<div class="np-done">
      <p class="scroll__lede">✓ Provisioning requested for <strong>${escapeHtml(slug)}</strong> (standalone${adopt ? ', adopting your existing repo' : ''}). The control plane stands it up — watch its status in <strong>Instances</strong> below.</p>
      <h3 class="scroll__h" style="font-size:1rem">Your steps (the parts only you can do):</h3>
      <ol class="np-steps">
        ${repoStep}
        ${dnsNote}
        ${signInStep}
        ${oa ? `<li data-onboard-step="first-sign-in"><strong>First sign-in</strong> — once the instance is live, open <code>${escapeHtml(oa.homepageUrl)}</code> and sign in with GitHub; that makes you the owner (Archon).</li>
        <li><strong>Verify</strong> — <code>${escapeHtml(oa.homepageUrl)}/healthz</code> should report <code>auth_configured: true</code>.</li>` : ''}
      </ol>
      <p class="ledger__note">This is the same sequence the <code>/new-project</code> assistant and <code>bongos onboard</code> use.</p>
    </div>`;
  }

  async function submit() {
    const q = (id) => host.querySelector(id);
    const productName = q('#np-name').value.trim();
    const owner = q('#np-owner').value.trim();
    const repo = q('#np-repo').value.trim();
    const slug = q('#np-slug').value.trim().toLowerCase();
    const domain = q('#np-domain').value.trim();
    const mode = q('#np-mode') ? q('#np-mode').value : 'greenfield'; // greenfield | adopt (ADR 0121)
    const err = q('#np-error');
    err.textContent = '';

    if (!productName) { err.textContent = 'Give the project a name.'; return; }
    if (!owner || !repo) { err.textContent = 'Give the GitHub repo (owner and name).'; return; }
    if (!validSlug(slug)) { err.textContent = 'Slug must be 2–40 lowercase letters/numbers/dashes (no leading/trailing/double dash).'; return; }

    const btn = q('#np-create');
    btn.disabled = true; btn.textContent = 'Requesting…';
    try {
      const data = await postJSON(`${API}/provisioning/instances`, {
        slug,
        hosting_shape: 'standalone',
        domain: domain || undefined,
        target_ref: `${owner}/${repo}`,
      });
      const instanceId = data && data.instance ? data.instance.id : null;
      q('#np-form').hidden = true;
      q('#np-result').innerHTML = renderNextSteps(instanceId, slug, domain, mode);
      // Wire the one-click GitHub sign-in button (task 2080), if a domain gave us one.
      const gh = q('#np-github-app');
      if (gh) gh.addEventListener('click', async () => {
        const msg = q('#np-github-app-msg');
        gh.disabled = true; gh.textContent = 'Opening GitHub…'; if (msg) msg.textContent = '';
        try {
          await launchGithubApp(gh.getAttribute('data-instance'));
        } catch (e2) {
          gh.disabled = false; gh.textContent = 'Set up GitHub sign-in';
          if (msg) msg.textContent = e2 && e2.message ? `Couldn’t start it: ${e2.message}` : 'Couldn’t start it — try again.';
        }
      });
    } catch (e) {
      err.textContent = e && e.message ? `Couldn’t request it: ${e.message}` : 'Couldn’t request it — try again.';
      btn.disabled = false; btn.textContent = 'Create project';
    }
  }

  const SKELETON =
    '<h2 id="np-h" class="scroll__h">Start a project</h2>' +
    '<p class="scroll__lede">Stand up a <strong>standalone</strong> Cloud Bongos instance — its own repo running a pinned copy of the platform. Start fresh, or adopt a repo you already have. We file the request and walk you through the few steps only you can do.</p>' +
    '<div id="np-form" class="np-form">' +
      '<label class="np-field"><span>Project name</span><input id="np-name" type="text" placeholder="Mercury" autocomplete="off"></label>' +
      '<label class="np-field"><span>Starting from</span><select id="np-mode">' +
        '<option value="greenfield">A new, empty repo (greenfield)</option>' +
        '<option value="adopt">A repo I already have (adopt)</option>' +
      '</select></label>' +
      '<label class="np-field"><span>GitHub repo owner</span><input id="np-owner" type="text" placeholder="acme" autocomplete="off"></label>' +
      '<label class="np-field"><span>GitHub repo name</span><input id="np-repo" type="text" placeholder="mercury" autocomplete="off"></label>' +
      '<label class="np-field"><span>Instance slug</span><input id="np-slug" type="text" placeholder="mercury" autocomplete="off"></label>' +
      '<label class="np-field"><span>Domain you own <span class="ledger__note">(optional now)</span></span><input id="np-domain" type="text" placeholder="mercury.example.com" autocomplete="off"></label>' +
      '<p id="np-error" class="np-error" role="alert"></p>' +
      '<button id="np-create" type="button" class="np-create-btn">Create project</button>' +
    '</div>' +
    '<div id="np-result"></div>';

  function mount(hostEl) {
    host = hostEl;
    host.innerHTML = SKELETON;
    const btn = host.querySelector('#np-create');
    if (btn) btn.addEventListener('click', submit);
  }

  window.OTB.contributeHallWidget({
    id: 'new-project-scroll', label: 'Start a project', order: 33,
    module: 'provisioning', view: 'home', zone: 'home-main',
    labelledby: 'np-h', mount,
  });
})();
