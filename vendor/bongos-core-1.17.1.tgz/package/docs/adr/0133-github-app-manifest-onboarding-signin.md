# 0133 — One-click GitHub sign-in for onboarding via the GitHub App Manifest flow

- **Status:** Accepted — built in task 2080.
- **Date:** 2026-07-07
- **Deciders:** example-owner (owner/Archon), Claude. Owner asked to automate the GitHub step after demo.cloudbongos.com hit `auth_not_configured`.
- **Task:** [#2080](https://example.com/builders#/task/2080) · **Goal:** 35 (greenfield onboarding), criterion 165.

## Context

The last human friction in greenfield onboarding was wiring GitHub sign-in. The owner had to: open GitHub → Developer settings → **create an OAuth App by hand**, set homepage + callback, **generate a client secret**, copy it, and hand it to the box (`oauth-secret.js place`). It is the one step no prior automation removed because **GitHub has no API to create an OAuth App** — so it can't be scripted as-is. It surfaced concretely when demo.cloudbongos.com came up post-[#2078](https://example.com/builders#/task/2078) and reported `auth_configured:false`.

## Decision

Use GitHub's **App Manifest flow** — the only real automation path GitHub offers. Instead of a hand-built OAuth App, the owner registers a GitHub **App** from a **pre-filled manifest**: one click, approve on GitHub, and GitHub hands *us* the credentials. Sign-in works unchanged because a GitHub App's user-to-server token hits the same `GET /user` the OAuth-app flow used; GitHub simply ignores the extra `scope` param for Apps, and we only use the token once at sign-in to identify the user before minting our own `builder_session` (so the App token's expiry is irrelevant).

**The flow spans the trust boundary ([ADR 0111](<redacted>.md) §2 / [ADR 0016](<redacted>.md)) — deliberately:**

1. **Web tier** (the mothership hall, where the signed-in owner requested the instance) — `POST /api/bongos/provisioning/instances/:id/github-app` (own-scoped) mints a one-time `state` token, stores a `provisioning_oauth_manifests` row (status `pending`, TTL 30 min), and returns the pre-filled manifest + the GitHub form-POST target. The browser POSTs the manifest to GitHub.
2. **GitHub** creates the App and redirects the owner's browser to the **mothership** callback `GET /api/bongos/provisioning/github-app/callback?code=&state=` (public — a browser redirect with no session; the unguessable single-use `state` is the authorization, exactly as GitHub's own conversion `code` is "the code IS the auth"). The callback stores the `code`, flips the row to `code_received`, and shows a "finishing setup" page.
3. **Control-plane runner** (`provision.js`, the sole token-holder) drains `code_received` rows on its existing timer tick, exchanges the code via `POST https://api.github.com/app-manifests/{code}/conversions` for `client_id`/`client_secret`, writes them into `/etc/<slug>/web.env` (the `oauth-secret.js` placement it already used), restarts the unit, and verifies `/healthz` reports `auth_configured:true`.

**The client secret never touches the browser, chat, or the web tier.** Only GitHub's short-lived, single-use `code` is web-tier-visible; the secret is fetched by the control plane and written straight to disk.

### Why DB-backed state, not the in-memory OAuth-state cookie

The web tier and the control-plane runner are **separate processes**. The existing web sign-in `state` lives in an apex cookie + memory because one process owns the whole round-trip. Here the callback (web) and the conversion (runner) are different processes, so the `state`/`code` lease is a DB row with `expires_at` (the `merge_lease` / `builder_sessions` pattern), not `deviceFlows`/`pairStore`.

### Why conversion is control-plane-side, not web-side

The conversion endpoint is unauthenticated (the code is the auth), so the web tier *could* call it — but the resulting secret must land in `/etc/<slug>/web.env` on the box, which is a control-plane privilege. Doing the exchange on the control plane keeps the secret out of the web tier and DB entirely: the web tier only ever holds the short-lived code.

### Manifest shape

`redirect_url` = the **mothership** callback (the instance can't do the exchange). `callback_urls` = the **instance's** own `/api/gds/auth/web/callback` (what `auth.js` actually builds) **and** the `/api/bongos/...` alias, so sign-in works regardless of which prefix a build emits. `default_permissions: {}` (sign-in needs none), `hook_attributes.active:false`, `public:false`. Personal vs org differs only in the POST URL (derived from the repo owner); the App works for sign-in either way.

**App name (tasks 2093 → 2095).** GitHub App names are globally unique across all of GitHub, so a bare project slug (e.g. `demo`) is almost always already taken. The auto name is the **instance domain** (e.g. `demo.cloudbongos.com`): a domain is inherently unique (so it never collides) and it reads perfectly on GitHub's sign-in consent screen, where the name is shown as *"`<name>` by `<owner>` … will redirect to `https://<domain>`"* — the name IS the destination. GitHub keeps the dots in the display name (only the internal slug is transformed) and caps it at 34 chars. **Fallback** (no domain, or a domain over 34 chars): brand-qualify the project — `<mothership brand> - <project>`, e.g. `Cloud Bongos - demo`, from the mothership's own `branding().identity.productName` (portable, not hardcoded) — still far less collision-prone than a bare slug. Either way it is only a default the owner can rename on GitHub's confirmation screen.

## Consequences

- **Back-compat preserved.** An instance already on an OAuth App keeps working untouched — `loadGithubCreds()` reads the same `<PREFIX>_GITHUB_CLIENT_ID/SECRET`. The manifest path is the new *default* for fresh instances; nothing about `auth.js` changed.
- **All three onboarding surfaces stay in lockstep** (the goal-35 rule): the hall "Start a project" wizard gets a one-click **Set up GitHub sign-in** button (primary); the `bongos onboard` CLI + the `/new-project` skill present it as recommended with the manual OAuth-app path kept as a documented fallback.
- **Runner gating.** Conversion only runs once the instance is `active` (its unit exists), so a code that arrives mid-provision waits instead of failing; a dedicated droplet (web.env baked into cloud-init, no post-hoc exec path here) is refused with guidance and uses the manual path.
- **Residual risk (accepted).** If a valid `pending` `state` leaked, an attacker could return their own App's code and wire the victim instance to their App. Mitigations: the state is 256-bit, minted only for the signed-in owner, single-use, 30-min TTL, never logged — the same posture as the existing OAuth-state cookie. A `code_received` row whose instance never goes active lingers (benign, visible); a TTL sweep for those is a later hardening.
- **New module surface:** table `provisioning_oauth_manifests` (migration `provisioning_003`), two routes, and the runner's `convertManifestCode`/`placeManifestCreds`/`drainOAuthManifests`. The intent-action CHECK is widened to include `oauth-manifest` for a future intent-driven path, though today the runner drains by scanning the table on the same timer tick.
