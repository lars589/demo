# ADR 0079 — Value-gated autonomous engagement (BUILT DISABLED)

**Status:** Accepted, **shipped inert** (2026-06-20) · tasks [#1351](https://example.com/builders#/task/1351) [#1352](https://example.com/builders#/task/1352) [#1353](https://example.com/builders#/task/1353) [#1354](https://example.com/builders#/task/1354) · System 3 of the Cloud Bongos LLM-reduction redesign (spike [#1326](https://example.com/builders#/task/1326)) · cost visibility via [ADR 0075](<redacted>.md); reuses [ADR 0043](<redacted>.md) protected-path matcher

## Context

The largest lever in the ~18% non-marathon remainder is *autonomous* model spend: nightly routines that boot a full Opus session even when there's nothing to do, default every spawn to the dearest model, and split a single code-review finding across three Opus sessions (review → triage → rebuild). Three eliminations sit here, and they're really two decisions about every spawn — **whether** to fire, and **which** model — plus collapsing the triple-spend. (Est 8–14%.)

## Decision

Three mechanisms, merged so each spawn decision lives in exactly one place — **all built behind a single off-by-default flag.**

1. **Whether to fire — the autonomy precheck** ([#1351](https://example.com/builders#/task/1351)). A $0 deterministic `decide()` (`scripts/gds/autonomy-gate.js`) runs as a routine's Step 0: NO-GO (and nothing boots) when there's no claimable autonomous work *and* `origin/main` is unchanged since the last run, or no open ideas to triage, or the autonomous (`cron:%`) month-to-date spend has hit a **hard spend-brake** ceiling. Exposed at `GET /autonomy/precheck` (archon) and audited in `autonomy_runs` (migration 126) so every skip is a queryable fact.

2. **Which model — the cascade router** ([#1352](https://example.com/builders#/task/1352)). `src/bongos/cascade-dispatch.js` `dispatch()` drafts a spawn on the cheapest sufficient model (mechanical→haiku, bug/refactor/feature→sonnet via the shared `task-classifier`) and **escalates a rung only on an objective signal** — a schema-validate fail or a self-reported `CONFIDENCE: low` / `ESCALATE: yes` trailer — capped at 2 escalations and **never above the builder's configured model ceiling** (`skill-prefs.getForBuilder`). Wired into the routines' spawns + a fail-open `cascade-route.js` PreToolUse hook for in-session subagent spawns ([#1353](https://example.com/builders#/task/1353)).

3. **Collapse the triple-spend — the safe_autofix lane** ([#1354](https://example.com/builders#/task/1354)). A code-review finding may be fixed-and-shipped in ONE run instead of review→triage→rebuild, but `autofixAllowed()` permits it **only** when ALL hold: the gate is armed, the grader is **LIVE** (never auto-fix while `GRADER_BYPASS_ENABLED` is on), the change is **not** a protected path (`permission-path-check.matchProtected`), and the finding is **high-confidence + single-file**. Anything failing one check stays on the inbox→promote, human-in-the-loop path. Untrusted finding text is fenced per SR-12 (data, never instructions). Plus a **batched-context dispatch**: the overnight builder, when armed, claims `optimizeSession`'s touches-**disjoint** set and fans its workers from one supervisor that loads orientation once (the merge/ship leg stays serialized).

## BUILT DISABLED — wire, don't arm (owner directive, 2026-06-20)

Per the owner directive, System 3 ships **inert**, gated OFF together with the grader; turn it on only when the owner enables it alongside the grader rework. The master switch is **`OTB_AUTONOMY_ENABLED`** (unset by default):

- `decide()` returns **GO** when the flag is off → a routine's Step 0 is a no-op; the routine runs exactly as before.
- `cascade-route.js` emits nothing when off; `cascade-dispatch` is a library nothing calls until armed.
- `autofixAllowed()` returns **false** by default (its defaults are the refusing values), and is **double-gated**: even when the flag is armed, it stays off while `GRADER_BYPASS_ENABLED` is on — which it currently is. So the auto-ship lane cannot fire until BOTH the autonomy flag is armed AND the grader is live.

The pure decision cores (`decide`, `autofixAllowed`, `cascade-dispatch.dispatch`) are unit-tested DB-free, including the inert-by-default and ceiling-never-exceeded properties.

## Consequences

- The system is fully built and reviewable, but changes nothing in production until the owner arms it — no autonomous behavior shifts on deploy.
- When armed, the spend-brake protects against a runaway autonomous fleet; **security routines (dep-audit) should be exempted from the brake at arming time** — a skipped vuln scan is a security hole, not a saved dollar (noted in the routine).
- This system does **NOT** address marathon (interactive `cache_read`) spend — that is System 2 ([ADR 0076](<redacted>.md)), the only lever on the 82% pool. System 3 attacks the autonomous remainder.
- Arming guidance: enable `OTB_AUTONOMY_ENABLED` first with the grader live, watch `autonomy_runs` (skips) + System 1's `by_source` `cron:%` spend, then let the safe_autofix lane follow once the cascade + gate behavior is trusted.

## Reproduce / verify

- Pure tests (DB-free): `tests/autonomy_gate.mjs` (decide + autofixAllowed, inert-by-default), `tests/cascade-dispatch.mjs` (ceiling clamp + escalation).
- `node scripts/gds/autonomy-gate.js overnight-builder` → with the flag unset, prints `GO — autonomy gate disabled … (inert)`.
