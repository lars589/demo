-- V3.R88 (#307): Graceful builder exit.
--
-- A builder can be deactivated (they quit / are offboarded) without losing any
-- history. status gates whether they can claim new work; their drachmae
-- (credits) and credit_log stay untouched (preserved indefinitely), their
-- shipped tasks and session_logs stay attributed to them, and an Archon can
-- reactivate them later. On exit their rank drops to the sandboxed 'xenos'
-- tier and their active claims are released cleanly (handled in app code).

ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'active'
    CHECK (status IN ('active', 'inactive')),
  ADD COLUMN IF NOT EXISTS deactivated_at     timestamptz,
  ADD COLUMN IF NOT EXISTS reactivated_at     timestamptz,
  ADD COLUMN IF NOT EXISTS deactivated_reason text;
