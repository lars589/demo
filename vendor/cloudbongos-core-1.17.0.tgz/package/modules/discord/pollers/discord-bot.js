// modules/discord/pollers/discord-bot.js — the web-process poller entry the loader
// starts/stops (BV1.R47 / task 1416).
//
// The module manifest declares contributes.pollers:["discord-bot"]; the loader
// (src/module-loader/loader.js startModulePollers) requires THIS file and calls
// start(deps) at boot, stop() at shutdown — the module-agnostic successor to the
// hardcoded `discordBot.start()` block server.js used to carry. A thin shim over
// the bot itself: start() is non-blocking + failure-isolated by the loader (a
// Discord gateway problem must never take the game/API down), and stop() closes
// the gateway socket cleanly so a systemd restart leaves no zombie session.

'use strict';

const bot = require('../discord-bot');

module.exports = {
  start: () => bot.start(),
  stop: () => bot.stop(),
};
