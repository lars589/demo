// src/bongos/routes/gate-approvals.js — Archon gate-surface PR approval from the hall
// (task 1179, ADR 0058 amendment).
//
// WHY. The gate-review CI check (ADR 0058) clears an ESCALATE (hard floor) ONLY on
// an owner approval, and a NEEDS_TRUST without a Metic+ author likewise blocks until
// the owner approves. Historically that owner approval was a GitHub APPROVED review
// by lars589 on the head sha — i.e. the owner had to leave a GitHub/terminal review.
// This router gives Archons a browser-only equivalent (feedback: auth flows must be
// UI-first), trust-consistent with the existing server-set `gate-author-trust`
// status: the server re-checks the caller's Archon rank server-side (ADR 0016) and
// sets a `gate-owner-approved` commit status that the gate-review workflow honors as
// owner approval. A PR author cannot forge it (only the server holds the credential).
//
//   GET  /gate-approvals               — open PRs whose gate-review check is red,
//                                         with the verdict + per-file reasons (Archon)
//   POST /gate-approvals/:pr/approve    — record owner approval + re-run the check (Archon)
//
// The list's "is this awaiting approval" signal is the LIVE gate-review check
// conclusion (authoritative), not a re-derivation; classifyChanges() is reused only
// to render WHY each PR escalated, so the hall shows exactly the CI reasoning.

const express = require('express');
// Intra-module + the published doorway — a module never requires a core internal.
const api = require('../../../src/module-api');
const auth = api;
const githubPush = require('../github-push');
const { parseId } = api;
// The SAME pure classifier the CI gate runs — reused (never duplicated) so the hall
// shows identical verdict + reasons. Safe to require: gate-review.js guards its CLI
// entrypoint behind `require.main === module`, so importing it runs no side effects.
const { classifyChanges, resolveAction } = require('../../../scripts/gds/gate-review');

// Pull a GDS task id out of a server-published PR's title ("task 1163: …") or body
// ("… for task 1163."). Returns a number or null. Display-only.
function taskIdFromPr(pr) {
  const hay = `${pr.title || ''}\n${pr.body || ''}`;
  const m = /\btask\s+(\d{1,7})\b/i.exec(hay);
  return m ? Number(m[1]) : null;
}

// Find a named check/status in the head-commit rollup (CheckRun.name or
// StatusContext.context — listOpenPullRequests flattens both to `name`).
function findCheck(pr, name) {
  return (pr.checks || []).find((c) => c.name === name) || null;
}
const isSuccess = (c) => c && String(c.conclusion || '').toUpperCase() === 'SUCCESS';
const isFailure = (c) => c && String(c.conclusion || '').toUpperCase() === 'FAILURE';

// Run the pure classifier over a PR's changed files to produce the display verdict +
// reasons. blobAt returns null (no file content fetched): the path-level hard-floor /
// sensitive-surface rules — which produce the human reasons — do not need content;
// the content-only AUTO-narrowing certifications fail-closed to a stricter verdict,
// which is the safe direction for a read-only "why is this stuck" view.
function summarizeGate(files) {
  const r = classifyChanges({ files, blobAt: () => null, diffBytes: 0 });
  const reasons = [
    ...(r.escalations || []).map((e) => ({ path: e.path, reason: e.reason, hard_floor: true })),
    ...(r.needsTrust || []).map((e) => ({ path: e.path, reason: e.reason, hard_floor: false })),
  ];
  return { verdict: r.verdict, reasons, surfaces: r.surfaces || [] };
}

module.exports = function buildGateApprovalsRouter() {
  const router = express.Router();

  // GET /gate-approvals — open PRs awaiting owner approval (gate-review red), with the
  // verdict + per-file reasons + changed files + diff link. rank: archon.
  router.get('/gate-approvals', auth.requireBuilder, auth.requireRank('archon'), async (req, res) => {
    if (!githubPush.isConfigured()) {
      return res.fail('publish_unconfigured', { status: 503, message: 'No server GitHub credential configured — cannot read pull requests.' });
    }
    try {
      const prs = await githubPush.listOpenPullRequests({});
      const awaiting = [];
      let checking = 0;
      for (const pr of prs) {
        if (pr.is_draft) continue;
        const gate = findCheck(pr, 'gate-review');
        if (!gate) continue; // not a gate-reviewed PR (or it hasn't run yet)
        if (String(gate.status || '').toUpperCase() !== 'COMPLETED') { checking += 1; continue; }
        if (!isFailure(gate)) continue; // green/neutral → not awaiting
        // gate-review is red → blocked awaiting trust/owner approval. Render WHY.
        let summary = { verdict: 'unknown', reasons: [], surfaces: [] };
        try {
          const files = await githubPush.getPullRequestFiles({ number: pr.number });
          summary = summarizeGate(files);
          summary.files = files.map((f) => ({ path: f.path, status: f.status }));
        } catch (_) {
          summary.files = [];
        }
        awaiting.push({
          number: pr.number,
          title: pr.title,
          url: pr.url,
          task: taskIdFromPr(pr),
          author: pr.author,
          head_sha: pr.head_sha,
          verdict: summary.verdict,
          reasons: summary.reasons,
          files: summary.files,
          author_trusted: isSuccess(findCheck(pr, 'gate-author-trust')),
          already_approved: isSuccess(findCheck(pr, githubPush.GATE_OWNER_APPROVED_CONTEXT)),
          gate_review_url: gate.url || null,
        });
      }
      // The PR check rollup is unreadable when the server credential lacks `Checks: read`
      // (operator blocker): listOpenPullRequests then returns partialErrors and every PR's
      // `checks` is empty, so the awaiting list is silently empty. Surface that so the hall
      // can say "checks unreadable — grant the App Checks:read" rather than "nothing stuck".
      const checksReadable = !(prs.partialErrors && prs.partialErrors.length);
      res.json({
        configured: true,
        awaiting,
        count: awaiting.length,
        checking,
        checks_readable: checksReadable,
        ...(checksReadable ? {} : {
          note: 'PR check rollup is unreadable — the server GitHub App is missing the Checks:read permission, so gate-review-red PRs cannot be listed. Grant it and reinstall.',
        }),
      });
    } catch (err) {
      console.error('[gds] GET /gate-approvals', err);
      // 500, not 502: Cloudflare replaces an origin 502/504 with its own branded
      // gateway-error page, which swallows this JSON body. A 500 is passed through, so
      // the structured error actually reaches the caller (the "never a bare 502" rule).
      res.fail('gate_list_failed', { status: 500, message: err.message, details: { detail: err.detail || null } });
    }
  });

  // POST /gate-approvals/:pr/approve — record owner approval for a stuck gate PR and
  // re-run the gate-review check so it clears. rank: archon (clears the hard floor —
  // pinned in route-rank-check.EXPECTED_RANKS for downgrade protection).
  router.post('/gate-approvals/:pr/approve', auth.requireBuilder, auth.requireRank('archon'), async (req, res) => {
    const number = parseId(req, res, { param: 'pr', code: 'bad_pr', positiveInt: true });
    if (number == null) return;
    if (!githubPush.isConfigured()) {
      return res.fail('publish_unconfigured', { status: 503, message: 'No server GitHub credential configured — cannot approve.' });
    }
    try {
      // Resolve the live OPEN PR + its current head sha (the approval is sha-pinned,
      // so a later commit's head carries no approval — red-team #2b protection).
      const prs = await githubPush.listOpenPullRequests({});
      const pr = prs.find((p) => p.number === number);
      if (!pr) return res.fail('pr_not_open', { status: 404, message: `No open PR #${number}.` });
      if (!pr.head_sha) return res.fail('no_head_sha', { status: 409, message: 'Could not resolve the PR head commit.' });

      const gate = findCheck(pr, 'gate-review');
      if (gate && isSuccess(gate)) {
        return res.json({ ok: true, pr: number, already_clear: true, message: 'gate-review is already green — nothing to approve.' });
      }

      // 1. Set the trustless owner-approval status on the head sha.
      const set = await githubPush.setGateOwnerApproved({
        sha: pr.head_sha,
        login: req.builder.github_login,
        targetUrl: pr.url,
      });
      if (!set) {
        // 500, not 502 — Cloudflare masks an origin 502 with its branded page (see catch).
        return res.fail('status_set_failed', { status: 500, message: 'Could not set the gate-owner-approved status.' });
      }

      // 2. Re-trigger gate-review (close+reopen → `pull_request: reopened`) so the
      //    required check re-evaluates the new approval; re-arm auto-merge.
      let recheck = { reopened: false, auto_merge: false };
      try {
        recheck = await githubPush.recheckPullRequest({ number });
      } catch (e) {
        // The status IS set; if the re-trigger failed, the next push or a manual
        // re-run still clears it, and the publish reconciler sweep merges once green.
        console.error('[gds] gate-approval recheck failed', e);
        return res.json({
          ok: true, pr: number, head_sha: pr.head_sha, status_set: true, recheck: 'failed',
          message: 'Approval recorded. Re-run of the gate check did not fire — it will clear on the next push or a manual re-run.',
        });
      }

      res.json({
        ok: true,
        pr: number,
        head_sha: pr.head_sha,
        status_set: true,
        recheck,
        message: 'Approval recorded. Re-running the gate check — the PR merges once it goes green.',
      });
    } catch (err) {
      console.error('[gds] POST /gate-approvals/:pr/approve', err);
      // 500, not 502: Cloudflare replaces an origin 502/504 with its own branded
      // gateway-error page, swallowing this JSON. The reported symptom — a bare
      // "error code: 502" interstitial instead of a structured error — was exactly this.
      // A 500 is passed through, so the caller sees { error, message, detail }.
      res.fail('gate_approve_failed', { status: 500, message: err.message, details: { detail: err.detail || null } });
    }
  });

  return router;
};
