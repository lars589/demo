-- migration 103: search_chunks — the lexical retrieval substrate (task 944, V4.R06)
--
-- Implements ADR 0060 §2 (GDS retrieval layer: Postgres-resident, lexical-first,
-- rank-scoped, fail-open). One table in the EXISTING GDS Postgres holds every
-- searchable chunk (markdown docs + DB prose); full-text (tsvector) and trigram
-- (pg_trgm) match run as SQL against it, fused with RRF in the search route
-- (#949). No new service, no new monthly cost (CLAUDE.md §4).
--
-- SCOPING IS A FIRST-CLASS COLUMN, NOT A LATER FILTER (ADR 0060 §6 / ADR 0016):
--   * min_rank          — the LOWEST builder rank that may see this chunk. The
--                         search route filters in the SQL WHERE clause against the
--                         caller's LIVE, server-resolved rank, so a sub-Metic query
--                         can never select a Metic+ chunk in the first place. This
--                         keeps the index from becoming a read-side bypass of the
--                         trust boundary (the exact failure mode ADR 0016 guards).
--   * owner_builder_id  — non-null ⟺ a per-builder PRIVATE chunk (e.g. a builder's
--                         own memory). Returned ONLY to that owner (the route adds
--                         `owner_builder_id IS NULL OR owner_builder_id = <session>`),
--                         the owner always taken from the authenticated session,
--                         never from input — same posture as src/bongos/routes/memory.js.
--
-- The isolation suite (#950, tests/search_isolation.mjs) is the regression guard
-- that both filters live in SQL and can't be dropped by a later refactor.

-- pg_trgm ships with standard Postgres contrib (no new package); enables the
-- trigram fuzzy-match leg (similarity / % operator + a GIN gin_trgm_ops index).
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE IF NOT EXISTS search_chunks (
  id               bigserial PRIMARY KEY,
  -- 'doc' = a chunk of a repo markdown file; 'db' = a chunk of DB prose
  -- (task description/value summary, learning, session-log summary, etc.).
  source_kind      text   NOT NULL CHECK (source_kind IN ('doc', 'db')),
  -- The source identity: a repo-relative path ('docs/adr/0016-....md') for docs,
  -- or a typed ref ('task:431', 'learning:53') for DB prose. Together with
  -- chunk_index it uniquely names a chunk, so re-ingest is an idempotent upsert.
  source_ref       text   NOT NULL,
  chunk_index      int    NOT NULL,
  -- Breadcrumb to the chunk's section, e.g. 'CLAUDE.md > §8 Versioning > Working
  -- rules'. Carried so a result is self-locating and the snippet has context.
  heading_path     text,
  -- The source's human title, for result display.
  title            text,
  -- The chunk text — what gets shown as a snippet and (with title + heading_path)
  -- indexed into tsv.
  body             text   NOT NULL,
  -- Scoping (see header). Default 'xenos' = visible to everyone (the common case
  -- for ordinary docs); permission-core docs are ingested at 'metic'.
  min_rank         text   NOT NULL DEFAULT 'xenos'
                     CHECK (min_rank IN ('xenos', 'thetes', 'metic', 'archon')),
  -- Per-builder private chunk owner (NULL = shared/non-private). ON DELETE CASCADE:
  -- a private chunk has no meaning once its owner is gone (mirrors builder_memory).
  owner_builder_id bigint REFERENCES builders(id) ON DELETE CASCADE,
  -- sha256 of body — the ingestion delta key (skip re-write when unchanged).
  content_hash     text   NOT NULL,
  -- Generated FTS vector over title (weight A) + heading_path (B) + body (C), so
  -- ts_rank_cd weights a title/heading hit above a body hit. Uses the 2-arg
  -- to_tsvector('english', ...) form — IMMUTABLE, as a generated column requires
  -- (the 1-arg form depends on default_text_search_config and is NOT immutable).
  tsv              tsvector GENERATED ALWAYS AS (
                     setweight(to_tsvector('english', coalesce(title, '')), 'A') ||
                     setweight(to_tsvector('english', coalesce(heading_path, '')), 'B') ||
                     setweight(to_tsvector('english', body), 'C')
                   ) STORED,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  -- One row per (source, chunk ordinal) → re-ingest is ON CONFLICT upsert.
  UNIQUE (source_kind, source_ref, chunk_index)
);

-- FTS leg: GIN over the generated tsvector.
CREATE INDEX IF NOT EXISTS idx_search_chunks_tsv
  ON search_chunks USING gin (tsv);

-- Trigram leg: GIN gin_trgm_ops over body for similarity() / % fuzzy match.
CREATE INDEX IF NOT EXISTS idx_search_chunks_body_trgm
  ON search_chunks USING gin (body gin_trgm_ops);

-- Idempotent re-ingest + delete-by-source (the ingesters key on this).
CREATE INDEX IF NOT EXISTS idx_search_chunks_source
  ON search_chunks (source_kind, source_ref);

-- Owner-scoped lookups (a builder's own private chunks). Partial — most chunks
-- are shared (owner NULL), so only index the private ones.
CREATE INDEX IF NOT EXISTS idx_search_chunks_owner
  ON search_chunks (owner_builder_id) WHERE owner_builder_id IS NOT NULL;

-- Counter hygiene: keep the migration-number allocator above this file so the
-- next reservation can't collide with 103 (per the planning-session learning).
UPDATE migration_counter SET next_number = GREATEST(next_number, 104) WHERE id = 1;
