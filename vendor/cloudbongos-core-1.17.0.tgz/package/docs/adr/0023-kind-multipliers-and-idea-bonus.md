# ADR 0023 — Kind multipliers + staged idea-promotion bonus

**Date:** 2026-05-28
**Context:** GDS-V3, task [#247](https://example.com/builders#/task/247) (V3.R27 — Kind multipliers + staged idea-bonus).
**Status:** Accepted.

## Problem

Every task in the GDS carries a `credits_reward` value (the in-world "drachmae" payout when the task ships). Before this ADR, that value was paid 1:1 regardless of task kind. A 40-credit `cleanup` ship and a 40-credit `bug` ship both landed exactly 40c. That's a problem for two reasons:

1. **It silently disincentivises the work we want more of.** Capturing a learning that prevents a future bug, resolving a blocker that was costing the builder days, or landing a decision/ADR are all *higher leverage* per builder-hour than the average feature. Paying them the same says "we don't care which you do." In practice we care a lot.
2. **The idea_inbox economy was unfunded.** Anyone could capture an idea, get it triaged into a task, and the task's eventual shipper got 100% of the reward. The capturer earned 0 — even though the idea was the unblocker. Capturing felt like volunteer work.

The fix has to be **small, transparent, and hard to game.** It can't be a sliding rubric the builder can argue with; it can't let a builder reclassify a task to chase 3× payouts; it has to leave a clear audit trail.

## Decision

Two coordinated changes, both at credit-grant time inside the existing `applyGrade` / `confirmTask` / `decideOverrideRequest` transactions:

### 1. Per-kind multiplier table (frozen constant in src/bongos/db.js)

```js
const KIND_MULTIPLIERS = Object.freeze({
  feature:             1.0,
  bug:                 1.2,
  'learning-capture':  1.5,
  'blocker-resolution':1.5,
  decision:            1.3,
  infra:               1.0,
  refactor:            0.9,
  cleanup:             0.8,
  spike:               1.1,
  unclassified:        1.0,
});
```

Applied at the moment a `task.confirmed` credit_log row is written. The `description` column (added in migration 031 for the net-negative bonus) records the math inline:

```
40c × 1.5 = 60c (learning-capture)
```

So an auditor reading credit_log later can reconstruct the payout without re-deriving the multiplier from the task's kind at read time.

### 2. Staged idea-promotion bonus

When a task ships and the task was promoted from `idea_inbox` (i.e. there exists a row with `idea_inbox.promoted_to_task_id = task.id`), the original capturer (`idea_inbox.captured_by`) receives **25% of the multiplier-adjusted reward**, rounded to the nearest integer drachma. Paid as a separate `credit_log` row with `reason='idea_promotion_bonus'` and an explanatory description.

Guards:
- **Idempotent** on `(task_id, reason='idea_promotion_bonus')` — a re-grade can't double-pay.
- **No self-bonus**: if the same builder captured the idea AND shipped the task, no bonus is paid (they already got the full task reward).
- **Only when capturer is set**: idea_inbox rows where `captured_by IS NULL` (legacy imports) skip the bonus.

## Multiplier values + rationale

The values fan out from `feature = 1.0` (the baseline kind) by no more than ±0.5×. Tight clamp on purpose: too narrow to make reclassification a meaningful exploit, wide enough to send a real signal.

| Kind                | Mult  | Why                                                                                                    |
| ------------------- | ----- | ------------------------------------------------------------------------------------------------------ |
| `feature`           | 1.0×  | Baseline — every other value is "relative to a feature."                                               |
| `bug`               | 1.2×  | Bug fixes prevent compounding failure. Slight bump to surface bug-finding as worthwhile-on-its-own.   |
| `learning-capture`  | 1.5×  | High leverage: one captured learning saves N future debugging sessions. The most under-incentivised work in V2. |
| `blocker-resolution`| 1.5×  | A resolved blocker unblocks every linked task. Same leverage argument as learnings.                   |
| `decision`          | 1.3×  | ADRs / planning artifacts are durable. Worth more than a single feature; not as compounding as a learning. |
| `infra`             | 1.0×  | Infra ships are large and valuable but already typically carry larger `credits_reward` values. No extra mult needed. |
| `refactor`          | 0.9×  | Refactors are mostly neutral — useful when they're a precursor to a feature, dead weight when they aren't. Light penalty. |
| `cleanup`           | 0.8×  | Cleanup is housekeeping. Necessary but not the work we want more of right now. Bigger penalty than refactor. |
| `spike`             | 1.1×  | Spikes produce knowledge (ADRs, follow-up tasks). Small premium to encourage them when uncertainty is real. |
| `unclassified`      | 1.0×  | Neutral — auto-classifier fallback. If a task lands here it should be re-kinded, not penalised.       |

These are policy values. **They will be re-tuned at version close-out** (PMS retros) based on what mix of work we actually want for the next version. The fact that they live in a frozen constant in `db.js` (not a `kind_multipliers` table) is deliberate: changing them should require a code review and commit, not a `psql` UPDATE.

## Idea-bonus rationale: why 25% and why a slice (not a flat fee)

**Why a slice (not flat):** The bonus has to scale with the task's value. A 5c throwaway-idea task and a 200c platform-shift task can both come out of the inbox; flat-fee would over-reward trivial captures and under-reward important ones. Slice scales naturally.

**Why 25%:** Big enough to be motivating (an idea that becomes a 100c bug-fix earns the capturer 25c — a meaningful chunk), small enough that the shipper still gets the majority share (their work is *executing* the idea, which is harder than capturing it). The shipper is paid 100% of the kind-adjusted reward; the capturer's bonus is *on top*, not deducted. (This is intentional. The marginal credit cost is real but small — most ideas come from the same handful of builders who would otherwise have shipped the work themselves.)

**Why "no self-bonus":** Self-paying would degenerate to "every capture is a free 25%." That's not what the bonus is for — it's compensation for the social good of capturing an idea *that someone else then runs with*.

## Consequences

### Direct
- All future ships pay out multiplier-adjusted credits. Old ships are untouched; their credit_log rows keep their NULL `description`.
- Learning-capture / blocker-resolution / decision ships become more attractive. Cleanup / refactor become slightly less so. The discipline mix should shift accordingly over the next two weeks of shipping.
- `idea_inbox.captured_by` becomes economically meaningful. Builders who triage and capture ideas now have a payoff curve. Capturing without expecting anything still works the same; capturing *deliberately* — knowing a bonus may follow — is rewarded.
- The `Credits awarded:` line in `/builder-ship` output gains two new lines when relevant (kind multiplier breakdown and idea-promotion bonus). Audit trail is also visible by reading `credit_log.description` directly.

### Indirect
- **Game-the-system risk:** A builder could theoretically reclassify their `feature` task as `learning-capture` to chase 1.5×. Two safeguards:
  - The auto-classifier (V2 [#122](https://example.com/builders#/task/122)) produces an opinion on `kind` at task creation; manual override is logged in `audit_log`.
  - Subagent grader sees the kind in the prompt and can flag misclassifications in `issues[]`.
  Worst case the swing is 0.5× — small enough that the friction of arguing the misclassification isn't worth the gain on most tasks.
- **Bonus drainage risk:** If a power-user captures hundreds of ideas in idea_inbox and they all eventually get shipped by others, that user accumulates large bonus payouts without doing the work. This is a *feature*, not a bug — capturing high-quality ideas IS valuable work. If the pattern becomes pathological we can cap per-capturer bonuses per version in a follow-up.
- **Re-grade idempotency:** Both the primary credit and the idea-bonus are guarded on the same `task_id` + `reason` key. A re-grade for the same task is a true no-op for both ledger rows.

### Reversal posture

This is reversible at policy level by editing `KIND_MULTIPLIERS` (uniform 1.0s + `IDEA_BONUS_FRACTION = 0` would restore the V2 behaviour). Already-paid bonuses stay paid (the ledger is append-only).

### What changes vs. what stays the same

| Before                                                          | After                                                                                                |
| --------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| 40c feature ships → 40c                                         | 40c feature ships → 40c (no change for the baseline)                                                 |
| 40c cleanup ships → 40c                                         | 40c cleanup ships → 32c                                                                              |
| 40c learning-capture ships → 40c                                | 40c learning-capture ships → 60c                                                                     |
| credit_log row has NULL description                             | credit_log row has `40c × 1.5 = 60c (learning-capture)`                                              |
| idea_inbox capturer earns 0 when their idea ships               | idea_inbox capturer earns 25% of the multiplied amount (rounded), if different from the shipper     |
| One credit_log row per ship                                     | Up to two rows: `task.confirmed` (shipper) + optional `idea_promotion_bonus` (capturer)              |
| `confirm` / `applyGrade` / `decideOverrideRequest` write 1× raw | All three paths route through `insertMultipliedConfirmCredit` + `maybeAwardIdeaPromotionBonus`        |

## Cross-refs

- Pairs with R32 (criterion-proposal workflow) — proposers will earn similar staged credit when their criteria land. Same shape, different source table.
- Builds on migration 031 (V3.R93 [#354](https://example.com/builders#/task/354)) which added `credit_log.description` for the net-negative ship bonus.
- Migration 041 (this task) reserves the migration number; the actual policy lives in code.
- Cross-references the kind enum from migration 006 (V2): `feature, bug, infra, refactor, spike, learning-capture, cleanup, decision, blocker-resolution, unclassified`.
