# ADR 0103 — Core-first extraction: Cloud Bongos is the trunk, Example splits

- **Status:** Accepted
- **Date:** 2026-07-02
- **Track:** internal
- **Task:** [#1726](https://example.com/builders#/task/1726) (BV1.R87) — the owner-review decision this ADR records.
- **Supersedes:** [ADR 0100](<redacted>.md) §§1–2 (the Mercury-first sequence and the "Example stays coupled until a later decision" plank). **Retains ADR 0100 §3** (per-repo GDS) **and §4** (the generated mirror, retired conditionally).
- **Builds on:** [ADR 0062](<redacted>.md) §1 (portable-core / host-instance cut-line), [ADR 0098](<redacted>.md) (`isPublishable()` — the executable definition of "the core"), [ADR 0100](<redacted>.md) §§3–4 + its R84 (`bongos package-core`, shipped), [ADR 0065](<redacted>.md) (AGPL / non-profit / AI-first).
- **Reshapes:** the R84 → R86 spine — inserts a core-extraction step before Mercury (R85) and adds a committed Example-split step (see §4).
- **Amended by:** [ADR 0108](<redacted>.md) — resolves §2's mechanism-neutral consumer-repo shape ("installs a pinned core version and layers its own content on top") into configurable-root.

## Context

[ADR 0100](<redacted>.md) was accepted 2026-07-01. It chose two repos, but sequenced **Mercury** (a greenfield Example instance) as the *first* two-repo consumer and deliberately left **Example coupled** as the single-checkout reference instance "until a later, separate decision" — on the reasoning that moving a live product before the update channel is proven buys risk for no gain.

A next-day owner review (2026-07-02, task [#1726](https://example.com/builders#/task/1726)) reopened planks 1 and 2. The owner's position, stated directly:

- **Cloud Bongos is the real product** — the thing of durable value — and should live as a clean standalone artifact, with Example as *one consumer of it*, not its host.
- **The coupling actively hurts.** One repo carrying both the game and the platform, with a convoluted shared history, is hard to reason about and hand off.
- **The boundary stays theoretical while Example is coupled.** OTB specifics keep leaking into the "portable" core. Evidence: a walk of the ~105 accumulated memory-file learnings on 2026-07-02 found **~85% are platform knowledge wearing OTB-specific framing** (example.com links, the droplet, `drachmae`) — the substance is core, the *wording* is coupled. Only 7 items are genuinely instance-bound.
- **Mercury is imminent** — the separation should be proven on something that matters to the business now.

"Leave Example coupled until later" reads, under these priorities, as "never." The precondition ADR 0100 waited for — a mechanical, CI-enforced boundary — already holds (ADR 0093 core-carve, the module system, `isPublishable()`), so the more ambitious cut is now buildable rather than a leap.

## Decision

### 1. Core-first extraction — the core gets its own repo, first.

The Cloud Bongos **core** — the `isPublishable()` subtree ([ADR 0098](<redacted>.md)): portable methodology + platform + GDS engine + neutral branding — is extracted into its **own standalone repository** with **fresh history**, AGPL/public-ready. That repo **is** Cloud Bongos, the product. This is the *first* physical move, ahead of standing up any consumer. R84's `bongos package-core` is reused, not discarded: the subtree it already packages is exactly what gets extracted.

### 2. Example splits — it is not the permanently-coupled reference instance.

Example becomes a **consumer repo** that installs a pinned core version and layers its own game content, branding, and modules on top — the same shape as any other instance. It is **sequenced after** the core extraction and, for live-prod-risk reasons, after greenfield Mercury has proven the consumer path. This reverses ADR 0100 §2's open-ended deferral into a committed, sequenced step. The single-checkout reskin (cloudbongos.com) stays a supported cheap-reskin shape.

### 3. Retained from ADR 0100: per-repo GDS (§3) and the conditional mirror (§4).

Each repo runs its own GDS (own DB, tasks, builders, credits) — a shared GDS is still rejected. The delayed redacted mirror ([ADR 0099](<redacted>.md)) stays the public surface **until** the core is physically extracted — under this ADR that trigger now fires *first*, so the mirror's retirement/repointing is re-evaluated at extraction time rather than after a Mercury detour.

### 4. Reshaped spine.

| Step | Task | Change |
|---|---|---|
| R84 — package the core | [#1688](https://example.com/builders#/task/1688) | shipped; reused as-is |
| **R88 — extract the core into its own repo** | [#1727](https://example.com/builders#/task/1727) | the new first physical move (dep: R84) |
| R85 — Mercury on a pinned core | [#1689](https://example.com/builders#/task/1689) | re-pointed to depend on R88 (extraction), not just R84 |
| R86 — `bongos upgrade` channel | [#1690](https://example.com/builders#/task/1690) | unchanged (dep: R85) |
| **R89 — split Example onto the pinned core** | [#1728](https://example.com/builders#/task/1728) | committed, sequenced (deps: R88 + R85) |

## Alternatives reconsidered (rejected)

- **Keep ADR 0100 as-is (Mercury-first, Example coupled forever).** Rejected — it leaves the core↔instance boundary untested and traps the product inside the game repo, which is the exact pain the owner raised.
- **Split Example *first*.** Rejected — moving a live product before the consumer/upgrade path is proven on greenfield Mercury adds risk for no gain. Core-first + Mercury-proof-first de-risks the prod migration.
- **One repo with a clean internal cut (`core/` vs `instances/`).** Rejected — cheapest, but Cloud Bongos never becomes a separately shippable product and the boundary stays enforced by fitness tests, not a real repo gap.

## Consequences

- **The core repo becomes the canonical public artifact.** ADR 0099's mirror retirement, deferred in ADR 0100 §4 to "physical extraction," is now re-evaluated as part of R88.
- **Two one-time migrations** (Mercury standup, then Example re-base) plus a permanent per-project upgrade step — the recurring cost the single-repo model avoided, now accepted for the product + boundary payoff.
- **A larger operational footprint** (a core repo + per-instance repos, each with its own GDS/CI) — weighed against the $5k budget, mitigated by building incrementally, Mercury-driven.
- **The 2026-07-02 learnings classification** (105 memory files, walked item-by-item with the owner: 85 CORE, 5 SPLIT, 4 INSTANCE, 11 DROP) is the reference for what knowledge travels into the extracted core repo. Companion: [`docs/cloud-bongos-core-learnings-classification.md`](../cloud-bongos-core-learnings-classification.md).
- **The module boundary is now load-bearing across a repo gap sooner** — the ADR 0062 / ADR 0061 fitness functions matter more, not less.

## Execution record — R88 shipped (2026-07-03, task [#1727](https://example.com/builders#/task/1727))

§1 is done. The core was extracted into **[github.com/example-owner/cloud-bongos](https://github.com/example-owner/cloud-bongos)** — **private**, `main`, **AGPL-3.0**, **fresh single-commit history**.

- **What was extracted:** the `isPublishable()` subtree via R84's `scripts/gds/package-core.js` — **989 core files** (of 2203), redacted in-memory through the fail-closed no-leak gate (0 residual leaks). The pin travels in-repo as `.cloudbongos-core.json`: `core_version 1.14.0`, `source_commit 2783a396…`, `tree_sha256 2bf9f8ee9a97…`. R85 ([#1689](https://example.com/builders#/task/1689)) and R89 ([#1728](https://example.com/builders#/task/1728)) can now depend on this pin.
- **Genericized on the way in:** identity surface branded to Cloud Bongos (README, package.json, CLAUDE.md 298→258 lines, GOVERNANCE); instance identity re-pointed to `docs/project-context.template.md` + `config/branding.neutral.json`; `drachmae→credits`, owner-name and Off-the-Boats/ancient-Greece framing removed.
- **§4 mirror re-evaluation (ADR 0099):** the physical-extraction trigger has now fired, and `cloud-bongos` is the **designated canonical public artifact** — but it is **PRIVATE for now**. So the ADR 0099 generated mirror is **NOT retired yet**; it stays the public surface until the owner flips `cloud-bongos` public, at which point the mirror is retired (or repointed). Retirement is bound to the public-flip, not to this extraction.
- **Deferred to follow-ups (tracked in the GDS):** the exhaustive `Off the Boats`→neutral sweep across the ~32 remaining ADR/test/recipe files; standalone vanilla-boot wiring (`server.js`/entrypoints still reference the reference instance's product layer) — naturally proven by R85/R89; core `package.json` dependency pruning (game deps carried in); dangling in-repo links to topology/instance paths the scaffold populates on `init`; seeding the CORE-bucketed learnings; and tagging R88/R89 to goal 26 (their `goal_id` is null).
