# ADR 0124 — Typed API response bodies (infer the success shape from `res.json`)

**Date:** 2026-07-05
**Status:** Accepted (follow-up to [ADR 0118](<redacted>.md); goal 36 `api-client-sdk`).
**Context:** [task 2061](https://builders.example.com#/task/2061) (BONGOS-V1), promoted from idea 519. [ADR 0118](<redacted>.md) / task 2050 typed every **request** body field-level from each route's `validate()` schema. Success **responses** stayed the `ApiResponse` (`= any`) alias: routes declare no response schema, so the generator had nothing to type them from — a caller got zero autocomplete or safety on what a call returns.

## Problem

The generated client (`clients/bongos-client`) is the one true way to call the API (goal 36). Its request bodies are typed, but every method returned `Promise<any>` (aliased `ApiResponse`). So `const { task } = await api.tasks.getTasks()` had no idea `task` was wrong (the field is `tasks`), and a paginated call's `page` block was untyped. The "typed client" was only half typed.

## Decision

**Infer the success shape statically from each route's inline `res.json({ … })` object literal** — do not add a parallel per-route response-schema declaration.

- `gen-api-docs.js` scans a route's handler window for success (`2xx`) `res.json(…)` / `res.status(2xx).json(…)` calls (reusing the `captureBalanced` / `splitTopLevel` / `splitKeyValue` machinery the request extractor already uses — it **never executes** a route). The top-level keys of the object literal become a `<OperationId>Response` component in `components.schemas`, attached to the `200` response's `content`.
- **Only keys are provable.** A property's value is usually a variable, so it types as `unknown` — the *shape* (which keys exist) is the win. Two values type with confidence: a **boolean literal** (`ok: true`), and the ADR-0119 `pageMeta(…)` `page` block → a shared **`PageInfo`** component.
- `gen-api-client.js` types the method return as `Promise<<OperationId>Response>`; the component renders as a TS interface automatically (same path as request schemas). A route with no provable shape keeps `Promise<ApiResponse>`.

**Degrade-gracefully contract — never emit a shape we cannot prove.** A route whose success body is a **bare value** (`res.json(row)`), contains a **top-level spread** (`{ …rest }`), an **empty** `{}`, or a **computed/quoted key** keeps the `ApiResponse` alias. We only ever *narrow* `any`; we never assert a wrong or partial-looking-complete shape. Branches within one handler are merged: a key present in every branch is required, others optional; a value schema is kept only where all branches agree.

## Why not a per-route `responseSchema` export (idea 519 option a)

ADR 0118 is **code-first**: the contract is read from what the route already does, not from a second declaration that can drift. The `res.json({ … })` literal *is* the response shape — adding a `responseSchema` export beside it would (a) duplicate that truth, (b) require touching 200+ route files for a one-time win, and (c) reintroduce exactly the drift the generator exists to kill. Reading the literal keeps a single source of truth and covers the whole surface for free.

## Consequences

- **162 of 221 endpoints** now return a concrete `<…>Response` interface; the remaining ~59 (bare values, spreads) safely stay `ApiResponse`. A representative, majority slice of the API is now typed end-to-end.
- **No runtime change.** Only `docs/api/openapi.json` and `clients/bongos-client/index.d.ts` change — the client's runtime JS (`index.mjs/.cjs/.global.js`) is untouched (return types are a `.d.ts`-only concern), so the devbox-vendored CJS stays byte-identical.
- Correctness is bounded: a value typed `unknown` forces a cast at the call site (honest — we don't know it); a missing route type is `any` (no worse than before). The generator can never over-claim a shape.
- Enforced by both generators' `--check` gate + `tests/api_docs.mjs` (the pure extractors + spec facts) and `tests/api_client.mjs` (the emitted `.d.ts`).

## Rejected

- **Per-route `responseSchema` export / `res.json` hint comment** — drift + churn; see above.
- **Executing routes / a running server to observe real responses** — breaks the generator's zero-execution, DB-free, deterministic contract (ADR 0118).
- **Typing every value by tracing the variable** — would need real data-flow analysis; brittle and far past the static line/regex extractor's remit. Keys + the two safe value cases capture the value at a fraction of the risk.
- **`additionalProperties: false` on response components** — omitted; since we degrade on spreads, the inferred shape is trusted, but leaving responses open avoids a false compile error if a handler branch we didn't parse adds a key.
