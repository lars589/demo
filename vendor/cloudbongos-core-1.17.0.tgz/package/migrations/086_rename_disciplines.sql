-- 086_rename_disciplines.sql — task #615 / GDS-V3: rename builder disciplines.
--
-- The original discipline set (migration 014 / 027) was:
--   creative | engineering | unclassified
--
-- "creative" conflated two different kinds of contribution — making visual
-- art assets vs. thinking/writing/scoping. A builder who can scope, research,
-- and write but cannot produce pixel art had no clean home. The new set
-- splits that axis three ways:
--
--   engineer — builds code: routes, scripts, game logic, infra, migrations
--   artist   — produces visual assets: pixel-art tiles, sprites, icons,
--              avatars, the art pipeline itself
--   ideator  — contributes through thinking: idea capture, task scoping,
--              research, docs/briefs, feedback, user observation, naming, lore
--
-- Plus 'unclassified' (task-only) for un-triaged work, unchanged.
--
-- This migration swaps BOTH discipline CHECK constraints and backfills the
-- existing data:
--
--   tasks.discipline (mig 014, enum: creative|engineering|unclassified):
--     engineering                            → engineer
--     creative + art touches (art/, png,     → artist
--       sprite, avatar, public/assets/)
--     creative + docs/ touches               → ideator
--     creative (ambiguous / no touches)      → unclassified  (hand-triage)
--     unclassified                           → unclassified  (unchanged)
--
--   builders.preferred_disciplines (mig 027, enum: creative|engineering):
--     engineering → {engineer}
--     creative    → {artist, ideator}   (inclusive: the builder opted into
--                   non-engineering work, so surface both new lanes; they can
--                   narrow later in /settings)
--
-- Constraints are dropped BEFORE the data updates (so the UPDATEs aren't
-- rejected by the old enum mid-flight) and re-added AFTER, matching the
-- pattern in migration 059. Every UPDATE is a no-op on already-migrated
-- values, so the whole file is idempotent and safe to re-run.
--
-- The discipline column is text (not a native enum) and the two SELECT t.*
-- views (claimable_tasks, tasks_session_fit) project the column by value, so
-- no view rebuild is needed — a value change is invisible to a `SELECT t.*`.

BEGIN;

-- =========================================================================
-- 1. Drop both CHECK constraints so the backfill UPDATEs can run.
-- =========================================================================
ALTER TABLE tasks    DROP CONSTRAINT IF EXISTS tasks_discipline_check;
ALTER TABLE builders DROP CONSTRAINT IF EXISTS builders_preferred_disciplines_check;

-- =========================================================================
-- 2. Backfill tasks.discipline.
-- =========================================================================

-- engineering → engineer
UPDATE tasks SET discipline = 'engineer'
 WHERE discipline = 'engineering';

-- creative + art-production touches → artist (applied first so it wins over
-- the docs rule when a task carries both art and docs paths).
UPDATE tasks SET discipline = 'artist'
 WHERE discipline = 'creative'
   AND touches IS NOT NULL
   AND EXISTS (
     SELECT 1 FROM unnest(touches) AS t
      WHERE t LIKE 'art/%'
         OR t LIKE 'public/assets/%'
         OR t ILIKE '%png%'
         OR t ILIKE '%sprite%'
         OR t ILIKE '%avatar%'
   );

-- creative + docs touches → ideator
UPDATE tasks SET discipline = 'ideator'
 WHERE discipline = 'creative'
   AND touches IS NOT NULL
   AND EXISTS (
     SELECT 1 FROM unnest(touches) AS t
      WHERE t LIKE 'docs/%'
   );

-- remaining creative (ambiguous / no touches) → unclassified for hand-triage
UPDATE tasks SET discipline = 'unclassified'
 WHERE discipline = 'creative';

-- =========================================================================
-- 3. Backfill builders.preferred_disciplines.
--    Map each element through the rename table, flatten, de-dup, re-aggregate.
--    engineering→{engineer}, creative→{artist,ideator}, anything already-new
--    passes through unchanged (idempotent).
-- =========================================================================
UPDATE builders b
   SET preferred_disciplines = COALESCE((
         SELECT array_agg(DISTINCT m.mapped ORDER BY m.mapped)
           FROM unnest(b.preferred_disciplines) AS d
           CROSS JOIN LATERAL (
             SELECT unnest(
               CASE d
                 WHEN 'engineering' THEN ARRAY['engineer']
                 WHEN 'creative'    THEN ARRAY['artist', 'ideator']
                 ELSE ARRAY[d]
               END
             ) AS mapped
           ) AS m
       ), '{}')
 WHERE preferred_disciplines IS NOT NULL
   AND array_length(preferred_disciplines, 1) > 0;

-- =========================================================================
-- 4. Re-add both CHECK constraints with the new enum.
-- =========================================================================
ALTER TABLE tasks ADD CONSTRAINT tasks_discipline_check
  CHECK (discipline IN ('engineer', 'artist', 'ideator', 'unclassified'));

-- preferred_disciplines never carries 'unclassified' (that's a task state,
-- not an interest area), mirroring migration 027's narrower set.
ALTER TABLE builders ADD CONSTRAINT builders_preferred_disciplines_check
  CHECK (preferred_disciplines <@ ARRAY['engineer', 'artist', 'ideator']::text[]);

INSERT INTO schema_migrations (version) VALUES ('086_rename_disciplines')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
