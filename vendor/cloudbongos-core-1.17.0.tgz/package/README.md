# Example

A persistent, shared 16-bit pixel-art world — the e-commerce experience for [Off the Boats](https://example.com), powered by [Example](https://example.com).

Project memory — architecture, scope, V1 limitations, future ideas, session log — lives in [`CLAUDE.md`](./CLAUDE.md). Read it before editing code.

> **Reading this on GitHub?** [`builders.example.com`](https://builders.example.com) is the canonical place to read project docs — task refs (`#NNN`) render as working links there. GitHub is the code host: great for diffs and PRs, but a bare `#NNN` here links to a GitHub issue and 404s.

## New builder? Start here

### Before you start (prerequisites)

You'll need three things on your machine first:

- **Git** — the tool that copies the code down. Check with `git --version`; install from [git-scm.com](https://git-scm.com/downloads) if it's missing.
- **Claude Code** — your pair-programmer for every session. Download the desktop app at [claude.com/download](https://claude.com/download) (Mac and Windows).
- **A GitHub account with access to this repo** — the project is private, so an Archon must invite you first. Accept the emailed invitation before cloning. (The bootstrap script below also checks for Node ≥ 22 and Python ≥ 3.10, and prints the install command if either is missing — you don't need them installed *before* cloning.)

### Step 0 — get the project onto your machine

Clone the repo, then `cd` into it. Everything below runs from inside that folder:

```sh
git clone https://github.com/example-owner/example.git
cd example
```

### Step 1 — bootstrap

One command bootstraps a fresh clone end-to-end — toolchain checks, JS deps, local env file, and a GDS session via GitHub:

```sh
# macOS / Linux:
./scripts/setup-builder.sh
# Windows — or any OS (node is the one guaranteed runtime):
node scripts/setup-builder.js
```

It checks Node ≥ 22 and Python ≥ 3.10 (prints the install command if either is missing), runs `npm ci`, copies `.env.local.example` to `.env.local` (optionally prompting for your Google AI Studio key — pass `--skip-keys` to leave it blank), and hands off to `node scripts/gds/setup.js` to authenticate against the GDS via the GitHub Device Flow. The script is idempotent: re-running on an already-set-up checkout reports "already done" rather than clobbering.

When it finishes, open Claude Code and run `/builder-start` to see what tasks are claimable.

## Secrets scanning

We keep secrets (`.env` files, API keys, private keys) out of the repo with two layers:

- **Pre-commit hook** ([`.husky/pre-commit`](./.husky/pre-commit)) — scans your *staged* changes before each commit and aborts if it finds a secret. Activate it **once per clone**:

  ```sh
  git config core.hooksPath .husky
  ```

  It always runs a built-in guard (blocks `.env`, `*.pem`, credential files, obvious key patterns). If [TruffleHog](https://github.com/trufflesecurity/trufflehog) is installed (`brew install trufflehog` on macOS; `scoop install trufflehog` / `choco install trufflehog` or the GitHub release on Windows) it also runs a deep scan; if not, it warns and lets the commit through — CI is the real gate.

  > **Windows:** git runs the `.husky/pre-commit` hook through the Git-Bash `sh` bundled with Git for Windows, so the hook works if you installed Git for Windows (the usual case). If you don't have a `sh` available, the local hook silently no-ops — CI's full-history TruffleHog scan is then your only gate (and it always runs regardless of platform).

- **CI scan** ([`.github/workflows/secrets-scan.yml`](./.github/workflows/secrets-scan.yml)) — every PR to `main` runs TruffleHog over the **full git history**. This must pass before merge.

### If a commit is blocked, here's how to investigate

1. **Read the output.** The hook prints the offending file(s) and why.
2. **Is it a real secret?** Then it must never be committed. Remove it from the commit (`git restore --staged <file>`), move the value out of the repo — local secrets go in `.env.local` (gitignored; run `/builder-setup`), production secrets live on the droplet at `/etc/example/`. If it was *already committed in an earlier commit*, the history scan will keep failing until the history is scrubbed — flag this to Lars, since rewriting shared history needs care.
3. **Is it a false positive?** (e.g. an example key in docs, a test fixture, a Stripe `pk_test_` publishable key.) Add a path regex — one per line — to [`.husky/secrets-allowlist.txt`](./.husky/secrets-allowlist.txt). Both the hook and CI read that allowlist. Keep entries narrow and only add them after confirming the match is genuinely not a secret.
4. **Genuine emergency commit** (you're sure it's clean and need to move now): `git commit --no-verify` skips the local hook — but CI will still scan the PR, so this only defers the check, it doesn't bypass it.

## If your CLI starts 401'ing

GDS CLI calls (`node scripts/gds/start.js`, `claim.js`, `ship.js`, etc.) authenticate against `example.com` using a session token at `~/.config/otb/gds-session.json`. Migration 035 (V3.R38 / [#259](https://example.com/builders#/task/259)) put a 1-hour rolling TTL on every session — every authenticated request resets it, so an active session never silently expires. But after a long idle, a token revocation, or an auth-changing deploy (e.g. mig 035 itself when it landed), the local token can stop working.

`apiCall` in `scripts/gds/cli-lib.js` detects HTTP 401 and exits with a clear recovery message rather than letting the failure cascade through downstream calls. When you see that message:

1. **Re-auth via Device Flow:**

   ```sh
   node scripts/gds/setup.js --force
   ```

   This pre-flights `GET /api/gds/me` against your existing session before doing anything. If the token is valid, it tells you who you're authenticated as and exits. If the token is dead (401), it falls through to the Device Flow *automatically* — no second `--force` needed. Browser opens to `github.com/login/device`; paste the printed code, authorize as the right GitHub account, you're back.

2. **If something feels off and you're not sure what,** run the doctor:

   ```sh
   node scripts/gds/doctor.js
   ```

   It checks session validity (`/me` returns 200, identity + rank), git plumbing (`core.hooksPath` resolves), repo state (on a branch, working-tree status), and environment files (`.env.local`, `~/.config/otb/env`). Green/red checklist, no arguments. Exits 0 if every check passes, 1 if any red.

Mirrors the "if a commit is blocked" pattern above: actionable, single command, no guessing.
