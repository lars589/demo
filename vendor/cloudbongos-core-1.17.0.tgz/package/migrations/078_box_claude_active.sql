-- migration 078: box claude_active flag + deprovision intent action
--
-- Two changes:
--   1. builder_boxes.claude_active — the box-side heartbeat reports whether a
--      `claude` process is running. The idle sweep skips boxes where this is
--      true, so a running Claude session keeps the box alive indefinitely.
--      Resets to false on deprovision (setBoxState clears it).
--
--   2. box_intents.action CHECK extended to include 'deprovision' — the new
--      POST /box/close route enqueues this, and the intent runner calls
--      cmdDeprovision. Keeps the DO token on the control plane (trust boundary
--      holds); the web tier only ever records a request.

ALTER TABLE builder_boxes
  ADD COLUMN IF NOT EXISTS claude_active bool NOT NULL DEFAULT false;

ALTER TABLE box_intents
  DROP CONSTRAINT IF EXISTS box_intents_action_check;

ALTER TABLE box_intents
  ADD CONSTRAINT box_intents_action_check
    CHECK (action IN ('provision', 'wake', 'deprovision'));
