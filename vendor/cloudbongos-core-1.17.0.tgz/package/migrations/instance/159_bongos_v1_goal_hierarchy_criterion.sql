-- BONGOS-V1 — goal-scoped-work-hierarchy done-when criterion (C6) — 2026-06-24
-- Owner-directed (archon), task 1507 / ADR 0086 (docs/adr/0086-goal-scoped-work-hierarchy.md).
--
-- Adds a 6th done_when_criterion to BONGOS-V1: the goal-scoped work hierarchy —
-- assign module-scoped GOALS, not individual tasks, and let a goal's members
-- author their own tasks within the goal's module wall, enforced server-side.
-- A criterion cluster ALONGSIDE the ADR 0083 module work (C5). The build tasks
-- (BV1.R54..R66, the ADR's Phases 1-4 + a deferred Phase-5 ADR spike + the live
-- proof) are seeded AFTER this is applied via
-- scripts/gds/seed-bongos-goal-hierarchy-tasks.js, so the positional ref C6
-- resolves at task-create (same migration+seed split as 144 + the module seed).
--
-- Idempotent on re-run: UPSERT on (version_id, criterion_id). Migrations 120/144
-- already seeded C1..C5 (sort_order 1..5); this adds sort_order 6.

BEGIN;

INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, sort_order)
SELECT * FROM (VALUES
  ('BONGOS-V1', 'goal-scoped-work-hierarchy',
   '**Builders are assigned module-scoped goals, not individual tasks — and can author their own work within a goal''s wall, enforced server-side.** The owner stops hand-authoring every task; a builder joins a shared, module-scoped goal and gains bounded authority to create + organize tasks beneath it, never exceeding the goal''s module scope or touching the protected core. The six-tier hierarchy (Project → Version → Goal → Criteria → Task → Sub-task) is a per-instance config preset; enforcement is core (ADR 0086, building on ADR 0016/0043/0049/0083/0084). Done when: (1) a module-scope map (`module-scope-map.js`, importing `PROTECTED_GLOBS`) + a configurable hierarchy preset (`config/hierarchy.json` + `hierarchy-config.js`, onboarding-edited) exist; (2) a `goals` tier (shared, joinable, `scope_modules`) sits between versions and criteria, `done_when_criteria` re-parent under goals (backfilled under a per-version default goal), and `tasks` carry `goal_id`, with the `/status` rollup running Version → Goals → Criteria → Tasks; (3) a goal member can author a task via `POST /goals/:id/tasks` only if it is scope-subset + clears the protected-path gate + the auto-derived rank floor, with two fitness checks (goal routes pinned in `route-rank-check`; scope code imports `PROTECTED_GLOBS`) and an abuse-matrix test proving the wall holds; (4) a polymorphic dependency edge spans tasks/goals/criteria and resolves at the existing claim gate, a criterion auto-flags "met — pending review" when its tasks ship, a `/goal-review` cadence (Metic+) confirms → auto-achieves goals, and goals archive/reopen/carry-forward at rescope; and (5) a sub-Metic builder demonstrably authors, claims, and ships a task inside an assigned goal while being BLOCKED server-side from authoring one that touches a protected path outside scope (the live proof). Phase 5 of the ADR (an AI relevance judge + sub-Metic membership inside protected-scope goals) is deferred to its own security-reviewed ADR.',
   6)
) AS v(version_id, criterion_id, criterion_md, sort_order)
WHERE EXISTS (SELECT 1 FROM versions WHERE id = 'BONGOS-V1')
ON CONFLICT (version_id, criterion_id) DO UPDATE
  SET criterion_md = EXCLUDED.criterion_md,
      sort_order   = EXCLUDED.sort_order;

COMMIT;
