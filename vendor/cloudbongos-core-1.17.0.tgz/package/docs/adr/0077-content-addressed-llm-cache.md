# ADR 0077 — Content-addressed LLM cache

**Status:** Accepted (2026-06-20) · tasks [#1358](https://example.com/builders#/task/1358) [#1359](https://example.com/builders#/task/1359) [#1360](https://example.com/builders#/task/1360) · System 5 of the Cloud Bongos LLM-reduction redesign (spike [#1326](https://example.com/builders#/task/1326)) · reports savings into [ADR 0075](<redacted>.md); reuses the content-hash convention of [ADR 0060](0060-gds-retrieval-layer.md)

## Context

Several GDS-internal model calls are **idempotent**: they re-process inputs that haven't changed. The nightly `architect-audit` re-audits a `main` that is often unchanged since the last run; `onboarding-analyze` re-runs over **immutable** session transcripts. Each is a full Opus call billed in full every time, for an answer byte-identical to one already produced. This is the residual after Systems 3 (autonomy gate) and 4 (deterministic-first cron) — the lowest-magnitude lever (est 2–5%), and the safety net that catches what slips through them.

Every GDS-internal model call already funnels through **one** spawn primitive — `grader.runSubagent` — which makes a single wrap point the whole surface.

## Decision

Memoize idempotent model runs at `runSubagent`, keyed on the **content** of the request, with validity bound to the **git SHA of the inputs**.

- **Cache key** = `sha256(normalized-prompt | model | task_type | scope_sha)` (`src/bongos/llm-cache.js`, table `llm_cache`, migration 125). `scope_sha` is the git tree/blob SHA of the embedded inputs (`git rev-parse HEAD:<path>`), so **a stale answer is only ever returned when the inputs are provably unchanged** — the moment the tree changes, the key changes and the cache misses. This is the correctness backbone.
- **The normalizer registry is the other correctness surface.** A per-`task_type` normalizer strips only **provably-volatile** lines (timestamps, run-ids, the architect's `version=` echo) so two logically-identical prompts hash the same — *without* ever collapsing two genuinely-different requests. Adding a task type means adding a normalizer; that is where a reviewer looks to verify a cache can't return a wrong answer.
- **Store only on a clean run.** A result is cached only when `exit_code === 0` and stdout is present — **never a timeout or a non-zero exit**. A cache must never pin a failure.
- **The wrap is opt-in and behavior-preserving.** `grader.runSubagentCached({prompt, opts, cache})` checks the cache then falls through to the **untouched** `runSubagent`; with no `cache` spec it is exactly today's call. A hit returns `{stdout, cost_usd: 0, cached: true}`, so the $0 flows automatically through the existing `extractCostUsd → session-cost` ledger, and the saving is recorded into `cost_baseline` (`system5:llm-cache`, [ADR 0075](<redacted>.md)) — `baseline_usd` = what the run *would* have cost, `amount_usd` = 0 — so the system proves its savings in dollars.
- **First plug-ins (highest rerun value):** `architect-audit` (key scoped to the git tree-hash of `--paths`) and `onboarding-analyze` (key on the immutable session id). Both are best-effort: any `llm_cache` error degrades to an ordinary uncached run — the cache can never take down the thing it accelerates.
- **v1 is exact-match.** Semantic / near-match caching is deferred; a v1 key either matches exactly (after normalization) or misses. That keeps correctness obvious.

## Consequences

- An unchanged-`main` `architect-audit` re-run, or a re-`onboarding-analyze` of a session, returns at **zero new tokens**, with `hit_count` incremented and the saving in `cost_baseline`.
- Because validity is git-SHA-scoped, the cache is **self-invalidating** — no manual purges; a real code change always re-runs.
- The blast radius of a wrong normalizer is bounded to its one `task_type`; the default normalizer only trims.
- **Runtime verification is deferred to a deployed run.** These caches sit on Opus subagent calls that this overnight build does not execute (and `architect-audit.js` is independently known to mis-parse its Opus output — a pre-existing defect, see the efficiency audit's meta-note). The pure key/normalizer/scope-sha logic is unit-tested DB-free; the lookup/store/hit-count/$0 path is verified on first real post-deploy run.

## Reproduce / verify

- Pure tests (DB-free): `tests/llm-cache.mjs` (sha256, normalizers, key composition, scope-sha invalidation).
- Post-deploy: run `architect-audit --paths <p>` twice over an unchanged tree → the 2nd logs `cost_usd=0`, `cached:true`, `llm_cache.hit_count` increments, and a `cost_baseline` `system5:llm-cache` row appears.
