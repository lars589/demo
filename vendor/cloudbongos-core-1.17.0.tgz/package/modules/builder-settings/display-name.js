'use strict';

// modules/builder-settings/display-name.js — the pure validator for a builder's
// self-edited DISPLAY NAME (task 1669).
//
// Today builders.display_name is seeded once from the GitHub display name at
// account creation, with no way to change it. The GET/PATCH /me/display-name
// routes (routes/settings.js) let a builder rename the label shown next to their
// work in the hall (header, leaderboard, work feed — all already read
// display_name, so a DB update propagates). This file is the SSOT for the rules:
// what a valid new name is, mirroring the pref-lib pattern (validatePatch +
// constants) so the route stays a thin shell.
//
// Scope: own name only — the route is api.requireBuilder and writes the
// AUTHENTICATED builder's row. Identity stays github_login/id; the display name
// is a free label, so UNIQUENESS IS NOT REQUIRED (names may collide).
//
// Storage: the `display_name` column on `builders` is `text NOT NULL`
// (migration 003), so there is no DB-level length ceiling — we enforce a
// sensible one here so the hall doesn't have to render an arbitrarily long
// string. 60 chars comfortably holds any real name (GitHub display names cap at
// 255 but real ones are short; 60 keeps the leaderboard / work-feed rows tidy).

// The longest display name we accept, in Unicode code points (so a multi-byte
// character counts as one, matching how a human reads the limit).
const MAX_LENGTH = 60;
const MIN_LENGTH = 1; // after trimming — empty / whitespace-only is rejected

// Count code points, not UTF-16 units, so an emoji or astral character is "1".
function codePointLength(str) {
  return Array.from(str).length;
}

// Control characters are rejected: C0 (0x00–0x1F), DEL (0x7F), and the C1 block
// (0x80–0x9F). These include tabs, newlines, and other invisibles that would
// break the single-line label everywhere display_name renders. A normal space
// inside the name is fine (it's not a control char); leading/trailing space is
// stripped by the trim below.
function hasControlChar(str) {
  for (const ch of str) {
    const cp = ch.codePointAt(0);
    if (cp <= 0x1f || cp === 0x7f || (cp >= 0x80 && cp <= 0x9f)) return true;
  }
  return false;
}

// Validate a candidate display name. Returns { ok:true, value } with the trimmed
// name on success, or { ok:false, errors:[{ error, ... }] } on failure. Pure: no
// DB, no IO — the route calls this, then writes `value` verbatim.
//
//   - not a string                       → 'must_be_string'
//   - empty / whitespace-only (post-trim)→ 'empty'
//   - longer than MAX_LENGTH (post-trim) → 'too_long'  (carries max + length)
//   - contains a control character       → 'control_char'
function validate(name) {
  if (typeof name !== 'string') {
    return { ok: false, errors: [{ error: 'must_be_string' }] };
  }
  const trimmed = name.trim();
  if (trimmed.length === 0) {
    return { ok: false, errors: [{ error: 'empty', message: 'Display name cannot be blank.' }] };
  }
  // Check control chars on the trimmed value — leading/trailing whitespace was
  // already removed; an interior control char (tab, newline) is what we forbid.
  if (hasControlChar(trimmed)) {
    return { ok: false, errors: [{ error: 'control_char', message: 'Display name cannot contain control characters.' }] };
  }
  const length = codePointLength(trimmed);
  if (length > MAX_LENGTH) {
    return {
      ok: false,
      errors: [{ error: 'too_long', message: `Display name must be ${MAX_LENGTH} characters or fewer.`, max: MAX_LENGTH, length }],
    };
  }
  return { ok: true, value: trimmed };
}

module.exports = {
  MAX_LENGTH,
  MIN_LENGTH,
  codePointLength,
  hasControlChar,
  validate,
};
