// roadmap.js — the Roadmap page (task 1757, owner request from the task-1723
// review): every declared version's progress, with its goals nested
// underneath (status, criteria, inline join/leave). Carved out of the Work
// Board's "Versions, by progress" section (work.js) so the board stays about
// claimable work and this page owns the bigger picture. Server gate is
// SIGNEDIN_BUILDERS_PAGE_RE in serve-internal.js.
//
// Reads: GET /me (viewer id + rank — rank gates the task-1760 drag handle so
// only an Archon sees it, though the server is the real enforcement), GET
// /public/progress (version lifecycle rollup — public, never gated), GET
// /goals?version=X + GET /goals/:id (per-version goals + members/criteria).
// Writes: POST /goals/:id/join | /leave, POST /goals/reorder (Archon-only,
// task 1760 — persists a version's goal priority order via drag-to-reorder).
(() => {
  'use strict';

  const API = '/api/bongos';
  // Generated typed client (task 1996 / R09), served as window.BongosClient by
  // /lib/bongos-client.js. baseUrl:'' passes the full same-origin paths this file
  // builds through unchanged; result-mode ({ status, ok, data }) preserves control flow 1:1.
  const api = window.BongosClient.createClient({ baseUrl: '', credentials: 'same-origin', throwOnError: false });
  const { escapeHtml, $, fmtNum } = window.OTB;
  const toast = (msg) => window.OTB.toast(msg, { duration: 2200, clear: true });

  const viewer = { id: null, isArchon: false };

  async function getJSON(path) {
    const res = await api.request('GET', path);
    if (res.status === 401) {
      window.location.assign(`${API}/auth/web/start?return=${encodeURIComponent(window.location.pathname)}`);
      throw new Error('redirecting to auth');
    }
    const data = res.data || {};
    if (!res.ok) { const e = new Error(`${path} → ${res.status}`); e.status = res.status; e.data = data; throw e; }
    return data;
  }
  async function postJSON(path, body) {
    const res = await api.request('POST', path, { body: body || {} });
    if (res.status === 401) { window.location.assign(`${API}/auth/web/start`); throw new Error('redirecting to auth'); }
    const data = res.data || {};
    if (!res.ok) { const e = new Error(`${path} → ${res.status}`); e.status = res.status; e.data = data; throw e; }
    return data;
  }

  // ---- version + goal rendering (moved from work.js, task 1757) ------------

  function goalBadge(status) {
    const cls = status === 'achieved' ? 'goal-badge--achieved'
      : (status === 'archived' ? 'goal-badge--archived' : 'goal-badge--open');
    return `<span class="goal-badge ${cls}">${escapeHtml(status)}</span>`;
  }

  function critListHtml(criteria) {
    return `<ul class="vbar__crit-list">${criteria.map((c) => {
      const { label, detail } = window.OTB.splitCriterion(c.criterion_md || '');
      const text = detail
        ? `<details class="vbar__crit-d"><summary class="vbar__crit-text">${escapeHtml(label)}</summary><div class="vbar__crit-full">${escapeHtml(detail)}</div></details>`
        : `<span class="vbar__crit-text">${escapeHtml(label)}</span>`;
      return `<li class="vbar__crit${c.satisfied ? ' vbar__crit--done' : ''}"><span class="vbar__crit-mark" aria-hidden="true">${c.satisfied ? '✓' : '○'}</span>${text}</li>`;
    }).join('')}</ul>`;
  }

  // One goal under a version: expandable to its criteria, with inline Join/Leave.
  // d = { goal, members, criteria }. `priority` is this goal's 1-based rank
  // within its version's list (the server's sort_order order, task 1760).
  function goalItemHtml(d, priority) {
    const g = d.goal;
    const crit = Array.isArray(d.criteria) ? d.criteria : [];
    const sat = crit.filter((c) => c.satisfied).length;
    const achieved = g.status === 'achieved';
    const joined = (d.members || []).some((m) => String(m.builder_id) === String(viewer.id));
    // task 1761: an open goal blocked by a not-yet-achieved prerequisite goal is
    // greyed + flagged (the tooltip names the goals it waits on).
    const unmetDeps = (Array.isArray(d.dependencies) ? d.dependencies : []).filter((dep) => !dep.satisfied);
    const blocked = g.status === 'open' && unmetDeps.length > 0;
    const blockedBadge = blocked
      ? `<span class="goal-badge goal-badge--blocked" title="Blocked until achieved: ${escapeHtml(unmetDeps.map((u) => u.title || ('goal ' + u.id)).join(', '))}">🔒 blocked</span>`
      : '';
    // Expanded by default when mid-flight (some but not all criteria met).
    const expanded = crit.length && sat > 0 && sat < crit.length;
    const critBlock = crit.length ? critListHtml(crit) : '<p class="vgoal__nocrit">No criteria yet.</p>';
    const action = joined
      ? `<button type="button" class="vgoal-action vgoal-leave" data-act="leave" data-id="${escapeHtml(String(g.id))}">Leave</button>`
      : (g.status === 'open'
        ? `<button type="button" class="vgoal-action vgoal-join" data-act="join" data-id="${escapeHtml(String(g.id))}">Join</button>`
        : '');
    // Priority is always visible ("sees order"); the drag handle is Archon-only
    // ("can't change it" for everyone else) — the server-side rank gate on
    // POST /goals/reorder is the real enforcement, this is just the affordance.
    const handle = viewer.isArchon
      ? `<span class="vgoal__handle" draggable="true" title="Drag to reprioritize within ${escapeHtml(g.version_id || 'this version')}" aria-hidden="true">⠿</span>`
      : '';
    // A custom disclosure (not <details>/<summary>): the criteria toggle is its own
    // button and Join/Leave is a plain sibling button — so neither click target is
    // nested in a <summary>, where the native details-toggle makes buttons flaky.
    return `
      <div class="vgoal${achieved ? ' vgoal--achieved' : ''}${blocked ? ' vgoal--blocked' : ''}" data-goal-id="${escapeHtml(String(g.id))}" data-version-id="${escapeHtml(String(g.version_id || ''))}"${viewer.isArchon ? ' draggable="true"' : ''}>
        <div class="vgoal__head">
          ${handle}
          <span class="vgoal__priority" title="Priority within this version">${priority}</span>
          <button type="button" class="vgoal__toggle" aria-expanded="${expanded ? 'true' : 'false'}">
            <span class="vgoal__caret${expanded ? ' vgoal__caret--open' : ''}" aria-hidden="true">▸</span>
          </button>
          <a class="vgoal__title vgoal__title--link" href="/goals#/goal/${escapeHtml(String(g.id))}" title="Open goal #${escapeHtml(String(g.id))} detail">${escapeHtml(g.title || 'Untitled goal')}</a>
          ${goalBadge(g.status)}
          ${blockedBadge}
          <span class="vgoal__prog">${sat}/${crit.length}</span>
          ${action}
        </div>
        <div class="vgoal__body"${expanded ? '' : ' hidden'}>
          <span class="vgoal__err" data-err="${escapeHtml(String(g.id))}" hidden></span>
          ${critBlock}
        </div>
      </div>`;
  }

  function renderGoals(details, desc) {
    const goals = Array.isArray(details) ? details : [];
    const description = (desc || '').trim();
    if (!goals.length && !description) return '';
    const achieved = goals.filter((d) => d.goal.status === 'achieved').length;
    const summary = goals.length ? `${achieved} of ${goals.length} goals achieved` : 'The work, in brief';
    const descBlock = description ? `<p class="vbar__desc">${escapeHtml(description)}</p>` : '';
    const list = goals.length ? `<div class="vgoal-list">${goals.map((d, i) => goalItemHtml(d, i + 1)).join('')}</div>` : '';
    // Auto-open when mid-flight (some but not all goals achieved).
    const open = goals.length && achieved > 0 && achieved < goals.length ? ' open' : '';
    return `
      <details class="vbar__criteria"${open}>
        <summary>${summary}</summary>
        <div class="vbar__details-body">${descBlock}${list}</div>
      </details>`;
  }

  // One version's progress card. Pulled out so the same markup serves both the
  // live, in-flight versions (rendered inline) and the shipped ones (folded away
  // below). `done=true` adds the "shipped" badge and a softened look.
  function versionBarHtml(v, goalsByVersion, done) {
    const total = Number(v.total_count) || 0;
    const cShipped = Number(v.lifecycle_shipped_count) || 0;
    const cConfirmed = Number(v.lifecycle_confirmed_count) || 0;
    const cCompleted = Number(v.lifecycle_completed_count) || 0;
    const pctOf = (n) => (total > 0 ? (n / total) * 100 : 0);
    const pct = Number(v.percent_complete) || 0;
    const tail = (cConfirmed + cCompleted > 0)
      ? `  ·  ${cShipped} shipped, ${cConfirmed} confirmed, ${cCompleted} completed`
      : '';
    const detailsBlock = renderGoals(goalsByVersion.get(v.version_id), v.done_when);
    const badge = done
      ? ' <span class="vbar__done-badge" title="shipped — no work remains">shipped</span>'
      : '';
    return `
      <div class="vbar${done ? ' vbar--done' : ''}">
        <div class="vbar__top">
          <span class="vbar__name">${escapeHtml(v.version_id)} · ${escapeHtml(v.name || '')}${badge}
          </span>
          <span class="vbar__count">${fmtNum(v.shipped_count)} of ${fmtNum(v.total_count)} shipped</span>
        </div>
        <div class="vbar__bar">
          <div class="vbar__seg vbar__seg--shipped"   style="width:${pctOf(cShipped)}%"   title="${cShipped} shipped (live)"></div>
          <div class="vbar__seg vbar__seg--confirmed" style="width:${pctOf(cConfirmed)}%" title="${cConfirmed} confirmed (awaiting merge)"></div>
          <div class="vbar__seg vbar__seg--completed" style="width:${pctOf(cCompleted)}%" title="${cCompleted} completed (awaiting verification)"></div>
        </div>
        <div class="vbar__pct">${pct}% complete · weighted by priority${tail}</div>
        ${detailsBlock}
      </div>
    `;
  }

  function renderVersionBars(progress, goalsByVersion) {
    const root = $('#roadmap-versions');
    if (!root) return;
    const rows = Array.isArray(progress) ? progress : [];
    const gbv = goalsByVersion instanceof Map ? goalsByVersion : new Map();
    if (!rows.length) {
      root.innerHTML = `<div class="profile__placeholder">No versions declared yet.</div>`;
      return;
    }
    // A version with status 'shipped' is history — its bar reads 100% and it
    // only crowds out the live work. Render the open versions inline; fold the
    // finished ones into one collapsed reveal the reader can expand.
    const live = rows.filter((v) => v.status !== 'shipped');
    const done = rows.filter((v) => v.status === 'shipped');

    const liveHtml = live.length
      ? live.map((v) => versionBarHtml(v, gbv, false)).join('')
      : `<div class="profile__placeholder">Every declared version has shipped — nothing is in flight right now.</div>`;

    let doneHtml = '';
    if (done.length) {
      const n = done.length;
      const noun = n === 1 ? 'version' : 'versions';
      doneHtml = `
        <details class="vbar__done-fold">
          <summary>${n} ${noun} already shipped — collapsed to keep the focus on live work. <span class="vbar__done-cta">Show ${n === 1 ? 'it' : 'them'}.</span></summary>
          <div class="vbars vbar__done-body">
            ${done.map((v) => versionBarHtml(v, gbv, true)).join('')}
          </div>
        </details>`;
    }

    root.innerHTML = liveHtml + doneHtml;
  }

  // Fetch a version's goals, each enriched with its members + criteria (so the
  // page can show goals under the version, expand to criteria, and offer join/leave).
  // GET /goals?version lists them; GET /goals/:id carries members + criteria. Returns
  // [] on any failure so a hiccup never blanks the bars.
  async function fetchGoals(versionId) {
    try {
      const list = await getJSON(`${API}/goals?version=${encodeURIComponent(versionId)}`);
      const goals = (list.goals || []).filter((g) => g.status !== 'archived');
      const details = await Promise.all(goals.map((g) =>
        getJSON(`${API}/goals/${encodeURIComponent(g.id)}`).catch(() => null)));
      return details.filter(Boolean);
    } catch (_) {
      return [];
    }
  }

  // Load (or reload) the version progress bars + their goals. Extracted so a
  // join/leave can re-render the section. Public progress read; goals per version.
  async function loadVersionBars() {
    try {
      const prog = await getJSON(`${API}/public/progress`);
      const versions = prog.progress || [];
      const goalsByVersion = new Map();
      await Promise.all(versions.map(async (v) => {
        goalsByVersion.set(v.version_id, await fetchGoals(v.version_id));
      }));
      renderVersionBars(versions, goalsByVersion);
    } catch (err) {
      const root = $('#roadmap-versions');
      if (root) root.innerHTML = `<div class="profile__placeholder">Version progress could not be loaded right now.</div>`;
    }
  }

  // Join or leave a goal, then re-render the version bars so the goal moves
  // between "joined" (Leave) and joinable (Join). Errors surface inline.
  async function doGoalMembership(goalId, act, btn) {
    if (btn.disabled) return;
    btn.disabled = true;
    const goalEl = btn.closest('.vgoal');
    const errEl = goalEl ? goalEl.querySelector('.vgoal__err') : null;
    if (errEl) { errEl.hidden = true; errEl.textContent = ''; }
    try {
      await postJSON(`${API}/goals/${encodeURIComponent(goalId)}/${act}`);
      toast(act === 'join' ? 'Joined the goal.' : 'Left the goal.');
      // Re-render just this goal's row in place — join/leave changes only this goal's
      // membership, so repainting (and collapsing) the whole version section would be
      // both wasteful and jarring. Re-fetch the one goal for its fresh member list; the
      // delegated #roadmap-versions handler catches clicks on the replacement button.
      const detail = await getJSON(`${API}/goals/${encodeURIComponent(goalId)}`).catch(() => null);
      if (detail && goalEl) {
        // Join/leave never changes order — carry the row's current priority
        // number over rather than re-deriving it (a single row has no view of
        // its siblings to recompute a rank from).
        const priority = goalEl.querySelector('.vgoal__priority')?.textContent || '';
        goalEl.outerHTML = goalItemHtml(detail, priority);
      } else if (goalEl) {
        // Couldn't refetch — flip the button optimistically so the UI isn't stuck.
        btn.outerHTML = act === 'join'
          ? `<button type="button" class="vgoal-action vgoal-leave" data-act="leave" data-id="${escapeHtml(String(goalId))}">Leave</button>`
          : `<button type="button" class="vgoal-action vgoal-join" data-act="join" data-id="${escapeHtml(String(goalId))}">Join</button>`;
      }
    } catch (err) {
      const code = err && err.data ? err.data.error : null;
      const msg = code === 'archon_approval_required' ? 'This goal needs an Archon\'s approval to join.'
        : code === 'goal_not_open' ? 'This goal is no longer open to join.'
        : code === 'not_a_member' ? 'You are not a member of this goal.'
        : (err && err.data && err.data.message) || `Could not ${act} the goal.`;
      if (errEl) { errEl.textContent = msg; errEl.hidden = false; }
      btn.disabled = false;
    }
  }

  // ---- drag-to-reorder (task 1760, Archon-only) ------------------------------
  // Native HTML5 drag-and-drop, scoped to one version's .vgoal-list (a goal
  // never crosses versions here — dragging never removes it from its list, it
  // only reorders siblings). On drop, persist the WHOLE list's new order via
  // POST /goals/reorder; the server is the real gate (route-rank archon) — this
  // is only reached by viewer.isArchon builders, matching the affordance.
  let dragEl = null;

  function wireDragReorder() {
    const root = $('#roadmap-versions');
    if (!root) return;
    root.addEventListener('dragstart', (e) => {
      const el = e.target.closest('.vgoal');
      if (!el || !viewer.isArchon) return;
      dragEl = el;
      el.classList.add('vgoal--dragging');
      e.dataTransfer.effectAllowed = 'move';
    });
    root.addEventListener('dragover', (e) => {
      if (!dragEl) return;
      const over = e.target.closest('.vgoal');
      const list = dragEl.closest('.vgoal-list');
      if (!over || !list || over === dragEl || !list.contains(over)) return;
      e.preventDefault();
      const rect = over.getBoundingClientRect();
      const after = (e.clientY - rect.top) > rect.height / 2;
      list.insertBefore(dragEl, after ? over.nextSibling : over);
    });
    root.addEventListener('drop', (e) => {
      if (dragEl) e.preventDefault();
    });
    root.addEventListener('dragend', async () => {
      if (!dragEl) return;
      const el = dragEl;
      const list = el.closest('.vgoal-list');
      el.classList.remove('vgoal--dragging');
      dragEl = null;
      if (!list) return;
      const versionId = el.dataset.versionId;
      const rows = [...list.querySelectorAll('.vgoal')];
      rows.forEach((row, i) => {
        const num = row.querySelector('.vgoal__priority');
        if (num) num.textContent = String(i + 1);
      });
      const orderedIds = rows.map((row) => Number(row.dataset.goalId));
      try {
        await postJSON(`${API}/goals/reorder`, { version_id: versionId, ordered_ids: orderedIds });
        toast('Priority order saved.');
      } catch (err) {
        toast((err && err.data && err.data.message) || 'Could not save the new order — reloading.');
        await loadVersionBars();
      }
    });
  }

  // ---- wiring + bootstrap ---------------------------------------------------

  function wireEvents() {
    // A criteria toggle (custom disclosure) and inline join/leave. Plain
    // buttons — no <summary> nesting.
    $('#roadmap-versions')?.addEventListener('click', (e) => {
      const toggle = e.target.closest('.vgoal__toggle');
      if (toggle) {
        const goalEl = toggle.closest('.vgoal');
        const body = goalEl ? goalEl.querySelector('.vgoal__body') : null;
        const nowOpen = toggle.getAttribute('aria-expanded') !== 'true';
        toggle.setAttribute('aria-expanded', String(nowOpen));
        toggle.querySelector('.vgoal__caret')?.classList.toggle('vgoal__caret--open', nowOpen);
        if (body) body.hidden = !nowOpen;
        return;
      }
      const act = e.target.closest('.vgoal-action');
      if (act) doGoalMembership(act.dataset.id, act.dataset.act, act);
    });
    wireDragReorder();
  }

  async function boot() {
    // /me settles the viewer id + rank (so a joined goal shows "Leave" not
    // "Join", and only an Archon sees the drag handle). Best-effort: a stale/
    // expired session still renders the public progress.
    try {
      const me = await getJSON(`${API}/me`).catch(() => null);
      viewer.id = me?.builder?.id ?? null;
      viewer.isArchon = (me?.builder?.rank || '').toLowerCase() === 'archon';
    } catch (_) { /* cosmetic only */ }

    const sub = $('#roadmap-sub');
    if (sub) sub.textContent = 'Every declared version, its progress, and the goals building toward it.';

    await loadVersionBars();
  }

  wireEvents();
  boot().catch((err) => {
    if (err && err.message === 'redirecting to auth') return;
    console.error('[roadmap] load failed:', err);
    toast('The roadmap failed to load. Reload to try again.');
  });
})();
