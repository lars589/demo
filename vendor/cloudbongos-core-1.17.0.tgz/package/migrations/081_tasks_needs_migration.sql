-- migration 081: re-home migration-number allocation onto tasks.needs_migration
--
-- touches[] cleanup [1/8] (task 876, architect audit
-- docs/audits/touches-array-2026-06-09.md, Musk algorithm / deletion-emphasized).
--
-- Until now the ONLY trigger for reserving a migration number at claim time was
-- the literal string 'migrations/' living inside a task's touches[] array
-- (db.js claimTask + batchClaim). That coupled a load-bearing allocation to a
-- free-text path array that drifts as code wanders into unexpected files — the
-- exact friction the audit targets. Replace the string sentinel with an
-- explicit boolean column the allocator keys off instead.
--
-- POST /tasks now sets needs_migration from the same detectsMigration()
-- title/description regex that used to inject 'migrations/'. Backfill every task
-- that still carries the old sentinel so no in-flight migration task loses its
-- reservation trigger across the cutover. (Duplicate migration numbers merge
-- cleanly and are NOT detectable at merge, so this column must land before the
-- touches[] column is ever dropped — see cluster steps [4/8]+.)

ALTER TABLE tasks
  ADD COLUMN IF NOT EXISTS needs_migration boolean NOT NULL DEFAULT false;

-- Backfill from the retiring sentinel: a task that declared 'migrations/' in
-- touches[] is a migration-bearing task.
UPDATE tasks
   SET needs_migration = true
 WHERE needs_migration = false
   AND 'migrations/' = ANY (touches);

-- Counter hygiene: 080_gds_v4_planning_seed.sql shipped without the customary
-- counter bump, so the allocator handed out 080 while 080_*.sql already existed
-- (the live collision that surfaced this task). Re-base the floor above this
-- file so the next reservation can't collide.
UPDATE migration_counter SET next_number = GREATEST(next_number, 82) WHERE id = 1;
