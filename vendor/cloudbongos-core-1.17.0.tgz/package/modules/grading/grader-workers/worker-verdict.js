// src/bongos/grader-workers/worker-verdict.js
//
// Shared computeVerdict boilerplate for the four grader workers (task 1090, C6).
// The error short-circuits, the common parsed-field extraction, and the success
// return assembly are byte-identical across narc / quality / hacker / efficiency
// (only the worker NAME + score field differ). This module owns ONLY that
// surrounding boilerplate — each worker keeps its SCORING and FAIL/CONCERNS
// TRIGGER logic inline, so no per-worker security trigger is ever flattened
// (the audit's explicit warning). Behavior-neutral: the objects produced here
// are identical (same keys, same order, same values) to the inlined copies.

// The { verdict:'fail', scores:{}, confidence:0, ... } shape every error
// short-circuit returns. `issues` defaults to [] (the subprocess_error and
// parse_error paths) and is the parsed issues array on the schema_error path
// (all four workers forward the parsed issues there, not []).
function failResult({ notesMd, error, issues = [] }) {
  return { verdict: 'fail', scores: {}, issues, notes_md: notesMd, confidence: 0, error };
}

// The three identical extractions every worker does after the parse guard:
// confidence (null-tolerant), the bounded issues array, and the subagent notes.
function parseCommon(parsed) {
  const conf = parsed.confidence == null
    ? null
    : Number.isFinite(Number(parsed.confidence)) ? Number(parsed.confidence) : null;
  const issues = Array.isArray(parsed.issues)
    ? parsed.issues.filter((i) => i && typeof i === 'object').slice(0, 50)
    : [];
  const notesFromSubagent = typeof parsed.notes_md === 'string' ? parsed.notes_md : '';
  return { conf, issues, notesFromSubagent };
}

// The success-return assembly: `${notesPrefix}\n${notes}`.trim() + the
// per-worker scores / issues / extra keys + confidence + error:null. `extra`
// carries the worker-specific key (narc ac_checklist, hacker surfaces_checked,
// efficiency expensive_patterns_checked) at the same position (after issues,
// before notes_md) the inlined returns used.
function finalizeVerdict({ verdict, scores, issues, extra = {}, notesPrefix, notesFromSubagent, confidence }) {
  return {
    verdict,
    scores,
    issues,
    ...extra,
    notes_md: `${notesPrefix}\n${notesFromSubagent.trim()}`.trim(),
    confidence,
    error: null,
  };
}

module.exports = { failResult, parseCommon, finalizeVerdict };
