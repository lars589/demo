-- 176_ui_discipline.sql — task 1376 / GDS-V4: add the `ui` discipline.
--
-- The discipline set after migration 086 was:
--   engineer | artist | ideator | unclassified   (tasks.discipline)
--   engineer | artist | ideator                  (builders.preferred_disciplines)
--
-- This adds a fifth interest area: `ui` — UI/interface DESIGN work (Figma,
-- Claude-Design, design systems, layout/wireframes). It splits out of the
-- pixel-art `artist` lane (ADR 0079): producing interface designs is a distinct
-- discipline from producing pixel-art assets, and it routes to its own /design
-- work-mode (scripts/gds/discipline-modes.json) instead of /paint.
--
-- Purely additive — no data backfill. Existing rows keep their discipline; the
-- only change is that 'ui' is now an accepted value on both CHECK constraints.
-- The task-classifier (modules/lifecycle/task-classifier.js) can now assign it,
-- and POST /tasks accepts it via VALID_DISCIPLINES.
--
-- discipline is a text column (not a native enum) and the claimable_tasks /
-- tasks_session_fit views project it by value, so no view rebuild is needed.
--
-- Constraints are dropped before being re-added with the widened set, matching
-- the pattern in migration 086. Idempotent: safe to re-run.

BEGIN;

-- tasks.discipline — add 'ui' to the accepted set.
ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_discipline_check;
ALTER TABLE tasks ADD CONSTRAINT tasks_discipline_check
  CHECK (discipline IN ('engineer', 'artist', 'ideator', 'ui', 'unclassified'));

-- builders.preferred_disciplines — add 'ui' so a builder can opt into the lane.
-- (Never carries 'unclassified' — that's a task state, not an interest area.)
ALTER TABLE builders DROP CONSTRAINT IF EXISTS builders_preferred_disciplines_check;
ALTER TABLE builders ADD CONSTRAINT builders_preferred_disciplines_check
  CHECK (preferred_disciplines <@ ARRAY['engineer', 'artist', 'ideator', 'ui']::text[]);

INSERT INTO schema_migrations (version) VALUES ('176_ui_discipline')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
