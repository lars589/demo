# ADR 0122 — Onboarding diagram renders: untracked + rendered at deploy from a host-provisioned Chrome

- **Status:** Accepted
- **Date:** 2026-07-05
- **Track:** internal
- **Completes:** [ADR 0110](<redacted>.md) — the diagram half it explicitly **deferred** ("the diagrams need verified headless-Chromium handling"). This ADR records that verified handling and lands the untrack.
- **Builds on:** [ADR 0094](<redacted>.md) (gitignored artifact rebuilt at deploy), [ADR 0063](<redacted>.md) / [ADR 0062](<redacted>.md) §8 (the nav-doc generators ADR 0110 already migrated)
- **Task:** [#2027](https://example.com/builders#/task/2027) (consolidated the duplicate [#1928](https://example.com/builders#/task/1928))

## Context

ADR 0110 moved the whole-file generated **navigation docs** (`docs/repo-map.md`, `docs/session-log-index.md`) off the git graph — gitignored, regenerated server-side at deploy — to kill the multi-builder branch-collision class. It **deferred the onboarding diagrams** (`docs/onboarding/diagrams/*.svg` + `*.png`) for one reason: unlike the pure-Node nav generators, rendering a Mermaid `.mmd` needs a **headless Chromium**, and `mermaid-cli` (via puppeteer) **downloads its own Chromium on first run** — a multi-minute network fetch that stalls/no-ops the $14/mo, 2 GB prod droplet. So the renders stayed tracked and committed on every render-capable ship, and kept colliding on parallel branches (the exact cost ADR 0110 set out to remove).

The blocker was never the untrack — it was proving a **reliable, non-downloading render on the actual deploy host**. That could not be verified from a credential-less dev box (puppeteer's browser download is blocked there too), so the work needed a deploy-host session.

## Decision

Apply the ADR 0110 model to the diagram **renders**, with a host-provisioned browser instead of an on-deploy download:

1. **Provision Chrome once on the host.** Install Google Chrome stable (`google-chrome-stable`, `apt` resolves all shared-lib deps on Ubuntu 24.04) on the prod droplet. It is the single persistent browser the render step reuses — no per-deploy download.
2. **`render-diagrams.sh` prefers an installed browser.** It auto-detects `google-chrome-stable`/`chromium`/… (or honors `PUPPETEER_EXECUTABLE_PATH`), and when it finds one exports `PUPPETEER_SKIP_DOWNLOAD=1` so puppeteer **never** attempts the droplet-stalling fetch. With nothing installed (a dev laptop) it falls back to puppeteer's own download, unchanged. It passes a committed `puppeteer-config.json` carrying `--no-sandbox` (required for headless Chrome as the non-root deploy user on Ubuntu 24.04, whose restricted unprivileged user namespaces break Chrome's own sandbox), and pins `mermaid-cli@11`.
3. **Render at deploy + at box-fetch.** `scripts/deploy/deploy-prod.sh` runs `render-diagrams.sh` (timeout-guarded, **LOUD `::ERROR::` on failure**, best-effort — never fails a deploy) right beside the ADR 0110 nav-doc generators; `infra/box-source-fetch.sh` does the same **guarded on a browser being present** (a box without Chrome skips instantly rather than stalling on a download — a box does not serve the diagrams page).
4. **Untrack only the renders.** `git rm --cached` + `.gitignore` for `docs/onboarding/diagrams/*.svg` + `*.png`. The **`.mmd` sources + `assertions.json` stay tracked** — `git reset --hard` restores them and the render regenerates the images from them.
5. **Ship stops producing/committing renders.** `ship.js`'s diagram regen runs `gen-diagrams.js --no-render` (sources only); the gitignored images never enter its `git add`.

## Why this is safe — and never worse than before

- **No bot commits to `main`; the trust boundary is untouched** (ADR 0016/0043/0055). The renders are written as untracked files on the droplet after `git reset --hard`, exactly like the atlas and the ADR 0110 nav docs.
- **The backstop is unaffected.** The nightly `diagram-drift` cron reads `assertions.json` (still tracked), not the images — so untracking the renders cannot blind it.
- **Verified before landing.** Chrome + `mermaid-cli@11` was confirmed rendering all five `.mmd` (svg + png, incl. the ELK-layout `04-architecture`) on the prod droplet using the installed browser with no download — the verification ADR 0110 required.

## Consequences

- The diagram-render branch-collision class is eliminated at the source; render-capable ships drop a bookkeeping commit.
- **Accepted staleness:** the served images are fresh only *after deploy* (or a box-fetch tick), not at merge — tolerant by nature for a human onboarding page; the LOUD `::ERROR::` is the alarm if a deploy render breaks, and the nightly drift cron is the belt-and-braces.
- **Operational coupling:** the prod droplet must keep Google Chrome installed. `deploy-prod.sh` is the hand-maintained `~/deploy.sh` mirror ([ADR 0042](<redacted>.md)/[0043](<redacted>.md)), so landing this requires an operator to (a) install Chrome (done) and (b) reinstall the updated `deploy.sh`. If Chrome is ever removed, the render step fails LOUD and the drift cron flags staleness — the page keeps its last-deployed images (no `git reset` wipes an untracked file that was just re-rendered) until the next successful deploy.
- **Fresh pristine checkout / core package:** a bare `git clone` that never deploys lacks the images (same accepted trade-off ADR 0110 notes for the nav docs). `docs/onboarding/diagrams/` is not in the core publish allowlist, so nothing changes for packaged core.

## Alternatives considered

- **On-deploy `npx mermaid-cli` with its own Chromium download** — rejected: the multi-minute first-run fetch stalls the 2 GB droplet (the original ADR 0110 deferral reason).
- **Snap `chromium` on Ubuntu 24.04** — rejected: flaky/confined headless behavior on a server; the Chrome `.deb` gives a stable `/usr/bin` path with apt-resolved deps.
- **Keep the renders tracked, strengthen the ADR 0082 conflict resolver only** — rejected for the same reason ADR 0110 rejected it for the nav docs: it hides the collision rather than removing it, and the cost grows with parallelism.
