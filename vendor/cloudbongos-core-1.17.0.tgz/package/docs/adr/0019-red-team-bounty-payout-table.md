# ADR 0019 — Red-team bounty payout table by severity

- **Status:** Accepted
- **Date:** 2026-05-27
- **Deciders:** Lars, autonomous builder (V3.R65 / [#284](https://example.com/builders#/task/284))

## Context

GDS-V3's incentive structure (criterion C9) adds a **red-team bounty**: a builder who finds and reports a security vulnerability against the system earns drachmae for it. The mechanism that *files* a report (`vulnerability_reports`, R63 / [#282](https://example.com/builders#/task/282)) and the mechanism that *auto-confirms and pays* one (R68) both need to agree on a single thing — **how many drachmae a report is worth, given its severity.**

Without one authoritative table, each consumer would invent its own constants and they would drift. We also need the numbers to be **tunable** by an Archon (the only rank that controls economy levers): if the bounty proves too generous or too stingy in practice, adjusting it should be an environment change, not a code edit and redeploy.

Drachmae are the project's in-world currency, stored as integer `delta` in `credit_log` (migrations/003_pms.sql). A bounty payout is therefore a plain integer count of drachmae in the same unit as a task's `credits_reward`. The "10c / 50c" shorthand in the task spec maps to 10 / 50 drachmae; there is no sub-drachma denomination.

## Decision

We will define the bounty payout table in `src/bongos/security.js` as four **default** integer amounts, each overridable by an environment variable:

| Severity | Default drachmae | Env override |
|---|---|---|
| low | 10 | `GDS_BOUNTY_LOW` |
| medium | 50 | `GDS_BOUNTY_MEDIUM` |
| high | 200 | `GDS_BOUNTY_HIGH` |
| critical | 1000 | `GDS_BOUNTY_CRITICAL` |

`security.js` exports `bountyTable()` (the flat `{low,medium,high,critical}` map, env applied) and `bountyTableDetailed()` (ordered rows carrying the default, the live value, and whether it was overridden) so that R68's award logic and the /builders hall both read the same source. The env merge happens once at module load, validated as a non-negative integer with fallback to the default — a typo in the env can never silently zero or negative-pay a bounty.

The table is surfaced read-only on the `/builders` hall under a **"Red-team rewards"** heading, served by a public read endpoint (`GET /api/gds/public/bounty-table`), mirroring how `/public/grades` exposes the grader rubric as a single source of truth.

### Why these tier amounts

The four tiers span two orders of magnitude (10 → 1000), which is the right shape for a bounty: it must be cheap to reward a flood of low-severity nitpicks without draining the treasury, yet pay a genuinely motivating sum for the rare catastrophic find.

- **low = 10** — roughly the floor of a trivial task reward. Enough to acknowledge a real but cosmetic finding (info leak with no exploit path, minor misconfig) without inviting noise-farming.
- **medium = 50** — ~5× low. A real flaw that needs specific conditions; comparable to a small bug-fix task.
- **high = 200** — ~4× medium. Privilege escalation, broad data exposure, auth bypass — work that would have cost us materially if shipped.
- **critical = 1000** — 5× high, 100× low. RCE, full account/rank takeover, treasury drain. Deliberately the single largest payout in the economy so a builder who finds one is unambiguously rewarded above any normal task.

The geometric spacing (≈4–5× per step) matches industry bug-bounty convention (e.g. CVSS-banded payouts) and keeps the ranking legible: each tier is visibly "a different league," not a smooth gradient a reporter would argue over.

## Alternatives considered

- **Hardcoded constants, no env override.** Simplest, but fails the done-when tunability requirement — and the right number is genuinely uncertain until we see real reports, so we want to retune without a deploy.
- **A `bounty_payouts` DB table editable via an API.** More flexible (Archon edits via UI, audit trail). Rejected as over-engineered for V3: there are exactly four numbers and they change rarely; an env var is the cheapest lever that still satisfies "Archon can tune without code." A DB-backed table can supersede this later if retune frequency justifies it.
- **Linear amounts (e.g. 10/20/30/40).** Rejected — the whole point of a severity bounty is to make a critical find pay dramatically more than a cosmetic one; linear spacing under-rewards the finds we most want.

## Consequences

- One module (`src/bongos/security.js`) is the source of truth for bounty amounts. R68's award logic imports `bountyTable()` rather than re-deriving constants — no drift.
- An Archon retunes any tier by setting the env var on the droplet and restarting the process (consistent with every other GDS env knob; takes effect next restart, not live).
- The /builders hall shows the live table — builders always see the current bounty, and an overridden tier is visibly marked so the displayed number is never stale relative to prod config.
- The amounts are a starting point, not gospel. If reports cluster at one tier or the treasury feels the cost, retune via env first; promote to a DB-backed editable table only if env churn becomes a chore.
