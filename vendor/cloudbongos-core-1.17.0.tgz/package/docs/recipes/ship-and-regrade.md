# Recipe: shipping, the grade gate, and re-grading a stuck task

> When a `/builder-ship` fails the subagent quality grader, the task lands at
> `completed` and the claim is gone. This recipe is how you recover — **fix the
> findings and re-grade**, which is the cheap default. Reaching for the Archon
> `/confirm` override is the last resort (see the memory rule
> `feedback_prefer_regrade_over_override`).

## The ship lifecycle (where the grade gate sits)

`/builder-ship` runs three transitions ([Phase 5](../session-logs/<redacted>.md)):

1. **`completed`** — the claim resolves once local verification (smoke) passes. **The claim is consumed here.**
2. **`confirmed`** — the v2 subagent quality grader (the 4-worker panel: Narc · Quality · Hacker · Efficiency Monger) passes. **Credits land here.**
3. **`shipped`** — branch auto-merged to `main` + deployed; the Discord `#ship-news` broadcast fires.

The grader reads **committed history** (`merge-base origin/main HEAD`…`HEAD`), independent of touches[] — so the diff it judges is whatever you've committed on the branch, not your working tree.

## The regrade-gap (why this recipe exists)

If the grade at step 2 **fails**, the task stays at `completed` but the claim is already gone (resolved at step 1). Historically there was no clean way back in — this was the **task-595-regrade-gap**, re-hit on [#600](https://example.com/builders#/task/600) and [#671](https://example.com/builders#/task/671)/[#673](https://example.com/builders#/task/673):

- `node scripts/gds/claim.js <id>` → refuses, "not ready (current status: completed)".
- `PATCH /tasks/:id {status:ready}` → refuses, `status_not_patchable`.
- `POST /tasks/:id/promote` → refuses, `cannot_promote` (only works from backlog).
- Re-running `ship.js` → "You don't have an active claim".

The only escapes were the Archon `/confirm` override (which *bypasses* the grader — wrong, per `feedback_prefer_regrade_over_override`) or hand-building a grader harness.

## The fix: `--regrade` ([#678](https://example.com/builders#/task/678))

```bash
node scripts/gds/ship.js <task-id> --regrade
```

This re-runs **ONLY the grade step** against the committed diff, with **no claim required**:

1. **Eligibility** — the task must be at `completed`, and you must either have *last held the claim* or be an **Archon**. (The ownership data comes from the `last_claim` field on `GET /api/gds/tasks/:id`; the gate is `evaluateRegradeEligibility` in `ship.js`.)
2. **Preflight** — your work must be committed (the grader reads committed history, not your working tree) and your local ship/grade tooling must be current with `main` (a stale `grader.js`/`ship.js` silently fails the same way — the [#662](https://example.com/builders#/task/662) lesson). `--force` overrides the freshness checks.
3. **Empty-diff guard** — the grader reads committed history, so an empty committed diff aborts cleanly.
4. **Grade** — runs the subagent grader and POSTs to the rank-open `/tasks/:id/grade` endpoint. `applyGrade` promotes `completed → confirmed` and awards credits on pass (idempotent — re-grading after the credit already landed is a no-op).
5. **On pass** — the normal `confirmed → shipped` auto-merge + deploy + memory/session sync tail runs, exactly as a first-try pass would have. (A grade-failed ship never reached merge, so a passing re-grade is the *first* time the task actually ships and broadcasts.)

Flags: `--summary "…"` (defaults to the task's stored value_summary), `--no-merge` (stop at confirmed; land later with `/merge-mode`), `--force` (override preflight freshness).

### Typical recovery loop

```bash
node scripts/gds/ship.js 600            # grade FAILS → task at completed, claim gone
# … read the issues, fix them, commit on the same branch …
node scripts/gds/ship.js 600 --regrade  # re-grades the committed diff; on pass → confirmed → shipped
```

## Why `/grade` is rank-open (and the ownership check is a UX guard)

`POST /tasks/:id/grade` is `requireBuilder` (any rank) by design — the *subagent grade* is the trust authority, not builder identity. `--regrade`'s "owner or Archon" check is therefore a client-side UX guardrail (don't accidentally re-grade someone else's task), not a security boundary. The real protection against a dishonest grade is the same as on the normal ship path: the builder runs the grader honestly against their committed diff.

## Last resort: the Archon override

Only if the grade was genuinely *wrong* (not "I don't want to fix it"):

```bash
curl -X POST -H "Authorization: Bearer <token>" https://example.com/api/gds/tasks/<id>/confirm
```

This writes a `task_grades` row with `grader_kind='lars'` so the audit trail shows it was a manual override. Prefer `--regrade`.

## Related

- Learning `#43` — "Recover a task stuck at 'completed': re-grade standalone, then /merge-mode" (the manual procedure this recipe automates).
- [`/merge-mode`](../../.claude/skills/merge-mode/SKILL.md) — lands `confirmed → shipped` when auto-merge bailed.
- [ADR 0024](../adr/<redacted>.md) — the MAS grader panel.
