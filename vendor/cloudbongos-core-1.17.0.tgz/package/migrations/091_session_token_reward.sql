-- 091_session_token_reward.sql
-- Task 1005 — flat cost-plus SESSION TOKEN REWARD (ADR 0054).
--
-- A builder now earns drachmae for a SHIPPED session proportional to its true
-- API token cost: drachmae = round(true_cost_usd * (1 + REWARD_MARGIN_PCT/100) * 100),
-- i.e. cost-plus-20%, denominated in integer cents. Computed SERVER-SIDE from
-- uploaded per-model token counts (never a client dollar figure). Idempotent
-- per session_id, append-only, reversible.
--
-- Three additive, nullable/defaulted changes — no backfill of historical rows,
-- no destructive edits. Forward-looking only.

-- (a) Per-model token usage rides as jsonb on the session record. ship.js
--     accumulates it from the same transcript usage it already parses; promoting
--     it to a first-class column (vs burying it in the free-form metrics blob)
--     makes the reward auditable + re-computable without parsing a blob. Shape:
--       { "<model-id>": { input, output, cache_read, cache_creation } }
ALTER TABLE session_records
  ADD COLUMN IF NOT EXISTS model_usage jsonb NOT NULL DEFAULT '{}'::jsonb;

-- (b) The token-reward drachmae actually granted for this session, mirrored here
--     for audit/reversibility. Authoritative payout is still the credit_log row;
--     this is an observability mirror (like drachmae_earned mirrors task credits).
ALTER TABLE session_records
  ADD COLUMN IF NOT EXISTS token_reward_drachmae integer NOT NULL DEFAULT 0;

-- (c) credit_log idempotency for the session token reward. credit_log has no
--     unique constraint anywhere today. We add a nullable session_id column + a
--     PARTIAL unique index scoped to the new reason. Existing rows keep
--     session_id = NULL and are unaffected (the partial index only covers rows
--     whose reason = 'session.token_reward'). This is the hard DB-level backstop
--     against a double payout when two ship uploads of the same session race.
ALTER TABLE credit_log
  ADD COLUMN IF NOT EXISTS session_id text;

CREATE UNIQUE INDEX IF NOT EXISTS uniq_credit_session_token_reward
  ON credit_log (session_id)
  WHERE reason = 'session.token_reward';

-- Counter hygiene: this migration was hand-authored (not handed out by the
-- claim-time allocator), so advance the allocator floor past 090 with GREATEST
-- (never a bare assignment) so a parallel claim can't reuse this number and a
-- concurrently-advanced counter is never rewound. (See 081 tail for the rule.)
UPDATE migration_counter SET next_number = GREATEST(next_number, 92) WHERE id = 1;
