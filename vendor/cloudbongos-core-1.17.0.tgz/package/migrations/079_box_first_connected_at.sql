-- migration 079: box first_connected_at — the monotonic "properly connected" signal
--
-- The onboarding "Path into the City" gains a first step, "Connect to thy dev
-- box" (#823, follow-up to #777 / ADR 0039). It must clear the moment a
-- newcomer actually reaches a working Claude on their box, and — being an
-- onboarding milestone — it must NEVER un-tick afterwards.
--
-- builder_boxes.claude_active (migration 078) is the live signal: the box-side
-- heartbeat (infra/box-heartbeat.sh) reports true while a `claude` process is
-- running. But it flips back to false when Claude stops, so it can't back a
-- monotonic step on its own. first_connected_at is the write-once derivative:
-- boxes.bumpActivity stamps it (COALESCE, never overwritten) the first time a
-- heartbeat reports claude_active=true. NULL until then; once set it stays set.
--
-- A heartbeat can only ping with a GDS token present on the box, so a
-- claude_active=true beat also implies the GDS CLI is authenticated — this one
-- signal subsumes the old cli_setup onboarding step it replaces.

ALTER TABLE builder_boxes
  ADD COLUMN IF NOT EXISTS first_connected_at timestamptz;
