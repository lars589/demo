# ADR 0108 — Instance composition topology: configurable-root (the core is consumed as a versioned npm dependency)

- **Status:** Accepted
- **Date:** 2026-07-03
- **Track:** internal
- **Task:** [#1870](https://example.com/builders#/task/1870) (BV1.R115) — the decision this ADR records.
- **Decides:** *how* a consumer instance physically composes with the extracted Cloud Bongos core — the composition **mechanism** that [ADR 0062](<redacted>.md) §10, [ADR 0100](<redacted>.md) §1, and [ADR 0103](<redacted>.md) §2 each left open. Those ADRs decided the repo *count* (two), the *order* (core-first), and per-repo GDS; they are deliberately mechanism-neutral ("installs a pinned core + layers its own content on top"), and [ADR 0103](<redacted>.md)'s R88 execution record explicitly deferred "the topology/instance paths the scaffold populates on `init`." This ADR resolves that deferral.
- **Replaces:** the never-shipped clone-and-layer draft of this same ADR number. A 2026-07-03 owner review rejected clone-and-layer in favour of the scalable model below — optimising for upgrade economics + a real product boundary over near-term least-resistance. (No supersession machinery: the draft never merged.)
- **Builds on:** [ADR 0062](<redacted>.md) §1 (core/host cut-line), [ADR 0098](<redacted>.md) (`isPublishable()` — now "the core *package* contents"), [ADR 0100](<redacted>.md) §§3–4 (per-repo GDS + conditional mirror, both retained), [ADR 0103](<redacted>.md) (core-first extraction; R88 shipped → `cloud-bongos`), [ADR 0105](<redacted>.md) (the `migrations/instance/` split), [ADR 0083](<redacted>.md)/[ADR 0061](<redacted>.md) (the module boundary + fitness functions), [ADR 0082](<redacted>.md).
- **Informs:** [#1689](https://example.com/builders#/task/1689) (R85 — Mercury, the first real consumer + the contract's validator), [#1690](https://example.com/builders#/task/1690) (R86 — the `bongos upgrade` channel), [#1728](https://example.com/builders#/task/1728) (R89 — the Example split), plus the net-new workstreams enumerated in §Consequences.

## Context

[ADR 0103](<redacted>.md) extracted the Cloud Bongos core into its own repo (R88, [#1727](https://example.com/builders#/task/1727), shipped 2026-07-03) and committed Mercury (R85) and Example (R89) to becoming *consumer repos on a pinned core*. It left the composition **mechanism** open. Two shapes were possible:

- **Clone-and-layer** — the consumer repo *is* the pinned core tree materialised at its **root**, host content layered on top; the core keeps sitting at repo-root, so its pervasive repo-root path assumptions keep working unchanged.
- **Configurable-root** — the core is installed as a **versioned dependency** (`@cloudbongos/core` in `node_modules/`) and resolves host content through an **injected instance-root**, so it no longer assumes it lives at the repo root.

A 2026-07-03 owner review chose **configurable-root**, explicitly weighting **scalability over least-resistance**. The decisive arguments: upgrades become an **O(1)-per-instance version bump** instead of an O(instances × drift) source merge; the core↔host boundary is enforced by the **packaging** (editing `node_modules` is obviously wrong and install-clobbered) rather than by convention + CI that *will* erode across many AI-agent builders and many instances; a dependency forces a **real public API/contract** on the core (the discipline that lets a platform serve many consumers without breaking them); instance repos stay **small and legible** (host content only); and "root is a parameter" is the precondition for any future **multi-instance / hosted** offering. Clone-and-layer dead-ends every one of those and would need this same refactor later anyway — under more pressure, on more instances, and on a live product.

A five-surface sweep ([#1870](https://example.com/builders#/task/1870)) established the real blast radius, and it is **lopsided**: the runtime-library change is small and already half-scaffolded; the genuine work and risk live in *delivery and operations*. The evidence:

- **The entrypoint seam already exists.** Three boot paths ship today — `server.js` (game + platform), `src/platform-server.js` (platform-only, zero game code), `src/preview-server.js` (game-only). The platform is exposed as `mountInternalSurfaces(app)` / `buildPlatformApp()` — ready-made core-package exports. The game is a seam-registered module, not wired into core boot.
- **The core runtime is thin.** Core deps are `express` + `pg` (+ an `undici` pin). The five Colyseus/Phaser libs are game-only; `discord.js`/`sharp` are optional-module.
- **The data/boundary partition is already single-sourced.** `publish-manifest.js`'s `isPublishable()` is the one authority; `package-core` consumes it (no second list); fitness Check 16 already hard-fails a core file that `require()`s an instance-excluded config (the R88 boot crash).
- **The module loader is already two-roots-capable.** `discoverModules({roots})` iterates a roots array and errors on cross-root key collisions; only `DEFAULT_ROOTS` is hardcoded.
- **Only ~8–11 files** resolve *instance* content off a `__dirname/../..` root and actually break under packaging (`branding.js`, `modules.js`, `hierarchy-config.js`, `pool.js`, the design adapter, `loader.js`, `serve-internal.js`, `migrate.sh`, `bin/bongos.js`, + a couple of scripts). The existing `src/instance-config.js` already solves the *sibling-identity* problem (config dir + env prefix) with a "OTB pins its values → zero change; vanilla → neutral" discipline — it is the template and the home for the fix.
- **The runtime substrate for a vanilla boot already exists** — `docker-compose` + `platform-server.js` boot GDS-only via `PG*` env, and `selfhost-boot.yml` CI proves a fresh empty Postgres boots vanilla with zero instance-data leakage.

The friction, instead, is concentrated in three places (detailed in §Consequences): the `.claude/` methodology surface cannot live in `node_modules`; deploy today is a `git reset --hard` on a shared checkout; and two independently-versioned repos will collide on migration numbering.

## Decision

### 1. The core is consumed as a versioned npm dependency; host content resolves through an injected instance-root.

Introduce two resolvers in the existing `src/instance-config.js`, extending its established zero-risk pattern from `~/.config` to the in-repo roots:

- **`resolveInstanceRoot()`** → where **host** content lives (`config/`, instance `modules/`, `migrations/instance/`, instance identity). Precedence: `<PREFIX>_INSTANCE_ROOT` env → a `bongos.config` pointer → `process.cwd()`.
- **`resolveCoreRoot()`** → where the **core package's own** files live (core `modules/`, core `migrations/`, the `infra/` installers, the neutral config defaults). When packaged: the `node_modules` package dir; today: `path.resolve(__dirname, '..')`.

The two directions are **opposite and both load-bearing**: config resolves from the *instance* root (with the `*.neutral.json` default in the *core* root); the `infra/bongos-install.{sh,ps1}` files that `serve-internal.js` serves resolve from the *core* root. A naive "use the instance-root everywhere" breaks the installers — this distinction is the crux of the `serve-internal` fix.

**Today both resolvers return the current repo root** (because `process.cwd()` === `__dirname/../..` === repo root in the single checkout), so routing the ~8–11 sites through them is **byte-identical for the live instance** — verified by the existing suite + a vanilla boot. Packaging later flips `resolveCoreRoot()` to the `node_modules` dir; the split becomes real with **no further per-site edits**.

### 2. `package-core` emits a real, installable npm package.

`isPublishable()` stays the single definition of "the core" — now "the package contents." `package-core` additionally: synthesises a `package/`-rooted `package.json` (`name` `@cloudbongos/core`, `version` = `CORE_VERSION`, `main` → `platform-server.js`, `exports` for `mountInternalSurfaces`/`buildPlatformApp`/the module-API, `bin` → `bongos`), **prunes** the game/art deps (leaving `express`/`pg`/`undici`), and ships a pruned lockfile. Today it ships the repo's game-heavy `package.json` verbatim under a `cloudbongos-core/` tar root — neither is package-installable.

### 3. The `.claude/` methodology surface is materialised into the instance, not resolved from `node_modules`.

Claude Code discovers `.claude/settings.json`, `hooks/`, and `skills/` from the **project root**, never from a dependency — so `bongos init`/`upgrade` must **materialise `.claude/` into the instance repo**, and the ~30 skills + the `settings.json` hooks must be rewritten from `node scripts/gds/…` to the **`bongos` bin** (which already resolves the heavy CLI — `ship.js`, the grader, `src/bongos/*` — inside the package). This formalises a split the publish boundary already encodes (skills ship in the core; hooks + `settings.json` are "topology"). The materialisation step is **net-new** — `init` writes only `config/` today.

### 4. `bongos upgrade` (R86) is a dependency version bump, not a snapshot-merge.

Upgrading = bump the pin in `package.json`/lockfile → `npm ci` → migrate → restart. Deploy shifts from the droplet `git reset --hard origin/main` model to **`git pull` the instance repo → `npm ci` (installs the pinned core) → migrate core + instance → start `platform-server.js` with the instance-root**. The Docker/`platform-server`/`selfhost-boot` substrate already models this shape.

### 5. Cross-repo migration numbering gets an explicit namespacing discipline.

`migrate.sh`'s basename merge-sort already orders files from arbitrary directories correctly (and keys idempotency on basename), so feeding it **three roots** (core-package / instance / module) works mechanically. But two independently-versioned repos both adding `NNN_*.sql` **will collide** on the shared `schema_migrations` stem key. Core migrations therefore get a core-owned namespace/prefix distinct from instance migrations, plus a lineage/numbering-divergence check (reuse the public mirror's existing pattern). Fitness Check 11's "additive + namespaced" rule extends to cover this.

### 6. Land incrementally and Mercury-first, so live prod is de-risked.

- **Step 1 lands now, zero-behaviour-change:** the two resolvers (defaulting to repo-root) + routing the ~8–11 sites through them. Good hygiene even if no split ever happened; verified against the suite + a vanilla boot.
- **Steps 2–3** (real package + `.claude/` materialisation) prove out on **greenfield Mercury (R85)** — the first consumer defines the contract.
- **R86** makes `bongos upgrade` a real version-bump channel, driven by Mercury's first core bump.
- **Example splits last (R89)** — and the trust-boundary-adjacent path sites (`route-rank-check.js`, `routes/backup.js`, `routes/builders.js`) plus the two-root awareness the guardrails need (see §Consequences) get a **security review** before they touch live prod.

## Alternatives considered

- **Clone-and-layer (the prior draft of this ADR).** Cheapest now, proven by the two proofs (cloudbongos.com reskin + the `package-core` tree snapshot), zero core-path changes. **Rejected as the destination:** merge-based upgrades don't scale across many instances × core versions; the boundary is convention + CI and rots under scale; there is no forcing function for a clean core API; and it dead-ends any multi-instance/hosted future — needing this exact refactor later regardless, under worse conditions. **Retained** only as the cheap single-checkout reskin shape (cloudbongos.com).
- **Git submodule for the core.** Rejected — still lands the core at a subpath (so it still needs configurable-root; it doesn't avoid the refactor) and adds the submodule UX tax on an AI-agent-first builder base.
- **One monorepo with an internal `core/` + `instances/` cut.** Already rejected in [ADR 0103](<redacted>.md) — the core never becomes a separately shippable product.

## Consequences

**More work now — the "pain" is real and concentrated in three net-new workstreams plus a cross-cutting guardrail fix:**

1. **`.claude/` materialisation + invocation rewrite** (§3). `bongos init`/`upgrade` must copy `.claude/` into the instance and rewrite ~30 skills + the `settings.json` hooks to the `bongos` bin. This is what makes an installed instance actually usable by AI agents; it does not exist today.
2. **Deploy conversion** (§4). `git reset --hard` → `npm ci`-of-the-pinned-core; `ship.js` (~151 KB, a monorepo-coupled deploy tool) needs rework; and the **shared-checkout dual-instance deploy** (example + cloudbongos.com on one tree — already the reason cloudbongos.com runs stale) must be cut *in tandem* with standing up the npm-install flow, or cloudbongos.com breaks.
3. **Cross-repo migration numbering** (§5) — the deepest design risk; needs the namespacing + lineage discipline before two repos version independently.
4. **The guardrails become two-root-aware.** `fitness.js`, `gen-repo-map.js`, and `gen-file-map.js` each hardcode `REPO_ROOT = __dirname/../..` and walk one tree; once the core is in `node_modules`, the core↔host boundary check, the CLAUDE.md-budget check, the nested-doc-presence check, and the two generators would inspect the wrong tree. They must learn the core-root/instance-root split — this is the mechanism [ADR 0062](<redacted>.md) §9 / [ADR 0061](<redacted>.md) rely on to keep the boundary from rotting, so it matters *more* under a real repo gap, not less.

**But the runtime-library half is small and de-risked:** ~8–11 readers through the resolvers, and the entrypoint seam, the two-roots loader, the single-sourced `isPublishable()` partition, and the Docker/vanilla-boot substrate all already exist. Step 1 is byte-identical for prod, which lets the risky part land reversibly and early.

**Docs to amend** (none *superseded* — this ADR resolves the mechanism they deferred, so they get cross-refs, not reversals): `docs/file-map.md` (present the tree as two — core-package vs instance), `docs/architecture.md` (repo + deploy), `docs/recipes/packaging-the-core.md` + `docs/recipes/self-host.md` (npm consumption + mount targets), [ADR 0105](<redacted>.md) (three-root migrations), `docs/modules-contract.md` (two-root discovery); cross-refs in [ADR 0062](<redacted>.md)/[0100](<redacted>.md)/[0103](<redacted>.md)/[0098](<redacted>.md), `docs/branding-contract.md`, and `CLAUDE.md` (whose nested-doc discovery model assumes core dirs sit at the instance root — they will live in the package). Keep within the CLAUDE.md 300-line / 42 KB fitness ceiling — relocate detail here, don't expand CLAUDE.md.

**Commitments:** R85 is built as `npm install`-of-the-core + configurable-root (and becomes the contract's validator); R86 is a version-bump channel; R89 keeps the risky path/guardrail/trust-boundary changes behind a security review. **No migration, no new criterion** minted by this ADR; recorded against goal 26 (Cloud Bongos productization and self-host).
