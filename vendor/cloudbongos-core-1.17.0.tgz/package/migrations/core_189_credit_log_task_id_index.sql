-- 189 index credit_log(task_id) — back the per-task credits_awarded rollups
-- Applied under task 1960 (follow-up from task 1957's review). Idempotent on re-run.
--
-- Problem: task 1957 added a per-task `credits_awarded` figure — the SUM of the
-- task-reward credit_log deltas WHERE task_id = t.id (see CREDITS_AWARDED_SUBQUERY
-- in modules/lifecycle/db.js). credit_log carried only idx_credit_log_builder
-- (builder_id, recorded_at); its task_id column (a FK from migration 003, which
-- Postgres does NOT auto-index) had no index, so every evaluation of that
-- subquery — and the existing sumCreditsForTasks() query in
-- modules/economy/credits.js — sequentially scans the append-only ledger.
-- 1957 already mitigated the hot board/claimable path with a CASE guard (unsettled
-- tasks skip the subquery entirely), but settled-task lists (the goal Done tab, the
-- ships ledger) and future ledger growth still benefit from a real index lookup.
--
-- Plain (non-concurrent) CREATE INDEX: migrate.sh applies each file with `psql -f`
-- in autocommit, and credit_log is small at current scale, so the brief exclusive
-- lock during the build is negligible. IF NOT EXISTS keeps re-runs a no-op.

CREATE INDEX IF NOT EXISTS idx_credit_log_task ON credit_log (task_id);
