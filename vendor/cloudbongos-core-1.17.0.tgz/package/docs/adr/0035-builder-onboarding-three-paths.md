# ADR 0035 — Builder onboarding: three setup paths (Local / DO Box / Remote Control)

**Date:** 2026-06-06
**Context:** GDS-V3, task [#715](https://example.com/builders#/task/715). Feeds done-when criterion **C1** (`a Metic onboards in ≤ 2h`). This ADR is the *onboarding-as-experience* companion to [ADR 0031](<redacted>.md), which locked the **substrate** (the containerized DO box, auto-suspend, rank-gated source access) but never consolidated how a person actually *arrives*. Builds on [ADR 0034](<redacted>.md) (the `xenos < thetes < metic < archon` ladder), [ADR 0016](<redacted>.md) (server-enforced permissions), [ADR 0022](0022-secrets-policy.md) (no secrets in repo), and the box onboarding middleware shipped in [#701](https://example.com/builders#/task/701) (§9.4 of ADR 0031).
**Status:** Accepted — §2 (the first-box Archon approval gate) superseded by [ADR 0059](<redacted>.md). *Decision record — locks the onboarding shape and three new policy decisions. The box-lane machinery already exists (ADR 0031 + [#701](https://example.com/builders#/task/701)); the deltas this ADR introduces (the Metic+ local gate, the first-box approval gate, the single hosted guide surface, the primer rewrite) are implementation sub-tasks listed at the end and are NOT yet built.*
**Track:** `internal` (dev-system / builder onboarding).

> **⚠️ Superseded in part by [ADR 0059](<redacted>.md) (task [#1141](https://example.com/builders#/task/1141)).** Decision **§2 — "A newcomer's FIRST box requires Archon approval"** is **removed**: with admission now invite-gated ([ADR 0050](<redacted>.md)), member-join is the sole human gate, and an admitted builder's first box now provisions hands-off. §1 (Metic+ local clone) and §3 (the single hosted guide) stand unchanged. Read §2 below as historical.

## Problem

A new builder can reach Example three different ways, but the project has never written down what the **arrival experience** is for each, who each is for, or how they're gated. ADR 0031 decided *where the worker runs* (a box we control); it did not decide *how a stranger goes from "I heard about this" to "I'm shipping tasks."* Three concrete gaps force this ADR:

1. **The live onboarding contradicts the intended model.** Today the *only* fully-working setup path is the one documented in [`docs/onboarding/primer.md`](../onboarding/primer.md) "Get set up": **accept a GitHub collaborator invite and clone the private repo onto your own disk** — open to *every* rank, including a brand-new Xenos. ADR 0031 §6 says source access should be a *rank-gated, revocable, box-held* boundary. So the live behavior is the exact opposite of the locked design: an unproven newcomer currently gets a permanent local copy of the whole repo. This must be reconciled.
2. **The box lane is built but has no front door.** ADR 0031 + [#701](https://example.com/builders#/task/701) shipped the whole provisioning spine — `POST /box/ensure`, the intent queue, the control-plane runner, the pairing-link path. But there is no *guided arrival*: nothing tells a non-technical or Chromebook builder, in plain language, "here is your first session, here is what to type, here is how you wait for your box." The capability exists; the on-ramp doesn't.
3. **Cost exposure is unbounded at the front door.** Anyone with a GitHub account can complete Device-Flow auth and become a Xenos, and a Xenos is above the box provisioning floor (`DEFAULT_PROVISION_FLOOR = 'xenos'`, [`src/bongos/boxes.js`](../../src/bongos/boxes.js)). With [#701](https://example.com/builders#/task/701)'s auto-draining intent queue, a signup could cause a paid droplet (~$24/mo, ~$5/active after auto-park) to be created with **zero human in the loop**. On a $5,000/yr budget that's a real hole.

## The three paths (what each *is*, who it's for, how it's gated)

Onboarding sorts every builder into exactly one of three on-ramps. All three share one foundation — the GitHub Device-Flow auth that `/builder-setup` already performs (`scripts/gds/setup.js`) and that writes the GDS session token — and all three end at the same place: a builder who can `/builder-start`, claim, and ship. They differ only in **where the worker runs** and **how the builder reaches it**, exactly as ADR 0031's three-pieces model (screen / worker / brain) predicts.

| Path | Worker runs | Reached via | Who it's for | Rank gate |
|---|---|---|---|---|
| **1. Local** | The builder's own machine | Native Claude Code / Desktop **Local** | Trusted power users who want to avoid box cost | **Metic+ only** |
| **2. DO Box** | A per-builder DigitalOcean box | Claude Desktop → **SSH** | The default for completely new users (Mac/Windows) | Xenos+ (first box needs approval) |
| **3. Remote Control** | The *same* per-builder DO box | Browser → **Remote Control** (`claude rc`) | Chromebook / iPad / thin-device users | Xenos+ (first box needs approval) |

### Path 1 — Local setup (Metic+ only)

- **User group.** Trusted power users who would rather run the repo on their own hardware than pay for (or wait on) a box.
- **What it is.** Claude Code pointed at a local folder that is a clone of the private GitHub repo — today's flow, unchanged in *mechanics*.
- **The gate (new policy).** **Local is Metic+ only.** A new user must **not** be able to clone the repo onto their own disk; for everyone below Metic, all source lives inside the box (Path 2/3). This aligns the live behavior with ADR 0031 §6/§9.2, where full source creds first arrive at graduation to Metic. Below Metic, the local on-ramp is simply not offered, and the collaborator-invite path is closed to them.
- **Onboarding steps.** Same as the current flow: install Claude Code, accept the repo invite, clone into an empty folder, `/builder-setup`, read the primer → `/builder-primer-read` → `/builder-start`.

### Path 2 — DO Box setup (the newcomer default)

- **User group.** Completely new users on a Mac or Windows machine.
- **What it is.** Claude Code runs *on* an org-controlled, containerized DigitalOcean box provisioned for that builder; the builder's Claude Desktop connects to it over SSH. The repo never lands on the builder's personal disk.
- **The gate.** Above the `xenos` provisioning floor, so any signed-in builder qualifies — **but the first droplet for a builder who has never had a box requires Archon approval before it is created** (new policy; see Decision §2). "One droplet at a time" is **already enforced**: `box_intents` carries a partial unique index (one open intent per builder) and `builder_boxes` is one row per builder.
- **Onboarding steps.**
  1. The new user opens a simple local Claude session pointed at the **hosted onboarding guide** (Decision §3) — the same content that drives the local-onboarding walkthrough today, but aimed at provisioning a box rather than cloning a repo.
  2. Claude walks the user through requesting a box (`/builder-box` → `POST /box/ensure`), which records a provision intent. The user is told their first box needs a quick approval, and waits.
  3. Once approved + provisioned, the user opens a new session, their Claude Desktop SSHes into the box, and they are now a builder in Example. The source surface they see is rank-scoped (`starter` sparse-checkout for Xenos/Thetes; `full` at Metic+ — ADR 0031 §9.2).

### Path 3 — Remote Control (Chromebook / thin devices)

> **⚠️ Superseded by [ADR 0038](<redacted>.md).** The `claude rc` headless-service mechanism described below was retired — a headless box cannot bootstrap `claude rc` (interactive-only Trusted-Devices enrollment). The box now serves its own `ttyd` browser terminal over a Cloudflare Tunnel where the builder runs normal interactive `claude`. The Path-3 *intent* (a browser-only thin-device on-ramp to the same per-builder box) stands; the `claude rc`-as-always-on-service mechanics below are historical.

- **User group.** Users on a device that cannot run Claude Desktop (a literal Chromebook, an iPad, a phone).
- **What it is.** Identical to Path 2 — the same per-builder box — but reached from a browser via Claude's Remote-Control (`claude rc` running as an always-on service on the box).
- **Onboarding steps.**
  1. Same as Path 2 steps 1–2, except the guide surface is the **hosted onboarding page in a browser tab** rather than a local Claude folder (a Chromebook has no local dev environment to point Claude at). It is the *same content* (Decision §3) — one guide, two ways to read it.
  2. After the box is provisioned, the user pairs: `POST /box/ensure` → poll `GET /box/pairing-link` until the `claude rc` link appears (published UP by the box's `box-report-pairing` cron, [#701](https://example.com/builders#/task/701)) → open the link. Claude then drives the box from the browser.

## Decision

The three paths above are the canonical onboarding model. Beyond consolidating them, this ADR locks **three policy decisions** (workshopped with Lars, 2026-06-06) and a **rollout sequence**.

### 1. Local source access is Metic+; everyone below is container-only

The <redacted> + clone-to-own-disk path becomes a **Metic+ affordance**. Below Metic (Xenos, Thetes), there is **no local clone** — source exists only inside the rank-gated box, where it is revocable and audited (ADR 0031 §9.2). This is the onboarding-side enforcement of the trust boundary: *proven* builders may hold a local copy; *unproven* ones work inside the box. Mechanically this means (a) the primer stops instructing newcomers to clone, and (b) collaborator invites are issued only at/after Metic.

> **Honest limit (carried from ADR 0031 §6/§9.2).** A Metic with a local clone, or any authorized builder with a box session, can still copy code they can read. This is defense-in-depth + revocation + audit, not insider-proof DRM. The Metic+ gate raises the bar from "any signup gets the repo forever" to "only a proven, promotable builder does."

### 2. A newcomer's FIRST box requires Archon approval

[#701](https://example.com/builders#/task/701) made `POST /box/ensure` enqueue a provision intent that the control-plane runner auto-drains. That is correct for *wakes* and for *re-provisions* of a builder who has earned a box before — but the **first ever provision for a builder** is now gated:

- A `provision` intent for a builder with **no prior box** (no `builder_boxes` row, or one that has never been `active`) is held in a **pending-approval** state instead of being drained. The runner skips it until an Archon approves.
- An Archon approves via an Archon-only affordance (a route + a `box.js` operator command — exact surface is an implementation detail; the decision is *that approval gates the first provision*). Approval flips the intent to drainable; the existing runner then provisions it unchanged.
- **`wake` intents and any subsequent provision** (a builder who has had an `active` box before) are **not** gated — they auto-drain as today. The gate is specifically the *first* paid droplet for an unproven account.

This closes the §Problem-3 cost hole: a stranger can sign in and read, but cannot cause us to spend money until a human says so. It rides the existing `box_intents` queue (add an approval state/column) rather than introducing a new mechanism, and it keeps the §6 trust-boundary invariant intact — the web tier still only *asks*; it never holds `DO_API_TOKEN` and never provisions directly.

> **Why not an invite-code gate (the considered alternative).** Closing signup entirely (invite codes) is the strongest cost+security control, but it adds a distribution burden and forecloses the open, low-friction "anyone can come look" funnel C1 implies. First-box approval keeps the funnel open (sign up, read, file ideas) while still putting a human between a signup and a charge. Revisit invite codes if signup-driven box spend ever becomes a real problem.

### 3. One hosted guide surface for both SSH and RC — no separate bootstrap repo

The pre-box "guide Claude" needs onboarding context, never source. Rather than build and maintain a **separate private bootstrap repo** (the original sketch), there is **one hosted onboarding guide** served from the GDS:

- **SSH/Desktop users** point a local Claude session at it (a hosted page, or the existing public `GET /box/connect` / `connect.sh` bootstrap it links to).
- **RC/Chromebook users** open the same content as a **browser page** — they have no local folder to point Claude at.

Same content, two ways to consume it. This avoids a second repo to keep in sync, and the *executable* half already exists (the public, `PUBLIC_ORIGIN`-pinned `connect.sh`/`.ps1` from [#685](https://example.com/builders#/task/685)). The new artifact is the **human/Claude-readable guided walkthrough** that frames the whole arrival — sign in → request box → wait for approval → connect/pair — and that is safe to serve publicly because it contains zero source.

### 4. Rollout — gate local to Metic+ now, keep it as a fallback until the box lane is hardware-verified

The box lane (Paths 2 & 3) is **built but unverified on real hardware**, and the box-side source credential is **inert** (`configured:false` — the prod secret is unset; ADR 0031 §9.2/§9.4, [#699](https://example.com/builders#/task/699)). We must never leave **zero** working paths. Therefore:

- **Now:** apply Decision §1's Metic+ gate to the local path, and make Path 2 the *documented* default for newcomers.
- **Keep:** the collaborator-invite local path as a **Metic+-only fallback** — it stays the proven escape hatch until the box lane works end-to-end on hardware.
- **Then:** once the verification plan below is green, the box lane becomes the real newcomer default and the local path settles into its permanent Metic+ niche.

## Verification plan (what "test the existing setup" means after this ADR)

ADR 0031 §9 + [#699](https://example.com/builders#/task/699) + [#701](https://example.com/builders#/task/701) record the box lane as hermetically tested but **hardware-unverified**. This ADR's acceptance does not assert the box lane *works* — it asserts the *shape*. The following legs must be exercised on a real box before Path 2/3 can be the default (this is the test campaign that follows this ADR):

1. **Source credential goes live.** Set the prod `BOX_SOURCE_*` secret(s) so `GET /box/source-access` returns `configured:true`; verify a real box sparse-clones the `starter` surface (Xenos) and the `full` surface (Metic) and that the token is scrubbed from `.git/config` (`infra/box-source-fetch.sh`). *Operator gotcha (recorded):* `DO_API_TOKEN` must carry **tag-create** scope or provisioning 422s.
2. **Auto-provision via the timer.** Install `box-intent-runner.timer` on the control plane; confirm a `POST /box/ensure` intent is drained into a live droplet — **including the new first-box approval gate**: an unapproved first intent stays pending; an Archon approval lets it drain.
3. **Wake-on-connect.** Park a box, confirm `POST /box/ensure` wakes it from snapshot.
4. **Desktop SSH connect.** A real Claude Desktop connects to a running box via the managed-settings host (the [#599](https://example.com/builders#/task/599) stable-hostname cutover) and runs Claude Code on it.
5. **RC pairing end-to-end.** `box-report-pairing` publishes a real `claude rc` link; a browser reads it via `GET /box/pairing-link` and drives the box.
6. **Guide + primer dry-run.** A fresh GitHub account, following only the hosted guide + rewritten primer, reaches "claimed and shipped a task" within the C1 ≤2h budget — the actual onboarding-time measurement.

## Consequences

- **The live primer must be rewritten.** [`docs/onboarding/primer.md`](../onboarding/primer.md) "Get set up" currently teaches only the open-to-all local clone. It must present the three paths, default newcomers to the box, and apply the Metic+ local gate. The ADR 0031 three-pieces mental model (screen/worker/brain) lands here verbatim, as 0031 §"mental model" always intended.
- **Collaborator-invite issuance becomes rank-aware.** Invites are issued at/after Metic, not on signup. (The mechanics of *who* sends invites and *when* is an operator step today; the policy is now written.)
- **`box_intents` gains an approval state.** A small schema/route/CLI addition; the runner learns to skip unapproved first-provisions. No new subsystem.
- **One thing to maintain, not two.** The single hosted guide means no second repo drifting out of sync — but it does mean the guide content is a real artifact someone owns and keeps current.
- **Cost stays bounded at the door.** Open, free signup + read; money only after a human approves the first box. Aligns with the §5 cost model of ADR 0031.
- **No relitigating 0031.** Substrate, auto-suspend, source-scoping, and the intent queue are unchanged. This ADR only adds the onboarding-experience layer and the three policy gates on top.

## Implementation sub-tasks (proposed — to be seeded in a planning/triage session)

Not yet created; listed so a build session has a starting decomposition. None are built by this ADR.

1. **Metic+ local gate.** Stop the primer/onboarding from offering local clone below Metic; make collaborator-invite issuance Metic+.
2. **First-box approval gate.** Add a pending-approval state to `box_intents` (schema + the runner skip), an Archon-only approve affordance (route + `box.js` command), and surface "your box is awaiting approval" to the waiting builder via `/builder-box`.
3. **Hosted onboarding guide.** Author the single public guided walkthrough (page + the content a local guide-Claude reads), framing sign-in → request box → await approval → connect/pair, for both SSH and RC. Reuses the existing public `connect.sh`/`.ps1`.
4. **Primer rewrite.** Replace the local-only "Get set up" with the three-path model + the 0031 mental model; keep `/builder-primer-read` as the gate.
5. **Run the verification plan.** The six-leg hardware campaign above — this is the "test the existing setup" work that motivated the ADR.

## Open questions (flagged, not blocking)

1. **Approval surface ergonomics.** Should first-box approval be a one-click action in the builders' hall, a Discord interaction (ADR 0033), or an operator CLI only? Lean: builders'-hall action + `box.js` fallback; decide at build time.
2. **Approval expiry.** Does an approved-but-undrained intent expire, and does a denied newcomer get told why? Lean: approvals don't expire; denials leave an audited note.
3. **Metic transition off the box.** When a Xenos/Thetes on a box graduates to Metic and *wants* the local path, what's the handoff (re-clone locally, retire the box, or keep both)? Touches ADR 0031 open-question [#1](https://example.com/builders#/task/1) (ownership transition); defer.
