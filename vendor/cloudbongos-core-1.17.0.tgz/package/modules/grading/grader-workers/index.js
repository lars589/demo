// MAS Phase 2.0 (#410) — Worker panel registry + shared runner.
//
// Each worker (narc.js, quality.js, …) exports:
//   KIND, NAME, SPECIALTY        — identification
//   buildPrompt({...})           — produces the subagent prompt
//   extractJson(rawString)       — parses the subagent's JSON response
//   computeVerdict(parsed, meta) — returns a partial WorkerResult
//
// runWorker() ties them together: build prompt → spawn subagent (via the
// existing grader.runSubagent) → parse → compute verdict → assemble the
// final WorkerResult (kind/name/scores/verdict/issues/notes/...).
//
// The DEFAULT_PANEL is the set of workers run by gradeSubagent today.
// Phase 2.0 ships narc + quality. Phase 2.1 will add 'hacker'. Phase 2.2
// will add 'efficiency'.

const narc = require('./narc');
const quality = require('./quality');
const hacker = require('./hacker');
const efficiency = require('./efficiency');

const REGISTRY = {
  [narc.KIND]: narc,
  [quality.KIND]: quality,
  [hacker.KIND]: hacker,
  [efficiency.KIND]: efficiency,
};

// The active panel for the ship-time gate. Order is presentation-only —
// workers run in parallel inside gradeSubagent.
const DEFAULT_PANEL = [narc.KIND, quality.KIND, hacker.KIND, efficiency.KIND];

// #465: transient subprocess/parse errors are infra noise, not a quality
// signal — auto-retry the worker ONCE on these before letting the error stand.
// Deliberately EXCLUDES:
//   - SUBAGENT_TIMEOUT — a real budget signal (the worker ran out of wall-clock;
//     retrying just burns another timeout). Handled via per-worker timeouts (#467).
//   - null / a real verdict — that's signal, never retried.
// One retry only — never erodes the gate's strictness, just absorbs the ~1-in-3
// good ships that were flaking on a single noisy subagent (see #465 desc).
const TRANSIENT_WORKER_ERRORS = new Set([
  'parse_error',
  'schema_error',
  'SUBAGENT_SPAWN_FAILED',
  'SUBAGENT_NONZERO_EXIT',
]);

// #467: per-worker subagent timeout. The global 240s applied to EVERY worker,
// which timed out the Read-heavy ones (Narc walks ACs + reads files — hence
// Phase 2.0.5's 5-read workaround; Quality is next-heaviest) while the light
// ones (Hacker, Efficiency) never needed that long. Per-worker budgets let the
// heavy lenses breathe without globally inflating every ship's worst-case wall
// time. A worker module may override by exporting its own MAX_TIMEOUT_MS;
// otherwise this map (keyed by KIND) is the single tuning surface. Falls back
// to runOpts.timeoutMs (then runSubagent's own 240s default) for any unlisted
// worker. Tune from the calibration data (#292) once it accrues.
const WORKER_MAX_TIMEOUT_MS = {
  narc: 360_000,       // Read-heavy: walks every acceptance criterion
  quality: 360_000,    // Read-heavy: reads changed files for cleanliness review
  hacker: 240_000,     // lighter: focused security scan
  efficiency: 240_000, // lighter: focused performance scan
};

// Resolve the timeout for a worker: explicit module override > KIND map >
// caller's runOpts > undefined (runSubagent applies its own default).
function timeoutForWorker(worker, runOpts) {
  return (
    worker.MAX_TIMEOUT_MS ??
    WORKER_MAX_TIMEOUT_MS[worker.KIND] ??
    runOpts?.timeoutMs
  );
}

// Resolve a list of worker kinds to their modules. Throws on unknown kinds
// so a typo in a custom panel surfaces immediately, not as a silent skip.
function resolvePanel(kinds) {
  const out = [];
  for (const k of kinds) {
    const mod = REGISTRY[k];
    if (!mod) throw new Error(`unknown worker kind: ${k}. Known: ${Object.keys(REGISTRY).join(', ')}`);
    out.push(mod);
  }
  return out;
}

// Runs one worker end-to-end. Returns a WorkerResult — always; subprocess /
// parse / schema errors become a verdict='fail' result with an error tag, so
// the caller can write the audit-trail row regardless.
//
// runSubagentFn is injected to avoid a circular dependency between
// grader-workers/* and grader.js (grader.js requires this module).
//
// opts:
//   model           the grader model for this worker (selected by caller)
//   runOpts         passed to runSubagentFn (timeout, cwd, etc.)
//
// The subagent's raw stdout + run timing + any subprocess error are surfaced
// onto the WorkerResult so aggregatePanel can decide pass/concerns/fail
// without knowing about the runSubagent internals. ("shot" is v3 multi-shot
// terminology; v4 calls these workers — but the subprocess plumbing is the
// same shape underneath.)
async function runWorker(worker, { task, valueSummary, diff, changedFiles, diffStats, model, runOpts, runSubagentFn, extractAssistantResultFn, deterministicFindings }) {
  // deterministicFindings (route-rank pre-pass, #475) is forwarded to every
  // worker's buildPrompt; only the Hacker reads it — the others ignore the
  // extra field, so this is a no-op for narc/quality/efficiency.
  const prompt = worker.buildPrompt({ task, valueSummary, diff, changedFiles, diffStats, deterministicFindings });

  // One subagent attempt → verdict. Pulled out so #465 can re-run it once on a
  // transient error without duplicating the spawn/parse/verdict plumbing.
  // #467: per-worker timeout (Read-heavy workers get longer; see the map above).
  const timeoutMs = timeoutForWorker(worker, runOpts);
  async function attempt() {
    let raw = null;
    let runMs = null;
    let costUsd = null;
    let subprocessError = null;
    const t0 = Date.now();
    try {
      const { stdout, run_ms, cost_usd } = await runSubagentFn({ prompt, opts: { ...runOpts, model, timeoutMs } });
      runMs = run_ms;
      // #486 (ADR 0028 path 1): runSubagent attaches the `claude -p` envelope's
      // total_cost_usd. Carry it out so aggregatePanel can sum the panel's own
      // API spend into panel_cost_usd → cost_log (source=grader).
      costUsd = cost_usd ?? null;
      raw = extractAssistantResultFn ? extractAssistantResultFn(stdout) : stdout;
    } catch (err) {
      runMs = err.run_ms ?? (Date.now() - t0);
      subprocessError = err.code || 'UNKNOWN';
    }
    const parsed = subprocessError
      ? null
      : (typeof raw === 'string' ? worker.extractJson(raw) : raw);
    const verdict = worker.computeVerdict(parsed, {
      model,
      run_ms: runMs,
      subprocess_error: subprocessError,
    });
    return { verdict, runMs, costUsd };
  }

  let { verdict, runMs, costUsd } = await attempt();
  // #465: retry ONCE on a transient error (the freshest attempt wins, even if it
  // also errored — one retry only). A real verdict or a SUBAGENT_TIMEOUT is
  // never retried. NB (#486): the freshest attempt's cost wins; a transient
  // first attempt's spend is not added (slight, rare undercount).
  let retried = false;
  if (TRANSIENT_WORKER_ERRORS.has(verdict.error)) {
    retried = true;
    ({ verdict, runMs, costUsd } = await attempt());
  }

  return {
    kind: worker.KIND,
    name: worker.NAME,
    specialty: worker.SPECIALTY,
    verdict: verdict.verdict,
    scores: verdict.scores || {},
    issues: verdict.issues || [],
    notes_md: verdict.notes_md || '',
    confidence: verdict.confidence ?? null,
    model,
    run_ms: runMs,
    cost_usd: costUsd, // #486: this worker's own subprocess API spend (USD)
    retried,
    error: verdict.error ?? null,
    // Narc-specific (carried opaquely; aggregatePanel doesn't need to know):
    ...(verdict.ac_checklist ? { ac_checklist: verdict.ac_checklist } : {}),
  };
}

module.exports = {
  REGISTRY,
  DEFAULT_PANEL,
  resolvePanel,
  runWorker,
  timeoutForWorker, // public surface; WORKER_MAX_TIMEOUT_MS stays module-internal
  TRANSIENT_WORKER_ERRORS,
  // re-export per-worker modules for direct access by tests
  narc,
  quality,
  hacker,
  efficiency,
};
