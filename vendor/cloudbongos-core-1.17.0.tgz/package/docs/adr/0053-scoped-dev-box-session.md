# ADR 0053 — Scoped, short-lived dev-box session + apex-cookie strip at the tunnel

**Date:** 2026-06-13
**Context:** GDS, security reports SR[#2](https://example.com/builders#/task/2) (HIGH) + SR[#11](https://example.com/builders#/task/11) (HIGH) from the 2026-06-08 server audit ([#870](https://example.com/builders#/task/870)); task [#919](https://example.com/builders#/task/919). Owner decision 2026-06-09: do the proper redesign, not the interim named-tunnel disable. Governed by the trust-boundary rule in [ADR 0016](<redacted>.md) and the box subsystem in [ADR 0031](<redacted>.md) / [ADR 0038](<redacted>.md) / [ADR 0044](<redacted>.md).
**Status:** Accepted.
**Track:** `internal` (development system / builder dev boxes + access control).

## Problem

A dev box is **outside** the ADR 0016 trust boundary — the GDS authenticates against the box, never the reverse. Two channels nonetheless put a builder's **full-authority** GDS bearer onto the box:

- **SR[#2](https://example.com/builders#/task/2) — baked full token.** `scripts/gds/box.js` mints a session and bakes it into cloud-init → `/root/.config/otb/gds-session.json`, so `box-source-fetch` can clone the rank-scoped repo on first boot (the [#818](https://example.com/builders#/task/818) chicken-and-egg: `/builder-setup` lives in the un-cloned repo). That session was `source='cli'`, and `source` was **purely informational** — `auth.requireBuilder` had no scope concept, so the baked token could claim/grade/ship and hit every `requireBuilder` route at the builder's live rank. Any on-box process, or the `169.254.169.254` metadata endpoint, could read it and act as the full builder.
- **SR[#11](https://example.com/builders#/task/11) — apex cookie rides the tunnel.** The hall session cookie is `gds_session; Domain=.example.com` (apex-scoped so [#726](https://example.com/builders#/task/726) SSO works across `builders.example.com`). The browser therefore sends it to `term-<login>.example.com` (ttyd) and `sandbox-<login>.example.com` (game preview) — both fronted by the box. The builder's full hall bearer rides the tunnel onto the less-trusted box.

## Decision

**Two independent defenses; the box never holds, and never receives, a full-authority credential.**

### 1. A third session source, `'box'`, that is deny-by-default (fixes SR[#2](https://example.com/builders#/task/2))

- `box.js` mints the baked session as **`source='box'`** (migration 090 widens the `builder_sessions.source` CHECK to `('cli','web','box')` and retroactively flips already-baked `user_agent='box-provision'` rows in place).
- `auth.requireBuilder` **rejects a `source='box'` session on every route** (`403 box_scope`) **except** the handful the on-box crons need, which opt in via a one-line `auth.allowBoxScope` middleware mounted ahead of `requireBuilder`. The allow-list IS the complete box surface:

  | Route | On-box caller |
  |---|---|
  | `GET /box/source-access` | `box-source-fetch.sh` (cron */10) |
  | `GET /box/authorized-keys` | `<redacted>.sh` (cron */10) |
  | `POST /box/heartbeat` | `box-heartbeat.sh` (cron */5) |
  | `POST /box/terminal` | `box-report-terminal.sh` (quick-tunnel credsync) |

- **Fail closed:** a route *without* `allowBoxScope` denies a box session — so any route added later is automatically out of reach of a box token. No path-prefix matching (which drifts); the gate keys on an explicit per-route flag.
- A builder who wants to do real work **from** the box runs `/builder-reauth` (interactive device flow), minting a normal `cli`/`web` session exactly like any laptop — never auto-baked.
- The credential is still 24h refresh-on-use (unchanged since [#400](https://example.com/builders#/task/400); SR[#2](https://example.com/builders#/task/2)'s "non-expiring" predates that). The fix is **scope**, not lifetime: even a captured, still-valid box token can do nothing but bootstrap.

### 2. Strip the `Cookie` request header at the edge for box subdomains (fixes SR[#11](https://example.com/builders#/task/11))

- A **zone Transform Rule** (`http_request_late_transform` phase, action `rewrite` → `headers.Cookie.operation = remove`) removes the Cookie request header where `starts_with(http.host, "term-")` or `starts_with(http.host, "sandbox-")`, applied at the Cloudflare edge **before** the request enters the tunnel. ttyd uses basic-auth and the sandbox serves the game, so neither needs the cookie. One wildcard-prefix rule covers every builder's box.
- Implemented as `CfTunnelApi.ensureCookieStripRule` (idempotent GET-merge-PUT that preserves other transform rules), wired **best-effort** into `ensureNamedTunnel` so a token lacking the scope warns but never blocks provisioning.
- We do **not** narrow the apex cookie — that would break [#726](https://example.com/builders#/task/726) cross-subdomain SSO.

## Alternatives considered

- **Single-use enrollment code exchanged on first boot for the scoped token** (instead of baking a session). Cleaner provenance, but adds a stateful exchange + a first-boot failure mode; the baked-but-scoped session reuses the existing `createSession` path and the same exposure class as the already-baked SSH keys / tunnel token. Deferred — `source='box'` already removes the authority that made the bake dangerous.
- **A dedicated `scope` column** rather than overloading `source`. Rejected: the audit specified `source='box'`, and `source` already means "how was this minted." One column, one migration.
- **Path-prefix allow-list inside `requireBuilder`** (`/api/gds/box/...`). Rejected as fragile (prefix drift, and it would wrongly admit non-bootstrap `/box/*` routes like `/box/ssh-key`, `/box/ensure`, `GET /box/terminal`). The per-route opt-in flag is precise and fails closed.
- **A Cloudflare Worker** to delete the cookie. Unnecessary — Cloudflare Transform Rules permit *removing* (not setting) the `Cookie` request header, which is exactly our need.
- **Box-side cookie strip** (ttyd / origin). Rejected: the box is the untrusted party; the strip must be at the edge.

## Consequences

- A leaked or compromised dev-box credential can do **nothing but the 4 bootstrap endpoints** — no claiming, shipping, grading, or reading the builder surface.
- `hasCliSession` (keyed on `source='cli'`) no longer auto-ticks the onboarding "Run /builder-setup" step purely from provisioning — more honest; it is display-only and never gates graduation.
- `revokeAllSessionsForBuilder` (demotion/offboard) revokes `box` rows like any other → the clawback is unaffected.
- **Operator action:** the cookie-strip rule needs the `CLOUDFLARE_API_TOKEN` to carry zone **Transform Rules (Account Rulesets) edit** scope. If absent, provisioning still succeeds and logs a warning; apply the rule once in the CF dashboard or add the scope. Tracked as an owner blocker.
- Verified by `tests/box_scope_session.mjs` (the scope gate, in the CI unit gate) and `tests/cf_tunnel.mjs` (the edge-rule shape). Hardware verification of a fresh box boot under the box-scoped token is a follow-up ([#919](https://example.com/builders#/task/919) note).
