-- GDS-V4 Planning Session #1 seed
-- Applied under claim 742 (task 937, V4.R00 — Planning Session #1).
-- Idempotent on re-run.
--
-- What this migration does:
--   1. Updates versions.GDS-V4 name + done_when to match the 6 criteria
--   2. Seeds 6 done_when_criteria rows for version_id='GDS-V4'
--   3. Renames the 2 existing open GDS-V4 carry-over tasks (263, 594) with
--      their V4.R## prefix and sets their priorities per the ranking.
--      Existing descriptions are preserved.
--
-- Net-new tasks (38 of them) are created via scripts/gds/seed-gds-v4-tasks.js
-- which runs after this migration is applied (same split as the V3 planning
-- seed, migration 018: tasks have rich descriptions + dependency wiring that
-- the API handles more cleanly than a long SQL VALUES list).
--
-- Source research: 2026-06-12 retrieval-layer architecture report + BFG
-- session-corpus friction mining (1,349 session_records; ceremony +
-- failed-tool-use taxonomies).

BEGIN;

-- ============================================================================
-- 1. Version name + done_when text
-- ============================================================================
UPDATE versions
SET name = 'GDS V4 — recall, resumable pipeline, honest measurement',
    done_when = 'When this is finished, a builder''s session answers "have we done this before?" in one call instead of an afternoon — project knowledge (markdown and database prose alike) is searchable in one rank-scoped query and pushed into sessions at claim time; a failed ship is one command from resume instead of a consumed claim; the recurring tool-error classes (wrong-tree writes, HTML 404s, phantom smoke servers) are engineered away; the BFG''s measurements reflect real friction so the improvement is provable against the 2026-06-12 baseline; and the city watches itself on one pane of glass.'
WHERE id = 'GDS-V4';

-- ============================================================================
-- 2. Seed 6 done_when_criteria rows for GDS-V4
--    UPSERT semantics via ON CONFLICT (version_id, criterion_id).
-- ============================================================================
INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, sort_order)
SELECT * FROM (VALUES
  ('GDS-V4', 'one-call-recall',
   '**Project knowledge is answerable in one call.** Any builder session — laptop, dev box, or browser — can ask one question and get back the relevant ADRs, recipes, session logs, learnings, ideas, and task notes, including the database prose nothing can search today. Done when: lexical search is live over repo markdown + DB prose; results are rank- and owner-scoped (Xenos never sees permission-core content; nobody sees another builder''s memory); every result cites its source so the agent can follow up; and a golden-question set mined from real sessions scores ≥80% recall@5 — whether plain text-search or embeddings gets there is decided by measurement, not taste.',
   1),
  ('GDS-V4', 'sessions-start-knowing',
   '**Sessions start knowing, not hunting.** What a session needs to act correctly is pushed at claim time instead of rediscovered: its worktree root, the claims it holds, the GDS API path prefix and field enums, OS environment facts, the next free ADR/migration number, and the top recall hits for the claimed task. Done when: the guess-and-retry API errors and worktree-path floods measured in the June 2026 corpus stop appearing in new sessions.',
   2),
  ('GDS-V4', 'failed-ship-never-strands',
   '**A failed ship never strands work.** Drift fails, grade failures, and merge bails leave the task one command from resume — no consumed claims, no reset-and-re-claim dance, no re-running an already-passing grader panel. Done when: a deliberately failed ship is resumed in one command, and claim_consumed_on_fail (which fired in 11 of 11 deep-dived sessions) goes quiet in new sessions.',
   3),
  ('GDS-V4', 'machine-room-ergonomics',
   '**Sessions stop fighting the machine room.** The recurring tool-error classes are engineered away: cross-tree writes guarded, API 404s/409s answer in JSON with a hint instead of an HTML page, laptop sessions stop smoke-testing against a server that isn''t running. Done when: the wrong-path class (84 hits, #1 in the June 2026 corpus) and its siblings drop measurably in new sessions.',
   4),
  ('GDS-V4', 'bfg-measures-what-hurts',
   '**The BFG measures what actually hurts.** The session evaluator''s numbers reflect real friction: ceremony is visible on cache-dominated marathon sessions (today they score ~99% efficient), the wrong-path footgun — the corpus''s #1 error class — is detected, harness guardrail retries stop inflating tool-error counts, and corpus coverage is reconciled. Done when: re-running the friction analysis produces numbers trustworthy enough to judge the other criteria.',
   5),
  ('GDS-V4', 'one-pane-of-glass',
   '**The city watches itself on one pane of glass.** The observability carry-overs land — Grafana dashboards as code, status surface v2 — plus staleness/health visibility for the new search index. Done when: those surfaces are live and the search index cannot silently go stale.',
   6)
) AS v(version_id, criterion_id, criterion_md, sort_order)
WHERE EXISTS (SELECT 1 FROM versions WHERE id = 'GDS-V4')
ON CONFLICT (version_id, criterion_id) DO UPDATE
  SET criterion_md = EXCLUDED.criterion_md,
      sort_order   = EXCLUDED.sort_order;

-- ============================================================================
-- 3. Re-prefix + re-prioritize the 2 existing open carry-over tasks.
--    Guarded so re-runs (and already-renamed rows) are no-ops.
-- ============================================================================
UPDATE tasks
SET title = 'V4.R28 — ' || regexp_replace(title, '^V\d+\.R\d+\s*—\s*', ''),
    priority = 3
WHERE id = 263 AND version_id = 'GDS-V4' AND title NOT LIKE 'V4.R%';

UPDATE tasks
SET title = 'V4.R29 — ' || regexp_replace(title, '^V\d+\.R\d+\s*—\s*', ''),
    priority = 3
WHERE id = 594 AND version_id = 'GDS-V4' AND title NOT LIKE 'V4.R%';

COMMIT;
