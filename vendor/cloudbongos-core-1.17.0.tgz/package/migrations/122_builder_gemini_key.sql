-- 122_builder_gemini_key.sql — per-builder Gemini key, encrypted at rest (task 1013).
--
-- Pragmatic BYOK (ADR 0073). The builder's own Google AI Studio (Gemini) key
-- moves from local-file-only (~/.config/otb/gds-session.json#gemini_api_key,
-- entered via the CLI) to a server-stored encrypted column that becomes the
-- source of truth — so a browser-first builder can enter it on the Settings page
-- and it syncs down to their box at session start (mirrors the shared-key rail).
--
-- Three columns on `builders`:
--   gemini_key_enc    — the AES-256-GCM blob "v1.<iv>.<tag>.<ct>" (base64url
--                       parts). NULL = no own key set. The plaintext NEVER lands
--                       in the DB; the master key lives only in server env
--                       (BUILDER_SECRET_KEY), so a DB dump alone cannot decrypt
--                       (src/bongos/secret-box.js).
--   gemini_key_last4  — last 4 chars of the plaintext, for the masked "…ABCD"
--                       display (like GitHub/Stripe). Not a secret.
--   gemini_key_set_at — when it was last set/replaced.
--
-- This mirrors the sparse per-builder column pattern (migrations 119, 075, 037):
-- behaviour lives in code (secret-box.js + builder-needs.js), not in a CHECK.
--
-- Idempotent: safe to re-run.

ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS gemini_key_enc    text,
  ADD COLUMN IF NOT EXISTS gemini_key_last4  text,
  ADD COLUMN IF NOT EXISTS gemini_key_set_at timestamptz;

INSERT INTO schema_migrations (version) VALUES ('122_builder_gemini_key')
  ON CONFLICT (version) DO NOTHING;
