# ADR 0072 — Dev-box code-staleness: make it visible, never auto-reset

- **Status:** Accepted
- **Date:** 2026-06-20
- **Track:** internal
- **Builds on:** [ADR 0031](<redacted>.md) (per-builder dev boxes), the `box-source-fetch.sh` self-update machinery ([#600](https://example.com/builders#/task/600), [#985](https://example.com/builders#/task/985)), and task [#1187](https://example.com/builders#/task/1187) (the box host-key reporter — the report-up cron pattern this mirrors)
- **Task:** [#1316](https://example.com/builders#/task/1316) (from idea [#332](https://example.com/builders#/idea/332))

## Context

A builder (LarsCode) repeatedly hit cryptic dev-box failures: the shared Gemini art key never reached the box, and Claude Desktop connect failed with "host verification failed." Both traced to **one cause — the box was running stale code.** Its box was provisioned 2026-06-07, before two features existed: the shared-art-key delivery rail ([ADR 0068](<redacted>.md), `fetch-art-key.js` + the `gen_api.py` shared tier) and the host-key reporter ([#1187](https://example.com/builders#/task/1187)).

Investigation refined the problem. Boxes **already auto-update**: `infra/box-source-fetch.sh` runs every ~10 min and `git pull --ff-only`s `/workspace`, *and* self-updates its own baked scripts/crons ([#985](https://example.com/builders#/task/985)). So any box provisioned *after* that machinery landed self-heals. The residual gaps:

1. A box provisioned **before** the self-update machinery has no self-update cron — it can never pull the fix, so it's stuck stale forever. Only a rebuild (deprovision → fresh provision) helps.
2. When `pull --ff-only` can't fast-forward (a diverged/dirty tree), `box-source-fetch.sh` logs and leaves the tree as-is — stale, **silently**.
3. **There was no visibility.** A stale box fails cryptically and the builder has no way to know the cause is old code.

## Decision

Add a **visibility** layer, not more auto-magic.

- The box reports its `/workspace` HEAD commit (sha + commit date) via a new cron `infra/box-report-version.sh` → `POST /box/version` (`allowBoxScope`, own resource), wired into the existing `box-source-fetch.sh` self-heal cron list so current boxes pick it up with no re-provision. Migration 121 adds `code_sha` / `code_committed_at` / `code_reported_at` to `builder_boxes` (same report-up shape as the host-keys columns, migration 105).
- The server computes staleness (`boxes.computeCodeStaleness`, pure + unit-tested) by comparing the box's reported commit date to the server's **own deployed commit date** (`src/build-info.js` `commitDate`). A box is stale when it's > 2 days behind, **or** when an active box past a 30-min provision grace has **never reported a version** — which is exactly the signature of a box too old to even run the reporter (the ancient pre-machinery box).
- Surfaced on `GET /box/me` and the `/boxes` Archon roster (via the shared `publicBox` projection), and rendered in the hall as an amber "This box is running old code — Close box, then provision a fresh one to update" banner (`public-builders/box-panel.js`), pointing at the existing Close-box affordance.

### Why visibility, not auto-reset

The tempting "durable fix" is to have the box force itself current (`git reset --hard origin/main`). **Rejected:** a dev box holds the builder's in-progress, uncommitted work. Auto-resetting would silently destroy it — a far worse failure than running slightly old code. `box-source-fetch.sh` already makes the safe move (`pull --ff-only`, which refuses to clobber). When that can't fast-forward, the right answer is to *tell the builder* (so they can commit/stash and rebuild), not to overwrite their tree. Rebuild is the builder's explicit, informed choice.

### Why a rebuild is the only fix for ancient boxes

A box that predates the self-update machinery has no mechanism to pull the fix — including no mechanism to pull *this* reporter. So it never reports, the server flags it stale on the "never reported while active" rule, and the surfaced remedy is a rebuild (Close box → provision fresh, which re-clones current `main` from cloud-init). There is no in-place path; that's inherent, and the flag makes it visible instead of cryptic.

## Consequences

- Stale boxes become **visible and self-explanatory** instead of failing cryptically. Going forward, post-machinery boxes self-update; the flag catches the legacy stragglers and any box whose pull has silently wedged.
- Thresholds (30-min grace, 2-day lag) live in code with the tests, not the schema — tunable without a migration. The 2-day window is deliberately generous so a box mid-pull right after a deploy is never false-flagged; the target is weeks-stale boxes.
- **Follow-ups (out of scope here):** surfacing the same flag in the Dev Box Electron app (a separate release artifact); and optionally a one-click "rebuild" in the hall (today it's the existing Close box → provision).
