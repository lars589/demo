# ADR 0074 — The memory map stays light (budget guard + auto-tidy + drawer)

**Status:** Accepted (2026-06-20) · task [#1362](https://example.com/builders#/task/1362)

## Context

A builder's durable memory is two layers:

- **The map** — `MEMORY.md` (`~/.claude/projects/<proj>/memory/`). The Claude Code harness loads it **in full at the start of every session**. By design it's an *index*: one line per memory — title + pointer + a one-line hook, just enough to judge relevance.
- **The drawer** — the per-topic `*.md` files holding the full facts. They sync to the GDS server (`builder_memory`, via `ship.js`/`pull-memory.js`) and are indexed by `/recall` (ADR 0060). They cost **zero** session tokens until something fetches them.

Only the map is paid for every session, so it must stay small. But nothing kept it small: every session that wrote a memory appended a line, and the "≤200-char, one-line" rule was unenforced. The map re-bloated (entries ballooned into full paragraphs) until the harness's ~24.4 KB hard limit silently **truncated** it — i.e. it started dropping information, undetected. The token-cost audit (tasks 1283/1285/1286) compressed it once by hand, but a one-time fix doesn't hold.

The relevance-fetch half of "load only what's relevant" already exists — `/recall` searches the server memory, and `recall-hints.js` surfaces task-relevant memories at session start for an active claim. The missing piece was keeping the always-loaded map itself light, automatically.

## Decision

Make the map self-maintaining, in `scripts/gds/memory-map.js` (pure, tested) driven from the session-start hook `.claude/hooks/pull-memory.js`:

1. **Guard** — measure `MEMORY.md` each session start; emit one warning line when it's over a soft byte budget *or* has over-long index lines. Silent when healthy.
2. **Auto-tidy** — when it crosses a higher threshold, **demote** the oldest non-rule entries until back under target. *Demote = remove the entry's line from `MEMORY.md` only.* The topic file is untouched — still on disk, on the server, and in `/recall`. Nothing is deleted; cold memories are one query away.
3. **Keep-always** — standing rules (`feedback_*` / `type: user`) and any entry with `pin: true` in its frontmatter are never demoted, regardless of age. Pinning is how the live-version pointer and standing security alerts stay on the map even when they aren't the newest.
4. **Parallel-safe write** — the builder runs many concurrent sessions, so the rewrite is optimistic: re-read just before writing and skip if the file changed since (another session's edit is never clobbered; it tidies next session).

Budgets are tunable constants in `memory-map.js` (`WARN_BYTES`, `TIDY_BYTES`, `TARGET_BYTES`, `MAX_LINE_CHARS`, `KEEP_NEWEST`).

## Consequences

- The always-loaded cost stays bounded automatically; truncation can't sneak up.
- "Newest + rules + pinned" is a deliberately simple relevance proxy. It can demote a still-useful old note — acceptable because demotion is lossless and `/recall` resurfaces it on demand. Pinning is the escape hatch for evergreen entries.
- `.claude/hooks/` is a gate hard-floor, so changes here ship via an owner-approved Gate PR (ADR 0043) — the heavy logic lives in `scripts/gds/memory-map.js` (not a hard floor) to keep the hook diff minimal.
- Future refinement (not built here): a `/memory-compact` skill + a BFG hygiene pass (ADR 0026) that scores relevance richer than recency.
