# `dev-box` module — per-builder cloud dev environments

> The **first** module extracted from core (BV1.R43, [ADR 0083](../../docs/adr/<redacted>.md)). It is the **template** every later module move copies — keep it clean.

Optional feature module: per-builder DigitalOcean droplets + Cloudflare tunnels, the sandbox game preview, and server-mediated branch publish. Gated by `config/modules.json` (`dev-box: true` for the OTB instance; off on a vanilla Cloud Bongos boot). The loader (`src/module-loader/loader.js`) discovers this dir via `module.json` and mounts the route factory.

## The boundary (the one rule)

This module reaches core **only** through the published doorway `../../src/module-api.js` (the semver'd contract; this module needs `coreVersion ^1.2.0`). It must **never** `require()` a core internal (`../../src/bongos/auth`, `../../src/bongos/db`, …) directly, and never another module. Core, in turn, must never `require()` a file in here — that's the forbidden core→module edge this extraction removed. (The fitness check that *enforces* this is BV1.R44/R45; until then it's WARN-mode, but the template models the right pattern.)

## Files

| File | What |
|---|---|
| `routes/box.js` | the HTTP surface — `/box/*` (own box; some `allowBoxScope`) + `/boxes/*` (Archon roster). The loader mounts this; its factory also **registers this module's seams** (idempotent). |
| `boxes.js` | box lifecycle logic + cost ledger. Pure-ish: `pool` is passed in (DI), so it has no core require. |
| `box-access.js` | source-access clawback (`flagBoxReconcileForBuilder`, `decideSourceAccess`). |
| `box-credential.js` | per-box credential provider. |
| `box-onboard.js` | SSH-key validation + connect/settings renderers. |
| `db.js` | the module's data slice — owns `setBuilderBoxBlocked` (the box-blocked write), reached through the doorway `pool`. Lifted out of core `db.js` in BV1.R68 ([ADR 0091](../../docs/adr/<redacted>.md)); box-blocked is cleanly dev-box-owned (this module is its only writer + reader). |

## Seams (how core and this module talk without importing each other)

- **Provides — port `box.hasEverConnected`** `(builderId) → Promise<bool>`. Core (`routes/me.js`, `routes/builders.js`) reads it via `resolveOptional('box.hasEverConnected', async () => false)` so onboarding's `box_connect` step auto-clears when a box is on, and degrades to `false` on a box-less instance.
- **Listens — event `builder.box-reconcile-needed`** `{ builderId, rank, status, actor }`. Core `db.js` emits it (via `emitAsync`) after a rank change / deactivate / auto-graduation; this module flags the droplet reconcile. Replaces the old `db.js → box-access` direct call.

Registration happens in `routes/box.js`'s factory (the loader runs it at boot, already module-gated), guarded by `hasProvider` so re-instantiation in tests can't double-register.

## NOT in this module

- **The network clients** — `scripts/gds/do-api.js` (DigitalOcean), `scripts/gds/cf-tunnel.js` (Cloudflare tunnel), and their shared `scripts/gds/http-api-client.js`. They were operator-CLI-only (never the web process), so they moved OUT to the control-plane tier in BV1 task [#1943](https://example.com/builders#/task/1943) ([ADR 0111](../../docs/adr/<redacted>.md) §2) — the DO client is now shared by `box.js` AND the instance-provisioning runner `provision.js`, which a module→module import could never allow.
- **`scripts/gds/box.js`** — the operator control-plane CLI (sole holder of `DO_API_TOKEN`/`CF_API_TOKEN`, ADR 0031 §9.4). It *requires* this module's `boxes`/`box-access`/`box-onboard` (module data/logic) plus the shared `scripts/gds/do-api`/`cf-tunnel` clients, but it is core ops tooling and stays in `scripts/gds/`.
- **The hall UI** (`modules/hall-ui/public/`: `box-panel.js`, `harbor.js`, the `watch.js` cost section, gated mounts in `builders.js`/`settings.js`). Per-module UI sections are design **phase 6**, not this move; they stay in the hall-ui module (carved in BV1.R85), already gated by `window.__MODULES__.enabled['dev-box']`.
- **`secret-box.js`** — unrelated per-builder secrets crypto; stays in core despite the name.

## Tests

`scripts/gds/smoke-box.sh` + `tests/box*.mjs` (boxes, box_access, box_onboard, box_host_keys, box_cost, box_code_staleness, box_terminal_ssrf, box_connect_e2e, cf_tunnel). They import from `modules/dev-box/…` — except the moved network clients (`tests/boxes.mjs`'s `do-api` import + `tests/cf_tunnel.mjs`) now import from `scripts/gds/…` ([#1943](https://example.com/builders#/task/1943)).
