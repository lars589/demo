// public-builders/dom-utils.js — shared frontend toolkit for the builders' hall
// (GDS-V4 C4 / task 1088). Loaded as the FIRST hall <script> on each page so the
// per-page IIFEs can pull these from one place instead of redefining them.
// Attaches a single global, `window.OTB`.
//
// NOT a consumer: modules/status-ui/public/ (the off-box status mirror) stays
// self-contained by design — do not wire this there. Network helpers
// (getJSON/postJSON/patchJSON) and renderRankBadge are deliberately NOT here:
// the former carry auth-redirect drift that differs per page (and box-panel
// catches its redirect by message), the latter is single-use and coupled to
// the rank-ladder constant (a D1 concern). See
// docs/audits/2026-06-14-repo-cleanup-audit.md §2A/§2B (frontend-utils).
//
// Each util is behavior-equivalent to the copies it replaces. The three real
// drifters are parameterized so every caller keeps its exact behavior:
//   - fmtDate(iso, {time})            date-only (default) vs date+time
//   - toast(msg, {duration, clear})   2200/2600/3200ms; clearTimeout or not
//   - rankLabel(rank, {empty})        '—' (ranks/builders) vs '' (sessions/watch)
(() => {
  'use strict';

  // HTML-escape for text interpolated into innerHTML. (8 byte-equivalent copies.)
  function escapeHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  // querySelector shorthand. (7 copies; pair.js's single-arg form is a subset.)
  const $ = (sel, root = document) => root.querySelector(sel);

  // fmtNum — null/undefined/NaN → '—', else locale-grouped. (builders, work.)
  function fmtNum(n) {
    if (n === null || n === undefined || Number.isNaN(Number(n))) return '—';
    return Number(n).toLocaleString();
  }

  // num — coerce to a finite number; NaN/missing → 0. (sessions, watch.)
  const num = (v) => Number(v) || 0;

  // fmtInt — grouped integer via num(). (sessions, watch.)
  function fmtInt(v) {
    return num(v).toLocaleString('en-US');
  }

  // fmtCompact — 7.8M / 222.5M / 12.3k for big token counts. (sessions, watch.)
  function fmtCompact(v) {
    const n = num(v);
    if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
    return String(n);
  }

  // fmtDate — default date-only (locale default, try/catch guard, matches
  // builders/work); {time:true} → date+time in 'en-US' with an isNaN guard
  // (matches sessions/watch). The two guards differ by design — preserved.
  function fmtDate(iso, { time = false } = {}) {
    if (!iso) return '—';
    if (time) {
      const d = new Date(iso);
      if (isNaN(d.getTime())) return '—';
      return d.toLocaleString('en-US', {
        month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
      });
    }
    try {
      return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
    } catch (_) { return '—'; }
  }

  // rankLabel — the DISPLAY label for a rank enum value. The enum stays Greek
  // (xenos/thetes/metic/archon) by decision; the LABEL is presentation, resolved
  // from the instance branding pack's rankLabels map (R57 / task 1196, ADR 0062
  // §3) so a non-OTB instance can render plain-English ranks. Falls back to
  // capitalizing the enum when the pack carries no label. Falsy rank → `empty`.
  function rankLabel(rank, { empty = '—' } = {}) {
    if (!rank) return empty;
    const map = (window.__BRANDING__ && window.__BRANDING__.rankLabels) || {};
    return map[rank] || (rank.charAt(0).toUpperCase() + rank.slice(1));
  }

  // toast — flash the page's #toast element. Per-page drift: duration
  // (2200/2600/3200) and whether the prior hide-timer is cleared. A
  // module-level timer backs the clear path; each hall page loads one consuming
  // script, so it is effectively per-page.
  let _toastTimer = null;
  function toast(msg, { duration = 3200, clear = false } = {}) {
    const el = $('#toast');
    if (!el) return;
    el.textContent = msg;
    el.dataset.visible = '1';
    if (clear) clearTimeout(_toastTimer);
    _toastTimer = setTimeout(() => { el.dataset.visible = '0'; }, duration);
  }

  // Feature-module gate (R60, task 1199 / ADR 0062 §4). serve-internal.js injects
  // window.__MODULES__ = { enabled: { game, 'art-pipeline', discord, 'dev-box' }, … }
  // synchronously (the same path as window.__BRANDING__), so hall/status pages can
  // hide an off module's UI. Defaults to TRUE when the global or key is missing, so
  // a stale cache / fetch hiccup degrades to showing the full UI, never silently
  // hiding a section on an instance that does have the module.
  function moduleOn(name) {
    const m = window.__MODULES__;
    if (!m || !m.enabled || !(name in m.enabled)) return true;
    return m.enabled[name] === true;
  }

  // Module→core settings-panel contribution seam (BV1.R42, ADR 0083) — the
  // browser twin of the server's 'profile.fields' seam (src/module-seams.js). A
  // module that has left core registers a Settings panel from its own client
  // script (loaded before settings.js, the box-panel.js pattern); settings.js
  // then renders every registered panel instead of hardcoding box/discord/art.
  // Empty until a module registers → the page renders exactly what it does today.
  // A panel: { id, title?, order?, mount(el) } — mount() is handed a container
  // element to render into. order sorts ascending (default 0).
  const _settingsPanels = [];
  function contributeSettingsPanel(panel) {
    if (!panel || typeof panel.mount !== 'function' || !panel.id) {
      throw new Error('contributeSettingsPanel({ id, title?, order?, mount }) requires id + mount()');
    }
    _settingsPanels.push(panel);
    return panel;
  }
  function settingsPanels() {
    return _settingsPanels.slice().sort((a, b) => (a.order || 0) - (b.order || 0));
  }

  // Hall-widget registry (BV1.R75, ADR 0062 §4) — the hall twin of the Settings
  // panel seam above, one altitude up. The hall's section strip + the <section>
  // markup were hardcoded in index.html + a literal SECTIONS array in builders.js;
  // now every widget — core AND module-contributed — registers here, and
  // builders.js mounts the registered set into <main>. A widget:
  //   { id, label, order?, rank?, module?, mount(host) }
  // - id     stable DOM id for the <section> (also the nav anchor target).
  // - label  short Cinzel chip label for the sticky section strip.
  // - order  ascending sort (default 0); render order == strip order.
  // - rank   optional 'archon' → only mounted when /me returns that rank.
  // - module optional module key → only mounted when window.OTB.moduleOn(key).
  //          A disabled module's widget never registers a section (loader.js gates
  //          which client scripts even load; this is the belt-and-suspenders).
  // - mount(host) renders the widget's body into the given <section> element. It
  //          is handed the section so a core widget can fill the static skeleton
  //          (heading + placeholder) builders.js stamps, then loadAll() wires data
  //          to it by id exactly as before.
  // Empty until something registers → builders.js renders the hall it does today
  // once it registers the core widgets unconditionally.
  const _hallWidgets = [];
  function contributeHallWidget(widget) {
    if (!widget || typeof widget.mount !== 'function' || !widget.id || !widget.label) {
      throw new Error('contributeHallWidget({ id, label, order?, rank?, module?, mount }) requires id + label + mount()');
    }
    if (widget.module && !moduleOn(widget.module)) return null; // off module → not registered
    _hallWidgets.push(widget);
    return widget;
  }
  function hallWidgets() {
    return _hallWidgets.slice().sort((a, b) => (a.order || 0) - (b.order || 0));
  }
  // The set of registered widget ids — the fitness check + builders.js use this to
  // assert nothing renders a <section> the registry doesn't own.
  function hallWidgetIds() {
    return _hallWidgets.map((w) => w.id);
  }

  // splitCriterion — a done-when criterion (criterion_md) is authored as a **bold
  // headline** sentence + detail; the headline is the short, scannable label. Returns
  // { label, detail }: label = the leading **headline** (cut at the first " — "
  // elaboration; trailing period + markdown markers dropped); detail = everything else
  // (the em-dash elaboration + the body), markdown-stripped. Falls back to the first
  // sentence when there's no bold lead. Pure. Both hall criteria surfaces (goal view +
  // Work Board) render label-first with the full thorough text one click away, so a
  // long criterion no longer swamps the list (BV1.R79).
  function stripMd(s) {
    return String(s ?? '')
      .replace(/\*\*(.+?)\*\*/g, '$1')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/\s+/g, ' ')
      .trim();
  }
  function splitCriterion(md) {
    const raw = String(md ?? '').trim();
    let headline; let rest;
    const bold = raw.match(/^\*\*([\s\S]+?)\*\*\s*/);
    if (bold) {
      headline = bold[1].trim();
      rest = raw.slice(bold[0].length).trim();
    } else {
      const sentences = raw.split(/(?<=[.!?])\s+/);
      headline = (sentences[0] || raw).trim();
      rest = raw.slice(headline.length).trim();
    }
    let label = stripMd(headline).replace(/[.\s]+$/, '');
    let lead = '';
    // Only trim at the em-dash elaboration when the headline is genuinely long — a
    // short headline keeps its full context (e.g. "Lands in Claude — Desktop and Code").
    const dash = label.indexOf(' — ');
    if (dash > 0 && label.length > 80) {
      lead = label.slice(dash + 3).trim();
      label = label.slice(0, dash).replace(/[.\s]+$/, '').trim();
    }
    const detail = stripMd([lead, rest].filter(Boolean).join(' '));
    return { label: label || stripMd(raw).slice(0, 80), detail };
  }

  window.OTB = {
    escapeHtml, $, fmtNum, num, fmtInt, fmtCompact, fmtDate, rankLabel, toast, moduleOn,
    contributeSettingsPanel, settingsPanels,
    contributeHallWidget, hallWidgets, hallWidgetIds,
    splitCriterion,
  };
})();
