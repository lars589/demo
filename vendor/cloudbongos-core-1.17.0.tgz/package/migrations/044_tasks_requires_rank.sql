-- 044_tasks_requires_rank.sql — V3.R82 (#301): per-task minimum rank gate.
--
-- Context: V3.R15 (migration 039) added `newcomer_friendly` as the row-level
-- gate that LETS A XENOS claim a sensitive-by-default task. This migration
-- adds the INVERSE — a per-task floor that RAISES the minimum required rank
-- above the default (xenos), so some tasks become Metic-only or Archon-only
-- because they touch sensitive infra.
--
-- The two flags compose without contradiction:
--   - requires_rank='xenos'        — the default; anyone may claim (subject to
--                                    the existing xenos sandbox: if the caller
--                                    IS a xenos, newcomer_friendly must also
--                                    be true. This preserves the V3.R15 rule).
--   - requires_rank='metic'        — at least a Metic may claim. Xenos blocked.
--   - requires_rank='archon'       — only an Archon may claim. Xenos+Metic blocked.
--
-- Tier ordering (lowest→highest): xenos < metic < archon. This is the three
-- LIVE ranks in V3 (ADR 0018); reserved-but-not-live ranks stay out of the
-- CHECK enum because Lars chose to wire only three for now (#360). When/if
-- another rank goes live, this CHECK extends in the same migration that wires
-- the new rank.
--
-- View rebuild: claimable_tasks and tasks_session_fit both do SELECT t.*, so
-- the new column flows through implicitly — but the views must be rebuilt
-- (DROP+CREATE) because column-list changes require it (same pattern as
-- migrations 028, 039). View bodies are unchanged.
--
-- View-level filter: the per-rank gate is realized in db.js listClaimableTasks
-- at SELECT time (same pattern as the xenos/newcomer_friendly gate added in
-- migration 039) — views are builder-agnostic (can't read session context).
-- Belt-and-braces: db.claimTask + claimTasksBatch re-check at claim time and
-- throw INSUFFICIENT_RANK (this migration is purely the schema piece; code
-- changes ship alongside).
--
-- Idempotent: safe to re-run.

ALTER TABLE tasks
  ADD COLUMN IF NOT EXISTS requires_rank text NOT NULL DEFAULT 'xenos';

-- Constrain to the three LIVE ranks. NOT VALID would let bad rows slip in;
-- the column has a NOT NULL DEFAULT so every existing row is already 'xenos'.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
     WHERE conname = 'tasks_requires_rank_enum'
       AND conrelid = 'tasks'::regclass
  ) THEN
    ALTER TABLE tasks
      ADD CONSTRAINT tasks_requires_rank_enum
      CHECK (requires_rank IN ('xenos', 'metic', 'archon'));
  END IF;
END $$;

-- Rebuild the two SELECT t.* views so the new column flows through. Bodies
-- identical to migration 039 — only the implicit t.* column list changes.

DROP VIEW IF EXISTS claimable_tasks;
CREATE VIEW claimable_tasks AS
SELECT t.*,
       pms_calibrated_minutes(t.est_minutes, t.kind) AS est_minutes_calibrated
  FROM tasks t
 WHERE t.status = 'ready'
   AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
   AND NOT EXISTS (
     SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id
   )
   AND NOT EXISTS (
     SELECT 1 FROM claims c
       JOIN tasks t2 ON t2.id = c.task_id
      WHERE c.released_at IS NULL
        AND t2.touches && t.touches
   );

DROP VIEW IF EXISTS tasks_session_fit;
CREATE VIEW tasks_session_fit AS
SELECT t.*,
  CASE
    WHEN t.automation_tag = 'overnight-safe' AND COALESCE(t.manual_degree, 5) <= 2
         AND NOT EXISTS (SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id)
      THEN ARRAY['autonomous','check-in','active']
    WHEN t.automation_tag = 'live-only' OR COALESCE(t.manual_degree, 5) >= 4
      THEN ARRAY['active']
    ELSE ARRAY['check-in','active']
  END AS fits_session_modes,
  pms_calibrated_minutes(t.est_minutes, t.kind) AS est_minutes_calibrated,
  CASE
    WHEN t.credits_reward > 0
     AND pms_calibrated_minutes(t.est_minutes, t.kind) IS NOT NULL
     AND pms_calibrated_minutes(t.est_minutes, t.kind) > 0
    THEN ROUND(t.credits_reward::numeric / pms_calibrated_minutes(t.est_minutes, t.kind), 3)
    ELSE NULL
  END AS credits_per_minute
FROM tasks t;

INSERT INTO schema_migrations (version) VALUES ('044_tasks_requires_rank')
  ON CONFLICT (version) DO NOTHING;
