# ADR 0109 — The GDS API is self-describing: generated OpenAPI 3.1 + a hosted `/docs` site

- **Status:** Accepted
- **Date:** 2026-07-03
- **Track:** internal
- **Task:** [#1918](https://example.com/builders#/task/1918) (BONGOS-V1) — Part A of the API-docs + `/api/gds`→`/api/bongos` rename plan.
- **Decides:** how the GDS API is documented so an AI agent (or any tool) can read it, and where that documentation is hosted.
- **Builds on:** [ADR 0016](<redacted>.md) (server-enforced ranks — the gate each endpoint carries), [ADR 0063](<redacted>.md) (the "generate, don't hand-maintain, enforce with `--check`" pattern this copies), [ADR 0062](<redacted>.md) §3 (branding-injected served HTML), [ADR 0108](<redacted>.md) (two-root generator conventions).
- **Informs:** the `/api/gds` → `/api/bongos` URL + naming rename (Part B), which flips the single `src/bongos/api-prefix.js` constant this ADR introduces.

## Context

The GDS API had **no machine-readable contract**. The only endpoint doc was `docs/routes-permissions.md` — a hand-maintained mirror that, by its own admission, drifted from the code (it claimed "154 registrations" against a live ~199). An AI agent hitting the API had nothing standard to consult, and every regeneration of the surface widened the gap. The prompter's ask: *"the GDS API needs to be better documented for AI to read"* and *"host this on cloudbongos.com/docs like others do."*

Two things were already true and shaped the answer:

1. **A route-introspection engine already exists and is CI-enforced.** `src/bongos/route-rank-check.js` (`discoverRouteFiles` + `classifyText` + `classifyRank`) already enumerates every endpoint — method, path, rank gate, source file — across core + every module, because the ship-time rank gate ([ADR 0016](<redacted>.md)) depends on it. It is the natural, non-drifting backbone for docs.
2. **A generator pattern is established** ([ADR 0063](<redacted>.md)): a deterministic file-reader with a `--check` mode wired into `fitness.js` and auto-regenerated at ship. Docs generated the same way cannot rot.

## Decision

**1. Generate an OpenAPI 3.1 spec from the live routes.** A new `scripts/gds/gen-api-docs.js` reuses `route-rank-check.js` to emit `docs/api/openapi.json` (the industry-standard format every tool — Postman, Swagger, Redoc, LLM tool-callers — already reads), plus a generated `docs/api-reference.md`. Each operation carries its rank in an `x-rank` extension + a `security` reference, its path params, and — best-effort from the route's `validateOrRespond` schema — its request-body field names. Endpoints whose body has no validator are marked `x-body-undocumented` and **counted**, so the gap is visible rather than silently absent. The old `docs/routes-permissions.md` is replaced by a generated pointer stub.

**2. Host a rendered docs site at `/docs`.** A vendored Redoc bundle (`public-docs/`, self-hosted — no CDN, matching the `/vendor/*` convention and staying CSP-safe) renders the spec. `serve-internal.js` serves `GET /docs` (branding-injected), `GET /docs/openapi.json` (CORS-open so external tools + AI can fetch it), and `GET /docs/redoc.standalone.js` — in the **shared** `mountInternalSurfaces`, so **every instance is self-documenting for free** and `cloudbongos.com/docs` is the advertised canonical URL. No Caddy change: the `cloudbongos.com` block already proxies non-gate paths to the platform process.

**3. Make the API self-discoverable.** `GET /api/gds` (the base path) returns a small JSON index pointing at `/docs` + the spec, and the API-shaped 404 hint now names `/docs` — so an agent that hits the API bare finds the contract on its own.

**4. Introduce a single prefix chokepoint.** `src/bongos/api-prefix.js` exports `API_PREFIX` (still `/api/gds`), consumed by the mount, the generator, the discovery route, and `context-pack.js`. This is deliberately the seam Part B flips to `/api/bongos` (adding `/api/gds` to `LEGACY_API_PREFIXES` for the permanent dual-mount) — turning a ~1,158-literal rename into a one-line change.

**5. Enforce freshness.** `gen-api-docs.js --check` (which also structurally validates the spec is OpenAPI 3.1) is wired into `fitness.js` and regenerated at ship, exactly like the repo-map / session-index / file-map generators. `npm run docs:api:lint` runs the full standard `@redocly/cli` lint on demand (kept out of the critical path to avoid a heavy dependency; the spec validates clean, zero warnings).

## Alternatives considered

- **A hand-written/OpenAPI-by-annotation spec (JSDoc `@openapi`).** Rejected: it reintroduces exactly the drift that killed `routes-permissions.md`. Generating from the enforced route set is the only non-rotting option.
- **Swagger UI instead of Redoc.** Either works over the same spec; Redoc is a single MIT bundle with a cleaner default read view. The renderer is a presentation choice — the *contract* (openapi.json) is the deliverable, and it is renderer-agnostic.
- **A CDN-hosted renderer.** Rejected: the codebase self-hosts all assets (no CSP today, but one "may be added later") and a self-hosted instance may be air-gapped. Vendoring (~1 MB) is the convention-matching, portable choice.
- **`@redocly/cli` as a hard CI dependency.** Rejected for the critical path: it is a large dependency tree in a deliberately lean, bootstrapped project. A dependency-free built-in structural validator runs in `fitness`; the full standard lint is available via `npm run docs:api:lint`.

## Consequences

- The API is now documented in a standard, tool-consumable format that cannot drift from the code, and is browsable by humans + AI at a stable URL on every instance.
- `docs/routes-permissions.md` is retired to a stub; references were re-pointed at `docs/api-reference.md`.
- Best-effort body extraction leaves 21 write endpoints with undocumented bodies (no validator schema) — a visible, counted backlog; adding a `validateOrRespond` schema surfaces them automatically.
- Part B (the URL rename) is now a one-line flip of `src/bongos/api-prefix.js` + the dual-mount, with the docs regenerating to the new canonical prefix for free.
