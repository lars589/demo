# ADR 0066 — Generated file-map sections (skills + scheduled-tasks) with a sidecar of notes

- **Status:** Accepted
- **Date:** 2026-06-19
- **Track:** internal
- **Builds on:** [ADR 0063](<redacted>.md) (generated symbol skeleton — same "generate, don't narrate" discipline + the `git-merge-regen` self-heal), [ADR 0062](<redacted>.md) §8–§9 (Path C fitness gate + the gen-on-deploy pattern), [ADR 0061](<redacted>.md) (the context-layer docs this keeps honest)
- **Task:** [#1276](https://example.com/builders#/task/1276)

## Context

`docs/file-map.md` is the repo's "where things live" index. Every other self-knowledge doc had already been moved off the honor system: the onboarding diagrams (`gen-diagrams.js`, task 357), the code symbol skeleton (`gen-repo-map.js`, [ADR 0063](<redacted>.md)), and the session-log index (`gen-session-index.js`, [ADR 0062](<redacted>.md) §8) are all **generated and CI-enforced** — so an agent physically cannot forget to update them. `file-map.md` was the last one still hand-maintained.

The cost showed up concretely: task 1267/1269/1272 shipped three new skills (`/ideate`, `/paint`, `/dev`) without adding them to `file-map.md`, which then needed a *separate* doc-hygiene task ([#1274](https://example.com/builders#/task/1274)) just to catch the map up. Worse, an audit while building this found the two enumerable sections had silently drifted into curated **subsets**: `.claude/skills/` had 28 dirs on disk but the map listed ~18 (`recall`, `status`, `builder-box`, `priority-session`, … were simply absent), and `.claude/scheduled-tasks/` had 17 but listed ~6. The map looked complete and wasn't.

The owner's directive: if this logging is critical for the system to know itself, it should happen automatically, not via a hand-filed follow-up task.

## Decision

Generate the two sections of `file-map.md` that are genuinely **"list every item" sets** — `.claude/skills/` and `.claude/scheduled-tasks/` — from what is on disk, and keep the per-entry one-line notes (the prose after the `←`) in a **sidecar** the generator reads.

`scripts/gds/gen-file-map.js` (zero-dependency, deterministic — dirs sorted by name, no timestamps):

1. Walks the immediate subdirectories of each section's dir and renders an aligned tree between sentinel markers (`<!-- BEGIN/END GENERATED FILE-MAP <section>/ -->`) placed **outside** the fenced code block so they don't render. The surrounding prose stays hand-written.
2. Pulls each entry's note from **`docs/file-map.notes.json`** — keyed by section → dir name. This is the one place a human writes these notes (a directory walk can't know what a skill *does*).
3. `--check` mode (the CI gate) fails (exit 2) on any of: a rendered block that differs from what's committed (drift); a dir on disk with **no note** (a skill can't land undescribed); a note whose dir no longer exists (no ghosts).

Wiring (the established three-point pattern):
- **Freshness gate** — added to `fitness.js` `checkGeneratedArtifactsFresh()`, so the DB-free `unit` required check enforces it on every PR (no new workflow).
- **Regenerate-on-deploy** — `ship.js` `regenerateFileMap()` runs it on the same beat as the repo map + session index and commits any change, so the map self-heals even if a builder forgets.
- **Merge self-heal** — `file-map.md` joins the `otb-regen` merge driver (`git-merge-regen.js` + `.gitattributes`): two parallel branches that each add a skill conflict only in the generated block, and the one correct resolution is to 3-way-merge the prose then re-inject both sections from the merged tree.

### Why a sidecar, not per-file markers

The pitch floated a `// @map:` comment in each file. Rejected: it can't work for `.json`/`.sql` files (no comments), the skills' frontmatter `description:` is the verbose Skill-tool trigger blurb (wrong register for a one-line map note), and it would scatter the notes across ~45 files. A single sidecar is uniform across file types, keeps the notes in one reviewable place, and still forces a one-line addition per new skill in the same PR (the gate fails otherwise) — the same "can't forget" property, less churn.

### Why `scripts/gds/` is NOT generated

`file-map.md`'s `scripts/gds/` listing is a deliberately **curated highlight reel** (~20 of ~70 files) and sits mid-tree inside the big fenced repo tree where HTML-comment markers can't live cleanly. Auto-generating it would either bloat it 3× with low-signal entries or require a curation list for little benefit. It stays hand-curated. The two generated sections cover the actual failure mode (a new skill/routine going missing).

## Consequences

- A new skill or scheduled task **cannot** ship without a note in `file-map.notes.json` — the `unit` gate fails — so the doc-hygiene follow-up task (the 1274 pattern) is structurally retired.
- The generation back-filled the ~10 skills + ~11 routines that had silently fallen out of the map; both sections are now exhaustive.
- One more sidecar file to keep in mind, but it's the *only* place those notes live and the gate points an author straight at it.
- Generating only two of file-map.md's many sections is a deliberate scope line; if another section later becomes a churny enumerable set, it can join `SECTIONS` the same way.

## Alternatives considered

- **Presence-only fitness check** (assert every skill/routine appears *somewhere* in the hand-written map). Lighter, but leaves the author hand-writing the line and doesn't fix the tree-art/ordering drift or the latent omissions. The owner chose generation.
- **Fully generate the entire `file-map.md` tree.** Throws away the hand-written framing prose (the intro, the droplet layout, the curated `scripts/` highlights) and the editorial notes; a bare `ls -R` is less useful, not more.
- **Per-file `// @map:` markers** — see "Why a sidecar" above.
