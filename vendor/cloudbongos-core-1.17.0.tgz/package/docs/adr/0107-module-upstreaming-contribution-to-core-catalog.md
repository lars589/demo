# ADR 0107 — Module upstreaming: instances contribute modules into the shared core catalog

- **Status:** Accepted
- **Date:** 2026-07-03
- **Track:** internal
- **Task:** [#1766](https://example.com/builders#/task/1766) (BV1) — the owner-review decision this ADR records + the initiative it seeds.
- **Builds on:** [ADR 0062](<redacted>.md) §1 (portable-core / host-instance / gated feature-module cut-line), [ADR 0083](<redacted>.md) (the module system — loader, manifest, seams, module-owned migrations), [ADR 0098](<redacted>.md) (`isPublishable()` — what a module may contain to enter an AGPL core), [ADR 0065](<redacted>.md) (AGPL-3.0, non-profit, AI-first — and its explicit rejection of CLA-relicensing as "capture").
- **Complements:** [ADR 0100](<redacted>.md) / [ADR 0103](<redacted>.md) — those define the **distribution** arrow (core → instance, a pinned versioned dependency). This ADR defines the **reverse** arrow (instance → core): an instance's module flows *upstream* into the shared catalog. The two arrows together make the module boundary a two-way membrane.

## Context

ADR 0103 makes the Cloud Bongos core its own repository — the product — with instances (Example, Mercury) consuming a pinned core and layering their own modules on top. That is one-directional: fixes and features flow core → instance.

The owner's direction (2026-07-03): an instance also builds feature modules of its own, and **should be able to submit those modules for approval to be merged into the shared core** — so the core accumulates a growing catalog of modules built by the sub-projects, each **credited to its author and its origin project**. A module accepted into core becomes available (opt-in) to *every* instance.

A read-only audit of the current codebase (task [#1766](https://example.com/builders#/task/1766)) established ground truth:

- **The prerequisites are solid.** A validated `module.json` manifest ([`src/module-loader/manifest-schema.js`](../../src/module-loader/manifest-schema.js)), a discover→mount loader with a **one-way import boundary** hard-enforced in CI ([`scripts/gds/fitness.js`](../../scripts/gds/fitness.js) Check 12, [ADR 0102](<redacted>.md)), opt-in **default-off** enablement (`config/modules.json` / `config/modules.neutral.json`), module-owned migrations, and the `isPublishable()` publish boundary that already decides which module *shapes* may enter an AGPL core.
- **The capability is absent.** There is no submission/approval/merge-upstream flow, no catalog/registry (a "marketplace" is an explicitly-deferred future fork in [`docs/design/modular-architecture/01-architecture.md`](../../docs/design/modular-architecture/01-architecture.md)), and the manifest has **no** `author` / `origin` / `license` / `maintainer` fields — adding them fails manifest validation until the schema is extended.
- **The name "contribution seam" is already taken** — it is the in-process UI/profile extension hook (`contribute`/`contributions`, `CORE_VERSION` 1.1.0). This capability must use a distinct name to avoid confusion: **module upstreaming** / **the module catalog**.
- **A CI gap:** contributed-module tests only run in core CI if placed at repo-root `tests/`; the runner does not discover `modules/<key>/tests/`.

## Decision

### 1. The upstreaming flow — submit → review → accept into the catalog.

An instance builds a module in its own repo. To land it in core, a **platform-native submission** (`bongos module submit`) packages the module + its attribution metadata + a sign-off, runs the automated pre-checks, and files it into a **rank-gated review queue on the core** — it does **not** grant the instance write access to core (consistent with ADR 0103's "no direct write access"). On acceptance the module lands in the core `modules/<key>/` tree **default-off**, is added to the `isPublishable()` allowlist, and its attribution is recorded. Every instance may then opt in via `config/modules.json`. *(Standard fork-and-PR remains a fallback, but the native flow is canonical because it captures attribution + sign-off and fits the GDS methodology.)*

### 2. Attribution is portable metadata, not a cross-database link.

Each repo runs its own GDS with its own builder identities ([ADR 0100](<redacted>.md) §3) — there is no shared identity key. So credit **travels with the module**: `module.json` gains `author`, `origin` (origin instance/project), `license`, and `maintainer` fields, captured at submit time. The catalog shows author + origin credit. This is a *record*, not a foreign key.

### 3. Reward: credit now, money later.

Accepted contributions earn **visible credit** (author + origin in the catalog) immediately. Any monetary reward (drachmae) — and the cross-instance identity/payout mechanics it would require — is **explicitly deferred** to a separate economics decision (owner call, 2026-07-03). This keeps the build unblocked and avoids prematurely solving cross-GDS identity.

### 4. Licensing: AGPL-in, sign-off, no CLA.

Core is AGPL-3.0 and [ADR 0065](<redacted>.md) rejected CLA-relicensing as capture. So **inbound = outbound**: a contributed module is accepted under AGPL-3.0 with a lightweight **DCO-style sign-off** (the contributor affirms it is their own work, licensed AGPL) — never a copyright-assignment CLA. The `isPublishable()` pre-check runs at **submit time** and rejects anything that cannot be AGPL'd (game content, pixel art, copyrighted reference material).

### 5. Security review is a hard accept-gate.

A module accepted into core runs **in-process, with full access, in every instance that enables it** — and the "untrusted modules → separate processes" isolation remains a deferred future fork. Therefore acceptance is a **security review**, not a works-check: no module enters the catalog without a reviewer (Metic+/maintainer) clearing it for safety, license, and quality. This is the single highest-risk property of the whole capability.

### 6. Default-off + the publish-allowlist is the accept action.

An accepted module ships `default: false` — instances opt in; none inherits everyone's features. Because a new module directory publishes only if explicitly added to the `isPublishable()` allowlist (default-deny), "accept into core" is a concrete, fail-safe checklist: add to `modules/`, set `default:false`, add to the allowlist, record attribution.

### 7. Maintenance & orphaning policy.

A module pinned to an old `coreVersion` rots as core advances. On acceptance a module either becomes **core-maintained** or carries a named **maintainer** and a deprecation path; `bongos upgrade`'s existing `coreVersion` pre-check surfaces incompatibility. The catalog must not fill with silently-broken entries.

### 8. Sequencing.

The **prerequisites** are direction-agnostic and buildable now in the single repo (dormant until the split): the manifest attribution fields, module-owned test discovery in core CI, and the submit-time AGPL/publish pre-check. The **pipeline** (`bongos module submit` → core-side review/accept → the catalog) depends on there being a core repo to receive into (R88, [#1727](https://example.com/builders#/task/1727)) and a producing consumer (Mercury R85, [#1689](https://example.com/builders#/task/1689)). Do not build the pipeline before the split.

### 9. How it's shown to users — the repo atlas + the Modules tab.

Two user-facing surfaces, both **UI-first** (a non-technical builder must be able to do all of this with clicks — no terminal required; the CLI verbs are the same actions underneath).

- **The repo atlas shows module provenance.** The atlas (`scripts/gds/gen-atlas.js`, `buildModuleView`) gains a clear split so a builder sees, at a glance, **which Cloud Bongos *core* modules this instance loads** versus **which modules the project built itself** (core-loaded vs. own-built). This is the "what am I running, and what's mine" view.
- **A "Modules" tab in the hall** does three jobs:
  1. **Enable / disable access to core modules** — a toggle UI over the enablement layer (`config/modules.json`), with the default-off contract (§6) respected. This is how an instance opts into the core catalog.
  2. **See the project's own modules** — the instance-specific modules it has built, listed distinctly from core.
  3. **Contribute / submit for review** — a UI-first "submit this module upstream" action that runs the §4 pre-check, captures the DCO sign-off, and files the module into the core review queue (§1). It is the clickable front door to `bongos module submit`; a submitted module then shows its review status, and accepted modules appear in the catalog with author + origin credit (§2).

The enable/disable and provenance views are buildable against the existing module system now; the submit-for-review action lights up when the submit pipeline (§8) lands. Tracked by [#1776](https://example.com/builders#/task/1776) (the tab + atlas provenance), with the catalog view in [#1772](https://example.com/builders#/task/1772) and the submit flow in [#1770](https://example.com/builders#/task/1770).

## Alternatives considered (rejected)

- **Fork-and-PR only.** Standard OSS, but loses attribution/sign-off capture and doesn't fit the GDS review/approval methodology. Kept as a fallback, not the canonical path.
- **A CLA granting relicensing rights.** Rejected by [ADR 0065](<redacted>.md) as capture; incompatible with the non-profit posture.
- **Auto-accept / CI-only gate (no security review).** Rejected — a module runs in every enabling instance with no sandbox; unreviewed inbound code is a supply-chain compromise across all instances.
- **Accepted modules default-on.** Rejected — every instance would inherit every contributed feature; breaks the "fail-to-vanilla" default-off contract.
- **A package marketplace now.** Rejected as premature (the design docs defer it); the in-repo catalog is the smaller first step.

## Consequences

- **The module boundary and `isPublishable()` become load-bearing for the *inbound* direction too**, not just outbound distribution — the ADR 0062 / ADR 0102 fitness functions matter more.
- **Core CI must run contributed-module tests** — the runner is extended to discover `modules/<key>/tests/` so contributions are self-contained (closes the audit's CI gap).
- **A review/maintainer role emerges** on the core repo (Metic+), with security + license + quality as the acceptance bar.
- **Cross-instance identity stays an open question**, deferred with the reward economics (§3).
- **Tooling note:** seeding this initiative's goal + criteria + task-attachment + spine consolidation is done via a **guarded data-migration**, because the GDS HTTP API cannot create done-when criteria, attach a task to a goal, or reparent an orphan (only `POST /goals` + goal-less `POST /tasks` + dependencies are API-exposed). That API gap is itself filed as a follow-up — the planning surface should not require hand-written SQL.
