-- 114 — Cloud Bongos rename: rewrite live user-facing DB strings (2026-06-19, task 1244 / ADR 0064).
--
-- The platform was renamed Medusa -> Cloud Bongos (task 1242 / ADR 0064). Migration 111 had baked
-- "Medusa" into LIVE rows the API still serves (/status, the builders' hall, /recall): the GDS-V4
-- C8 + C9 done-when criteria and the R67 dogfood-proof task. Per owner directive (2026-06-19) those
-- live strings are rewritten forward here. Display text ONLY — never the criterion_id keys
-- (medusa-standalone-instance / medusa-open-and-protected, referenced by task_criteria + code) and
-- never schema_migrations version strings. Editing 110/111 directly would break idempotency.
--
-- Case-sensitive REPLACE on 'Medusa' (the platform name) leaves lowercase filenames/keys
-- (seed-medusa-tasks.js, medusa-*) untouched; the CLI 'medusa upgrade' becomes 'cloudbongos upgrade'.
-- Idempotent: REPLACE over already-rewritten text is a no-op. The other 23 R50-R74 task
-- descriptions are deliberately KEPT as history (owner "history preserved" choice).

BEGIN;

-- C8 + C9 done-when criteria — display text only (criterion_id keys stay).
UPDATE done_when_criteria
SET criterion_md = REPLACE(REPLACE(criterion_md, 'Medusa', 'Cloud Bongos'), 'medusa upgrade', 'cloudbongos upgrade')
WHERE version_id = 'GDS-V4'
  AND criterion_id IN ('medusa-standalone-instance', 'medusa-open-and-protected');

-- R67 dogfood-proof task (the owner-flagged live string) — title + description.
UPDATE tasks
SET title = REPLACE(title, 'Medusa', 'Cloud Bongos'),
    description = REPLACE(REPLACE(description, 'Medusa', 'Cloud Bongos'), 'medusa upgrade', 'cloudbongos upgrade')
WHERE source_ref = 'gds-v4-r67';

INSERT INTO schema_migrations (version) VALUES ('114_cloudbongos_rename_live_strings')
ON CONFLICT DO NOTHING;

COMMIT;
