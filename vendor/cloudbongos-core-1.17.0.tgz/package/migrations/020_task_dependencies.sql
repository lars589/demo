-- 020_task_dependencies.sql
-- GDS-V3 / task 309 / V3.R01b — Task dependencies + auto-promotion system.
--
-- Adds a many-to-many task-dependency table and a trigger that auto-promotes
-- non-spike tasks from 'backlog' → 'ready' when their last dependency ships.
--
-- Operating rules (see ADR 0015):
--   * task_dependencies(task_id, depends_on_task_id) is the canonical edge list.
--   * A task is "satisfied" iff every row pointing at it from task_dependencies
--     has the referenced task in status='shipped'.
--   * The trigger fires when a task transitions INTO status='shipped'.
--     It scans every dependent of the just-shipped task. If a dependent is
--     in 'backlog', is NOT a spike, and all its other deps are also shipped,
--     it auto-promotes to 'ready'. Spikes stay in backlog by convention —
--     they're the architectural gates that humans open manually.
--   * Claim-time enforcement (refusing to claim while a dep is unshipped) is
--     handled in the application layer (src/bongos/db.js createClaim).

BEGIN;

-- ============================================================================
-- 1. task_dependencies table
-- ============================================================================
CREATE TABLE IF NOT EXISTS task_dependencies (
  task_id            bigint NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  depends_on_task_id bigint NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  created_at         timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (task_id, depends_on_task_id),
  CONSTRAINT no_self_dep CHECK (task_id <> depends_on_task_id)
);

-- "What does X depend on?" (forward edge)
CREATE INDEX IF NOT EXISTS idx_task_deps_task
  ON task_dependencies (task_id);

-- "What depends on Y?" (reverse edge — used by the auto-promotion trigger)
CREATE INDEX IF NOT EXISTS idx_task_deps_depends_on
  ON task_dependencies (depends_on_task_id);

-- ============================================================================
-- 2. Auto-promotion trigger
-- ============================================================================
-- Fires AFTER UPDATE OF status when the new status is 'shipped'. Looks for
-- backlog tasks that depend on the just-shipped one, AND whose remaining
-- deps are also all shipped, AND that are not kind='spike'. Promotes them
-- to 'ready'.
--
-- We deliberately do NOT touch tasks in any other status (active, blocked,
-- completed, etc.) — auto-promotion only kicks in from 'backlog'. If a task
-- was manually promoted earlier and is mid-flight, the trigger leaves it
-- alone.

CREATE OR REPLACE FUNCTION promote_dependents_on_ship()
RETURNS TRIGGER AS $$
BEGIN
  -- Only fire on transition INTO 'shipped'
  IF NEW.status = 'shipped' AND (OLD.status IS DISTINCT FROM 'shipped') THEN
    UPDATE tasks t
       SET status = 'ready',
           promoted_at = COALESCE(t.promoted_at, now()),
           updated_at = now()
     WHERE t.status = 'backlog'
       AND t.kind <> 'spike'
       AND EXISTS (
         SELECT 1 FROM task_dependencies td
          WHERE td.task_id = t.id
            AND td.depends_on_task_id = NEW.id
       )
       AND NOT EXISTS (
         -- still has at least one unshipped dep
         SELECT 1 FROM task_dependencies td2
           JOIN tasks dep ON dep.id = td2.depends_on_task_id
          WHERE td2.task_id = t.id
            AND dep.status <> 'shipped'
            AND dep.id <> NEW.id  -- the one we just shipped counts as shipped
       );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_promote_dependents_on_ship ON tasks;
CREATE TRIGGER trg_promote_dependents_on_ship
  AFTER UPDATE OF status ON tasks
  FOR EACH ROW
  EXECUTE FUNCTION promote_dependents_on_ship();

-- ============================================================================
-- 3. Bump migration counter
-- ============================================================================
UPDATE migration_counter SET next_number = GREATEST(next_number, 21) WHERE id = 1;

-- ============================================================================
-- 4. Record migration
-- ============================================================================
INSERT INTO schema_migrations (version) VALUES ('020_task_dependencies')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
