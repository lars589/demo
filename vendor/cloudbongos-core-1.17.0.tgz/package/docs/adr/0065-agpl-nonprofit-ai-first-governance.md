# ADR 0065 — Cloud Bongos is AGPL-3.0, non-profit, and AI-first

- **Status:** Accepted
- **Date:** 2026-06-19
- **Track:** internal
- **Task:** [#1207](https://example.com/builders#/task/1207) (V4.R68) — the foundational decision for the C9 open-source track.
- **Builds on:** [ADR 0062](<redacted>.md) (the instance-model build platform — defines the portable core / host instance / feature-module cut-line this ADR releases), [ADR 0064](<redacted>.md) (the platform is named **Cloud Bongos**), [ADR 0016](<redacted>.md) (the server-enforced trust boundary — survives open-sourcing untouched).
- **Gates:** [#1208](https://example.com/builders#/task/1208) (R69 LICENSE file), [#1209](https://example.com/builders#/task/1209) (R70 governance docs), [#1210](https://example.com/builders#/task/1210) (R71 public mirror + carve-out), [#1211](https://example.com/builders#/task/1211) (R72 delayed export pipeline), [#1212](https://example.com/builders#/task/1212) (R73 lineage-consistency proof). This ADR is the decision those five tasks implement.

## Context

[ADR 0062](<redacted>.md) decoupled the GDS into **Cloud Bongos** — a configurable, self-hostable build platform where AI agents claim tasks and ship code, with a human owner setting scope and the hard gates. Example (the Off the Boats game) becomes **customer 1** running on it; Cloud Bongos runs on its own plain vanilla brand as **customer 0** and builds itself.

Criterion **C9 (`medusa-open-and-protected`)** commits Cloud Bongos to being *open, free, and protected from capture*: released to the public as open source on a deliberate, delayed cadence. Three questions had to be answered before any of R69–R73 could be built, because each is downstream of the answer:

1. **Which license?** The choice determines whether a well-funded operator can take the code, host it as a closed SaaS, and out-compete the project that produced it.
2. **What is the governance posture?** Whether the project is a commercial concern that monetizes its contributors, or a non-profit commons.
3. **Who writes the code, and is that a rule or a norm?** Cloud Bongos is AI-first by construction; the open-source release has to say what that means for outside contributors.

The owner locked the answers in the 2026-06-17 planning session ([log](../session-logs/<redacted>.md)). This ADR records them and the alternatives rejected, so R69–R73 build against one decision instead of re-litigating it five times.

## Decision

### 1. License: AGPL-3.0

Cloud Bongos is released under the **GNU Affero General Public License, version 3.0 (AGPL-3.0)**.

The AGPL's distinguishing clause (§13) closes the **hosted-closed-fork loophole**: anyone who runs a modified Cloud Bongos as a *network service* must offer that service's complete corresponding source to its users. A plain GPL would let a SaaS operator modify the platform and never distribute a binary — the modifications stay private because nothing is "distributed" in the GPL sense. The AGPL treats "you can use it over the network" as the trigger. This is the **only license consistent with the anti-monopoly goal** in C9: it keeps the platform a commons even when it is operated, not just when it is shipped.

The license covers the **publishable subset only** — the portable methodology core, the Cloud Bongos platform code, the neutral (customer-0) branding, and sanitized docs/ADRs. It does **not** attach to a host instance's private identity, secrets, content, or operational infrastructure (see §4). An instance owner's own branding pack and game/world content remain theirs.

### 2. Governance: non-profit, capture-resistant

The project is run as a **non-profit**: it is **not monetized from its contributors**, and it is structured so no single party can capture it.

- No contributor pays to contribute, and no contribution is resold as a proprietary add-on by the project.
- The drachmae/credit economy ([ADR 0054](<redacted>.md)) is an **instance-internal** mechanism — it rewards builders on a given instance out of that instance's own budget; it is not the project monetizing the commons. It ships as a feature an instance configures, not as a revenue stream flowing to a central owner.
- The AGPL is the legal backstop; the non-profit posture is the social one. Together they are the "protected from capture" half of C9.

Optional **managed-hosting** (operating instances for owners) was captured as a post-C8 idea in the planning session. If it is ever built, it is a service offered *on top of* the same AGPL artifact — it does not change the artifact's license or the non-profit posture of the platform itself.

### 3. AI-first is a documented norm, not a technical gate

Cloud Bongos is **AI-first**: the expectation is that **AI agents write the code** — a human owner sets scope, direction, and the hard gates (rank, approval, deploy); the day-to-day building is done by AI agents claiming tasks.

This is a **documented norm folded into governance/methodology, not a technical gate**. We do *not* add machinery that detects or blocks human-authored commits. The norm is stated in CONTRIBUTING (R70) and lives in the portable methodology core (CLAUDE.md, [ADR 0061](<redacted>.md)); enforcement is cultural and reviewable, the same way the "every change is backed by a claimed task" rule is. An instance is free to relax it; the project ships it as the default expectation because the whole methodology — the grader, the session-token economy, the claim lifecycle — is designed around agents as the primary authors.

### 4. The public-mirror boundary (jointly defined with R50)

What is published is the **portable core + platform, never a host's private surface**. Concretely, the publishable subset is:

- **Published:** the portable methodology core (CLAUDE.md framing, the claim→ship lifecycle, the trust-boundary/rank machinery), the GDS platform code (`src/bongos/*`, `scripts/gds/*` minus instance literals), the neutral customer-0 branding (`config/branding.neutral.json`), the docs/ADRs (sanitized), and the skills that drive the methodology.
- **Not published:** secrets and credentials, a host instance's identity literals (domains, IPs, owner, OAuth app, repo), live DB contents, prod operational infra, customer-1 (Example) game/art content and brand pack, and **anything inside the redaction window** — the public mirror lags the private repo by **~6 months** so an operator can never track head-of-line development in real time (R72).

The mirror is **generated** from the private Example repo by the delayed-export pipeline (R72), not maintained as a hand-curated fork; R73 proves private↔public lineage consistency and no-leak. This boundary is the same §1 cut-line ADR 0062 drew (portable core / host instance / gated feature-modules) — open-sourcing it just means the *core* side of that line is the thing that ships, and R71 carves the subtree to match.

## Alternatives considered (rejected)

- **MIT / BSD / Apache-2.0 (permissive).** Maximum adoption, but a permissive license **does not close the hosted-closed-fork loophole** at all — a funded operator could fork, close, and out-host the commons with zero obligation. Directly contradicts "protected from capture." Apache-2.0's explicit patent grant is a real virtue, but not enough to outweigh the capture risk. Rejected.
- **GPL-3.0 (copyleft, no network clause).** Copyleft on *distribution*, but the **SaaS loophole** stays open: run a modified copy as a network service and you never "distribute," so the modifications stay private. For a platform whose primary deployment mode is *being operated over the network*, GPL is copyleft with the relevant case carved out. AGPL is GPL-3.0 plus exactly the clause we need. Rejected in favor of AGPL.
- **Source-available / BSL (Business Source License), commons-clause, "open-core."** Would let the project monetize hosting or gate features, but it is **not open source** (fails the OSI definition / DFSG), conflicts with the non-profit posture, and reintroduces the central-capture risk we are trying to design out. Rejected.
- **Dual-license / CLA-backed relicensing.** A contributor license agreement assigning rights to a central entity is the standard path to *later* relicensing (i.e., the capture move we are guarding against). Rejected as inconsistent with the non-profit, capture-resistant posture. Inbound contributions are inbound=outbound under the AGPL (the standard for AGPL projects).

## Consequences

- **R69–R73 have one decision to build against.** R69 drops the AGPL-3.0 `LICENSE` file; R70 writes GOVERNANCE/CONTRIBUTING/CODE_OF_CONDUCT encoding the non-profit + AI-first norms decided here; R71 carves the publishable subtree to the §4 boundary; R72 builds the 6-month-delayed redacted export; R73 proves lineage + no-leak.
- **The trust boundary and rank ladder are unaffected.** Server-enforced permissions ([ADR 0016](<redacted>.md)) and the Greek rank enum ([ADR 0062](<redacted>.md) planning lock) are core methodology; open-sourcing the code does not weaken them — an instance's authority still lives in its own DB, checked server-side, regardless of who can read the source.
- **Downstream operators inherit the AGPL obligation.** Anyone hosting a modified Cloud Bongos owes their users source. That is the intended effect, not a side effect.
- **No new infrastructure or recurring cost** from this decision itself; it is a license + posture choice. The export pipeline (R72) has its own cost profile, evaluated under its task.
