# ADR 0018 — The three-rank model goes live (Xenos → Metic → Archon)

**Date:** 2026-05-27
**Context:** Task [#360](https://example.com/builders#/task/360), follow-up to the V3.R86 ([#305](https://example.com/builders#/task/305)) CLAUDE.md audit. Advances GDS-V3 criterion
C2 (`three-ranks-gate-everything`). Builds on (and partially supersedes) [ADR 0016](<redacted>.md).
**Status:** Accepted.

## Problem

The V3.R86 audit surfaced that the project carried **two conflicting rank models**:

- **Enforced** (migration 023 / task [#106](https://example.com/builders#/task/106)): a deliberately-minimal **two-rank** model — `archon`
  plus `thetes` as the default for any new builder, with `xenos` used only as the
  deactivation/offboarding tier (migration 025). `metic` was reserved but unwired.
- **Planned** (the V3 planning seed's criterion C2 + the skills): a **three-rank** model — **Xenos**
  (default, sandboxed: read-only + ship only explicitly-open tasks), **Metic** (Archon-approved
  working rank: full claim/ship + idea triage + blocker review + planning/priority sessions),
  **Archon** (rank promotion, ratification, version close, infra).

The two models *disagreed on fundamentals*: the default rank (`thetes` vs `xenos`), the name of the
approved working rank (`thetes` vs `metic`), and the role of `xenos` (exit tier vs entry tier).
Several skills (`priority-session`, `planning-session`) gate on a `Metic+` rank that wasn't live, and
`priority-session`'s gate (`xenos`→block, `metic|archon`→proceed) didn't even handle a live `thetes`.
This is exactly the doc↔DB drift ADR 0016 warns about, except here the *plan of record* (criterion
C2) was the three-rank model while the *implementation* shipped two.

Lars chose to resolve it by **wiring the three-rank model for real** rather than ratifying the
two-rank reality.

## Decision

Three ranks are now LIVE: **`archon`** (top), **`metic`** (approved working rank), **`xenos`**
(sandboxed entry default). `thetes` becomes reserved. The 16-value CHECK enum (migration 023) is
unchanged — `metic` and `xenos` were already reserved values, so going live is a code + default
change, not an enum migration.

### What each live rank can do

| Operation | Xenos | Metic | Archon |
|---|:--:|:--:|:--:|
| Read public surfaces, `/me` | ✅ | ✅ | ✅ |
| File an idea / blocker, capture a learning, log cost | ✅ | ✅ | ✅ |
| Claim + ship **own** work | only `xenos_claimable` tasks | any ready task | any ready task |
| Idea triage (`PATCH /inbox/:id`) | ❌ | ✅ | ✅ |
| Blocker review (`POST /blockers/:id/{resolve,link}`) | ❌ | ✅ | ✅ |
| Planning / priority sessions | ❌ | ✅ | ✅ |
| Create / promote / edit tasks, deps, confirm, done-when scope | ❌ | ❌ | ✅ |
| Grant/revoke rank, offboard, version close, infra | ❌ | ❌ | ✅ |

> **Update (2026-06-26, [ADR 0090](<redacted>.md)):** the *"Create / promote / edit tasks, deps"* part of row 7 moved to **✅ for Metic** — a Metic may now author + shape tasks (`POST /tasks`, `PATCH /tasks/:id`, `POST /tasks/:id/promote`, and the `tasks/:id/{dependencies,criteria}` CRUD). `confirm` (grader-bypass), `done-when` *scope*-setting, abandon, rank, and version-close stay Archon-only (row 8 is unchanged). The table above is preserved as the 2026 record; ADR 0090 is the current authority.

### Mechanisms

- **Default flip (migration 029):** `builders.rank` DEFAULT `'thetes'` → `'xenos'`. Not retroactive;
  affects only builders created from now on. Blast radius today is zero (only `example-owner`/archon exists).
- **Xenos sandbox (migration 029 + `db.claimTask`/`claimTasksBatch`):** new column
  `tasks.xenos_claimable boolean NOT NULL DEFAULT false`. A `xenos` may claim a task only if it's
  `true`; otherwise the claim path throws `XENOS_RESTRICTED` (→ 403). An Archon opens a task to Xenos
  via `PATCH /api/gds/tasks/:id { xenos_claimable: true }`. This is a **row-level** rule, not a route
  gate — it can't live in `requireRank` because it depends on the specific task being claimed.
- **Metic route grants:** the triage/review routes criterion C2 assigns to Metic widened from
  `requireRank('archon')` to `requireRank('metic','archon')`: `PATCH /inbox/:id`,
  `POST /blockers/:id/{resolve,link}`. Everything that mutates *plan/scope* (task create/promote/edit,
  dependencies, confirm, done-when, rank, version close) stays Archon-only — the fail-closed default.

### Why this didn't need skill changes

Adopting the three-rank model makes the skills' *existing* rank checks correct without edits:
`priority-session`'s gate (`xenos`→stop, `metic|archon`→proceed) is now exactly right because `metic`
is a real promotable rank and `xenos` is the real default. The per-skill *enforcement flips* that are
still advisory (e.g. `planning-session` → V3.R88) remain their own tasks; this ADR makes the ranks
they reference real.

## Consequences

**Good:**
- Target (criterion C2) and shipped now agree; the doc↔DB divergence the audit found is closed.
- A new teammate starts sandboxed and is *deliberately* promoted to Metic before they can ship freely
  — the "vet before they can ship" property C2 wanted.
- The trust boundary is unchanged in shape: authority still lives in `builders.rank`, checked
  server-side per request with no caching (ADR 0016). This ADR only widens *which* ranks are granted.

**Costs / follow-ups:**
- New surface to keep gated: any future Metic-eligible review route must remember `requireRank('metic','archon')`;
  any plan-mutating route stays `archon`. The periodic auditor ([#266](https://example.com/builders#/task/266)/[#267](https://example.com/builders#/task/267)) covers the "no ungated
  privileged route" half but does **not** assert the *correct* rank — that stays a review concern.
- **Not** in scope here (tracked separately): per-skill enforcement flips (`planning-session` V3.R88),
  marking criterion C2 fully satisfied (Archon does that after verifying the `/builders` hall shows
  rank + the auditor is green), and updating the onboarding rank-ladder diagram
  (`docs/onboarding/diagrams/02-rank-ladder.mmd`, which lives on a newer `main` than this branch).

## Supersedes

The "two-rank V3 scope (Archon + Thetes) is deliberately minimal" bullet in
[ADR 0016 §Consequences](<redacted>.md#consequences) is
superseded: the middle/entry ranks are no longer all reserved-and-unwired — `metic` and `xenos` are
live as of this ADR.
