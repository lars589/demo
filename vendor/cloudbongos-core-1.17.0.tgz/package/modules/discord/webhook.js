// modules/discord/webhook.js — the module's outbound Discord webhook poster
// (BV1.R47 / task 1416).
//
// A near-verbatim twin of scripts/discord/lib.js. Why a copy and not a shared
// require: the module boundary (ADR 0083) forbids a module reaching into core or
// scripts/, and the kernel doorway must not name a module — so the poster a
// module needs lives IN the module. scripts/discord/lib.js stays for the two CORE
// consumers that still post webhooks (src/bongos/approval-broadcast.js + the
// scripts/discord/post.js CLI). KEEP THE TWO IN SYNC — same channels, same
// 2000-char cap, same allowed_mentions suppression (#871). Config is read through
// the published doorway (configPath) so the path resolves identically.
//
// Discord is a one-way window into the GDS (the trust-boundary ADR): this only
// ever POSTs outward — it never reads authority or state back.

'use strict';

const fs = require('node:fs');
const api = require('../../src/module-api');

// The configured instance config dir (OTB → ~/.config/otb, unchanged). R61.
const WEBHOOKS_PATH = api.configPath('discord-webhooks.json');

// Known channel keys. Each maps to a webhook URL in the file above, or to the
// env var DISCORD_<KEY>_WEBHOOK (upper-cased), which wins when set. Mirrors
// scripts/discord/lib.js exactly.
const CHANNELS = new Set([
  'ship_news', 'ship_feed', 'security_ship_feed',
  'member_approvals',
]);

function loadWebhooks() {
  let cfg = {};
  try {
    cfg = JSON.parse(fs.readFileSync(WEBHOOKS_PATH, 'utf8'));
  } catch {
    // File is optional when the URLs are provided via env vars instead.
  }
  for (const ch of CHANNELS) {
    const envVal = process.env[`DISCORD_${ch.toUpperCase()}_WEBHOOK`];
    if (envVal) cfg[ch] = envVal;
  }
  return cfg;
}

async function postWebhook(channel, text) {
  if (!CHANNELS.has(channel)) {
    throw new Error(`Unknown Discord channel '${channel}'. Known: ${[...CHANNELS].join(', ')}`);
  }
  const url = loadWebhooks()[channel];
  if (!url) {
    throw new Error(
      `No webhook URL for channel '${channel}'. Set it in ${WEBHOOKS_PATH} ` +
      `or env DISCORD_${channel.toUpperCase()}_WEBHOOK. See scripts/discord/README.md.`
    );
  }
  // Discord hard-caps message content at 2000 chars.
  const content = String(text).slice(0, 2000);
  // SECURITY (#871): suppress ALL mention pings. The content is DB-sourced and
  // attacker-influenceable; allowed_mentions:{parse:[]} renders text verbatim but
  // fires zero notifications. (Discord defaults to parsing mentions when omitted.)
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content, allowed_mentions: { parse: [] } }),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`Discord webhook POST -> ${res.status}: ${body.slice(0, 300)}`);
  }
  return { ok: true, status: res.status }; // 204 No Content on success
}

module.exports = { CHANNELS, WEBHOOKS_PATH, loadWebhooks, postWebhook };
