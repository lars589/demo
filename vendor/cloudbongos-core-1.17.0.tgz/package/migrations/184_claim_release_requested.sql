-- 184_claim_release_requested.sql — the flag-for-release nudge (task 1736).
--
-- A goal owner/manager resolving a task conflict (GET /goals/:id/conflicts →
-- POST /goals/:id/conflicts/resolve, action 'flag_release') asks the holder of
-- the task's ACTIVE claim to wrap up or release. The flag is a soft nudge, not
-- an eviction: nothing about the claim's validity changes; the holder sees it
-- on their own claim reads (getActiveClaimsForBuilder → /api/gds/me).
--
-- Lives in core migrations/ (not modules/lifecycle/migrations/) because it
-- ALTERs the SHARED claims table — a module migration may only touch its own
-- namespaced objects (ADR 0083 §Decision #5; the fitness check enforces it).
--
-- Purely additive + idempotent; replay-safe on a fresh DB (no data touched).

BEGIN;

ALTER TABLE claims
  ADD COLUMN IF NOT EXISTS release_requested_by   bigint REFERENCES builders(id),
  ADD COLUMN IF NOT EXISTS release_requested_at   timestamptz,
  ADD COLUMN IF NOT EXISTS release_requested_note text;

INSERT INTO schema_migrations (version) VALUES ('184_claim_release_requested')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
