# 0014 — `families.json` is canonical over `vocabulary.json` for any shared id

- **Status:** Accepted
- **Date:** 2026-05-11
- **Deciders:** Lars
- **Track:** `internal` (art pipeline)
- **Extends:** [ADR 0008-a](./<redacted>.md) (family-based tile generation), [ADR 0009](./0009-autotile-architecture.md) (autotile architecture)

## Context

The pixel-art pipeline grew in two phases:

1. **Phase 0** seeded `art/template/vocabulary.json`. Each entry is one
   atomic tile or sprite, generated one-at-a-time, scored against the
   per-tile rubric.
2. **Phase 1+** introduced `art/template/families.json`. A family is a
   *group* of related members (a player spritesheet, the 8 container
   panels, an autotile family). Families carry richer metadata: edge
   contracts, color profiles, member kinds, anchor refinement,
   deterministic checks, layout cell coordinates, sliceable strategies.

Both files coexisted while families were being migrated from per-tile
generation. That migration is now far enough along that several ids
appear in *both* files:

- `player_down_idle`, `player_up_idle`, `player_left_idle`,
  `player_right_idle` — vocab + `player_character` family members
- `rock_small` — vocab + `rock` family member
- `vendor_hyperion` — vocab id + `vendor_hyperion` family id (whose
  members are `vendor_hyperion_idle` / `..._talk`)
- `marble_path` — vocab id + autotile family id

Duplication has two failure modes:
1. **Drift.** A descriptor or `game_key` updated in one file but not
   the other. Whichever file the running pipeline reads from "wins"
   silently; the other becomes stale.
2. **Double-publish.** `build_tilesheet.py` writes every vocab entry
   then every family member. Same id from both sources overwrites the
   manifest entry twice — order-dependent, fragile.

We need one canonical source for any id that has both representations.

## Decision

**We will treat `families.json` as the canonical source for any id that
appears in both files.** `vocabulary.json` is reserved for legacy
per-tile entries that are *not* covered by any family — atomic singletons
from Phase 0 (e.g. `amphora`, `column_base`, `olive_tree`) that have not
yet been migrated to a family and may never need to be.

Concretely:

1. Vocabulary entries whose `id` matches any of (a) a family id,
   (b) a family member id, or (c) an autotile family id are **removed**
   from `vocabulary.json`. As of GDS [#139](https://example.com/builders#/task/139) that's 7 entries:
   `marble_path`, `player_{down,up,left,right}_idle`, `rock_small`,
   `vendor_hyperion`.
2. `build_tilesheet.py` builds the set of "family-owned" ids at the top
   of `main()` and silently skips any vocab entry whose id is in that
   set. This is defense in depth — even if a future edit re-introduces
   an overlapping vocab entry, families.json wins by construction.
3. Future migrations (e.g. `amphora` → an amphora family) follow the
   same pattern: add the family entry to `families.json`, then remove
   the now-redundant entry from `vocabulary.json` in the same change.
4. `vocabulary.json`'s `_comment` field documents this canon rule and
   points back at this ADR.

## Alternatives considered

- **Merge both files into one `assets.json`.** Cleaner long-term but
  the rubric / schema / orchestrator code-paths are different enough
  (per-tile review vs. family review with deterministic gates) that
  merging now would invite churn. Defer until Phase 0 is fully drained.
- **Keep both files, prefer vocabulary.json when both define an id.**
  Backwards but symmetrical. Rejected because families.json carries
  strictly more metadata — the deterministic checks, color profiles,
  and edge contracts are not expressible in the vocabulary schema, so
  preferring vocabulary would be a regression in fidelity.
- **Auto-generate vocabulary.json from families.json at build time.**
  Possible but introduces a generated-file invariant we'd have to
  guard in CI. The remaining 16 vocab-only entries don't justify the
  tooling cost yet.

## Consequences

- **One file owns each id.** No more drift between two
  descriptors for the same sprite.
- **Per-tile pipeline still works** for legacy entries — Phase 0
  outputs continue to land at `art/generated/tiles/<id>.png` and get
  published by the vocabulary loop. Nothing about the orchestrator
  changes.
- **build_tilesheet.py is monotone:** for any given manifest id, exactly
  one publishing pass writes it. The order of (vocab pass → family pass
  → autotile pass) is no longer load-bearing, because the vocab pass
  skips family-owned ids up front.
- **Migration motion is mechanical.** Promoting a vocab entry to a
  family: add the family, remove the vocab entry, regenerate. The
  scanner / smoke tests catch any regression at the manifest level.
- **No game-side change.** Both `key` (vocab) and `game_key` (family)
  resolve to the same texture-key conventions used by Player.js /
  vendorSprite.js / tilePalette.js. The texture keys the game asks
  for (`player_down`, `vendor_idle`, `tex_rock_small`, etc.) are all
  still defined in the manifest after the dedup.
