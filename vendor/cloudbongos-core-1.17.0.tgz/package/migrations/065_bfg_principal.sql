-- 065_bfg_principal.sql — BFG service principal + cross-builder memory WRITE
-- substrate (MAS Phase 6 sub-phase 6C.1, ADR 0026 §6C).
--
-- THE trust-boundary exception (extends ADR 0016): this lands the IDENTITY half
-- of the first cross-builder memory WRITE capability in the system. The write
-- endpoint (src/bongos/routes/memory.js) gates on the EXACT principal identity
-- (builders.system_role = 'bfg'), NOT on rank — so an Archon token, or any
-- rank-escalated / stolen token, is rejected at the write endpoint (ADR 0026:
-- "gate on the exact principal identity, not on rank"). The principal:
--   * cannot claim work — status='inactive' reuses the existing db.claimTask
--     guard (BUILDER_INACTIVE), so no new claim-path code is needed;
--   * cannot earn drachmae — it never claims/ships, so credit_log never grows
--     for it (and it's rank='xenos', which carries no authority anyway);
--   * is not loginable — github_id 'system:bfg' is non-numeric, so the GitHub
--     OAuth upsert path (numeric ids) can never produce or authenticate it.
--
-- karma_log.reason is free-text (migration 040) — no schema change is needed to
-- "add" a reason. This migration DOCUMENTS the new BFG vocabulary so the value
-- is discoverable in one place:
--   karma_log.reason  'bfg_correction'        — a transparent, attributed
--                       negative karma delta the BFG applies ALONGSIDE a visible
--                       corrective memory note (wired in 6C.2). granted_by = the
--                       BFG principal id.
--   audit_log action  'bfg_dream_write' /     — recorded per cross-builder write
--                     'bfg_correction_write'    by the write endpoint (the
--                       audit_log.method CHECK only allows write verbs, so the
--                       true semantics live in request_body_redacted.action,
--                       mirroring the Archon forensic-read pattern).

-- 1. system_role marker: NULL for every human builder, 'bfg' for the principal.
--    The write endpoint's identity gate keys on this exact value.
ALTER TABLE builders ADD COLUMN IF NOT EXISTS system_role text;

-- At most one row per system role (a second 'bfg' row is a bug, not a feature).
CREATE UNIQUE INDEX IF NOT EXISTS idx_builders_system_role
  ON builders (system_role) WHERE system_role IS NOT NULL;

-- Defense-in-depth allowlist: system_role may only be NULL or a KNOWN system
-- role. The app-layer gate (requireBfgPrincipal) checks exact equality, but a
-- DB-level CHECK means even raw SQL or a future careless update route cannot
-- mint an arbitrary system_role and ride a (hypothetically relaxed) gate. A new
-- system principal in the future widens this CHECK in its own migration — an
-- intentional, reviewable act, not an accident. Idempotent via pg_constraint.
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'builders_system_role_check') THEN
    ALTER TABLE builders
      ADD CONSTRAINT builders_system_role_check
      CHECK (system_role IS NULL OR system_role IN ('bfg'));
  END IF;
END $$;

-- 2. The BFG service principal. Idempotent via NOT EXISTS (the #476 guard for
--    hardcoded natural keys — re-running this migration is a no-op). All three
--    NOT NULL columns without defaults (github_id, github_login, display_name)
--    are provided; rank/status are set explicitly though they have defaults.
INSERT INTO builders (github_id, github_login, display_name, rank, status, system_role)
SELECT 'system:bfg', 'bfg-system', 'The BFG (system)', 'xenos', 'inactive', 'bfg'
WHERE NOT EXISTS (SELECT 1 FROM builders WHERE system_role = 'bfg');
