# Session-end handoff — template

> **Use this at the end of every working session.** Write your entry as its own dated file `docs/session-logs/YYYY-MM-DD-<slug>.md`. Soft cap: ~400 words per entry. The next Claude session — or the next human — should be able to pick up cold from this. **You never touch an index by hand:** the CLAUDE.md §13 recent-sessions snippet and the full `docs/session-log-index.md` are generated from the files and regenerate at ship (`scripts/gds/gen-session-index.js`).

---

## Template (copy this block)

```markdown
### YYYY-MM-DD — {short title of what shipped or what was attempted}

**What shipped (with confidence tags):**
- [verified-prod] {thing that was tested end-to-end on the live site by a real human}
- [verified-smoke] {thing that passed an automated smoke test but wasn't manually verified}
- [implemented-not-verified] {thing that compiles and deploys but hasn't been touched yet}

**What's broken or unverified:**
- {anything that's known not to work, or known to be untested — be honest, don't paper over}

**Manual checks the next session should run first:**
- {one-line action} → {expected result}
- {repeat for each check}

**Next obvious work:**
- {the thing the next session should pick up, with enough context to start without re-reading much}

**New limitations / risks / blockers introduced this session:**
- {new V1 architecture limitation → added to limitations/current-version.md}
- {new ops gotcha → long-form recipe under docs/recipes/, OR short rule via `node scripts/gds/learning-capture.js`}
- {new blocker for Lars → POST /api/gds/blockers (the markdown file is frozen archive only)}
- {(or "none")}

**Generative ideas captured this session:**
- {captured via `node scripts/gds/capture.js` (B2 idea_inbox), or "none". The markdown file is frozen archive only.}

**Decisions made (linked to ADRs):**
- {NNNN — title} (or "none — no architectural decisions this session")
```

---

## Confidence tag definitions

These tags are required on every "shipped" claim. They prevent the session log from quietly conflating "the smoke test passed" with "a real person used the feature in a real browser."

- `[verified-prod]` — A human (Lars or me, in a deployed-to-production context) opened the live site and exercised the feature end-to-end. The thing demonstrably works for a real visitor.
- `[verified-smoke]` — An automated smoke test (one of the `/tmp/colyseus-*-smoketest.js` scripts, a `curl /healthz`, etc.) exercised the feature against production or a faithful local equivalent. The code path runs; the user-visible behavior may or may not match.
- `[implemented-not-verified]` — The code is written, committed, deployed, and the service didn't crash on startup. Nothing has actually exercised the feature. Flag for next session to verify.

If a claim doesn't fit any of these tags, it doesn't belong in the "shipped" list — put it in "unverified" or "next obvious work."

---

## Definition of Done (applies to every "shipped" claim)

A feature is "shipped" when **all five** are true:

1. **Smoke tests pass** (or there is no relevant smoke test, explicitly noted)
2. **Deploy succeeded** — `ci` mode (current): the PR auto-merged → the `deploy-prod` Actions run went green → `curl /healthz` returns 200 (legacy `laptop` mode: `git push` → `~/deploy.sh` → `/healthz` 200)
3. **Manually verified in a real browser** on the live site (this is what `[verified-prod]` means)
4. **Limitations / risks / blockers updated** if this work introduced or resolved any
5. **Session log written** as a dated file in `docs/session-logs/` with this template (the §13 snippet + `docs/session-log-index.md` regenerate at ship — don't hand-edit them)

If even one of these is false, the claim is `[verified-smoke]` or `[implemented-not-verified]`, not `[verified-prod]`.

### Diagram backstop (task [#357](https://example.com/builders#/task/357); conceptual diagrams auto-generated [#436](https://example.com/builders#/task/436))

If your change touched anything the onboarding diagrams describe — the **rank enum or which ranks are wired** (`requireRank`, `builders.rank` default, exit/assign paths), the **task-status set**, the **versions** (id/track/status), or the **complete-architecture** (the ADR 0024 memory chain + the dev-box → production ship flow) **/ drachmae-karma** models (which now flip per the **shipped** status of their backing tasks) — then before shipping:

- **All five diagrams are auto-generated** by `scripts/gds/gen-diagrams.js` — run it (`node scripts/gds/gen-diagrams.js`) and confirm the result looks right; **do not hand-edit any `.mmd`**. The mechanical three (`01-task-lifecycle`, `02-rank-ladder`, `05-versioning`) regenerate from migrations + the public version API. The conceptual two (`03-drachmae-karma`, `04-architecture`) regenerate from the **authenticated** `/tasks/:id` status of their backing tasks (and 03's seeded-achievement count); if no session is present the generator skips them cleanly. Rendering produces both `.svg` (the pannable viewer asset) and `.png` (fallback).
- To change a diagram's **layout or wording**, edit the matching template function in `gen-diagrams.js` — not the `.mmd`. `assertions.json` is rebuilt by the generator in lockstep, so you don't hand-maintain it.

The `diagram-drift` routine is a belt-and-braces backstop (it should find nothing once the generator has run), but the point is not to rely on it — running `gen-diagrams.js` is part of the change.

---

## Why this template exists

Past sessions varied wildly in length and rigor. Some session-log entries were ~1000 words of prose; others were a sentence. Without a template, the log is hard to skim and hard to trust. (Context-budget growth is now handled structurally — the prose lives in per-session files and only a bounded, generated snippet loads in CLAUDE.md §13.)

This template forces:

- **Skimmability.** Same shape every entry — eyes know where to look.
- **Honesty about completion.** Confidence tags make it impossible to silently overstate "shipped."
- **Continuity.** Manual-checks and next-obvious-work let the next session start in 2 minutes instead of 20.
- **Bounded growth.** Soft 400-word cap keeps each file lean; CLAUDE.md carries only a generated, bounded recent-sessions snippet, so the always-loaded cost can't balloon.

---

## Old entries

There is **no per-session compaction chore** anymore. CLAUDE.md §13 shows only a generated, bounded recent-sessions snippet (older entries roll off it automatically) and the full history is the generated [`docs/session-log-index.md`](session-log-index.md) — neither is hand-maintained. Trimming very old prose from `docs/session-logs/` into `docs/session-log-archive.md` is optional on-disk housekeeping; it no longer affects the loaded-every-session context cost.
