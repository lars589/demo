'use strict';

// Bug-attachment storage — durable re-hosting of #bugs screenshots (task #936,
// follow-on to ADR 0047 / task #931).
//
// Discord CDN attachment URLs are signed and EXPIRE (~24h). A bug-task can sit
// in the queue for days before it's claimed, so a bare Discord link would be a
// dead image by then. Lars's call (2026-06-12): SAVE OUR OWN COPY. The bot
// downloads each image attachment and re-hosts it on our server under a
// builders-only, auth-gated route (routes/bug-attachments.js), and the task
// description embeds that durable link.
//
// This module is the pure-ish storage core: where files live, how a filename
// is validated (path-traversal-safe), and how one image is fetched + screened
// + written. It has NO express/discord deps so it unit-tests with an injected
// fetch.
//
// ANTI-ABUSE (extends the ADR 0047 guard to bytes): only image/* with an
// allowlisted extension, magic-byte sniff (don't trust the content-type
// header), a per-image size cap, a per-bug image cap, and a strict
// download-host allowlist (the URL must be a Discord CDN host — defense against
// a crafted attachment pointing our fetch at something else, i.e. SSRF).

const path = require('node:path');
const fs = require('node:fs/promises');
const crypto = require('node:crypto');

// ext ⇄ content-type for the formats we accept.
const EXT_BY_TYPE = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/gif': 'gif',
  'image/webp': 'webp',
};
const TYPE_BY_EXT = {
  png: 'image/png',
  jpg: 'image/jpeg',
  gif: 'image/gif',
  webp: 'image/webp',
};

const MAX_BYTES = 8 * 1024 * 1024; // 8 MB per image
const MAX_IMAGES_PER_BUG = 6;       // cap attachments folded into one bug

// Stored filenames are bot-generated, never user-supplied: a fixed shape we can
// validate exactly. This is the whole path-traversal defense — the serve route
// only ever opens a name that matches this.
const NAME_RE = /^bug-[a-z0-9]{1,40}-[0-9a-f]{16}\.(png|jpg|gif|webp)$/;

// Where re-hosted images live. Outside the git tree (a `var/` dir) so a deploy's
// `git reset --hard` / pull never wipes them; gitignored. Env override for tests
// / non-default layouts.
function attachmentsDir() {
  return process.env.BUG_ATTACHMENTS_DIR || path.join(__dirname, '..', '..', 'var', 'bug-attachments');
}

// PURE — is this a well-formed, bot-generated attachment name?
function isSafeName(name) {
  return typeof name === 'string' && NAME_RE.test(name);
}

// PURE — resolve a name to an absolute path INSIDE attachmentsDir, or null if
// the name is unsafe or would escape the dir. Belt (regex) and braces (prefix
// check on the resolved path).
function resolveSafe(name) {
  if (!isSafeName(name)) return null;
  const dir = path.resolve(attachmentsDir());
  const p = path.resolve(dir, name);
  if (p !== path.join(dir, name)) return null;
  if (!p.startsWith(dir + path.sep)) return null;
  return p;
}

// PURE — the content-type to serve a stored file with (from its extension).
function contentTypeForName(name) {
  const ext = String(name).split('.').pop().toLowerCase();
  return TYPE_BY_EXT[ext] || 'application/octet-stream';
}

// PURE — only fetch from Discord's own CDN hosts. Anything else is refused
// before a network call (SSRF guard). Discord serves message attachments from
// EXACTLY these two hosts, so we match them exactly rather than by a
// `.discordapp.{com,net}` suffix. (L4 residual, red-team 2026-06-12: the suffix
// form would also accept any future/attacker-influenced `*.discordapp.com` or
// `*.discordapp.net` subdomain — a value-judgement we don't need to make for an
// attachment fetch where the real hosts are known and fixed.)
const ALLOWED_ATTACHMENT_HOSTS = new Set([
  'cdn.discordapp.com',
  'media.discordapp.net',
]);
function isAllowedAttachmentHost(urlStr) {
  let u;
  try { u = new URL(urlStr); } catch { return false; }
  if (u.protocol !== 'https:') return false;
  return ALLOWED_ATTACHMENT_HOSTS.has(u.hostname.toLowerCase());
}

// PURE — confirm the bytes really are the claimed image format (magic bytes),
// so a mislabeled content-type can't smuggle a non-image onto disk.
function sniffMatches(buf, ext) {
  if (!buf || buf.length < 12) return false;
  switch (ext) {
    case 'png':
      return buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
    case 'jpg':
      return buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
    case 'gif':
      return buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x38;
    case 'webp':
      return (
        buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46 && // 'RIFF'
        buf[8] === 0x57 && buf[9] === 0x45 && buf[10] === 0x42 && buf[11] === 0x50 // 'WEBP'
      );
    default:
      return false;
  }
}

// Download one image and re-host it. Returns { ok:true, file, url, bytes } on
// success, or { ok:false, reason } when the image is refused (never throws on a
// refusal; throws only on an unexpected fs error the caller wraps). `messageId`
// just seeds the (still-random) filename so attachments group readably.
// How many manual redirect hops we'll re-validate + follow before giving up.
// Discord CDN attachments are direct (0 redirects) in practice; a small bound
// covers a CDN edge bounce without becoming an open redirect-follow loop.
const MAX_REDIRECT_HOPS = 3;

async function persistImageFromUrl(url, { messageId = 'x', fetchImpl = globalThis.fetch, dir = attachmentsDir() } = {}) {
  if (!isAllowedAttachmentHost(url)) return { ok: false, reason: 'bad_host' };
  // L3 residual (red-team 2026-06-12): fetch with redirect:'manual' and re-run
  // the host allowlist on every Location before following. With redirect:'follow'
  // a 30x from an allowed host to an arbitrary host would be followed silently —
  // re-opening the SSRF hole the host check was meant to close (defense in depth).
  let resp;
  let currentUrl = url;
  let hops = 0;
  for (;;) {
    try {
      resp = await fetchImpl(currentUrl, { redirect: 'manual' });
    } catch (e) {
      return { ok: false, reason: 'fetch_failed', error: e.message };
    }
    const status = resp && resp.status;
    if (status >= 300 && status < 400) {
      const location = resp.headers?.get?.('location');
      if (!location) return { ok: false, reason: 'redirect_no_location' };
      // Resolve relative redirects against the current URL, then re-validate the
      // RESOLVED host against the SAME allowlist before following it.
      let next;
      try { next = new URL(location, currentUrl).toString(); } catch { return { ok: false, reason: 'redirect_bad_location' }; }
      if (!isAllowedAttachmentHost(next)) return { ok: false, reason: 'redirect_bad_host' };
      if (++hops > MAX_REDIRECT_HOPS) return { ok: false, reason: 'too_many_redirects' };
      currentUrl = next;
      continue;
    }
    break;
  }
  if (!resp || !resp.ok) return { ok: false, reason: 'fetch_status' };

  const rawType = (resp.headers?.get?.('content-type') || '').split(';')[0].trim().toLowerCase();
  const ext = EXT_BY_TYPE[rawType];
  if (!ext) return { ok: false, reason: 'bad_type', type: rawType };

  const ab = await resp.arrayBuffer();
  const buf = Buffer.from(ab);
  if (buf.length === 0) return { ok: false, reason: 'empty' };
  if (buf.length > MAX_BYTES) return { ok: false, reason: 'too_big', bytes: buf.length };
  if (!sniffMatches(buf, ext)) return { ok: false, reason: 'sniff_mismatch' };

  const idSlug = String(messageId).replace(/[^a-z0-9]/gi, '').slice(0, 40).toLowerCase() || 'x';
  const file = `bug-${idSlug}-${crypto.randomBytes(8).toString('hex')}.${ext}`;
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(path.join(dir, file), buf, { mode: 0o640 });
  return { ok: true, file, url: `/api/gds/bug-attachments/${file}`, bytes: buf.length };
}

// Persist a list of image URLs (capped). Best-effort: refused/failed images are
// skipped (logged), never aborting the others. Returns the stored refs
// ({ file, url }) in input order. Used by discord-bugs.recordInboundBug.
async function persistImages(urls, { messageId = 'x', fetchImpl = globalThis.fetch } = {}) {
  const capped = (Array.isArray(urls) ? urls : []).slice(0, MAX_IMAGES_PER_BUG);
  const out = [];
  for (const u of capped) {
    let r;
    try {
      r = await persistImageFromUrl(u, { messageId, fetchImpl });
    } catch (e) {
      console.error('[discord-bot] image persist threw (skipping):', e.message);
      continue;
    }
    if (r.ok) out.push({ file: r.file, url: r.url });
    else console.warn(`[discord-bot] image refused (${r.reason}) — skipping one attachment.`);
  }
  return out;
}

module.exports = {
  EXT_BY_TYPE,
  TYPE_BY_EXT,
  MAX_BYTES,
  MAX_IMAGES_PER_BUG,
  attachmentsDir,
  isSafeName,
  resolveSafe,
  contentTypeForName,
  isAllowedAttachmentHost,
  sniffMatches,
  persistImageFromUrl,
  persistImages,
};
