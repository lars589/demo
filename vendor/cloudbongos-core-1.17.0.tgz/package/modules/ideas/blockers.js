// Blockers — DB-canonical replacement for blockers/blockers.md (Phase 2a).
//
// A blocker is a thing stuck on a human (typically Lars). When a blocker
// resolves, a trigger on the blockers table auto-promotes every task linked
// via task_blockers from 'blocked' → 'ready'.
//
// Carved into modules/ideas/ (BV1.R78 / ADR 0093 §1): reaches the shared pool
// through the published doorway (src/module-api.js). OTB byte-identical.

const { pool } = require('../../src/module-api');

async function listOpenBlockers() {
  const { rows } = await pool.query(
    `SELECT b.id, b.title, b.body_md, b.status, b.created_at,
            b.source, b.source_ref,
            COALESCE(
              (SELECT array_agg(tb.task_id ORDER BY tb.task_id)
                 FROM task_blockers tb WHERE tb.blocker_id = b.id),
              ARRAY[]::bigint[]
            ) AS blocking_task_ids
       FROM blockers b
      WHERE b.status = 'open'
      ORDER BY b.id`
  );
  return rows;
}

async function getBlocker(id) {
  const { rows } = await pool.query(
    `SELECT id, title, body_md, status, created_at, resolved_at, resolved_by, resolution_note,
            source, source_ref
       FROM blockers WHERE id = $1`,
    [id]
  );
  return rows[0] || null;
}

// Idempotent: if (source, source_ref) is already taken, ON CONFLICT skips.
// Returns the row when inserted, null when skipped.
async function createBlocker({ title, bodyMd, source, sourceRef }) {
  if (!title) {
    const e = new Error('title is required');
    e.code = 'TITLE_REQUIRED';
    throw e;
  }
  const { rows } = await pool.query(
    `INSERT INTO blockers (title, body_md, source, source_ref)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (source, source_ref) WHERE source IS NOT NULL AND source_ref IS NOT NULL
       DO NOTHING
     RETURNING id, title, body_md, status, created_at, source, source_ref`,
    [title, bodyMd ?? '', source ?? null, sourceRef ?? null]
  );
  return rows[0] || null;
}

// Resolve a blocker. The trigger on blockers.status flips linked tasks
// from 'blocked' → 'ready' atomically.
async function resolveBlocker({ id, builderId, resolutionNote }) {
  const { rows } = await pool.query(
    `UPDATE blockers
        SET status = 'resolved',
            resolved_by = $2,
            resolution_note = $3
      WHERE id = $1 AND status = 'open'
      RETURNING id, title, status, resolved_at, resolved_by, resolution_note`,
    [id, builderId, resolutionNote ?? null]
  );
  if (rows.length === 0) {
    const e = new Error('blocker not found or already resolved');
    e.code = 'BLOCKER_NOT_OPEN';
    throw e;
  }
  // After-the-fact: count how many tasks the trigger just promoted.
  const { rows: promoted } = await pool.query(
    `SELECT id, title FROM tasks
      WHERE id IN (SELECT task_id FROM task_blockers WHERE blocker_id = $1)
        AND status = 'ready'`,
    [id]
  );
  return { blocker: rows[0], promoted_tasks: promoted };
}

// Link a blocker to a task (lives in task_blockers via the new blocker_id col).
async function linkBlockerToTask({ blockerId, taskId }) {
  await pool.query(
    `INSERT INTO task_blockers (task_id, blocker_id, blocker_ref)
     VALUES ($1, $2, $3)
     ON CONFLICT DO NOTHING`,
    [taskId, blockerId, `blocker:${blockerId}`]
  );
}

module.exports = {
  listOpenBlockers,
  getBlocker,
  createBlocker,
  resolveBlocker,
  linkBlockerToTask,
};
