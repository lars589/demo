-- 163_polymorphic_dependencies.sql — ADR 0086 §5 / Phase 4 / BV1.R62 / task 1516.
--
-- One polymorphic "blocked-until-done" edge over {task, goal, criterion}, taking
-- over from the task-only task_dependencies table (020) as the canonical edge for
-- the claim gate + auto-promotion. Read it as "FROM is blocked until TO is done":
--   TO is "done"  <=>  task status='shipped' | criterion satisfied | goal status='achieved'.
--
-- ADR 0086 §5 prose says "tasks.dependencies[] migrates in" — there is NO such
-- column; the real task->task edges live in the task_dependencies join table (020),
-- and we migrate THOSE in here. task_dependencies is RETAINED, not dropped:
-- migration 021 still seeds it on a fresh DB, and `dependencies` is a superset, so
-- the move is reversible (stop reading the new table → fall back to the old one).
--
-- Inheritance: a task is gated by edges FROM itself, FROM its goal (tasks.goal_id),
-- and FROM every criterion it fulfils (task_criteria). One enforcement point — the
-- claim gate (db.js unsatisfiedDeps) — resolves all three. The promotion trigger
-- fires on each "done" event (task ship / criterion satisfy / goal achieve) and
-- promotes any backlog (non-spike) task whose FULL resolved dep set is now done.

BEGIN;

-- ============================================================================
-- 1. dependencies — the polymorphic edge
-- ============================================================================
-- No FK is possible (the target table varies by *_kind), so the CHECK constrains
-- the kinds and `kind` disambiguates ids across tasks/goals/criteria (all bigint).
-- The criterion referent is done_when_criteria.id — the numeric id that
-- task_criteria.criterion_id also holds — NEVER the criterion_id text slug.
CREATE TABLE IF NOT EXISTS dependencies (
  from_kind  text   NOT NULL CHECK (from_kind IN ('task', 'goal', 'criterion')),
  from_id    bigint NOT NULL,
  to_kind    text   NOT NULL CHECK (to_kind   IN ('task', 'goal', 'criterion')),
  to_id      bigint NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (from_kind, from_id, to_kind, to_id),
  CONSTRAINT no_self_dep CHECK (NOT (from_kind = to_kind AND from_id = to_id))
);

-- "What does X depend on?" (forward, gate read) + "what depends on Y?" (reverse,
-- promotion read).
CREATE INDEX IF NOT EXISTS idx_dependencies_from ON dependencies (from_kind, from_id);
CREATE INDEX IF NOT EXISTS idx_dependencies_to   ON dependencies (to_kind, to_id);

-- ============================================================================
-- 2. Migrate the existing task->task edges in (additive superset of 020)
-- ============================================================================
-- A SELECT-backfill (not literal VALUES): empty on a fresh DB where
-- task_dependencies is empty, and re-runnable (ON CONFLICT DO NOTHING).
INSERT INTO dependencies (from_kind, from_id, to_kind, to_id, created_at)
SELECT 'task', td.task_id, 'task', td.depends_on_task_id, td.created_at
  FROM task_dependencies td
ON CONFLICT DO NOTHING;

-- ============================================================================
-- 3. Resolution predicate + generalized auto-promotion
-- ============================================================================
-- task_is_fully_unblocked(T): TRUE iff NONE of T's gating edges points at an
-- un-done node. Gating edges = FROM the task itself, FROM its goal, or FROM any
-- criterion it fulfils. Shared by all three promotion triggers below, and it
-- mirrors the claim gate's unsatisfiedDeps in db.js (same three-source union, same
-- done-ness test) so promotion and the gate can never disagree. An orphaned `to`
-- (no FK; row deleted) yields no EXISTS match → counts as un-done → task stays
-- blocked (fail-closed).
CREATE OR REPLACE FUNCTION task_is_fully_unblocked(p_task_id bigint)
RETURNS boolean AS $$
  SELECT NOT EXISTS (
    WITH gating AS (
      SELECT d.to_kind, d.to_id
        FROM dependencies d
        JOIN tasks t ON t.id = p_task_id
       WHERE (d.from_kind = 'task'      AND d.from_id = t.id)
          OR (d.from_kind = 'goal'      AND d.from_id = t.goal_id)
          OR (d.from_kind = 'criterion' AND d.from_id IN (
                SELECT tc.criterion_id FROM task_criteria tc WHERE tc.task_id = t.id))
    )
    SELECT 1
      FROM gating g
     WHERE NOT (
          (g.to_kind = 'task'      AND EXISTS (SELECT 1 FROM tasks              x WHERE x.id = g.to_id AND x.status = 'shipped'))
       OR (g.to_kind = 'criterion' AND EXISTS (SELECT 1 FROM done_when_criteria x WHERE x.id = g.to_id AND x.satisfied))
       OR (g.to_kind = 'goal'      AND EXISTS (SELECT 1 FROM goals              x WHERE x.id = g.to_id AND x.status = 'achieved'))
     )
  );
$$ LANGUAGE sql STABLE;

-- Each trigger fn scopes candidates to backlog (non-spike) tasks actually gated by
-- the node that just became done (direct, or inherited via goal/criterion), then
-- re-checks the FULL dep set with task_is_fully_unblocked. Promotion only flips
-- backlog -> ready (never to a "done" state), so the AFTER triggers cannot recurse.

-- (a) a task shipped
CREATE OR REPLACE FUNCTION promote_dependents_on_ship()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'shipped' AND (OLD.status IS DISTINCT FROM 'shipped') THEN
    UPDATE tasks t
       SET status = 'ready', promoted_at = COALESCE(t.promoted_at, now()), updated_at = now()
     WHERE t.status = 'backlog'
       AND t.kind <> 'spike'
       AND EXISTS (
         SELECT 1 FROM dependencies d
          WHERE d.to_kind = 'task' AND d.to_id = NEW.id
            AND ( (d.from_kind = 'task'      AND d.from_id = t.id)
               OR (d.from_kind = 'goal'      AND d.from_id = t.goal_id)
               OR (d.from_kind = 'criterion' AND d.from_id IN (
                     SELECT tc.criterion_id FROM task_criteria tc WHERE tc.task_id = t.id)) )
       )
       AND task_is_fully_unblocked(t.id);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- (b) a criterion satisfied
CREATE OR REPLACE FUNCTION promote_dependents_on_criterion_satisfy()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.satisfied = true AND (OLD.satisfied IS DISTINCT FROM true) THEN
    UPDATE tasks t
       SET status = 'ready', promoted_at = COALESCE(t.promoted_at, now()), updated_at = now()
     WHERE t.status = 'backlog'
       AND t.kind <> 'spike'
       AND EXISTS (
         SELECT 1 FROM dependencies d
          WHERE d.to_kind = 'criterion' AND d.to_id = NEW.id
            AND ( (d.from_kind = 'task'      AND d.from_id = t.id)
               OR (d.from_kind = 'goal'      AND d.from_id = t.goal_id)
               OR (d.from_kind = 'criterion' AND d.from_id IN (
                     SELECT tc.criterion_id FROM task_criteria tc WHERE tc.task_id = t.id)) )
       )
       AND task_is_fully_unblocked(t.id);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- (c) a goal achieved
CREATE OR REPLACE FUNCTION promote_dependents_on_goal_achieve()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'achieved' AND (OLD.status IS DISTINCT FROM 'achieved') THEN
    UPDATE tasks t
       SET status = 'ready', promoted_at = COALESCE(t.promoted_at, now()), updated_at = now()
     WHERE t.status = 'backlog'
       AND t.kind <> 'spike'
       AND EXISTS (
         SELECT 1 FROM dependencies d
          WHERE d.to_kind = 'goal' AND d.to_id = NEW.id
            AND ( (d.from_kind = 'task'      AND d.from_id = t.id)
               OR (d.from_kind = 'goal'      AND d.from_id = t.goal_id)
               OR (d.from_kind = 'criterion' AND d.from_id IN (
                     SELECT tc.criterion_id FROM task_criteria tc WHERE tc.task_id = t.id)) )
       )
       AND task_is_fully_unblocked(t.id);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Replace 020's single task-only trigger; add the criterion + goal triggers.
DROP TRIGGER IF EXISTS trg_promote_dependents_on_ship ON tasks;
CREATE TRIGGER trg_promote_dependents_on_ship
  AFTER UPDATE OF status ON tasks
  FOR EACH ROW
  EXECUTE FUNCTION promote_dependents_on_ship();

DROP TRIGGER IF EXISTS trg_promote_dependents_on_crit_satisfy ON done_when_criteria;
CREATE TRIGGER trg_promote_dependents_on_crit_satisfy
  AFTER UPDATE OF satisfied ON done_when_criteria
  FOR EACH ROW
  EXECUTE FUNCTION promote_dependents_on_criterion_satisfy();

DROP TRIGGER IF EXISTS trg_promote_dependents_on_goal_achieve ON goals;
CREATE TRIGGER trg_promote_dependents_on_goal_achieve
  AFTER UPDATE OF status ON goals
  FOR EACH ROW
  EXECUTE FUNCTION promote_dependents_on_goal_achieve();

-- ============================================================================
-- 4. Bump migration counter + record
-- ============================================================================
UPDATE migration_counter SET next_number = GREATEST(next_number, 164) WHERE id = 1;

INSERT INTO schema_migrations (version) VALUES ('163_polymorphic_dependencies')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
