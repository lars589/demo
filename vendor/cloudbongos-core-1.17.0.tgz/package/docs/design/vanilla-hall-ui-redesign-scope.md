# Vanilla Hall UI — Redesign Scope

**Surface:** the default UI every Cloud Bongos instance ships — the `hall-ui` module (`modules/hall-ui/public`) served at `builders.<apex>` → **builders.cloudbongos.com**.

**What this fixes:** component **type, placement, and sizing**. It deliberately does **not** settle final visual design, colour, typography, or exact copy.

**Status:** scope for hand-off. Owner to seed tasks from §12–§14.

**Visual companion:** the annotated wireframes for every surface below are rendered as an interactive artifact — [Cloud Bongos — Vanilla UI Redesign Scope](https://claude.ai/code/artifact/b6992395-ff5b-4356-8acb-99908a574aa8).

**Locked decisions (owner, 2026-07-02):**

| Fork | Decision |
|---|---|
| Layout paradigm | **Dashboard shell** — persistent sidebar + top bar + focused content per view |
| Scope breadth | **Landing + primary pages** — shell + Home, Work, Standing, Achievements, Leaderboard, Docs, Settings. Archon pages inherit the shell only. |
| Voice / theming | **Neutralize to a clean default** — strip the "chronicles of the city" lore to neutral, professional labels |

---

## 0. Starting point — what exists today

The current hall is **one long single-column page** (`index.html`, `<main>` capped at 1080px) styled as an illuminated "chronicles of the city" manuscript. `<main>` stacks eleven registry-driven widget "scrolls" in a fixed order; the header carries an epigraph + H1 + a stack of text nav-links; a sticky chip strip jumps between sections; depth lives on separate full pages behind those links.

```
┌────────────────────────────────────────────┐
│ header — epigraph · H1 · welcome · 8 links   │
│ sticky chip nav (jump-to-section)            │
├────────────────────────────────────────────┤
│ Welcome → Path → Standing → Honours → Karma  │
│ → Acclaim → Works → Marks → Curve → Bounty   │
│ → Roll → Goals            (11+ stacked)      │
│ footer                                       │
└────────────────────────────────────────────┘
```

The eleven core widgets (from `hall-widgets.js`, by mount order): **Welcome, Path (onboarding), Standing (profile), Honours (8 laurels), Karma, Acclaim, Works (ships), Marks (grades), Curve (analytics), Bounty (red-team rewards), Roll (leaderboard)** — plus a **Goals** widget (`goals.js`).

Separate full pages behind header links: **Work Board, Primer, Diagrams, Repo Atlas, Ranks, Settings, Pair**, plus Archon-only **Watch, Harbor, Gate**.

The data and the registry seam stay. The redesign changes the **frame** the widgets live in.

---

## 1. Principles — what "vanilla" has to mean

This is the recommended base every project inherits and then customizes. It should read as neutral, obvious, and calm.

- **Neutral first** — no theme baked into markup; character arrives through the brand pack.
- **Scan, don't scroll** — persistent navigation replaces the long scroll; any surface is one click away.
- **Frame > contents** — the redesign owns the shell and placement; widgets keep registering as they do now, so instances add/remove without touching the frame.
- **Summary before detail** — headline numbers and state up top; tables and history below. State shows as form (pills, marks), not just text.

---

## 2. The shell — persistent frame

One shell wraps every page, replacing both the header text-link stack and the per-page sticky chip nav.

```
┌──────┬────────────────────────────────┐
│ LOGO │  top bar: title · search · user │
│ ──── ├────────────────────────────────┤
│ Home │  ┌─────┐┌─────┐┌─────┐┌─────┐   │
│ Work │  │stat ││stat ││stat ││stat │   │
│ Stnd │  └─────┘└─────┘└─────┘└─────┘   │
│ Achv │  ┌────────────┐┌────────────┐   │
│ Lead │  │  card      ││  card      │   │
│ Docs │  └────────────┘└────────────┘   │
│ Sett │  ┌──────────────────────────┐   │
│ Admin│  │  table / main content    │   │
│      │  └──────────────────────────┘   │
└──────┴────────────────────────────────┘
```

| Region | Component type | Placement | Size | Behaviour |
|---|---|---|---|---|
| **Sidebar** | Vertical nav rail + brand mark | Fixed left, full height | 240px → 64px rail → drawer | 64px icon rail <1024, off-canvas drawer <768. Active item marked with accent inset. |
| **Top bar** | Context bar: page title, search, notifications, user menu | Fixed top of content column | height 56px | Sticky. Holds the user chip (today in the header welcome line) + logout. |
| **Content** | Scrollable view region | Right of sidebar, below top bar | max 1120px, gutter 24–32 | Only region that scrolls. One view at a time; centers past max. |
| **Footer** | Minimal meta line | End of content flow | auto | Reduced to sign-out + instance name; no lore. |

> **Seam preserved.** The shell is chrome only. The hall-widget registry (`dom-utils.js` · `contributeHallWidget`) and the `/api/gds/*` reads are unchanged — widgets mount into view containers instead of one `<main>`.

---

## 3. Navigation model — where the sidebar sends you

Seven primary destinations plus a gated Admin group. Today's eleven scrolls collapse onto **Home, Standing, Achievements, Leaderboard**; the separate pages become sidebar entries.

| Nav entry | Absorbs (today) | Type | Gate |
|---|---|---|---|
| **Home** | Welcome, Path (onboarding), Goals, quick stats, recent Works snippet | Dashboard view | signed-in |
| **Work** | Work Board (WIP, Claimable, History) | Full page | signed-in |
| **Standing** | Profile, Karma, Acclaim, Works, Marks, Curve, Bounty | Sectioned page | signed-in |
| **Achievements** | Honours (laurel grid) | Grid view | signed-in |
| **Leaderboard** | Roll of the Foremost | Table view | signed-in |
| **Docs** | Primer, Diagrams/maps, Repo Atlas | Doc pages + TOC | signed-in |
| **Settings** | Settings (all panels) | Sub-nav + panels | signed-in |
| **Admin ▾** | Watch, Harbor, Gate | Grouped, collapsed | **Archon only** |

> Rank/permission gating is **unchanged** — Xenos still don't see Work until graduation; Admin only unhides at `rank=archon`. The redesign moves *where* those links render (into the sidebar), not *whether* they gate.

---

## 4. Surface · Home — the landing dashboard

Light and glanceable: a stat row, then a two-column band, then a compact recent-work list. Onboarding/welcome float above for pre-graduation members.

| Component | Type | Placement | Size |
|---|---|---|---|
| Welcome / onboarding | Dismissable banner | Top, above stats | full-width · collapsible |
| Quick stats | Stat-tile row (4) | Below banner | grid auto-fit · min 200px · h ~88 |
| Standing summary | Card w/ link-out | Left of band | 50% · ≥320px |
| Goals | Card / list | Right of band | 50% · ≥320px |
| Recent work | Compact data table | Full-width, below band | 5 rows · row 44 |

---

## 5. Surface · Standing — everything about one member

The heaviest consolidation: seven of today's scrolls become one page with an in-page section rail so it stays scannable.

| Component | Type | Placement | Size |
|---|---|---|---|
| Profile header | Identity band (avatar, name, rank, key numbers) | Top, full-width | full · h ~120 |
| Section rail | In-page anchor nav | Left, sticky | 150–180px |
| Works | Filter bar + data table + pager | Panel 1 | fill · filters wrap |
| Curve | Headline + metric grid + kind breakdown | Panel 2 | metrics auto-fit min 180 |
| Marks / Karma / Acclaim | Ledger tables | Panels 3–5 | row 44 · sticky head |
| Bounty | Reference table (reward schedule) | Panel 6 | compact |

> On narrow viewports the in-page rail collapses to a horizontal chip strip — reusing the pattern the old sticky chip nav established.

---

## 6. Surface · Work — the Work Board

Kept close to today's three-section structure (in-progress, claimable, history), reframed as filterable tables inside the shell.

| Component | Type | Placement | Size |
|---|---|---|---|
| Board header | Count summary + filter bar | Top | full · filters wrap |
| In progress | Data table (grouped) | Primary | full · row 44 |
| Claimable | Data table w/ claim action | Below WIP | full · row 44 |
| History | Collapsed table | Bottom | expandable |
| Gate strip | Archon-only banner | Top when present | Archon |

---

## 7. Surface · Settings — grouped panels

Settings has the most sections today (~15: connections, dev box, box app, craft, display name, wandering, render, art key, CLI, voices, sounds, event sounds…). It gets its own left sub-nav so each group is a focused panel.

| Component | Type | Placement | Size |
|---|---|---|---|
| Settings sub-nav | Vertical group list | Left of panel | 170–200px |
| Active panel | Grouped form / fields | Fill | max 720px reading col |
| Voices | Data table (per-skill voice) | Within its panel | full · row 44 |
| Panel footer | Save / action row | Bottom of panel | sticky-optional |

> The exact grouping of the ~15 sections into ~6–7 sub-nav panels is an open question (§14). The placement pattern (sub-nav + one panel) holds regardless.

---

## 8. Surfaces · Docs · Achievements · Leaderboard — the lighter views

- **Docs** — Primer already has a TOC aside; formalize it. Left TOC (200px, sticky) + centered reading column (max 68ch). Diagrams and Repo Atlas are sibling entries under Docs.
- **Achievements** — the 8-laurel honours grid, kept as a grid: `auto-fill minmax(220px,1fr)`. Held vs. unearned distinguished by state, not a separate list. Full content width.
- **Leaderboard** — full-width data table (place · member · rank · credits · karma), sortable headers preserved, pager below. Row height 44, sticky header on scroll.

---

## 9. Component taxonomy — the building blocks (types, not skins)

The whole surface is composed from a small, reused kit. Fixing this list is most of the scope.

| Block | Used for | Default size / rule |
|---|---|---|
| **App shell** | Sidebar + top bar + content frame | 240 / 56 / max 1120 |
| **Nav rail item** | Sidebar + in-page section navs | h 36 · active accent inset |
| **Stat tile** | Headline numbers (credits, shipped, karma, rank) | min 200 · h ~88 · tabular-nums |
| **Card** | Grouped content (profile, goals, summaries) | radius 10 · pad 18–20 · hairline |
| **Data table (ledger)** | Works, karma, acclaim, marks, leaderboard, voices | row 44 · sticky head · x-scroll wrap |
| **Filter bar** | Works / Work Board filtering | wrap · label+select ~200 |
| **Pager** | Long tables | prev · range · next |
| **Badge grid** | Achievements / honours | auto-fill minmax(220,1fr) |
| **Metric grid** | Dev curve | auto-fit minmax(180,1fr) |
| **Banner** | Welcome, onboarding, Archon gate | full · dismissable/collapsible |
| **Status pill / mark** | State (rank, grade, in/out) | h 20 · form-encoded state |
| **Reading column** | Docs / primer | max 68ch · TOC 200 |

---

## 10. Sizing & responsive system — one scale, four breakpoints

**Tokens**

| Token | Value |
|---|---|
| Space scale | 4 · 8 · 12 · 16 · 24 · 32 · 48 |
| Sidebar width | 240 → 64 → drawer |
| Top bar height | 56 |
| Content max-width | 1120 |
| Reading column | ≤ 68ch |
| Card radius / pad | 10 / 18–20 |
| Table row height | 44 |
| Stat tile min | 200 |

**Breakpoints**

| ≤ px | What changes |
|---|---|
| 1280 | Content stops growing; centers |
| 1024 | Sidebar → 64px icon rail; 4→2 tile columns |
| 768 | Sidebar → off-canvas drawer; two-col bands stack; in-page rails → chip strips |
| 480 | Single column; tables scroll in their wrappers; filter bars stack |

---

## 11. Voice neutralization — themed → vanilla default

Not layout, but it rides along. Most of this already flows through the brand pack (`brand-apply.js`, `copy.hallName`, `currency-label`) — neutralizing means shipping a neutral default pack **and** de-loring the hardcoded strings (ties to **idea [#351](https://example.com/builders#/idea/351)**, auth pages hardcoding OTB lore).

| Today (themed) | Vanilla default | Source |
|---|---|---|
| "The Builders' Hall" · "chronicles of the city" epigraph | "Builders" · no epigraph | brand pack + markup |
| "scroll" (section) | card / panel | markup + CSS class |
| "Thy Standing in the City" | Standing / Profile | markup |
| drachmae | credits (`currency-label`) | brand pack (already) |
| Honours / laurels | Achievements | markup |
| "Works Wrought by Thy Hand" | Your work | markup |
| "Marks of the Inspector" | Reviews / quality marks | markup |
| "Roll of the Foremost" | Leaderboard | markup |
| "leave the hall" | Sign out | markup |
| citizen | member / builder | markup + brand pack |
| Xenos / Thetes / Metic / Archon | *rank names — deeper copy decision, see §14* | brand pack + access control |

---

## 12. Scope boundaries — in · deferred · out

**In scope**
- App shell (sidebar, top bar, content)
- Home dashboard
- Standing, Work, Achievements, Leaderboard, Settings, Docs layout
- Component taxonomy + sizing system
- Responsive behaviour
- Neutral default voice

**Deferred**
- Archon pages — Watch, Harbor, Gate (inherit shell only; internal layout unchanged)
- Rank-name copy decision
- Public apex landing page (separate surface)

**Out of scope**
- Final colour / typography / visual identity
- Exact copy wording
- API / data-model changes
- The `bongos-app` desktop tool (separate product)

---

## 13. Implementation seams — what the redesign must not break

The hall has hard architectural constraints (see `modules/hall-ui/CLAUDE.md`). Placement changes are cheap only if they respect these.

- **Widget registry is the source of truth.** A fitness check (`scripts/gds/fitness.js checkHallSectionRegistry`) reds the build if a `<section class="scroll">` is hardcoded into `<main>`. Views must mount registered widgets, not inline them.
- **No framework, no build step.** Static HTML/CSS/JS polling `/api/gds/*`. The shell is hand-rolled CSS + a small amount of JS — no framework may be introduced.
- **Dedicated serving block.** `src/bongos/serve-internal.js` serves this from `BUILDERS_DIR` with the subdomain rewrite shim, canonical redirects, page gates, and asset-stamping. New assets must carry the content-hash `?v=` stamp.
- **Server-side gates stay authoritative.** Hiding a sidebar item is cosmetic; `requireArchonPage` and the sign-in redirects remain the real access control.
- **Brand pack drives copy.** Neutralizing voice = a neutral default pack + removing hardcoded lore, not English strings baked into markup.
- **Module-contributed widgets keep working.** The shell must give a stable mount point so a module's `hall-widget.js` lands in the right view (`injectModuleHallWidgets` seam).

---

## 14. Open questions — decide before build

1. **Sidebar vs. top nav** as the primary — this scope assumes a left sidebar. Confirm before locking the shell.
2. **Settings grouping** — the ~15 sections need a final grouping into ~6–7 sub-nav panels.
3. **Standing consolidation depth** — one page with an in-page rail, or should Curve / Bounty split off?
4. **Rank vocabulary** — keep Xenos/Thetes/Metic/Archon, or neutralize to plain tiers? Touches access-control copy, so flagged separately.
5. **Where module hall-widgets land** in the new view structure (Home vs. their own view).
6. **Desktop-first vs. mobile-usage** — how much the drawer/mobile path matters for the builder audience.
