-- 173_bongos_v1_c7_core_modularized.sql
-- Adds BONGOS-V1 criterion C7 (gds-core-modularized) — the "Config B" core
-- decomposition wave seeded by planning session 2026-06-26 (task 1567).
-- The four feature modules (C5) shipped; this criterion owns breaking the GDS
-- *core* into kernel-mediated modules. Parented under goal 10 (GDS core
-- modularization). Idempotent on the (version_id, criterion_id) unique key.
-- Vanilla-safe guard (task 1264 / hardware-verify R63): this criterion parents to
-- goal id 10 (OTB's "GDS core modularization" goal). Goal ids aren't migration-seeded,
-- so a fresh self-host DB has no goal #10 and this INSERT would violate the goal_id
-- foreign key. Skip unless that goal exists. (Already applied on the OTB instance;
-- guard only bites on a fresh vanilla DB.)
DO $c7$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM goals WHERE id = 10) THEN
    RAISE NOTICE '173: goal 10 (GDS core modularization) absent — vanilla instance, skipping BONGOS-V1 C7 criterion seed.';
    RETURN;
  END IF;

INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, sort_order, goal_id)
VALUES (
  'BONGOS-V1',
  'gds-core-modularized',
  '**The GDS core is itself decomposed into cohesive, kernel-mediated modules — not just the four feature modules.** A bounded ~3.5k-LOC kernel (auth · rank · pool · audit · trust primitives · loader · seams) is the *only* thing core domains import, through the published doorway; the ~6k-LOC shared `db.js` is carved per-domain so each module owns its SQL; capabilities the lifecycle invokes (grade, reward) resolve through kernel **ports**, never direct imports. **Proven when ≥2 core domains live as modules with their `db.js` slices extracted, the kernel is bounded + fitness-enforced, and OTB behaves byte-identically.** The lifecycle state machine (tasks/claims/versions) is NOT split — only the capabilities it calls are extracted behind seams. (ADR 0083 §"the four module moves" + design doc 02-module-map.md §3/§6; planning 2026-06-26, task 1567.)',
  7,
  10
)
ON CONFLICT (version_id, criterion_id) DO UPDATE
  SET criterion_md = EXCLUDED.criterion_md,
      sort_order  = EXCLUDED.sort_order,
      goal_id     = EXCLUDED.goal_id;

END
$c7$;
