-- 045_builder_onboarding_state.sql — V3.R75 (#294): auto-completing onboarding checklist.
--
-- #238 (migration 043) gave us the funnel basics: builders.onboarded_at and
-- builders.first_ship_at, the two single-timestamp shortcuts the Archon roster
-- already renders. That covers the *start* and *finish* of the funnel but
-- nothing in between, and it gives the *builder* themselves no way to see
-- "where am I in onboarding right now?". This migration adds the structured
-- middle: a small state-machine row per builder that ticks itself off as
-- events fire (Device Flow done, first /builder-start, first claim, first
-- ship, first karma vote received, graduated).
--
-- Design choices:
--
--   * One row per builder (PRIMARY KEY = builder_id). The state is a 1:1
--     relationship — every builder gets exactly one onboarding journey, and
--     re-running it has no meaning. Upserts on first hit.
--
--   * `current_stage` is the next stage the builder needs to clear. Stays
--     'graduated' once they've graduated. completed_stages[] is the audit
--     trail (what they've already cleared) so the UI can render checkmarks
--     without inferring from the cached current_stage alone.
--
--   * `completed_stages text[]` not `jsonb`: this is a flat append-only set
--     of stage names. Postgres arrays + the ANY operator are the right shape;
--     jsonb would be a strictly-worse fit for the set semantics.
--
--   * CHECK constraint on `current_stage` against the 7 stages so a code bug
--     can't smuggle in 'frist_ship'-style typos. completed_stages[] is NOT
--     CHECK-constrained per element — Postgres can't CHECK array elements
--     against an enum without a custom domain or a trigger, and the cost
--     isn't worth the marginal safety. The application layer normalizes
--     stage names through markStage().
--
--   * `started_at` set on first row creation (when auth_complete fires).
--     `completed_at` set when `current_stage` flips to 'graduated'. The gap
--     between the two is the time-to-graduate metric (extends time-to-first-
--     ship from #238 — graduation = first_ship + first_vote_received).
--
-- Backfill strategy:
--
-- Every existing builder gets a row with completed_stages reconstructed from
-- the observability columns added in migration 043:
--
--   onboarded_at    IS NOT NULL → auth_complete cleared
--   first_ship_at   IS NOT NULL → first_claim + first_ship cleared
--                                 (you can't ship without claiming first, so
--                                 first_claim is implied — backfilling both
--                                 keeps the checklist coherent)
--
-- We can't reconstruct first_start (the GET /tasks/claimable signal) or
-- first_vote_received (karma_log peer-vote rows) from existing data because
-- those weren't tracked. Existing builders who have already cleared those
-- stages WILL re-fire the event the next time they hit the endpoint —
-- markStage() is idempotent, so the re-fire is a no-op and graduation is
-- still reachable. primer_read has no historical signal at all and stays
-- uncleared for everyone until the primer-read route lands (see notes_md on
-- the issuing task).
--
-- current_stage is set to the FIRST stage not yet in completed_stages, with
-- a graduation-detector that flips to 'graduated' iff all six prior stages
-- are cleared. The application code maintains the same invariant going
-- forward.
--
-- Idempotent: safe to re-run.

BEGIN;

CREATE TABLE IF NOT EXISTS builder_onboarding_state (
  builder_id        bigint PRIMARY KEY REFERENCES builders(id) ON DELETE CASCADE,
  current_stage     text NOT NULL,
  completed_stages  text[] NOT NULL DEFAULT '{}'::text[],
  started_at        timestamptz NOT NULL DEFAULT now(),
  completed_at      timestamptz
);

-- The seven stages. Order matters for current_stage advancement but is
-- defined in the application layer (src/bongos/onboarding-state.js) — the DB
-- only validates the enum membership.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
     WHERE conname = 'builder_onboarding_state_stage_enum'
       AND conrelid = 'builder_onboarding_state'::regclass
  ) THEN
    ALTER TABLE builder_onboarding_state
      ADD CONSTRAINT builder_onboarding_state_stage_enum
      CHECK (current_stage IN (
        'auth_complete',
        'primer_read',
        'first_start',
        'first_claim',
        'first_ship',
        'first_vote_received',
        'graduated'
      ));
  END IF;
END $$;

-- Sparse index for "still onboarding" queries (completed_at IS NULL) — the
-- Archon dashboard will hit this frequently to surface in-progress builders.
CREATE INDEX IF NOT EXISTS idx_builder_onboarding_in_progress
  ON builder_onboarding_state (started_at)
  WHERE completed_at IS NULL;

-- ---------------------------------------------------------------------------
-- Backfill. Inserts one row per builder if missing, with completed_stages[]
-- reconstructed from the migration 043 observability columns.
-- ---------------------------------------------------------------------------

-- Helper: pick the first uncompleted stage in canonical order, or 'graduated'
-- if all six are done. Inlined as a CASE in the INSERT below — keeps it one
-- statement, no PL/pgSQL function needed.
INSERT INTO builder_onboarding_state (builder_id, current_stage, completed_stages, started_at, completed_at)
SELECT
  b.id,
  CASE
    WHEN b.onboarded_at IS NULL THEN 'auth_complete'
    -- primer_read has no historical signal — always next-after-auth unless
    -- a later stage is already cleared (in which case the builder has clearly
    -- already moved on, and we don't want to gate them on a backfilled stage
    -- they never saw the prompt for).
    WHEN b.first_ship_at IS NULL THEN 'primer_read'
    -- After first_ship is cleared, the only stage left is first_vote_received.
    ELSE 'first_vote_received'
  END AS current_stage,
  ARRAY(
    SELECT s FROM (VALUES
      ('auth_complete',    b.onboarded_at  IS NOT NULL),
      -- first_claim is implied by first_ship_at (can't ship what you didn't
      -- claim). Backfilling both keeps the checklist coherent for legacy rows.
      ('first_claim',      b.first_ship_at IS NOT NULL),
      ('first_ship',       b.first_ship_at IS NOT NULL)
    ) AS v(s, cleared)
    WHERE cleared
  ) AS completed_stages,
  COALESCE(b.onboarded_at, b.created_at, now()) AS started_at,
  NULL::timestamptz AS completed_at
FROM builders b
WHERE NOT EXISTS (
  SELECT 1 FROM builder_onboarding_state s WHERE s.builder_id = b.id
);

INSERT INTO schema_migrations (version) VALUES ('045_builder_onboarding_state')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
