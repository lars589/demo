# ADR 0057 — Per-builder container cost ledger (org-funded → self-fund tracking)

**Date:** 2026-06-15
**Status:** Accepted
**Track:** `internal` (dev-system / cost oversight).
**Context:** GDS-V3, task [#602](https://example.com/builders#/task/602), criterion C-cost. Implements the ledger half of ADR 0031 §5 (cost passthrough). Companion to [ADR 0031](<redacted>.md) (the dev box) and the early-stage billing policy ("tracked, not settled" — both drachmae earnings and container costs are recorded but not actually paid/charged yet).

## Problem

Builders run org-provisioned DigitalOcean dev boxes (ADR 0031). We want every box cost event recorded per builder — visible to the builder on their own profile and to the Archon for oversight — so the org can see what each box costs *before* any real self-fund/charge mechanism exists. No payment integration, no drachmae deduction yet.

## Decisions

1. **Reuse `cost_log`; no new table, no migration.** The existing `cost_log` table (migrations/003, builder-attributed since 046, idempotent on `(source, source_ref)`) already carries timestamp/amount/description/builder_id — the exact shape the task asks for. Container events are logged with `category='compute'` and distinguished by `source`: `box-lifecycle` (compute hours, already shipped via `recordComputeCost`), `box-spinup`, `box-storage`. Bucketing is by `source`, so a $0 spin-up line stays distinct from compute. This avoids a CHECK-constraint migration (the one real deploy risk) entirely.

2. **Accrue at lifecycle transitions — no billing cron.** Compute hours settle at park/deprovision (existing). Spin-up logs at provision + wake. Storage (snapshot-only, charged only while *parked*) settles at wake and deprovision from `parked_at`. All accrual rides the `scripts/gds/box.js` lifecycle ops that already run — no new always-on infra.

3. **Spin-up is a $0 event marker by default.** DigitalOcean charges no provision fee — billing starts at the first active hour (captured by compute). We still write a spin-up `cost_log` row (at `$0`, overridable via `BOX_SPINUP_COST_USD`) so the ledger records every create/resume as a timestamped line, per the task's "capture spin-up events" requirement. No fabricated cost.

4. **Storage = snapshot rate while parked.** `SNAPSHOT_MONTHLY_USD` (~$0.30, overridable) × parked hours. A running box's disk is already in the droplet hourly rate, so storage is a separate line only for the rare manual-park window (the automated lifecycle deprovisions rather than parks — ADR 0031 / box.js).

5. **Two views.** Builder-own: `GET /box/me` returns a `cost` block (`{spinup_usd, compute_usd, storage_usd, total_usd}`, own-scoped, **never** `allowBoxScope`), rendered on the box panel framed as "tracked, not charged." Archon: `GET /boxes/cost-ledger` returns the full ledger + per-builder totals (declared archon-first per the route-rank auditor), surfaced as a "Dev-Box Costs" section on the `/watch` page — cost oversight without a DB query.

## Consequences

- The "compute" category in the public cost summary now also includes near-$0 spin-up rows; negligible.
- When a real self-fund/charge mechanism lands (drachmae deduction or DO-account handoff), it reads this ledger — the data is already accruing.
- Pure cost math (`storageCostUsd`, `summarizeBoxCost`) is unit-tested (`tests/box_cost.mjs`); the DB writers ride the box-lifecycle integration smoke.
