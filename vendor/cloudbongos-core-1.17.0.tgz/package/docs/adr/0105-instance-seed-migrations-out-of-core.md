# 0105 — Instance/product seed data out of the core migration path

- **Status:** Accepted
- **Date:** 2026-07-02
- **Deciders:** Lars (owner) · Claude (Opus 4.8)
- **Track:** `internal` (Cloud Bongos)
- **Relates to:** [ADR 0062](<redacted>.md) (core ↔ host / instance model), [ADR 0083](<redacted>.md) (module-owned migrations — the enabled-gated precedent this generalizes). Executed under task [#1704](https://example.com/builders#/task/1704); the tactical predecessor was task [#1264](https://example.com/builders#/task/1264) (the 172/173 guards).
- **Amended by:** [ADR 0108](<redacted>.md) §5 — under configurable-root, `migrations/instance/` becomes a genuinely SEPARATE repo's directory (not a subtree of the same checkout), and two independently-versioned repos both adding `NNN_*.sql` will collide on the shared `schema_migrations` stem key. §5 commits to a namespacing/lineage discipline before that ships (task 1885, W5); this ADR's basename-merge-sort ordering and stem-key idempotency in `migrate.sh` are the mechanism §5 extends, not replaces.

## Context

`scripts/migrate.sh` applies **every** file in `migrations/*.sql` on **every** Cloud Bongos instance. But ~16 of those files embed **OTB/product scope-truth** — `INSERT`s into `versions`, `goals`, `done_when_criteria` for OTB's specific project history (game V1/V2/V3, the PMS/GDS/BONGOS platform versions, the goal hierarchy). On a fresh **vanilla self-host** DB those rows either:

- **Crash the boot** — a seed that references a row created out-of-band on OTB (e.g. the V2/V3 game versions and goal 10, which were created via the API, not by any migration) hits a foreign-key violation, and `docker compose up` crash-loops. This is the 2026-07-02 self-host regression.
- **Pollute the DB** — a self-contained seed (one that creates its own version) runs fine but leaves a vanilla instance carrying OTB's versions/goals/criteria, which a fresh instance has no business owning.

Task [#1264](https://example.com/builders#/task/1264) patched the two *crashers* (migrations 172, 173) with per-migration `DO`-block guards keyed on the presence of the referenced OTB rows. That stopped the crash but left the **class** latent: the other ~14 seed migrations still pollute, and nothing stops the next one from re-introducing a crasher. Two adjacent findings: the `MEDUSA_GDS_ONLY` env var was **documented as the vanilla marker but read by no code** (vestigial), and the self-host "does a fresh DB boot?" check (task [#1264](https://example.com/builders#/task/1264)) was a **manual** verification — CI had no Postgres and no Docker job, so the whole class was invisible to CI.

An audit of migrations 001..183 classified them: **10 pure seed files** (no schema — e.g. the `*_planning_seed` files, 172, 173, 182, 183) and **6 mixed schema+seed files** (003, 006, 019, 065, 067, 160). Of the mixed ones, only 003 and 006 *create* OTB scope-truth (versions + their criteria); 019 renames (no-ops on a vanilla DB), 160 self-derives its goals from `versions` (empty ⇒ zero goals), and 065/067 seed **generic platform system principals** (`bfg-system`, `discord-bot-system`) that are not OTB scope-truth.

## Decision

**Instance/product seed data is a declared class that does not run on a non-owning instance.** Concretely:

1. **A dedicated `migrations/instance/` directory** holds the 10 pure seed files (relocated via `git mv` — the stem-key tracking in `migrate.sh` means moving a file never re-runs it on OTB prod). This makes the class visible on disk and is the home for any future instance seed.

2. **`migrate.sh` applies instance seeds only for the owning instance, and defaults OFF.** A single `SEED_INSTANCE` decision:
   - `on` only when `GDS_APPLY_INSTANCE_SEEDS=1` is set explicitly;
   - `off` by default, and **hard `off`** when `MEDUSA_GDS_ONLY=1` (which reviving gives that var a real consumer at last).

   `off` is the safe default for **every** fresh non-owning DB — a vanilla self-host *and* a branded third-party instance — so neither ever inherits OTB's data. The owning instance opts in only when rebuilding its DB from scratch (a DR runbook step); a normal OTB deploy never needs it, because those rows are already in `schema_migrations` and are skipped as-applied regardless.

3. **Order is preserved.** `migrate.sh` merges `migrations/*.sql` and (when on) `migrations/instance/*.sql` into one list **sorted by filename basename**, so the original global numeric sequence is intact — e.g. instance seed `018` still applies before core rename `019`. A from-scratch OTB replay reproduces the original 5 versions / 11 goals / 43 criteria exactly.

4. **The unavoidable seed blocks embedded in the mixed files 003/006 are guarded in place.** `SEED_INSTANCE` is exposed to SQL as the `app.seed_instance_data` GUC (via `PGOPTIONS`, inherited by every `psql`), and each OTB version/criteria `INSERT` is wrapped in `IF current_setting('app.seed_instance_data', true) IS DISTINCT FROM 'off' THEN … END IF`. Platform-universal seeds (achievements) and the `schema_migrations` self-registration stay ungated. Default (GUC unset, e.g. a direct `psql -f`) = seed, so nothing about the historical files' behaviour changes outside `migrate.sh`.

5. **A CI gate makes it un-regressable.** A `selfhost-boot.yml` workflow spins a fresh `postgres:16` service, runs `migrate.sh`, and asserts (a) a **vanilla** boot exits 0 with zero OTB versions/goals/criteria (but achievements present), and (b) an **owning-instance** boot seeds versions. The workflow is authored, but its **landing is gated on blocker 52** — a GitHub App cannot push/merge `.github/workflows/*` changes, which currently strands such PRs at `confirmed` (it stalled task [#1310](https://example.com/builders#/task/1310) the same way). So the structural fix lands on its own first; the gate lands in a follow-up once blocker 52 is resolved (grant the App the `workflows` permission) or via a one-off owner merge, after which the operator flips it to a required check on `main`.

**System principals kept.** `bfg-system` (the `sessions` module is `default: true`) and `discord-bot-system` are generic, inert (`status=inactive`) platform accounts, not OTB scope-truth, and remain on a vanilla instance.

## Consequences

- A vanilla `docker compose up` now boots on a fresh DB with **only schema + platform-universal defaults** — no crash, no foreign-key failure, no leftover OTB versions/goals/criteria. Verified end-to-end against a throwaway `postgres:16-alpine`.
- OTB prod is **unaffected**: every seed is already recorded in `schema_migrations`, so nothing re-runs; a from-scratch OTB DR sets `GDS_APPLY_INSTANCE_SEEDS=1` and replays identically.
- The self-host regression class moves from a manual check toward a CI gate (`selfhost-boot.yml`, authored here) — closing the same "un-gated proof" gap that bit C9, once blocker 52 lets the workflow land.
- **Trade-off:** OTB DR now requires the explicit opt-in flag (documented in `docs/recipes/self-host.md`), chosen over auto-detecting "am I OTB" so that a *branded* self-host can never inherit OTB's seeds. The forward norm (already the practice, per migration 172's header) is to seed instance scope-truth via API/`seed-*.js` scripts, not migrations.
- **Deferred:** an authoring-time `fitness.js` check that flags a new instance-seed `INSERT` in core `migrations/` was considered but not shipped — it false-positives on legitimately-derived seeds (160's `INSERT … SELECT FROM versions`), and the `selfhost-boot.yml` gate already catches the regression empirically. Revisit if the class recurs.
