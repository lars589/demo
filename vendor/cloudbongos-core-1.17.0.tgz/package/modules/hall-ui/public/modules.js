// public-builders/modules.js — the hall "Modules" tab (/builders/modules).
//
// ADR 0107 §9 / task 1776. Three jobs:
//   1. List every on-disk module, split "built by this project" vs. "core-loaded
//      from Cloud Bongos" (src/module-loader/provenance.js decides the split —
//      see GET /api/bongos/modules).
//   2. Enable/disable — a toggle over config/modules.json (POST /modules/:key/enable).
//      Any signed-in builder sees the state; only metic+archon can flip it (the
//      server enforces this — a lower-rank click just gets a 403 + a friendly
//      toast, same as every other rank-gated write in this hall).
//   3. "Submit for review" front door — returns 501 today (the submit pipeline,
//      task 1770, hasn't landed) so the button stays visibly disabled with a
//      tooltip rather than pretending to queue something.

(() => {
  'use strict';

  const API = '/api/bongos';
  // Generated typed client (task 1996 / R09), served as window.BongosClient by
  // /lib/bongos-client.js. baseUrl:'' passes the full `${API}/...` URLs below
  // through unchanged; result-mode ({ status, ok, data }) preserves control flow 1:1.
  const api = window.BongosClient.createClient({ baseUrl: '', credentials: 'same-origin', throwOnError: false });
  const { escapeHtml, $, toast } = window.OTB;

  let viewerRank = 'xenos';
  let canToggle = false;

  function provenanceChip(m) {
    return m.provenance === 'core'
      ? '<span class="mod-chip mod-chip--core">core-loaded</span>'
      : '<span class="mod-chip mod-chip--own">built here</span>';
  }

  function attributionChips(m) {
    const chips = [];
    if (m.author) chips.push(`<span class="mod-chip">by ${escapeHtml(m.author)}</span>`);
    if (m.origin) chips.push(`<span class="mod-chip">from ${escapeHtml(m.origin)}</span>`);
    if (m.license) chips.push(`<span class="mod-chip">${escapeHtml(m.license)}</span>`);
    return chips.join('');
  }

  function cardHTML(m) {
    return `
      <div class="mod-card" data-key="${escapeHtml(m.key)}">
        <div class="mod-card__head">
          <div>
            <div class="mod-card__title">${escapeHtml(m.title || m.key)}</div>
            <div class="mod-card__key">${escapeHtml(m.key)}</div>
          </div>
        </div>
        <p class="mod-card__desc">${escapeHtml(m.description || '')}</p>
        <div class="mod-chips">${provenanceChip(m)}${attributionChips(m)}</div>
        <div class="mod-card__actions">
          <button type="button" class="mod-toggle" data-on="${m.enabled ? '1' : '0'}"
            ${canToggle ? '' : 'disabled title="Metic+ can enable or disable a module"'}>
            ${m.enabled ? 'Enabled' : 'Disabled'}
          </button>
        </div>
      </div>`;
  }

  function render(data) {
    const own = data.modules.filter((m) => m.provenance === 'own');
    const core = data.modules.filter((m) => m.provenance === 'core');

    const sub = $('#modules-sub');
    if (sub) sub.textContent = `${data.modules.length} module(s) — ${own.length} built by this project, ${core.length} core-loaded.`;

    const ownGrid = $('#own-grid');
    if (ownGrid) ownGrid.innerHTML = own.length ? own.map(cardHTML).join('') : '<div class="mod-empty">None on disk.</div>';

    const coreGrid = $('#core-grid');
    if (coreGrid) coreGrid.innerHTML = core.length ? core.map(cardHTML).join('') : '<div class="mod-empty">None yet.</div>';

    const submitStatus = $('#submit-status');
    if (submitStatus) {
      submitStatus.innerHTML = own.length
        ? own.map((m) => `
          <span style="display:inline-flex;align-items:center;gap:8px;margin:4px 12px 4px 0;">
            <button type="button" class="mod-submit" data-submit-key="${escapeHtml(m.key)}"
              ${data.submit_pipeline_live ? '' : 'disabled title="Submit pipeline not live yet — tracked by task 1770"'}>
              Submit "${escapeHtml(m.key)}" for review
            </button>
          </span>`).join('')
        : '<span class="mod-note">No modules of this project\'s own to submit.</span>';
    }

    // Wire toggles.
    document.querySelectorAll('.mod-toggle').forEach((btn) => {
      btn.addEventListener('click', onToggle);
    });
    document.querySelectorAll('[data-submit-key]').forEach((btn) => {
      btn.addEventListener('click', onSubmit);
    });
  }

  async function onToggle(ev) {
    const btn = ev.currentTarget;
    const card = btn.closest('.mod-card');
    const key = card && card.dataset.key;
    if (!key) return;
    const next = btn.dataset.on !== '1';
    btn.disabled = true;
    try {
      const res = await api.request('POST', `${API}/modules/${encodeURIComponent(key)}/enable`, { body: { enabled: next } });
      const body = res.data || {};
      if (!res.ok) throw new Error(body.message || `enable → ${res.status}`);
      btn.dataset.on = next ? '1' : '0';
      btn.textContent = next ? 'Enabled' : 'Disabled';
      toast(body.note || (next ? `${key} enabled.` : `${key} disabled.`), { duration: 3200 });
    } catch (err) {
      console.error('[modules] toggle failed', err);
      toast(err.message || 'Could not change that module.', { duration: 3200 });
    } finally {
      btn.disabled = !canToggle;
    }
  }

  async function onSubmit(ev) {
    const btn = ev.currentTarget;
    const key = btn.dataset.submitKey;
    try {
      const res = await api.request('POST', `${API}/modules/${encodeURIComponent(key)}/submit`);
      const body = res.data || {};
      toast(body.message || 'Not available yet.', { duration: 4200 });
    } catch (err) {
      toast('Could not reach the submit endpoint.', { duration: 3200 });
    }
  }

  async function load() {
    try {
      const meRes = await api.request('GET', `${API}/me`);
      if (meRes.status === 401) { window.location.assign(`${API}/auth/web/start`); return; }
      const mePayload = meRes.data || {};
      const builder = (mePayload && mePayload.builder) ? mePayload.builder : mePayload;
      viewerRank = (builder && builder.rank) || 'xenos';
      canToggle = viewerRank === 'metic' || viewerRank === 'archon';

      const res = await api.request('GET', `${API}/modules`);
      if (res.status === 401) { window.location.assign(`${API}/auth/web/start`); return; }
      if (!res.ok) throw new Error(`modules → ${res.status}`);
      const data = res.data;
      render(data);
    } catch (err) {
      console.error('[modules] failed to load', err);
      const sub = $('#modules-sub');
      if (sub) sub.textContent = 'Could not load modules. Return to the hall and try again.';
      toast('Could not load modules.', { duration: 3200 });
    }
  }

  load();
})();
