-- Uptime monitoring: healthcheck results for each tracked service.
--
-- The Node process polls internal endpoints on a 60-second interval and
-- inserts a row per check. The public /api/pms/public/uptime endpoint
-- reads this table directly — no external SaaS required.
--
-- service names are fixed strings declared in the poller:
--   game_server, api, database

BEGIN;

CREATE TABLE IF NOT EXISTS uptime_checks (
  id          bigserial PRIMARY KEY,
  service     text      NOT NULL,
  status      text      NOT NULL CHECK (status IN ('up', 'down', 'degraded')),
  latency_ms  integer,
  checked_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS uptime_checks_service_checked_at
  ON uptime_checks (service, checked_at DESC);

-- Keep only 90 days of history. Applied by the poller after each insert,
-- not as a trigger (cheap enough at 1 call/min).
-- No cron required — prune happens inline.

INSERT INTO schema_migrations (version) VALUES ('010_uptime') ON CONFLICT DO NOTHING;

COMMIT;
