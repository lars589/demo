-- 064_grade_attempts.sql — BFG session evaluator 6D.6 (ADR 0027).
--
-- task_grades has task_id UNIQUE — it keeps only the LATEST grade, so the number
-- of grade ATTEMPTS (re-grade thrash) is lost. This append-only log records every
-- grader run so that thrash is countable (the #506-class signal: a task graded
-- 3+ times burned a lot of tokens). Written best-effort + post-commit by
-- db.applyGrade — a logging failure never affects the grade that just committed.

CREATE TABLE IF NOT EXISTS grade_attempts (
  id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  task_id      bigint NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  builder_id   bigint REFERENCES builders(id),
  passed       boolean NOT NULL,
  score        numeric(3,1),
  attempted_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_grade_attempts_task ON grade_attempts (task_id);
