// Click-to-copy for the builders' hall — task #519.
//
// Clicking any pasteable command or code on a /builders page copies it to the
// clipboard. Loaded by every hall page (index, primer, diagrams). It is
// deliberately SELF-CONTAINED: primer.html and diagrams.html don't load
// builders.js, so this module ships its own copy logic + toast and depends on
// nothing else. Read-only on the wire — pure clipboard, no server calls.
//
// What's copyable, in priority order:
//   1. Block units — <pre>, the welcome panel's `.welcome__paste` one-liner,
//      and anything tagged `[data-copy]`. Clicking ANYWHERE inside one copies
//      the WHOLE unit (so the "Clone … into this folder" line copies entire,
//      even when you click the URL chip nested inside it).
//   2. Inline chips — <code> (includes `.welcome__cmd`) and <kbd>. Copies just
//      that token (e.g. `/builder-start`).
// Clicks meant for a real link or button inside code are left alone.
(function () {
  'use strict';

  var BLOCK_SEL  = 'pre, .welcome__paste, [data-copy]';
  var INLINE_SEL = 'code, kbd';
  var ANY_SEL    = BLOCK_SEL + ', ' + INLINE_SEL;

  // Resolve the click/keypress target to the element whose text we copy, or
  // null if this interaction isn't a copy. A block unit wins over a nested
  // inline chip; an interactive ancestor (link/button) that wraps the code
  // means "let the real control handle it", so we bail.
  function resolveCopyTarget(node) {
    if (!node || !node.closest) return null;
    // Defer only to GENUINE controls (links, buttons, summaries) — NOT the
    // role="button" we add to copyables ourselves for accessibility, which
    // would otherwise suppress the very copy we want.
    var CTRL_SEL = 'a[href], button, summary';
    var block = node.closest(BLOCK_SEL);
    if (block) {
      // A real link/button sitting between the click and the block → not ours.
      var innerCtrl = node.closest(CTRL_SEL);
      if (innerCtrl && block.contains(innerCtrl) && innerCtrl !== block) return null;
      return block;
    }
    var inline = node.closest(INLINE_SEL);
    if (!inline) return null;
    if (inline.closest(CTRL_SEL)) return null;
    return inline;
  }

  function textOf(el) {
    // innerText preserves <pre> line breaks; strip trailing whitespace only.
    return (el.innerText || el.textContent || '').replace(/\s+$/, '');
  }

  function writeClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext) {
      return navigator.clipboard.writeText(text).then(function () { return true; },
                                                       function () { return legacyCopy(text); });
    }
    return Promise.resolve(legacyCopy(text));
  }

  // Fallback for insecure contexts / older browsers without the async API.
  function legacyCopy(text) {
    try {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.top = '-1000px';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      var ok = document.execCommand('copy');
      document.body.removeChild(ta);
      return ok;
    } catch (_) { return false; }
  }

  // --- toast (own element so it works on pages without builders.js) ---
  var toastEl = null, toastTimer = null;
  function toast(msg) {
    if (!toastEl) {
      toastEl = document.getElementById('copy-toast');
      if (!toastEl) {
        toastEl = document.createElement('div');
        toastEl.id = 'copy-toast';
        toastEl.setAttribute('role', 'status');
        toastEl.setAttribute('aria-live', 'polite');
        document.body.appendChild(toastEl);
      }
    }
    toastEl.textContent = msg;
    toastEl.dataset.visible = '1';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.dataset.visible = '0'; }, 1800);
  }

  function flash(el) {
    el.dataset.copied = '1';
    setTimeout(function () { delete el.dataset.copied; }, 900);
  }

  function doCopy(el) {
    var text = textOf(el);
    if (!text) return;
    writeClipboard(text).then(function (ok) {
      if (ok) {
        flash(el);
        var preview = text.length > 52 ? text.slice(0, 49) + '…' : text;
        toast('Copied: ' + preview);
      } else {
        toast('Could not copy — select the text and copy it manually.');
      }
    });
  }

  // Delegated handlers — one pair for the whole document, so dynamically
  // rendered content (the welcome panel, the primer markdown) is covered with
  // no re-binding.
  document.addEventListener('click', function (e) {
    var el = resolveCopyTarget(e.target);
    if (el) doCopy(el);
  });
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' && e.key !== ' ' && e.key !== 'Spacebar') return;
    // Only act when the focused element is itself the copy target (a tab-stop
    // we added below) — don't swallow space/enter elsewhere.
    var el = resolveCopyTarget(e.target);
    if (el && el === e.target) { e.preventDefault(); doCopy(el); }
  });

  // Decoration: title hint for discoverability on every copyable, plus a tab
  // stop on the PRIMARY surfaces (blocks + command chips) so keyboard users
  // can reach them — without flooding the tab order with every inline <code>
  // token in the primer prose.
  function decorate(el) {
    if (!el || el.dataset.copyReady) return;
    el.dataset.copyReady = '1';
    if (!el.title) el.title = 'Click to copy';
    var primary = el.matches(BLOCK_SEL) || (el.classList && el.classList.contains('welcome__cmd'));
    if (primary && !el.hasAttribute('tabindex')) {
      el.setAttribute('tabindex', '0');
      el.setAttribute('role', 'button');
      el.setAttribute('aria-label', 'Copy to clipboard');
    }
  }
  function decorateAll(root) {
    var scope = root && root.querySelectorAll ? root : document;
    scope.querySelectorAll(ANY_SEL).forEach(decorate);
  }

  function init() {
    decorateAll(document);
    // Catch content rendered after load (welcome panel, primer markdown).
    if (window.MutationObserver) {
      var obs = new MutationObserver(function (muts) {
        for (var i = 0; i < muts.length; i++) {
          var added = muts[i].addedNodes;
          for (var j = 0; j < added.length; j++) {
            var n = added[j];
            if (n.nodeType !== 1) continue;
            if (n.matches && n.matches(ANY_SEL)) decorate(n);
            if (n.querySelectorAll) n.querySelectorAll(ANY_SEL).forEach(decorate);
          }
        }
      });
      obs.observe(document.body, { childList: true, subtree: true });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
