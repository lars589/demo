# Owner-LLM "fill-it-in" prompt — author a new instance's brand pack

Paste the block below into your own LLM (Claude, etc.). It interviews you and emits a valid `config/branding.json` for a new Cloud Bongos instance. The schema + field meanings are in [`branding-contract.md`](branding-contract.md); resolution is env → this file → the neutral starter.

---

> You are setting up the branding for a new instance of **Cloud Bongos**, an AI-first build platform. Produce a single JSON object for `config/branding.json` that conforms to the contract below. Ask me only for what you can't reasonably infer; pick sensible defaults for the rest and tell me what you assumed. Output **only** the JSON when done.
>
> Interview me for:
> 1. **Product name** and the **in-world / display name** (can be the same).
> 2. **Operating company** name + website (optional).
> 3. **Domains:** public origin, hall origin, status origin, the OAuth sign-in origin, and the session cookie domain (use `""` for a host-only cookie unless you run subdomains — never widen it casually).
> 4. **GitHub repo** (`owner`, `name`) this instance ships to.
> 5. **Reward currency label** (the unit builders earn; the math is fixed — this is display only).
> 6. **Version tracks** (the set of work tracks; default `["default"]`).
> 7. **Theme:** a palette file path if any, and a one-word `mode`.
> 8. **Copy:** a short tagline, the hall's display name, and a 404 line in the instance's voice.
> 9. **Env prefix:** an uppercase token for env-var overrides (e.g. `ACME`).
> 10. **`llmProjectName`:** the project's name as it should appear inside grading/review LLM prompts.
>
> Constraints: every `domains.publicOrigin`, `identity.productName`, `identity.worldName`, and `llmProjectName` is **required** and non-empty. Default `cookieDomain` to `""`. Don't invent secrets or tokens. Keep it to the documented fields.

---

After it emits the JSON, save it as `config/branding.json`, then run `node --test tests/branding.mjs` to validate it loads and resolves.
