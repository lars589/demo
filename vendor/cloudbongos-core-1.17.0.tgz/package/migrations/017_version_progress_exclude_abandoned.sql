-- PMS task #218 — version_progress should not count abandoned tasks.
--
-- Background: migration 012 rebuilt version_progress to treat completed +
-- confirmed + shipped as "done" but kept abandoned tasks in the denominator.
-- That's wrong: abandoned is a terminal state (deliberately cut), not pending
-- work. It should be filtered out just like __smoke__ and parent tasks.
--
-- Effect: closing versions surface their true completion ratio. PMS-V2 (which
-- abandoned 5 tasks during build, mostly debris + redundant rows) jumps from
-- 92% to 100% once its last in-flight task lands. The progress-bar metric now
-- matches "of the work this version actually scoped, what shipped?"
--
-- DROP+CREATE rather than CREATE OR REPLACE because Postgres rejects the
-- latter when the column list/order would change. Here the columns are
-- identical to migration 012 — the only diff is one extra clause in each
-- FILTER — but DROP+CREATE is the safe pattern for view edits (see PMS
-- learnings).

DROP VIEW IF EXISTS version_progress;
CREATE VIEW version_progress AS
SELECT v.id AS version_id,
       v.name,
       v.track,
       v.status,
       count(*) FILTER (
         WHERE t.status IN ('completed', 'confirmed', 'shipped')
           AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
           AND NOT EXISTS (SELECT 1 FROM tasks c WHERE c.parent_task_id = t.id)
       ) AS shipped_count,
       count(*) FILTER (
         WHERE t.status <> 'abandoned'
           AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
           AND NOT EXISTS (SELECT 1 FROM tasks c WHERE c.parent_task_id = t.id)
       ) AS total_count,
       COALESCE(SUM(CASE
         WHEN t.status IN ('completed', 'confirmed', 'shipped')
              AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
              AND NOT EXISTS (SELECT 1 FROM tasks c WHERE c.parent_task_id = t.id)
         THEN (6 - COALESCE(t.priority, 5))
         ELSE 0 END), 0) AS shipped_weight,
       COALESCE(SUM(CASE
         WHEN t.status <> 'abandoned'
              AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
              AND NOT EXISTS (SELECT 1 FROM tasks c WHERE c.parent_task_id = t.id)
         THEN (6 - COALESCE(t.priority, 5))
         ELSE 0 END), 0) AS total_weight
  FROM versions v
  LEFT JOIN tasks t ON t.version_id = v.id
 GROUP BY v.id, v.name, v.track, v.status;
