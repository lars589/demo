-- Migration 182 — Consolidate GDS-V4 into BONGOS-V1 + split out the Bongos desktop app
-- ============================================================================
-- Archon-directed project cleanup, 2026-07-02 (task 1709, ADR 0103; with Lars).
--
-- GDS-V4 and BONGOS-V1 were two parallel internal / Cloud-Bongos versions with
-- no clean divide. This migration makes BONGOS-V1 the single go-forward internal
-- (Cloud Bongos platform) version, carries GDS-V4's still-relevant open work
-- into it, splits the Bongos DESKTOP APP into its own goal, prunes superseded
-- work, and freezes GDS-V4.
--
-- REVERSIBLE by construction: no destructive drops — only status / version_id /
-- goal_id / one dependency-edge mutations. The exact before-state is snapshotted
-- in the task-1709 session notes. See ADR 0103 for the full rationale + the
-- ADR-0095 (grep-over-embeddings) decision that retires the C1 recall arm.
--
-- Idempotency: migrate.sh applies each numbered migration once; the goal INSERT
-- is additionally NOT-EXISTS-guarded so a manual re-run cannot double-create it.
-- ============================================================================

BEGIN;

-- 1. Create the "Bongos desktop app" goal under BONGOS-V1 and reparent the app
--    tasks (mascot/brand, branded download + auto-update, the cloudbongos.com
--    landing/download page, the feedback-capture app, the absorbed Dev Box
--    switch). scope_modules stays empty until the code carve (bongos-app/ ->
--    modules/bongos-app/) creates the module, at which point the goal is scoped
--    to it. See ADR 0087 (the app absorbs Dev Box).
DO $$
DECLARE app_goal_id bigint;
BEGIN
  SELECT id INTO app_goal_id
    FROM goals
   WHERE version_id = 'BONGOS-V1' AND title = 'Bongos desktop app'
   LIMIT 1;

  IF app_goal_id IS NULL THEN
    INSERT INTO goals (version_id, title, description, scope_modules, created_by, status)
    VALUES (
      'BONGOS-V1',
      'Bongos desktop app',
      'The Cloud Bongos DESKTOP APP (bongos-app/): a Zoom-style feedback-capture '
      || 'walkthrough tool that produces one model-agnostic prompt bundle for a coding '
      || 'agent, and the umbrella app that absorbs the Dev Box switch (ADR 0045/0072/0087). '
      || 'Distinct from the Cloud Bongos PLATFORM (the GDS engine, modules, grader, hosting). '
      || 'Covers: mascot/brand (Bongo Buddha), branded download + auto-update, the '
      || 'cloudbongos.com landing/download page, and the dev-box desktop client. The code '
      || 'carve bongos-app/ -> modules/bongos-app/ is tracked as a task under this goal.',
      '{}',
      1,
      'open'
    )
    RETURNING id INTO app_goal_id;
  END IF;

  -- App tasks currently in GDS-V4: rebind version AND attach to the app goal.
  --   1523 interactive mascot · 1294 devbox-app go-live bump ·
  --   1463 devbox-app build workflow · 1484 dev-box host-key / app re-pin
  UPDATE tasks
     SET version_id = 'BONGOS-V1', goal_id = app_goal_id, updated_at = now()
   WHERE id IN (1523, 1294, 1463, 1484)
     AND version_id = 'GDS-V4';

  -- App tasks already in BONGOS-V1: attach to the app goal.
  --   1311 branded download + auto-update · 1682/1700/1701 Bongo Buddha anim ·
  --   1702 cloudbongos.com landing/download page
  UPDATE tasks
     SET goal_id = app_goal_id, updated_at = now()
   WHERE id IN (1311, 1682, 1700, 1701, 1702)
     AND version_id = 'BONGOS-V1';
END $$;

-- 2. Abandon 19 superseded tasks:
--      C1 recall/embeddings arm (939,962,966-971,1221) — retired by ADR 0095's
--        grep-over-embeddings decision (Anthropic + Sourcegraph removed embedding
--        indexes; the endorsed path is meaning-in-source, tracked separately).
--      Old V3.R## grader tasks (201,202,242,292,388,490,492) — superseded by the
--        shipped 4-worker grader panel + ADR 0089.
--      T-NNN task-ref migration (753,754,755) — the current hall-link convention
--        already works and is enforced.
UPDATE tasks
   SET status = 'abandoned', updated_at = now()
 WHERE id IN (939,962,966,967,968,969,970,971,1221,
              201,202,242,292,388,490,492,
              753,754,755)
   AND version_id = 'GDS-V4'
   AND status IN ('backlog', 'ready');

-- 3. Sever the 758 -> 753 dependency edge. 753 (T-NNN ADR) is being abandoned;
--    758 ("document the hall as the canonical doc surface") is kept and must not
--    be left permanently unclaimable (DEPS_NOT_SHIPPED) by a dead dependency.
--    Delete from both the polymorphic table (the gate read) and the legacy one.
DELETE FROM dependencies
 WHERE from_kind = 'task' AND from_id = 758 AND to_kind = 'task' AND to_id = 753;
DELETE FROM task_dependencies
 WHERE task_id = 758 AND depends_on_task_id = 753;

-- 4. Move two misfiled game-art tasks to product V2 (they are world art, not
--    internal-track work): 586 grass_on_sand variety, 587 player_walk family.
UPDATE tasks
   SET version_id = 'V2', updated_at = now()
 WHERE id IN (586, 587)
   AND version_id = 'GDS-V4';

-- 5. Carry every remaining NON-TERMINAL GDS-V4 task (the platform work) forward
--    to BONGOS-V1. Non-terminal = backlog/ready/completed/blocked. This leaves
--    the in-flight tail (10 confirmed + 1 active) and terminal history
--    (shipped/abandoned) attributed to GDS-V4, exactly like a normal
--    version-close carry-over. Runs AFTER steps 1/2/4 so the app / abandoned /
--    product tasks are already out of scope; self-correcting for the remainder.
UPDATE tasks
   SET version_id = 'BONGOS-V1', updated_at = now()
 WHERE version_id = 'GDS-V4'
   AND status IN ('backlog', 'ready', 'completed', 'blocked');

-- 6. BONGOS-V1 becomes the single go-forward internal version: rename it off the
--    misleading "Bongos App" title (the app is now a GOAL inside it, step 1) and
--    mark it 'building' (it is actively being built).
UPDATE versions
   SET name = 'Cloud Bongos — platform (V1)', status = 'building'
 WHERE id = 'BONGOS-V1';

-- 7. Freeze GDS-V4 — sealed to new planning. Its 11 in-flight tasks land as its
--    final shipped history; its 358 shipped + 51 abandoned rows stay as the
--    archive of what GDS-V4 delivered. ('frozen', not 'shipped': GDS-V4 did not
--    ship — it was absorbed — and 'shipped' would falsely read 100% + could gate
--    the in-flight tail.)
UPDATE versions
   SET status = 'frozen'
 WHERE id = 'GDS-V4'
   AND status <> 'shipped';

COMMIT;
