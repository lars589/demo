-- 121_box_code_version.sql — dev-box code-version reporting (idea 332, task 1316).
--
-- Why
-- ---
-- Boxes already auto-update: infra/box-source-fetch.sh (cron */10) `git pull
-- --ff-only`s /workspace and self-updates its own baked scripts/crons (#985). But
-- two failure modes leave a box silently STALE with no visibility:
--   1. A box provisioned BEFORE that machinery existed has no self-update cron, so
--      it can never pull the fix — only a rebuild helps (box-LarsCode, 2026-06-07).
--   2. When `pull --ff-only` can't fast-forward, the script logs and leaves the
--      tree as-is — stale, silently.
-- A stale box then fails CRYPTICALLY (no shared art key delivered, host-key
-- reporter absent → connect fails) and the builder has no idea the cause is old
-- code. This adds the VISIBILITY layer — the box reports its HEAD commit so the
-- server can flag "running old code → rebuild." (We never auto-reset: that would
-- clobber a builder's uncommitted work — ADR 0072.)
--
-- Columns on builder_boxes (same report-up shape as host_keys, migration 105):
--   code_sha          — the box's /workspace HEAD commit sha (40-hex), reported up.
--   code_committed_at — that commit's date (ISO), for the "how far behind"
--                       comparison against the server's own deployed commit date
--                       (src/build-info.js).
--   code_reported_at  — when the box last reported; NULL on an active box past the
--                       provision grace ⇒ the box is too old to even run the
--                       reporter (a pre-machinery box) ⇒ stale.
--
-- Staleness is COMPUTED in code (boxes.computeCodeStaleness), not stored, so the
-- thresholds live with the logic + tests — nothing to migrate to tune them.
--
-- Idempotent: safe to re-run.

ALTER TABLE builder_boxes ADD COLUMN IF NOT EXISTS code_sha          text;
ALTER TABLE builder_boxes ADD COLUMN IF NOT EXISTS code_committed_at timestamptz;
ALTER TABLE builder_boxes ADD COLUMN IF NOT EXISTS code_reported_at  timestamptz;

INSERT INTO schema_migrations (version) VALUES ('121_box_code_version')
  ON CONFLICT (version) DO NOTHING;
