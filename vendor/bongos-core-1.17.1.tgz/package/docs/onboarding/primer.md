# The Citizen's Primer

*Read this before you claim your first work. ~10 minutes.*

You're about to build inside Off the Boats, a project that runs on a small purpose-built dev system. This primer is the one document that gives you enough context to ask Claude smart questions and ship your first task without getting lost. Read it linearly — it's short on purpose.

When you're done, open [/builders](https://example.com/builders) and run `/builder-start`. There's no separate "I have read it" step anymore — reading the primer is on your honor, and the work queue is already open to you.

---

## What Off the Boats is

Off the Boats is a web experience that drops visitors into a single, persistent, playable digital world set in ancient Greece. Inside the world, players can spend real money to buy **physical goods** (fulfilled by a third-party logistics company called Example) and **digital assets** that develop the shared world. The world is never wiped — every interaction is permanent. The brand is mythic and underground: prices feel like a discovered secret, and the world reads as ancient even though the inciting object is a literal shipping container washed ashore. Visit [example.com](https://example.com) to see it.

## What the GDS is

The **Game Development System** (GDS) is the project's internal nervous system. It's a Postgres-backed task database with a small HTTP API, a CLI (the `/builder-*` slash commands), and a public dashboard at [status.example.com](https://status.example.com). Every change to the project — code, docs, art, migrations, even direct DB writes — happens under a **claim** on a GDS task. The claim is what makes parallel work safe (no two builders editing the same files at once) and what gives credit-tracking, cost-tracking, and the karma system something concrete to hang off.

You don't need to understand the GDS schema to ship work. You just need to know: *claim a task, work on it inside your worktree, ship it.* The CLI handles the rest.

## The claim → ship lifecycle

Every piece of work moves through this loop:

```
backlog ─────▶ ready ─────▶ active ─────▶ completed ─────▶ confirmed ─────▶ shipped
   │             │             │              │                │               │
   │             │             │              │                │               └─ deployed to example.com
   │             │             │              │                └─ verification passed, credits awarded
   │             │             │              └─ you said "done", ship.js runs the smoke tests
   │             │             └─ you ran /builder-claim (locks the task to your session)
   │             └─ dependencies all shipped (auto-promoted by a DB trigger)
   └─ task exists in the queue but isn't open yet
```

You drive the middle three states. The system handles the rest.

**One claim at a time** while you're a Xenos. New builders hold a single active claim — ship it (or release it) before opening another, so the first work gets carried through. The limit is keyed to your rank: it lifts automatically when you graduate to **Thetes** (after your third shipped task), after which you can hold parallel claims if you want.

When you ship, `ship.js` runs the project's **smoke tests** and the quality grader. If they pass, the task auto-confirms and **credits land** (this is the `completed → confirmed` edge — *not* the final deploy). The final `confirmed → shipped` hop — landing on `main` and deploying — is then handled for you, but *what it takes to land* depends on your rank and what you changed; the next section covers it. (There used to be an up-front `touches[]` "drift scanner" here too; it was retired — `git merge` at land time is the real collision detector. See [ADR 0049](../adr/<redacted>.md).)

## How work lands — and what auto-ships

`confirmed → shipped` is not a person clicking "merge". When you ship, `ship.js` opens a pull request and the project lands it for you — **nobody pushes to `main` by hand**. The PR has to go green on the automated checks (the test suite, a secret scan, and the **gate-review** classifier); the server then auto-merges it and `main` deploys to production. If a green PR ever stalls, a server sweep lands it within about five minutes, and `/merge-mode` is the manual fallback.

The one thing that decides whether your ship is **instant** or **waits for an Archon** is *what your change touches*, weighed against your rank by the **gate-review** step ([ADR 0058](../adr/<redacted>.md)):

| What your change touches | What happens |
|---|---|
| **Normal work** — game code, art, docs, tests, most of `src/` | **Auto-merges on green for any rank**, Xenos included. No approval. |
| **A protected "gate surface"** — migrations, server routes, the ship / deploy plumbing | Auto-merges **only if you are Metic or above** (rank trust). A Xenos or Thetes ship here **waits for an Archon** to approve. |
| **The safety core** — the gate's own machinery, the deploy switch, the rank / permission enforcement | **Always** waits for an Archon, whatever your rank. |

So your first tasks **ship with no approval**: the newcomer chores — a tile, a doc fix, a unit test, a batch of ideas — all sit on the safe side of that line, and a clean ship merges and deploys on its own. You only meet the Archon gate if your change reaches into the project's own safety machinery, which builders below Metic are asked to stay clear of anyway ([ADR 0043](../adr/<redacted>.md)). Landing is always the GDS's job: you never run `git push origin main`, `ssh` to the server, or deploy by hand — `/builder-ship` opens the PR and the server does the rest ([ADR 0042](../adr/<redacted>.md)).

## The rank ladder

Four ranks, in ancient-Greek-civilization order:

| Rank       | What it means                                                          | What it unlocks                                                                  |
|------------|------------------------------------------------------------------------|----------------------------------------------------------------------------------|
| **Xenos**  | Default for new builders. "Sandbox" tier.                              | Can only claim tasks flagged `newcomer_friendly`. Read everything. No mutations. |
| **Thetes** | Graduated newcomer. You reach it **automatically after your 3rd shipped task** — no one has to promote you. | Claim **any** task in the general queue (not just newcomer-friendly). Still no triage/blocker/scope powers. |
| **Metic**  | Approved working rank. The "real builders."                            | Claim any ready task. Idea triage, blocker review. Most of the work happens here. |
| **Archon** | Project keeper.                                                        | Scope mutations, rank changes, infra-level operations.                            |

So the sandbox is short: ship three small `newcomer_friendly` tasks and the city opens the whole queue to you on its own (the jump to **Metic** — with its triage/trust powers — is still a deliberate Archon promotion). Rank lives on the `builders.rank` column in the production database and is checked server-side on every privileged request — **with no caching**. A demotion takes effect on your next request. You cannot escalate your own rank by editing local files; the server is the source of truth. See [ADR 0016](../adr/<redacted>.md) and [ADR 0034](../adr/<redacted>.md) for the full trust model.

## Drachmae and karma

Two parallel reputation tracks. You don't need to *do* anything special to earn either — claim a task, do good work, ship it, and the system tracks both. The full mechanics (formulas, the kind table, the budget cap, every karma source) live in **[Drachmae & karma — how you get paid](drachmae-and-karma.md)**; here's the shape of it.

- **Drachmae** (called "credits" in code) are your **equity** in the project — a score and a stake, *not* a currency you spend on anything. They only go up, and they persist if you leave and come back. Most of your drachmae now come from a **cost-plus reward on each shipped session**: the server prices the LLM tokens your work actually burned and pays you that real cost **plus 20%** ([ADR 0054](../adr/<redacted>.md)). On top of that, each task pays its `credits_reward` adjusted by the *kind* of work (a captured learning or a resolved blocker is worth 1.5×; cleanup 0.8×), and capturing an idea that someone else then ships earns you a 25% bonus ([ADR 0023](../adr/<redacted>.md)). Credits land at the `completed → confirmed` edge — when verification passes, not at deploy. See the standings on [/builders](https://example.com/builders).

- **Karma** is a *separate* signal that measures **peer trust** — how other builders rate the *way* you work, not how much you ship. It's earned when Metic-and-above builders upvote your confirmed work (tallied weekly), when a proposal of yours is ratified, and when you capture ideas; it can also go *down* if you break things. Karma shows up on your profile (with a 30-day trend) and as a sortable column on the leaderboard, and it feeds your "builder strength" score. **It does not gate rank promotions** — those happen automatically by ship count (Xenos → Thetes after three ships) or by an Archon's deliberate decision. A builder who ships fast but breaks things gains drachmae and loses karma; a builder who ships thoughtfully gains both.

One more thing worth knowing: builders are **uncapped by default** — your spend is tracked (it's the cost side of the same coin the reward is computed from) but never blocks you. There's no default budget. An Archon *can* set a per-builder **monthly budget cap** as a manual brake on a runaway; if one is set for you, you get a warning at 80% and `/builder-ship` pauses at 100% until it's raised ([ADR 0085](../adr/<redacted>.md)).

## How to ask Claude about anything

Claude is your pair-programmer here, but it doesn't know the project until you point it at the right files. The cheapest way to get good answers is to **name the surface you're looking at**. Some examples that work well:

- *"Read [`CLAUDE.md`](../../CLAUDE.md) — what version are we currently building and what's the next claimable thing?"*
- *"Read [`docs/architecture.md`](../architecture.md) — explain how the WorldRoom enforces server-authoritative movement."*
- *"My task touches `src/bongos/auth.js` — read it and `docs/canonical-permissions.md`, then tell me which routes I'd need a `requireRank` gate on."*
- *"Look at the last 5 entries in [§13 of CLAUDE.md](../../CLAUDE.md#13-session-log) — what was the most recent V3 task that touched the builders' hall?"*

What doesn't work well:

- *"How does the GDS work?"* — too open. Claude will hallucinate or read everything inefficiently.
- *"What should I work on?"* — ask `/builder-start` instead. That's the GDS's job, not Claude's.
- *"Is this safe to ship?"* — ask `/builder-ship` (it runs the smoke tests and, when enabled, the quality grader). Or run `/code-review` if you want a second opinion.

**Use slash commands for plumbing, use Claude for thinking.** The `/builder-*` skills know how to talk to the GDS. Claude knows how to read your code and reason about it. Don't ask Claude to do something a slash command already does — it's slower and less reliable.

## What the system remembers for you

As you work, Claude writes down durable facts — your standing preferences, a gotcha that cost real time, the current state of the project — so the next session doesn't start cold. You don't manage any of this by hand, but it's worth knowing the shape:

- **The map** (`MEMORY.md`) — a short index loaded at the **start of every session**: one line per memory, just enough to know *what* is known and where the detail lives. Kept deliberately small.
- **The drawer** — the full notes themselves. They live on your machine, sync to the server (so your memory follows you across machines and boxes), and are searchable with `/recall`. They cost nothing until something fetches them.

The map stays light on its own: a session-start guard warns if it's drifting large, and an auto-tidy moves the oldest, least-relevant notes off the map into the drawer when it crosses a threshold — **nothing is deleted**, it's just no longer loaded every session (a `/recall` away when a task needs it). Your standing rules, and anything pinned, always stay on the map. Full picture: [ADR 0074](../adr/<redacted>.md) and [diagram 4 — the architecture](diagrams/).

## Where to find more depth

The whole project's source-of-truth index is [`CLAUDE.md`](../../CLAUDE.md). Two starting points:

- **For *what's true right now*** — go to the GDS DB via `/builder-start` or [/builders](https://example.com/builders). Tasks, claims, ranks, credits, costs all live there. CLAUDE.md is *descriptive*; the DB is *authoritative*.
- **For *why we chose what we chose*** — go to [`docs/adr/`](../adr/) (Architecture Decision Records). Each ADR is one decision with the trade-offs that drove it.

Other depth, in roughly the order you'll need it:

- [`docs/onboarding/drachmae-and-karma.md`](drachmae-and-karma.md) — the full reward economy: how drachmae and karma are earned, the cost-plus session reward, and the monthly budget cap
- [`docs/architecture.md`](../architecture.md) — live system: droplet, stack, schema, API surface
- [`docs/modules-contract.md`](../modules-contract.md) — the product is built as a small core plus swappable `modules/<key>/` (dev boxes, the game, Discord, art, and more); this is the live roster and how a task lands inside one
- [`docs/canonical-permissions.md`](../canonical-permissions.md) — who can do what (rank gates)
- [`docs/file-map.md`](../file-map.md) — where every folder is and what it contains
- [`docs/recipes/`](../recipes/) — long-form ops gotchas (read before deploying)
- [`docs/onboarding/diagrams/`](diagrams/) — pan-and-zoom maps of the task lifecycle, rank ladder, the credit economy, the complete architecture (where your work runs and how it reaches production), and versioning

You don't need to read these now. Bookmark them; come back when something specific is unclear.

## Get set up on your machine

You don't need to be a programmer to build here. Entry to the project is **approval-gated**: a stranger can't just sign in with GitHub — you first ask for entry on the [builders' hall](https://example.com/builders) and an Archon admits you. Since you're reading this gated primer, you've already been admitted.

### Where your work runs — screen, worker, brain

Claude Code is **three pieces that can live in different places**:

- **The screen** — the window you look at and type into. Always on *your* device (the Claude desktop app, or a browser tab). It just shows files and sends your messages.
- **The worker** — the part that opens files, runs commands, edits code, runs the project. Runs in **one place you choose**.
- **The brain** — the AI model itself. **Always on Anthropic's servers**, whatever else you pick.

You only ever choose **where the worker goes** — and that single choice *is* your setup path.

### Three ways to set up

| Path | Where the worker runs | Who it's for |
|---|---|---|
| **Cloud box** — *the default for new builders* | A dev box we create for you on DigitalOcean; your desktop app connects to it | Anyone new on a Mac or Windows machine. Nothing to install but the app — the code never lands on your own disk |
| **Remote Control** | The **same** cloud box, but driven from a browser tab — [step-by-step guide](browser-terminal-guide.md) | Chromebooks / iPads / phones that can't run the desktop app |
| **Local** — *trusted builders only (Metic and up)* | Your own computer | Power users who'd rather run the code on their own hardware to save the box cost |

Your **first** cloud box is created hands-off; a returning box wakes itself; you never wait on an operator. (Entry to the project is already approval-gated — an Archon admitted you when you joined — so there's no separate per-box approval step.)

> **Why is Local trusted-only?** Below Metic, the project's code lives **only inside the cloud box we control** — gated, revocable, and audited. Holding a permanent copy on your own machine is a trust grant that arrives when you're promoted to Metic, not on day one. New builders work in the box.

> **Where things stand today.** The cloud-box on-ramp is built *and* now verified end-to-end — the desktop on/off app, the browser terminal, the per-builder sandbox preview, and the box → production ship path (a credential-less box uploads its branch and the server merges + deploys it via a GitHub App credential) have all shipped, and the whole box → production chain has been hardware-verified on a real box ([#1027](https://example.com/builders#/task/1027), [#1028](https://example.com/builders#/task/1028)). So the **cloud box is the proven default for new builders.** The **local-clone route below is the permanent home for Metic-and-up builders** — a fully supported alternative, not a stopgap. The single map that shows the whole picture — device, dev box, the per-builder memory layer, the server (authority *and* production), and how code travels from a box to prod — is [diagram 4, *The complete architecture*](diagrams/).

> **Why a copy of the code at all?** The `/builder-*` commands you'll use every session aren't a separate download — they live *inside* the project's code (in `.claude/skills/`). The moment Claude Code **starts a session on a folder (or box) that already holds the code**, all the commands appear automatically. So "get the code" and "get the commands" are the same step — there's no plugin or zip to install. (One wrinkle: if you *clone the code mid-session into a folder that started empty*, the commands won't appear until you start a fresh session on that folder — step 3 handles it.)

### The steps that work today (local route)

Take them in order — each one sets up the next, from "I'm admitted" to "I'm looking at work I can claim."

**1. Install the Claude desktop app.** Claude Code runs in a desktop app, **not** in the website — so you can't do this from a browser tab. Download it for your computer at **[claude.com/download](https://claude.com/download)** (Mac and Windows). Install it, open it, and sign in. You'll work in its **Code** tab.

**2. Accept your invitation to the code (check your email).** When the Archon admitted you, GitHub emailed you a message like *"… invited you to collaborate."* Open it, click **View invitation**, then **Accept**. GitHub then drops you on the project's repository page. That page is just the code sitting at rest — a list of folders and files. **You don't need to do anything there**; accepting the invite is the whole point of this step. (No email? Check your spam folder, or ask the Archon to (re)send the repository invite — GitHub invitations can expire after 7 days.)

**3. Open the code in Claude Code.** Back in the Claude desktop app's **Code** tab, you'll start a session on a folder. The easiest path — let Claude do the technical part for you:
   - Make a new, empty folder on your computer (anywhere — your Desktop is fine).
   - In Claude Code, point a new session at that empty folder.
   - Type this one plain-English message and send it:
     > *Clone the GitHub repository I was just invited to into this folder and open it as the project.*
   
   Claude handles the rest (this is the "git" plumbing you may have heard about — you don't need to learn it). When Claude asks for permission to reach GitHub, say yes — the repository is private, so it needs your go-ahead. If it asks which repository, paste the web address from the repo page you landed on in step 2.
   
   Once it finishes, that folder **is** the project. **One catch worth knowing:** the `/builder-*` commands came down *with* the code, but Claude Code only loads them when a session *starts* on a folder that already contains them — and this session started on an *empty* folder. So before the next step, **start a fresh Claude Code session on this same folder**: end this session and open a new one pointing at the folder. (Starting fresh is the clean way — the new session scans the folder from scratch, and the `/builder-*` commands will all be there.)

**4. Enrol yourself and begin.** In the **fresh** session, type `/builder-setup` — or just say *"set up builder"* in plain English — and follow the prompts. It signs you in with GitHub once and registers you in the GDS so the commands know who you are. Then type `/builder-start` to see the works you can claim right now.

If a `/builder-*` command ever says "no GDS session," just run `/builder-setup` again — that re-links you. And if `/builder-setup` itself comes back **"unknown command,"** you're almost certainly still in the session that did the cloning — start a fresh session on the folder (end of step 3) and it'll be there.

> **Prefer a terminal? (the quicker path if you're technical.)** Steps 3–4 above are the no-terminal route. If you're comfortable on a command line, skip them — clone the repo yourself, `cd` into it, and run the bootstrap:
>
> **Before you start**, have three things ready: **Git** (check `git --version`; get it from [git-scm.com](https://git-scm.com/downloads)), the **Claude Code** desktop app ([claude.com/download](https://claude.com/download)), and a **GitHub account that's been invited to this private repo** (accept the emailed invite from step 2). Node ≥ 22 and Python ≥ 3.10 are checked by the bootstrap script — it prints the install command if either is missing, so you don't need them before cloning.
>
> **Step 0 — get the project onto your machine.** Clone the repo and `cd` into the folder it creates:
>
> ```sh
> git clone https://github.com/example-owner/example.git
> cd example
> ```
>
> **Then bootstrap** from inside that folder: `./scripts/setup-builder.sh` (macOS/Linux) — or `node scripts/setup-builder.js` (Windows, or any OS). It checks your toolchain, installs dependencies, and runs the same GitHub sign-in in one shot — no Claude-session juggling. Either route lands you in the same place.

## Your first task

Run `/builder-start` to see what you can claim — no acknowledgment step needed, the queue is open. New builders see only `newcomer_friendly` tasks — small, well-scoped, easy to finish in one sitting. Pick one that looks interesting, claim it with `/builder-claim N`, do the work, and ship it with `/builder-ship`.

When you ship your **first** task, drachmae land in your column and you're inducted as a citizen of Example. Ship your **third** and you graduate to **Thetes** — the one-claim limit lifts and the whole general queue opens to you. Welcome.

## Your own dev box

Every active builder — from your very first day as a **Xenos**, and **whatever your craft** (engineer, artist, or ideator) — gets a **personal dev box and a live game preview of your own**. There's no separate Archon approval to unlock them: being admitted to the project *is* the approval. Two everyday commands put them at your fingertips:

- **`/builder-box`** — your box's control panel. It shows whether your box is awake, what it has cost, and your sign-in details, and it can **wake or (re)create your box hands-off** when it's asleep — you never wait on an operator. It's also where you find your **sandbox URL** (below) and, on a Chromebook or tablet, the browser-terminal link. Reach for it whenever you're unsure your box is up or you need to get back onto it.
- **`/builder-stage`** — your private preview. Before you ship a change that touches the game, run `/builder-stage` to push your current edits to your **sandbox** — a personal copy of the game at `sandbox-<your-login>.example.com` that reflects only *your* work-in-progress. Open the link, watch your change running for real, and only then ship it. Nothing you stage there touches the live game or anyone else's box.

In short: `/builder-box` gets you a workshop; `/builder-stage` lets you see your work on the shelf before it reaches the shop floor.
