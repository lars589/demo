-- 055_task_criteria.sql — #435: structured criterion↔task link.
--
-- WHY THIS EXISTS
-- ---------------
-- Before this table, the only record of "which tasks satisfy criterion C8"
-- lived as prose in each task's description (`**Criterion:** C8 — …`).
-- Answering "what's left for C8?" therefore meant grepping seed-v3-tasks.js,
-- eyeballing a "Gates V3.R55–V3.R63" sentence, then re-querying every task's
-- status by hand (~10 calls). This makes the relation a first-class, queryable
-- thing so GET /api/gds/versions/:id/progress (and the /status skill) can roll
-- it up in one call. See ADR 0025.
--
-- WHY MANY-TO-MANY (and not a column on tasks)
-- --------------------------------------------
-- done_when_criteria.satisfied_by_task_id already exists, but it is the SINGLE,
-- REVERSE link: the one ship-task that *closed* a criterion. We need the
-- forward, MANY link: the many tasks that *gate*/contribute to a criterion
-- (C8 ← R55–R63). Tasks also contribute to multiple criteria (prose like
-- "C2, C7"), so the relation is many-to-many → a join table is the only honest
-- shape. (ADR 0025 records the rejected alternatives.)
--
-- THE BACKFILL IS POSITIONAL — and that is exactly the fragility we're retiring
-- -----------------------------------------------------------------------------
-- The prose says "C8" but a criterion's criterion_id is a semantic slug
-- (`cloneable-local-memory-server-sync`). "Cn" is the 1-based position by
-- (sort_order, criterion_id) within the version: C1 = onboarding-2h, …,
-- C8 = cloneable-local-memory-server-sync. So the backfill ranks each version's
-- criteria with ROW_NUMBER() and joins prose "Cn" → the n-th criterion of the
-- SAME version. A task listing "C2, C7" yields two rows.
--
-- This positional decode is brittle (reorder the criteria and old prose drifts),
-- which is the whole reason this table exists: from here on the structured link
-- is canonical and new tasks should populate task_criteria directly (follow-up
-- task: wire task-create + a manage endpoint). This is a ONE-TIME historical
-- backfill of the prose that existed at migration time — it is not re-run.
--
-- Tasks whose Criterion line has no "Cn" token (e.g. "cross-cutting (identity)",
-- "the proof Tier 1 is done") are intentionally left unlinked; /progress counts
-- them as unattributed rather than guessing.

BEGIN;

CREATE TABLE IF NOT EXISTS task_criteria (
  task_id      bigint NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  criterion_id bigint NOT NULL REFERENCES done_when_criteria(id) ON DELETE CASCADE,
  source       text   NOT NULL DEFAULT 'backfill',  -- 'backfill' | 'manual' | 'planning'
  created_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (task_id, criterion_id)
);

CREATE INDEX IF NOT EXISTS idx_task_criteria_criterion ON task_criteria (criterion_id);
CREATE INDEX IF NOT EXISTS idx_task_criteria_task      ON task_criteria (task_id);

-- One-time positional backfill from the **Criterion:** Cn prose.
WITH crit_line AS (
  -- The text of the Criterion line only (so we never pick up a stray "Cn"
  -- elsewhere in the body). regexp_match (singular) → first occurrence.
  SELECT id AS task_id,
         version_id,
         (regexp_match(description, '\*\*Criterion:\*\*\s*([^\r\n]*)'))[1] AS line
    FROM tasks
   WHERE description ~ '\*\*Criterion:\*\*'
),
crit_nums AS (
  -- Every "Cn" token on that line → one (task, n) pair. 'g' flag handles
  -- multi-criterion tasks ("C2, C7").
  SELECT task_id,
         version_id,
         (regexp_matches(line, 'C([0-9]+)', 'g'))[1]::int AS cnum
    FROM crit_line
   WHERE line IS NOT NULL AND line <> ''
),
ranked AS (
  -- Live 1-based position per version — same ordering listCriteria() uses.
  SELECT id AS criterion_id,
         version_id,
         ROW_NUMBER() OVER (PARTITION BY version_id ORDER BY sort_order, criterion_id) AS cnum
    FROM done_when_criteria
)
INSERT INTO task_criteria (task_id, criterion_id, source)
SELECT cn.task_id, r.criterion_id, 'backfill'
  FROM crit_nums cn
  JOIN ranked r
    ON r.version_id = cn.version_id
   AND r.cnum       = cn.cnum
ON CONFLICT DO NOTHING;

INSERT INTO schema_migrations (version) VALUES ('055_task_criteria') ON CONFLICT DO NOTHING;

COMMIT;
