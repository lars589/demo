'use strict';

// Generic per-author message-burst aggregator — shared by the #bugs
// (discord-bugs.js) and #ideas (discord-inbound.js) intakes (task #979,
// extracted from the #936 bug aggregator).
//
// A bug or idea is often split across two quick messages — a screenshot and
// then "here's what I mean", in either order. This buffers each author's
// messages in a channel and, once they go quiet for `windowMs`, fires onFlush
// ONCE with the combined burst (text joined, image URLs concatenated, anchored
// on the first message's id).
//
// In-memory + best-effort by design: a bot restart drops any un-flushed buffer
// (the author just re-posts) — the same trade-off ADR 0033 takes for the
// reaction/inbound paths. Timers are injectable so tests run deterministically.

// PURE — fold a burst of messages from one author into one record. Text parts
// are joined (blank-line separated, in arrival order); image URLs are
// concatenated; the record is keyed on the FIRST message's id (its anchor).
function combineParts(parts) {
  const texts = parts.map((p) => (typeof p.content === 'string' ? p.content.trim() : '')).filter(Boolean);
  const imageUrls = parts.flatMap((p) => (Array.isArray(p.imageUrls) ? p.imageUrls : []));
  return { content: texts.join('\n\n'), imageUrls, messageId: parts[0] ? parts[0].messageId : undefined };
}

function createMessageAggregator({ onFlush, windowMs, timers = global } = {}) {
  const pending = new Map(); // authorId -> { parts:[], discordUserId, timer }

  function flush(authorId) {
    const e = pending.get(authorId);
    if (!e) return;
    pending.delete(authorId);
    if (e.timer) timers.clearTimeout(e.timer);
    const combined = combineParts(e.parts);
    Promise.resolve()
      .then(() => onFlush({ discordUserId: e.discordUserId, ...combined }))
      .catch((err) => console.error('[discord-bot] message aggregator flush failed:', err.message));
  }

  function enqueue({ discordUserId, content, imageUrls = [], messageId }) {
    let e = pending.get(discordUserId);
    if (!e) { e = { parts: [], discordUserId, timer: null }; pending.set(discordUserId, e); }
    e.parts.push({ content, imageUrls, messageId });
    if (e.timer) timers.clearTimeout(e.timer);
    e.timer = timers.setTimeout(() => flush(discordUserId), windowMs);
    if (e.timer && e.timer.unref) e.timer.unref(); // don't keep the process alive
  }

  function flushAll() { for (const k of [...pending.keys()]) flush(k); }

  return { enqueue, flush, flushAll, _pending: pending };
}

module.exports = { combineParts, createMessageAggregator };
