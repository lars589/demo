-- 027_builders_preferred_disciplines.sql — adds builders.preferred_disciplines.
--
-- A builder's preferred_disciplines is the set of interest areas they want
-- the work queue tilted toward — the builder-side mirror of tasks.discipline
-- (migration 014). Valid elements are the *real* interest areas only:
--
--   creative      — map/world, quests, narrative, visual art, pixel pipeline
--   engineering   — gameplay mechanics, infra, the GDS itself, perf, bugs
--
-- Encoding:
--   {}                          — no preference stated (default)
--   {creative}                  — creative only
--   {engineering}               — engineering only
--   {creative,engineering}      — "both"
--
-- Note the enum here is intentionally narrower than tasks.discipline, which
-- also carries 'unclassified' for un-triaged work. A builder never *prefers*
-- unclassified — that's a state of a task, not an interest area — so it is
-- excluded from the CHECK. Empty array is the builder equivalent of "no
-- preference yet".
--
-- Pairs with V3.R81 (#299), which consumes this column to gate the queue and
-- surface cross-discipline recommendations.
--
-- Idempotent: safe to re-run.

ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS preferred_disciplines text[] NOT NULL DEFAULT '{}';

-- Validate every element against the discipline enum (creative|engineering).
-- Postgres forbids subqueries in CHECK constraints, so we use the array
-- containment operator `<@` ("is contained by"): the constraint holds iff
-- every element of preferred_disciplines is in the allowed set. The empty
-- array `<@` anything is true, so the default {} passes.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'builders_preferred_disciplines_check'
  ) THEN
    ALTER TABLE builders ADD CONSTRAINT builders_preferred_disciplines_check
      CHECK (preferred_disciplines <@ ARRAY['creative', 'engineering']::text[]);
  END IF;
END$$;

INSERT INTO schema_migrations (version) VALUES ('027_builders_preferred_disciplines')
  ON CONFLICT (version) DO NOTHING;
