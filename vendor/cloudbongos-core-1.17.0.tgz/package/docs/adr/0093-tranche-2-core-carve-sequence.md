# ADR 0093 — Tranche-2 core-carve sequence (Config-B, completing C7)

**Status:** Accepted (2026-06-27) · task [#1627](https://example.com/builders#/task/1627) (BV1.R76) · criterion **C7 `gds-core-modularized`** (BONGOS-V1) · owner-greenlit

**Amends:** [ADR 0091](<redacted>.md) — which carved the first two core domains (memory R72, grading R73) and **explicitly deferred tranche 2 "per owner."** The owner greenlit tranche 2 on 2026-06-27. This ADR fixes the order, the remaining kernel ports, and the lifecycle endgame; it changes nothing about 0091's kernel roster, the carve mechanism, or the fitness ratchet — those ship as reusable infrastructure.

**Builds on:** [ADR 0083](<redacted>.md) (the strangler plan + 5 module rules), [02 module-map](../design/modular-architecture/02-module-map.md) (the import-graph evidence + the decided ~16-module roster), [04 module-lifecycle](../design/modular-architecture/04-module-lifecycle.md) (the seam/port mechanism).

---

## Context

Tranche 1 ([ADR 0091](<redacted>.md)) did two things: it **proved the core-carve pattern** on the two cleanest-slicing domains (memory, grading — demonstrated by [`scripts/gds/coreB-carve-proof.sh`](../../scripts/gds/coreB-carve-proof.sh), R74), and it **shipped the infrastructure** every later carve reuses — the bounded kernel roster + `KERNEL_FILES` fitness ratchet (R70), the doorway with `withTx` (R68), the per-domain `db.js` slice pattern + `db-kernel.js` (R69), and the `grade` kernel **port** (R73). That infrastructure is generic: each remaining core domain is now a *pure carve* copying R72/R73, with **no new scaffolding**.

What remains is the bulk of the core: ~8 cohesive domains + the two web UIs + the lifecycle state machine ([02 §6](../design/modular-architecture/02-module-map.md) roster). The import-graph scan ([02 §2](../design/modular-architecture/02-module-map.md)) already told us which slice cleanly (economy, ideas, security alongside the proven memory/grading) and which is the coupled cluster (the lifecycle — `tasks → grader/github-push/ship-broadcast`). This ADR turns that evidence into a sequence.

---

## Decision

### 1. Carve order — clean-slicing-first, lifecycle last

Per [02 §2](../design/modular-architecture/02-module-map.md) (import-graph, not intuition) and §68 ("peel the clean, scan-confirmed modules off one at a time, most self-contained first"):

| Task | Carve | ≈LOC | Why this slot |
|---|---|---:|---|
| **R77** | economy (credits·cost·streak·achievements·leaderboard) | ~1.0k | clean slice; **also registers the `reward` port** — the lifecycle's last extractable capability (see §2), so it must precede lifecycle |
| **R78** | ideas (inbox·capture·triage·blockers) | ~0.9k | clean, self-contained |
| **R79** | security (red-team·bounty, rank-gated) | ~1.0k | clean feature slice ([02 §5](../design/modular-architecture/02-module-map.md): security-the-*feature*, not security-the-property) |
| **R80** | builder-settings (prefs·builder-needs) | ~1.6k | `me`/`public` stay as thin read facades |
| **R81** | onboarding (admission·setup·newcomer) | ~1.9k | |
| **R82** | sessions/BFG (records·cost/eval/digest·corpus) | ~2k | |
| **R83** | autonomy/MAS (conductor·architect·autonomy-gate·routines) | ~1.5k | cross-cutting — carve seams carefully |
| **R84** | status-UI (`public-status`) | ~3k | web surface; big but mechanical |
| **R85** | hall-UI (`public-builders`) | ~13k | largest; mechanical |
| **R86** | lifecycle (tasks·claims·versions·ship) | ~9k | **last + delicate** — the coupled state machine |
| **R87** | proof: extend `coreB-carve-proof.sh` to all domains → **C7 satisfied** | — | the criterion's final hinge |

### 2. economy registers the `reward` kernel port — the twin of `grade`

The lifecycle invokes two domain capabilities at ship: **grade** (already a port, R73) and **reward** (credit allocation — `applyGrade`/credit-log). [02 §3/§4](../design/modular-architecture/02-module-map.md) and the [04 lifecycle](../design/modular-architecture/04-module-lifecycle.md) seam design both name `reward` as the second illustrative port. R77 makes it real: economy `registerProvider('reward', …)` at boot; the lifecycle resolves `seams.resolveOptional('reward')` instead of importing economy. This is why **economy is first and lifecycle is last** — by the time the state machine is carved, every capability it calls is already a kernel port, so the lifecycle module imports only the kernel + resolves ports (the [ADR 0091 §4](<redacted>.md) rule, applied to the whole cluster).

### 3. The lifecycle stays ONE module, carved last

Do **not** split tasks/claims/versions/ship apart ([02 §4](../design/modular-architecture/02-module-map.md), restated in [ADR 0091](<redacted>.md) alternatives). Keep the state machine whole; the only edges it keeps are kernel + the grade/reward ports. Carving it last means the `db.js` residue at the end is exactly the lifecycle slice + `db-kernel.js` — the shape ADR 0091 §2 predicted.

### 4. Every carve is proof-gated; C7 is satisfied by R87

Each carve ships only when behavior is byte-identical — `coreB-carve-proof.sh` extended to assert the new module + its slice + its tests. Risk stays **per-domain**, never a big-bang. C7 (`gds-core-modularized`) is satisfied when R87 proves the whole core is decomposed — not before. Tranche 1 proved the *pattern*; tranche 2 completes the *decomposition* the criterion's done-when actually demands.

### 5. The "temporary doorway leaks" retire as their domains carve

ADR 0091 §3 parked three honest leaks on the doorway (`createTask`, `captureIdea`, `VOTABLE_TASK_STATUSES`) because their owning domains weren't carved. They retire here: `captureIdea` → behind an `ideas.*` seam at R78; `createTask`/`VOTABLE_TASK_STATUSES` → behind a `lifecycle.*` seam at R86. Each carve deletes its leak.

---

## Consequences

**Positive.** The core becomes the ~16-module + kernel roster ([02 §6](../design/modular-architecture/02-module-map.md)); `db.js` shrinks to the lifecycle slice + `db-kernel.js`. A "work on X" task loads module X + the doorway, not a 6k-LOC monolith — the AI-scoping payoff, now realized for the whole core, not just two domains. All doorway leaks retire.

**Negative / cost.** ~10 carves, each a focused session (low-hundreds of dollars total, negligible vs the budget). The lifecycle carve (R86) is delicate — it's the most coupled file cluster; it's last precisely so the ground under it (ports for grade + reward) is solid first. Kernel-trust-surface touches (`module-api.js`, `fitness.js`) on the economy/lifecycle carves mean owner Gate approval on those PRs — the boundary working as designed.

**Neutral.** Single-package / single-process / no-bundler preserved. The ~16 roster is a ceiling, not a floor ([02 §6](../design/modular-architecture/02-module-map.md)) — merging two modules is cheap and the fitness ratchet makes a later split safe, so the first cut is not a lock-in.

---

## Alternatives considered

- **A new criterion for tranche 2 — rejected.** C7's done-when already demands "the GDS core is *itself* decomposed … not just the four feature modules." Tranche 2 *is* C7; a second criterion would split one decision across two rows.
- **Carve the lifecycle earlier — rejected.** Its capabilities (`reward`) aren't ports until economy is a module; carving the state machine while it still `require`s economy would either break the kernel-only rule or bloat the kernel. Sequence the ports first.
- **Config C (a module per route-group) — rejected** ([02 §3](../design/modular-architecture/02-module-map.md)). tasks/claims/versions/credits are one cohesive cluster; forcing them apart fights cohesion and sprawls manifests. Extract capabilities behind seams; keep the machine.
- **Carve all domains in one session — rejected (owner).** Per-domain proof gates keep the blast radius bounded; back-to-back unreviewed carves of a 6k-LOC monolith is exactly the big-bang the strangler avoids.
