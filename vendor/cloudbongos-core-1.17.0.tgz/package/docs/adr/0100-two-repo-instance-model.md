# ADR 0100 — Two-repo instance model: a project consumes Cloud Bongos as a versioned platform

- **Status:** Accepted — **§§1–2 superseded by [ADR 0103](<redacted>.md)** (2026-07-02 owner review: core-first extraction, and Example *does* split rather than staying coupled). §3 (per-repo GDS) and §4 (conditional mirror) remain in force.
- **Date:** 2026-07-01
- **Track:** internal
- **Task:** [#1607](https://example.com/builders#/task/1607) (BV1.R77) — the decision gate this ADR resolves.
- **Decides:** the physical-repo topology that [ADR 0062](<redacted>.md) §10 left open and [ADR 0065](<redacted>.md) §4 answered for the *open-source* surface only.
- **Builds on:** [ADR 0062](<redacted>.md) §1 (portable-core / host-instance / feature-module cut-line), [ADR 0064](<redacted>.md) (the Cloud Bongos rename), [ADR 0083](<redacted>.md) + [ADR 0093](<redacted>.md) (the module boundary + completed core-carve that make the split mechanical), [ADR 0098](<redacted>.md) (`isPublishable()` — the executable definition of "what is the core"), [ADR 0099](<redacted>.md) (the delayed mirror), [ADR 0015](<redacted>.md) (dependencies).
- **Amends:** ADR 0062 §10 (chooses a physical topology it left open); ADR 0065 §4 (puts the generated mirror on a *conditional* retirement path — §4 below).
- **Seeds:** GDS-V4 R84 → R85 → R86 (package the core → stand Mercury up on a pinned core → make `bongos upgrade` a real update channel).
- **Amended by:** [ADR 0108](<redacted>.md) — resolves §1's mechanism-neutral "installs a pinned core + layers its own content on top" into configurable-root (the core as a `node_modules` dependency + an injected instance-root), not clone-and-layer.

## Context

ADR 0062 drew the **logical** cut-line — portable core / host instance / gated feature-modules — and deliberately left the **physical** repo topology open. cloudbongos.com ([#1206](https://example.com/builders#/task/1206)) then proved a second, non-game branded instance ships from the **same checkout** (a second process + second DB), so one repo was enough to prove the boundary. For the *open-source* release, ADR 0065 §4 chose a **generated one-way mirror** of the single private repo (delayed + redacted), explicitly *not* a fork.

Two owner priorities now push past the single-repo model:

- **Mercury** — Example' internal platform — should be "its own Cloud Bongos project": not code living inside the Off the Boats repo, and not merely another reskin of one checkout.
- **Core improvements should flow to future projects** on each project's own schedule — an explicit "update to the latest platform" capability.

The 2026-06-26 gap analysis (planning [#1604](https://example.com/builders#/task/1604)) found the logical boundary ~70% built and CI-enforced. Since then the load-bearing pieces landed: the bounded kernel ([#1570](https://example.com/builders#/task/1570)), the completed Config-B core-carve ([#1578](https://example.com/builders#/task/1578) + ADR 0093 — BONGOS-V1 C7 now satisfied), the hall-widget registry ([#1612](https://example.com/builders#/task/1612)), and core de-branding ([#1613](https://example.com/builders#/task/1613)). The boundary now holds, so a split is **mechanical, not a leap** — which is exactly the precondition this gate ([#1607](https://example.com/builders#/task/1607)) was told to wait for.

The single-repo model's one genuine virtue is **free updates**: with one copy of the code, every instance gets platform fixes the moment they land, no upgrade step. Splitting removes that property and requires new machinery — packaging the core as an installable unit, an update-consumption channel (the `bongos upgrade` CLI is a stub today, [#1203](https://example.com/builders#/task/1203)), and a GDS-topology decision across repos.

## Decision

### 1. The destination is two repos — a project installs Cloud Bongos as a versioned platform dependency.

A Cloud Bongos *instance* may be a **separate repository** that installs a **pinned version** of the Cloud Bongos **core** — the portable methodology + platform + neutral branding, exactly the subtree `isPublishable()` already defines (ADR 0098) — and layers its own project content, branding, and modules on top. This is the *physical* realization of ADR 0062 §1's *logical* cut-line. The single-checkout instance model (cloudbongos.com) is **not** deprecated: it stays a supported shape, and the cheaper one for a quick reskin.

### 2. Sequenced — Mercury is the forcing function; do not design the channel up front.

We build the smallest slice that stands **Mercury up as customer 2** in its own repo on a *pinned* core, and let that first real consumer's needs define the update channel, rather than guessing. Order: package the core (R84) → stand Mercury up on a pinned core (R85) → make `bongos upgrade` a real update-consumption channel, driven by Mercury's first core bump (R86).

**Example is not split in this sequence.** It stays the single-checkout reference instance and keeps getting core updates for free, until a later, separate decision — moving a working product before the channel is proven on a greenfield one buys risk for no gain.

### 3. GDS topology: per-repo.

Each project runs its **own** GDS — its own database, tasks, builders, versions, and credits. Mercury's builders never see Cloud Bongos platform tasks and vice versa; that separation of work is the point. A single shared GDS across repos is **rejected**: it re-couples exactly what the split exists to separate, and widens the trust/identity surface (ADR 0062 §5, [ADR 0016](<redacted>.md)). The cost — more than one GDS database to operate — is accepted as the price of clean separation.

### 4. The generated mirror (ADR 0065 §4) is retained now, retired conditionally.

The delayed redacted mirror (ADR 0099) stays the public open-source surface **until** the Cloud Bongos core is physically extracted into its own repo. At that point the core repo becomes the canonical public artifact (secrets scrubbed, AGPL intact), and the mirror is re-evaluated for retirement or repointing — a decision deferred to *that* task, not made here. Until then ADR 0065 §4 is unchanged and in force. The AGPL-3.0 license, the non-profit/AI-first governance, and the 6-month delay window (ADR 0065 §§1–3) are **unaffected** by repo topology.

## Alternatives considered (rejected)

- **A — stay single-repo + generated mirror (the seeded plan).** Cheapest, already built, free instant updates. Rejected as the *destination*: it structurally cannot deliver <redacted> or an update channel — a project would have to live inside the OTB repo or be a reskin, and there is nothing to "update" while everything shares one checkout. **Retained** as the model for cheap reskins and as the interim public-release mechanism (§4).
- **Two repos, one shared GDS.** Rejected — re-couples the work-tracking plane the split means to separate (§3).
- **Split Example out immediately, alongside Mercury.** Rejected — moving a live product before the channel is proven adds risk for no gain; greenfield Mercury is the safer first consumer (§2).
- **Fork / hand-maintained downstream.** Rejected in ADR 0065 §4 and still rejected — a divergent fork loses the free flow of core fixes without the discipline of a versioned dependency.

## Consequences

- **P4 and P5 become buildable.** The R84 → R85 → R86 spine delivers Mercury (P5) and the update channel (P4). R84 auto-promotes to `ready` when this gate ([#1607](https://example.com/builders#/task/1607)) ships (ADR 0015).
- **A permanent per-project upgrade step** replaces free updates — the recurring cost the single-repo model avoided, now explicit and owned per project.
- **A larger operational footprint** (more repos, CI, at least one more GDS database) — weighed against the $5k budget and mitigated by building incrementally, driven by Mercury, not ahead of it.
- **The module boundary is now load-bearing across a repo gap.** A two-repo consumer amplifies any core↔host leak into a cross-repo break, so the ADR 0062 Path-C fitness functions ([ADR 0061](<redacted>.md)) matter more, not less.
- **Example is unaffected today** — single-checkout reference instance, free core updates, until a separate future decision.
- **No new criterion is minted by this ADR.** The seeded tasks are a distinct "done-when" from GDS-V4 C8 (single-checkout configurable instance); whether to track them under a new criterion is left to the owner (see the shipping task's notes).
