# Module Lifecycle & Maintenance

How modules talk to each other, grow, and stay healthy as the codebase expands.

## 1. How modules talk without importing each other

The one-way rule forbids a module importing another. But the **lifecycle** (which ships a task) needs a reward figure the **economy** module calculates. The resolution is a **kernel-mediated seam** — the kernel is a switchboard:

- **Ports** (a *required, single-provider* capability): the economy module registers a `reward` provider; at ship, the lifecycle asks the kernel to resolve `reward` and calls it. **Economy owns the formula *and* the ledger**; the lifecycle only supplies the session and delivers the result.
- **Events** (an *optional* reaction): the lifecycle emits `task.shipped`; the discord module reacts if it cares.
- **Contributions** (an *accumulating extension point*): zero-or-more modules each add a piece to a named point and the kernel hands the whole set to a core consumer — how a module adds its own slice to a shared core surface without core hardcoding it. The `profile.fields` point lets dev-box/discord/art add their slice to the `GET /me` payload (and its browser twin, `window.OTB.contributeSettingsPanel`, adds a Settings panel) instead of those being baked into `routes/me.js` + `settings.js` (BV1.R42 / task 1411 — the strangler prerequisite for those three moves; game has no such coupling). Add-only: a contribution may introduce keys, never overwrite a core one.

```mermaid
graph LR
    LC["LIFECYCLE<br/>build state machine<br/>▸ ship step"]
    subgraph K["KERNEL — the switchboard (seam registry)"]
        PR["port: reward"]
        PG["port: grade"]
        EV["event: task.shipped"]
    end
    EC["ECONOMY<br/>reward model + ledger"]
    GR["GRADING<br/>grade-a-diff"]
    DC["DISCORD<br/>notify"]
    LC -->|"① at ship: resolve reward + grade, emit shipped"| K
    EC -->|"② provides"| PR
    GR -->|"② provides"| PG
    EV -.->|reacts| DC
```

No module holds a reference to another; the kernel resolves ports and fans out events. The one-way arrow holds.

> **This revises the earlier fusion — for the better.** The scan showed `tasks → grader`/`tasks → ship` as *direct imports*, so they looked like one module. But the seam economy needs *un*-fuses them: those imports become **seam calls**. So **grading and economy become their own modules the lifecycle *orchestrates*, not imports.** The lifecycle shrinks to the build **state machine** (claim→active→…→shipped) that, at defined points, asks the kernel for `grade` and `reward`. That's ports-and-adapters, and it's cleaner than the blob.

The decided roster (~16 modules + kernel) lives in [02 §6](02-module-map.md#6-the-decided-roster-16-modules--kernel).

## 2. The four maintenance flows

| Flow | What happens | What keeps it safe |
|---|---|---|
| **Add a module** | `bongos module new <key>` scaffolds the manifest + dirs → write routes/db/ui/skills → declare in `module.json` → flip the flag in `config/modules.json`. Loader discovers + mounts. **No core edit.** | fitness: manifest valid, write routes rank-gated, migrations additive + namespaced, no kernel-internal imports |
| **Grow a feature inside a module** | claim a module-scoped task → edit only `modules/<key>/` → additive namespaced migration → ship | blast radius = that module; ship-time diff⊆module |
| **One module needs another's capability** | declare it (consumed port / `prerequisites.modules`) → call it **through the kernel seam**, never by import | loader verifies the provider is enabled; one-way arrow preserved; fitness fails any direct cross-module import |
| **Evolve the kernel contract** | adding to `module-api.js` = a **minor** semver bump (safe); changing/removing = **major**. Each module declares the `coreVersion` it supports. | `bongos upgrade` pre-checks every enabled module's `coreVersion` and refuses/warns on mismatch (fail-closed) |
| **A feature spanning modules** | decompose into an **epic of per-module child tasks + dependencies**. If two modules keep needing each other, add a kernel **port**. | each child stays isolated + parallel-safe; the coupling scan flags chronic cross-talk |

## 3. Fitness functions are the immune system

The reason this stays healthy as the codebase triples is **not reviewer vigilance — it's CI.** Every PR runs the fitness checks (core carries no module code · core never imports a module · modules import only the published API · every module write route is rank-gated · module migrations are additive + namespaced). A violation is a **red build**. In an **AI-built** system this is decisive: an agent working a module-scoped task **cannot** silently erode the architecture, because the boundary is enforced on the way in. The "ratchet" rule makes it monotonic — grandfathered violations may only shrink; new ones are rejected. The architecture maintains itself.

## 4. The manifest is the living contract

As a module grows, the one thing you keep honest is its `module.json` — the single declared source of what it contributes (routes, skills, UI, migrations, the ports it provides and consumes). Loader + fitness both act on it, so "maintaining a module" largely means "keeping its manifest true," and CI proves you did. Each module also carries its own nested `CLAUDE.md`, so an agent scoped to it stays oriented no matter how big the rest of the platform gets.

**Detecting drift:** re-run the `require()`-graph / coupling scan periodically (cheap, deterministic). If two modules that shouldn't talk keep accumulating seam calls, the boundary is drifting — formalize a port or merge them. That scan is how you catch a wrong line early (it's how the work/ship/grade over-split was caught in [02](02-module-map.md)).

## 5. The honest tradeoff

More modules buy isolation, AI-scoping, and parallelism — but each is ceremony (a manifest, a boundary to enforce, maybe a seam to wire). For a bootstrapped team the sweet spot is **"as modular as the evidence supports, no finer."** Promote a cluster to a module when (a) the scan shows it's genuinely self-contained, (b) you want to scope agents/access to it, or (c) it's optional per-instance. Until then, leave it coarse. The migration is incremental and reversible-ish — merging two modules is cheap, and the fitness ratchet makes splitting them safe — so you are never locked into the first cut.

---

*The seam mechanism is ADR 0080 §6's declared extension points (`extends: { hooks: [...] }`) generalized to required ports + events; the upgrade/compat flow is ADR 0080 §7; fitness functions are ADR 0062 §9 / ADR 0080 §5.*
