-- 123_cost_log_tiers.sql — per-tier USD breakdown on cost_log (GDS-V4 task 1344,
-- System 1: Cost Attribution & Savings Ledger).
--
-- priceUsage (src/bongos/llm-pricing.js, task 1343) already computes the per-tier
-- component split (fresh input / cache-read / cache-write / output) but the
-- ledger discarded it, lumping every call into a single amount_usd. The
-- marathon-session finding (~82% of spend is cache_read, re-billed every turn for
-- hours) stays an *inference* until that tier is a queryable column. These four
-- nullable columns persist the split so costSummary() can GROUP BY tier (task
-- 1345) and the audit can report the cache_read share (task 1346).
--
--   fresh_input_usd — uncached input tokens priced at the family input rate.
--   cache_read_usd  — cache-read tokens (0.1× input). The marathon cost sink.
--   cache_write_usd — cache-creation tokens: the 5m + 1h tiers SUMMED into one
--                     "what we paid to write cache" figure (priceUsage splits
--                     them; the ledger does not need that granularity).
--   output_usd      — output tokens.
--
-- All nullable: historical rows and non-LLM rows (manual/infra/domain/compute,
-- e.g. boxes.js 'box-lifecycle' compute rows) stay NULL. The four need not sum
-- to amount_usd for legacy rows; for the session/cron rows written by
-- scripts/gds/session-cost.js they sum to amount_usd by construction.
--
-- Additive + idempotent: safe to re-run.

ALTER TABLE cost_log
  ADD COLUMN IF NOT EXISTS fresh_input_usd numeric,
  ADD COLUMN IF NOT EXISTS cache_read_usd  numeric,
  ADD COLUMN IF NOT EXISTS cache_write_usd numeric,
  ADD COLUMN IF NOT EXISTS output_usd      numeric;

INSERT INTO schema_migrations (version) VALUES ('123_cost_log_tiers')
  ON CONFLICT (version) DO NOTHING;
