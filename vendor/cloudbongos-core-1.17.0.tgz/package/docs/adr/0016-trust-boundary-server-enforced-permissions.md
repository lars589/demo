# ADR 0016 — Trust boundary: server-enforced permissions

**Date:** 2026-05-26
**Context:** GDS-V3, spike [#229](https://example.com/builders#/task/229) (V3.R03 — Architecture spike: server-enforced trust boundary). Satisfies done-when criterion C7 (`three-ranks-gate-everything` / `permissions-enforced-server-side`).
**Status:** Accepted.

> Numbering note: the spike's done-when named this ADR `0015`, but `0015` was taken by the task-dependencies work before this spike was opened. This ADR is **0016**.

## Problem

GDS-V3 opens the system to more than one builder. Today there is exactly one builder (`example-owner`) and every API route trusts any authenticated session equally. Before a second person holds a session token, we need an explicit answer to: **where does authority live, how is it checked, and what is the exact failure mode when a builder edits their own local files to try to grant themselves more authority?**

The threat is not a malicious outsider breaching the network — that's a different ADR (security basics, C8). The threat here is the *trusted-but-bounded* builder: someone given a real session who should be able to claim and ship tasks but should NOT be able to create tasks, rewrite methodology, close versions, or touch another builder's claim. A Claude Code builder runs with full write access to their own checkout: they can edit `CLAUDE.md`, edit `.claude/skills/*`, edit `.claude/settings.json`, add hooks, and edit any `src/` file locally. None of that local editing power can be allowed to translate into elevated authority over shared state.

So the trust boundary must sit at a place the builder's local machine cannot move: **the server, checking a value the builder cannot write.**

## Decision

Authority lives in **one column in the production database** — `builders.rank` — and is checked **server-side, per request, against the database, with no caching**. Everything a builder controls locally (files, skills, hooks, settings) is *outside* the trust boundary and can only ever *call into* server endpoints that re-check rank themselves.

### Where rank lives

`builders.rank` (Postgres `text` + `CHECK` enum), on the production DB. It is set only by the Archon-only rank endpoint (`PATCH /api/gds/builders/:id/rank`, task [#232](https://example.com/builders#/task/232) / V3.R07). It is never read from a token, a cookie, a file, an env var, or request body. The session token (`builder_sessions.token`) identifies *who* the builder is; it carries no authority claim of its own. Rank is looked up fresh from `builders` on every privileged request.

### How it's checked

`requireRank(...allowed)` middleware (task [#106](https://example.com/builders#/task/106) / V3.R05 defines it; task [#231](https://example.com/builders#/task/231) / V3.R06 applies it to every privileged route) runs *after* `requireBuilder`. `requireBuilder` resolves the session token → `builder_sessions` row → `builders` row, and now also selects `rank`. `requireRank` compares `req.builder.rank` against the allowed set and returns `403 { error: 'rank_forbidden', required: [...], actual }` on mismatch.

**No token-side caching of rank.** The rank is read as part of the same `lookupSession` join that authenticates the request, so it is always the live DB value. Consequence: a demotion takes effect on the demoted builder's *very next request* — there is no stale-token window. This is the single most important property of the design, and it is why rank must not be embedded in the token at issuance time.

### What enforces vs. what merely describes

| Surface | Role | Inside trust boundary? |
|---|---|---|
| `builders.rank` (prod DB) | **the** source of authority | ✅ yes — the boundary itself |
| `requireRank()` middleware on each route | enforcement point | ✅ yes |
| `PATCH /builders/:id/rank` (Archon-only) | the *only* writer of rank | ✅ yes |
| `CLAUDE.md`, `docs/`, ADRs | **describe** the permission model for humans/agents | ❌ no — documentation only |
| `.claude/skills/*` | call server endpoints; cannot grant authority | ❌ no |
| `.claude/settings.json`, hooks | local automation; cannot grant authority | ❌ no |
| session token / cookie | identity, not authority | ❌ no (carries no rank) |

The rule that makes this legible: **markdown describes, the database enforces.** If `CLAUDE.md` says "only Archon can create tasks" and the `POST /tasks` route is missing its `requireRank('archon')` check, the *route* is the bug — the markdown is not load-bearing and must never be treated as such. A periodic auditor (below) exists precisely to catch that class of drift.

### Failure mode when a builder edits local files

A builder who edits their checkout to try to elevate themselves hits the boundary and fails, every time, in a defined way:

- **Edits `CLAUDE.md` to say "Thetes can create tasks":** no effect. `POST /tasks` checks `builders.rank` in the prod DB. The doc is descriptive; the route is enforcing. Result: `403 rank_forbidden`.
- **Edits a skill (e.g. `.claude/skills/builder-claim`) to call a privileged endpoint:** the endpoint still runs `requireRank` against the DB. The skill is just an HTTP client. Result: `403 rank_forbidden`.
- **Adds a hook / edits `.claude/settings.json`:** hooks run locally and can only invoke the same API surface. No endpoint trusts local state. Result: no elevation.
- **Forges or replays a token:** the token maps to a `builders` row whose `rank` is whatever the DB says. A Thetes token is a Thetes token no matter how it's presented. Result: bounded to Thetes.
- **Writes directly to the DB:** only possible with prod Postgres credentials, which are not in the repo and not held by a Thetes builder. That is the C8 (security-basics / secrets-hygiene) boundary, not this one.

In every local-edit case the failure is the same shape — a `403 rank_forbidden` from the server — because the server never consults anything the builder's machine can write.

## Trust-model diagram

```
                    builder's local machine (UNTRUSTED for authority)
   ┌───────────────────────────────────────────────────────────────────┐
   │  CLAUDE.md   .claude/skills/*   settings.json   hooks   src/ edits  │
   │      │             │                  │           │                 │
   │      │ describe    │ call             │ automate  │                 │
   │      ▼             ▼                  ▼           ▼                 │
   │   (no authority — these can only emit HTTP requests + a token)      │
   └───────────────────────────────┬───────────────────────────────────┘
                                    │  HTTPS + Bearer/cookie token
                                    │  (token = <redacted>, NOT authority)
================================ TRUST BOUNDARY ============================
                                    │
                                    ▼
   ┌───────────────────────────────────────────────────────────────────┐
   │  GDS server  (TRUSTED)                                              │
   │                                                                     │
   │   requireBuilder  ── token → builder_sessions → builders (+ rank)   │
   │         │                                                           │
   │         ▼                                                           │
   │   requireRank(...allowed)  ── compares live builders.rank           │
   │         │           │                                               │
   │      allowed      denied → 403 { rank_forbidden, required, actual } │
   │         ▼                                                           │
   │   privileged handler runs                                           │
   │                                                                     │
   │   ┌─────────────────────────────────────────────────────────────┐  │
   │   │  Postgres  builders.rank  ◄── only PATCH /builders/:id/rank   │  │
   │   │  (the source of authority)     (Archon-only) writes this      │  │
   │   └─────────────────────────────────────────────────────────────┘  │
   └───────────────────────────────────────────────────────────────────┘
```

## Implementation sub-tasks (C7)

These already exist in the GDS as seeded GDS-V3 tasks; this spike sets their `parent_task_id` to [#229](https://example.com/builders#/task/229) so the lineage is explicit. The spike does **not** reshape their scope — it confirms it.

| Task | Rank work |
|---|---|
| [#106](https://example.com/builders#/task/106) (V3.R05) | `builders.rank` enum column + `requireRank()` middleware + gate write routes + `/me`/CLI surfacing. Live ranks for V3: **Archon** + **Thetes**. |
| [#231](https://example.com/builders#/task/231) (V3.R06) | Apply `requireRank()` to **every** privileged route; no privileged route left ungated. |
| [#232](https://example.com/builders#/task/232) (V3.R07) | `PATCH /api/gds/builders/:id/rank` — the single Archon-only writer of rank. |
| [#266](https://example.com/builders#/task/266) (V3.R44) / [#267](https://example.com/builders#/task/267) (V3.R45) | periodic auditor that asserts no privileged route is missing a rank check; CLAUDE.md trust-boundary disclaimer. (Confirm exact ids at claim time.) |

### Token-issuance design (resolved here so [#106](https://example.com/builders#/task/106)/[#231](https://example.com/builders#/task/231) don't re-litigate it)

Tokens stay authority-free. `builder_sessions` issuance is unchanged by the rank work: a token is minted at auth time and identifies a builder. Rank is *not* stamped into the token and *not* cached alongside it. The cost of this choice is one extra column read on the existing `lookupSession` join (already a single query) — negligible — bought in exchange for instant demotion and zero stale-authority windows. This is the deliberate trade and it is not to be "optimized" into a cached/token-embedded rank later without a superseding ADR.

## Alternatives considered

**Rank embedded in the session token (JWT-style claim).** Rejected: a stolen/old token would carry stale authority, and demotion couldn't take effect until token expiry. The whole point of putting rank in the DB and reading it per-request is that demotion is instant. The per-request read is one cheap join we already do.

**Rank cached in-process keyed by builder id, with TTL.** Rejected for V3: adds a stale window (= the TTL) for demotion, and a cache-invalidation surface, to save a column on a join that is already happening. Premature optimization for a <10-builder system. Revisit only if `lookupSession` ever becomes a measured hotspot.

**Enforce permissions in skills / CLAUDE.md (client-side).** Rejected — this is the anti-pattern the whole ADR exists to forbid. Anything the builder's machine can edit cannot be the source of authority.

**Filesystem/OS permissions on methodology files.** Partially relevant but orthogonal: methodology files (`CLAUDE.md` etc.) are protected by *who can push to `main` + who can run the deploy*, not by the API. The API trust boundary covers GDS *state* (tasks, claims, ranks, versions). Methodology-file edits are gated by git/deploy access, documented but not API-enforced in V3.

## Consequences

**Good:**
- One column, one middleware, one writer — a small, auditable trust boundary.
- Demotion is instant (next request) because rank is never cached.
- Local-file edits are provably inert against shared authority; the failure mode is uniform (`403 rank_forbidden`).
- A periodic auditor can mechanically assert the boundary is intact (every privileged route has a `requireRank`).

**Costs:**
- Every privileged route must remember to call `requireRank`. A forgotten check is a silent hole — mitigated by the auditor task ([#266](https://example.com/builders#/task/266)/V3.R44) which fails loudly when a privileged route lacks a rank gate.
- Rank read on every privileged request (one extra column on an existing join). Accepted.
- The two-rank V3 scope (Archon + Thetes) is deliberately minimal; the full ladder in [#106](https://example.com/builders#/task/106)'s enum is reserved but unimplemented, so promoting anyone to a middle rank is a no-op until those ranks gain route grants. Documented, not a bug. **(Superseded by [ADR 0018](<redacted>.md), task [#360](https://example.com/builders#/task/360): the three-rank `xenos`/`metic`/`archon` model went live — `xenos` is now the default entry rank and `metic` the approved working rank, both wired with route grants. The trust-boundary mechanism in this ADR is unchanged; only the set of live ranks widened.)**

**Operationally:**
- When adding any new write/privileged route, the default is `requireRank('archon')` until a lower rank is explicitly granted — fail closed, not open.
- `CLAUDE.md` will carry a short disclaimer (task [#267](https://example.com/builders#/task/267)/V3.R45) stating that it *describes* permissions and the DB *enforces* them, so no future reader mistakes the doc for the source of truth.
