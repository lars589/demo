# ADR 0024 — Cloneable repo + local-first memory with server-canonical sync

**Date:** 2026-05-29
**Context:** GDS-V3, spike [#230](https://example.com/builders#/task/230) (V3.R04 — Architecture spike: cloneability + local-first memory with server sync). Satisfies done-when criterion C8 (`cloneable-local-memory-server-sync`). Companion to [ADR 0016](<redacted>.md) (trust boundary — same enforcement boundary applies here) and [ADR 0022](0022-secrets-policy.md) (no secrets in repo — a precondition for "cloneable").
**Status:** Accepted.

> Numbering note: the spike's done-when named this ADR `<redacted>.md`, but `0016` was already taken by the trust-boundary ADR before this spike was opened. This ADR is **0024**. Same correction the R03 spike (ADR 0016) made for itself.

## Problem

GDS-V3 opens the system to more than one builder. Today there is exactly one builder (`example-owner`) on exactly one machine, so "memory" is whatever lives in `~/.claude/projects/<redacted>/memory/` on that one laptop. If that laptop dies, the memory is gone. If a Metic onboards from `git clone`, their memory starts empty and stays empty — there is no path for them to pick up where a previous session left off, even their *own* previous session on a different machine.

We need an explicit answer to:

1. **What is "memory" in this project, and why does it need to survive the laptop?** Distinct from the *code* (which `git` already handles) and distinct from the *system state* (which the GDS DB already handles).
2. **Where does memory live canonically?** Local file, server DB, object store?
3. **When does it sync, in which direction, on whose authority?**
4. **What happens when two builders (or one builder on two machines) edit the same memory file?**
5. **Can builder A read builder B's memory?** Under what conditions?
6. **What happens when the server's memory store is wiped?**

These cluster into five design choices: **schema**, **sync trigger**, **conflict policy**, **isolation**, **backup cadence**. The rest of this ADR is the choice made for each, with the rejected alternatives recorded so the trade-off survives the decision.

## What "memory" means here

Three distinct artifact classes live on a builder's laptop. Only one of them is in scope:

| Artifact | Where canonical | Already solved? |
|---|---|---|
| Source code, ADRs, skills, migrations, CLAUDE.md | `git` (origin = `github.com/example-owner/example`) | ✅ yes — git is the answer |
| Work state (tasks, claims, credits, learnings, idea_inbox) | GDS Postgres on droplet | ✅ yes — `/api/gds/*` is the answer |
| **Claude Code's per-session memory dir** (`~/.claude/projects/<project>/memory/*.md`) | **Local laptop only** | ❌ no — this is what R04 designs |

The third row is what this ADR addresses. It's the auto-memory Claude Code itself writes (e.g. `MEMORY.md`, `feedback_*.md`) plus any builder-authored persistent context that isn't code and isn't a GDS row. Today there's no path off the laptop; that is the gap C8 is trying to close.

**Out of scope:** the GDS `learnings` table (already server-canonical, written via `node scripts/gds/learning-capture.js`), the `~/.config/otb/` directory (per-builder *secrets* — covered by ADR 0022, never synced), and the art pipeline's iteration ledger (already in-repo at `art/iterations/`). If a thing is already on the server or already in git, it is not "memory" in this ADR's sense.

## Decision

Five choices, each forced into the simplest viable shape unless the simple version actively breaks. Default posture per CLAUDE.md §4: choose cheap and small; pay complexity only when the simple version visibly fails.

### 1. Schema — Postgres TEXT in one new table

A new table `builder_memory(builder_id, path, content TEXT, mtime, sha256, byte_len, PRIMARY KEY (builder_id, path))` on the existing GDS Postgres. Per-file rows; `path` is the relative path under the builder's memory dir (e.g. `MEMORY.md`, `feedback_auth_flows_ui_first.md`). Content stored as `TEXT` (not `BYTEA`) because memory files are markdown — readable in `psql` for forensics is a meaningful Archon convenience.

**Limits** (enforced at the helper layer in [#273](https://example.com/builders#/task/273) R54):

- Per-file cap: **1 MB**. Memory files measured today are kilobytes; 1 MB is 1000× headroom and stops a runaway loop from filling the row.
- Per-builder cap: **50 MB total**. 50,000× current observed size. A sync that would exceed the cap returns `413 memory_quota_exceeded` and is logged; the builder is told what to prune.
- Per-builder file count cap: **2000 files**. Defensive.

**Rejected: object storage (DO Spaces / S3).** Adds $5/mo minimum + an SDK dependency + a second auth-token surface + a second backup story. For files measured in kilobytes, with backup already free from `pg_dump`, this is buying complexity to solve a problem we don't have. Revisit only when (a) we see per-file sizes routinely above 100 KB or (b) total table size exceeds ~1 GB and `pg_dump` time becomes painful.

**Rejected: git-backed memory** (push to a per-builder branch in the repo). Tempting because git is already there, but it conflates *code-king* artifacts with *per-builder mutable scratch* — and worse, it would expose one builder's memory diffs in the public repo, contradicting the isolation requirement (§4 below).

### 2. Sync trigger — lifecycle-event push + pull, no daemon

Two trigger points, both transactional boundaries that already exist in the methodology:

- **Push on `/builder-ship`.** After the ship completes successfully (drachmae landed, branch merged or queued), `scripts/gds/ship.js` walks `~/.claude/projects/<project>/memory/*` and calls `POST /api/gds/memory/sync` with each file. If the push fails, ship still succeeds — work is preserved in the GDS row, memory can be resynced next time. Progress visible to the builder ("syncing 3 memory files…"). This is what [#274](https://example.com/builders#/task/274) R55 implements.
- **Pull on `SessionStart` hook + `/builder-start`.** A new hook (or extension of the existing `.claude/hooks/sync-env-local.sh` pattern) calls `GET /api/gds/memory/since?mtime=<local-newest>` and writes any files the server has that are newer than the local copy. This is what [#275](https://example.com/builders#/task/275) R56 implements.

No background polling. No Claude-Code-side daemon. No mid-session sync. The two trigger points are predictable, debuggable, and align with the natural commit/restart boundaries builders already think in.

**Rejected: every-N-minutes background sync.** A daemon means a process to start, a process to stop, a place for it to log, a place for it to fail silently. The marginal benefit (memory survives a `kill -9` mid-session) is small — the same session is probably about to re-write the file anyway.

**Rejected: sync on every Claude Code tool call.** Per-tool-call HTTP is a perceptible latency tax on every `/builder-*` interaction. Not worth it.

### 3. Conflict policy — last-write-wins per file, server clock authoritative

When the push handler receives a file, it compares the incoming `mtime` against the stored row. **Newer wins.** No merge, no rejection, no warning. The server's clock decides which `mtime` is "newer" (clients are not trusted to set the future-mtime trick).

The expected collision shape is **one builder, two machines** — e.g. Lars edits memory on the desktop, then later on the laptop. Push from laptop overwrites the desktop's version. Pull-on-start brings the laptop's version back to the desktop next session. The lost-write window is "the time between push-A and pull-B," which in practice is one session boundary — recoverable from backup (§5) if a real loss occurs.

Two-builders-same-builder-id is impossible by construction: `builder_id` is the unique GitHub user, not a session.

Two-builders-different-builder-id on the same file is impossible by construction: paths are namespaced by `builder_id` (§4).

**Operator escape hatch:** the conflict-resolution recipe (`docs/recipes/memory-sync-conflicts.md`, shipped by [#277](https://example.com/builders#/task/277) R58) documents how to restore an older version of a file from `pg_dump` if a builder confirms a clobber.

**Rejected: three-way merge for markdown files.** Tempting (markdown diffs reasonably well), but the failure mode — a half-merged `MEMORY.md` that looks plausible but is structurally broken — is worse than the simple lose-one. Defer to V4 and only if we observe real collisions in V3.

**Rejected: optimistic concurrency (reject pushes whose base-mtime is stale, force a pull-first).** Adds a step builders will work around by `--force`-ing. Push-then-overwrite is simpler and the recovery path (backup) handles the rare bad case.

### 4. Isolation — server enforces `req.builder.id === path_owner.builder_id`

All memory endpoints (`POST /memory/sync`, `GET /memory/since`, `GET /memory/files`, `GET /memory/files/:path`) check that the requester's `req.builder.id` matches the row's `builder_id` before reading or writing. Mismatch returns `403 memory_forbidden`. The check happens in the route handler, after `requireBuilder`, before any DB work. Same trust-boundary posture as [ADR 0016](<redacted>.md): the server enforces; nothing the builder can edit locally can grant cross-builder access.

**Archon forensic exception — read-only.** An Archon-only endpoint `GET /memory/builders/:id/files` exists for restore + forensics use cases (e.g. a builder offboards, Archon needs to inspect their memory; a corrupt file needs restoration). Every Archon read is logged to `audit_log` with `actor_builder_id`, `target_builder_id`, `path`, `reason`. **There is no Archon write endpoint.** Restores happen via `pg_restore` into a sandbox schema, never live. Read-only is the V3 posture; cross-builder *reads* are likely to be relaxed in a later version (e.g. Metics seeing each other's memory for collaboration), but cross-builder *writes* through the API are not on the roadmap. Any future relaxation requires a superseding ADR.

In V3: no other rank gets cross-builder access. Not Metic, not Thetes. Not for any reason short of an ADR-supersede.

### 5. Backup cadence — ride the existing `pg_dump`

`builder_memory` is a Postgres table. It rides whatever backup cadence the GDS DB has.

> **Precondition (confirmed during this spike):** the GDS DB does **not** currently have a nightly `pg_dump` cron. R62 ([#281](https://example.com/builders#/task/281)) therefore has two parts: (a) stand up nightly `pg_dump` for the whole GDS DB (which `builder_memory` then inherits for free), and (b) the restore drill + recipe doc. Part (a) is the gating dependency for flipping C8 — until backups are real, the "server-canonical" half of C8 is unverified. A follow-up task is filed for part (a) so it's not buried inside R62's scope.

**Target cadence:** nightly `pg_dump` to a separate volume on the droplet + weekly off-droplet archive (Backblaze B2 or DO Spaces — the cheapest target). **Retention:** 30 days rolling daily + 12 weekly archives. **Drill:** quarterly. Pick a random builder, restore their `builder_memory` rows from yesterday's dump into a sandbox schema, diff against live, confirm match. Documented in `docs/recipes/memory-backup.md`, shipped by [#281](https://example.com/builders#/task/281) R62.

**Cost ceiling:** $1–2/month for off-droplet storage at expected memory sizes (GDS DB is currently <100 MB total; 12 weekly archives = ~1.2 GB; B2 cold tier is ~$0.005/GB/mo). Inside the $5K/year envelope without trouble.

## Trust-model + sync diagram

```
                  Builder's local machine (cloneable from git)
   ┌────────────────────────────────────────────────────────────────────┐
   │   git clone repo  +  /builder-setup (Gemini key, Anthropic link)   │
   │                                                                    │
   │   ~/.claude/projects/<project>/memory/                             │
   │   ├── MEMORY.md          (Claude Code auto-memory)                 │
   │   ├── feedback_*.md      (rules captured from feedback)            │
   │   └── …                                                            │
   │                                                                    │
   │   ▲                                  │                             │
   │   │ pull (on SessionStart            │ push (on /builder-ship)     │
   │   │  + /builder-start)               │                             │
   └───┼──────────────────────────────────┼─────────────────────────────┘
       │                                  │
       │   HTTPS + Bearer/Cookie session token  (identity, not authority)
       │                                  │
============================== TRUST BOUNDARY ==============================
       │                                  │
       ▼                                  ▼
   ┌────────────────────────────────────────────────────────────────────┐
   │  GDS server  (single droplet, Node + Postgres)                     │
   │                                                                    │
   │   POST /memory/sync          GET /memory/since?mtime=...           │
   │       │                          │                                 │
   │       ▼ requireBuilder           ▼ requireBuilder                  │
   │       ▼ isolation check          ▼ isolation check                 │
   │       ▼  (req.builder.id ==      ▼                                 │
   │           path_owner_id)                                           │
   │       │                          │                                 │
   │       ▼                          ▼                                 │
   │   ┌────────────────────────────────────────────────────────────┐   │
   │   │  builder_memory (builder_id, path, content TEXT,           │   │
   │   │                   mtime, sha256, byte_len)                  │   │
   │   │                                                              │   │
   │   │  ► last-write-wins on push (server clock)                    │   │
   │   │  ► quota: 1 MB/file · 50 MB/builder · 2000 files/builder    │   │
   │   │  ► forensic read: Archon only, audit-logged                  │   │
   │   └────────────────────────────────────────────────────────────┘   │
   │                                                                    │
   │   ┌────────────────────────────────────────────────────────────┐   │
   │   │  Nightly pg_dump → droplet volume; weekly archive offsite  │   │
   │   │  30 daily + 12 weekly retention; quarterly restore drill   │   │
   │   └────────────────────────────────────────────────────────────┘   │
   └────────────────────────────────────────────────────────────────────┘
```

## Implementation sub-tasks (C8)

These already exist as seeded GDS-V3 tasks; this spike sets `parent_task_id = 230` on each so the lineage is explicit. The spike **does not reshape their scope** — the design decisions above match the assumptions the seeds were drafted under. If any seed description references an assumption this ADR overrode, the task description gets a follow-up edit in the same ship.

| Task | What it builds | Encodes which decision |
|---|---|---|
| [#273](https://example.com/builders#/task/273) (V3.R54) | `builder_memory` schema + `storeMemoryFile / fetchMemoryFile / listMemoryFiles` helpers, per-builder isolation at helper layer | §1 (schema), §4 (isolation) |
| [#274](https://example.com/builders#/task/274) (V3.R55) | `/builder-ship` reads local memory dir, calls `POST /memory/sync`, progress UX | §2 (push trigger) |
| [#275](https://example.com/builders#/task/275) (V3.R56) | SessionStart / `/builder-start` reads `/memory/since`, writes newer files locally, last-write-wins | §2 (pull trigger), §3 (conflict policy applied client-side too) |
| [#276](https://example.com/builders#/task/276) (V3.R57) | Every memory endpoint asserts `req.builder.id === path_owner_id`; Archon forensic-read endpoint with audit log | §4 (isolation enforcement) |
| [#277](https://example.com/builders#/task/277) (V3.R58) | `docs/recipes/memory-sync-conflicts.md` — operator playbook for clobber recovery, parallel-session warning | §3 (conflict policy doc) |
| [#280](https://example.com/builders#/task/280) (V3.R61) | `portability-smoke-memory.sh` + `portability-smoke-art.sh` — fresh-clone → ship → re-clone → memory restored | validates the whole stack end-to-end |
| [#281](https://example.com/builders#/task/281) (V3.R62) | Nightly `pg_dump` + weekly offsite archive + restore drill + `docs/recipes/memory-backup.md` | §5 (backup cadence) |

Already shipped under C8 (kept here for reference): [#278](https://example.com/builders#/task/278) R59 (.env.local propagation), [#279](https://example.com/builders#/task/279) R60 (secrets-in-repo scan, + ADR 0022).

## Portability test plan

The validation gate C8 ultimately answers: **"a Metic with no prior project state can clone, set up, ship, and have their memory follow them to a second machine."** Decomposes into a scripted smoke test ([#280](https://example.com/builders#/task/280) R61) and a manual rehearsal that runs before C8 is flipped to satisfied.

### Scripted smoke (`scripts/gds/portability-smoke-memory.sh`)

Runs on staging, ideally nightly in CI. Uses a synthetic Metic account.

> **Path-encoding gotcha (important for the implementer of [#280](https://example.com/builders#/task/280) R61):** Claude Code does NOT store memory at `~/.claude/projects/$PWD/...`. It hyphen-encodes the absolute project path — every `/` becomes a `-`. So a project at `/Users/lars/foo/bar` lives at `~/.claude/projects/-Users-lars-foo-bar/`. The smoke script must resolve the real encoded path; do not use `$PWD` directly. The exact encoding rule may shift across Claude Code versions, so prefer querying it via `claude` CLI or inspecting `~/.claude/projects/` after a session start over hard-coding the substitution.

```
# Phase 0 — helper to resolve the encoded Claude Code memory dir for this checkout.
# Strategy: derive it from the absolute project path, with a verification step that
# fails loudly if the encoded dir doesn't appear after a SessionStart trigger.
encode_project_dir() {
  # Hyphen-encode the absolute path. If Claude Code's rule changes, replace this
  # with a CLI query and bump the smoke script — do NOT silently let the path drift.
  printf '%s' "$1" | sed 's|/|-|g'
}

# Phase 1 — bootstrap from cold
WORK=$(mktemp -d)
cd "$WORK"
git clone https://github.com/example-owner/example.git
cd example
PROJECT_DIR="$PWD"
MEM_DIR=~/.claude/projects/"$(encode_project_dir "$PROJECT_DIR")"/memory
./scripts/setup-builder.sh                       # Node, Python, npm ci, …
TEST_GDS_TOKEN=<redacted> ./scripts/gds/auth-from-env.sh

# Phase 2 — capture a memory file pre-ship
mkdir -p "$MEM_DIR"
echo "smoke marker $(uuidgen)" > "$MEM_DIR/portability-smoke.md"
MARKER=$(cat "$MEM_DIR/portability-smoke.md")

# Phase 3 — claim + ship a known no-op task
node scripts/gds/claim.js <staging-portability-task>
# (the no-op task has zero-touch scope: it just exists for this drill)
node scripts/gds/ship.js <id> --notes "portability smoke" --summary "portability smoke"

# Phase 4 — wipe local memory + repo, re-clone, verify pull
rm -rf "$MEM_DIR"
WORK2=$(mktemp -d)
cd "$WORK2"
git clone https://github.com/example-owner/example.git
cd example
PROJECT_DIR_2="$PWD"
MEM_DIR_2=~/.claude/projects/"$(encode_project_dir "$PROJECT_DIR_2")"/memory
TEST_GDS_TOKEN=<redacted> ./scripts/gds/auth-from-env.sh
node scripts/gds/start.js                        # triggers pull
# The pull writes to MEM_DIR_2 (encoded for the *new* checkout path); the GDS
# sync logic must key memory by builder_id, not by local path, so files restore
# regardless of where on disk this checkout lives.
test "$(cat "$MEM_DIR_2/portability-smoke.md")" = "$MARKER"
echo "OK — memory survived clean reclone"
```

Failures file an idea_inbox row tagged `portability-regression` for follow-up.

### Manual rehearsal (one-time, gates C8-satisfied flip)

Lars (or a stand-in) runs the full flow with a stopwatch, on a fresh laptop / VM:

1. Fresh macOS or Linux box — no prior project artifacts, no `~/.claude`, no `~/.config/otb`.
2. Stopwatch starts.
3. `git clone` → `./scripts/setup-builder.sh` → `/builder-setup` (real browser auth).
4. `/builder-start` → claim a `newcomer_friendly` task.
5. Do the task, `/builder-ship`. (This pushes memory.)
6. Wipe `~/.claude` entirely.
7. On the same box: `git clone` to a fresh dir → `/builder-setup` (re-auth) → `/builder-start`.
8. Confirm `~/.claude/projects/.../memory/` contains the files from step 5.
9. Stopwatch stops. Note total elapsed time for the C1 onboarding-2h reference.

## Alternatives considered

**Sync via git** — push memory to a per-builder branch in the repo, e.g. `memory/<github-login>`. Rejected for three reasons: (a) leaks each builder's memory diffs to anyone with read on the repo, contradicting §4 isolation; (b) couples memory size to repo size (clones get heavier over time); (c) requires `git push` to be a viable operation from inside `/builder-ship`, which it already isn't on the no-`git` paths (mobile, sandboxed).

**Sync via DO Spaces (S3-compatible object storage)** — see §1 rejection. Right answer if file sizes were megabytes or if Postgres backup became painful; wrong answer for our actual data shape.

**Server-canonical, no local copy** (every memory read fetches from server) — rejected because Claude Code reads `~/.claude/projects/<...>/memory/*.md` directly from disk and rewriting that is out of scope. Local-first is mandatory for the way Claude Code already works.

**Local-only, never sync** — rejected because it fails C8: a builder's memory does not follow them across machines, and a dead laptop loses memory forever. Today's de-facto state, not the V3 target.

**Encrypted-at-rest (client-side encryption with per-builder key)** — rejected for V3. The server is single-tenant on a single droplet that already holds the GDS DB; encrypting memory at rest doesn't change the threat model (anyone with droplet root sees everything anyway). Revisit if (a) the server becomes multi-tenant, (b) we move to a managed Postgres where the operator can read rows, or (c) a builder requests it explicitly.

**Per-session memory snapshotting (every Claude tool call writes a delta)** — rejected as over-engineered. The information content of "memory after a session" is approximately the same as "memory at ship time"; per-tool-call deltas are noise.

## Consequences

**Good:**
- One table, two endpoints, two triggers — the smallest possible surface that satisfies C8.
- No new infra cost. Rides Postgres + existing `pg_dump`.
- Memory follows the builder across machines and across worktrees on the same machine.
- A wiped laptop is recoverable in two commands (`git clone` + `/builder-start`).
- Trust boundary is the same one [ADR 0016](<redacted>.md) already established — no new authority concept to reason about.
- Forensic access exists (for Archon) but is audit-logged, so misuse is visible.

**Costs:**
- A new sync step in `/builder-ship` slows ship by however long `POST /memory/sync` takes. Expected p50: <500 ms for typical memory dirs (kilobytes, ~3 files). Cap the wall time; if the push hangs, log + continue rather than block ship.
- Last-write-wins means the rare two-machine collision *will* lose one side's edit. Acceptable because (a) the same builder typically intends to overwrite, (b) `pg_dump` makes it recoverable, (c) the alternative (true merge) is much more complex for less than 1× the rare-event benefit.
- The 1 MB per-file cap and 50 MB per-builder cap are *guesses*. If real-world memory grows past them we either raise the cap or prune. Both are cheap; the guess being wrong is not load-bearing.

**Operationally:**
- Backup cadence has to be real before the first non-Lars builder pushes memory. Precondition check on R62: confirm GDS DB is in a `pg_dump` cron before C8 is flipped. If not, that's the first task to ship under R62.
- `docs/recipes/memory-sync-conflicts.md` (R58) needs to land before the manual rehearsal, so the playbook exists when a collision is observed.
- The onboarding diagram of the memory layer originally labelled the server-side store "PLANNED: R54–R62, mostly backlog." After this spike + R54–R62 shipped, that label was dropped. (That diagram, `04-server-repo-memory`, was later merged with the dev-box diagram into the single `04-architecture` map under [#1059](https://example.com/builders#/task/1059); it is now auto-generated and reads LIVE.)

**Implementation notes that reach into other criteria:**
- The isolation check in §4 IS a privileged-route addition. The periodic rank-check auditor ([#265](https://example.com/builders#/task/265) / V3.R45) needs to learn about the new memory endpoints so it asserts they're gated. Captured as a follow-up note on R57 ([#276](https://example.com/builders#/task/276)).
- The audit-log entry on Archon forensic reads is a security surface; the security review ([#288](https://example.com/builders#/task/288) V3.R69) should include it once the endpoint exists.
