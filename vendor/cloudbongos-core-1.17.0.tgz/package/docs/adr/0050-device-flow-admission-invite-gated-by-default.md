# ADR 0050 — Device-Flow admission posture: invite-gated by default

**Date:** 2026-06-13
**Context:** GDS, security report SR-19 / task [#1000](https://example.com/builders#/task/1000). Closes an admission inconsistency between the two GitHub enrollment paths in `src/bongos/auth.js`. Extends the web-sign-in approval gate added 2026-05-30 (the `access_requests` `'invited'` model) and is governed by the trust-boundary rule in [ADR 0016](<redacted>.md) (the server enforces admission, not the client).
**Status:** Accepted.
**Track:** `internal` (development system / builder onboarding + access control).

## Problem (SR-19)

The two ways a GitHub account becomes a builder were gated **inconsistently**:

- **`completeWebFlow`** (the web hall sign-in, `/api/gds/auth/web/callback`) refused a **first-time** GitHub account unless an Archon had marked their `access_requests` row `'invited'`. Established builders (a `builders` row already exists for their `github_id`) always passed.
- **`pollDeviceFlow`** (the CLI `/builder-setup` device flow, `/api/gds/auth/device/poll`) called `upsertBuilder()` **unconditionally** the moment GitHub returned an access token. So **any GitHub account could self-enroll as a Xenos and mint a never-expiring CLI session with no Archon approval whatsoever** — simply by running `/builder-setup` and authorizing on github.com.

This directly contradicted the documented posture that **Archon admission is the only gate** for new builders (CLAUDE.md / [ADR 0016](<redacted>.md) / [ADR 0035](<redacted>.md)). The web door was locked; the CLI door was wide open. The blast radius is bounded by the Xenos sandbox (a self-enrolled account lands at the lowest rank, can only claim `xenos_claimable` tasks, and is kept out of the permission/methodology core), but it is still an unauthorized foothold inside the trust boundary and an inconsistency an auditor will (and did) flag.

## Decision

**Make both enrollment paths consistent: invite-gated by default, with an env escape-hatch.**

1. `pollDeviceFlow` now applies the **same gate** `completeWebFlow` applies, before `upsertBuilder`:
   - Look up `getBuilderByGithubId(ghUser.id)`.
   - If **no** existing builder row AND open enrollment is off AND the login has **no** `'invited'` access request → throw the same `NOT_APPROVED` error the web flow throws.
   - **An existing builder ALWAYS passes.** The gate only blocks genuine first-time entries, so an already-approved builder can never be locked out of CLI re-enrollment (e.g. re-auth on a new box). This early-pass is the load-bearing invariant.

2. Both paths share one **pure decision helper**, `firstTimeAdmissionBlocked({ existing, approved })`, so the web and CLI gates **cannot drift** out of sync the way they just did.

3. **Escape-hatch:** `openEnrollmentEnabled()` reads the environment flag **`OTB_OPEN_XENOS_ENROLLMENT`** (truthy = `'1'` or `'true'`). When set, the invite gate is skipped in **both** paths and any GitHub account self-enrolls as a Xenos again — restoring the old fully-open behavior **without a code change or redeploy**, for an owner who deliberately wants open enrollment. **Default (unset) = invite required.**

4. The CLI surfaces the refusal gracefully: the `device/poll` route returns a structured `403 { state: 'not_approved' }` (mirroring the web flow's `NOT_APPROVED` branch), and `scripts/gds/setup.js` prints a friendly "this account hasn't been approved yet — ask an Archon to invite you, then re-run `/builder-setup`" message instead of a raw error dump.

## Alternatives considered

- **Formally accept open Xenos enrollment** (document the device flow as intentionally open, relying on the Xenos sandbox to contain the risk). Rejected as the *default*: it contradicts the stated "Archon admission is the only gate" posture and leaves an un-audited self-enrollment door, even if low-privilege. It remains available **on demand** via `OTB_OPEN_XENOS_ENROLLMENT=1` — so this ADR doesn't foreclose it, it just makes "secure" the default and "open" the explicit, reversible owner choice.
- **A repo-collaborator / GitHub-org check** as the gate. Rejected: newcomers build on hosted dev boxes with no repo access, so there is deliberately no collaborator check anywhere (2026-06-07). The `access_requests` `'invited'` model is the established admission signal; reusing it keeps one gate, not two.
- **Gate inside `upsertBuilder`** (a DB-layer guard). Rejected: `upsertBuilder` is also the update path for existing builders and is called from non-admission contexts; pushing an admission policy into it would conflate "create a record" with "admit a person." The gate belongs at the two flow entry points, sharing one pure helper.

## Consequences

- **Secure by default:** a fresh GitHub account can no longer self-enroll via `/builder-setup` — it needs an Archon invite, exactly like the web hall.
- **No existing builder is locked out:** the existing-row early-pass guarantees re-auth/re-enroll keeps working for anyone already admitted.
- **Reversible without a deploy:** an owner who wants open enrollment flips `OTB_OPEN_XENOS_ENROLLMENT=1` in the systemd `EnvironmentFile` and restarts the process.
- **No drift:** the shared `firstTimeAdmissionBlocked()` helper means a future change to admission policy lands in one place for both doors.
