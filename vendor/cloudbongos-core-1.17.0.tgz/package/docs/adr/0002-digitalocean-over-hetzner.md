# 0002 — DigitalOcean over Hetzner for V1 hosting

- **Status:** Accepted
- **Date:** 2026-05-08
- **Deciders:** Lars

## Context

After locking in the [single-VPS stack](./<redacted>.md), we needed a hosting provider. Hetzner was the initial pick on cost (~$5/mo for an equivalent VPS). Setup was blocked at Hetzner's KYC step, which requires identity verification documents and a turnaround period before the account is provisioned.

## Decision

We will host on **DigitalOcean** (NYC3 region, Premium Intel 2 GB / 1 vCPU / 60 GB NVMe, ~$14/mo).

## Alternatives considered

- **Hetzner.** Cheapest at this tier, EU-based (latency penalty for the US-centric audience but acceptable). KYC friction blocked first-night progress.
- **AWS Lightsail / Google Compute Engine micro tier.** Comparable pricing, more bureaucratic console, more services to ignore. Marginal benefit for our scale.
- **Vultr.** Comparable to DigitalOcean on price and features. DigitalOcean was familiar to the operator and had no friction at signup.

## Consequences

- **~$120/yr more than Hetzner** — trivial against the $5K total budget.
- **No KYC delay** — same-night provisioning let the foundation work happen as planned.
- **NYC3 region** is good latency to the East Coast and acceptable to the rest of the US; Example is in Cleveland (Eastern Time), so this aligns with the expected operator and brand geography.
- **Premium Intel** was selected because Premium AMD wasn't available in NYC; functionally identical for this workload.
- **Lock-in is minimal** — the entire stack is OSS and the host is a generic Ubuntu VPS. Migration to another VPS provider would be a one-day operation if cost ever becomes a problem.
