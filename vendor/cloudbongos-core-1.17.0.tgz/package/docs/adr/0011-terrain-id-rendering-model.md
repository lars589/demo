# 0011 — Terrain-id world map + dispatched render strategies (Phase D)

- **Status:** Accepted; cell data model extended by [ADR 0012](./<redacted>.md)
- **Date:** 2026-05-09
- **Deciders:** Lars

> **Update (same day):** [ADR 0012](./<redacted>.md)
> splits the cell from one terrain id into two layers — ground (always
> defined) + object (optional overlay). The dispatched render
> strategies (`single` / `blob47` / `path16`) and the autotile cross-
> verify gate from this ADR are unchanged; only the cell data model is
> extended. Read 0012 for the current architecture.

## Context

[ADR 0008](./<redacted>.md) and
[ADR 0009](./0009-autotile-architecture.md) established two new asset
pipelines (family + autotile) but stopped at the asset boundary. The
runtime renderer still treated the world as a flat 2D grid of tile-id
strings: each cell stored a key like `'grass'` or `'container_door'`,
`tilePalette.js` painted a single PNG per cell, and the door tile was
literally one cell wide. Multi-tile objects had to be hand-laid in the
map by repeating the same id, and autotile families had no way to
contribute tiles at all — `selectBlob47` / `selectPath16` from
[`autotile.js`](../../public/game/world/autotile.js) existed but nothing
called them.

ADR 0009 explicitly flagged this gap as **Phase D**, deferring the
runtime data-model refactor to a separate change because it touches
both the server's movement-validation map and the client's renderer.

We needed:

1. A world data model that can represent both autotile-driven terrains
   (cells whose final tile depends on neighbors) and plain singletons
   (vendor sprites, container panels) without the renderer having to
   special-case each one.
2. A way to ship the refactor before all autotile families are
   generated, so the world keeps rendering when assets are missing.
3. A single source of truth for "is this cell walkable?" that the
   server uses for movement validation and the client honors for
   prediction.
4. Cross-verification that the JS runtime picker and the Python
   compositor agree on tile selection — drift here means the renderer
   would pick a different tile than the compositor produced and edge
   matching breaks.

## Decision

Cells store a **terrain id**. The renderer dispatches per terrain to a
**render strategy** declared in a single registry. Three strategies:

- `single` — paint the texture registered as `tex_<game_key>`. Legacy
  path; covers terrains we have not migrated to autotiles (sea, rock,
  the 8 container panels).
- `blob47` — query 8 neighbors, call `selectBlob47(myTerrain, neighbors)`,
  paint `tex_at_<family>_<idx>` (PNG at
  `/assets/tiles/autotile/<family>/<NN>.png`). Falls back to a declared
  `fallbackTile` if the autotile family hasn't been generated yet.
- `path16` — same shape but 4-cardinal-only and 16 tiles.

The terrain enum, the render registry, and the walkability set live in
two mirrored files:

- [`public/game/world/terrain.js`](../../public/game/world/terrain.js)
  (ESM, full version with autotile-picker helpers)
- [`src/world/terrain.js`](../../src/world/terrain.js)
  (CJS, narrow — only the enum and walkability set; the server doesn't
  draw)

Until the world becomes data-driven, these two MUST stay in sync. Same
constraint and rationale as the existing two-copy `map.js`.

The renderer's per-cell dispatch lives in
[`tilePalette.js`](../../public/game/world/tilePalette.js) as
`pickTextureKeyForCell(scene, grid, x, y)`, called from
`WorldScene.drawMap()`. The 8-neighbor lookup uses `neighborsAt(grid, x, y)`
from `terrain.js`. Off-grid neighbors resolve to `null`, which the
"same as my terrain?" check naturally treats as exterior.

The container is treated as a multi-tile placed object: each of its
8 cells is a distinct terrain id (`CONTAINER_PANEL_TL` through
`CONTAINER_PANEL_BR`). The map places them in row-major order at the
container's anchor cell. All 8 are in `BLOCKING_TERRAINS`. The
container family in [`families.json`](../../art/template/families.json)
was respecced from 2×2 to 2×4 (door at bottom-left) so the family-
pipeline output matches the in-game placement footprint without
shrinking the building or moving the vendor.

`wet_sand` was dropped from the data model. The tide-line foam now
emerges from the `sand_on_sea` autotile boundary tiles — terrain is
just `SAND` right up to where it meets `SEA`, and the autotile picker
chooses the foam variant at the boundary. One less hand-tuned terrain
in the map.

A Python↔JS cross-verification smoke test
([`tests/autotile_xverify.mjs`](../../tests/autotile_xverify.mjs) plus
its emitter [`art/pipeline/autotile_xverify.py`](../../art/pipeline/autotile_xverify.py))
asserts that all 256 blob47 inputs and all 16 path16 inputs map to the
same tile index in both implementations. Wired into
[`art/pipeline/smoke_test.sh`](../../art/pipeline/smoke_test.sh) so any
drift fails the build.

## Consequences

### Positive

- **One renderer for all terrain types.** Adding a new autotile family
  is a families.json entry + a TERRAIN_RENDER row + a generation run.
  No new render code per terrain.
- **Phase D ships before the assets do.** Every autotile-strategy
  terrain declares a `fallbackTile`. With zero autotile families
  generated, the renderer falls back to the legacy single-tile PNGs and
  the world looks identical to pre-Phase-D. Adding a family is a
  visual-only change, not a code change.
- **Walkability is a property of the terrain, not the tile artwork.**
  The autotile picker can produce a foam-edge tile or a corner tile or
  a fully-interior tile for the same `SAND` terrain, and movement
  validation always says "sand is walkable." This decouples appearance
  from gameplay rules.
- **Cross-verify catches algorithm drift.** Any change to either
  `autotile_mapping.py` or `autotile.js` that breaks parity fails the
  smoke test. We can edit either side with confidence the other won't
  silently disagree.
- **Server-side terrain.js is narrow.** The CJS twin only carries the
  enum and walkability — no rendering knowledge. Less surface to keep
  in sync, less chance of accidental drift between server and client.

### Negative / costs

- **Terrain-id mirroring tax.** Two files (`src/world/terrain.js` and
  `public/game/world/terrain.js`) must stay in sync. Same problem as
  the existing two-copy map.js. Fix is the same: consolidate when the
  map becomes data-driven from Postgres.
- **Container placement is bound to the family layout.** Moving the
  container to a different size (3-wide, 5-wide, etc.) means
  re-speccing the family AND regenerating its art. We accepted this in
  exchange for the family pipeline producing coherent multi-panel art.
- **Per-cell autotile lookup at draw time.** `drawMap()` runs once per
  scene init, not per frame, so the cost is trivial in V1. If the
  world becomes large or partially streamed in the future, pre-baking
  the lookups into a tile-index grid is a clean optimization.
- **`fallbackTile` is a deliberate visual fib.** Until a family
  generates, the renderer paints the same single PNG at every cell of
  that terrain — no autotile boundaries appear. This is correct
  behavior (Phase D ships before assets), but it means a partial
  autotile rollout looks half-finished. Acceptable.

### What this does not change

- The server's movement validation in `WorldRoom.js` already calls
  `isBlocked()` from `src/world/map.js`; that function now reads
  `BLOCKING_TERRAINS` instead of `BLOCKING_TILES`. Same shape,
  different source.
- Vendor placement, dialog, and interact semantics are unchanged. The
  vendor stands at (13, 9) — same cell as before, now typed as
  `CONTAINER_PANEL_DOOR` instead of the old `container_door` tile id.
- The cost ledger ($80 hard stop) and the rest of the art-pipeline
  rules from ADR 0008 + 0009 are unchanged.
- Per-tile families and autotile families coexist with legacy per-tile
  vocabulary in `art/template/vocabulary.json` — `build_tilesheet.py`
  emits one unified manifest that covers all three.

## What this does not commit to

- **No procedural-fallback shrinkage.** The procedural fallbacks in
  `tilePalette.js` are the safety net when neither the family nor the
  legacy PNG loaded. We could ship without them once the families and
  the fallbacks are stable, but for V1 they cost nothing and make the
  world resilient.
- **No `wet_sand` regret.** If the `sand_on_sea` boundary tiles end up
  too uniform (every tide cell looking identical), we can re-introduce
  wet_sand as a dedicated terrain — it's a one-line addition to the
  enum. Not blocking V1.
