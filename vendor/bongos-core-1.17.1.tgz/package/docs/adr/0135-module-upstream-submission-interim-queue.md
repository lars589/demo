# 0135 — Module upstream submission: the review queue lives in the submitting instance's own DB (interim)

- **Status:** Accepted
- **Date:** 2026-07-08
- **Task:** [#1770](https://example.com/builders#/task/1770) (BONGOS-V1) — `bongos module submit` + `POST /modules/:key/submit`.
- **Builds on:** [ADR 0107](<redacted>.md) (the upstreaming decision — submit → review → accept), [ADR 0103](<redacted>.md) (the core extracted to `github.com/example-owner/cloud-bongos`, private), [ADR 0100](<redacted>.md) §3 (per-repo GDS — each project runs its own DB).

## Context

ADR 0107 §1 describes `bongos module submit <key>` as packaging a module + attribution + a DCO sign-off and filing it "into a rank-gated review queue **on the core**" — without granting the submitting instance write access to core. Task 1770 depends on R88 (the core extraction, [#1727](https://example.com/builders#/task/1727), shipped) and originally also listed R85 (Mercury, the forcing-function second consumer). R85 was abandoned ([#1689](https://example.com/builders#/task/1689)): the two-repo model it was meant to prove is already proven end-to-end by a different standalone instance, so it dropped as a dependency.

That leaves a gap task 1770 has to resolve to be buildable at all: **what does "on the core" concretely mean today?** The extracted core repo (`github.com/example-owner/cloud-bongos`) is a **private git repository, not a running service** — it has no HTTP API, no reachable review-queue endpoint, and (per ADR 0100 §3) each Cloud Bongos project runs its **own** GDS database; there is no shared cross-repo GDS a submission could land in. Building a real cross-repo network submission would mean inventing a core-side API that doesn't exist yet, authenticating an instance against it, and defining a wire format — none of which is this task's job (that's ADR 0107 §8's *pipeline* stage, gated on task 1771, "core-side review & accept flow," which is still `backlog`).

## Decision

**The review queue is a table (`module_submissions`, migration `<redacted>.sql`) in THIS instance's own Bongos DB** — the same database the module was built against — not a network call to a remote core.

- `bongos module submit <key>` packages the module (manifest + a full base64 file snapshot + the recorded DCO sign-off), re-runs the ADR 0107 §4 AGPL/publish pre-check, and **refuses (exit 1)** if the pre-check fails or no sign-off is on file — exactly the ADR's "done when" bar.
- The packaging + submission both flow through `POST /api/gds/modules/:key/submit` (rank: metic+archon) — the SAME route the hall "Modules" tab's submit button calls (ADR 0107 §9), so there is one authoritative implementation, not a CLI copy and a UI copy. The route re-runs the pre-check against **its own** on-disk copy of the module (the server's deployed checkout), which is the real gate — a builder's local pre-check pass is a courtesy/fail-fast, not proof, if their changes aren't committed + shipped + deployed yet.
- `GET /api/gds/modules/submissions` (rank: metic+archon) lists the queue — the surface task 1771's core-side review UI reads from.

This satisfies the letter of ADR 0107 §1 ("rank-gated review queue," "refuses if the pre-check fails," "captures attribution + sign-off") using infrastructure that actually exists today, and is forward-compatible: when a real core-side receiving endpoint exists (task 1771 or later), filing becomes a network hop to that endpoint instead of a local `INSERT`, with **no change to the CLI's or the hall UI's caller-facing contract** (both already only see `{ signed_by }` in, `{ submission }` out).

## Alternatives considered (rejected)

- **A live HTTP call to a core-hosted endpoint.** Rejected for now — no such endpoint exists; inventing one is task 1771's job (core-side review & accept), not the submit side's. Building it here would mean guessing at a contract 1771 might not honor.
- **A GitHub Issue/PR against `github.com/example-owner/cloud-bongos` via the GitHub API.** Considered (the ADR's "fork-and-PR remains a fallback" framing), but rejected as the *native* path: it would silently degrade every submission to the explicitly-non-canonical fallback, loses the structured queue (status/reviewed_by/reviewed_at) task 1771 needs, and the repo is private — the CLI/server have no standing GitHub credential scoped for that repo today.
- **A dry-run-only client (mirroring `do-api.js`'s DigitalOcean/Cloudflare pattern) that just logs "would submit" and writes a local file.** Rejected — a local orphan file is a worse "review queue" than a real, queryable DB table the instance already operates and backs up; it would need its own bespoke listing/status mechanism that duplicates what Postgres already gives us for free.

## Consequences

- **The queue is scoped per-instance, not global**, until a real cross-repo channel exists. Two instances submitting modules with the same key don't collide (each queue is local), which is fine for now (there is exactly one non-abandoned instance, this one) but is a real gap once a second live instance exists — revisit when task 1771 is scoped.
- **Task 1771** ("core-side review & accept flow") inherits a concrete shape to review against: read `module_submissions` (`status='pending'`), accept/reject with `reviewed_by`/`reviewed_at`/`review_notes`, and the accept action still has to do the ADR 0107 §6 checklist (land in `modules/<key>/`, `default:false`, allowlist, record attribution) — this ADR does not change any of that.
- **`scripts/gds/module.js` is required directly by `src/bongos/routes/modules.js`** (both resolve under `resolveCoreRoot()` — see `scripts/gds/CLAUDE.md`) to reuse `checkModulePublishability`/`recordSignOff`/`readSignOff`/`<redacted>` rather than re-implementing the pre-check server-side. `module.js` never statically requires the CLI session/fetch layer (`cli-lib.js`) — only `cmdSubmit`'s network leg lazy-requires it, and only when a human/agent actually runs the CLI — so this stays safe to load into the always-on server process (the same discipline `llm-cache.js` documents for the same reason).
