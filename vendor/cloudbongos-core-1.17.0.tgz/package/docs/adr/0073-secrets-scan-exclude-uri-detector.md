# ADR 0073 — The secrets scan excludes TruffleHog's generic URI detector

**Date:** 2026-06-20
**Context:** Secrets-scanning gate (`.github/workflows/secrets-scan.yml` + the `.husky/pre-commit` early-catch). Tasks [#1318](https://example.com/builders#/task/1318) and [#1320](https://example.com/builders#/task/1320). Relates to [ADR 0022](0022-secrets-policy.md) (secrets policy) and [ADR 0071](<redacted>.md) (dev-box teardown — the trigger).
**Status:** Accepted.
**Track:** `internal` (development system / CI gates).

## Problem — a noisy detector turned a green gate red repo-wide

The CI gate runs `trufflehog git` over the branch's **full history** with `--results=verified,unknown --fail`. TruffleHog's generic **URI** detector flags any `scheme://<userinfo>@host` string as an embedded credential. Two things in this repo match that shape and are **not** secrets:

1. **A rejection-test fixture** — `tests/box_terminal_ssrf.mjs` asserts the SSRF guard *rejects* terminal URLs that carry userinfo credentials, so the fixtures contain exactly that shape on purpose.
2. **Per-builder tunnel hostnames** that no longer resolve. The detector "verifies" a URI by DNS/connection; an unresolvable host yields an `unknown` (unverifiable) result, which `--results=verified,unknown` reports.

This was latent until 2026-06-20: when a builder's dev box was torn down ([ADR 0071](<redacted>.md)) its tunnel host stopped resolving, flipping the fixture's result to a gating failure — reddening **every** PR built off `main` (caught while landing Bongos `R01`, task [#1296](https://example.com/builders#/task/1296)).

The first attempt (task [#1318](https://example.com/builders#/task/1318)) added the fixture file to `--exclude-paths`. That failed for two compounding reasons, and is the load-bearing lesson here:

- **TruffleHog scans commit messages, not just file contents.** `--exclude-paths` filters by file path; it has no effect on a finding that lives in a commit message.
- The [#1318](https://example.com/builders#/task/1318) fix **quoted the offending URL in its own commit message** (and in an allowlist comment). That commit is now permanent in `main`'s history, so a path exclude can never suppress it.

## Decision

Exclude the **URI** detector from both scan surfaces: add `--exclude-detectors=URI` to the CI `trufflehog git` invocation and to the `.husky/pre-commit` `trufflehog filesystem` invocation. Remove the [#1318](https://example.com/builders#/task/1318) path-allowlist entry (superseded; its comment also carried the offending shape).

**This loses no meaningful coverage.** The high-value credentials-in-URL case — database connection strings (`postgres://`, `mysql://`, `redis://`, `mongodb://`, JDBC, …) — is caught by TruffleHog's **dedicated** connection-string detectors, which remain enabled. Verified locally (TruffleHog 3.95.6): a Postgres connection string with a password is still detected with the URI detector excluded. The generic URI detector adds only <redacted> matching, whose signal here is dominated by test fixtures and documentation.

**Operational rules that fall out of this:**

- **Keep commit messages free of credential-shaped URLs.** The scan reads them; history is immutable. Describe such strings in prose, never paste them.
- **A noisy detector is excluded at the detector level, not by path-allowlisting individual files** — path excludes cannot reach commit-message or cross-file recurrences of the same shape.

## Consequences

- The gate is green repo-wide again; the permanent commit-message false positive in the [#1318](https://example.com/builders#/task/1318) fix commit is neutralized without rewriting `main`'s history.
- A real credential embedded in a *non-database* URL (e.g. `<redacted>) would no longer be flagged by the URI detector. Judged acceptable: that pattern is rare in this codebase, the dedicated detectors cover the common high-value cases, and the alternative (per-host regex allowlists that every new dev-box hostname must be added to) is more fragile.
- Revisit if TruffleHog gains a way to scope a detector by path/ref, or a finding-level (not path-level) allowlist — that would let us re-enable URI with the fixtures suppressed surgically.
