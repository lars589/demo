# 0112 — Private goals: a visibility flag + a two-sided membership-request queue (invitations + join-requests)

- **Status:** Accepted
- **Date:** 2026-07-03
- **Deciders:** jaxri (Metic, owner request), Claude

**Builds on / amends:** [ADR 0086](<redacted>.md) (goal-scoped work hierarchy — this ADR adds a privacy dimension + the self-service membership queue its §3 deferred), [ADR 0106](<redacted>.md) (goal owner/manager authority — the exact authority this ADR reuses for who may invite/approve), [ADR 0016](<redacted>.md) (server-enforced rank boundary — unchanged). Reuses the approval-queue shape of `access_requests` ([`modules/onboarding/routes/access-requests.js`](../../modules/onboarding/routes/access-requests.js)).

**Track:** `internal` (GDS / methodology — a Cloud Bongos platform capability).

---

## Context

Goals are shared, module-scoped workspaces ([ADR 0086](<redacted>.md)). Today a *normal* (non-protected-scope) goal is **open-join**: `POST /goals/:id/join` adds anyone who asks. Protected-scope goals are already Archon-mediated. There was no middle ground — no way for a goal's own owner/manager ([ADR 0106](<redacted>.md)) to say "this is a curated group; ask to join, or wait to be invited." ADR 0086 §3 explicitly deferred the self-service "request → approve" queue ("it co-evolves with that ADR"); this is that ADR for the normal-goal case.

The owner request (2026-07-03): let a goal manager **make a goal private and invite builders**, let any builder **request to join**, gate approval to the goal's **owner/manager (or an Archon)**, and surface both sides in a **home-page inbox**.

One product decision was made explicitly with the requester: **private means join-gated, not hidden.** A private goal still appears in the goals list with its title + progress; "private" controls who may *join*, not who may *see*. This keeps the change small and additive — no membership filter has to thread through the goals list, goal detail, roadmap, work board, and task queries (the "fully hidden" alternative, rejected below).

## Decision

**A goal gains a `visibility` of `public` (default) or `private`. On a private goal, non-members cannot self-join — they are INVITED (and accept) or they REQUEST to join (and an owner/manager/Archon approves). Both directions are rows in one new `goal_membership_requests` queue, and each builder's actionable slice of that queue is their home-page inbox.**

### 1. Visibility (task 1951)

- `goals.visibility text NOT NULL DEFAULT 'public' CHECK (visibility IN ('public','private'))` — a purely additive column (core migration `core_188_…`, because `goals` is a **core-owned** table; [ADR 0083](<redacted>.md) §Decision 5). Every existing goal defaults to `public` = today's behaviour, so nothing changes until a manager flips it.
- `PATCH /goals/:id/visibility { visibility }` — the owner, a manager, or an Archon (the `authorizeGoalManagement` gate, [ADR 0106](<redacted>.md)). (task 1952)

### 2. The membership-request queue (task 1951)

One table, both directions, distinguished by `kind`:

| `kind` | who opens it | who resolves it | on accept/approve |
|---|---|---|---|
| `invite` | owner \| manager \| Archon, targeting `builder_id` | **only the target** (`builder_id`) — accept / decline | membership added |
| `request` | the builder themselves | owner \| manager \| Archon — approve / deny | membership added |

`goal_membership_requests(id, goal_id, builder_id, kind, status, note, created_by, resolved_by, timestamps)`, `status ∈ {pending, accepted, rejected, cancelled}`. A **partial unique index on `(goal_id, builder_id) WHERE status='pending'`** means one open ask per person+goal (the `access_requests` precedent) — an invite and a request can't both be open, and neither piles up duplicates. Resolved rows stay as the audit trail and never block a later re-ask.

**An invitation is consented, not a force-add.** It creates a *pending* row the invitee accepts from their inbox — distinct from the existing `POST /goals/:id/members` (kept byte-identical), which is the immediate owner/manager/Archon add. "Invite" is the new consented path; "add member" is the old direct one.

### 3. Routes (task 1952) — every wall in-handler, pinned `any-builder`

Following the [ADR 0106](<redacted>.md) precedent (the wall is the in-handler pure ordered gate, not a rank middleware; each route pinned in `route-rank-check` so an accidental `requireRank` re-gate or a gate removal is a red build):

- `POST /goals/:id/join` — **changed**: on a `private` goal, a non-member who isn't owner/manager/Archon is refused `409 goal_private` ("request to join or wait for an invite") instead of being added. Public + protected-scope behaviour unchanged.
- `POST /goals/:id/requests { note? }` — a builder asks to join (refused on a public non-protected goal — just join — and if already a member).
- `POST /goals/:id/invitations { builder_id, note? }` — owner/manager/Archon opens a pending invite (protected-scope keeps the Archon-only + Metic+-target rule).
- `POST /goals/:id/requests/:reqId/respond { action: approve|deny }` — owner/manager/Archon; approve → add member.
- `POST /goals/:id/invitations/:reqId/respond { action: accept|decline }` — **only the target** may resolve their own invite; accept → add member.
- `GET /goals/inbox` — the caller's `{ invitations, joinRequests, myPendingRequests }` (task 1954's home widget + task 1953's goals page read it). Mounted before `GET /goals/:id` so `inbox` isn't captured as an id (the `/goals/reorder` precedent).

The membership add on accept/approve is atomic with the resolve: `resolveMembershipRequest` only moves a row **from `pending`**, so a re-submitted resolve can't double-add.

### 4. The inbox scope (task 1954)

`listInboxFor(builderId)` returns three buckets: invitations addressed to me, join-requests on goals I **own or manage** (`goals.created_by = me` OR a `goal_members 'lead'` row), and my own outstanding requests. Requests only ever exist on a private goal someone made private — so an owner/manager always exists and a request never lands in nobody's inbox. An Archon can still approve any request via the route; the inbox stays scoped to what a builder owns/manages so it doesn't drown an Archon in every goal's queue.

## Consequences

- **Additive + reversible.** Default `public` means zero behaviour change on every existing goal; the whole feature is dark until a manager flips a goal private. Each of the four build phases (schema, API, goals-page UI, home inbox) ships independently.
- **Reuses the existing authority model wholesale** — no new notion of "who runs a goal"; invitations/approvals gate on the same owner/manager/Archon as role changes and conflict resolution ([ADR 0106](<redacted>.md)).
- **Protected-scope goals are unchanged** — their stronger Archon-mediation ([ADR 0086](<redacted>.md) §3) still governs; `visibility` is orthogonal and additive on top.
- **Private = join-gated, not hidden.** A non-member can still see a private goal's title + progress. If true concealment is ever wanted it needs its own ADR (a membership filter across list/detail/roadmap/board/tasks) — deliberately **not** built now.

## Alternatives considered

- **Fully hidden private goals (invisible to non-members) — rejected** (owner). Stronger privacy, but forces a membership filter through the goals list, goal detail, roadmap, work board, and every task query — a large surface for a feature whose ask is "control who joins." Join-gating delivers the intent with a purely additive change.
- **Invite = immediate add (no accept step) — rejected.** The owner asked for an inbox that *accepts* invitations, so an invite is consented (pending until the invitee accepts). The immediate-add path already exists as `POST /goals/:id/members` and is kept.
- **Two separate tables (invitations, join_requests) — rejected.** They share the same lifecycle (pending → accepted/rejected/cancelled), the same partial-unique "one open ask per person+goal" rule, and feed the same inbox. One table with a `kind` discriminator is less machinery and makes the mutual-exclusion index trivial.
- **Requests allowed on public goals — rejected.** A public goal is open-join; a request there is redundant. Requests are the private-goal path; the route refuses a request on a public non-protected goal.
