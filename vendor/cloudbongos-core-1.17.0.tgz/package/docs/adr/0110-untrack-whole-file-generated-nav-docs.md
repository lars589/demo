# ADR 0110 — Move whole-file generated navigation docs off the git graph; regenerate as deploy/box outputs

- **Status:** Accepted
- **Date:** 2026-07-03
- **Track:** internal
- **Builds on:** [ADR 0094](<redacted>.md) (the `gen-atlas.js` precedent — a gitignored artifact rebuilt on every deploy), [ADR 0063](<redacted>.md) (`gen-repo-map.js`), [ADR 0062](<redacted>.md) §8 (`gen-session-index.js`), [ADR 0082](<redacted>.md) (the reactive `otb-regen` heal — kept, not replaced), [ADR 0055](<redacted>.md) (server-mediated publish — untouched)
- **Task:** [#1926](https://example.com/builders#/task/1926)
- **Supersedes (in part):** the "regenerated + committed at ship" contract for `docs/repo-map.md` and `docs/session-log-index.md` (ADR 0063 / ADR 0062 §8). The nested-block half of that contract stands.

## Context

Every `/builder-ship` regenerated and **committed** up to four generated artifacts onto the shipping builder's feature branch — `docs/repo-map.md`, `docs/session-log-index.md`, the OpenAPI docs, and (render-capable ships) the diagrams — plus the file-map. Because these are rebuilt deterministically from the whole tree, two builders working in parallel produce *different* copies and their branches **collide on nearly every merge**. ADR 0082 built a reactive heal (the `otb-regen` merge driver + a server-side resolver) that untangles these collisions after the fact — but it treats the *symptom*. As the platform pushes toward multi-builder parallelism (BONGOS-V1), the healing cost grows with the number of concurrent branches, and a confirmed PR can still stall waiting on the ~5-minute reconciler.

The owner asked to remove the **dependency at the source**, not keep patching the collision. A design workflow (2026-07-03, 11 agents, adversarially reviewed) mapped the artifacts and found they split cleanly into two kinds:

- **Whole-file generated** — every byte is machine-owned (`docs/repo-map.md`, `docs/session-log-index.md`, the OpenAPI spec + reference, the diagram renders). A file like this need not live in git at all.
- **Hybrid** — hand-written prose with a generator-owned block between markers (the three nested `CLAUDE.md` symbol blocks; the `CLAUDE.md` §13 "recent sessions" snippet; `docs/file-map.md`'s two sections). These **cannot** leave git without deleting the human prose.

The `gen-atlas.js` precedent (ADR 0094) already proved the pattern for the whole-file kind: gitignore the artifact and regenerate it server-side on every deploy into the served directory — untracked, so `git reset --hard` never wipes it and no branch can ever diff it. The deploy-prod.sh atlas comment even names this as "the model the doc generators migrate onto."

## Decision

Apply the atlas pattern to the two **whole-file navigation** artifacts — `docs/repo-map.md` and `docs/session-log-index.md` — in this pass. (The OpenAPI spec and the diagram renders are deferred to follow-up tasks: the spec has external consumers and wants a bounded freshness bot; the diagrams need verified headless-Chromium handling. `docs/file-map.md` is hybrid and stays as-is.)

1. **Untrack + gitignore** `docs/repo-map.md` and `docs/session-log-index.md` (`git rm --cached` + `.gitignore`). They can no longer appear in a branch diff, so the collision class is gone at the source.
2. **Regenerate at deploy** — `scripts/deploy/deploy-prod.sh` runs both pure-JS generators beside `gen-atlas.js`, best-effort, and **LOUD on failure** (`::ERROR::` → journald) so a broken generator surfaces instead of silently serving a stale/absent map (this advances goal 24 / criterion `gcarry-pipe-loud`).
3. **Regenerate at box-source-fetch** — `infra/box-source-fetch.sh` regenerates them after the credential scrub so a fresh dev-box clone has them for the `/dev` skill and the §13 links (additive, best-effort, never touches the security path).
4. **Split the CI freshness gate.** Both generators are **dual-duty** — each also refreshes a *tracked* block (the nested `CLAUDE.md` symbol blocks; the `CLAUDE.md` §13 snippet). The old `--check` bundled the whole file and the block into one exit code, so naively relaxing it would silently drop the block gate too (the adversarial review's fatal flaw). Instead each generator now exposes `--check-block` (tracked block only) and `--check-whole` (the gitignored whole file); `fitness.js` gates the **block bucket HARD** via `--check-block`. The whole-file freshness moves from a merge-time invariant to a deploy-time one.
5. **Ship-time regen keeps only the tracked blocks.** `ship.js`'s `regenerateRepoMap`/`regenerateSessionIndex` still run the generator (which writes the gitignored whole file harmlessly) but drop the gitignored paths from their `git add`/`git status` lists — an explicit `git add <ignored path>` **aborts the whole command** (exit 1), which would have dropped the nested-block commit.

## Why this is safe — and never worse than today

- **No bot ever commits to `main`; the trust boundary is untouched.** The whole files are written as untracked files on the droplet after `git reset --hard`, exactly like `atlas.json` — no push credential, no branch-protection bypass, zero change to ADR 0016/0043/0055. No `.github/workflows/` file is added (the server App token can't land those).
- **The reactive heal is retained, not deleted.** `git-merge-regen.js`, its `REGENERABLE` set, the `.gitattributes` drivers, and the ADR 0082 server resolver are **unchanged**. Once the two files are gitignored they simply never appear in a diff, so the driver is a harmless never-triggered backstop for them — and it still actively heals the hybrid docs (`file-map.md`, nested `CLAUDE.md`) that remain tracked. During the transition it also still covers any in-flight branch that already committed the old files.
- **The block gate stays hard.** A code change that didn't regenerate its nested block, or a session change that didn't regenerate the §13 snippet, still fails its PR via `--check-block`. Only *whole-file* drift is no longer gated (there's nothing committed to gate).

## Consequences

- The `repo-map.md` / `session-log-index.md` collision class — a recurring multi-builder merge cost (the PR #167 lineage) — is eliminated at the source. Ship drops up to two bookkeeping commits per session.
- **Accepted staleness:** the *served/on-disk* whole files are fresh only *after deploy* (or a box-fetch tick), not at merge. For navigation indexes this is tolerant by nature — worst case an agent's symbol map is a few minutes stale. A generator that breaks at deploy leaves a stale/absent file with no *blocking* backstop; the LOUD `::ERROR::` line is the alarm (mandatory, not optional).
- **Transition wrinkle:** a branch that already committed either file before this lands will hit a one-time modify/delete conflict on its next merge with `main` (resolve = keep deleted). New branches never touch the files.
- **Fresh pristine checkout:** a bare `git clone` that never runs a generator lacks the two files, so a markdown link to them (e.g. the CLAUDE.md nav row, the §13 snippet's "full history" link) points at an absent path *there only*. Nothing hard-checks links in that state; every real environment (box, deploy) regenerates them. `docs-entropy` (a scheduled scanner, not a CI gate) runs where they exist.
- The generated-artifact set is now defined per-bucket; adding a future gitignored generated file means: `.gitignore` + a deploy-prod.sh regen line + a box-source-fetch line + a `--check-block`/`--check-whole` split if it is dual-duty.

## Alternatives considered

- **Post-main regen bot / cron that re-commits the files** (the owner's two original ideas) — rejected as the *primary* mechanism: both keep the files in git, weaken the freshness gate for every content PR, burn CI on regen PRs, and (there is no GitHub webhook in this codebase) can only poll anyway. "Don't commit the file" is strictly simpler than "automate re-committing it." The bounded bot survives only for the API spec (a follow-up task), which has external consumers.
- **Strengthen the reactive heal only** (ADR 0082++) — rejected: makes conflicts invisible, not absent; the per-branch bookkeeping commits and the heal latency remain, and the cost grows with parallelism.
- **Trim `docs/repo-map.md` from `REGENERABLE`/`.gitattributes`** — deferred: it would force a rewrite of `tests/git_merge_regen.mjs` (which uses repo-map as its canonical whole-file heal fixture) for no real gain, since a gitignored file never reaches the driver anyway. Leaving the entries in place is the lower-risk transition posture.
