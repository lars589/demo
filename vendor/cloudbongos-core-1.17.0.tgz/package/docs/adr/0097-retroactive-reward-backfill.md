# ADR 0097 — Retroactive drachmae backfill for shipped 0-reward tasks

- **Date:** 2026-06-28
- **Status:** Accepted
- **Track:** `internal` (GDS / economy)
- **Task:** [#1672](https://example.com/builders#/task/1672)
- **Relates to:** [ADR 0023](<redacted>.md) (per-task kind multipliers), [ADR 0054](<redacted>.md) (cost-plus session reward)

## Context — the gap

A task's `credits_reward` column **defaults to 0**. The per-task ship credit is
minted by `modules/economy/credits.js insertMultipliedConfirmCredit`, which
computes `applyKindMultiplier(credits_reward, kind)` — so a task that shipped
with `credits_reward = 0` (or NULL) paid `0 × multiplier = 0` drachmae. Many
early ships, and most dev-box / CI agent ships, never had a fair per-task reward
set, so the builders who did real, shipped work earned nothing for it on the
per-task stream.

There are **two reward streams** a builder accrues to `builders.total_credits`:

1. **Per-task** — `reason='task.confirmed'`, the kind-multiplied `credits_reward`
   ([ADR 0023](<redacted>.md)). This is the stream
   that paid 0 for the affected tasks.
2. **Cost-plus session** — `reason='session.token_reward'`,
   `round(true_cost_usd × 1.20)` per shipped session ([ADR 0054](<redacted>.md)).
   This was supposed to backstop the per-task gap, but it pays **~0 for dev-box /
   CI agent ships**: those sessions upload no priced model usage, so
   `priceModelUsage` returns ~$0 and the reward rounds to 0. So for exactly the
   ships that missed the per-task reward, the cost-plus stream *also* paid nothing.

The net effect: a real backlog of shipped work that minted no drachmae for its
builders. This ADR records the decision (and the tool) to remediate that **once,
fairly, and safely** — with an Archon authorizing the amounts.

## Decision

Ship a **one-time backfill SCRIPT** — `scripts/gds/backfill-task-rewards.js` —
that lets an Archon retroactively mint a fair, reviewed per-task reward for
shipped 0-reward tasks. The script is the deliverable; the **live run is a
separate, deliberate Archon action**, out of scope for the shipping session.

### The two reward streams + the netting rule

Backfill must not **double-pay**. For each builder, the script:

1. Computes the **would-be per-task total**: for each of that builder's shipped
   0-reward tasks, `applyKindMultiplier(reviewedRaw, kind).effective` — i.e. the
   exact amount the per-task stream *would* have paid had a fair `credits_reward`
   been set. The "reviewed raw" value is a per-task input from an Archon-reviewed
   mapping (`--rewards <file.json>`), **not** an auto-formula from `estimate`
   (re-deriving from `estimate` would just reproduce the un-reviewed numbers that
   caused the gap).
2. Sums what the **cost-plus stream already paid** that builder
   (`SUM(delta) WHERE reason='session.token_reward'`).
3. Mints only the **net**: `max(0, wouldBeTotal − costPlusAlreadyPaid)`. Floored
   at 0 — if the cost-plus stream over-paid for some sessions, backfill never
   claws back; it only ever **tops up** toward the fair task total.

The dry-run report shows, per builder: tasks, would-be per-task total, cost-plus
already paid, and the net to mint — so the Archon can **see whether the cost-plus
stream actually fired** (the audit confirms it pays ~0 for dev-box/CI ships) before
authorizing anything.

> **Why net at the builder level.** `session.token_reward` rows are session-level
> (`task_id` is NULL), so there is no clean per-task join back to a session reward.
> The honest audit question is "did the cost-plus stream already compensate this
> builder for the work these tasks represent" — a builder-level question — so the
> netting is builder-level.

### Idempotency key

Every minted row is keyed on **`(task_id, reason='reward.backfill')`**. The apply
path SELECTs existing keys first (and re-checks inside the write transaction) and
skips any task already backfilled — so a re-run can never double-mint. This
mirrors the existing idempotency guards in `maybeAwardIdeaPromotionBonus`
(`(task_id, reason='idea_promotion_bonus')`) and `awardNetNegativeBonus`
(`(task_id, reason='ship.net_negative')`). The inline `description` records the
math (`"backfill: 40c × 1.2 = 48c (bug) [reward.backfill task #N]"`), matching the
self-describing convention of the other credit_log writers (migration 031).

### Safety model — dry-run first, Archon-gated, never on import

- **Dry-run by default.** With no flags the script prints the full plan + grand
  total and **writes nothing**. The whole reason a tool that mints currency is
  safe to ship inert.
- **`--apply` requires ALL of:** the explicit `--apply` flag; an **Archon rank**
  verified server-side via `GET /api/gds/me` (the script refuses for any other
  rank — markdown/local edits cannot grant authority, [ADR 0016](<redacted>.md));
  and an **interactive y/N confirmation** at the terminal.
- **Never acts on import/require.** All work is inside `main()`, gated on
  `require.main === module`. Importing the file (the unit test does) touches no DB
  and mints nothing.
- **Graceful with no DB.** On a builder box with no prod credentials, `--help`
  and the dry-run report a clean message and exit non-zero — no stack trace, no
  mint.
- **One transaction.** The apply path inserts all credit_log rows and updates
  `builders.total_credits` in a single `BEGIN…COMMIT`, rolling back on any error.

## NOT a migration

This is a **one-time, OTB-specific remediation**, deliberately **not** a
`migrations/` file. Migrations run on **every instance**, including
`cloudbongos.com` — and a fresh instance has no 0-reward backlog to fix. Putting
this in `migrations/` would re-run a currency-minting operation against every new
instance's empty ledger, which is exactly wrong. It lives under `scripts/gds/` as
an Archon-invoked tool, like the other backfill scripts (`backfill-cost.js`,
`backfill-sessions.js`).

## Consequences

- An Archon can fairly compensate the 0-reward backlog with a reviewed,
  netted, auditable, idempotent run.
- The fix is gated behind rank + interactive confirmation + dry-run-first, so it
  cannot mint by accident or from a non-Archon machine.
- The **forward fix** (stop tasks shipping with `credits_reward = 0`) is a
  separate concern — this ADR remediates the existing backlog only; it does not
  change the default or the ship-time reward path.

## Tests

`tests/backfill_task_rewards.mjs` unit-tests the **pure logic only** (no DB):
the idempotency-key construction, the kind-multiplied per-task would-be amounts
(reusing the real `applyKindMultiplier`), the cost-plus netting (floored at 0),
and the per-builder plan assembly (already-backfilled exclusion, 0-mapping skip).
