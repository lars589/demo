-- 070_box_intents.sql — #701 (ADR 0031 §1/§2, open-question §9.4): the box
-- onboarding middleware — server-side auto-provision + wake-on-connect + the
-- web/Chromebook Remote-Control pairing path.
--
-- Context
-- -------
-- The box lifecycle (provision/park/wake/deprovision) is OPERATOR-ONLY: it runs
-- on the trusted control plane (scripts/gds/box.js) so the internet-facing web
-- process never holds DO_API_TOKEN and a stolen builder token can never spin up
-- or destroy infrastructure (routes/box.js header). That is the right security
-- posture, but it leaves a non-technical / Chromebook newcomer with no hands-off
-- on-ramp: someone has to run a CLI to give them a box, and a returning builder's
-- parked box stays parked until an operator wakes it.
--
-- #701 closes that gap WITHOUT moving the DO token into the web process. The web
-- side only ever RECORDS A REQUEST — an "intent" — in this queue. The existing
-- control-plane runner (box-intent-runner.timer → `box.js run-intents --apply`,
-- the same systemd-timer pattern as box-idle-suspend) drains the queue and does
-- the actual DigitalOcean work. The web process stays powerless over infra: it
-- can ask for a box to be provisioned or woken, never create or destroy one.
--
-- Two pieces:
--   1. box_intents — the provision/wake request queue (this is the middleware).
--   2. builder_boxes.remote_pairing_url/_at — where a box publishes its current
--      Remote-Control pairing link (POST /box/pairing) so a Chromebook builder
--      can read it from the browser (GET /box/pairing-link) without first SSHing
--      into the box (open question §9.4).
--
-- Idempotent: safe to re-run.

-- ---------------------------------------------------------------------------
-- box_intents — the provision / wake request queue (the trust-boundary-safe
-- bridge between the web process and the control plane).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS box_intents (
  id            bigserial PRIMARY KEY,
  builder_id    bigint NOT NULL REFERENCES builders(id) ON DELETE CASCADE,

  -- The lifecycle op being requested. Only the two SAFE, builder-initiated ops
  -- are queueable: 'provision' (first box) and 'wake' (recreate a parked box).
  -- park/deprovision are NEVER queued from the web — those stay operator/sweep
  -- only (a builder can't be tricked into destroying their own box).
  action        text NOT NULL CHECK (action IN ('provision', 'wake')),

  -- pending  → waiting for the runner to pick it up
  -- running  → the runner claimed it and is doing the DO work
  -- done     → the lifecycle op succeeded
  -- error    → the op failed (last_error carries why); a fresh intent can be
  --            enqueued (this row is no longer "open" so the partial unique
  --            index below lets a retry through).
  state         text NOT NULL DEFAULT 'pending'
                  CHECK (state IN ('pending', 'running', 'done', 'error')),

  -- Who asked. 'api:self' for a builder's own /box/ensure call; an actor tag for
  -- anything the control plane enqueues. Audit only.
  requested_by  text,

  -- Retry accounting. The runner bumps attempts each time it claims the intent;
  -- a small cap (enforced in the runner, not here) stops a poison intent from
  -- looping forever.
  attempts      int NOT NULL DEFAULT 0,
  last_error    text,

  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  resolved_at   timestamptz
);

-- At most ONE open (pending|running) intent per builder. A builder hammering
-- "connect" from a flaky Chromebook tab must not pile up a queue of redundant
-- provisions — the second enqueue collides here and the route returns the
-- already-open intent instead. Resolved (done|error) rows are exempt, so a retry
-- after a failure is always allowed.
CREATE UNIQUE INDEX IF NOT EXISTS ux_box_intents_open
  ON box_intents (builder_id)
  WHERE state IN ('pending', 'running');

-- The runner's hot path: "oldest pending intent". A partial index keeps it tiny
-- (it only ever indexes the unresolved tail, not the full history).
CREATE INDEX IF NOT EXISTS idx_box_intents_pending
  ON box_intents (created_at)
  WHERE state = 'pending';

-- ---------------------------------------------------------------------------
-- builder_boxes — where an active box publishes its Remote-Control pairing link.
-- ---------------------------------------------------------------------------
-- A box running `claude rc` (the always-on Remote-Control service, infra/
-- claude-rc.service) emits a pairing link a thin device drives the session from.
-- For a Chromebook (no Claude Desktop) that link is the whole on-ramp, but it
-- only exists ON the box — and reaching it would require SSH, which defeats the
-- point. So the box POSTs its current link up to the GDS (POST /box/pairing,
-- authenticated as the builder via the GDS token already on the box), and the
-- builder reads it from the browser (GET /box/pairing-link). The URL is a
-- short-lived Remote-Control handle, not a credential — but it IS sensitive, so
-- it is only ever returned to the box's OWN builder, and cleared when the box is
-- parked/destroyed (it is meaningless once the droplet is gone).
ALTER TABLE builder_boxes ADD COLUMN IF NOT EXISTS remote_pairing_url text;
ALTER TABLE builder_boxes ADD COLUMN IF NOT EXISTS remote_pairing_at  timestamptz;

INSERT INTO schema_migrations (version) VALUES ('070_box_intents')
  ON CONFLICT (version) DO NOTHING;
