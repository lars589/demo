-- 028_tasks_parallel_safe.sql — adds tasks.parallel_safe.
--
-- The autonomous overnight session-runner (task #358) can run several tasks at
-- once in separate sub-agents when the operator opts into parallel mode
-- (--parallel N). `touches[]` disjointness already prevents *file* collisions
-- mechanically (claimable_tasks + the unique active-claim index), but some
-- tasks are unsafe to run concurrently for non-file reasons: they restart the
-- server, mutate shared infra/DB, or run long deploys. parallel_safe is the
-- human/planning judgment layered on top of the mechanical touches check.
--
-- Encoding (deliberately conservative — unset means "do NOT fan out"):
--   NULL   — not yet judged (default). Treated as serial-only by the runner.
--   false  — explicitly unsafe to run alongside other tasks.
--   true   — safe to run concurrently (subject to touches[] disjointness too).
--
-- A task is eligible for a parallel slot iff it is autonomous-fit
-- (tasks_session_fit → 'autonomous' ∈ fits_session_modes, i.e.
-- automation_tag='overnight-safe' AND manual_degree<=2 AND no blocker) AND
-- parallel_safe = true. See src/bongos/db.js listClaimableTasks({ fit: 'parallel' }).
--
-- Idempotent: safe to re-run.

ALTER TABLE tasks
  ADD COLUMN IF NOT EXISTS parallel_safe boolean;

-- Rebuild the two SELECT t.* views so the new column flows through. Same
-- bodies as migration 015 — only the implicit t.* column list changes (it now
-- includes parallel_safe). DROP+CREATE rather than OR REPLACE because the
-- column-list changes; mirrors how migration 014 added `discipline`. Neither
-- view has dependents (verified against pg_depend at migration-write time).

DROP VIEW IF EXISTS claimable_tasks;
CREATE VIEW claimable_tasks AS
SELECT t.*,
       pms_calibrated_minutes(t.est_minutes, t.kind) AS est_minutes_calibrated
  FROM tasks t
 WHERE t.status = 'ready'
   AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
   AND NOT EXISTS (
     SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id
   )
   AND NOT EXISTS (
     SELECT 1 FROM claims c
       JOIN tasks t2 ON t2.id = c.task_id
      WHERE c.released_at IS NULL
        AND t2.touches && t.touches
   );

DROP VIEW IF EXISTS tasks_session_fit;
CREATE VIEW tasks_session_fit AS
SELECT t.*,
  CASE
    WHEN t.automation_tag = 'overnight-safe' AND COALESCE(t.manual_degree, 5) <= 2
         AND NOT EXISTS (SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id)
      THEN ARRAY['autonomous','check-in','active']
    WHEN t.automation_tag = 'live-only' OR COALESCE(t.manual_degree, 5) >= 4
      THEN ARRAY['active']
    ELSE ARRAY['check-in','active']
  END AS fits_session_modes,
  pms_calibrated_minutes(t.est_minutes, t.kind) AS est_minutes_calibrated,
  CASE
    WHEN t.credits_reward > 0
     AND pms_calibrated_minutes(t.est_minutes, t.kind) IS NOT NULL
     AND pms_calibrated_minutes(t.est_minutes, t.kind) > 0
    THEN ROUND(t.credits_reward::numeric / pms_calibrated_minutes(t.est_minutes, t.kind), 3)
    ELSE NULL
  END AS credits_per_minute
FROM tasks t;

INSERT INTO schema_migrations (version) VALUES ('028_tasks_parallel_safe')
  ON CONFLICT (version) DO NOTHING;
