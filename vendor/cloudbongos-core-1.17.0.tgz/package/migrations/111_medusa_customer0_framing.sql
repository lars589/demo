-- GDS-V4 Medusa — customer-0 framing + vanilla brand pack (2026-06-17)
-- Applied under claim 985 (task 1215). Idempotent on re-run.
--
-- Refines the Medusa model from the planning session: Medusa runs on its own
-- plain "vanilla" brand as CUSTOMER 0 and builds itself (the GDS builds itself);
-- Amazonprimea is CUSTOMER 1. Adds the vanilla-brand-pack task (R74) via
-- scripts/gds/seed-medusa-tasks.js (re-run after this migration).
--
-- What this migration does:
--   1. Updates the C8 (medusa-standalone-instance) criterion_md to the
--      customer-0 / customer-1 framing.
--   2. Updates the R67 dogfood proof task description to "Medusa builds itself
--      as customer 0" (matched by source_ref; idempotent).

BEGIN;

-- 1. C8 criterion text → customer-0 / customer-1 framing.
UPDATE done_when_criteria
SET criterion_md = '**Medusa runs as a configurable, self-hostable, branded instance — Medusa itself is customer 0, Amazonprimea is customer 1.** The build system is no longer a fixture of the game: it boots with no game code in the process, runs on its own database, and takes its identity, branding, and feature selection from per-instance config. Medusa runs on its own plain "vanilla" brand as **customer 0** and builds itself (the GDS builds itself); **Amazonprimea is customer 1**, its surfaces (status/builders) unchanged because their look now comes from config rather than hard-coding. Done when: a Medusa-only entrypoint boots with no Colyseus/Phaser/game routes; a fresh instance''s database holds only build-system tables (game tables only when the game module is enabled); one command (docker compose) stands an instance up with zero hard-coded server IP / service name / deploy script; product name, domain, sign-in origin, repo binding, currency label and the full branding pack resolve from one config (the Medusa vanilla brand is customer 0''s pack; an owner''s own LLM fills a new customer''s pack); the first admin is set at install time, not in a migration; core carries no hard-coded project branding (the deploy-time diagram generator reads instance branding too; Greek rank names stay by decision); an instance turns feature modules (game, art pipeline, Discord, dev boxes) on/off; an instance declares its core version and `medusa upgrade` applies new migrations + code while preserving instance config; and Medusa builds itself as customer 0 on the vanilla brand, taking a task claim->grade->ship end-to-end. Live Amazonprimea (customer 1) is unaffected throughout.'
WHERE version_id = 'GDS-V4' AND criterion_id = 'medusa-standalone-instance';

-- 2. R67 dogfood proof → customer-0 self-build framing.
UPDATE tasks
SET description = 'Part of Medusa (C8) — the proof-task that satisfies C8 ("the GDS builds itself"). Customer 0 = Medusa itself, running on the vanilla brand pack (R74); customer 1 = Amazonprimea.

Stand Medusa up as customer 0 (its own database, vanilla brand, no game code) and take one real task through the full lifecycle on it: claim -> grade -> merge -> ship with credits awarded. Medusa building Medusa, on Medusa. (A separate non-game third project is an acceptable alternative proof, but customer-0 self-build is the truest.)

**Done when:** a task reaches ''shipped'' with credits on the customer-0 Medusa instance carrying zero game code; documented as the C8 acceptance.'
WHERE source_ref = 'gds-v4-r67';

-- Self-register so migrate.sh skips this hot-applied file on the next deploy.
INSERT INTO schema_migrations (version) VALUES ('111_medusa_customer0_framing')
ON CONFLICT DO NOTHING;

COMMIT;
