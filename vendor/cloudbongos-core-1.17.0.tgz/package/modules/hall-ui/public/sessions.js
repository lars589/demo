// public-builders/sessions.js — the Session Ledger (/builders/sessions).
//
// Archon-only monitoring view of the BFG session corpus (ADR 0027 / cluster 6D).
// Read-only. Fetches /api/bongos/me to learn the viewer's rank; only the Archon
// sees data. The data itself comes from GET /api/bongos/sessions/search, which the
// SERVER gates to Archon and AUDITS (one audit_log row per load, by design) —
// this page only reflects what that endpoint returns; it is not the authority.
// On a 401 it redirects into the web sign-in flow, like the other hall pages.

(() => {
  'use strict';

  const API = '/api/bongos';
  // Generated typed client (task 1996 / R09), served as window.BongosClient by
  // /lib/bongos-client.js. baseUrl:'' passes the full `${API}/...` URLs below
  // through unchanged; result-mode ({ status, ok, data }) preserves control flow 1:1.
  const api = window.BongosClient.createClient({ baseUrl: '', credentials: 'same-origin', throwOnError: false });

  // escapeHtml / $ / num / fmtInt / fmtCompact / fmtDate / toast / rankLabel now
  // come from the shared window.OTB toolkit (dom-utils.js, loaded first). Thin
  // wrappers keep this file's exact variants (date+time fmtDate; '' rankLabel
  // empty; the 3200ms non-clearing toast). fmtDuration / shortSid stay local.
  const { escapeHtml, $, num, fmtInt, fmtCompact } = window.OTB;
  const fmtDate = (iso) => window.OTB.fmtDate(iso, { time: true });
  const rankLabel = (rank) => window.OTB.rankLabel(rank, { empty: '' });
  const toast = (msg) => window.OTB.toast(msg);

  // ---- formatters ----------------------------------------------------------

  function fmtDuration(seconds) {
    const s = num(seconds);
    if (!s) return '—';
    if (s < 60) return `${s}s`;
    const m = Math.floor(s / 60);
    if (m < 60) return `${m}m ${s % 60}s`;
    const h = Math.floor(m / 60);
    return `${h}h ${m % 60}m`;
  }

  const shortSid = (sid) => String(sid || '').slice(0, 8) || '—';

  // ---- rendering -----------------------------------------------------------

  // Stats reflect the WHOLE corpus (server-computed `totals`), not just the
  // visible page — so the Tally stays put as the viewer pages through.
  function renderStats(totals) {
    const t = totals || {};
    const cards = [
      { num: fmtInt(t.total), label: 'Sessions' },
      { num: fmtInt(t.builders), label: 'Builders' },
      { num: fmtCompact(t.tokens), label: 'Tokens' },
      { num: fmtInt(t.turns), label: 'Assistant turns' },
      { num: fmtInt(t.tool_errors), label: 'Tool errors' },
      { num: fmtInt(t.drachmae), label: `${(window.OTBBranding?.currencyLabel?.({ caps: true }) ?? 'Credits')} earned` },
    ];
    $('#stats-body').innerHTML = cards
      .map(
        (c) =>
          `<div class="stat-tile"><span class="stat-tile__label">${escapeHtml(c.label)}</span>` +
          `<span class="stat-tile__num">${escapeHtml(c.num)}</span></div>`
      )
      .join('');
  }

  function renderTable(sessions) {
    const body = $('#sessions-body');
    if (!sessions.length) {
      body.innerHTML =
        '<tr><td colspan="8" class="ledger__empty">No sessions recorded yet. They land here as builders ship and end sessions.</td></tr>';
      return;
    }
    body.innerHTML = sessions
      .map((s) => {
        const tasks = Array.isArray(s.task_ids) && s.task_ids.length
          ? s.task_ids.map((t) => `#${escapeHtml(t)}`).join(', ')
          : '—';
        const errs = num(s.tool_errors);
        return (
          '<tr>' +
          `<td><span class="ledger-sid" title="${escapeHtml(s.session_id)}">${escapeHtml(shortSid(s.session_id))}</span></td>` +
          `<td>${escapeHtml(s.github_login || ('#' + s.builder_id))}` +
          (s.rank ? ` <span class="ledger-rank">(${escapeHtml(rankLabel(s.rank))})</span>` : '') +
          '</td>' +
          `<td>${tasks}</td>` +
          `<td class="ledger__num">${fmtInt(s.assistant_turns)}</td>` +
          `<td class="ledger__num" title="${fmtInt(s.total_tokens)} tokens">${escapeHtml(fmtCompact(s.total_tokens))}</td>` +
          `<td class="ledger__num${errs > 0 ? ' warn' : ''}">${errs}</td>` +
          `<td class="ledger__num">${escapeHtml(fmtDuration(s.duration_seconds))}</td>` +
          `<td class="ledger__date">${escapeHtml(fmtDate(s.uploaded_at))}</td>` +
          '</tr>'
        );
      })
      .join('');
  }

  function showSealed(message) {
    $('#ledger-sub').textContent = 'Archons only.';
    const gate = $('#gate-scroll');
    if (message) $('#gate-body').textContent = message;
    gate.hidden = false;
    $('#stats-scroll').hidden = true;
    $('#sessions-scroll').hidden = true;
  }

  // ---- paging state --------------------------------------------------------

  const PAGE_SIZE = 50;
  const state = { offset: 0, total: 0 };
  let loading = false;

  function renderPager() {
    const pager = $('#ledger-pager');
    const total = state.total;
    if (total <= PAGE_SIZE) {
      // Everything fits on one page — no pager needed.
      pager.hidden = true;
      return;
    }
    pager.hidden = false;
    const page = Math.floor(state.offset / PAGE_SIZE) + 1;
    const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    const from = state.offset + 1;
    const to = Math.min(state.offset + PAGE_SIZE, total);
    $('#pager-pos').textContent = `Page ${fmtInt(page)} of ${fmtInt(pages)} · ${fmtInt(from)}–${fmtInt(to)} of ${fmtInt(total)}`;
    $('#pager-prev').disabled = loading || state.offset <= 0;
    $('#pager-next').disabled = loading || state.offset + PAGE_SIZE >= total;
  }

  function showData(data) {
    const sessions = Array.isArray(data.sessions) ? data.sessions : [];
    const totals = data.totals || { total: data.total || sessions.length };
    state.total = num(totals.total);
    $('#gate-scroll').hidden = true;
    $('#stats-scroll').hidden = false;
    $('#sessions-scroll').hidden = false;
    renderStats(totals);
    renderTable(sessions);
    renderPager();
    $('#ledger-sub').textContent =
      `${fmtInt(totals.total)} session${num(totals.total) === 1 ? '' : 's'} across ${fmtInt(totals.builders)} builder${num(totals.builders) === 1 ? '' : 's'}.`;
    $('#ledger-foot').textContent =
      'Most recent first. Each load of this page is itself recorded in the audit log.';
  }

  // ---- load ----------------------------------------------------------------

  // Fetch one page at the current offset. Returns true on success.
  async function fetchPage() {
    loading = true;
    renderPager();
    try {
      const res = await api.request(
        'GET',
        `${API}/sessions/search?order=recent&limit=${PAGE_SIZE}&offset=${state.offset}`
      );
      if (res.status === 401) { window.location.assign(`${API}/auth/web/start`); return false; }
      if (res.status === 403) {
        showSealed('You do not have access to the session log.');
        return false;
      }
      if (!res.ok) throw new Error(`search → ${res.status}`);
      const data = res.data;
      showData(data);
      return true;
    } catch (err) {
      console.error('[sessions] failed to load corpus', err);
      $('#ledger-sub').textContent = 'The session log could not be loaded. Try again.';
      toast('Could not load sessions.');
      return false;
    } finally {
      loading = false;
      renderPager();
    }
  }

  async function goTo(offset) {
    if (loading) return;
    const next = Math.max(0, offset);
    if (next === state.offset) return;
    const prev = state.offset;
    state.offset = next;
    const ok = await fetchPage();
    if (!ok) state.offset = prev; // roll back on failure so the pager stays honest
    else window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function wirePager() {
    $('#pager-prev').addEventListener('click', () => goTo(state.offset - PAGE_SIZE));
    $('#pager-next').addEventListener('click', () => goTo(state.offset + PAGE_SIZE));
  }

  async function load() {
    // 1. Who is viewing? (rank gate — the server enforces too.)
    let builder;
    try {
      const res = await api.request('GET', `${API}/me`);
      if (res.status === 401) {
        window.location.assign(`${API}/auth/web/start`);
        return;
      }
      if (!res.ok) throw new Error(`me → ${res.status}`);
      const payload = res.data;
      builder = (payload && payload.builder) ? payload.builder : payload;
    } catch (err) {
      console.error('[sessions] failed to read viewer', err);
      $('#ledger-sub').textContent = 'Could not verify your access. Try again.';
      toast('Could not load sessions.');
      return;
    }

    if (!builder || builder.rank !== 'archon') {
      showSealed('The session log is available to Archons only. Your current rank does not have access.');
      return;
    }

    // 2. Fetch the first page (Archon-gated + audited server-side).
    wirePager();
    await fetchPage();
  }

  load();
})();
