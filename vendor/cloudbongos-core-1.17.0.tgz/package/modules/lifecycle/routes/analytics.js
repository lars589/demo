// Builder analytics — the "AI dev curve" (V3.R72 / #291, criterion C5).
//
// Two surfaces, deliberately split by trust boundary:
//   - GET /analytics/builder/:id   — authenticated. A builder may read their
//     OWN curve; an Archon may read any builder's (the cross-builder aggregate
//     is just every builder's own page, plus the ecosystem feed below).
//   - GET /public/analytics/ecosystem — no auth. Ecosystem-wide aggregate with
//     NO per-builder identity, for status.amazonprimea.com. Individual curves
//     never cross onto the open web (mirrors the public-task privacy gate).
//
// All data derives from existing columns (see db.builderAnalytics /
// db.ecosystemAnalytics) — no migration. JSON only, same Express app.

const express = require('express');
// Intra-module + the published doorway — a module never requires a core internal.
const api = require('../../../src/module-api');
const db = require('../db');
const auth = api;
const { parseId, corsPublicGet, asyncHandler } = api;

// Clamp the trend window to a sane range. Default 90 days. `all` → 365 cap so
// a single query can never scan an unbounded history.
function parseDays(raw) {
  const s = (raw || '').toString().trim().toLowerCase();
  if (s === 'all') return 365;
  const n = parseInt(s, 10);
  if (Number.isFinite(n) && n > 0) return Math.min(n, 365);
  return 90;
}

module.exports = function buildAnalyticsRouter() {
  const router = express.Router();

  // CORS for the public ecosystem feed (mirrors routes/public.js, ADR 0029 /
  // #566) — the off-box status page reads it cross-origin. Read-only, no-auth,
  // no-secret, so a static '*' scoped to '/public/analytics' is safe. Shared
  // middleware: corsPublicGet (_helpers.js) — byte-identical to the public.js mount.
  router.use('/public/analytics', corsPublicGet('/public/analytics'));

  // rank: public — ecosystem-wide dev-curve aggregate; individuals stripped.
  router.get('/public/analytics/ecosystem', asyncHandler('GET /public/analytics/ecosystem', async (req, res) => {
    const days = parseDays(req.query.days);
    const data = await db.ecosystemAnalytics(days);
    res.set('Cache-Control', 'public, max-age=60');
    res.json(data);
  }, { message: false, errorCode: 'ecosystem_analytics_failed' }));

  // rank: own-or-archon — a builder's historical AI dev curve. A builder reads
  // their own id; an Archon reads anyone's (powers the cross-builder view).
  router.get('/analytics/builder/:id', auth.requireBuilder, asyncHandler('GET /analytics/builder/:id', async (req, res) => {
    const targetId = parseId(req, res, { code: 'bad_builder_id', positiveInt: true });
    if (targetId === null) return;
    const isSelf = String(targetId) === String(req.builder.id);
    if (!isSelf && req.builder.rank !== 'archon') {
      return res.fail('forbidden', { status: 403, message: 'You can only view your own analytics.' });
    }
    const days = parseDays(req.query.days);
    const data = await db.builderAnalytics(targetId, days);
    res.json({ builder_id: targetId, ...data });
  }, { message: false, errorCode: 'builder_analytics_failed' }));

  return router;
};
