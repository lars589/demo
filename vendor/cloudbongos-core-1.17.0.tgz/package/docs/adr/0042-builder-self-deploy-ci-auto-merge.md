# ADR 0042 — Builder self-deploy: CI auto-deploy on main + PR auto-merge

**Date:** 2026-06-07
**Context:** GDS-V3, task [#679](https://example.com/builders#/task/679) (cut prod deploy over to CI). Completes the [#597](https://example.com/builders#/task/597) / [ADR 0031](<redacted>.md) §6 goal — *no builder box holds the production droplet SSH key*. Extends [ADR 0031](<redacted>.md) §6; re-applies [ADR 0016](<redacted>.md) to CI.
**Status:** Accepted — **armed in production 2026-06-13** (interim, grader-off variant — task [#859](https://example.com/builders#/task/859); `config/deploy.json` `mode: ci`; see the *Arming record* below + session log [`<redacted>.md`](../session-logs/<redacted>.md)).

## Problem

Deploying to production is the one builder action still gated by *possession of a secret on a particular machine*, not by `builders.rank`. `scripts/gds/ship.js` (and `/merge-mode`) land a confirmed task by, on the shipper's own machine: merging the branch into `main` in a local `main` checkout, `git push origin main`, then `ssh lars@REDACTED_IP "~/deploy.sh"`. That SSH needs the operator's droplet key.

Observed 2026-06-07: builder `#25` ("niels", a Thetes on Windows) took [#631](https://example.com/builders#/task/631) to `confirmed` (built, smoke 16/16, credited) but could not deploy — `ssh … → Permission denied (publickey)`. His box has no droplet key, by design. He had to hand the final step to the operator. Every non-operator builder hits this wall, on every ship. It is the last thing standing between a trusted builder and self-sufficiency.

## Decision

Move production deploy off the shipper's machine and onto GitHub Actions, and land work via **PR auto-merge** instead of a local merge — so a builder with neither a `main` checkout nor the droplet key can ship end to end.

After cutover, the flow is:

1. Builder ships → `ship.js` pushes the **feature branch**, opens a **PR** to `main`, and enables **GitHub auto-merge**. (No local `main` merge, no `git push origin main`, no SSH.)
2. Required PR checks run. When they pass and branch protection is satisfied, GitHub **auto-merges** to `main` — no human in the loop for an ordinary PR. (Operator decision, [#679](https://example.com/builders#/task/679): *"auto-merge PR when checks pass."*)
3. The merge to `main` triggers [`.github/workflows/deploy-prod.yml`](../../.github/workflows/deploy-prod.yml) (built inert under [#597](https://example.com/builders#/task/597)), which SSHes `~/deploy.sh` from Actions using a key held **only in repo Actions secrets** — never on any builder box.
4. `ship.js` **confirms the deploy landed** — PR state `MERGED` → the `deploy-prod` workflow run for the merge commit concluded `success` → public `healthz` 200 — so the synchronous "deploy-confirmed" UX is preserved without the key. On any timeout the task stays at `confirmed` with a precise next step (never a false `shipped`).

### One switch, default OFF, atomic cutover

A single committed switch — [`config/deploy.json`](../../config/deploy.json) `mode` (`laptop` | `ci`), overridable by env `OTB_DEPLOY_MODE` — selects the path. It ships as **`laptop`** (today's behavior, byte-for-byte), so all of this code is **inert** until a deliberate flip. `ship.js` reads it via the pure, exported `parseDeployMode` (env > config > safe-default `laptop`).

The cutover is **atomic** — flipping `config/deploy.json` to `ci` must happen *in lockstep* with arming the GitHub side (`deploy-prod.yml`'s `PROD_SSH_KEY` + `DROPLET_KNOWN_HOSTS` secrets + `PROD_DEPLOY_VIA_CI=true` variable) and branch protection. Half a cutover is a live incident:
- `ci` here **without** the GitHub side armed → prod stops deploying (nothing runs `deploy.sh`). `deploy-prod.yml` gates the whole job on `PROD_DEPLOY_VIA_CI`, so a disarmed run concludes **`skipped`, not `success`** — and `ship.js`'s `deployRunSucceeded` only accepts `completed`+`success` on the merge commit, so it will NOT false-flip the task to `shipped`; it times out at `confirmed` with a clear message (closes the security-review finding that a disarmed run otherwise looked like a real deploy). An armed-but-secrets-missing run **fails hard** (exit 1), never silently.
- `laptop` here **with** the GitHub side armed → double-deploy race on the droplet checkout (`deploy-prod.yml`'s own header warns of this).

### The auto-merge gate must be tamper-proof — the security crux

With no human in the merge loop, **the CI checks *are* the authority**. The threat (per [ADR 0016](<redacted>.md)) is a trusted-but-bounded builder weakening the gate from inside their own PR. Two defenses:

1. **[`CODEOWNERS`](../../CODEOWNERS)** — a PR touching any gate surface (`.github/`, `config/deploy.json`, `ship.js`, the grader, `auth.js`/`route-rank-check.js`) **or any code that executes on the droplet at deploy** (`migrations/`, `scripts/migrate.sh`, `package.json`/`package-lock.json`, `scripts/deploy/` — `~/deploy.sh` runs migrations + `npm ci` from the merged tree, so a malicious migration or poisoned lockfile would otherwise auto-merge and run on prod) requires Archon review *even under auto-merge*, when branch protection has "Require review from Code Owners" on. Ordinary PRs (game, art, docs) carry no code owner and auto-merge freely — that's the point.

2. **The grader must RE-RUN in CI** — CODEOWNERS only catches *committed* changes to `ship.js`. A builder could run a **locally-edited, uncommitted** `ship.js` that skips the grade and opens an auto-merge PR anyway. An earlier draft of this ADR proposed a CI check that *reads the server-recorded grade* — but that is **theater**: `POST /tasks/:id/grade` records the grader scores *from the request body* (the server does not recompute them), so a tampered local ship.js can POST a fake passing grade. The only tamper-proof gate runs the grader **in CI, against the PR diff**, where the builder cannot touch it — [`.github/workflows/grade-gate.yml`](../../.github/workflows/grade-gate.yml) + [`scripts/gds/ci-grade.js`](../../scripts/gds/ci-grade.js) ([#855](https://example.com/builders#/task/855)), which reuse the exact production grading path (`ship.js runSubagentGrader` → the adversarial worker panel) and **fail closed**. It is **skip-safe** (green-but-not-gating) until the operator wires a grader auth secret AND marks it a required check — the same inert-until-armed pattern as `deploy-prod.yml`. This is a **hard precondition** of arming `ci` mode.

### Why not just hand builders the droplet key

Rejected. It puts a full shell on the production box (prod DB, every secret) on a remote builder's machine — the exact thing the trust boundary exists to prevent, and a Thetes has no trust powers by design. The deploy key lives only in Actions secrets, used by a workflow whose definition is <redacted>.

## Cutover preconditions (do NOT arm `ci` until ALL hold)

1. **CI grade-gate armed + verified** — the grader RE-RUN-in-CI check (`grade-gate.yml` + `ci-grade.js`, [#855](https://example.com/builders#/task/855)) is built and skip-safe but NOT yet a real gate. The operator must (a) add a grader auth secret (`ANTHROPIC_API_KEY` or `CLAUDE_CODE_OAUTH_TOKEN` — the grader spawns the `claude` CLI, ~4 model calls/PR), (b) verify a real grader-in-CI run passes a known-good PR and fails a known-bad one, and (c) mark `grade-gate` a required status check on `main`. *Without this, `ci` mode lets a tampered local ship.js bypass the quality grader.* (Built in [#855](https://example.com/builders#/task/855); arming/verification is part of the cutover.)
2. **Functional checks required** — the DB-free **unit suite** runs as a PR check ([`.github/workflows/pr-unit-tests.yml`](../../.github/workflows/pr-unit-tests.yml) + [`scripts/gds/run-unit-tests.js`](../../scripts/gds/run-unit-tests.js), 56 tests, [#856](https://example.com/builders#/task/856)); the operator marks it required at cutover. The **integration smoke** (full server + Postgres service container) is a follow-up ([#862](https://example.com/builders#/task/862)). The existing `secrets-scan` / `dep-audit` already run on PRs.
3. **Branch protection on `main`** — require a PR (block direct pushes), require the checks in (1)+(2) + Code-Owner review, enable auto-merge.
4. **`deploy-prod.yml` armed** — `PROD_SSH_KEY` + `DROPLET_KNOWN_HOSTS` secrets + `PROD_DEPLOY_VIA_CI=true` (a dedicated deploy keypair, not a personal key).
5. **Flip `config/deploy.json` → `ci`** — atomically with (3)+(4).

Until (1)–(5), the switch stays `laptop` and the operator lands work as today (`/merge-mode`).

## Consequences

- **Builder `#25` and every future builder** can ship end to end from any machine (Windows, Chromebook, dev box) with no `main` checkout and no droplet key.
- **The merge to `main` becomes the control checkpoint** — what reaches `main` goes live within ~1 min. Governance moves from "who holds the key" to "what the checks require + who reviews the gate" — squarely inside the [ADR 0016](<redacted>.md) model.
- **New dependency:** `ci` mode uses the GitHub CLI (`gh`) on the builder's machine to open the PR + enable auto-merge. A follow-up either adds a `doctor.js` check for `gh` or moves PR creation server-side (the server already holds a GitHub principal) to drop the per-builder dependency.
- **Deploy confirmation is workflow-run-based**, not commit-pinned at the edge (`/healthz` returns only `ok`). A follow-up can expose the running commit for a stricter edge assertion.

## Follow-ups (filed as GDS tasks)

- CI **grade-gate** reading the server-recorded grade — **blocks cutover** (precondition 1).
- PR-check workflows: unit suite + integration smoke (Postgres service) as required checks (precondition 2).
- Drop the per-builder `gh` dependency (server-mediated PR creation) + `doctor.js gh` check.
- Commit/version endpoint for a commit-pinned edge deploy confirmation.

## Arming record — 2026-06-13 (task 859): the grader-off INTERIM cutover

`ci` mode was **armed in production** on 2026-06-13 under task 859 — but as a deliberate
**interim variant** that defers precondition 1 (the CI grade-gate), because the
subagent grader was already globally bypassed (`GRADER_BYPASS_ENABLED=1`, [ADR 0041](<redacted>.md))
during the provider outage. With the grader off everywhere, gating auto-merge on a
*grade-gate* would be theater; instead the merge gate is:

- **Required PR checks:** `unit` (the DB-free unit suite, task 856) + `trufflehog` (full-history secret scan). Both were red on `main` for unrelated reasons and were greened first: `anti_grid` (needs numpy, Node-only runner) moved to the unit runner's `KNOWN_FAILING` set; `tests/bfg.mjs` (deliberate fake-DSN fixtures) added to the secret-scan allowlist.
- **Code-Owner review** on every gate surface (this repo's `CODEOWNERS`), now extended to the gate "brains" (`scripts/gds/run-unit-tests.js`, `.husky/`) so a PR cannot mute a test or allowlist a real secret unreviewed.
- **Deploy-time `main-audit`** on the droplet (`~/deploy.sh` → `infra/deploy-main-audit-gate.sh`, [ADR 0043](<redacted>.md)) — reverts/blocks sub-Metic edits to permission-sensitive paths regardless of how they merged.

What was set: `PROD_SSH_KEY` (a dedicated ed25519 deploy key, **forced-command `~/deploy.sh`** in the droplet's `authorized_keys`) + `DROPLET_KNOWN_HOSTS` secrets; repo var `PROD_DEPLOY_VIA_CI=true`; branch protection on `main` (require PR, required checks `unit`+`trufflehog`, require Code-Owner review, 0 ordinary approvals, block direct push for non-admins); repo auto-merge enabled; `config/deploy.json` → `ci`. `deploy-prod.yml` verified end-to-end (Actions → SSH → `~/deploy.sh` → public healthz) before the flip.

**Tighten-later (re-arm when the grader returns):** turn `GRADER_BYPASS_ENABLED` off, re-introduce the `grade-gate` required check (precondition 1, needs an `ANTHROPIC_API_KEY` Actions secret), and land the integration-smoke gate (task 862, precondition 2). **Rollback:** set `config/deploy.json` → `laptop` **and** unset the `PROD_DEPLOY_VIA_CI` repo var (admins retain direct main-push for this).
