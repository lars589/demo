const express = require('express');
// The published doorway — requireBuilder / requireRank live on the doorway surface
// (a module never reaches into core auth directly; the one-way boundary, ADR 0083).
const api = require('../../../src/module-api');
const auth = api;
// The autonomy gate is a domain CLI under scripts/ (it travels with this domain
// but stays a command; its gatherSignals reaches the ideas/economy/lifecycle reads
// from OUTSIDE the kernel boundary, which a modules/ file may not do). scripts/ is
// neither core internals nor a sibling module, so importing it here is allowed.
const autonomyGate = require('../../../scripts/gds/autonomy-gate');

// System 3 (task 1351): the autonomy precheck over HTTP. The deterministic
// decision logic lives in scripts/gds/autonomy-gate.js (run directly as a CLI
// Step 0 by the nightly routines on the droplet); this endpoint exposes the same
// decision for any other caller. BUILT DISABLED: while OTB_AUTONOMY_ENABLED!=1
// it always returns decision:'go' (inert).
//
// rank: archon — autonomy is an ops control surface, and a precheck records an
// autonomy_runs row + git-fetches. Keep it archon-scoped (ADR 0016).
module.exports = function buildAutonomyRouter() {
  const router = express.Router();

  router.get('/autonomy/precheck', auth.requireBuilder, auth.requireRank('archon'), async (req, res) => {
    const routine = String(req.query.routine || '').slice(0, 64);
    if (!routine) return res.fail('routine_required', { status: 400, message: 'pass ?routine=<name>' });
    try {
      const out = await autonomyGate.precheck(routine);
      res.json(out);
    } catch (err) {
      // Fail-open: an autonomy gate must never become a new way to break a routine.
      console.error('[gds] GET /autonomy/precheck', err);
      res.json({ routine, decision: 'go', reason: `precheck error (fail-open): ${err.message}`, enabled: autonomyGate.isEnabled() });
    }
  });

  return router;
};
