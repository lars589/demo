# ADR 0025 — Structured criterion↔task link (`task_criteria`)

**Date:** 2026-05-30
**Context:** GDS-V3, task [#435](https://example.com/builders#/task/435) (Project status queryability — structured criterion↔task link + /status skill + Conductor nudge).
**Status:** Accepted.

## Problem

Answering a routine question — "what's left to satisfy criterion C8?" — took ~10 sequential GDS calls. The reason: the relationship between a done-when criterion and the tasks that satisfy it existed **only as prose** inside each task's `description`:

```
**Criterion:** C8 — cloneable repo, local-first memory, server-canonical on ship.
…
**Cross-refs:** Gates V3.R55–V3.R63 (the C8 implementation tasks).
```

To answer the question a session had to: read `done_when_criteria` to find C8, grep `scripts/gds/seed-v3-tasks.js` to discover which tasks claim that criterion, eyeball a "Gates R55–R63" sentence, then re-query each task's live status. That is archaeology, not a query — slow, error-prone, and impossible to surface on the public status dashboard.

There was already a link, but the wrong one: `done_when_criteria.satisfied_by_task_id` is a **single, reverse** pointer — the one ship-task that *closed* a criterion. We needed the **forward, many** relation: the many tasks that *gate* a criterion, before it's closed.

## Decision

Add a dedicated **many-to-many join table** `task_criteria(task_id, criterion_id)` (migration 055), referencing `tasks(id)` and `done_when_criteria(id)`. A new read helper `criterionProgress(versionId)` joins it to roll up, per criterion: the gating tasks, their live statuses, and what remains. Surfaced as the public `GET /api/gds/versions/:id/progress`, consumed by `scripts/gds/status.js` + the `/status` skill, and routed to by a Conductor nudge.

### Why many-to-many (rejected alternatives)

- **A `criterion_id` column on `tasks`** — rejected: tasks routinely contribute to *multiple* criteria (prose like "C2, C7"). A single FK column can't represent that without a delimiter hack.
- **Reusing `satisfied_by_task_id`** — rejected: it's singular and semantically the *closing* task, not the *gating* set. Overloading it would conflate "this task finished the criterion" with "this task is one of several that build toward it."
- **Keep parsing prose at read time** — rejected: that's the status quo whose cost we're removing. Every consumer (CLI, dashboard, future agents) would re-implement a fragile parser.

### The backfill is positional — and that fragility is the point

Migration 055 backfills the table from the existing prose. The catch: the prose says "C8" but a criterion's `criterion_id` is a semantic slug (`cloneable-local-memory-server-sync`). **"Cn" is the 1-based position** by `(sort_order, criterion_id)` within the version. So the backfill ranks each version's criteria with `ROW_NUMBER()` and joins prose "Cn" → the n-th criterion of the *same* version.

This positional decode is brittle — reorder the criteria and old prose references drift. That brittleness is exactly why the structured link must exist: **after this backfill, `task_criteria` is canonical**, and prose `Cn` references are legacy. New tasks should populate the join table directly rather than relying on the decode being re-run (it is not — it's a one-time historical migration).

`cnum` is recomputed live (same `ROW_NUMBER()` ordering) in `criterionProgress`, so the "C8" label the user sees stays correct even if criteria are added or reordered later. Tasks whose Criterion line carries no "Cn" token (e.g. "cross-cutting (identity)") are left unlinked and counted as `unattributed_tasks` — the rollup reports coverage honestly rather than guessing.

## Consequences

- **One-call status.** `/status C8` answers in a single request what previously took ~10. The public dashboard can adopt the same endpoint.
- **The Conductor stays advisory + zero-cost.** It gains one regex trigger that *routes* status-intent prompts to `/status` (proposes, never disposes; no LLM call) — it does not answer questions itself. Consistent with [ADR 0024 (MAS)](<redacted>.md) Phase 3.
- **Follow-up needed:** task creation does not yet populate `task_criteria`, so tasks created after the backfill are unlinked until a manage endpoint / planning-flow wire-up lands. Filed as a follow-up task at ship time. Until then `/status` under-counts new work, which `unattributed_tasks` makes visible.
- **No authority change.** The endpoint is public read-only (same posture as `/versions/:id/done-when`); the join table carries no permission semantics. ADR 0016 trust boundary is untouched.
