'use strict';

// Discord role-sync — Phase 3 F5 (ADR 0033 §4).
//
// ONE-WAY: GDS → Discord. The bot sets a member's Discord rank-role
// (Xenos / Metic / Archon) from the LIVE `builders.rank`. It READS the GDS and
// WRITES Discord — never the reverse — so a Discord role can never feed
// authority back into the GDS (ADR 0016 / 0032 §2: roles are cosmetic
// reflections, never keys). Role badges become continuously honest.
//
// Fired on three triggers (ADR 0033 §4): on link (F2 callback), on rank change
// (PATCH /builders/:id/rank), and on a periodic reconcile (the bot's interval +
// on-ready sweep). All best-effort: a Discord-side failure (missing Manage
// Roles, hierarchy, member left the guild) logs and moves on — it must never
// break a rank change or a link.
//
// The FOUR live ranks have Discord roles (xenos/thetes/metic/archon). Any other
// rank value maps to NO managed role, and the sync strips the managed roles.
//
// Requires (go-live, not code): the GuildMembers privileged intent, the bot to
// hold Manage Roles, and the bot's own role positioned ABOVE the three rank
// roles in the guild hierarchy. Without those the role writes 403 and are
// logged — the GDS is unaffected.

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const db = require('./db');
const ic = require('../../src/module-api');

// The live ranks that map to a Discord role badge = the full rank ladder, in
// order low→high. Sourced from db.LIVE_RANK_LADDER — the server-side single
// source (D1) — so a ladder change (e.g. thetes, ADR 0034) lands in one place.
const MANAGED_RANKS = db.LIVE_RANK_LADDER;

// PURE — the rank→role-id map from env (DISCORD_ROLE_XENOS/METIC/ARCHON) or
// ~/.config/otb/discord-bot.json `role_ids: { xenos, metic, archon }`. Returns
// only the keys actually configured; an empty map means role-sync is inert.
function loadRoleMap(env = process.env) {
  const out = {};
  const envKeys = { xenos: 'DISCORD_ROLE_XENOS', thetes: 'DISCORD_ROLE_THETES', metic: 'DISCORD_ROLE_METIC', archon: 'DISCORD_ROLE_ARCHON' };
  for (const rank of MANAGED_RANKS) {
    if (env[envKeys[rank]]) out[rank] = String(env[envKeys[rank]]);
  }
  if (Object.keys(out).length) return out;
  try {
    const raw = ic.readConfigFileSync('discord-bot.json');
    const cfg = JSON.parse(raw);
    if (cfg.role_ids && typeof cfg.role_ids === 'object') {
      for (const rank of MANAGED_RANKS) {
        if (cfg.role_ids[rank]) out[rank] = String(cfg.role_ids[rank]);
      }
    }
  } catch (_) { /* not configured */ }
  return out;
}

// PURE — the guild id the bot manages roles in. Env DISCORD_GUILD_ID, else the
// file's guild_id, else null (caller falls back to the bot's single cached guild).
function loadGuildId(env = process.env) {
  if (env.DISCORD_GUILD_ID) return String(env.DISCORD_GUILD_ID);
  try {
    const raw = ic.readConfigFileSync('discord-bot.json');
    const cfg = JSON.parse(raw);
    if (cfg.guild_id) return String(cfg.guild_id);
  } catch (_) { /* not configured */ }
  return null;
}

// PURE — a rank's Discord role id, or null if it isn't a managed live rank or
// has no configured mapping.
function rankToRoleId(rank, roleMap) {
  if (!MANAGED_RANKS.includes(rank)) return null;
  return roleMap[rank] || null;
}

// PURE — given the member's CURRENT role ids and their target rank, compute the
// minimal change: which managed role to add (the target, if missing) and which
// managed roles to remove (any other rank role they currently hold). Idempotent:
// a member already holding exactly their rank role yields { add:null, remove:[] }.
// Never touches non-managed roles — we only ever own the three rank badges.
function computeRoleChange(currentRoleIds, rank, roleMap) {
  const managedIds = MANAGED_RANKS.map((r) => roleMap[r]).filter(Boolean);
  const target = rankToRoleId(rank, roleMap);
  const current = new Set((currentRoleIds || []).map(String));
  const remove = managedIds.filter((id) => id !== target && current.has(id));
  const add = target && !current.has(target) ? target : null;
  return { add, remove };
}

// The bot's managed guild, or null if the bot isn't connected / not in it.
// Lazy-requires discord-bot to avoid a require cycle (bot → role-sync on its
// reconcile path; role-sync → bot here).
function getGuild() {
  const bot = require('./discord-bot');
  const client = bot.getClient && bot.getClient();
  if (!client) return null;
  const gid = loadGuildId();
  return gid ? client.guilds.cache.get(gid) || null : client.guilds.cache.first() || null;
}

const realDeps = {
  getDiscordLink: db.getDiscordLink,
  getBuilderById: db.getBuilderById,
  listDiscordLinks: db.listDiscordLinks,
  loadRoleMap,
  getGuild,
};

// Sync ONE builder's Discord rank-role from their live rank. Best-effort, never
// throws. Returns a small status object for logging/tests.
async function syncBuilderRole(builderId, deps = realDeps) {
  try {
    const link = await deps.getDiscordLink(builderId);
    if (!link) return { ok: false, reason: 'not_linked' };
    const builder = await deps.getBuilderById(builderId);
    if (!builder) return { ok: false, reason: 'no_builder' };

    const roleMap = deps.loadRoleMap();
    if (!Object.keys(roleMap).length) return { ok: false, reason: 'no_role_map' };

    const guild = deps.getGuild();
    if (!guild) return { ok: false, reason: 'no_guild' };

    const member = await guild.members.fetch(link.discord_user_id).catch(() => null);
    if (!member) return { ok: false, reason: 'member_not_found' };

    const current = [...member.roles.cache.keys()];
    const { add, remove } = computeRoleChange(current, builder.rank, roleMap);
    if (!add && !remove.length) return { ok: true, noop: true };

    if (remove.length) await member.roles.remove(remove, 'GDS role-sync (ADR 0033 §4)');
    if (add) await member.roles.add(add, 'GDS role-sync (ADR 0033 §4)');
    return { ok: true, add, removed: remove };
  } catch (err) {
    // Most likely a Discord permission/hierarchy problem — log, don't throw.
    console.error(`[discord-bot] role-sync failed for builder ${builderId}:`, err.message);
    return { ok: false, reason: 'error', error: err.message };
  }
}

// Display colors for each managed rank role (Discord uses decimal integers).
// These mirror the hall badge palette in modules/hall-ui/public/style.css
// (.rank-badge--<rank> background) so a builder's Discord role color matches the
// badge they see in the builders' hall; 0 = Discord default if a rank is missing.
//   xenos  #d4ae7a (weathered bronze)   thetes #c98a5e (polished copper)
//   metic  #e6e1d3 (weathered marble)   archon #e7c14a (sun gold)
const RANK_COLORS = { xenos: 0xD4AE7A, thetes: 0xC98A5E, metic: 0xE6E1D3, archon: 0xE7C14A };

// Create any managed rank roles that are missing from the guild and save their
// ids back to ~/.config/otb/discord-bot.json. Called once on bot ready so the
// config stays self-maintaining — no manual copy-paste of role ids needed.
// Best-effort: a Discord 403 (missing Manage Roles) logs and returns the
// partial map rather than crashing the reconcile that follows. Env-sourced role
// ids are never overwritten (env wins over file per loadRoleMap convention).
async function ensureRankRoles(guild) {
  if (!guild) return {};
  const botToken = require('./auth').loadDiscordBotToken();
  if (!botToken) return {};

  // Load existing map; determine which ranks have no id yet.
  const existing = loadRoleMap();
  const missing = MANAGED_RANKS.filter((r) => !existing[r]);

  const created = {};
  for (const rank of missing) {
    try {
      const res = await fetch(`https://discord.com/api/guilds/${guild.id}/roles`, {
        method: 'POST',
        headers: { Authorization: `Bot ${botToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: rank.charAt(0).toUpperCase() + rank.slice(1),
          color: RANK_COLORS[rank] || 0,
          hoist: false,
          mentionable: false,
        }),
      });
      if (!res.ok) {
        const text = await res.text();
        console.error(`[discord-bot] ensureRankRoles: failed to create ${rank} role (${res.status}): ${text}`);
        continue;
      }
      const role = await res.json();
      created[rank] = role.id;
      console.log(`[discord-bot] ensureRankRoles: created ${rank} role (id=${role.id})`);
    } catch (e) {
      console.error(`[discord-bot] ensureRankRoles: error creating ${rank} role:`, e.message);
    }
  }

  if (Object.keys(created).length) {
    // Persist the new ids into the config file so the next boot finds them.
    // File-only: we never overwrite env vars. If the file isn't writable, log
    // and continue — the ids will be recreated on the next boot instead.
    const cfgPath = ic.configPath('discord-bot.json');
    try {
      // Read the existing config from wherever it lives (configured or legacy
      // dir) so we preserve its other fields, then write to the configured dir.
      const cfg = JSON.parse(ic.readConfigFileSync('discord-bot.json') || '{}');
      cfg.role_ids = Object.assign({}, cfg.role_ids || {}, created);
      fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 4), 'utf8');
      console.log(`[discord-bot] ensureRankRoles: saved ${Object.keys(created).join(', ')} to config.`);
    } catch (e) {
      console.error('[discord-bot] ensureRankRoles: could not save role ids to config:', e.message);
    }
  }

  const finalMap = Object.assign({}, existing, created);

  // Reorder managed roles in Discord to match the rank ladder (MANAGED_RANKS is
  // low→high; archon must sit above metic above thetes above xenos). Discord
  // allows partial PATCH — we only send the 4 managed roles; others are untouched.
  // Strategy: fetch all guild roles, collect the positions currently occupied by
  // managed roles, sort them descending, and assign archon→metic→thetes→xenos
  // from highest to lowest. This keeps managed roles in the same position band
  // while making their relative order correct.
  const managedIds = MANAGED_RANKS.map((r) => finalMap[r]).filter(Boolean);
  if (managedIds.length >= 2) {
    try {
      const allRolesRes = await fetch(`https://discord.com/api/guilds/${guild.id}/roles`, {
        headers: { Authorization: `Bot ${botToken}` },
      });
      if (allRolesRes.ok) {
        const allRoles = await allRolesRes.json();
        const posMap = {};
        const colorMap = {};
        for (const r of allRoles) { posMap[r.id] = r.position; colorMap[r.id] = r.color; }

        // Recolor managed roles whose color has drifted from RANK_COLORS. Color
        // is only set at creation (above), so a palette change here wouldn't
        // otherwise reach roles that already exist — PATCH each one individually
        // (the bulk roles endpoint only moves positions, not colors).
        for (const rank of MANAGED_RANKS) {
          const id = finalMap[rank];
          const desired = RANK_COLORS[rank];
          if (!id || desired === undefined || colorMap[id] === desired) continue;
          try {
            const recolorRes = await fetch(`https://discord.com/api/guilds/${guild.id}/roles/${id}`, {
              method: 'PATCH',
              headers: { Authorization: `Bot ${botToken}`, 'Content-Type': 'application/json' },
              body: JSON.stringify({ color: desired }),
            });
            if (recolorRes.ok) {
              console.log(`[discord-bot] ensureRankRoles: recolored ${rank} role to #${desired.toString(16).padStart(6, '0')}`);
            } else {
              const text = await recolorRes.text();
              console.error(`[discord-bot] ensureRankRoles: recolor ${rank} failed (${recolorRes.status}): ${text}`);
            }
          } catch (e) {
            console.error(`[discord-bot] ensureRankRoles: error recoloring ${rank} role:`, e.message);
          }
        }

        // Gather positions currently occupied by managed roles, sorted desc.
        const managedPositions = managedIds
          .map((id) => posMap[id])
          .filter((p) => p !== undefined)
          .sort((a, b) => b - a);

        // MANAGED_RANKS is low→high, so reverse for highest→lowest assignment.
        const highToLow = [...MANAGED_RANKS].reverse();
        const patch = [];
        for (let i = 0; i < highToLow.length; i++) {
          const id = finalMap[highToLow[i]];
          if (id && managedPositions[i] !== undefined) patch.push({ id, position: managedPositions[i] });
        }

        if (patch.length >= 2) {
          const patchRes = await fetch(`https://discord.com/api/guilds/${guild.id}/roles`, {
            method: 'PATCH',
            headers: { Authorization: `Bot ${botToken}`, 'Content-Type': 'application/json' },
            body: JSON.stringify(patch),
          });
          if (patchRes.ok) {
            const order = highToLow.filter((r) => finalMap[r]).join(' > ');
            console.log(`[discord-bot] ensureRankRoles: reordered roles (${order})`);
          } else {
            const text = await patchRes.text();
            console.error(`[discord-bot] ensureRankRoles: role reorder failed (${patchRes.status}): ${text}`);
          }
        }
      }
    } catch (e) {
      console.error('[discord-bot] ensureRankRoles: error reordering roles:', e.message);
    }
  }

  return finalMap;
}

// Sweep every linked builder. Used on-ready + on the periodic interval. Returns
// counts for the log line. Sequential to stay gentle on Discord's rate limits;
// the link table is tiny.
async function reconcileAll(deps = realDeps) {
  const links = await deps.listDiscordLinks();
  let synced = 0;
  for (const l of links) {
    const r = await syncBuilderRole(l.builder_id, deps);
    if (r.ok) synced++;
  }
  return { total: links.length, synced };
}

module.exports = {
  // pure (unit-tested)
  MANAGED_RANKS,
  RANK_COLORS,
  loadRoleMap,
  loadGuildId,
  rankToRoleId,
  computeRoleChange,
  // effectful
  getGuild,
  ensureRankRoles,
  syncBuilderRole,
  reconcileAll,
  realDeps,
};
