-- 068_thetes_requires_rank.sql — #692 / ADR 0034: make `thetes` a 4th LIVE rank.
--
-- Context: `thetes` is the GRADUATED-newcomer rank, sitting between `xenos`
-- (sandboxed entry) and `metic` (trusted working rank): ladder is
--   archon > metic > thetes > xenos.
-- A Thetes escapes the newcomer_friendly sandbox and claims the whole general
-- queue (any task with requires_rank='xenos', the default) but is blocked from
-- tasks raised to requires_rank='metic'/'archon'. A Xenos auto-graduates here
-- after 3 confirmed tasks (server-side, in the confirm transaction — db.js
-- maybeAutoGraduateToThetes).
--
-- `thetes` is ALREADY allowed by builders.rank's CHECK (migration 023 reserved
-- the full ladder up front), so this migration only widens the INVERSE gate:
-- tasks.requires_rank, whose CHECK (migration 044) currently allows just
-- xenos/metic/archon. Without this, an Archon could never raise a task's floor
-- to 'thetes', and rankAllowsTask's tier comparison would have no schema-backed
-- domain for the value.
--
-- Idempotent: drops + re-adds the named constraint, safe to re-run.

ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_requires_rank_enum;
ALTER TABLE tasks
  ADD CONSTRAINT tasks_requires_rank_enum
  CHECK (requires_rank IN ('xenos', 'thetes', 'metic', 'archon'));

INSERT INTO schema_migrations (version) VALUES ('068_thetes_requires_rank')
  ON CONFLICT (version) DO NOTHING;
