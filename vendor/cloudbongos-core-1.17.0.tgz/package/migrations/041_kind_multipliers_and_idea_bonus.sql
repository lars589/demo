-- 041_kind_multipliers_and_idea_bonus.sql — V3.R27 (#247).
--
-- Per-kind credit multipliers + staged idea-promotion bonus.
--
-- The multiplier table lives as a frozen constant in src/bongos/db.js
-- (KIND_MULTIPLIERS) — NOT in this database. See ADR 0023 for the rationale:
-- policy values deserve a code-review + commit trail, not an UPDATE on a hot
-- table. This file exists to:
--
--   1. Reserve migration number 041 so the claim allocator advances cleanly.
--   2. Document the policy at the schema layer so anyone reading the
--      migrations folder sees the change without having to grep db.js.
--   3. Tighten the credit_log.reason convention by recording the two new
--      reason strings ('idea_promotion_bonus' already, 'task.confirmed'
--      still primary) in a comment so future migrations don't accidentally
--      collide with them.
--
-- Effects on existing data:
--   - None. All existing credit_log rows are untouched (their `description`
--     stays NULL; new rows write a "<raw>c × <mult> = <effective>c (<kind>)"
--     string).
--   - The credit_log.reason column is text (no CHECK), so 'idea_promotion_bonus'
--     is accepted without a schema change. The trigger trg_credit_log_apply
--     fires on every INSERT regardless of reason, so total_credits stays in
--     sync without modification.
--
-- Idempotent: this whole file is comments + counter bump + schema_migrations
-- INSERT. Re-running it is a no-op.

-- Reason convention (informational, not enforced):
--   'task.confirmed'        — primary ship payout, kind-multiplied (V3.R27)
--   'ship.net_negative'     — flat +1 simplification bonus (V3.R93)
--   'idea_promotion_bonus'  — 25% slice to idea_inbox.captured_by (V3.R27)
--   'rank_change'           — promotion/demotion stipend (V3.R28)
--   'task.bonus' / etc.     — legacy/manual adjustments

-- Bump the migration counter past 041 so the next claim that includes
-- 'migrations/' allocates 042.
UPDATE migration_counter SET next_number = GREATEST(next_number, 42) WHERE id = 1;

INSERT INTO schema_migrations (version) VALUES ('041_kind_multipliers_and_idea_bonus')
  ON CONFLICT (version) DO NOTHING;
