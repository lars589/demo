# ADR 0051 — Full session transcripts in the BFG corpus (with transcript-grade scrubbing)

**Date:** 2026-06-13
**Context:** GDS-V4, task [#1004](https://example.com/builders#/task/1004) (full-transcript capture) with hard precondition task [#1003](https://example.com/builders#/task/1003) (transcript-grade scrubber, extends [#723](https://example.com/builders#/task/723)) and coverage task [#965](https://example.com/builders#/task/965). **Amends the privacy/size posture of [ADR 0027](<redacted>.md)** (BFG session-inefficiency evaluator) and its schema (`migrations/062_session_records.sql`). Companion to [ADR 0026](<redacted>.md) (BFG charter + §6C transparency), [ADR 0020](<redacted>.md) (security-model posture), [ADR 0028](<redacted>.md), and [ADR 0016](<redacted>.md) (read access is server-enforced, not a doc claim). Read API: tasks [#541](https://example.com/builders#/task/541)/[#627](https://example.com/builders#/task/627). Coverage history: [#551](https://example.com/builders#/task/551)/[#608](https://example.com/builders#/task/608)/[#617](https://example.com/builders#/task/617)/[#620](https://example.com/builders#/task/620).
**Status:** Proposed. Directive accepted (Lars, 2026-06-13); the **mechanism awaits review, and capture MUST NOT ship until the scrubber precondition (task 1003) is verified.**
**Track:** `internal` (dev-system / BFG).

## Problem

[ADR 0027](<redacted>.md) made a deliberate choice, stated in `migrations/062_session_records.sql`:

> *"the heavy transcript CONTENT is never uploaded. Each row holds per-turn METADATA (role, tool name, error flag, token usage, content length) + short secret-scrubbed snippets + token aggregates. That keeps rows small (KB, not MB) and the secret surface minimal."*

That was the right call for an *efficiency metrics* evaluator. But it has a cost that surfaced concretely on 2026-06-13 while investigating why builder `IAMMASTERQUA` (id 25, Thetes) could not use the sandbox: pulling their 8 sessions from the corpus, the **assistant turns came back near-empty**. The corpus can compute ceremony-vs-work ratios and tool-error counts, but **neither the BFG nor an Archon can read what actually happened** — what the builder asked, what guidance they were given, where they hit a dead-end. The digest measures sessions; it cannot be *read*.

Lars's directive (2026-06-13): **the BFG must hold the full transcript of every session, readable — with secrets still scrubbed (non-negotiable).**

## Decision

**Store the full, secret-scrubbed transcript of every session in the corpus, and reaffirm that read access is Archon/BFG-only + audited.** Four parts:

### 1. Full per-turn content (replaces the thin snippet model)
Capture the complete per-turn transcript — user prompts, assistant text, tool calls **and** their results — instead of length-bounded snippets. Stored as scrubbed text on each turn in `session_records` (new `transcript jsonb` column, or a widened `detail`; migration **085** reserved on claim 762). The per-turn *metadata* and `metrics` aggregates ADR 0027 relies on are kept — the evaluator logic is unchanged; only the stored fidelity grows.

### 2. Every session, no silent gaps
Coverage is already most of the way there: the `SessionEnd` hook (`scripts/gds/session-digest.js`) fires once per session end (not just on ship) and upserts **one record per `session_id`**, and `ship.js` covers the mid-session tail. This ADR keeps that invariant and pairs it with the coverage-reconciliation work (task 965) + the durable skip-logging (task 617) so a session that fails to upload is *visible*, never silently absent.

### 3. Hard precondition — transcript-grade scrubbing (task 1003)
Because the heavy content now leaves the box, the scrubber becomes load-bearing. Extend the secret-scrub in `scripts/gds/ship.js` + `scripts/gds/session-digest.js` (completing the still-open token-redaction task 723) to aggressively redact: API keys, GDS / Anthropic / Apple tokens, the contents of `~/.config/otb/gds-session.json` and `env`, `Authorization` headers, private keys, and high-entropy strings. **Scrubbing runs on the builder's box, before anything is uploaded.** A planted-secret test corpus must be caught in full before capture ships. **This task gates task 1004.**

### 4. Access + retention posture (reaffirmed and bounded)
- **Read access unchanged and reaffirmed:** full transcripts are sensitive. A builder may read their **own** sessions; any cross-builder read stays **Archon / BFG-principal only and fail-closed audited** (`/sessions/:id`, `/sessions/search` — the audit row is written *before* the query runs). This is server-enforced (ADR 0016), not a doc promise.
- **Retention — keep forever** (Lars, 2026-06-13: *"keep forever; we will optimize storage costs in the future"*). Full content is retained indefinitely in the central corpus; rows grow from KB to MB and the nightly `pg_dump` (task [#412](https://example.com/builders#/task/412)) grows with them. Storage-cost optimization (compression, cold-tiering, or off-DB object storage) is an explicit **future** concern, filed for later — not designed in now.
- **Server-side system of record, never on the boxes** (Lars, 2026-06-13: *"keep these on our server not on every dev box"*). The authoritative corpus is `session_records` in the central Postgres on the droplet. Dev boxes do **not** store, accumulate, or sync transcripts — a box scrubs its session at source and uploads it, holding only Claude Code's own transient local `.jsonl` (which we neither persist nor replicate across boxes). The home of record is single, and the standing secret surface on any individual box stays minimal.
- **Transparency:** builders should know their full sessions are retained server-side for BFG. Surface it in the primer / per ADR 0026 §6C's transparent-correction posture.

## The security trade-off (stated plainly)

This **reverses ADR 0027's central safety margin** ("content never uploaded"). The replacement safety model is three-layered: content is (a) **aggressively scrubbed at the source** before it leaves the box, (b) **access-gated** to Archon/BFG + audited, and (c) **centralized on the server**, never spread across dev boxes. Note this model deliberately does *not* lean on retention bounding — Lars chose to keep transcripts forever — so (a) the source scrub and (b) the access gate carry the full weight. The residual risk is real and acknowledged: a scrubber miss now leaks actual content rather than a short snippet, and it leaks it permanently — which is exactly why task 1003 (scrubber + planted-secret test) is sequenced **first** and is a hard gate on task 1004. The forever-corpus also becomes a higher-value target; the existing nightly backup and any future restore drill inherit that sensitivity.

## Consequences

- **Pros:** the BFG (and an Archon) can finally *read* sessions — root-causing builder friction like the IAMMASTERQUA sandbox dead-end becomes possible; "honest measurement" (a GDS-V4 goal) gets the raw material it was missing.
- **Cons / risks:** an ever-growing DB + backups (forever retention); a bigger, *permanent* secret-exposure surface if scrubbing regresses; full records of builders' work stored centrally (mitigated by scrub-at-source, audited gating, server-side centralization, and transparency — but explicitly **not** by retention limits).
- **Supersedes** the ADR 0027 / migration 062 *storage* note only. ADR 0027's evaluator design and read-gating posture stand.

## Alternatives considered

- **Fuller snippets, not full transcripts** — smaller blast radius, but does not satisfy the directive (assistant reasoning/answers still truncated).
- **Full transcripts, unscrubbed** — rejected outright: violates the non-negotiable secret constraint and our security posture.
- **Store transcripts off-DB (object storage), pointer in the row** — keeps rows small and isolates the blast radius; deferred as a future option since it would fork the existing one-record-per-session read API. Revisit if DB size becomes the binding constraint.

## Decisions recorded (Lars, 2026-06-13)

- **Retention: keep forever.** Full transcript content is never aged out; storage-cost optimization is deferred to a future task, not built now.
- **Storage location: central server only.** The corpus lives in the droplet's Postgres (`session_records`); dev boxes never accumulate or sync transcripts (see Decision §4).
- **Consequence for sequencing:** with no retention bound to limit exposure, the source-scrub (task 1003) and the audited access gate are the *only* safety layers. Task 1003 is therefore a hard, non-skippable precondition for task 1004, and its planted-secret test must pass before any capture code ships.
