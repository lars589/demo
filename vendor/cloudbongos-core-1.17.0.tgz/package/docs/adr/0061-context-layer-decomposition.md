# ADR 0061 — Context-layer decomposition: a CLAUDE.md content charter + nested per-module docs

- **Status:** Accepted
- **Date:** 2026-06-18
- **Track:** internal
- **Builds on:** [ADR 0016](<redacted>.md) (markdown only describes; the server/DB enforce — so trimming CLAUDE.md can never weaken authority), [ADR 0060](0060-gds-retrieval-layer.md) (the `/recall` retrieval half of "find what we know"; this ADR is the *instruction/navigation* half), [ADR 0024](<redacted>.md) (the Architect, which drives the deeper Path C module refactor)
- **Task:** 1222 (GDS-V4) — Path A of the 2026-06-18 "context cliff" research.

## Context

This project is almost entirely AI-authored. The owner's worry is concrete: as agents keep adding code and docs, the repo gets harder to scan and an agent's ability to change it safely degrades — a **context cliff**. The literature backs this up:

- **Length alone degrades reliability** — Chroma's *Context Rot* (2025, 18 models): accuracy falls as input grows, even on trivial tasks.
- **Position matters** — *Lost in the Middle* (TACL 2024): a fact buried mid-context is recalled far worse than at the edges.
- **Related-but-wrong content misleads** — a single near-miss distractor measurably lowers answers, and a large repo is a distractor factory.
- **Effective ≪ advertised** — NVIDIA's RULER (2024): usable context is roughly half the advertised window.

CLAUDE.md is the most-loaded artifact we have: Claude Code reads the root **in full, every session, regardless of length**. Anthropic's own guidance is **under ~200 lines**, with the rule *"a bloated CLAUDE.md causes Claude to ignore your actual instructions."* Ours was **351 lines** and mixed three kinds of content — durable framing, live state, and operational rules — so it over-spent the always-on budget *and* drifted (live-state prose goes stale between the DB and the file).

Cursor addresses the same problem by splitting one rules file into many small, **scoped, lazily-loaded** `.cursor/rules` files (loaded only when a matching file is in context). Claude Code has the native equivalent — **nested `CLAUDE.md` files load on demand** when an agent reads a file in that directory — and we were not using it: one root file, zero nested ones.

> On the owner's worry that "CLAUDE.md is deeply ingrained into making everything work": per [ADR 0016](<redacted>.md) it is **descriptive, not authoritative** — the server/DB enforce permissions and the ship pipeline, and editing the file grants no authority. So the risk is *not* that a wrong CLAUDE.md breaks enforcement. The risk is narrower and real: it over-spends the always-loaded context budget, and its live-state prose drifts. This ADR fixes that risk without touching enforcement.

## Decision

### 1. A content charter, stated at the top of CLAUDE.md

A short "Working with this file" section codifies what belongs in the root, with three rules:

- **The per-line test** (Anthropic's): *"Would removing this line cause an agent to make a mistake? If not, cut it."*
- **The decoder — what goes where:** durable framing + pointers + invariants → this file; live state (tasks/versions/ranks/costs) → the GDS DB; *why* a non-obvious choice was made → an ADR; multi-page how-to → a recipe; specifics of one module → that dir's nested `CLAUDE.md`; short per-rule learnings → the `learnings` table.
- **A size budget:** the root targets **≤ ~200 lines** (hard ceiling ~250). When it crosses, relocate detail *down the decoder* — don't append.

This is the "best practices for what goes in CLAUDE.md" the owner asked for, kept short so it doesn't itself bloat the file; the full rationale is this ADR.

### 2. Nested per-module `CLAUDE.md` (load on demand)

Thin `CLAUDE.md` files in the highest-traffic directories, loaded by Claude Code only when an agent works there. First set: `src/bongos/`, `src/bongos/routes/`, `scripts/gds/` (the GDS core + CLI, where the monoliths live — `db.js` ~219 KB, `ship.js` ~151 KB, `tasks.js` ~79 KB). Each follows a fixed template:

- **Purpose** — one paragraph: what this directory is for.
- **Key files / public surface** — the handful of entry points and what each does (the "function block" view — read this, dive into the implementation only as needed).
- **Gotchas / invariants** — the non-obvious rules that prevent mistakes here.
- **See also** — the relevant ADRs / recipes.

`CLAUDE.md` (not `README.md`) is deliberate: only `CLAUDE.md` is auto-loaded for the agent; READMEs serve humans. Where a dir already has a README (e.g. `art/`, `migrations/`), the nested `CLAUDE.md` stays a thin pointer + agent-only gotchas.

### 3. Hard invariants live in code, not prose

Anything that must never be skipped is a hook or CI check, not a CLAUDE.md sentence — prose is advisory, gates are deterministic. This is already largely true (`stop-refcheck.js`, `route-rank-check`, the grader pre-pass, `linkify-refs.js`). The charter makes the principle explicit so future rules land in the right layer.

### 4. Freshness is the seam to Path B

Hand-written nested docs will drift exactly like the owner fears. The **factual** half (the "public surface" list) is therefore a generation target for **Path B** — a tree-sitter symbol skeleton regenerated in CI the way `gen-diagrams.js` regenerates diagrams. Until then the *purpose / gotchas / see-also* halves are stable by design (matklad's ARCHITECTURE.md principle: record invariants, not line-level facts that rot).

## Consequences

- The root shrinks toward budget; per-module depth arrives only when relevant — less dilution, better instruction adherence (the documented failure mode).
- An agent (or human) gets a high-level map of each busy directory without reading every file — the "read generally, then dive in" property the owner asked for.
- **Risk:** nested docs drift until Path B generates their factual half — mitigated by keeping them thin + invariant-focused, plus a follow-up task for the generator.
- **Risk:** over-aggressive trimming could drop a load-bearing line — mitigated by *relocating* rather than deleting, and by the per-line test being conservative ("if unsure, keep").
- A future CI check can enforce the root size budget (filed as a follow-up).
