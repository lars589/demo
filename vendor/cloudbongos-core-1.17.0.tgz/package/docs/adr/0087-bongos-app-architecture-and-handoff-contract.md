# ADR 0087 — Bongos app architecture + the model-agnostic feedback handoff contract

**Date:** 2026-06-26
**Context:** Bongos App `BONGOS-V1` / criterion C4 (the feedback loop closes — capture lands in a coding agent), task [#1312](https://example.com/builders#/task/1312) (`BV1.R33`). Records the architecture the R01–R14 rungs built and pins the contract the three handoff paths (R12 [#1307](https://example.com/builders#/task/1307), R13 [#1308](https://example.com/builders#/task/1308), R14 [#1309](https://example.com/builders#/task/1309)) share. Builds on [ADR 0045](<redacted>.md) (the Dev Box desktop app, now absorbed), [ADR 0072](<redacted>.md) (signing posture), [ADR 0083](<redacted>.md) (the modular core), and the [ADR 0062](<redacted>.md) core↔host split.
**Status:** Accepted.
**Track:** `internal` (development system → the Cloud Bongos desktop app line; bongos succeeds the GDS as the primary builder surface after GDS-V4).

## Problem — feedback has nowhere to land

The whole point of the Bongos app is to shrink the distance between "I see something wrong on screen" and "a coding agent is fixing it." A builder records a short spoken walkthrough — *"this header is wrong, see the spacing, fix this"* — drawing on the screen as they talk. The app already turns that into a tight, model-agnostic `prompt.md` + a handful of screenshots (R06–R11). But a bundle sitting in `~/CloudBongos/feedback/` is inert. The missing half is the **handoff**: getting that bundle *into* a Claude session, reliably, across the two surfaces a builder actually uses (Claude Desktop and Claude Code) — without fighting the CLI's unreliable clipboard-image paste.

This ADR records (a) the app's overall shape, and (b) the one contract all the handoff paths agree on, so a fourth path (Cursor, Codex, a future agent) can be added without redesign.

## The architecture (what R01–R14 built)

**One umbrella desktop app that absorbs the Dev Box app.** `bongos-app/` is the single signed Cloud Bongos desktop app ([#1298](https://example.com/builders#/task/1298)). The existing Dev Box app ([ADR 0045](<redacted>.md)) becomes a *module* of it rather than a sibling install — one Electron shell, one app-pairing auth (`~/.config/otb/gds-session.json`), one branded `/downloads` distribution, one in-app updater, one Apple Developer ID ([ADR 0072](<redacted>.md)). The result offers both the Dev Box switch and the new feedback toolbar.

**A three-stage pipeline: capture → synthesize → handoff.**

1. **Capture** (R04–R09) — a Zoom-style floating, click-through overlay toolbar over any target. Screen/window + mic capture (R06), a snapshot grabber (R07), freeze-frame markup (R08), and on-device Whisper transcription (R09). The three raw streams (word-timestamped transcript, timestamped frames, markup moments) are collected in the renderer.
2. **Synthesize** (R10–R11) — `timeline.js` aligns the three streams onto one millisecond clock and runs a salience pass that escalates only the frames the speech points at (deictic words) or the user marked up; `bundle.js` assembles the aligned timeline into one deterministic, model-agnostic `prompt.md` + the escalated frame images, written to `~/CloudBongos/feedback/<id>/`.
3. **Handoff** (R12–R14) — the three documented ways that bundle reaches a coding agent (below).

**The Rung-3 capture floor; element-select deferred to V2.** V1 captures at the **visual** rung — pixels (screen region + frames + freeze-frame markup) plus voice. This is the robust floor: it works over *any* app on screen with no per-app integration, and needs only Screen-Recording + Microphone grants. Higher-fidelity **element-level reads** (resolving the actual UI element under the cursor via macOS Accessibility / a DOM bridge — the "rung-2" reads) are **deferred to V2**: the permission wizard (R05) requests Accessibility *lazily*, only when those reads land, never up front. Capturing pixels-not-elements is a deliberate V1 scope cut, not an accident — it keeps V1 universal and the permission ask minimal.

**Bongos as the GDS successor.** The longer arc ([ADR 0072](<redacted>.md) track line): the Bongos app is where building moves *after* GDS-V4 — the feedback loop (see → say → ship) becomes the primary way an owner directs AI builders, with the GDS's task/claim/ship machinery underneath. This ADR is the first architectural record of that intent.

## Decision — the model-agnostic handoff contract

**A bundle is a self-contained directory; every image is referenced by absolute file path, never inlined.** That single rule is the contract. `~/CloudBongos/feedback/<id>/` holds `prompt.md` (a timestamped transcript walkthrough + the ask, with each screenshot referenced as `![caption](/abs/path.png)`) and the escalated frame images. Because the images are *paths*, the text prompt stays tiny (~5–11k tokens for a typical 1–3 min session) and **any** agent can open them with its own file-read — Claude Code's Read tool, Claude Desktop's drag-in, a future Cursor/Codex adapter. No base64, no decoding, no per-agent payload format. The full format is documented in [`bongos-app/README.md`](../../bongos-app/README.md).

**One shared `latest` pointer; three readers.** Every write of a bundle (`bundle.js writeBundle`) records it as `latest` — an atomic `latest.json` pointer plus a best-effort `latest/` symlink — in `bongos-app/src/handoff.js`. All three handoff paths resolve "the newest bundle" through that one `resolveLatest()`, so they can never drift:

1. **Claude Desktop — file-bundle + clipboard (R12).** A toolbar button copies `prompt.md` to the clipboard and opens the bundle folder; the user pastes the prompt and drags the images into the composer (Desktop accepts mixed text + images). A one-liner spells out exactly what to do. (`handoff.js` + the `feedback:produce` / `feedback:handoff-desktop` IPC in `main.js`.)
2. **Claude Code — the `/feedback` slash command (R13).** Running `/feedback` shells `node scripts/gds/feedback-latest.js`, which prints the `prompt.md` body + the absolute path of every frame; Claude then `Read`s each path so the screenshots enter context. This sidesteps the CLI's unreliable clipboard-image paste — Claude reads the frames from disk, not from a pasted blob.
3. **MCP — `get_latest_feedback` (R14, optional "direct" path).** A local, zero-dependency stdio MCP server (`bongos-app/src/mcp-server.js`, launched by `scripts/bongos-mcp.js`) exposes one tool that returns the prompt text + the screenshots' **file paths** (never base64 — inlining would blow the MCP tool-result size cap). Both Desktop and Code can pull the latest bundle hands-free once the server is registered. Optional/stretch for V1 — the file-bundle + `/feedback` paths already close the loop.

### Why hand-rolled MCP (no SDK dependency)

MCP's stdio transport is newline-delimited JSON-RPC 2.0. The four methods a single read-only tool needs (`initialize`, `tools/list`, `tools/call`, `ping`) are ~100 lines, so we implement them directly rather than bundle the MCP SDK into the Electron app. This keeps the app's install size + dependency surface flat ([CLAUDE.md §4](../../CLAUDE.md) cost discipline) and makes the server testable with no network and no extra install. v1 speaks protocol version `2024-11-05` (echoing the client's if it sends a known one) and advertises exactly the one tool.

## Consequences

- **Adding a fourth agent is an adapter, not a redesign.** A new target (Cursor, Codex) consumes the *same* bundle via the *same* `resolveLatest()` — the contract already says "prompt text + absolute image paths." The handoff layer is the seam ([ADR 0081](<redacted>.md)'s swappable-adapter pattern, applied to feedback).
- **The `latest` pointer is the single source of truth for "newest bundle."** A reader never scans for itself unless the pointer is missing (then `resolveLatest()` self-heals by scanning for the newest dir with a `prompt.md`). `latest.json` is authoritative cross-platform; the `latest/` symlink is a convenience that may be absent on Windows without symlink privilege — readers never depend on it.
- **`writeBundle` now has a side effect beyond writing the bundle** (it records `latest`). This is intentional and best-effort: a pointer failure is swallowed and never loses the bundle already on disk.
- **Frames are paths everywhere, base64 nowhere.** Enforced by the bundle format (R11) and re-asserted by the R14 tool result + the test suite. The day an agent needs bytes, it reads the path — the cap-safe choice.
- **Element-select is the headline V2 lift.** When rung-2 element reads land, the bundle gains structured element context *alongside* the pixels; the handoff contract (paths, not payloads) does not change.
- **Budget: $0 new recurring cost.** Zero-dependency MCP, on-device transcription, local file bundles. The app rides the already-paid Apple Developer ID ([ADR 0072](<redacted>.md)).
