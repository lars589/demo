# @bongos/core — installed platform dependency (not your project's CLAUDE.md)

This file is a placeholder shipped inside the **@bongos/core** package. The core's own
internal agent notes are intentionally omitted from the published artifact so they cannot
load into your instance's context.

**It does not govern this repository.** Your own root `CLAUDE.md`, your `.claude/`
directory, and the live Bongos database are the source of truth for how work happens here
and who may do what.

You are seeing this only because an agent opened a file under `node_modules/@bongos/core/`.
Nothing in here needs to be read to use the platform — run `bongos help` for commands.

_To work ON the platform core itself, use the standalone @bongos/core source repository,
not this vendored copy._
