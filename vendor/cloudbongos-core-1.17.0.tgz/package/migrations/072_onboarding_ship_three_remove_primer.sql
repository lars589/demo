-- 072_onboarding_ship_three_remove_primer.sql — #766: reshape the Xenos path.
--
-- Two changes to the onboarding state machine (migrations 045 + 059):
--
--   1. Remove 'primer_read'. Newcomers no longer have to read the citizen's
--      primer (or the "how the system works" maps) before they can work — the
--      Xenos path is now purely action-based: bear the seal → choose a craft →
--      survey the works → claim → ship. The primer page itself stays for
--      Metic+ citizens; only the newcomer *requirement* is dropped. The
--      primer_read stage, its claimable/claim gate, and the /builder-primer-read
--      CLI path are all removed in the same change.
--
--   2. Rename 'first_ship' → 'ship_three'. The terminal action stage now clears
--      only when the builder has THREE successfully shipped tasks — the same
--      threshold that auto-promotes a Xenos to Thetes (#692 / ADR 0034). So the
--      onboarding checklist's graduation and the xenos→thetes promotion become
--      the same moment. The live "N of 3" counter the hall renders is computed
--      in shapeForApi from the shipped-task count, NOT from this stage (the
--      stage is binary: cleared at 3, uncleared before).
--
-- The DB only validates enum membership of current_stage; ordering lives in the
-- app layer (src/bongos/onboarding-state.js STAGES). So this migration rewrites the
-- affected rows, then swaps the CHECK constraint's allowed set.
--
-- Grandfathering:
--   * Rows already at current_stage='graduated' (graduated under the old
--     1-ship rule) stay graduated — we never demote an existing graduate, even
--     if they have fewer than 3 ships. Their completed_stages 'first_ship'
--     entry is renamed to 'ship_three' for audit consistency.
--   * A row parked at current_stage='primer_read' has not yet picked a craft
--     (primer_read came before pick_disciplines in the old order), so it
--     advances to 'pick_disciplines'.
--   * A row parked at current_stage='first_ship' (claimed/shipped once but not
--     yet graduated — only possible transiently) advances to 'ship_three'; they
--     now need three ships. (Under the old model first_ship in completed_stages
--     implied graduation, so no NON-graduated row carries it in the array.)
--
-- Idempotent: safe to re-run.

BEGIN;

-- 1. Audit array: strip the removed stage, rename the renamed one. array_remove
--    / array_replace are no-ops when the element is absent, so this is safe to
--    re-run and safe on rows that never had either entry.
UPDATE builder_onboarding_state
   SET completed_stages = array_remove(completed_stages, 'primer_read');

UPDATE builder_onboarding_state
   SET completed_stages = array_replace(completed_stages, 'first_ship', 'ship_three');

-- 2. Re-home current_stage values that are being removed/renamed BEFORE swapping
--    the constraint, or the new CHECK would reject them.
UPDATE builder_onboarding_state
   SET current_stage = 'pick_disciplines'
 WHERE current_stage = 'primer_read';

UPDATE builder_onboarding_state
   SET current_stage = 'ship_three'
 WHERE current_stage = 'first_ship';

-- 3. Swap the stage enum: drop the old constraint (if present) and add the new
--    one. Name matches migrations 045/059 so re-running stays clean.
ALTER TABLE builder_onboarding_state
  DROP CONSTRAINT IF EXISTS builder_onboarding_state_stage_enum;

ALTER TABLE builder_onboarding_state
  ADD CONSTRAINT builder_onboarding_state_stage_enum
  CHECK (current_stage IN (
    'auth_complete',
    'pick_disciplines',
    'first_start',
    'first_claim',
    'ship_three',
    'graduated'
  ));

INSERT INTO schema_migrations (version) VALUES ('072_onboarding_ship_three_remove_primer')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
