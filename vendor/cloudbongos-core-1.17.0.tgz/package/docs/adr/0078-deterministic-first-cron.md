# ADR 0078 — Deterministic-first cron harness

**Status:** Accepted (2026-06-20) · tasks [#1355](https://example.com/builders#/task/1355) [#1356](https://example.com/builders#/task/1356) [#1357](https://example.com/builders#/task/1357) · System 4 of the Cloud Bongos LLM-reduction redesign (spike [#1326](https://example.com/builders#/task/1326)) · cost visibility via [ADR 0075](<redacted>.md)

## Context

Several of the ~17 scheduled routines are an **Opus session wrapping a single committed deterministic script**. `peer-vote-tally` literally instructs the model "do NOT compute anything by hand — run `tally.js`"; `diagram-drift` runs `check.js --file-idea`; `dep-audit-nightly` and `main-audit` run a scan script. Booting a model, loading CLAUDE.md, and paying per-turn `cache_read` just to shell one `node` command is pure waste — the model adds nothing a cron line couldn't do. (Est 3–6% of total token spend.)

## Decision

A routine **declares its run mode** in SKILL.md frontmatter, and a dispatcher runs it at the cheapest sufficient tier — for deterministic routines, **no model is launched at all**.

- **`scripts/gds/run-routine.js <name>`** (task 1355) reads `mode:` + a `steps:` list (`command` + `sink: discord|gds|none`) from the routine's SKILL.md frontmatter:
  - **`deterministic`** — `execFileSync` each step as plain node; route stdout by sink; non-zero exit → best-effort `#ops` alert + non-zero exit. **This is the whole execution — no `claude -p`.**
  - **`hybrid`** — run the deterministic prefix as code; spawn `claude -p` *only* when a step emits a non-empty `{"needs_judgment": …}` payload, feeding the model only that payload.
  - **`judgment`** — the status quo: a wrapped session over the SKILL body.
  - Steps run with `OTB_COST_CRON_ROUTINE=<name>` so System 1 ([ADR 0075](<redacted>.md)) tags any (hybrid) spend `cron:<routine>:*` — making "did demoting this to deterministic actually cost ~$0?" a queryable fact.
- **Convert only the provably-deterministic wrappers (task 1356).** `peer-vote-tally` and `diagram-drift` already do their whole job in one self-contained, self-filing script — converted to `mode: deterministic`. **`main-audit` and `dep-audit-nightly` were NOT converted:** `main-audit.js` is trust-boundary core (SEC [#863](https://example.com/builders#/task/863) / [ADR 0043](<redacted>.md)) and neither script self-files its findings (the model currently does the per-finding `idea_inbox` / `vulnerability_report` filing), so demoting them blindly would silently drop alerting. They need a self-filing flag added to their (security) scripts first — a separate, security-reviewed task.
- **A fitness check stops the boundary from rotting (task 1357).** `fitness.checkDeterministicRoutines` fails CI if a `mode: deterministic` SKILL body contains a judgment/mutation instruction (`git push`/`commit`, `deploy.sh`, an `Edit`/`Write` tool instruction, free-text synthesis) — *negated* mentions ("never pushes", "does NOT edit") are allowed as descriptive boundaries — or if a fenced `node …` command diverges from the declared `steps:`. The pure core (`scanDeterministicBody`) is unit-tested both ways (clean passes, each violation class is caught). This is the structural cure for the markdown-graveyard pattern: a deterministic routine can never quietly become a wrapped session again.

## Consequences

- Two nightly/weekly Opus sessions become zero-model cron lines; the pattern is now declared, enforced, and ready for more routines to adopt as their scripts gain self-sufficiency.
- **Operator action required (not in-repo):** the cron entries for `peer-vote-tally` + `diagram-drift` must be repointed from `claude -p <skill>` to `node scripts/gds/run-routine.js <name>`. The schedules live in the operator/MCP layer (`~/.claude/scheduled-tasks/` is symlinked to the repo), so the repo holds the SKILL definitions but not the launch command.
- The fitness check means the SKILL *body* of a deterministic routine is now documentation only — it must describe, not instruct. Remediation steps move to a separate claimed task (the routine *detects*; a human *fixes*).
- Composes with the rest of the redesign: System 3 (autonomy gate) decides whether a *judgment* routine fires; this decides a *deterministic* routine needs no model at all; System 5 (cache) catches a same-model-run-twice.

## Reproduce / verify

- Pure tests (DB-free): `tests/run_routine.mjs` (frontmatter parser + tokenizer), `tests/fitness.mjs` (the deterministic-boundary check, clean + catches).
- `node scripts/gds/run-routine.js peer-vote-tally --dry-run` → prints the one command it would run, no model.
- Post-deploy: System 1's `by_source` shows `cron:peer-vote-tally:*` / `cron:diagram-drift:*` at ~$0.

## Amendment (2026-06-21) — server-internal-timer realization for server-call routines

**Status:** Accepted · task [#1382](https://example.com/builders#/task/1382) · supersedes the "operator wires cron" consequence above for `peer-vote-tally`.

**What we found.** The original decision built an external dispatcher (`scripts/gds/run-routine.js`) and left the *scheduling* to the operator/MCP layer. Nothing was ever durably scheduled — **every scheduler layer was empty** (the local app tasks, the in-session cron, and the claude.ai cloud routines all returned nothing; the "overnight build" was a manually-pasted brief). So both routines' realized run count was **zero**, and a deterministic routine that never fires saves no tokens because it does no work. (Confirmed in the System 4 effectiveness eval, task [#1371](https://example.com/builders#/task/1371).)

**What changed.** `peer-vote-tally`'s real work is server-side and needs no model, so the durable realization is an **in-process timer** inside the always-on Node process — the same pattern as `src/bongos/publish-reconciler.js` and `src/bongos/uptime-poller.js`. `src/bongos/routine-timers.js` runs **peer-vote-tally weekly**, calling `db.tallyPeerVotes()` directly (the exact transaction the Archon-gated `POST /tasks/peer-votes/tally` route runs, now extracted to `db.js` so route + timer share one path). The route's Archon gate is an HTTP-auth concern; an in-process call has no requester and the SQL writes `karma_log` with `granted_by = NULL`. Idempotent (only matured, untallied votes) and protected by a `FOR UPDATE OF pv` row lock — the real multi-instance guard.

The timer is **unref'd**, **best-effort** (a throw logs `[routine-timers]` and waits for the next tick — never crashes the game/API), kill-switched by `ROUTINE_TIMERS_DISABLED=1`, and a **no-op anywhere the DB is unreachable** (builder laptops/boxes), so it is safe to start unconditionally on the game boot. Started/stopped in `server.js` beside `publishReconciler` — and **only** in `server.js` (the game/droplet entrypoint), not `src/platform-server.js`, so a future second always-on instance can't double-run; if one ever shares the `example` DB, set `ROUTINE_TIMERS_DISABLED=1` on the secondary.

**`diagram-drift` was intentionally NOT made a timer.** All five onboarding diagrams already auto-regenerate from live facts on every deploy (`gen-diagrams.js`), so a daily drift check is near-redundant, and an in-process loopback read would add a needless request surface. The manual `node scripts/gds/run-routine.js diagram-drift` remains for on-demand use.

**What we KEPT.** `run-routine.js`, the SKILLs' `mode: deterministic` declarations, `tally.js`, `check.js`, and the `checkDeterministicRoutines` fitness guard are all unchanged. `run-routine.js` remains the manual/on-demand front door (and keeps `tests/run_routine.mjs` meaningful); the timer is the always-on front door. Both reach the same deterministic work. The amendment is documented HERE and in `docs/recipes/ops-gotchas.md`, **never** in a deterministic SKILL body (a stray `node …` line there would fail the prose↔steps divergence check).

**Operator action retired.** The original "repoint the cron entries from `claude -p` to `node run-routine.js`" step is no longer required for `peer-vote-tally` — the server schedules it itself.
