# ADR 0058 — Automatic gate-surface gatekeeper (rank-based auto-approval + deterministic hard floor)

- **Status:** Accepted
- **Date:** 2026-06-15
- **Track:** internal
- **Builds on:** [ADR 0042](<redacted>.md) (CI self-deploy), [ADR 0043](<redacted>.md) (protected paths + rank floor), [ADR 0016](<redacted>.md) (trust boundary), [ADR 0055](<redacted>.md) (server-mediated publish), [ADR 0057](<redacted>.md) (Archon approval channels)
- **Task:** 1139

## Context

In deploy mode `ci` ([ADR 0042](<redacted>.md)) PRs auto-merge on green required checks and `main` auto-deploys to prod. `CODEOWNERS` (owner review on gate surfaces, enforced by `require_code_owner_reviews`) was the **only** human in that loop — it stops a builder from weakening the gate from inside their own auto-merging PR (disabling a check, muting a test, lowering a rank requirement, sneaking a malicious migration).

That review made the owner a bottleneck: **every** PR touching a gate surface (the ~36 `PROTECTED_GLOBS` in [`src/bongos/permission-path-check.js`](../../src/bongos/permission-path-check.js)) blocked on a manual approval — and nothing surfaced those pending PRs, so server-mediated-publish PRs ([ADR 0055](<redacted>.md)) stranded silently (the 2026-06-15 retro: tasks 1068/1096/602/476 sat `confirmed` for days, blocked on an approval the owner never saw).

A red-team design pass established one hard truth: a **deterministic** analyzer can only *safely* certify a tiny set of changes as benign (un-muting a test, narrowing the secret allowlist, and PRs touching no gate surface). New migrations, dependency bumps, and auth/route changes are **undecidable** by rules — and an LLM reviewer is rejected as authoritative because the project's own history (grader prompt-injection fencing, task 995) proves it is trickable.

## Decision

A **rank-based** gatekeeper (owner directive, 2026-06-15: "I don't want to review anything manually"), implemented as a deterministic CI check with three verdicts over the PR **diff-as-data**:

- **PASS** — no gate surface, or only **AUTO** pure-removal surfaces (`run-unit-tests.js` removing a test-mute; `.husky/secrets-allowlist.txt` removing a line). Auto-merge. This already clears the *common* PR (game/art/docs/non-gate `src/`).
- **NEEDS_TRUST** — a sensitive-but-routine gate surface (migrations, deps, routes, `server.js`, ship plumbing, boxes, doctrine docs, a `db.js` change outside the rank-tier region, a deleted/shrunk test). Auto-merges **iff the author is Metic+** (rank trust, server-resolved) **or the owner approved**; otherwise escalates.
- **ESCALATE — the HARD FLOOR (rank-independent)** — the gate's own machinery + deploy switch: `gate-review.js` itself, `.github/`, `CODEOWNERS`, `config/deploy.json`, `infra/` (branch-protection-as-code), `auth.js`, `route-rank-check.js`, `permission-path-check.js`, the grader, `main-audit.js`, `run-unit-tests.js` (non-narrowing), the hooks, and `db.js`'s `REQUIRES_RANK_TIER` (content rule). **No rank bypasses this** — it always pings the owner. Pre-flight rejections (symlink, non-ASCII/whitespace path, oversize diff, analyzer error) also ESCALATE, fail-closed.

The hard floor is the irreducible root of trust: a compromised or prompt-injected senior session **cannot** auto-merge a change that disables the gatekeeper, the deploy-time audit, branch protection, or the rank brain. The owner explicitly accepted the residual risk that a hijacked senior session could auto-merge a *non-floor* sensitive change — bounded by (a) this floor, (b) the existing autonomous-path protected-path exclusion (task 994), and (c) the deploy-time `main-audit.js --verify-head` backstop.

### Why these specifics (red-team-closed)

- **Gate-surface set = imported `PROTECTED_GLOBS`, never a hand-typed list** (red-team finding `#1`: a hand-typed shrink dropped `db.js`/`routes.js`/`server.js` and was *less* safe than today). A drift test asserts no protected glob is ever classified PASS.
- **Two-layer enforcement**: the in-CI `gate-review` check is the fast cooperative gate; `main-audit.js --verify-head` on the droplet is the authoritative net (asserts the merged SHA carries a `success` gate-review conclusion — closes the workflow-self-neuter, raw-push, and cancelled-check races).
- **Trusted-base overlay**: the workflow overlays the whole `scripts/` + `src/` from `origin/main` before running, so a PR cannot edit the analyzer to pass itself.
- **`run-unit-tests.js`, `config/deploy.json`, `CODEOWNERS`, `scripts/deploy/`, `gate-review.js`, `grader-rubric.json` added to `PROTECTED_GLOBS`** — these gate-machinery paths were previously unprotected at the sub-Metic floor; adding them closes that pre-existing gap and makes the hard floor a subset of the protected set.
- **Escalation reuses [ADR 0057](<redacted>.md)**: a `#gate-approvals` channel + `gate-pr #<n>` marker; the owner clears it by approving the (App-authored) PR. Inert until `DISCORD_GATE_APPROVALS_WEBHOOK` is set.

## Rollout (the gate is never weaker mid-flight)

1. **Report-only** (this task): ship `gate-review.js` + `gate-review.yml` with `GATE_REPORT_ONLY=1` (always exit 0 — verdict to the run summary only). `CODEOWNERS`/branch protection unchanged → gate identical to today.
2. **Verify**: confirm the verdict against real PRs + the red-team matrix (`tests/gate_review.mjs`).
3. **Enforce**: drop `GATE_REPORT_ONLY`, add `gate-review` to required checks, add the `--verify-head` conclusion assertion, and wire the server rank-attestation (`GATE_AUTHOR_TRUSTED`) + the `#gate-approvals` ping. Then shrink `CODEOWNERS` only for the two AUTO surfaces.

## Consequences

- The owner's manual-review surface shrinks from "every PR touching ~36 protected paths" to "only changes to the gate's own machinery + deploy switch" — pinged, never silently blocked.
- A purely-deterministic gate could not deliver "review nothing" without the rank-trust layer (migrations/deps are undecidable); the rank layer is the deliberate trade the owner chose.
- The hard floor + two-layer enforcement keep the safety system itself un-auto-disablable.

## Update — enforcing, and the two server-attestation vectors (task 1142, task 1169)

The gatekeeper went **ENFORCING** (task 1142): `gate-review.yml` no longer sets `GATE_REPORT_ONLY`, and `gate-review` is a required check. The `GATE_AUTHOR_TRUSTED` signal is the `gate-author-trust` **commit status** — set only by the server (which alone holds the authenticated builder's server-resolved rank + the App/PAT credential), so CI reads it but cannot forge it. The server posts it via `githubPush.setCommitStatus` from **two** ship paths, sharing one helper (`postGateAuthorTrust` in [`src/bongos/routes/tasks.js`](../../src/bongos/routes/tasks.js)):

1. **Server-mediated publish** ([ADR 0055](<redacted>.md), dev box / `pushVia 'server'`): `POST /tasks/:id/publish-branch` attests the pushed tip after opening the PR.
2. **Laptop `ci`-land** (`pushVia 'local'` — task 1169): `ship.js` pushes the branch + opens the PR with the laptop's own `gh` credential, which **cannot** forge the attestation. So `ciLandLocal` calls `POST /tasks/:id/attest-gate` (`requireBuilder` + ownership, deliberately **no** `allowBoxScope`) right **after the push and before opening the PR** — race-free for a fresh PR, since the PR-open is what fires `gate-review` and it runs only after the status is already present. Before task 1169 the laptop path posted *nothing*, so a Metic+ author's gate-surface PR from a laptop was BLOCKED and they could not self-approve their own PR (hit live on task 1162 / PR #131).

A commit status posted on a SHA does **not** re-trigger a `pull_request`-triggered check, so a **reused** open PR that already ran `gate-review` red (on the same SHA, before the attestation existed) gets a best-effort `gh run rerun` nudge of that stale run. A freshly-opened PR needs no nudge.

## Update — owner approval from the hall (task 1179)

Clearing an ESCALATE (and a NEEDS_TRUST without a Metic+ author) required a GitHub `APPROVED` review by `example-owner` on the head SHA — i.e. the owner had to leave a GitHub/terminal review, which the non-technical owner should never have to (feedback: auth flows must be UI-first). This adds a **second owner-approval channel**, trust-equal to the GitHub review, drivable from the builders' hall:

- **The Gate** (`/builders/gate`, Archon-only page, server-gated by `requireArchonPage`) lists every open PR whose `gate-review` check is red — the LIVE check conclusion is the authoritative "awaiting approval" signal — and renders **why** by reusing the **exact** pure `classifyChanges()` the CI runs (no duplicated policy). Each held PR shows its task, author, head SHA, the verdict + per-file reasons (hard-floor flagged), changed files, and a diff link.
- **Approve** (`POST /api/gds/gate-approvals/:pr/approve`, `requireBuilder` + `requireRank('archon')`) sets a **`gate-owner-approved`** commit status on the head SHA via `githubPush.setGateOwnerApproved` — set **exactly like** `gate-author-trust`: only the server holds the credential, and it sets it only after re-checking the caller's Archon rank server-side ([ADR 0016](<redacted>.md)). A PR author cannot forge it. `gate-review.yml`'s trust step now resolves `OWNER_APPROVED=1` from **either** a `example-owner` GitHub review **or** this status. Both are read on the head SHA, so a later commit's head carries no approval (the same red-team `#2b` sha-pin protection).
- **Re-trigger without a new App permission.** A commit status does not re-fire a `pull_request` check, and the publish App is not granted `actions:write`. So Approve **closes+reopens** the PR (`recheckPullRequest`, using the `pull_requests:write` the App already holds), which fires `pull_request: reopened` → `gate-review` re-runs with the real PR context, reads the new status on the correct head SHA, and goes green; auto-merge is re-armed and the publish reconciler `mergeIfGreen` sweep (task 1162) is the backstop.

The approve route **clears the hard floor**, so `POST /gate-approvals/:pr/approve` is pinned `archon` in `route-rank-check.EXPECTED_RANKS` (a silent downgrade would let any builder clear an ESCALATE). Because `gate-review.yml` is itself a hard-floor surface, the PR that introduces this change ESCALATEs and must be owner-approved to land — the bootstrapping case, shipped via `OTB_PUSH_VIA_SERVER=1` so the App authors the PR and the owner can approve it. Coverage: `tests/gate_approvals.mjs`. Authority is unchanged in substance — only `rank='archon'` (server-checked) can clear the gate, as before; this just adds a browser surface to do it.
