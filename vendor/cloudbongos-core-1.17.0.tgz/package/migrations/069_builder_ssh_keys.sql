-- 069_builder_ssh_keys.sql — #685 (ADR 0031 §1/§6): server-side SSH-key distribution.
-- (Renumbered 068→069 at ship time: main had meanwhile merged 068_thetes_requires_rank.)
--
-- Context
-- -------
-- Today, connecting a builder's Claude Desktop to their dev box requires the
-- operator to SSH into the box and hand-append the builder's public key to
-- ~/.ssh/authorized_keys — a manual round-trip across two machines (the builder
-- ssh-keygens, pastes the public half back, the operator installs it). #685
-- removes that round-trip: the builder registers their OWN public key with the
-- GDS (POST /box/ssh-key), and the box PULLS its authorized_keys from the GDS at
-- boot + on a cron (GET /box/authorized-keys), exactly like it already pulls
-- rank-gated source (#600 / box-source-fetch.sh).
--
-- This table is the registry that backs both. A public SSH key is NOT a secret
-- (it is, by design, the half you hand out), so it lives in the DB in the clear —
-- unlike the box source CREDENTIAL, which stays in the prod env (ADR 0022). The
-- security property is the SAME as source access: GET /box/authorized-keys is
-- gated on the builder's LIVE rank+status (box-access.decideSourceAccess), so a
-- demoted/deactivated builder's keys stop being served on the box's very next
-- fetch — instant, credential-layer offboarding (the droplet teardown is the
-- slower control-plane half via `box.js reconcile`). Empty served file = no SSH
-- login = the box is locked even before it is destroyed.
--
-- Idempotent: safe to re-run.

-- ---------------------------------------------------------------------------
-- builder_ssh_keys — public SSH keys a builder authorizes for their dev box.
-- Many keys per builder (laptop + desktop + a re-key); de-duped by fingerprint.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS builder_ssh_keys (
  id            bigserial PRIMARY KEY,
  builder_id    bigint NOT NULL REFERENCES builders(id) ON DELETE CASCADE,

  -- The full authorized_keys line as the builder presented it, already
  -- validated + normalized server-side to "<type> <base64> [comment]" (a single
  -- line, no shell metacharacters) by src/bongos/box-onboard.validateSshPublicKey.
  -- Stored verbatim so GET /box/authorized-keys can emit it unchanged.
  public_key    text NOT NULL,
  -- Algorithm token (ssh-ed25519 | ssh-rsa | ecdsa-sha2-* | sk-*). Recorded for
  -- the roster/audit and so a future policy ("ed25519 only") is a pure filter.
  key_type      text NOT NULL,
  -- SHA256 fingerprint (base64, no padding — the `SHA256:...` form ssh-keygen
  -- prints). The natural de-dupe key: re-registering the same key is a no-op,
  -- not a duplicate authorized_keys line on the box.
  fingerprint   text NOT NULL,
  -- Human label for the roster ("box-connect macOS 2026-06-05"); never trusted
  -- input on the box side (it is a comment, not part of the key material).
  label         text,

  created_at    timestamptz NOT NULL DEFAULT now(),
  -- Bumped when GET /box/authorized-keys serves this key to a live box, so the
  -- roster can show "last seen on a box" without a separate events table.
  last_used_at  timestamptz,

  -- One row per (builder, key). Re-registering the same key updates the label /
  -- last_used_at via ON CONFLICT rather than inserting a duplicate.
  UNIQUE (builder_id, fingerprint)
);

-- The hot read path is "every key for THIS builder" (GET /box/authorized-keys,
-- GET /box/ssh-key). A single index on builder_id serves both.
CREATE INDEX IF NOT EXISTS idx_builder_ssh_keys_builder ON builder_ssh_keys (builder_id);

INSERT INTO schema_migrations (version) VALUES ('069_builder_ssh_keys')
  ON CONFLICT (version) DO NOTHING;
