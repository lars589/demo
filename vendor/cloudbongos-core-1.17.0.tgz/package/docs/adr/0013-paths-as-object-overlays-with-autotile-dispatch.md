# 0013 — Paths as object overlays with autotile dispatch

- **Status:** Accepted
- **Date:** 2026-05-10
- **Deciders:** Lars
- **Extends:** [ADR 0012](./<redacted>.md) (cell model), [ADR 0011](./0011-terrain-id-rendering-model.md) (render dispatch), [ADR 0009](./0009-autotile-architecture.md) (autotile families)

## Context

The V1 world places a marble flagstone path running 4 cells north-to-south
through the sand band (cells `(13, 10..13)`). Up until now the path was
declared as a **ground terrain** (`TERRAIN.MARBLE_PATH`) with a `path16`
render strategy. The `marble_path` autotile family was generated with
three primitives: `path_terrain` (the surrounding ground texture), `path_node`
(centered marble cluster), and `path_arm_N` (vertical strip of marble).
Each composed tile was an opaque RGB image — the path arms and node
pasted onto a `path_terrain` background that filled the whole 32×32.

That model has two structural problems:

1. **Terrain mismatch.** The composed path tiles include their own
   `path_terrain` margins. The V1 world places the path over `SAND`, but
   the family was designed for paths through grass (per the prompt). The
   path tiles' margins read as grass, the surrounding world ground reads
   as sand → visible color discontinuity at every path cell's edge,
   which Lars correctly described as "visible gaps showing through."
2. **Combinatorial family explosion.** If V2 adds paths that run through
   grass *and* paths through marble plazas *and* paths through cobble,
   each pairing needs its own family — `marble_path_on_sand`,
   `marble_path_on_grass`, etc. The number of families is `paths × grounds`,
   which doesn't scale.

ADR 0012's whole point was that **objects are overlays on top of ground**,
free from polluting ground rendering. That model fits paths perfectly —
a path is a thing you walk on top of the ground, not a kind of ground.
But ADR 0012 limited objects to single-tile rendering, which doesn't
support the autotile dispatch a path needs to pick the right
straight/junction/end-cap tile based on its neighbors.

## Decision

**Paths become objects with autotile dispatch.** Specifically:

- A new object id `OBJECT.PATH_MARBLE` (declared on the OBJECT enum,
  added to neither `BLOCKING_OBJECTS` nor `BLOCKING_TERRAINS` — a path is
  walkable). The world places the path on the **objects** layer; the
  ground at those cells is `SAND` (just like the surrounding cells).
- `OBJECT_RENDER` extends from `{ tile }` only to the same dispatch
  shape that `TERRAIN_RENDER` already supports:
  `{ strategy: 'single' | 'path16' | 'blob47', family, fallbackTile }`.
  Single-tile is preserved for back-compat (legacy short-form `{ tile }`
  still accepted, normalized internally).
- A new `pickObjectAutotileIndex(object, neighbors)` mirrors the existing
  `pickAutotileIndex(terrain, neighbors)` — same dispatch logic, looks up
  in `OBJECT_RENDER` instead of `TERRAIN_RENDER`. The picker queries the
  **objects** grid for neighbors of the same object id. (`neighborsAt`
  itself is unchanged — already generic over any 2D grid.)
- The `marble_path` autotile family drops the `path_terrain` primitive
  entirely. Its tiles are now produced as **RGBA with alpha-keyed
  backgrounds**: the marble flagstones are opaque, everything else is
  transparent. The world's ground tile is painted first (depth 0); the
  path tile renders on top (depth 1). The surrounding sand-or-grass-or-
  whatever shows through wherever the marble doesn't cover.
- A new `kind='alpha_tile'` in `post_process.process()` does explicit
  magenta-key transparency removal *before* palette quantization (the
  locked palette doesn't contain pure `#FF00FF`, so magenta would
  otherwise palette-snap to a near-purple and dodge the threshold). The
  autotile orchestrator routes primitives with `transparent_bg: true`
  to this kind.
- `compose_path16` in `autotile_compositor.py` defaults to a transparent
  RGBA canvas when no `terrain` primitive is present. Legacy families
  that still ship a terrain primitive get the old opaque behavior.
- `family_checks.color_profile_check` masks alpha=0 pixels out of the
  in-range fraction so transparent regions don't skew the score.

The runtime renderer is unchanged in shape: `WorldScene.drawMap` still
does ground pass + object pass. Phaser's `add.image` blits RGBA natively;
the alpha pixels just don't paint over the ground that's already there.

## Consequences

**Paths are now terrain-agnostic.** The same `marble_path` family works
over sand, grass, marble plazas, and any future ground. The V1 world's
path strip renders correctly — sand shows through where the marble
doesn't cover, no gaps, no color mismatch.

**Object-layer autotile dispatch is now a first-class pattern.** Future
linear or regional overlays (fences, low walls, rivers, trails, footpaths
in dirt, bridges, vine borders) reuse this without further architectural
work. Pick `path16` for line connections, `blob47` for region overlays.

**The cell model stays at two layers.** This is *not* a layer-count
expansion. Ground is the always-defined surface; object is the optional
overlay. Both layers can autotile-dispatch — the dispatch generalizes,
not the cell shape.

**`MARBLE_PATH` ground terrain is now vestigial.** It's declared and its
`TERRAIN_RENDER` entry remains for back-compat, but `INITIAL_MAP` no
longer places it. A future cleanup task can remove the enum entry once
no other code references it; not urgent.

**The walkability test grew by 1 case** (the path strip is walkable
across all 4 cells) and the existing `(13, 10) is sand` assertion
loosened to require `ground = SAND, object = PATH_MARBLE` instead of
`ground = MARBLE_PATH, object = null`. `terrain_picker.mjs` gained 4
cases covering object-layer autotile dispatch — including the
**OBJECT-LAYER AUTOTILE INVARIANT** mirror of ADR 0012's ground invariant
(object autotile sees only the object grid; ground never affects it).

**Alpha rendering has a known generation cost.** Each new alpha-keyed
family needs primitives generated with magenta-key backdrops. The model
needs explicit instruction to use `#FF00FF` solid backgrounds; in
practice the family pipeline's color profile gate caught the path_node
at 39% in-range (1pt below the 40% threshold) on retry, but accepted
best-effort because the gate is WARN-not-block in V1. Future iteration
can hard-block on color once the pipeline reliably hits ≥80%.

## Alternatives considered

**Option A — Pragmatic regen of `marble_path.path_terrain` to be sand.**
~$0.08 of generation work. Visible problem disappears for V1. But binds
the family to one underlying terrain forever — the moment a path needs
to run through grass, this model breaks again. We chose the architectural
fix because the explicit goal of this stress-test session is improving
the building architecture, not patching surface symptoms.

**Option B — Multi-layer ground cells.** Instead of two layers (ground
+ object), let ground itself be a stack: `[sand, marble_path]` for path
cells. Cleaner conceptually for "path on top of ground" framing, but a
much larger schema change — affects every consumer of `INITIAL_MAP.ground`,
breaks the "ground is always one terrain" invariant ADR 0011 leans on,
and doesn't generalize beyond paths.

**Option C — Composite at preload.** Generate the full opaque path tile
at runtime by stitching `world_ground_tile + path_alpha_overlay` once
per cell when the world loads. Equivalent visual outcome to the chosen
approach, but does the compositing in JS (slow), per-cell (lots of
texture cache pressure), and at preload (delays first render). The
chosen approach offloads the compositing to the GPU at draw time, which
is what Phaser is already optimized for.

## Verification

- `tests/walkability.mjs` — 14/14 passing. New: PATH_MARBLE non-blocking;
  4-cell strip walkable; ground=SAND object=PATH_MARBLE at the path cells.
- `tests/terrain_picker.mjs` — 14/14 passing. New: OBJECT_RENDER strategy
  enumeration; `pickObjectAutotileIndex` dispatch correctness on
  isolated, vertical-strip, top/bottom end-cap configurations; the
  object-layer autotile invariant.
- `tests/autotile_xverify.mjs` — unchanged, still green (the JS↔Python
  lookup tables didn't change; only the dispatch wrapper shifted).
- Visual: `/tmp/path-on-sand-preview.png` (rendered at session time)
  shows a 4-tile vertical strip with marble flagstones running down the
  center column and sand visible on left/right margins — no magenta, no
  terrain mismatch, no gaps. The browser will reproduce this at runtime.
- The `_magenta_mask` detector runs before palette quantization, on raw
  model output, with threshold `R>180 ∧ G<80 ∧ B>140` (caught 61% of
  pixels in `path_node`, 33% in `path_arm_N`).
