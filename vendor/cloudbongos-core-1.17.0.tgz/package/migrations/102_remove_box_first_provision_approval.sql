-- 102_remove_box_first_provision_approval.sql — ADR 0059 (task 1141): REMOVE the
-- dev-box "first-box Archon approval" gate. Reverts migration 071.
--
-- Context
-- -------
-- Migration 071 (#717, ADR 0035 Decision 2) added a 'pending_approval' state to
-- box_intents so a newcomer's FIRST paid droplet was held until an Archon ran
-- POST /box/intents/:id/approve. That double-gated admission: a builder already
-- had to be admitted to the project (the invite/member-join gate) before they
-- could ever reach /box/ensure, and then their first box was gated AGAIN.
--
-- ADR 0059 / task 1141 collapses this to a single approval — the member-join
-- (invite) admission gate — and lets an admitted builder's first box auto-drain
-- like every subsequent provision and every wake. The web tier still only RECORDS
-- A REQUEST and never holds DO_API_TOKEN (the migration-070 invariant is
-- unchanged); the box lifecycle stays operator/control-plane only. This migration
-- only removes the SECOND, redundant gate on box provisioning. The member-join /
-- access-request admission flow is untouched.
--
-- This file reverts migration 071 back to the migration-070 schema: it drains any
-- held first-box requests, removes 'pending_approval' from the state CHECK, restores
-- the migration-070 partial unique index, and drops the approval audit columns.
--
-- Do NOT edit migration 071 itself — it already ran on prod; this forward migration
-- undoes its effects.
--
-- Idempotent: safe to re-run.

-- Step 1 — drain held requests FIRST, before the tightened CHECK is re-added, so no
-- live row violates the constraint. A 'pending_approval' row was a first-box request
-- waiting on an Archon; with the gate gone, it simply becomes a normal 'pending'
-- request the control-plane runner will auto-drain.
UPDATE box_intents
   SET state = 'pending', updated_at = now()
 WHERE state = 'pending_approval';

-- Step 2 — restore the migration-070 state CHECK (drop 'pending_approval'). Postgres
-- has no ALTER ... DROP VALUE for a CHECK, so drop + re-add. Same constraint name
-- migration 071 used.
ALTER TABLE box_intents DROP CONSTRAINT IF EXISTS box_intents_state_check;
ALTER TABLE box_intents ADD CONSTRAINT box_intents_state_check
  CHECK (state IN ('pending', 'running', 'done', 'error'));

-- Step 3 — restore the migration-070 partial unique index (one open intent per
-- builder), dropping 'pending_approval' from the open set. After step 1 no held rows
-- remain, so the open set is again {pending, running}.
DROP INDEX IF EXISTS ux_box_intents_open;
CREATE UNIQUE INDEX IF NOT EXISTS ux_box_intents_open
  ON box_intents (builder_id)
  WHERE state IN ('pending', 'running');

-- Step 4 — drop the approval audit columns migration 071 added. With the gate gone
-- there is nothing to attribute.
ALTER TABLE box_intents DROP COLUMN IF EXISTS approved_by;
ALTER TABLE box_intents DROP COLUMN IF EXISTS approved_at;

INSERT INTO schema_migrations (version) VALUES ('102_remove_box_first_provision_approval')
  ON CONFLICT (version) DO NOTHING;
