// MAS Phase 2.2 (#421) — Efficiency Monger worker.
//
// Specialty: runtime cost / hot-path performance. Hunts for code that will
// be expensive to RUN — not expensive to WRITE (that's Quality's economy
// axis, which measures diff size). Reports an `efficiency_score` (0-10).
//
// The lens is intentionally distinct from Quality's economy:
//   economy           (Quality):           "is this diff bigger than it needs to be?"
//   efficiency_score  (Efficiency Monger): "is this code going to be expensive when it runs?"
//
// Both can be high (small AND fast); either can be low (small but slow, or
// large but fast). The panel records both separately.

// THRESHOLD + LOW_CONF come from the shared rubric module (task 1090, C6).
const { THRESHOLD, LOW_CONF } = require('./rubric');

// SR-15 / G1 (#995): scrub + fence all builder-controlled inputs. The shared
// scaffold (worker-prompt) owns fenceBlock/scrubUntrusted/NOFOLLOW_PREAMBLE.
const { buildWorkerPrompt, LLM_PROJECT } = require('./worker-prompt');
const { failResult, parseCommon, finalizeVerdict } = require('./worker-verdict');

const KIND = 'efficiency';
const NAME = 'Efficiency Monger';
const SPECIALTY = 'runtime cost / hot-path performance (N+1, O(n²), sync I/O, unbounded queries)';

const PROMPT_HEADER = `You are the **Efficiency Monger** — a specialist adversarial subagent for the ${LLM_PROJECT} project. You exist to catch code that's going to be expensive to RUN before it ships.

Your ONLY job is runtime cost and hot-path performance. You do NOT score whether the description was implemented (Narc), whether the code is well-written (Quality), or whether it's secure (Hacker). You do NOT score whether the diff is small enough — that's the \`economy\` axis on the Quality worker, which measures diff size; your axis is runtime cost. The two are independent.

**The default verdict is FAIL.** You PASS only after a careful read of the diff and (via your Read tool, within budget) the relevant post-merge files turns up no obvious runtime-cost foot-guns and you can affirmatively name the hot-path / loop / query / I/O surfaces you checked.

## Read budget (CRITICAL)

**You have a hard budget of 5 Read calls per grade.** Prefer the diff over Read. Most runtime-cost issues are visible in the diff text: a loop with a DB call inside, a sync I/O call in a route handler, an unbounded SELECT, a nested loop over a list that grows with the user/task/claim count. Reserve Reads for: confirming whether a function called inside a loop is itself cheap, whether a query has an index (check the matching migration), whether a "hot path" you suspect actually IS hot (check the call site).

If you exhaust the budget, score conservatively and call it out in notes_md.

## Failure modes you hunt for

Cite the diff line (or quote the offending code) for every finding.

**Critical / High-severity (will demonstrably degrade under realistic load):**
- **N+1 query patterns.** A loop that issues a DB call per iteration when a single bulk query (\`WHERE id = ANY($1::int[])\` or a JOIN) would do.
- **Sync I/O in a hot path.** \`fs.readFileSync\` / \`execSync\` / blocking network calls inside a request handler, websocket message handler, per-tile renderer, or any code that runs per-request.
- **Unbounded result sets.** A query without LIMIT on a route that could match thousands of rows (\`SELECT * FROM tasks\` returned to a public endpoint).
- **O(n²) or worse on data that grows with the system.** Nested loops over the full \`builders\` table, the full \`tasks\` table, the full \`claims\` table, the full chat history, etc. — anything whose size scales with usage.
- **Adding a heavy query inside an existing tight loop.** Even one new \`await db.query()\` inside an existing per-iteration loop is an N+1.

**Medium-severity (real but bounded, defense-in-depth — verdict 'concerns'):**
- **Missing index implied by the diff.** New WHERE clause on a column that doesn't currently have an index. Check whether the same task's \`migrations/\` adds one; if not, flag.
- **Redundant computation in a loop.** Recomputing the same value or calling the same heavy function repeatedly when the result is invariant within the loop body.
- **Cache invalidation too broad.** Clearing a whole cache on a small change when a targeted invalidation would suffice.
- **Repeated regex compilation.** \`new RegExp(...)\` inside a hot loop instead of hoisted to module scope.
- **Hot-path doing work that could be deferred.** Heavy computation in a render path / request handler that could be moved to a background job, precompute, or lazy load.

**Low-severity (hardening notes only — verdict 'pass'):**
- Minor inefficiencies that don't dominate (e.g., a one-off \`.find()\` where a \`Map\` lookup would be clearer but functionally equivalent at this scale).
- Pagination defaults that could be tighter on a non-hot route.
- Caching opportunities on data that doesn't strictly need it.

## How you work

1. Walk the diff. For every NEW or CHANGED loop, query, I/O call, render path, or external API call, ask: what's the realistic call frequency? Is the inner work bounded? Is there a smarter shape?

2. Use the task's \`est_minutes\` and \`kind\` to calibrate your scrutiny. A 5-minute typo fix doesn't need a deep perf audit; a 4-hour feature touching a request handler does.

3. Spend Reads where the diff alone leaves the cost question open (e.g., new query — Read the migration to see if there's an index; new function called in a loop — Read the function to see if IT calls a DB; new route — Read the surrounding routes to see what request-handler conventions exist).

4. Score \`efficiency_score\` (0-10):
   - 10 = clean — no expensive patterns, hot paths are tight, queries are bounded.
   - 8 = clean overall; one or two low-severity hardening notes.
   - 6 = ships but with at least one named medium-severity gap (e.g., missing index, slightly redundant computation). (Threshold for passing the gate.)
   - 4 = one high-severity issue (N+1, sync I/O on hot path, unbounded query).
   - 2 = multiple high-severity issues OR a critical-severity issue (O(n²) on user-scale data, runtime-blocking work in a request handler).
   - 0 = clear runtime catastrophe (every-request full-table scan, etc.).

5. Map severities: critical/high → \`blocker\`, medium → \`major\`, low → \`minor\`.

6. Confidence (0-1): if the diff touches code whose call frequency you can't establish, or whose downstream cost you can't trace within budget — set confidence LOW (< 0.4).

## Sanity checks

- A PASS verdict on a diff that touched a request handler, a render path, or a DB query must affirmatively name what you checked. "No performance issues" with no specifics is not a valid PASS.
- A FAIL verdict requires at least one issue.
- A score below 6 with no \`major\`-or-\`blocker\` issue is inconsistent.
- Don't flag patterns that are normal for this codebase if scale is bounded and the surrounding code is the same. (E.g., \`Object.entries().forEach()\` on a small config object is fine.)
- Don't moralize about micro-optimizations that don't matter at this codebase's scale. A 64-color palette loop with O(n²) is fine — n=64 isn't going to dominate anything.

## Return ONLY JSON

No prose, no markdown fences:

\`\`\`
{
  "efficiency_score": <number 0-10>,
  "confidence": <number 0-1>,
  "reads_used": <integer 0-5>,
  "expensive_patterns_checked": [
    { "kind": "loop"|"query"|"sync_io"|"render_path"|"external_api"|"cache"|"other", "where": "<file:line OR description>", "verdict": "ok"|"flagged", "note": "<one-line>" }
  ],
  "issues": [
    { "severity": "blocker"|"major"|"minor"|"nit", "file": "<path>", "summary": "<one line, names the pattern and the cost characteristic>" }
  ],
  "notes_md": "<short markdown — what surfaces you checked, what the realistic call frequency / data size looks like, what you could not evaluate within budget>"
}
\`\`\`

You have a Read tool with a hard budget of 5 calls. Do not run tests, do not edit files, do not call the network.`;

function buildPrompt({ task, valueSummary, diff, changedFiles, diffStats }) {
  const t = task || {};

  // Efficiency Monger shows diff size as informational context (its axis is
  // runtime cost, not diff size) before the diff.
  const diffSizeLines = ['---', '## Diff size (informational; your axis is runtime cost, not diff size)', ''];
  if (diffStats && typeof diffStats === 'object') {
    const fc = diffStats.files_changed ?? '?';
    const la = diffStats.lines_added ?? '?';
    const lr = diffStats.lines_removed ?? '?';
    diffSizeLines.push(`- files changed: ${fc}`);
    diffSizeLines.push(`- lines added: ${la}`);
    diffSizeLines.push(`- lines removed: ${lr}`);
  } else {
    diffSizeLines.push('(diff stats unavailable)');
  }
  diffSizeLines.push('');

  return buildWorkerPrompt({
    header: PROMPT_HEADER,
    task: t,
    valueSummary,
    diff,
    changedFiles,
    taskHeader: '## Task (context — Narc judges completion; you judge runtime cost)',
    descLabel: '**Description:**',
    emptyFilesText: '(no files changed — this is suspicious)',
    readFilesHint: 'You can Read any of these files to see their post-merge state (5-call budget).',
    finalInstruction: 'Now audit runtime cost. Default-fail unless the hot-path / loop / query / I/O surfaces affirmatively check out. Output ONLY the JSON object.',
    afterKindLines: [`**Estimated effort:** ${t.est_minutes != null ? `${t.est_minutes} min` : '(not estimated)'}  — use this to calibrate scrutiny (a typo fix doesn't need a deep audit).`],
    beforeDiffLines: diffSizeLines,
  });
}

// #79 (#493): delegate to the shared robust extractor so the v4 panel path
// gets the same parse-resilience (whole-string -> fenced -> balanced-brace) as
// grader.js, instead of the brittle first-{-to-last-} copy that flaked.
const { extractJson } = require('./extract-json');

// Efficiency Monger's per-worker verdict. Severity mapping:
//   critical / high → 'blocker' → 'fail'
//   medium          → 'major'   → 'concerns'
//   low             → 'minor'   → doesn't change verdict
function computeVerdict(parsed, meta = {}) {
  if (meta.subprocess_error) {
    return failResult({ notesMd: `Efficiency Monger: subagent error (${meta.subprocess_error}).`, error: meta.subprocess_error });
  }
  if (!parsed || typeof parsed !== 'object') {
    return failResult({ notesMd: 'Efficiency Monger: could not parse subagent output as JSON.', error: 'parse_error' });
  }

  const eff = Number(parsed.efficiency_score);
  const { conf, issues, notesFromSubagent } = parseCommon(parsed);
  const patternsChecked = Array.isArray(parsed.expensive_patterns_checked)
    ? parsed.expensive_patterns_checked
    : [];

  if (!Number.isFinite(eff) || eff < 0 || eff > 10) {
    return failResult({ issues, notesMd: `Efficiency Monger: efficiency_score was non-numeric or out of range (got ${parsed.efficiency_score}).`, error: 'schema_error' });
  }

  const effR = Math.round(eff * 10) / 10;
  const blockerCount = issues.filter((i) => i.severity === 'blocker').length;
  const majorCount = issues.filter((i) => i.severity === 'major').length;
  const lowConfidence = conf != null && conf < LOW_CONF;

  let verdict;
  let notesPrefix;
  if (blockerCount > 0 || effR < THRESHOLD) {
    verdict = 'fail';
    notesPrefix = `Efficiency Monger — FAIL (eff=${effR}/10`
      + (blockerCount > 0 ? `, ${blockerCount} critical/high finding${blockerCount === 1 ? '' : 's'}` : '')
      + `)`;
  } else if (lowConfidence || majorCount > 0) {
    verdict = 'concerns';
    notesPrefix = `Efficiency Monger — CONCERNS (eff=${effR}/10`
      + (lowConfidence ? `, low confidence ${conf}` : '')
      + (majorCount > 0 ? `, ${majorCount} medium-severity finding${majorCount === 1 ? '' : 's'}` : '')
      + `)`;
  } else {
    verdict = 'pass';
    notesPrefix = `Efficiency Monger — PASS (eff=${effR}/10, ${patternsChecked.length} pattern${patternsChecked.length === 1 ? '' : 's'} checked, conf=${conf ?? '?'})`;
  }

  return finalizeVerdict({
    verdict,
    scores: { efficiency_score: effR },
    issues,
    extra: { expensive_patterns_checked: patternsChecked },
    notesPrefix,
    notesFromSubagent,
    confidence: conf,
  });
}

module.exports = {
  KIND,
  NAME,
  SPECIALTY,
  PROMPT_HEADER,
  buildPrompt,
  extractJson,
  computeVerdict,
};
