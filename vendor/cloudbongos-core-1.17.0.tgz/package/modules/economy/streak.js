'use strict';

// Streak math + anti-gaming guards (PMS-V2 #52, criterion 3).
//
// Definitions (locked in PMS-V2 planning, see limitations/pms-v2.md):
//   - A "ship-day" = a local-builder-timezone calendar day in which the builder
//     shipped >=1 qualifying task.
//   - A "qualifying ship" requires:
//       * claim.outcome = 'shipped'           (builder declared done)
//       * task.status IN ('confirmed','shipped')  (verification passed; credits landed)
//       * task.est_minutes >= 15              (anti-gaming floor)
//     NOTE: cleanup/refactor tasks DO now count (V3.R93 #354). The original
//     PMS-V2 rule excluded kind='cleanup', which mildly penalized the exact
//     simplification work we want to reward. That exclusion was removed in both
//     the SQL below and the wouldExtendStreak guard; the only anti-gaming floor
//     that remains is est_minutes >= 15.
//   - Cap: at most 5 qualifying ships per local-day count toward streak (so you
//     can't pad a streak by shipping micro-tasks). Note: since one calendar day
//     is one ship-day regardless of count, the 5-cap doesn't change ship-day
//     identification — it's a guard that's surfaced honestly in the per-day
//     counts the API returns (and that future "qualifying ships" features can
//     use to throttle credit recognition).
//   - Current streak = consecutive ship-days ending today (in the builder's
//     timezone). If today is NOT a ship-day, current streak = 0. Strict.
//   - Longest streak = the longest run of consecutive ship-days ever.
//
// SOURCE of ship events: claims (joined to tasks) — NOT session_logs. The
// session_logs row for a just-finishing ship is INSERTed AFTER evaluateAfterShip
// runs in resolveClaim, so it's invisible at evaluator time. The claim row,
// however, has already been UPDATEd to outcome='shipped' + released_at=now()
// and the task to status='confirmed' before the evaluator fires, so claims+tasks
// gives us a stable, in-transaction view.
//
// Caller contract:
//   - Pass a `client` for in-transaction calls (achievements evaluator path).
//   - Pass `pool` for out-of-transaction calls (HTTP /me/streak path).
// Either works — both have .query().

// Carved into modules/economy/ (BV1.R77 / ADR 0093 §1-2): reach the shared pool
// through the published doorway — a module never requires a core internal.
const { pool } = require('../../src/module-api');

// -------------------------------------------------------------------------
// Core query — pulls a builder's qualifying ship-days in their local TZ.
// Caps each calendar day at 5 ships (anti-gaming).
//
// Returns: { ship_days: [{ local_date: 'YYYY-MM-DD', count: int (1..5) }],
//            timezone: 'America/...' }
// Sorted by local_date ASC.
// -------------------------------------------------------------------------
async function qualifyingShipDays(client, builderId) {
  const sql = `
    WITH builder_tz AS (
      SELECT timezone FROM builders WHERE id = $1
    ),
    qualifying AS (
      SELECT c.released_at,
             ((c.released_at AT TIME ZONE (SELECT timezone FROM builder_tz))::date) AS local_date
        FROM claims c
        JOIN tasks t ON t.id = c.task_id
       WHERE c.builder_id = $1
         AND c.outcome = 'shipped'
         AND c.released_at IS NOT NULL
         AND t.status IN ('confirmed', 'shipped')
         AND t.est_minutes >= 15
    ),
    ranked AS (
      SELECT local_date,
             ROW_NUMBER() OVER (PARTITION BY local_date ORDER BY released_at) AS rn
        FROM qualifying
    ),
    capped AS (
      SELECT local_date, COUNT(*)::int AS cnt
        FROM ranked
       WHERE rn <= 5
       GROUP BY local_date
    )
    SELECT to_char(local_date, 'YYYY-MM-DD') AS local_date,
           cnt,
           (SELECT timezone FROM builder_tz) AS timezone
      FROM capped
      ORDER BY local_date
  `;
  const { rows } = await client.query(sql, [builderId]);
  if (rows.length === 0) {
    // We still want the builder's timezone for downstream "today" math.
    const { rows: tzRows } = await client.query(
      'SELECT timezone FROM builders WHERE id = $1',
      [builderId]
    );
    return {
      ship_days: [],
      timezone: tzRows[0]?.timezone || 'America/New_York',
    };
  }
  return {
    ship_days: rows.map((r) => ({ local_date: r.local_date, count: Number(r.cnt) })),
    timezone: rows[0].timezone,
  };
}

// -------------------------------------------------------------------------
// "Today" in the builder's local timezone, formatted as 'YYYY-MM-DD'.
// Pulled from Postgres so the same clock the qualifying-ships query used
// is used here (no JS-vs-DB clock drift, no host-TZ surprises).
// -------------------------------------------------------------------------
async function todayInBuilderTz(client, builderId) {
  const { rows } = await client.query(
    `SELECT to_char((now() AT TIME ZONE timezone)::date, 'YYYY-MM-DD') AS today
       FROM builders WHERE id = $1`,
    [builderId]
  );
  return rows[0]?.today || null;
}

// -------------------------------------------------------------------------
// Pure helpers (no DB) — walk a sorted ascending list of YYYY-MM-DD strings
// and compute current + longest streak relative to "today" string.
// -------------------------------------------------------------------------
function ymdToOrdinal(ymd) {
  // 'YYYY-MM-DD' → integer day-number suitable for diffing.
  // Using Date.UTC so DST has no effect (we're comparing whole local days).
  const [y, m, d] = ymd.split('-').map(Number);
  return Math.floor(Date.UTC(y, m - 1, d) / 86400000);
}

function computeRunsFromShipDays(shipDayStrs, todayStr) {
  if (!shipDayStrs || shipDayStrs.length === 0) {
    return { current_streak: 0, longest_streak: 0, last_ship_day: null };
  }
  const ords = shipDayStrs.map(ymdToOrdinal);
  const todayOrd = todayStr ? ymdToOrdinal(todayStr) : null;

  // Longest run: walk and count consecutive (diff==1) values.
  let longest = 1;
  let run = 1;
  for (let i = 1; i < ords.length; i++) {
    if (ords[i] === ords[i - 1] + 1) {
      run++;
      if (run > longest) longest = run;
    } else if (ords[i] === ords[i - 1]) {
      // duplicate — shouldn't happen given GROUP BY, but stay defensive
      continue;
    } else {
      run = 1;
    }
  }

  // Current run: streak ending TODAY (strict). If today is not a ship-day,
  // current_streak = 0.
  let current = 0;
  if (todayOrd !== null) {
    const lastOrd = ords[ords.length - 1];
    if (lastOrd === todayOrd) {
      current = 1;
      for (let i = ords.length - 2; i >= 0; i--) {
        if (ords[i] === ords[i + 1] - 1) {
          current++;
        } else {
          break;
        }
      }
    }
  }

  return {
    current_streak: current,
    longest_streak: longest,
    last_ship_day: shipDayStrs[shipDayStrs.length - 1],
  };
}

// -------------------------------------------------------------------------
// Public: computeStreak(builderId, [client])
// -------------------------------------------------------------------------
async function computeStreak(builderId, client) {
  const c = client || pool;
  const [{ ship_days, timezone }, today] = await Promise.all([
    qualifyingShipDays(c, builderId),
    todayInBuilderTz(c, builderId),
  ]);
  const dayStrs = ship_days.map((d) => d.local_date);
  const runs = computeRunsFromShipDays(dayStrs, today);
  // Find when the current run started (for UI display + 'streak began' hint)
  let current_started_on = null;
  if (runs.current_streak > 0) {
    const lastOrd = ymdToOrdinal(today);
    const startOrd = lastOrd - (runs.current_streak - 1);
    const ms = startOrd * 86400000;
    const dt = new Date(ms);
    const y = dt.getUTCFullYear();
    const m = String(dt.getUTCMonth() + 1).padStart(2, '0');
    const d = String(dt.getUTCDate()).padStart(2, '0');
    current_started_on = `${y}-${m}-${d}`;
  }
  return {
    current_streak: runs.current_streak,
    longest_streak: runs.longest_streak,
    last_ship_day: runs.last_ship_day,
    current_started_on,
    timezone,
    today,
    ship_day_counts: ship_days, // useful for debug / future UI
  };
}

// -------------------------------------------------------------------------
// Public: wouldExtendStreak(builderId, taskId, [client])
//
// Preview helper: "if this task were shipped right now (qualifying), what
// would the streak become?" Used by /me to render hints like
// "shipping #52 would extend your streak to 4 days".
//
// Returns: { current_streak, projected_streak, qualifies, reason? }
//   qualifies = false when task doesn't meet est_minutes>=15. (As of V3.R93
//   #354 kind='cleanup' is NO LONGER a disqualifier — cleanup/refactor ships
//   count toward streaks like any other ship.)
//   reason explains why (rendered by CLI).
// -------------------------------------------------------------------------
async function wouldExtendStreak(builderId, taskId, client) {
  const c = client || pool;
  const cur = await computeStreak(builderId, c);

  const { rows: taskRows } = await c.query(
    'SELECT id, kind, est_minutes FROM tasks WHERE id = $1',
    [taskId]
  );
  const task = taskRows[0];
  if (!task) {
    return { current_streak: cur.current_streak, projected_streak: cur.current_streak,
             qualifies: false, reason: 'task-not-found' };
  }
  if ((task.est_minutes ?? 0) < 15) {
    return { current_streak: cur.current_streak, projected_streak: cur.current_streak,
             qualifies: false, reason: 'est_minutes<15' };
  }
  // V3.R93 (#354): kind='cleanup' used to disqualify here. It no longer does —
  // cleanup/refactor ships count toward streaks. The only remaining floor is
  // est_minutes >= 15 above.

  // Project: today becomes (or stays) a ship-day.
  const todayOrd = ymdToOrdinal(cur.today);
  const ords = cur.ship_day_counts.map((d) => ymdToOrdinal(d.local_date));

  if (cur.current_streak > 0) {
    // Already shipped today → today already counted. Streak doesn't change
    // from another ship today (one calendar day = one ship-day).
    return {
      current_streak: cur.current_streak,
      projected_streak: cur.current_streak,
      qualifies: true,
      reason: 'today-already-counted',
    };
  }

  // current_streak = 0 means today is NOT yet a ship-day. Shipping now adds today.
  // Find run length ending at yesterday.
  let runEndingYesterday = 0;
  if (ords.length > 0) {
    const lastOrd = ords[ords.length - 1];
    if (lastOrd === todayOrd - 1) {
      runEndingYesterday = 1;
      for (let i = ords.length - 2; i >= 0; i--) {
        if (ords[i] === ords[i + 1] - 1) runEndingYesterday++;
        else break;
      }
    }
  }
  return {
    current_streak: cur.current_streak,
    projected_streak: runEndingYesterday + 1,
    qualifies: true,
    reason: runEndingYesterday > 0 ? 'extends-yesterday-run' : 'starts-new-run',
  };
}

module.exports = {
  computeStreak,
  wouldExtendStreak,
  // Exported for testing
  qualifyingShipDays,
  todayInBuilderTz,
  ymdToOrdinal,
  computeRunsFromShipDays,
};
