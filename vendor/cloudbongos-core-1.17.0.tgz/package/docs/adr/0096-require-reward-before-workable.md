# ADR 0096 — Require a `credits_reward` (drachmae) value before a task is workable

**Date:** 2026-06-28
**Status:** Accepted
**Track:** `internal` (GDS / economy + lifecycle)
**Task:** [#1670](https://example.com/builders#/task/1670) (GDS-V4)

## Context — the problem

Every task carries a `credits_reward` integer — the in-world drachmae payout when it
ships ([ADR 0023](<redacted>.md), [ADR 0054](<redacted>.md)).
That column was created with `NOT NULL DEFAULT 0` (migration `003_pms.sql`). Nothing in
the lifecycle ever required it to be set, so the default path was:

> create a task (reward = 0) → promote it to `ready` → claim → ship → **pay 0 drachmae**.

A task could travel the whole claim→ship→credit pipeline paying nothing. The credit
ledger then records a real shipped task with a zero payout — the reward economy is
silently unfunded for every task whose author never set a value. At the time of this
change there were ~57 tasks sitting in `ready` with `credits_reward = 0`.

The fix is to make a present, positive reward a **precondition for a task becoming
workable** — without stranding any of the existing zero-reward work.

## Decision — three enforcement points

The reward requirement is enforced at the two transitions that make a task *workable*,
plus the predicate that auto-promotes tasks:

1. **Promote-to-ready (`POST /tasks/:id/promote`).** Refuses to flip a task to `ready`
   when `credits_reward` is NULL or `<= 0`, returning `409 { error: 'REWARD_REQUIRED' }`
   with an actionable message that *suggests* a value derived from `kind` + `est_minutes`
   and names the `PATCH /tasks/:id` call to set it. (`modules/lifecycle/routes/tasks.js`.)

2. **Auto-promote predicate (`task_is_fully_unblocked`, migration 177).** This SQL
   predicate is the single condition shared by all three auto-promotion triggers
   (`promote_dependents_on_ship` / `_criterion_satisfy` / `_goal_achieve`, migration 163).
   It now requires `(reward_gate_exempt OR credits_reward > 0)` **in addition to** the
   dependency-doneness check. A deps-shipped task with no reward therefore stays `backlog`
   when its last dependency ships — it does not auto-promote until an author sets a reward.

3. **Claim-time backstop (`db.claimTask`).** Refuses a claim on a 0/NULL-reward task with
   the same `REWARD_REQUIRED` error (mapped to `409` in `modules/lifecycle/routes/claims.js`).
   This catches the residual case where a row reached `ready` by some path other than the
   promote route, or had its reward zeroed after promotion. It mirrors the existing
   `DEPS_NOT_SHIPPED` claim backstop (second line of defence behind the promote gate).

All three resolve through one shared pure helper, `db.rewardGateError(task, { grandfathered })`,
so the route, the claim path, and the unit tests can never disagree (the
`deriveRequiredRank` / `highestRank` precedent).

## Grandfathering — never strand existing work

The critical constraint: this change must **not** make any currently-claimable task
unclaimable, and must **not** retro-demote any `ready` task to `backlog`. We grandfather
explicitly with a dedicated flag rather than a fragile timestamp cutoff (`promoted_at` is
not reliably stamped — `updateTaskStatus` doesn't set it):

- Migration 177 adds `tasks.reward_gate_exempt boolean NOT NULL DEFAULT false` and sets it
  `true` for **every task already at or past `ready`** (`status IN ('ready','active',
  'completed','confirmed','shipped')`). Those ~57 zero-reward `ready` tasks — and any
  in-flight work — are permanently exempt: `rewardGateError` returns `null` for them, so
  the claim backstop lets them through.
- **New** tasks default `reward_gate_exempt = false`, so the gate applies only to
  transitions happening *after* this change.
- The predicate change is **forward-only by construction**: the auto-promotion triggers
  fire on later ship/satisfy/achieve events and only ever flip `backlog → ready`. They
  never re-evaluate a row already in `ready`, so no demotion can occur. (And the exempt
  rows would pass the predicate's reward clause anyway.)

Net effect: existing claimable + in-flight work is untouched; the gate bites only on the
next promotion or claim of an unrewarded task.

## Anti-gaming — the reward stays author-set

[ADR 0023](<redacted>.md) makes `credits_reward` an author-set,
review-gated value on purpose (auto-deriving it from `est_minutes` would be trivially
gameable — inflate the estimate, inflate the payout). This ADR preserves that stance:

- We do **not** auto-derive or auto-apply `credits_reward`. The refusal MAY *suggest* a
  value (`suggestCreditsReward` — ~1 drachma per estimated minute, weighted by a coarse
  per-kind factor, floored at 5), but a human must confirm it via `PATCH /tasks/:id`.
- Setting the reward is the existing `PATCH /tasks/:id` path — no new write surface. The
  gate only requires the value to be *present and positive*, never that it match the
  suggestion.

## Coordination — backfilling the existing zero-reward tasks

The grandfathered ~57 tasks remain claimable at 0 reward by design (so we don't strand
them), but they still *should* be valued. That backfill is tracked separately as
**<redacted>** (task 1672) — it walks the grandfathered
zero-reward tasks and assigns each an author-set value. Once a task is backfilled to a
positive reward it no longer depends on its exempt flag to be claimable. The
`reward_gate_exempt` column can be retired in a later migration once the backfill is
complete and no zero-reward `ready` tasks remain.

## Consequences

- No task created/promoted/claimed after this change can be worked while paying 0 drachmae.
- Existing `ready` + in-flight zero-reward tasks stay fully workable (grandfathered).
- The promote/claim refusals name the way forward (suggested value + the `PATCH` call),
  matching the `TASK_NOT_READY` actionable-hint precedent ([#952](https://example.com/builders#/task/952)).
- One new column (`reward_gate_exempt`), one `CREATE OR REPLACE` of an existing predicate,
  no data loss; the migration is idempotent and a clean no-op on replay.

---

## Amendment — 2026-06-28 (task [#1673](https://example.com/builders#/task/1673)): AUTO-ASSIGN at the gate, don't BLOCK

The original decision above made a missing reward **block** the two workable transitions
(promote returned `409 REWARD_REQUIRED`; the claim backstop threw the same). In practice
that turned a missing-value into a hard wall: a perfectly good task with a deps-met,
ready-to-work footprint could not be promoted or claimed until someone hand-set a value
first. That is friction the methodology doesn't want — the goal is "no task is worked for
0 drachmae", not "stop work until a human types a number."

**The shift: the gate now AUTO-ASSIGNS a fair, capped value and PROCEEDS.**

- **Promote-to-ready (`POST /tasks/:id/promote`).** When `credits_reward` is 0/NULL it
  assigns `suggestCreditsReward(task)` (persisted via `db.setCreditsReward`), then flips to
  `ready` and returns `{ ok: true, assigned_credits_reward: N }`. No refusal. The shared
  decision is `db.rewardGateAssignment(task)` (returns `{ assign: N }` or `null`).

- **Claim (`db.claimTask`).** Same — if 0/NULL at claim time it assigns the capped
  suggestion **inside the existing `FOR UPDATE` transaction**, so the assignment and the
  claim commit atomically, then proceeds. This also gives the ~27 grandfathered
  `reward_gate_exempt` zero-reward tasks a real payout the moment they're claimed.

- **Auto-promote predicate (migration 178).** The reward clause migration 177 added to
  `task_is_fully_unblocked` — `(reward_gate_exempt OR credits_reward > 0)` — is **reverted**:
  the predicate returns to the migration-163 dependency-doneness check **only**. Auto-promotion
  no longer blocks on reward, because claim-time auto-assign covers every task before any work
  starts. A deps-shipped task auto-promotes `backlog → ready` even at 0 reward; it gets valued at claim.

- **`reward_gate_exempt` is now inert.** Nothing reads it anymore (the gate auto-assigns
  regardless of the flag). The column is left in place; a later migration may drop it once the
  task-1672 backfill is complete (same retirement plan as the original "Coordination" section).

### Anti-gaming — the cap + the audit (this reverses ADR 0023's strict author-set stance, narrowly)

[ADR 0023](<redacted>.md) made `credits_reward` strictly
author-set precisely because auto-deriving it from `est_minutes` is gameable (inflate the
estimate → inflate the pay). Auto-assigning at the gate crosses that line — so two guards
contain the blast radius:

1. **CAP.** `suggestCreditsReward` is capped at `REWARD_SUGGESTION_CAP = 60` drachmae. The
   formula stays modest (~1 drachma/estimated-minute, weighted by a coarse per-kind factor,
   floored at 5), and the cap bounds how far an inflated estimate can push the *auto-assigned*
   value. Anyone who genuinely needs more sets `credits_reward` by hand via `PATCH /tasks/:id`
   — the ADR 0023 author-set, review-gated path is untouched for explicit values.

2. **AUDIT.** Every auto-assignment logs a `[reward-gate] AUTO-ASSIGN task N credits_reward
   -> V` line (with the actor: `[promote]` or `[claim by builder B]`), and the `credits_reward`
   change is itself visible on the task. The assignment is never silent.

3. **The PRIMARY pay driver is unchanged and ungameable.** Builder earnings are driven by the
   **cost-plus session reward** ([ADR 0054](<redacted>.md)) —
   `round(true_cost_usd × 1.20)` per shipped session, derived from real token cost, not from
   any author-set or auto-derived per-task number. The per-task `credits_reward` is a modest,
   capped floor on top of that; capping it keeps the gameable lever small.

### Net effect

No task is ever worked for 0 drachmae **and** no promote/claim is ever blocked for a missing
value. The friction is gone; the economy stays funded; the gameable surface is a capped,
audited floor sitting under the ungameable cost-plus primary reward.

## Amendment — 2026-06-28 (task [#1677](https://example.com/builders#/task/1677)): assign at CREATION — the PRIMARY point; promote/claim is the BACKSTOP

The first amendment moved assignment to the two *workable* transitions (promote, claim). That
still left a window: a freshly **created** `backlog` task read `credits_reward = 0` until it was
later promoted or claimed. The owner's intent is stronger — **every task should carry a fair
drachmae value from the moment it is born**, so anyone reading the backlog sees real numbers, not
zeros waiting to be filled in.

**The shift: creation is now the PRIMARY assignment point; promote/claim becomes the backstop.**

- **`db.createTask` (the lowest create layer).** When the caller supplies no positive
  `credits_reward` (null/undefined/0), `createTask` auto-assigns `suggestCreditsReward({ kind,
  est_minutes })` — the same capped (`<= REWARD_SUGGESTION_CAP`) helper — **before the INSERT**, so
  the row is born with a value. An explicitly-provided **positive** value is respected, never
  overridden (the author-set path stays intact). Putting the default here means **every**
  create-vector inherits creation-time assignment automatically: `POST /tasks`, idea-promotion,
  newcomer-restock, the Discord `#bugs → task` flow, and any seed script — all call `createTask`.

- **`POST /tasks` route.** Its `credits_reward: body.credits_reward ?? 0` default flows a 0/absent
  value into `createTask` as "unset" (so the creation default fires), and the `201` response now
  surfaces the assigned `credits_reward` so the creator immediately sees the value the task was
  born with.

- **Audit.** `createTask` logs `[reward-gate] AUTO-ASSIGN task N credits_reward -> V (cap …)
  [creation]` on each creation-time fill; the visible `credits_reward` on the row is the other half
  of the trail.

- **The promote/claim auto-assign (the first amendment) is KEPT as a BACKSTOP.** It now fires
  rarely — new tasks already carry a value — but it still covers any legacy row created before this
  change, or any edge path that somehow births a 0-reward task. Defence in depth: creation is the
  primary point, promote/claim the safety net.

The **cap + anti-gaming reasoning is unchanged** — the same `REWARD_SUGGESTION_CAP` bounds the
auto-assigned floor, and the ungameable cost-plus session reward ([ADR 0054](<redacted>.md))
remains the **primary** pay driver. This per-task value stays a modest, capped, audited floor; it
just now lands at birth instead of at first-work.

### Net effect (post-1677)

Every task is born with a fair, capped drachmae value. The backlog never shows a placeholder zero;
promote/claim no longer carries the assignment weight (it's a backstop); the economy stays funded
end-to-end with the same anti-gaming ceiling.
