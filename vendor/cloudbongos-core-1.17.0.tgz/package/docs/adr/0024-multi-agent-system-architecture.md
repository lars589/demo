# 0024 — Multi-Agent System (MAS) architecture

- **Status:** Accepted — all phases shipped (Phase 4.5, autonomous background dispatch, shipped [#458](https://example.com/builders#/task/458); INERT until `OTB_AUTONOMY_ENABLED=1`). See *Phase plan & implementation history* below.
- **Date:** 2026-05-29 (Phases 1–3); 2026-05-30 (Phases 4–5); Phase 6 + C7 followed.
- **Deciders:** Lars Kristensen (Archon), Claude
- **Track:** `internal` (GDS)
- **Supersedes:** none. Extends [ADR 0010](0010-pms-architecture.md) (GDS architecture), [ADR 0016](<redacted>.md) (trust boundary), [ADR 0017](<redacted>.md) (economy lens — the first piece of the Grader's worker decomposition).

## Context

As the GDS opens to multiple builders, three structural risks scale faster than headcount:

1. **The ship-time grader is lenient by construction.** [`src/bongos/grader.js`](../../src/bongos/grader.js) v2 (V3.R18 / [#209](https://example.com/builders#/task/209)) runs a *single* Opus subagent against the diff. Opus wrote the code; Opus grades it. Academic LLM-as-judge work (Zheng et al. 2023, Chiang & Lee 2023) consistently documents ~10–15% same-family inflation. The prompt asks "what score?" rather than "find what's wrong, then decide if it passes" — the default-to-pass framing is the bias. The recorded 14-day passing rate (65/75 = 87%) is suspiciously high for un-calibrated work.

2. **Methodology hygiene is reactive.** Documentation drift, dead code, and architectural sprawl are caught (if at all) by `overnight-code-review` and `repo-simplify-sweep` — both downstream of merge, both advisory, both already overfilling. No upstream gate looks at the *system* the way the grader looks at the diff.

3. **No standing entity watches the symphony.** Cron routines fire on a clock; skills fire when a builder remembers to invoke them. Nothing watches a builder's session in flight and dispatches the right specialist at the right moment.

The user-proposed agent hierarchy (Conductor → Delegators → Workers) is a 3-tier orchestrator that names these gaps. The research literature (Anthropic's multi-agent research system, "Building Effective Agents" patterns, MetaGPT post-mortems) consistently shows 2-tier orchestration beats 3-tier in practice: deeper hierarchies amplify intent-loss between layers. The decision below collapses the proposal to 2 tiers while keeping the user's specialization intent.

## Decision

Adopt a **2-tier multi-agent architecture** with one persistent agent and three on-demand roles, building incrementally over six phases.

### The cast

```
                       ┌──────────────────┐
                       │    CONDUCTOR     │  persistent · Opus
                       │  (UserPromptSubmit hook)
                       │  watches triggers, suggests / dispatches
                       └────────┬─────────┘
                                │  proposes — never disposes (no new permissions; inherits builder rank)
        ┌───────────────────────┼───────────────────────┐
        ▼                       ▼                       ▼
   ╔══════════╗            ╔══════════╗            ╔══════════╗
   ║  GRADER  ║            ║ ARCHITECT║            ║   BFG    ║
   ║ on /ship ║            ║quarterly ║            ║post-ship │
   ╚════╤═════╝            ╚════╤═════╝            ╚════╤═════╝
        │                       │                       │
   ┌────┴────┬─────────────┐  audits → idea_inbox  CLAUDE.md ↔ reality
   ▼         ▼             ▼                       memory graph hygiene
HACKER    NARC      EFFICIENCY                     (no workers yet)
red-team  completion MONGER
                    cost/perf
```

**One persistent agent: the Conductor.** Implemented as a `UserPromptSubmit` hook in `.claude/settings.json`. Runs per builder turn. Inherits the builder's rank — no new authority. Output is advisory: it suggests `/builder-redteam` on security-sensitive edits, suggests Grader pre-flight before `/builder-ship`, dispatches BFG after doc edits, and so on. **Conductor proposes; the builder confirms.** Anything that touches a rank-gated route still goes through the existing DB-enforced check ([ADR 0016](<redacted>.md)) — the Conductor cannot grant or bypass authority.

**Three invoked roles, summoned by trigger, not persistent:**

- **Grader** (on `/builder-ship`). The ship-time gate. Phase 1 makes it strict (default-fail framing + cross-family Sonnet grading Opus's work + 3-shot unanimous-PASS); Phase 2 decomposes it into a worker panel: *Narc* (semantic completion — task description vs diff), *Quality* (code quality + advisory economy), *Hacker* (security red-team — wraps `/builder-redteam` as a CI gate), *Efficiency Monger* (runtime cost / hot-path performance). Unanimous-PASS gate; non-unanimous falls through to the manual-confirm release valve. Plus a deterministic route-rank pre-pass (C7).
- **Architect** (quarterly cadence + Conductor nudge). Bounded-scope audits feed `docs/audits/<scope>-<date>.md` + `idea_inbox` seeds. Each quarterly audit becomes the foundational input for the next version's planning session. *No workers yet* — the Architect does its own work flexibly per the user's "delegators without workers do the work themselves" rule.
- **BFG** (post-ship + pre-cron). Memory + index hygiene at its root — audits CLAUDE.md claims against DB reality, prunes stale references, verifies `[[links]]` resolve. **Widened in [ADR 0026](<redacted>.md) and now shipped (Phase 6 complete):** it also adds DB counter-vs-ledger drift checks (6A.2), scores builders + propagates transferable practice (6B), and operates the audited cross-builder memory WRITE path for dreams + transparent corrections (6C). *No grader-style workers — it does its own work (the "delegators without workers do the work themselves" rule).* Vector-store retrieval still deferred — the MEMORY.md graph + frontmatter suffices.

### Why 2 tiers, not 3

The user's original proposal had Conductor → Delegator → Worker. Three reasons to collapse:

1. **Empirical.** Anthropic's multi-agent research system is deliberately 2-tier; their published numbers (90% improvement on breadth-first research, 15× tokens) are for that shape. No published multi-agent system the team has read about achieves better-than-2-tier coordination at scale.
2. **Information loss.** Every hand-off between agents is a lossy translation of intent. Three hops compound. The Conductor → Worker direct path keeps intent intact.
3. **The middle tier was a category error.** A "Delegator that has no workers does the work itself" is just a *Specialist* with a fancier name. Reifying the middle creates a permissions question (can a Delegator grant Workers powers it doesn't have?) and an attribution question (who gets the credit / blame?) that 2-tier sidesteps.

The user's specialization intent is preserved: the Grader runs a worker panel; the Architect and the BFG do their own work (no grader-style workers) and can grow them if the "do it repeatedly → codify as worker" rule ever fires.

### The Musk algorithm applied to the proposal

Musk's 5-step engineering algorithm: (1) make requirements less dumb, (2) delete, (3) simplify, (4) accelerate, (5) automate — "if you're not adding 10% back, you didn't delete enough." Applied to the original proposal:

- **Project Manager (deleted):** what the Conductor does. Reprioritization *is* conducting. Splitting it doubles the surface for no specialization.
- **Janitor (deleted as standalone, merged into Architect):** cleanup is downstream of an architecture decision ("delete X"). The existing `repo-simplify-sweep` + `overnight-code-review` crons already cover the autonomous cleanup loop; the Architect's audit work *feeds* them.
- **BFG vs Architect (kept separate):** boundary sharpened. BFG owns *current truth* (memory hygiene, live state). Architect owns *future structure* (forward-looking design, version-foundation audits). Distinct enough they won't fight over files.

Reduced cast: **4 agents, not 6** (1 persistent + 3 invoked).

**Grader strictness — strict-first, loosen-later.** The grader is the load-bearing first change (its output is consumed by every shipped task). It does not relax during calibration; if it stalls genuine work we tune the prompt, not the gate, with the manual-confirm endpoint (`POST /tasks/:id/confirm`) as the emergency release valve. New grader signals (`shots[]`, `grader_model`, per-worker scores) land in the jsonb `task_grades.signals` column with no migration; top-level `rubric_scores` get the median across shots. This mirrors how the economy lens earned its teeth ([ADR 0017](<redacted>.md)): advisory → calibrate → gate.

## Phase plan & implementation history

Built incrementally over six phases, each independently shippable and required to earn its keep before the next ("is this earning its tokens?" — delete the phase if not). **All shipped:**

- **1** — strict grader: default-fail framing + cross-family Sonnet + 3-shot unanimous.
- **2** — the grader's 4-worker panel (Narc · Quality · Hacker · Efficiency Monger) replacing the 3-shot generalist, unanimous-PASS gate; + server audit-trail forwarding of `security_score`/`efficiency_score`.
- **3** — Conductor as a deterministic (zero-LLM) `UserPromptSubmit` hook, advisory only.
- **4** — Conductor **session-mediated** dispatch (`scripts/gds/conductor-dispatch.js` runs any specialist on the working diff, reusing the grader-workers machinery).
- **4.5** — Conductor **autonomous background** dispatch (`conductor-dispatch.js auto-dispatch`): selects the next claimable autonomous task *without a human prompt* and emits its `/builder-claim` directive for a runner to execute. It **proposes, never disposes** in the autonomous path too — the selector emits the directive; the runner + ship pipeline (where ADR 0016's DB gates and the grader still bite) is what claims, builds, and lands. Gated by the same `scripts/gds/autonomy-gate.js` precheck the nightly routines use (master kill-switch + MTD spend brake + no-signal skip), so it is **INERT until `OTB_AUTONOMY_ENABLED=1`**. The candidate feed is the protected-path-filtered `fit:'autonomous'` view (SR-12) — the permission/methodology/deploy core can never be auto-selected.
- **5** — Architect role + first audit (`scripts/gds/architect-audit.js --scope` → `docs/audits/` + idea_inbox seeds; on-demand, not cron'd).
- **6** — BFG built out well past bootstrap (doc/index + per-builder memory hygiene, DB counter-vs-ledger drift, cross-builder read + interaction-quality scoring, and the first audited cross-builder memory WRITE path — identity-gated, kill-switched, builder-reversible). Charter: [ADR 0026](<redacted>.md); session-inefficiency evaluator (cluster 6D): [ADR 0027](<redacted>.md).
- **C7** — the grader's deterministic **route-rank pre-pass** (`src/bongos/route-rank-check.js`, shared via `grader.routeRankPrePass()` by the ship-time panel and `conductor-dispatch.js`): every route must classify to a known rank; write-route `unknown` → hard fail. The deterministic-first → LLM-on-demand pattern; C7's periodic auditor, in-context at ship time.

Per-phase scope, rationale, "out of scope", and ship detail (incl. the Phase-1 first-ship calibration data + the `Number(null)=0` self-ship learning) live in the shipping tasks + the session logs — this ADR is the decision record, not the changelog. Phase tasks: [#395](https://example.com/builders#/task/395) (1) · [#410](https://example.com/builders#/task/410)/[#413](https://example.com/builders#/task/413)/[#416](https://example.com/builders#/task/416)/[#421](https://example.com/builders#/task/421)/[#423](https://example.com/builders#/task/423) (2) · [#427](https://example.com/builders#/task/427) (3) · [#439](https://example.com/builders#/task/439) (4) · [#459](https://example.com/builders#/task/459) (5) · [#442](https://example.com/builders#/task/442)–[#448](https://example.com/builders#/task/448) (6) · [#475](https://example.com/builders#/task/475) (C7) · [#458](https://example.com/builders#/task/458) (4.5).

## Consequences

**Good:**

- The trust gate at `/builder-ship` actually bites. Calibration data — not vibes — drives future tightening.
- Cost is ~neutral: 3× Sonnet ≈ 1× Opus (prior). Grader cost-per-shipped-task does not balloon.
- Architecture-ready for per-builder model preferences ([ADR 0021](<redacted>.md)): when GDS-V4 ships builder-configurable model allocation, the `selectGraderModel(builderModel)` function becomes the obvious extension point.
- Trust boundary preserved: nothing here grants new permissions; the Conductor (Phase 3+) inherits builder rank and proposes, never disposes ([ADR 0016](<redacted>.md) stays load-bearing).
- The original Delegators (Project Manager, Janitor) are *deleted* rather than built — the Musk rule applied to ourselves.

**Bad / accepted:**

- <redacted> will likely stall at `completed`. Builders need to know this; the deploy banner should warn.
- Sonnet may grade Sonnet builders same-family (when those exist). The cross-family premise assumes Opus builders. Phase 2's per-builder model-selection logic fixes this; Phase 1 accepts the assumption.
- Three concurrent Sonnet subprocess invocations slow ship by ~1.5× the longest single shot (parallel, not serial — but the slowest shot still gates). Acceptable trade vs the leniency cost.
- If 3 Sonnets agree too much (insufficient disagreement signal), the unanimous gate is theatrical. Calibration window will reveal this; Phase 1.5 mixes Opus into the panel if needed.

**Reversibility:**

- Phase 1 can be reverted by setting the rubric's `v3` entry's `shots: 1` and `default_model: claude-opus-4-7` (the field is `default_model`, not `model` — the latter is the v2 field name). The shot-aggregation code stays; the policy reverts. No migration needed.
- The MAS hierarchy as a whole is reversible up through Phase 6. The persistent Conductor hook is the only piece that, once wired, will create dependency on its trigger taxonomy; deleting the hook restores prior behavior.

## References

- [ADR 0010](0010-pms-architecture.md) — GDS (then PMS) architecture
- [ADR 0016](<redacted>.md) — trust boundary (Conductor must not bypass)
- [ADR 0017](<redacted>.md) — economy lens (first Grader worker, retroactively)
- [ADR 0021](<redacted>.md) — per-builder model preferences (Phase 1's hardcoded Sonnet generalizes here)
- Anthropic, "Building Effective Agents" (Schluntz & Zhang, Dec 2024) — orchestrator-workers and evaluator-optimizer patterns
- Anthropic, "How we built our multi-agent research system" (Engineering blog, 2025) — empirical 2-tier orchestration, ~15× token cost
- Zheng et al., "Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena" (NeurIPS 2023) — same-family judge inflation
- Chiang & Lee, "Can Large Language Models Be an Alternative to Human Evaluations?" (ACL 2023) — LLM-judge sycophancy
- Musk's 5-step engineering algorithm — applied to the proposal itself, not just to its outputs
