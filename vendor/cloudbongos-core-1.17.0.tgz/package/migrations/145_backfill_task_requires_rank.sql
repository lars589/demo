-- 145_backfill_task_requires_rank.sql — task 1498 / ADR 0084.
--
-- WHY: tasks.requires_rank (V3.R82, migration 044/068) shipped INERT — no
-- create/edit path ever set it, so every task sits at the 'xenos' default and
-- the claim-time rank gate (db.claimTask / claimTasksBatch) never bites. Going
-- forward db.deriveRequiredRank (reusing permission-path-check.matchProtected)
-- is the LIVE authority: it derives a floor on every create/PATCH. This one-time
-- pass brings EXISTING open tasks up to the same floor so the whole board is
-- correctly rank-scoped now, not just new work (Lars's directive, 2026-06-23).
--
-- RULE (mirrors deriveRequiredRank): a non-terminal task floors at 'metic' when
-- it is security_sensitive OR any touches[] entry hits the permission-sensitive
-- set. The conditions below are GENERATED from PROTECTED_GLOBS in
-- src/bongos/permission-path-check.js (the single source of truth) as of 2026-06-23
-- — every glob there is an exact file or a trailing-'/' directory prefix with no
-- '*'/'**' wildcard and no LIKE-special char, so prefix LIKE / exact '=' is an
-- exact translation (the generator asserts this). permission-path-check.js stays
-- authoritative: a future glob change does NOT rewrite this historical snapshot
-- (new/edited tasks re-derive through the JS helper). Regenerate with
-- the throwaway gen step if you ever need to re-snapshot.
--
-- SAFE + IDEMPOTENT: only raises the default ('xenos' -> 'metic'); never lowers
-- a floor and never touches a deliberate override. Re-running matches no rows.

UPDATE tasks
   SET requires_rank = 'metic', updated_at = now()
 WHERE status NOT IN ('shipped', 'abandoned')
   AND requires_rank = 'xenos'        -- only raise the default; leave overrides alone
   AND (
        security_sensitive = true
     OR EXISTS (
          SELECT 1 FROM unnest(touches) AS f
           WHERE
              f LIKE 'src/bongos/middleware/%'
           OR f LIKE 'src/bongos/routes/%'
           OR f LIKE 'src/bongos/grader-workers/%'
           OR f LIKE 'scripts/gds/hooks/%'
           OR f LIKE 'scripts/deploy/%'
           OR f LIKE 'migrations/%'
           OR f LIKE 'infra/%'
           OR f LIKE '.github/%'
           OR f LIKE '.husky/%'
           OR f LIKE '.claude/hooks/%'
           OR f = 'src/bongos/auth.js'
           OR f = 'src/bongos/db.js'
           OR f = 'src/bongos/route-rank-check.js'
           OR f = 'src/bongos/permission-path-check.js'
           OR f = 'src/bongos/routes.js'
           OR f = 'server.js'
           OR f = 'src/bongos/boxes.js'
           OR f = 'src/bongos/box-access.js'
           OR f = 'src/bongos/box-credential.js'
           OR f = 'src/bongos/grader.js'
           OR f = 'src/bongos/grader-rubric.json'
           OR f = 'scripts/gds/ship.js'
           OR f = 'scripts/gds/confirm.js'
           OR f = 'scripts/gds/merge-mode.js'
           OR f = 'scripts/gds/ci-grade.js'
           OR f = 'scripts/gds/grade-smoke.js'
           OR f = 'scripts/gds/conductor-dispatch.js'
           OR f = 'scripts/gds/main-audit.js'
           OR f = 'scripts/gds/push-main.js'
           OR f = 'scripts/gds/run-unit-tests.js'
           OR f = 'scripts/gds/gate-review.js'
           OR f = 'scripts/gds/setup.js'
           OR f = 'scripts/gds/install-git-hooks.js'
           OR f = 'scripts/gds/cli-lib.js'
           OR f = 'scripts/migrate.sh'
           OR f = 'src/bongos/merge-lock.js'
           OR f = 'src/bongos/ship-preflight.js'
           OR f = 'CODEOWNERS'
           OR f = 'config/deploy.json'
           OR f = 'package.json'
           OR f = 'package-lock.json'
           OR f = 'docs/canonical-permissions.md'
           OR f = 'docs/adr/0016-trust-boundary-server-enforced-permissions.md'
           OR f = 'docs/adr/0043-git-ssh-trust-boundary-and-rank-floor-on-permission-paths.md'
           OR f = 'CLAUDE.md'
           OR f = '.claude/settings.json'
        )
       );

INSERT INTO schema_migrations (version) VALUES ('145_backfill_task_requires_rank')
  ON CONFLICT (version) DO NOTHING;
