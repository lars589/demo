# 0012 — Ground-object cell split: terrain becomes ground + sparse object layer

- **Status:** Accepted
- **Date:** 2026-05-09
- **Deciders:** Lars
- **Supersedes (in part):** [ADR 0011](./0011-terrain-id-rendering-model.md) — extends its data model; the dispatched render-strategies architecture stays valid.

## Context

[ADR 0011](./0011-terrain-id-rendering-model.md) established that each
map cell stores a TERRAIN id and the renderer dispatches per terrain to
a render strategy (`single` / `blob47` / `path16`). It worked, but the
first browser session uncovered a structural bug: the V1 top band has
GRASS, SAND, and ROCK randomly intermixed (1/11 rock, 3/11 sand,
7/11 grass), and the autotile picker — which checks `n === my` for
each neighbor — treated rocks and sand as "different from grass" the
same way. Every grass cell with a rock neighbor rendered a boundary
tile, even though a rock isn't a kind of land — it's a thing sitting
on land. The result was a marble-flagstone appearance instead of the
intended meadow.

A scoped fix (per-terrain `interiorEquivalents` to mark "rocks count
as same-as-grass for the picker," option B in the scoping note) would
have removed the artifact in ~12 LOC. We chose to pay down the deeper
debt instead, because:

1. The wider problem is conflation: a single terrain id at every cell
   tries to mean both "what's the visual surface here" AND "what's
   blocking movement here." That conflation breaks at any cell whose
   surface differs from its overlay (rocks on grass, containers on
   sand, future trees / fences / signs / item drops on whatever).
2. The world is about to grow. Doing the architectural split now,
   while the map is small and entirely procedural, costs ~2 hours.
   Doing it later, after we've baked the assumption into level data,
   gameplay events, and persistence, costs much more.
3. Industry-standard tile renderers (Tiled, RPG Maker, FireRed itself)
   separate ground tiles from object overlays. Aligning with that
   convention makes future contributions cheaper.

## Decision

Each cell carries TWO independent pieces of data:

- **Ground terrain** — always defined. Drives the autotile renderer.
  Walkable unless declared in `BLOCKING_TERRAINS`. The set is small
  and stable: `GRASS`, `SAND`, `SEA`, `MARBLE_PATH`. Future additions
  are alternative ground types.
- **Object** — optional (zero or one per cell in V1; lists in V2 if
  needed). Painted in a second draw pass at depth 1. May block
  movement (`BLOCKING_OBJECTS`). Currently: `ROCK` plus the 8
  `CONTAINER_PANEL_*` ids that compose the shipping container.

`INITIAL_MAP` exports `{ ground, objects }` — two parallel 2D arrays.
Both client (`public/game/world/map.js`) and server (`src/world/map.js`)
build them with identical logic. The shape is JSON-serializable for
the eventual move to a Postgres-backed map.

The autotile picker (`pickAutotileIndex` in
[`public/game/world/terrain.js`](../../public/game/world/terrain.js))
takes the ground grid only. Objects never enter its view. That is the
core invariant that fixes the marble-flagstone artifact: a grass cell
with a rock object on top is, to the picker, just a grass cell — its
neighbors are ground terrains too, and only sand neighbors at the
y=6 transition trigger the autotile boundary tile.

### Render pipeline

`WorldScene.drawMap(map)` runs two passes:

1. **Ground pass.** For every cell, paint
   `pickGroundTextureKey(scene, map.ground, x, y)` at depth 0. Uses the
   autotile dispatch from ADR 0011.
2. **Object pass.** For every cell where `map.objects[y][x]`, paint
   `pickObjectTextureKey(scene, map.objects, x, y)` at depth 1. Single-
   tile per object id; no autotile dispatch on the object layer.

Vendor and player sprites continue to live at higher depths (8 and 10
respectively) above objects. The vendor at (13, 9) sits visually atop
the door panel object, exactly as before.

### Walkability

`isBlocked(x, y)`:
```
out-of-bounds              → blocked
ground in BLOCKING_TERRAINS  → blocked   (SEA only, in V1)
object in BLOCKING_OBJECTS   → blocked   (ROCK + 8 container panels, in V1)
otherwise                    → walkable
```

Server (`src/world/map.js`) is the source of truth for movement
validation. Client honors the same rule for prediction. Both read from
the same shared `terrain.js` enums + sets. Tests in
[`tests/walkability.mjs`](../../tests/walkability.mjs) exercise the
server module directly to guard against drift.

### Asset implications

- `rock_small.png` (AI-generated, currently RGB no-alpha): renders
  opaquely on top of the ground autotile. Acceptable for V1 — the rock
  visually fills its cell, identical to the pre-split look. The win
  is in the surrounding GRASS cells, which now render smooth meadow
  instead of marble-flagstone borders. Future polish: regenerate with
  magenta-key transparent BG so the autotiled grass shows through at
  the rock's corners (~$0.04). Not blocking V1.
- The procedural rock fallback in [`tilePalette.js`](../../public/game/world/tilePalette.js)
  was updated to drop its grass-green BG fillRect — the canvas is
  transparent by default, so the procedural rock now correctly shows
  the underlying ground at corners.
- Container panels: stay opaque. The container is a solid building
  covering its 8 cells of sand. Opaque is correct.

### Cross-verify safety

The Python↔JS autotile lookup table cross-verifier
([`tests/autotile_xverify.mjs`](../../tests/autotile_xverify.mjs))
tests `selectBlob47` / `selectPath16` directly — unchanged by this
ADR. Picker behavior change is captured in the new
[`tests/terrain_picker.mjs`](../../tests/terrain_picker.mjs), which
asserts the ground-only invariant.

## Consequences

### Positive

- **The marble-flagstone bug is gone by construction.** The picker
  cannot see objects, so rocks (and any future overlays) cannot
  pollute boundary tile selection.
- **Clean walkability.** Movement rules read like the intent: "is the
  ground impassable, OR is the object impassable?" No more entanglement
  between visual identity and blocking.
- **Future objects are nearly free.** Trees, signs, fences, item
  drops, multi-tile structures all slot in as new `OBJECT` enum
  entries + manifest tile + (if blocking) `BLOCKING_OBJECTS` entry.
  No renderer changes per addition.
- **Container scales.** Adding a second container, a market stall, a
  multi-cell tent — all just place more object-cell sets. The picker
  paints clean ground around each.
- **Persistence-ready data shape.** `objects[y][x]` maps directly to
  a `(x, y, object_id)` table when player-placed objects need to
  persist. `ground[y][x]` maps to a separate ground table that
  rarely changes.
- **Aligned with industry convention.** Tiled, RPG Maker, FireRed all
  use ground + object layers. Future contributors recognize the model.

### Negative / costs

- **Two-file mirror tax doubles** — now `terrain.js` AND `map.js` each
  exist as CJS server + ESM client twins (4 files). Same fix as before:
  consolidate when the world becomes data-driven from Postgres.
- **Container is 8 distinct object ids** rather than an anchor + 2×4
  footprint. Per-cell is simpler for V1; anchor-based becomes
  attractive when we have many multi-tile structures (V2+).
- **Z-order between objects is V1-flat** — every object renders at
  depth 1. A future "tall object in front of player" effect needs
  per-object depth-sort by `(y + footprint_height)`. Not urgent.
- **Per-cell object limit is one** in V1. A flower next to a sign in
  the same cell would need `objects[y][x]: string[]`. Trivial to lift
  when needed.

### What this does not change

- ADR 0011's dispatched render strategies (`single` / `blob47` /
  `path16`) are unchanged. They now operate on the GROUND grid only.
- The autotile pipeline (ADR 0009) and the family pipeline (ADR 0008)
  are unchanged. Container panels are still generated by the family
  pipeline; their PNGs are interpreted as object overlays now.
- Vendor placement, dialog, interact semantics: unchanged. The vendor
  at (13, 9) still occupies the door cell. The cell is still blocked
  (now via object-blocking, was previously via terrain-blocking).
- The hardcoded V1 map geometry: unchanged. The container is still 4
  wide × 2 tall at anchor (13, 8); rocks scatter on the same noise
  function.
- Cost ledger and budget rules: unchanged.

## Migration path

Single commit, atomic switch. Server and client move together. The
`players` table has no terrain references (only x/y/facing); the
`world_events` table has no terrain references in payloads; nothing
external needs migrating. The Colyseus smoke tests in `/tmp/colyseus-*`
still validate movement against the same `isBlocked()` API surface.

## Testing

- [`tests/terrain_picker.mjs`](../../tests/terrain_picker.mjs) (10
  cases) — picker dispatch shape, neighbor lookup, ground-only
  invariant, path16 sanity (lone node = 0; cross junction = 15).
- [`tests/walkability.mjs`](../../tests/walkability.mjs) (13 cases) —
  enum sanity, isBlocking{Terrain,Object}, isBlocked over the actual
  INITIAL_MAP for sea / sand / grass / rock-on-grass / all 8 container
  cells / vendor cell / cell south of vendor / out-of-bounds.
- Both wired into `art/pipeline/smoke_test.sh` step 3b. The smoke test
  fails the build if either test fails.

## Future work this enables

- **Trees** (decorative, blocking): one OBJECT entry + tile.
- **Signs** (interactive, blocking, dialog payload): OBJECT entry +
  tile + a small `INTERACTIONS` map keyed by `(x, y)` consumed by
  `WorldScene.handleInteract`.
- **Item drops** (non-blocking, pickable): OBJECT entry + tile,
  exclude from `BLOCKING_OBJECTS`. Pickup is a server event that
  mutates `objects[y][x] = null` and broadcasts.
- **Multiple buildings / placed objects**: just place more
  object-cell sets. Ground autotile renders cleanly around them.
- **Persistent player-placed objects**: `objects` grid is the natural
  persistence shape (`(x, y, object_id)`).
