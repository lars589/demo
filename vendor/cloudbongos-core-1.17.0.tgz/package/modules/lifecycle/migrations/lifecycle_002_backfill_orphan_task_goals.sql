-- lifecycle_002_backfill_orphan_task_goals.sql — task 1763.
--
-- The goal-clean-up invariant: every task belongs to a goal. Going forward,
-- db.createTask defaults a goal-less new task into its version's catch-all
-- "<version> — general" goal (created by migration 160), so no NEW orphan is
-- minted by any create-vector. This one-time, idempotent backfill sweeps the
-- PRE-EXISTING orphan tasks into that same per-version general goal — the exact
-- mirror of migration 160's criterion backfill (same title match: the spaced
-- em-dash `<version_id> — general`; keep in sync with db.generalGoalIdForVersion).
--
-- PORTABLE + replay-safe: no instance data is hard-coded. On a fresh/vanilla DB
-- there are no orphan tasks (createTask assigns a goal from the first task), so
-- the UPDATE simply touches zero rows. A version with no general goal (should not
-- happen post-160, but defensively) leaves its tasks unlinked rather than erroring.
--
-- Instance-specific re-homing (e.g. OTB's hall-UI program tasks into a NAMED goal
-- like #25 rather than the catch-all) is deliberately NOT done here — that is
-- owning-instance data, applied under a claim via the PATCH /tasks/:id goal_id
-- endpoint this task adds, not shipped to every instance.

BEGIN;

-- Deliberately does NOT bump updated_at (mirrors migration 160's criterion
-- backfill): this is a one-time invariant cleanup, not a meaningful edit, so it
-- must not churn "recently updated" sort orders across every backfilled row.
UPDATE tasks t
   SET goal_id = g.id
  FROM goals g
 WHERE g.version_id = t.version_id
   AND g.title = t.version_id || ' — general'
   AND t.goal_id IS NULL;

INSERT INTO schema_migrations (version) VALUES ('lifecycle_002_backfill_orphan_task_goals')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
