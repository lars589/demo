-- 014_pms_task_discipline.sql — adds tasks.discipline.
--
-- tasks.kind classifies the TYPE of change (feature / bug / refactor / ...).
-- tasks.discipline classifies the BUILDER INTEREST AREA — orthogonal axis
-- so a builder can filter the work queue to what they actually want to do:
--
--   creative      — map/world recommendations, quests, narrative, visual art,
--                   level design, pixel-art pipeline work
--   engineering   — gameplay mechanics, infra, the PMS itself, performance,
--                   data plumbing, bug fixes that aren't visual
--   unclassified  — default for existing rows + new captures; gets triaged later
--
-- Applies to both tracks (product + internal). Existing rows stay
-- 'unclassified'; retroactive classification is a separate task.
--
-- The two existing tasks views that expose `SELECT t.*` (claimable_tasks,
-- tasks_session_fit) are rebuilt below so the new column flows through to
-- API consumers without a follow-up migration. version_progress and
-- version_lifecycle_breakdown project specific columns and don't need
-- rebuilding.
--
-- Idempotent: safe to re-run.

-- =========================================================================
-- 1. Column + CHECK constraint
-- =========================================================================

ALTER TABLE tasks
  ADD COLUMN IF NOT EXISTS discipline text NOT NULL DEFAULT 'unclassified';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'tasks_discipline_check'
  ) THEN
    ALTER TABLE tasks ADD CONSTRAINT tasks_discipline_check
      CHECK (discipline IN ('creative', 'engineering', 'unclassified'));
  END IF;
END$$;

-- =========================================================================
-- 2. Rebuild views that use SELECT t.* so the new column is exposed
-- =========================================================================

-- claimable_tasks — body identical to migration 006's definition. Rebuilt
-- only so SELECT t.* re-expands and picks up tasks.discipline.
DROP VIEW IF EXISTS claimable_tasks;
CREATE VIEW claimable_tasks AS
SELECT t.*
  FROM tasks t
 WHERE t.status = 'ready'
   AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
   AND NOT EXISTS (
     SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id
   )
   AND NOT EXISTS (
     SELECT 1 FROM claims c
       JOIN tasks t2 ON t2.id = c.task_id
      WHERE c.released_at IS NULL
        AND t2.touches && t.touches
   );

-- tasks_session_fit — body identical to migration 006's definition.
DROP VIEW IF EXISTS tasks_session_fit;
CREATE VIEW tasks_session_fit AS
SELECT t.*,
  CASE
    WHEN t.automation_tag = 'overnight-safe' AND COALESCE(t.manual_degree, 5) <= 2
         AND NOT EXISTS (SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id)
      THEN ARRAY['autonomous','check-in','active']
    WHEN t.automation_tag = 'live-only' OR COALESCE(t.manual_degree, 5) >= 4
      THEN ARRAY['active']
    ELSE ARRAY['check-in','active']
  END AS fits_session_modes,
  CASE WHEN t.credits_reward > 0 AND t.est_minutes IS NOT NULL AND t.est_minutes > 0
    THEN ROUND(t.credits_reward::numeric / t.est_minutes, 3)
    ELSE NULL
  END AS credits_per_minute
FROM tasks t;

-- =========================================================================
-- 3. Record migration
-- =========================================================================

INSERT INTO schema_migrations (version) VALUES ('014_pms_task_discipline')
  ON CONFLICT (version) DO NOTHING;
