-- 174_close_orphaned_claims_on_terminal_tasks.sql
-- task 1643 — one-shot backfill that pairs with the shipTask claim-close safety
-- net (src/bongos/db.js).
--
-- THE STRAND CLASS. A claim is normally closed by db.resolveClaim
-- (claimed→completed: UPDATE claims SET released_at=now()). The confirm paths
-- (confirmTask / override-confirm / grader-confirm) and shipTask
-- (confirmed→shipped) flip task status + award credits but never touch the
-- claim. So a task that reaches a terminal state WITHOUT going through
-- resolveClaim on that claim (strand recovery, direct-SQL fixups) leaves the
-- claim dangling released_at=NULL forever, and every claim-aware view (builder
-- dashboard, parallel-safety) keeps showing the shipped/confirmed task as
-- actively claimed. The stale-claim sweeper can't repair it — its release resets
-- the task to 'ready', which would un-ship a shipped task.
--
-- Live repro: task 1300 (BV1.R05) is correctly shipped (PR #410, on main) but
-- claim #1292 (builder 95) is still open. This closes #1292 and any siblings.
--
-- Going forward, shipTask closes open claims in the ship txn, so new ships can't
-- strand. This statement mops up the EXISTING backlog on terminal tasks.
-- Idempotent: a second run matches no rows (every such claim is already closed).
-- COALESCE preserves any outcome already recorded; an open claim has
-- outcome=NULL, so it lands 'shipped' (a valid claims.outcome CHECK value).
UPDATE claims c
   SET released_at = now(),
       outcome     = COALESCE(c.outcome, 'shipped')
  FROM tasks t
 WHERE c.task_id = t.id
   AND c.released_at IS NULL
   AND t.status IN ('shipped', 'confirmed');
