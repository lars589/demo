// modules/hall-ui/public/profile.js — the viewable builder profile page
// (/builders/profile, task 1467, goal 25 "bx-identity").
//
// A PUBLIC, shareable portfolio for one builder: rank, works shipped, standing
// (drachmae + karma), achievements, and recent works. Reads the public route
// GET /api/bongos/builders/:id/profile — every field it shows is already
// world-readable on the leaderboard, so unlike ranks.js/work.js this page does
// NOT hard-redirect a logged-out visitor to sign-in. Which builder to show comes
// from ?id=<numeric builder id>; with no id it soft-resolves the viewer's own id
// via /me (and shows a friendly empty state if the visitor is signed out).

(() => {
  'use strict';

  const API = '/api/bongos';
  // Generated typed client (task 1996), served as window.BongosClient. baseUrl:''
  // passes the full `${API}/...` URLs through unchanged; result mode
  // ({ status, ok, data }) preserves control flow 1:1. throwOnError:false so a
  // 401/404 is a value to branch on, not an exception.
  const api = window.BongosClient.createClient({ baseUrl: '', credentials: 'same-origin', throwOnError: false });

  const { escapeHtml, $, fmtNum, fmtDate } = window.OTB;
  const rankLabel = (rank) => window.OTB.rankLabel(rank);
  const toast = (msg) => window.OTB.toast(msg, { duration: 2600, clear: true });

  // The four live ranks (ADR 0018 + 0034). Reserved/legacy rank strings coerce
  // to 'xenos' for the badge, matching builders.js normalizeRank.
  const RANK_LADDER = ['xenos', 'thetes', 'metic', 'archon'];
  const normalizeRank = (rank) => (RANK_LADDER.includes(rank) ? rank : 'xenos');

  const curLabel = (caps) => {
    const l = (window.__BRANDING__ && window.__BRANDING__.currency && window.__BRANDING__.currency.label) || 'credits';
    return caps ? l.charAt(0).toUpperCase() + l.slice(1) : l;
  };

  function badge(rank) {
    const r = normalizeRank(rank);
    return `<span class="rank-badge rank-badge--${r}" aria-label="Rank: ${escapeHtml(rankLabel(r))}">${escapeHtml(rankLabel(r))}</span>`;
  }

  // ---- render: standing header --------------------------------------------

  function renderHead(builder) {
    const head = $('#profile-head');
    if (!head) return;
    const name = escapeHtml(builder.display_name || builder.github_login || 'Builder');
    const avatar = builder.avatar_url
      ? `<img class="profile__avatar" src="${escapeHtml(builder.avatar_url)}" alt="">`
      : `<div class="profile__avatar" aria-hidden="true"></div>`;
    const prefs = Array.isArray(builder.preferred_disciplines) ? builder.preferred_disciplines : [];
    const disciplines = prefs.length
      ? `<div class="profile__disciplines">
           <span class="profile__disc-label">Preferred work:</span>
           <span class="profile__disc-value">${escapeHtml(prefs.join(', '))}</span>
         </div>`
      : '';

    head.innerHTML = `
      ${avatar}
      <div>
        <div class="profile__name-row">
          <p class="profile__name">${name}</p>
          ${badge(builder.rank)}
        </div>
        <p class="profile__handle">@${escapeHtml(builder.github_login || 'unknown')}</p>
        <div class="profile__stats">
          <span>Member since ${fmtDate(builder.created_at)}</span>
        </div>
        ${disciplines}
      </div>
      <div class="profile__credits">
        <span class="profile__credits-num" title="${escapeHtml(curLabel(true))} — total payout from shipped work.">${fmtNum(builder.total_credits)}</span>
        <span class="profile__credits-label">${escapeHtml(curLabel())}</span>
        <span class="profile__karma" title="Karma — peer recognition and approvals, a separate counter from ${escapeHtml(curLabel())}.">
          <span class="profile__karma-num">${fmtNum(builder.karma)}</span>
          <span class="profile__karma-label">karma</span>
        </span>
      </div>`;
  }

  // ---- render: by the numbers ---------------------------------------------

  function tile(label, num, sub) {
    return `
      <div class="stat-tile">
        <span class="stat-tile__label">${escapeHtml(label)}</span>
        <span class="stat-tile__num">${num}</span>
        ${sub ? `<span class="stat-tile__sub">${escapeHtml(sub)}</span>` : ''}
      </div>`;
  }

  function renderNumbers(shippedCount, achievements) {
    const body = $('#numbers-body');
    if (!body) return;
    const achCount = Array.isArray(achievements) ? achievements.length : 0;
    body.innerHTML =
      tile('Works shipped', fmtNum(shippedCount)) +
      tile('Achievements', fmtNum(achCount), 'earned');
  }

  // ---- render: achievements shelf -----------------------------------------

  function renderAchievements(achievements) {
    const grid = $('#ach-grid');
    if (!grid) return;
    const list = Array.isArray(achievements) ? achievements : [];
    if (!list.length) {
      grid.innerHTML = `<div class="profile__placeholder">No achievements earned yet.</div>`;
      return;
    }
    // Every row the route returns is UNLOCKED (getBuilderAchievements joins the
    // builder_achievements ledger), so no locked/greyed variant is needed here.
    grid.innerHTML = list.map((a) => {
      const bonus = a.credit_bonus ? `<p class="ach__bonus">+${fmtNum(a.credit_bonus)} ${escapeHtml(curLabel())}</p>` : '';
      const when = a.unlocked_at ? `<p class="ach__bonus">Won ${fmtDate(a.unlocked_at)}</p>` : bonus;
      return `
        <div class="ach" title="${escapeHtml(a.achievement_id || a.name || '')}">
          <div class="ach__icon" aria-hidden="true">${escapeHtml(a.icon || '✦')}</div>
          <div class="ach__body">
            <p class="ach__name">${escapeHtml(a.name || '')}</p>
            <p class="ach__desc">${escapeHtml(a.description || '')}</p>
            ${when}
          </div>
        </div>`;
    }).join('');
  }

  // ---- render: recent works -----------------------------------------------

  function renderWorks(ships) {
    const tbody = $('#works-table tbody');
    const lede = $('#works-lede');
    if (!tbody) return;
    const list = Array.isArray(ships) ? ships : [];
    if (!list.length) {
      tbody.innerHTML = `<tr><td colspan="4" class="ledger__empty">Nothing shipped yet.</td></tr>`;
      if (lede) lede.hidden = true;
      return;
    }
    tbody.innerHTML = list.map((s) => {
      // credits_awarded is the actual ledger figure for a shipped task; fall back
      // to the creation-time estimate only if the awarded figure is absent.
      const reward = s.credits_awarded != null ? s.credits_awarded : s.credits_reward;
      const summary = s.value_summary
        ? `<span style="display:block;margin-top:2px;font-size:12px;color:var(--ink-faint)">${escapeHtml(s.value_summary)}</span>`
        : '';
      return `
        <tr>
          <td class="ledger__num">#${escapeHtml(String(s.id))}</td>
          <td><a href="/task/${encodeURIComponent(s.id)}">${escapeHtml(s.title || `Task ${s.id}`)}</a>${summary}</td>
          <td class="ledger__drachmae">${fmtNum(reward)}</td>
          <td class="ledger__date">${fmtDate(s.shipped_at)}</td>
        </tr>`;
    }).join('');
  }

  // ---- states -------------------------------------------------------------

  function showMessage(text) {
    const sub = $('#profile-sub');
    if (sub) sub.textContent = text;
  }

  function renderProfile(data) {
    const builder = data.builder || {};
    const name = builder.display_name || builder.github_login || 'Builder';
    const shipped = Number(data.shipped_count) || 0;
    showMessage(`${name} — ${rankLabel(normalizeRank(builder.rank))} · ${fmtNum(shipped)} work${shipped === 1 ? '' : 's'} shipped`);
    renderHead(builder);
    renderNumbers(data.shipped_count, data.achievements);
    renderAchievements(data.achievements);
    renderWorks(data.recent_ships);
  }

  // Render the friendly "no builder chosen" empty state for a signed-out visitor
  // who landed on /profile with no ?id=. We can't default to "self" without a
  // session, so we invite them in rather than bouncing them.
  function renderEmpty() {
    showMessage('Pick a builder to view their profile.');
    const head = $('#profile-head');
    if (head) {
      head.innerHTML = `
        <div class="profile__placeholder">
          No builder selected. Open a builder from the
          <a href="/#leaderboard">leaderboard</a>, or
          <a href="${API}/auth/web/start">sign in</a> to see your own profile.
        </div>`;
    }
    // Blank the data sections so their loading dots don't linger.
    const numbers = $('#numbers-body'); if (numbers) numbers.innerHTML = '';
    const ach = $('#ach-grid'); if (ach) ach.innerHTML = '';
    const works = $('#works-table tbody'); if (works) works.innerHTML = '';
    const worksLede = $('#works-lede'); if (worksLede) worksLede.hidden = true;
  }

  async function fetchProfile(id) {
    const res = await api.request('GET', `${API}/builders/${encodeURIComponent(id)}/profile`);
    if (res.status === 404) {
      showMessage('No builder found with that id.');
      return;
    }
    if (!res.ok) throw new Error(`profile → ${res.status}`);
    renderProfile(res.data || {});
  }

  async function load() {
    const idParam = new URLSearchParams(location.search).get('id');
    try {
      if (idParam) {
        await fetchProfile(idParam);
        return;
      }
      // No id — soft-resolve the viewer's OWN id from /me (no hard redirect; a
      // signed-out visitor gets the empty state instead of a bounce).
      const me = await api.request('GET', `${API}/me`);
      if (me.status === 401) {
        renderEmpty();
        return;
      }
      if (!me.ok) throw new Error(`me → ${me.status}`);
      const builder = (me.data && me.data.builder) ? me.data.builder : me.data;
      const selfId = builder && builder.id;
      if (!selfId) {
        renderEmpty();
        return;
      }
      await fetchProfile(selfId);
    } catch (err) {
      console.error('[profile] failed to load', err);
      showMessage('Could not load this profile. Return to the hall and try again.');
      toast('Could not load the profile.');
    }
  }

  load();
})();
