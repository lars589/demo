-- V3.R24 (#244) — builders.karma + karma_log table.
--
-- Karma is the internal good-citizenship reputation track that sits ALONGSIDE
-- drachmae (builders.total_credits). Drachmae rewards work shipped (objective:
-- task verified → credit_log row → builders.total_credits bump). Karma rewards
-- good citizenship (subjective: voting fairly, surfacing useful ideas, helping
-- newcomers, getting proposals ratified). Separate track so a builder can see
-- "I'm a productive shipper" vs "I'm a great teammate" as distinct signals.
--
-- Shape mirrors credit_log (see migrations/003_pms.sql §credit_log) exactly:
-- append-only ledger, cached counter on the builders row, AFTER INSERT trigger
-- keeps the counter in sync. Differences from credit_log:
--   * No task_id link (karma is people-shaped, not task-shaped).
--   * Adds granted_by (nullable builder_id) so manual Archon grants and peer
--     votes can record WHO drove the delta. NULL = system-attributed (e.g. a
--     trigger or scheduled job that bumps karma on proposal ratification).
--
-- Initial reason vocabulary (free-text but documented):
--   peer_upvote          — another builder upvoted this builder's idea/comment
--   peer_downvote        — another builder downvoted (delta is negative)
--   proposal_ratified    — a proposal this builder authored was ratified
--   archon_grant         — an Archon manually granted karma (granted_by set)
-- V4 will add: claude_interaction_signal, player_upvote.
--
-- Foundation for R25 (voting UI) and R28 (ratification boost). Cross-refs in
-- the task description on GDS task #244.

-- 1. Cached counter on builders ---------------------------------------------
ALTER TABLE builders ADD COLUMN IF NOT EXISTS karma integer NOT NULL DEFAULT 0;

-- 2. Append-only ledger -----------------------------------------------------
CREATE TABLE IF NOT EXISTS karma_log (
  id              bigserial PRIMARY KEY,
  builder_id      bigint NOT NULL REFERENCES builders(id),
  delta           integer NOT NULL,             -- positive = earned, negative = lost
  reason          text NOT NULL,                -- 'peer_upvote' | 'peer_downvote' | 'proposal_ratified' | 'archon_grant' | ...
  recorded_at     timestamptz NOT NULL DEFAULT now(),
  granted_by      bigint REFERENCES builders(id)  -- NULL = system-attributed
);

CREATE INDEX IF NOT EXISTS idx_karma_log_builder ON karma_log (builder_id, recorded_at);

-- 3. Keep builders.karma in sync via trigger --------------------------------
-- Mirrors pms_apply_credit (migrations/003_pms.sql) — same AFTER INSERT shape,
-- same per-row UPDATE on the cached counter.
CREATE OR REPLACE FUNCTION gds_apply_karma() RETURNS trigger AS $$
BEGIN
  UPDATE builders
     SET karma = karma + NEW.delta
   WHERE id = NEW.builder_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_karma_log_apply ON karma_log;
CREATE TRIGGER trg_karma_log_apply
  AFTER INSERT ON karma_log
  FOR EACH ROW EXECUTE FUNCTION gds_apply_karma();
