-- migration 088: per-builder Anthropic account attestation (V3.R10 / task 235, criterion C3)
--
-- C3 wants every builder shipping under their OWN credentials, with cost +
-- authorship attributable to a real person. The GDS identity is already a
-- GitHub OAuth login, but we also want to know WHICH Anthropic account is
-- driving the Claude Code session that makes the API calls — so a forged or
-- borrowed CLI token can be cross-checked against the Anthropic identity the
-- trusted local agent reports.
--
-- A first-party "sign in with Anthropic" OAuth does not exist yet. Instead we
-- lean on the fact that Claude Code itself is the trusted agent on the
-- builder's machine: during /builder-setup it reads its own ~/.claude.json
-- oauthAccount (emailAddress + accountUuid), the builder confirms the email,
-- and we store the attested pair here. Thereafter the CLI sends the
-- accountUuid as an X-Anthropic-User header and requireBuilder cross-checks it.
--
-- This is ATTESTATION, not strong auth (the header can be omitted) — the V4
-- follow-up replaces it with real Anthropic OAuth when that ships. Both columns
-- are NULL until a builder links, so the requireBuilder cross-check is inert
-- for every existing builder and the column add is fully back-compat.

ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS anthropic_email   text,
  ADD COLUMN IF NOT EXISTS anthropic_user_id text;

-- Counter hygiene: keep the migration-number allocator above this file so the
-- next reservation can't collide with 088.
UPDATE migration_counter SET next_number = GREATEST(next_number, 89) WHERE id = 1;
