-- 034_lifecycle_breakdown_leaf_only.sql — fix version_lifecycle_breakdown
-- double-count of parent + children (V3.R23 / #243).
--
-- Background: migration 012 created version_lifecycle_breakdown to give the
-- public dashboard a per-state breakdown (completed / confirmed / shipped) per
-- version. Unlike its sibling view version_progress — which was rebuilt in
-- 006_pms_v2 (and tweaked in 012 and 017) to count ONLY LEAF TASKS — the
-- lifecycle breakdown counts EVERY task row. The result: a parent task with 3
-- shipped children inflates "shipped_count" by 4 (the parent's own row + each
-- child's row), which distorts the leaderboard and the version-progress card
-- on the status page.
--
-- Fix: replace version_lifecycle_breakdown with the same leaf predicate
-- version_progress uses —
--   NOT EXISTS (SELECT 1 FROM tasks c WHERE c.parent_task_id = t.id)
-- — so only rows that have no children contribute. Parents become invisible
-- to the rollup; their state is reflected by their children, which is the
-- correct semantics (a parent is shipped when all its children are shipped,
-- but the leaderboard cares about leaf work).
--
-- The column list is unchanged from migration 012 (version_id, name, track,
-- completed_count, confirmed_count, shipped_count). Postgres rejects
-- CREATE OR REPLACE VIEW when a column name or order changes; even though
-- nothing changes here, the established safe pattern in this repo (see
-- migration 017's comment) is DROP + CREATE for any view edit. Following it.
--
-- Forward-compatibility note: this view does NOT filter out abandoned or
-- __smoke__ tasks beyond what migration 012 did — those are kept where they
-- were so the per-state numerator stays honest (e.g. completed_count is "leaf
-- tasks currently at status=completed", which by definition can't be
-- abandoned). The __smoke__ exclusion already in 012 stays.

DROP VIEW IF EXISTS version_lifecycle_breakdown;
CREATE VIEW version_lifecycle_breakdown AS
SELECT v.id AS version_id,
       v.name,
       v.track,
       count(*) FILTER (
         WHERE t.status = 'completed'
           AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
           AND NOT EXISTS (SELECT 1 FROM tasks c WHERE c.parent_task_id = t.id)
       ) AS completed_count,
       count(*) FILTER (
         WHERE t.status = 'confirmed'
           AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
           AND NOT EXISTS (SELECT 1 FROM tasks c WHERE c.parent_task_id = t.id)
       ) AS confirmed_count,
       count(*) FILTER (
         WHERE t.status = 'shipped'
           AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
           AND NOT EXISTS (SELECT 1 FROM tasks c WHERE c.parent_task_id = t.id)
       ) AS shipped_count
  FROM versions v
  LEFT JOIN tasks t ON t.version_id = v.id
 GROUP BY v.id, v.name, v.track;

-- Bump the migration counter past 034 so the next claim that includes
-- 'migrations/' allocates 035.
UPDATE migration_counter SET next_number = GREATEST(next_number, 35) WHERE id = 1;

INSERT INTO schema_migrations (version) VALUES ('034_lifecycle_breakdown_leaf_only')
  ON CONFLICT (version) DO NOTHING;
