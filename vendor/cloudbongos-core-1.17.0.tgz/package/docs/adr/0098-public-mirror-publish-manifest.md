# ADR 0098 — The Cloud Bongos public-mirror publish manifest (the R71 carve-out)

- **Status:** Accepted
- **Date:** 2026-06-30
- **Track:** internal
- **Task:** [#1210](https://example.com/builders#/task/1210) (V4.R71) — the publishable-subtree carve-out + the public mirror repo.
- **Builds on:** [ADR 0065](<redacted>.md) §4 (the AGPL decision + the prose publish boundary this task makes executable), [ADR 0062](<redacted>.md) §1 (the portable-core / host-instance / feature-module cut-line), [ADR 0043](<redacted>.md) (`PROTECTED_GLOBS`), [ADR 0058](<redacted>.md) (the gate-review "no allow-by-omission" doctrine this borrows).
- **Gates:** [#1211](https://example.com/builders#/task/1211) (R72 — the delayed export pipeline, which *consumes* this manifest) and [#1212](https://example.com/builders#/task/1212) (R73 — the lineage + no-leak proof, which *asserts against* it).
- **Referenced by:** [ADR 0108](<redacted>.md) §2 — `isPublishable()` stays the single definition of "the core," now read as "the core npm package's contents," not just the mirror/package-core tarball subtree.

## Context

[ADR 0065](<redacted>.md) §4 defined the public-mirror boundary in **prose**: publish the portable methodology core + the platform + the neutral (customer-0) branding + sanitized docs; never publish secrets, instance identity literals, prod infra, or the customer-1 (Example) game/art content. That prose is the policy. But R72 (the generated, redacted, 6-month-delayed export) and R73 (the no-leak proof) need the boundary as an **executable, drift-proof artifact** — not a paragraph a future builder has to re-interpret per file.

The task instructs reusing the existing `PROTECTED_GLOBS` / `SENSITIVE_DOC_GLOBS` inventories. The catch: **those inventories are necessary but not sufficient, and `PROTECTED_GLOBS` is emphatically not a denylist.**

- `PROTECTED_GLOBS` (`src/bongos/permission-path-check.js`) is *write*-protection over the trust/pipeline/infra code. ADR 0065 §4 **publishes** most of it — the rank/permission machinery, the grader, and the ship pipeline **are** the open-source methodology. Only its *topology* subset (prod infra, deploy, CI, the local gate hooks) is excluded.
- `SENSITIVE_DOC_GLOBS` (`scripts/gds/search-ingest-md.js`) is *read*-gating; its security/audit corpus is excluded, but `docs/canonical-permissions.md` and the trust-boundary ADRs are methodology and publish (sanitized).
- Neither list mentions the **game, the art pipeline, or the instance's identity config** — which are the single largest exclusions, excluded for content/copyright/instance reasons, not trust reasons. (The art subtree additionally carries the 83 ripped Pokémon FireRed reference maps in `modules/art-pipeline/references/` — an independent, hard copyright reason never to ship it under an AGPL mirror.)

## Decision

### 1. One machine-readable manifest is the source of truth

The boundary is `scripts/gds/publish-manifest.js`, exporting `isPublishable(repoRelativePath) → boolean` (plus `partitionPaths`, the lists, and a `--list` CLI). R72 imports `isPublishable` to select what it exports; R73 asserts no path it forbids ever reached the mirror. The exact globs live **only** in that module — this ADR documents the *model* and *categories* so the two can't drift (the gen-repo-map pattern). Run `node scripts/gds/publish-manifest.js --list` to print the current boundary.

### 2. Default-deny, two layers

```
isPublishable(p)  ==  matchesDeny(p) ? false : matchesAllow(p)
```

The **allowlist is the primary gate**: a path in no allowlisted subtree is silently *not* published, so a new, unclassified surface never leaks by omission. The **denylist is a hard override applied first** (defense-in-depth): even a path inside an allowlisted subtree is dropped if denied — e.g. `scripts/` is broadly allowed but `scripts/deploy/` is denied and wins.

### 3. Reuse the trust inventories; never re-type them

The manifest `require()`s `PROTECTED_GLOBS`, `HARD_FLOOR_GLOBS`, and `SENSITIVE_DOC_GLOBS` from their homes — never copies them (the gate-review.js "imported, never hand-retyped" rule). It **partitions** `PROTECTED_GLOBS` into a small `PROTECTED_TOPOLOGY_EXCLUDE` list (infra, deploy, CI, `.husky/`, the local `.claude/hooks/` + `.claude/settings.json`) versus the remainder, which publishes as the methodology core. `tests/publish_manifest.mjs` asserts the partition is consistent with the live inventory — every topology-exclude entry is a verbatim `PROTECTED_GLOB`, and every non-topology protected surface stays publishable. If `PROTECTED_GLOBS` changes incompatibly, the test fails and the carve-out must be re-decided. **No allow-by-omission**, applied to publishing.

### 4. The boundary, by category

The enforced globs are in the manifest; this is the rationale-bearing summary.

| Publishable (allowlist) | Why |
|---|---|
| `src/` (engine + GDS), `scripts/`, `bin/`, `server.js` | the platform + the instance-model engine (game/art residue denied below) |
| `migrations/`, `tests/` | the build system's own schema + tests |
| platform-core `modules/`: lifecycle, grading, economy, memory, onboarding, ideas, builder-settings, sessions, autonomy, security, hall-ui, status-ui, dev-box, discord | the engine; instance flavor comes from the brand pack, not the code |
| `config/*.neutral.json`, `config/design-tokens.schema.json` | the customer-0 neutral starters + the generic contract schema |
| `CLAUDE.md`, `README`, `LICENSE`, `GOVERNANCE`, `CONTRIBUTING`, `CODE_OF_CONDUCT` | the portable methodology core + governance (R69/R70) |
| `docs/adr/`, `docs/recipes/`, `docs/design/`, `docs/architecture.md`, `docs/*-contract.md`, `docs/canonical-permissions.md`, `docs/handoff-template.md`, `docs/project-context.template.md` | sanitized methodology docs + the neutral project-context scaffold |
| `.claude/skills/` | the methodology slash-commands (hooks + settings denied) |
| Docker + repo scaffolding, `.env.local.example` | self-host scaffolding; examples only |

| Permanently excluded (denylist) | Why |
|---|---|
| `modules/game/`, `public/`, `src/world/`, `src/rooms/`, `src/preview-server.js` | customer-1 game content |
| `modules/art-pipeline/`, `modules/character-anim/`, `art/`, `scripts/art/`, `scripts/tile-*.js` | OTB art + **the ripped Pokémon FireRed reference corpus (copyright)** |
| `config/branding.json`, `config/modules.json`, `config/deploy.json`, `config/devbox-app.json`, `config/hierarchy.json`, `CODEOWNERS` | this host's identity + ops config (the `*.neutral.*` twins publish) |
| `docs/project-context.md`, `docs/lore/`, `docs/TRACKS.md`, `docs/session-logs/`, `docs/handoffs/`, `docs/reviews/`, `docs/discord/`, `blockers/`, `limitations/`, `generative-ideas.md` | instance build history + roadmap prose |
| `docs/security/`, `docs/audits/`, `docs/security-baseline.md`, `docs/routes-permissions.md` | the security/audit corpus (read-gated; attack-surface intel) |
| `infra/`, `scripts/deploy/`, `.github/`, `.husky/`, `.claude/hooks/`, `.claude/settings.json` | prod topology, deploy, CI, local gate automation (the topology subset of `PROTECTED_GLOBS`) |
| `.env`, `.env.local`, `.claude/settings.local.json`, `.claude/worktrees/` | secrets + throwaway local state |

### 5. Deferred — excluded by default until R72 / the owner decides

Default-deny keeps these safely out of the mirror until a deliberate call is made; none is needed for the boundary to be correct:

- **The customer-0 brand pack** — `brand/cloud-bongos/` (the Bongo Buddha mascot + sky-whale art) and `config/branding.cloudbongos.json`. ADR 0065 §4 publishes `config/branding.neutral.json` as the vanilla identity; whether the Cloud Bongos *visual* brand also ships (vs. a neutral install) is a separate owner decision (large binary art + a trademark-vs-AGPL question).
- **The desktop clients** — `bongos-app/` and `devbox-app/` source (their installers already publish off-repo to a separate releases repo).
- **`modules/demo/`** — a sample module that could ship as an example.

### 6. Granularity — subtree boundary now, file-level redaction in R72

This task draws the boundary at the **subtree** level. The *generated* export (R72) does the file-level work ADR 0065 §4 assigns it: redacting instance literals (droplet IP, `*.example.com`, the owner login, OAuth/repo bindings) from *inside* published files, and relocating module-owned tests. Known file-level follow-ups for R72: the game/art tests still under top-level `tests/` should travel with their (excluded) modules, and `.devcontainer/` + `public-landing/` need literal-redaction. R73's no-leak + lineage proof is the backstop that catches any straggler.

### 7. The mirror repo

The public mirror is created **empty** — a `README` plus the AGPL-3.0 `LICENSE` — and is populated only by R72's delayed, redacted export. It does **not** carry source until R73 proves no-leak. The owner created it as **`cloudbongos/bongos`** in a dedicated `cloudbongos` GitHub org — brand-named (not `example-`-prefixed like the status/devbox off-repo mirrors, and not the pre-rename `medusa`) — **private for now**, to be flipped public once R73's no-leak proof lands. It is seeded with the README + the AGPL-3.0 `LICENSE` and nothing else.

## Alternatives considered (rejected)

- **A prose-only carve-out** (just this doc, no manifest). Satisfies the literal "done when" but forces R72 to re-derive globs from prose and gives R73 nothing to assert against. The whole value of reusing `PROTECTED_GLOBS` is an executable boundary. Rejected.
- **Dump `PROTECTED_GLOBS` into the denylist.** Wrong: it would exclude the rank/permission/ship machinery that ADR 0065 §4 explicitly publishes as the methodology. The partition (topology-excluded vs methodology-published) is the necessary nuance. Rejected.
- **Denylist-first (publish everything except a blocklist).** One forgotten entry leaks a secret or the game. A publish boundary must fail safe — default-deny. Rejected.
- **A DB-stored manifest (hence the planning `needs_migration` flag).** The boundary is over *files* (globs), consumed by file-level tooling (R72/R73); there is no live state to store. No migration is needed — the reserved number goes unused.

## Consequences

- **R72 and R73 build against one executable artifact**, not a paragraph. R72 imports `isPublishable`; R73 asserts no denied path leaked + that private↔public lineage stays consistent.
- **The carve-out cannot silently drift** from the live trust inventory — `tests/publish_manifest.mjs` (in the unit gate) fails if the partition stops covering `PROTECTED_GLOBS`.
- **No migration, no recurring cost.** This is a manifest + a doc + a test. The export pipeline's cost is evaluated under R72.
- **The deferred items (§5) remain owner decisions.** They are excluded until then, so the mirror is never *less* safe for the deferral.
