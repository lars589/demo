'use strict';

// Discord admin command surface — ADR 0037, task #727.
//
// The ONLY command path by which a human triggers the bot to act on channels.
// Both routes are Archon-gated: requireBuilder resolves the live builder, then
// requireRank('archon') re-checks builders.rank server-side (ADR 0016). A
// Metic, Thetes, Xenos, or unauthenticated caller gets a 403 — this is the
// "lower ranks cannot command the bot" rule from task #727, enforced where it
// is load-bearing (the server) rather than in Discord roles.
//
// Passive bot features (ship-feed applause, #ideas inbound, role badges) are
// untouched by this file — they remain open to everyone by design.

const express = require('express');
const api = require('../../../src/module-api');
const auth = require('../auth');
const db = require('../db');
const shipBroadcast = require('../ship-broadcast');
const roleSync = require('../discord-role-sync');

// The module's kernel seams, registered when this factory runs (the loader runs
// it at boot, already gated to enabled instances — ADR 0083 / BV1.R47). They are
// how core reaches discord WITHOUT importing it:
//   • PORT discord.isLinked(builderId) → bool — core (routes/me.js, builders.js)
//     reads it via resolveOptional to render the hall's Connect/Unlink state and
//     auto-clear onboarding's discord step; degrades to false when discord is off.
//   • PORT discord.guildJoinSpec(rank) → { guildId, roleIds } — the OAuth link
//     callback (core routes/auth.js) reads it to auto-join the just-linked builder
//     to the guild with their rank role at add-time, and to pick the guild on
//     unlink; degrades to { guildId: null } so the callback simply skips the join.
//   • EVENT task.shipped — core (publish-reconciler / routes/tasks) emits it on the
//     confirmed→shipped transition; we post the #ship-news / #ship-feed broadcast.
//   • EVENT builder.role-sync-needed { builderId } — core emits it on a rank change
//     (routes/builders.js) + after a link (routes/auth.js); we repair the Discord
//     rank-role badge. Fire-and-forget; the listener owns its own error handling.
// All replace former direct core→discord requires. Idempotent: ports are
// hasProvider-guarded; listeners are replaced (off→on) so a test re-instantiating
// the router never accumulates duplicates.
let _shipListenerOff = null;
let _roleSyncListenerOff = null;
function registerSeams() {
  if (!api.hasProvider('discord.isLinked')) {
    api.registerProvider('discord.isLinked', async (builderId) => !!(await db.getDiscordLink(builderId)));
  }
  if (!api.hasProvider('discord.guildJoinSpec')) {
    api.registerProvider('discord.guildJoinSpec', async (rank) => {
      const guildId = roleSync.loadGuildId() || null;
      const roleId = rank ? roleSync.rankToRoleId(rank, roleSync.loadRoleMap()) : null;
      return { guildId, roleIds: roleId ? [roleId] : [] };
    });
  }
  if (_shipListenerOff) _shipListenerOff();
  _shipListenerOff = api.on('task.shipped', (task) => shipBroadcast.postShipBroadcast(task));
  if (_roleSyncListenerOff) _roleSyncListenerOff();
  _roleSyncListenerOff = api.on('builder.role-sync-needed', ({ builderId }) =>
    roleSync.syncBuilderRole(builderId).catch((e) =>
      console.log('[discord] role-sync (non-blocking):', e && e.message)));
}

module.exports = function buildDiscordRouter() {
  registerSeams();
  const router = express.Router();

  // GET /api/bongos/discord/channels/plan — dry run. Returns the ops the bot WOULD
  // apply to make Discord match docs/discord/channels.json, plus warnings. No
  // writes. 503 when the bot is disabled / not connected to a guild.
  // rank: archon — channel administration command.
  router.get('/discord/channels/plan', auth.requireBuilder, auth.requireRank('archon'), async (req, res) => {
    try {
      const channels = require('../discord-channels');
      const plan = channels.computePlan();
      if (!plan.ok) {
        return res.fail('bot_unavailable', 503, { reason: plan.reason });
      }
      return res.json({ ok: true, guild_id: plan.guildId, op_count: plan.ops.length, ops: plan.ops, warnings: plan.warnings });
    } catch (err) {
      console.error('[gds] GET /discord/channels/plan', err);
      return res.fail('internal_error', 500);
    }
  });

  // POST /api/bongos/discord/channels/reconcile — apply the config to Discord now.
  // Best-effort; returns how many ops applied/failed. 503 when the bot is
  // disabled / not connected.
  // rank: archon — channel administration command.
  router.post('/discord/channels/reconcile', auth.requireBuilder, auth.requireRank('archon'), async (req, res) => {
    try {
      const channels = require('../discord-channels');
      const result = await channels.reconcileChannels();
      if (!result.ok) {
        return res.fail('bot_unavailable', 503, { reason: result.reason });
      }
      return res.json({ ok: true, applied: result.applied, failed: result.failed, total: result.total, warnings: result.warnings });
    } catch (err) {
      console.error('[gds] POST /discord/channels/reconcile', err);
      return res.fail('internal_error', 500);
    }
  });

  return router;
};
