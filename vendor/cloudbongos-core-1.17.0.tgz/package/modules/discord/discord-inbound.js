'use strict';

// Discord inbound → idea_inbox — Phase 3 F6, part 1 (ADR 0033 §5).
//
// The bot files a message posted in the designated #ideas channel into the GDS
// idea_inbox via the SAME path the web/CLI use (inbox.captureIdea), attributed
// to the linked builder when the author has linked their Discord (else captured
// unattributed — captured_by NULL, which idea_inbox already allows). This is the
// inbound surface that will RETIRE the Google Chat inbound machinery — but that
// removal is a DELIBERATELY SEPARATE follow-up, gated on this path being
// verified live (never delete the working inbound before the replacement works).
//
// TRUST BOUNDARY: filing an idea is the open-to-all path (POST /inbox is
// any-authenticated-builder; an unlinked Discord user is strictly LESS privileged
// — their idea is captured unattributed). The bot asserts only WHO posted; it
// grants nothing. Every filing is audited with surface='discord_bot'. No rank is
// involved, so there is nothing to escalate. (kind='criterion-proposal' — the
// one rank-gated idea kind — is never produced here; the auto-classifier can't
// emit it, and we don't pass it.)
//
// Requires (go-live): the Message Content PRIVILEGED intent (to read message
// text) + DISCORD_IDEAS_CHANNEL_ID. Inert until both are set.

// captureIdea is no longer a doorway export (retired at BV1.R78 / ADR 0093 §5).
// We resolve the `ideas.capture` kernel PORT the ideas module registers — the
// codebase's first module→module port (declared in this module's `consumes`).
const api = require('../../src/module-api');
const db = require('./db');
const { auditDiscordBot } = require('./discord-audit');
const auth = require('./auth');
const attachments = require('./bug-attachments');
const { createMessageAggregator } = require('./discord-message-buffer');
const { LIMITS } = api;

// Auto-pairing window for #ideas (task #979) — same default as #bugs. Env
// DISCORD_IDEAS_PAIR_WINDOW_MS overrides.
const DEFAULT_PAIR_WINDOW_MS = 45 * 1000;

// Title for an idea that arrives as image(s) with no usable text.
const IMAGE_ONLY_TITLE = 'Idea (image)';

function pairWindowMs(env = process.env) {
  const n = Number(env.DISCORD_IDEAS_PAIR_WINDOW_MS);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : DEFAULT_PAIR_WINDOW_MS;
}

// PURE — turn a raw message into { title, bodyMd }, or null when there's nothing
// to file (blank text AND no images). Title = first non-empty line (capped) or,
// for an image-only message, a default; body = the full message text (capped,
// possibly empty). Unit-tested.
function deriveIdea(content, { hasImages = false } = {}) {
  const trimmed = typeof content === 'string' ? content.trim() : '';
  if (!trimmed && !hasImages) return null;
  const cap = LIMITS.TITLE;
  let title;
  if (trimmed) {
    const firstLine = (trimmed.split('\n').find((l) => l.trim()) || trimmed).trim();
    title = firstLine.length > cap ? `${firstLine.slice(0, cap - 1)}…` : firstLine;
  } else {
    title = IMAGE_ONLY_TITLE;
  }
  const bodyMd = trimmed.length > LIMITS.DESCRIPTION ? trimmed.slice(0, LIMITS.DESCRIPTION) : trimmed;
  return { title, bodyMd };
}

const realDeps = {
  getBuilderByDiscordUserId: db.getBuilderByDiscordUserId,
  // Lazy: resolve the `ideas.capture` port at CALL time, so the ideas module's
  // registration (at its route-factory mount) need not precede this module's load.
  captureIdea: (...a) => api.resolve('ideas.capture')(...a),
  insertAuditLog: db.insertAuditLog,
  persistImages: attachments.persistImages,
};

// File one inbound message as an idea. NEVER throws (the caller is a gateway
// event handler). Returns a small status object for logging/tests.
async function recordInboundIdea({ discordUserId, content, imageUrls = [], messageId }, deps = realDeps) {
  if (!auth.isValidDiscordUserId(discordUserId)) {
    return { outcome: 'ignored', reason: 'bad_discord_user_id' };
  }
  const hasImages = Array.isArray(imageUrls) && imageUrls.length > 0;
  const derived = deriveIdea(content, { hasImages });
  if (!derived) return { outcome: 'ignored', reason: 'empty' };

  try {
    const builder = await deps.getBuilderByDiscordUserId(discordUserId);

    // Re-host any images on our server (durable — Discord CDN links expire, and
    // an idea can sit in the inbox even longer than a bug before triage). We
    // re-host for linked AND unlinked authors: the byte-level guards in
    // bug-attachments.persistImages (host allowlist + content-type + magic-byte
    // sniff + size/count caps) are the protection, not author identity. A
    // persist failure must not lose the idea.
    let stored = [];
    if (hasImages) {
      try {
        stored = await deps.persistImages(imageUrls, { messageId });
      } catch (e) {
        console.error('[discord-bot] idea image persist failed (filing without images):', e.message);
      }
    }

    // Provenance footer so triage knows where the idea came from. The author's
    // raw Discord snowflake is NOT embedded (it's recorded in the Archon-only
    // audit_log instead); only the builder login when linked. Then the durable
    // attachment links.
    const origin = builder
      ? `\n\n— filed from Discord #ideas by ${builder.github_login}`
      : '\n\n— filed from Discord #ideas (unlinked author)';
    let bodyMd = `${derived.bodyMd}${origin}`;
    if (stored.length > 0) {
      const imgs = stored.map((s, i) => `![attachment ${i + 1}](${s.url})`).join('\n');
      bodyMd += `\n\nAttachments (${stored.length}):\n${imgs}`;
    }
    bodyMd = bodyMd.slice(0, LIMITS.DESCRIPTION);

    const idea = await deps.captureIdea({
      title: derived.title,
      bodyMd,
      capturedBy: builder ? builder.id : null,
      // kind left null → inbox.captureIdea auto-classifies. We never pass
      // 'criterion-proposal' (the rank-gated kind) from this path.
    });

    await auditDiscordBot(deps, {
      builderId: builder ? builder.id : null,
      route: 'discord:inbound',
      requestBodyRedacted: { discord_user_id: discordUserId, message_id: messageId, idea_id: idea.id, images: stored.length },
      responseStatus: 201,
      logLabel: 'inbound audit-log write failed',
    });

    return { outcome: 'filed', ideaId: idea.id, capturedBy: builder ? builder.id : null, images: stored.length };
  } catch (err) {
    console.error('[discord-bot] recordInboundIdea failed:', err.message);
    return { outcome: 'error', error: err.message };
  }
}

// Auto-pairing aggregator for #ideas — a thin wrapper over the shared per-author
// burst aggregator (discord-message-buffer.js) that supplies the #ideas default
// window. onFlush files the combined burst as ONE idea.
function createIdeaAggregator({ onFlush, windowMs = pairWindowMs(), timers = global } = {}) {
  return createMessageAggregator({ onFlush, windowMs, timers });
}

module.exports = { deriveIdea, recordInboundIdea, createIdeaAggregator, pairWindowMs, realDeps };
