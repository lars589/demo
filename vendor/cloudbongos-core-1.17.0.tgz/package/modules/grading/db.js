// modules/grading/db.js — the grading module's db slice (ADR 0102).
//
// The grade-TREND read (`builderRollingAvgGrade`) carved from the core db.js
// residue so the published doorway (a KERNEL_FILE) stops importing `./gds/db` —
// the last tranche-2 kernel→domain leak (fitness Check 12 / ADR 0091 §1).
//
// It reads `task_grades` (grading domain). Two consumers reach it through the
// `grade.builderRollingAvgGrade` seam port: core me.js's profile aggregator and
// the sessions module's BFG scorer. Both degrade to a zero-grade shape when this
// module is off (a vanilla instance). Reaches `pool` through the doorway.
//
// The old core copy interpolated a shared `gradePassCount` SQL fragment (a
// documented twin with lifecycle/db.js); that one-liner is inlined here so this
// slice carries no cross-file fragment dependency.

'use strict';

const api = require('../../src/module-api');
const { pool } = api;

// Rolling grade stats for a builder over the last `days`: { n, avg_score, n_passed }.
// Windows by graded_at; `shipped_by` attributes the grade to the builder who did
// the work. Returns a zero row when the builder has no grades in the window.
async function builderRollingAvgGrade(builderId, days = 14) {
  const { rows } = await pool.query(
    `SELECT
       COUNT(*)::int                                            AS n,
       COALESCE(AVG(g.score), 0)::numeric(3,1)                  AS avg_score,
       COALESCE(SUM(CASE WHEN g.passed THEN 1 ELSE 0 END), 0)::int AS n_passed
       FROM task_grades g
       JOIN tasks t ON t.id = g.task_id
      WHERE t.shipped_by = $1
        AND g.graded_at >= now() - ($2 || ' days')::interval`,
    [builderId, String(days)]
  );
  return rows[0] || { n: 0, avg_score: 0, n_passed: 0 };
}

module.exports = { builderRollingAvgGrade };
