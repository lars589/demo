# `lifecycle` module — the build state machine + the `lifecycle` kernel port

> The **LAST and most-coupled CORE-domain** carved into a module (BV1.R86, [ADR 0093](../../docs/adr/<redacted>.md) §1,§3) — after memory (R72), grading (R73), economy (R77), ideas (R78), security (R79), builder-settings (R80), onboarding (R81), sessions (R82), autonomy (R83), status-UI (R84), hall-UI (R85). Carved last on purpose: by now every capability it INVOKES (`grade`, `reward`, `onboarding`) is a kernel port it resolves, so the lifecycle imports only the kernel + resolves those ports ([02-module-map §4](../../docs/design/modular-architecture/02-module-map.md): keep the state machine WHOLE, never split). `default: true` — every instance runs the lifecycle. This carve makes the `db.js` residue exactly what ADR 0093 §3 predicted: the kernel identity/auth/twin slice + `db-kernel.js`.

Owns the **build state machine**: tasks · claims · versions · done-when criteria · goals · dependencies · the claim→ship→grade→credit lifecycle · override requests · the ship/confirm/promote orchestration · `github-push` (server-mediated branch publish) · `merge-lock` · `conflict-resolve` · the `publish-reconciler` (confirmed→shipped auto-heal) · `ship-card`/`ship-preflight` · `version-close` · the peer-vote→karma fold-in · the work-tracking analytics (est-drift, grade trend, AI-dev curve).

## The boundary (the one rule)

This module reaches core **only** through the published doorway [`../../src/module-api.js`](../../src/module-api.js) (`coreVersion ^1.12.0` — it needs the R86 doorway additions: `repoInfo`, `moduleScopeMap`, `pathMatch`, `userAgent`, `asyncHandler`, `corsPublicGet`). It must **never** `require()` a core internal directly, and never another module. Core, in turn, must never `require()` a file in here — it reaches the lifecycle only through the `lifecycle` port (below). Both directions are enforced by the BV1.R44/R45 fitness checks.

## The `lifecycle` kernel PORT (ADR 0093 §3 — the headline of this carve)

The inverse of every prior carve: the lifecycle is carved last, so every capability it *invokes* (`grade`/`reward`/`onboarding`) is already a port it RESOLVES; the `lifecycle` port is the surface **core and the other modules resolve to reach the build state machine** without importing this module.

- **Provides — port `lifecycle`** → the surface in [`lifecycle.js`](lifecycle.js) (DELEGATES, does not spread, to `./db` + `./task-classifier` so test stubs bite at call time — the economy `reward` precedent). Registered in [`routes/lifecycle.js`](routes/lifecycle.js)'s factory (the loader runs it at boot + on every test router rebuild; `hasProvider`-guarded). It **retires the three ADR-0091 §3 doorway leaks** — `createTask`, `VOTABLE_TASK_STATUSES`, `tallyPeerVotes` — plus exposes `classifyTaskKind` and the work-tracking READS the staying-core read routes need.
- **Core + the other modules consume it WITHOUT importing this module** (all via `seams.resolveOptional('lifecycle')`):
  - `src/bongos/routes/public.js` (the status surface) — `getTask`/`listVersions`/`versionProgress`/`recentShippedTasks`/`estimationDriftSummary`/`rollingAvgGrade`/`gradeTrendByDay`.
  - `src/bongos/routes/me.js` (the profile reader) — `<redacted>`/`getEstVsActualRatio`/`recentGradesForBuilder`/`<redacted>`/`<redacted>`.
  - `src/bongos/routes/builders.js` (the Archon roster) — `getBuildersRoster`/`<redacted>`/`gradeByBuilder`/`<redacted>`.
  - `src/bongos/cascade-dispatch.js` (dormant System 3) — `classifyTaskKind`.
  - `modules/onboarding/db.js` (newcomer-restock) + `modules/discord/db.js` (#bugs→task) — `createTask`.
  - `modules/discord/discord-reaction.js` — `VOTABLE_TASK_STATUSES`.
  - `modules/autonomy/pollers/routine-timers.js` — `tallyPeerVotes`.
- **It RESOLVES (as a transaction-participant consumer)** the `reward` + `onboarding` ports inside its own `withTx` — `claimTask`/`confirmTask`/`decideOverrideRequest`/`applyGrade` open the tx, run the state-machine SQL, and call `seams.resolveOptional('reward')|('onboarding').*(client, …)` so the credit/achievement/stage writes commit atomically with the status flip (ADR 0093 §2). It resolves via `resolveOptional` (graceful), so `consumes: []` — a vanilla instance without economy/onboarding degrades those writes to best-effort no-ops, it does not fail.

## Files

| File | What |
|---|---|
| `db.js` | the lifecycle data layer — ~97 functions: tasks/claims/versions/goals/dependencies/criteria, the claim→ship→grade→credit lifecycle (`claimTask`/`resolveClaim`/`confirmTask`/`shipTask`/`applyGrade`/`abandonTask`), overrides, estimation + work analytics, the merge lease, `tallyPeerVotes`, `createTask`. Reaches the pool/withTx/seams via the doorway; resolves `reward`/`onboarding` as a consumer. |
| `task-classifier.js` | the `tasks.kind`/discipline heuristic + `VOTABLE_TASK_STATUSES`/`VALID_KINDS`/`VALID_DISCIPLINES`/`TASK_FIELD_BOUNDS`. `branding()` (instance blocker-vendors) via the doorway. |
| `done-when.js` · `hierarchy.js` · `version-close.js` | the done-when criterion read/write surface, the shallow one-level task hierarchy, and the version-close gate evaluator. Pool via the doorway. |
| `github-push.js` · `conflict-resolve.js` · `publish-reconciler.js` | server-mediated branch publish ([ADR 0055](../../docs/adr/<redacted>.md)) + the [ADR 0082](../../docs/adr/<redacted>.md) generated-file conflict resolver + the confirmed→shipped reconciler. `repoInfo`/`branding`/`userAgent` via the doorway; siblings require each other. |
| `ship-card.js` · `ship-preflight.js` · `merge-lock.js` | the CLI lifecycle card, the ship preflight guards, and the cross-machine merge lease serializer (pure; `branding` via the doorway). |
| `lifecycle.js` | the `lifecycle` port provider surface (delegates to `./db` + `./task-classifier`). |
| `routes/{tasks,claims,versions,done-when,goals,dependencies,gate-approvals,analytics}.js` | the lifecycle HTTP surface — moved out of `src/bongos/routes/`; the loader mounts them via `contributes.routes`. Auth/validators/seams via the doorway; `./db` + libs are siblings. |
| `routes/lifecycle.js` | the route factory that registers the `lifecycle` port (no HTTP endpoint). |
| `pollers/publish-reconciler.js` | the loader poller entry (`start`/`stop`) for the publish reconciler — inverts the old `server.js` hardcoded start (the autonomy routine-timers precedent). |

## Boundary-forced duplication (keep in sync)

Two helpers are **deliberately duplicated** with core `src/bongos/db.js` (ADR 0091 §2 — "boundary-forced duplication is allowed + documented"): the same SQL runs on both sides of the kernel↔module line, and a module can't import core:

- **`sealSessionLog`** — core `deactivateBuilder` (rank/identity management, stays core) writes the same `session_logs` close row; here `resolveClaim`/`shipTask` write it.
- **`_applyRankChangeTx` (+ its `RANKS` / `singleRungPromotionError` deps)** — core `setBuilderRank` (Archon-driven, stays core) runs the same in-tx rank change; here it backs the automatic xenos→thetes graduation on ship (`maybeAutoGraduateToThetes`).
- **the `gradePassCount` SQL fragment** — core `builderRollingAvgGrade` (the grade-trend read the sessions BFG also consumes, kept on the doorway) + the module's grade reads share it.

## NOT in this module (the db.js residue — stays core)

- **Builder IDENTITY + admission** (`upsertBuilder`/`getBuilderByGithubId`/`hasInvitedAccessRequest`/`linkAnthropicAccount`/`updateBuilderDisciplines`) — `auth.js` imports these; they CANNOT live in a module.
- **Rank + status MANAGEMENT** (`setBuilderRank`/`_applyRankChangeTx`/`<redacted>`/`deactivate`/`reactivateBuilder`) — Archon identity ops consumed by `routes/builders.js`, NOT the task lifecycle.
- **AUTH sessions** (`createSession`/`lookupSession`/`revoke*`/`hasCliSession`/`SESSION_TTL_MS`) — the `builder_sessions` token store `auth.js` drives.
- **TWIN / social** (Discord link flow, karma feed, `listAuditLog`, the grade-trend `builderRollingAvgGrade`) + the **security_docs** store (the kernel security-PROPERTY plane).
- **The Gemini-key leak** (`getBuilderGeminiKeyRow`/…) — art-pipeline credential infra.
- **The lifecycle CLIs** — a command travels with its domain but stays a CLI under `scripts/gds/` (`ship.js`/`claim.js`/`release.js`/`merge-mode.js`/`confirm.js`/`merge-lock.js`/`version-close.js`/`main-audit.js`/`gate-review.js`/`push-main.js`/`ci-grade.js`), outside the kernel boundary — they may require this module directly (the grading/economy precedent).

## Tables

None owned. `tasks`/`claims`/`versions`/`goals`/`done_when_criteria`/`dependencies`/`task_grades`/`task_override_requests`/`merge_leases` (+ their migrations) were created before the module system and stay in core `migrations/` (the shared-schema additive rule). The module owns the *queries*; any **new** lifecycle migration belongs in `modules/lifecycle/migrations/` namespaced `lifecycle_*`.

## Tests

The DB-free carved-surface tests in `scripts/gds/coreB-carve-proof.sh` (`task_classifier_vocab`, `criterion_progress`, `github_push_*`, `ship_card`, `ship_preflight`, `merge_lock`, `conflict_resolve`, `publish_reconciler`, `goal_achievement`, `context_pack`) import from `modules/lifecycle/…` and pass byte-identical. The DB-integration tests (`grade_attempts`, `rank_gate`, `abandon_task`, `confirm_attribution`/`override_attribution`/`grade_attribution`, `goal_routes`/`goal_tier`/`goal_achievement`, `dependencies_*`, `task_create_idempotency`, `worktree_disambiguation`, `cap_newcomer_tasks`, `migration_allocation`, `task_ownership_gate`, `verify_task_guard`, `versions_route`, `gate_approvals`, `merge_lease`, `autonomous_fit_protected_paths`, …) require/read `modules/lifecycle/{db,routes/*,libs}.js`; the route-consumer tests (`onboarding_route_signals`, `onboarding_observability`, `discord_reaction`) register the `lifecycle` port. See [ADR 0093](../../docs/adr/<redacted>.md).
