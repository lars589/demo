# 0009 — Autotile architecture: AI primitives + procedural compositor

- **Status:** Accepted
- **Date:** 2026-05-09
- **Deciders:** Lars

## Context

V1 needs to render coherent terrain boundaries: grass islands within sand, sand
beaches against shallow sea, marble flagstone paths through grass, cliffs.
Earlier work in [ADR 0008](./<redacted>.md) established
the family pipeline and produced beautiful single illustrations for continuous
objects (containers, houses), but that pipeline could not produce a true
autotile family — a set of tiles where every cell is a different topology
(corner, edge, T-junction, etc.) that must connect cleanly with its neighbors
in any combination.

The stress test confirmed this: under continuous_illustration the 9-tile path
autotile produced a "border tile set" (a square frame of flagstones) but lost
the four-way cross and the topology variants a real autotile needs. The model
is good at drawing single illustrations; it is not good at producing all
distinct topology variants of a tile set as one image.

We needed an architecture that:

1. Produces all 47 (region) or 16 (path) topology variants for an autotile.
2. Guarantees that adjacent tiles connect at their shared seams.
3. Lets the model do what it is good at (texture appearance) without asking
   it to do what it is bad at (tile-set topology).
4. Stays cheap (the project budget is $80, currently ~$2.50 spent).
5. Produces output that integrates with the runtime tile picker in Phaser.

## Decision

We will use **AI-generated primitives + procedural composition** for autotile
families.

For each autotile family, the AI generates 3–5 small primitive textures:

- For region families (47-blob): an interior texture, an exterior texture,
  and three boundary patches (horizontal-edge, concave-corner, convex-corner)
  in their NW orientation.
- For path families (16-path): a surrounding-terrain texture, a path node,
  and a path arm.

A pure-Python compositor (`art/pipeline/autotile_compositor.py`) then composes
all 47 (or 16) tiles by deterministic per-quadrant masking. Each 32×32 tile is
divided into 4 quadrants of 16×16; each quadrant's content is determined by
3 input bits (one edge each side, plus the corner) which select among 5 patch
types (interior, concave, horizontal edge, vertical edge, convex). Patches
are flipped or rotated for non-NW quadrants.

**Edges match by construction.** Every tile that has the same edge configuration
samples its boundary pixels from the same primitive at the same logical
position. So when two such tiles sit next to each other in the world, the
seam pixels are guaranteed identical to within bounded jitter.

Two standard autotile schemes are implemented:

- **47-blob** (RPG Maker A2 / Cr31 / Tiled "terrain" mode standard) for
  region terrain. 8-neighbor with corner-mask reduction. The corner-mask
  rule: a corner-neighbor bit is meaningful only if both adjacent edges
  are also same-terrain (otherwise the boundary along the edge occludes
  the corner). This collapses 256 raw neighbor configurations to 47
  distinct tiles.

- **16-path** for line/path terrain. 4-cardinal-only. Each path tile is
  identified by which of the 4 cardinal neighbors are also part of the
  same line (path/road/wall/fence). Direct identity: tile_idx == bitmask.

A new family kind in `families.json` (`autotile_blob_47` / `autotile_path_16`)
declares the family's primitives. A new orchestrator
(`art/pipeline/autotile_orchestrator.py`) generates the primitives via the
existing AI pipeline and calls the compositor.

Texture-style primitives (interior/exterior/terrain) get an additional
seamless-enforcement post-step: the leftmost and rightmost columns of pixels
are averaged to a single column applied to both, and the topmost and
bottommost rows likewise. After re-quantizing to the locked palette, the
texture tiles seamlessly with itself — proven by the validation harness
(100% edge-match on all-interior compositions).

The runtime tile picker is split-implementation:
- `art/pipeline/autotile_mapping.py` (Python) — used by the compositor
- `public/game/world/autotile.js` (JavaScript) — used by the in-game renderer
- Cross-verified at build time: both produce identical tile indices for all
  256 neighbor configurations.

## Alternatives considered

- **AI generates the whole tile set in one image (continuous_illustration
  scaled up).** Rejected on stress-test evidence — the model produces a
  coherent illustration but not the topology variants a real autotile needs.
- **Cell-by-cell with image-conditioning anchors** ("Strategy A" in the
  Pattern-C plan: generate tile 1, generate tile 2 with tile 1's matching
  edge as a reference image, etc.). Rejected for V1 on cost (47 sequential
  generations per family) and reliability (model interpretation of edge
  references is fragile). Kept as a fallback if the primitives approach
  fails for a specific family.
- **Hand-paint each of the 47 tiles.** Rejected — V1 has no artist budget;
  the bootstrapping spirit of the project demands a self-driving pipeline.
- **Hand-paint a 5×3 RPG-Maker template (15 quadrants) and derive the 47
  tiles by composition.** Equivalent quality but more manual and less
  flexible than primitives + compositor. Skipped.
- **Wang tiles (corner-coded) instead of blob47.** Equivalent expressive
  power; 16 corner-coded tiles vs 47 blob tiles. Rejected because the
  corner-coded approach forces every boundary to bend at the corner
  (no smooth straights), which doesn't match the FireRed visual aesthetic.
- **Skip cliffs.** Considered. Tried anyway as an experiment. Result: the
  47-blob produces topologically correct cliff regions but stylistically
  weak — real cliffs need direction-specific tiles (south face very
  different from north). Documented as a Phase-D limitation; if V1 ships
  cliffs, they need a follow-up direction-aware scheme.

## Consequences

### Positive

- **All 47 (or 16) tiles produced from 3–5 primitive generations.** Cost per
  autotile family is ~$0.25–0.45 vs ~$1.88 if we hand-generated each tile.
- **Edges match by construction.** No retry loop needed for seam alignment.
  The 100% edge-match score on all-interior compositions proves it.
- **Standards-compliant.** Anyone familiar with RPG Maker A2, Tiled
  "terrain" mode, or Cr31's blob convention can read the bitmask code
  without learning a custom scheme.
- **Renderer is data-driven.** World map stores terrain ids; runtime picks
  tile indices via lookup. Shape change (region → autotile) is a swap of
  the picker function.
- **Single source of truth** for the lookup table. Python and JS
  cross-verified at build time.

### Negative / costs

- **Direction-asymmetric terrain** (cliffs, where the south face looks
  different from the north) is poorly served by 47-blob. Documented
  limitation — cliffs ship as best-effort with stylized "shelf" look or
  defer to V2 with a direction-aware scheme.
- **Boundary tiles are stylistically coherent but not pixel-perfect at
  every seam.** The corner and edge primitives are independently generated
  and don't perfectly match each other at every transition. Acceptable for
  V1; producing pixel-perfect transitions would require generating boundary
  primitives in pairs with image conditioning. Defer to V2.
- **Multiple autotile families against the same neighbor terrain** require
  per-family primitives. We can't share an "edge between grass and sand"
  primitive between grass_on_sand and sand_on_grass. Acceptable — terrain
  pairs are a finite, small set in V1.
- **Triple-junctions** (where 3 terrains meet at one tile) are not
  representable. Standard autotile schemes punt on this; we forbid triple
  junctions in level design. V1 world is small enough this isn't binding.
- **Runtime data-model refactor required.** `src/world/map.js` and
  `public/game/world/map.js` currently store tile ids. They need to store
  terrain ids and let the runtime call the autotile picker. This refactor
  is in V1 scope but is risky enough that it ships in a separate PR after
  this ADR (kept as a pending Phase D in the rollout).

### Operational rules adopted with this decision

1. **Texture-role primitives** (interior, exterior, terrain) get the
   seamless-enforcement post-step automatically. No exceptions.
2. **Boundary primitives** (concave/convex/horiz patches) are generated
   in their NW orientation only. The compositor flips/rotates them.
   Don't generate per-orientation copies.
3. **Per-tile sample variation** (jitter into the interior primitive based
   on tile coordinates) is a Phase-V2 nice-to-have. Phase B–D ships without
   it; expect visible repetition in large interior fields.
4. **Atomic-swap rule still applies.** Autotile output sits in
   `art/iterations/_autotile/<family>/` until Lars reviews and approves
   atomic-swap into `art/generated/tiles/`.
5. **Cross-verification of Python/JS tables** is a smoke-test gate. If the
   tables disagree, the build fails. Single source of truth is the rule
   in autotile_mapping.py; autotile.js is generated to match.

## What this does not change

- The locked 64-color palette is still authoritative.
- The cost ledger ($80 hard stop) still gates all generation.
- The per-tile pipeline still serves the 22 atomic non-autotile tiles
  (grass_base, sand_base, container_door, etc.) until/unless those are
  also migrated to autotiles.
- The family pipeline (ADR 0008) still serves character families and
  multi-tile object families. Autotiles are an addition, not a replacement.
