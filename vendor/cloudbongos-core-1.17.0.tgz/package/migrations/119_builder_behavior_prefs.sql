-- 119_builder_behavior_prefs.sql — per-builder agent-behavior preferences,
-- starting with the "wandering" knob (task 1268).
--
-- One jsonb column on `builders` (behavior_prefs), default '{}'. It holds
-- reserved keys for per-builder behavior tuning; the first is 'wandering' — an
-- integer level 0..3 (Locked | Focused | Balanced | Exploratory) controlling how
-- readily an agent opens a NEW THREAD of work (a tangent, an investigation, an
-- unsolicited suggestion) vs. staying on its claimed task. A MISSING key falls
-- back to the rank-derived default resolved in src/bongos/wandering-prefs.js
-- (Xenos→Locked … Archon→Exploratory), so the column stays sparse: a builder
-- who never touches the setting has '{}' and behaves at their rank's default.
--
-- This deliberately mirrors migration 037 (skill_model_prefs) and 075
-- (sound_prefs): per-builder personalized config, sparse + irregular, read by
-- primary key, with the allowlist + defaults + the rank clamp living in code
-- (src/bongos/wandering-prefs.js) rather than a Postgres CHECK — so adding a new
-- behavior knob (or a new level) is a one-line code change, not a coordinated
-- schema migration. behavior_prefs is the blob; 'wandering' is one reserved key.
--
-- Enforcement note: the stored value is the builder's DESIRED level; the
-- effective level is clamp(override, 0, maxForRank) computed server-side on
-- every read (wandering-prefs.effectiveLevel). A Xenos who stores Exploratory is
-- still resolved to Locked — so opening this up for self-service later is safe.
--
-- Idempotent: safe to re-run.

ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS behavior_prefs jsonb NOT NULL DEFAULT '{}'::jsonb;

INSERT INTO schema_migrations (version) VALUES ('119_builder_behavior_prefs')
  ON CONFLICT (version) DO NOTHING;
