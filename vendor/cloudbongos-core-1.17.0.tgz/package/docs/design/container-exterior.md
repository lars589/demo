# Container building — exterior structure design (V2)

- **Task:** [#641](https://example.com/builders#/task/641) (V2 · product · creative). Promoted from idea_inbox [#160](https://example.com/builders#/idea/160) (builder 25 art/design brief, 2026-06-04).
- **Date:** 2026-06-11
- **Status:** Design locked at the structure level. Pixel-precise tile specs are [#643](https://example.com/builders#/task/643) (facade); interior is [#642](https://example.com/builders#/task/642)/[#644](https://example.com/builders#/task/644)/[#645](https://example.com/builders#/task/645); palette implementation is [#640](https://example.com/builders#/task/640) / [ADR 0044](../adr/0044-mediterranean-palette-replacement.md).

## What changes

The container is no longer a single beached 4×2 object (the current `CONTAINER_LAYOUT` in
`src/world/terrain.js`). It becomes a **two-storey trading house built from stacked
shipping containers** — a designed building with a glass storefront, a wooden deck,
an exterior staircase, and a flat rooftop. It reads as a *destination*, not salvage.

The narrative survives intact: Hermes placed the containers; the Examplens stacked
them into a trading house. The mythic contradiction (an *ancient* shipping container)
stays — see the colour note below.

## Colour: weathered black/charcoal (decided)

The original brief asked for "bold, uniform red or black — not rusted or weathered."
That option was resolved **after** the brief was written: blocker [#7](https://example.com/builders#/blocker/7) (Lars, 2026-06-10,
recorded as a style-guide rule) fixed the container as **weathered black/charcoal
corrugated metal with rust streaks**, with faded Hermes-teal as an *accent only* (the
door + the caduceus etch). The later decision wins. So the building is charcoal and
weathered — it is "designed architecture" by its *shape and glass*, not by looking
factory-new. ADR 0044 already constrains the replacement palette to carry enough
charcoal/grey value steps for this.

## Top-down structure (32×32 tiles, FireRed building anatomy)

FireRed conveys buildings top-down as **facade rows (what you'd see standing in front)
topped by roof rows**. A second storey = a taller facade. The reference is the Celadon
department store: tall glass-fronted facade, flat roof.

The building is an **8-wide × 6-tall** visual block (up from 4×2):

| Rows (top→bottom) | Band | Content |
|---|---|---|
| 1–2 | **Rooftop** | Flat container roof; 1-px railing along the edge tiles; a stair landing tile at the right edge where the exterior staircase arrives. Future rooftop deck props (parasol, crates) are object overlays, not part of this family. |
| 3–4 | **Upper-storey facade** | Charcoal corrugated container walls with a continuous band of **large glass panels** (semi-transparent blue-grey, single white highlight stripe). Container seams visible at the stacked-unit joints. |
| 5–6 | **Ground-storey facade** | Glass storefront panels flanking a centred **door** (the one Hermes-teal accent, faint caduceus etch, warm interior glow). Wall-mounted light fixtures as small details on the wall tiles either side — lit at dusk/night. |

Attached, outside the 8×6 block:

- **Exterior staircase** — a 1-tile-wide steel stair strip climbing the building's right
  side from ground to the rooftop landing. Purely visual in V2 (blocking); the rooftop
  becomes walkable in a later version, the art shouldn't need to change for that.
- **Wooden deck** — a 2-row walkable apron in front of the ground facade, drawn as an
  alpha-margined object overlay over sand (the marble-path technique, [ADR 0013](../adr/<redacted>.md)),
  so it works on any ground. Outdoor furniture (table, two chairs) are blocking
  object singletons placed on the deck, off the door's walking line.

### Placement and collision

Anchor at **(11, 4)** in the current 30×18 world: the building spans cols 11–18,
rows 4–9 (grass behind, sand in front), the deck spans rows 10–11, and the existing
marble path (col 13, rows 10–13) shifts to meet the door at col 14–15. All building
tiles **block**, including the door — interaction stays "stand adjacent and face it,"
exactly like the current container door. Deck tiles are walkable; furniture blocks.

## Pipeline mapping (what gets generated, later)

Per [ADR 0008](../adr/<redacted>.md), coherent groups are families, not per-tile calls:

1. **`container_building_facade`** family — wall, glass-panel, door, light-fixture, and
   staircase tiles (replaces the 2×4 `container` family in `art/template/families.json`).
2. **`container_building_roof`** family — roof field, railing edges/corners, stair landing.
3. **`deck_wood`** — 16-autotile alpha-tile line family (same recipe as `marble_path`).
4. **Furniture singletons** (table, chair) — per-tile pipeline.

**Sequencing rule: generate nothing until [#640](https://example.com/builders#/task/640) / ADR 0044 lands.** Every one of these
tiles would be quantized against the old palette and re-done after the Mediterranean
swap. Spec work ([#643](https://example.com/builders#/task/643)) can proceed now; generation waits.

## Engineering follow-up (not this task)

The world model needs a matching change in **both** `map.js`/`terrain.js` twins
(server + client): new OBJECT ids, an 8×6 building layout replacing
`CONTAINER_PANELS_ROWMAJOR`/`CONTAINER_LAYOUT`, deck overlay placement, and blocking
rules as above. That is an engineering task to be filed when the facade family's tile
ids are final (after [#643](https://example.com/builders#/task/643)).
