# ADR 0097 — One active claim per session + a claim binds to a dedicated worktree

**Date:** 2026-06-29
**Status:** Accepted
**Track:** `internal` (development system / lifecycle)
**Task:** [#1642](https://example.com/builders#/task/1642) (GDS-V4)
**Amends:** [ADR 0049](<redacted>.md) (the parallel-safety contract). 0049 fixed *cross-claim* parallel safety (two claims colliding); this adds the missing *within-session* invariant.

## Context — the commingled-ship hole

ADR 0049 made cross-claim safety honest: `git merge` is the authoritative collision detector for interactive builders, and `uniq_active_claim_per_task` guarantees two sessions can't both claim the same task. But it left one invariant unstated, and a real failure mode followed from it.

A single Claude Code session works inside **one git worktree**, and that worktree owns **one branch**. If a builder claims a second task from the *same* worktree, both tasks' commits land on that one branch. `/builder-ship` publishes the whole branch — so shipping the first task drags the second task's (unfinished, ungraded) commits along with it. The ship is *commingled*: two tasks' work ride out under one task's ship, the grader reads a diff that mixes scopes, and the second task's ledger is now a lie.

The only pre-existing "one claim" guard was `gateNewcomerClaim`: **Xenos-only**, **builder-scoped**, and **fail-open**. It kept a brand-new builder focused, but did nothing for a Metic/Archon (or even a graduated Thetes) running two claims from one worktree, and it keyed on the builder, not the worktree — so it couldn't express "one claim *per worktree*" at all.

## Decision

Two new rules, both at the lifecycle layer:

### 1. One active claim per session

`POST /api/gds/claims` refuses a new claim when the **same `creator_session_id`** already holds an active claim, returning `409 session_already_has_active_claim` whose body names the in-flight task (`active_task_id` + `active_task_title`) and the remedy. This generalizes `gateNewcomerClaim` from Xenos-only to **all ranks** and from builder-scoped to **session-scoped**.

- **Session-scoped, NOT builder-scoped — the load-bearing choice.** A builder legitimately runs many sessions in parallel, each in its own worktree with its own single claim (the `feedback_parallel_sessions_not_anomaly` memory; one human builder, many sessions, is the *norm* at current scale). Keying on the builder would break that norm — it would cap a builder at one claim across all their worktrees. Keying on `creator_session_id` (already on the claim row, set per-CLI-session) caps each *worktree* at one claim, which is exactly the branch-isolation invariant we need and nothing more.
- **Fail-CLOSED.** Unlike `gateNewcomerClaim` (fail-open — onboarding plumbing must never brick a claim), this is a *correctness* guard against commingled ships. If the session-active-claim lookup throws, the route REFUSES (`409 session_claim_check_failed`) rather than silently allowing a second claim through. The deliberate asymmetry: a flaky onboarding read should not block work, but a flaky concurrency read must not let a commingling claim slip past.
- **NULL-session handling.** A web claim (`bind_session=false`, [#616](https://example.com/builders#/task/616)) stores `creator_session_id = NULL` and is adoptable by any of the builder's CLI sessions. The guard **skips NULL sessions**: an incoming NULL-session claim is allowed (there is nothing to scope to), and a pile of existing NULL-session web claims never counts against any CLI session (the DB lookup filters to the same non-null session, and the pure decision double-checks `creator_session_id != null`). So web-claim-then-ship-from-any-terminal keeps working untouched.
- **The decision is a pure, exported function.** `shouldRefuseSessionClaim({ activeClaimsForSession, creatorSessionId })` lives in `modules/lifecycle/routes/claims.js` and is unit-tested DB-free (`tests/one_active_claim_per_session.mjs`). The route middleware (`gateOneActiveClaimPerSession`) is thin: resolve the session, look up its active claims, call the pure fn, translate refuse→409.

### 2. A claim binds to a dedicated worktree

The default claim flow (`.claude/skills/builder-claim/SKILL.md`) ensures the task runs in its **own** worktree (e.g. `EnterWorktree task-N`) so a builder never reuses a worktree that already owns a claim. This is the harness's job — the GDS cannot create worktrees — so it is enforced as skill guidance plus the server guard above: if the harness reuses a busy worktree, the server refusal is the backstop, and the documented remedy is a fresh worktree/session.

### DB defence-in-depth

`migrations/<redacted>.sql` adds a **partial unique index** `uniq_active_claim_per_session ON claims (creator_session_id) WHERE released_at IS NULL AND creator_session_id IS NOT NULL`.

- **Predicate divergence from the task spec, on purpose.** The spec cited `WHERE status='active'`, but `claims` has **no `status` column** — "active" is the table's `released_at IS NULL` convention (the row's lifecycle status lives on `tasks`). The index uses the real column.
- **Migration safety.** A unique index *fails to create* if existing rows already violate it, which would block deploy. The migration first heals any current violation (keep the earliest active bound claim per session, close the rest — the same shape as migration 174), so the `CREATE` always succeeds; it is idempotent. The **app-layer guard is authoritative**; the index is belt-and-braces and must not break deploy.

## Consequences

- A session can hold at most one active claim — commingled ships are structurally prevented, not just discouraged.
- The many-sessions-per-builder norm (ADR 0049's `feedback_parallel_sessions_not_anomaly`) is preserved exactly: each worktree/session still gets its own claim.
- Web claims (NULL session) are unaffected — claim-in-browser, ship-from-any-terminal still works.
- This composes with, and does not alter, ADR 0049's split cross-claim contract: the per-task index, the advisory `touches[]` warning, and the autonomous-runner footprint gate are all untouched. This ADR only adds the within-session invariant 0049 left implicit.
