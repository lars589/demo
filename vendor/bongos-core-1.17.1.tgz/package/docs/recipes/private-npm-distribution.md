# Recipe — private-first npm distribution (core + client)

> Implements [ADR 0134](../adr/<redacted>.md). Pre-launch, `@bongos/core` and `@bongos/client` publish as **private, scoped** npm packages on the owner's paid `bongos` npm org (the canonical brand); at launch they flip to public. The daily command is `bongos` regardless of package name.
>
> **Why private must be scoped:** on npm, *unscoped* names are always public — only *scoped* names (`@bongos/…`) can be private, and only on a paid plan. So the packages publish under the `@bongos` scope, which maps to the paid `bongos` org.

## The pieces

| Package | What it is | Built by |
|---|---|---|
| `@bongos/core` | the platform an instance installs + the `bongos` CLI (`bin`) | `bongos package-core` (`scripts/gds/package-core.js`) — synthesizes the package.json + a pruned lockfile, redacts, and packs a `.tgz` |
| `@bongos/client` | the generated typed API client | `node scripts/gds/gen-api-client.js` (regenerates `clients/bongos-client/`) |

Both carry `publishConfig: { access: "restricted" }`, so **publishing them is private by default** — no public leak if a flag is forgotten.

## One-time owner setup (only the owner can do these)

These involve payment and permanent, account-level actions. They are **not** done inside a build session.

1. **Put the `bongos` npm org on a paid plan.** Private scoped publishing requires it. On npmjs.com → your org → Billing → upgrade to a plan that allows private packages (npm Teams, ~$7/member/month). Add as members only the people who need to publish or install during pre-launch — each is a billed seat.
2. **Create an access token.** npmjs.com → Access Tokens → *Generate New Token* → **Classic → Automation** (bypasses 2FA, which npm requires to publish), with **read-write** on the `@bongos` packages — a **read-only** token is enough for machines that only install. Store it as an environment variable, never in a committed file:
   ```sh
   export NPM_TOKEN=<redacted>
   ```

## Publish (the real, permanent step — owner)

Always preview with a dry-run first (no upload, no login needed):

```sh
# Core — build the tarball and DRY-RUN the private publish:
node scripts/gds/package-core.js --publish
```

Look for `restricted access` and the `@bongos/core@<version>` line. When it looks right, publish for real (this is **permanent** — npm can't delete a name after 72h):

```sh
npm login                                         # once per machine (+ 2FA)
node scripts/gds/package-core.js --publish --live # actually publishes, still private
```

For the client (note the `./` — without it, npm reads the path as a git package spec, not a folder):

```sh
node scripts/gds/gen-api-client.js                # ensure it's fresh
npm pack ./clients/bongos-client --dry-run        # token-free content preview
npm publish ./clients/bongos-client               # real (publishConfig makes it restricted; needs npm login)
```

## Install a private package (any consumer machine or instance)

Add a one-line `.npmrc` (repo-root or `~/.npmrc`) that reads the token from the environment:

```
//registry.npmjs.org/:_authToken=<redacted>
```

Then, with `NPM_TOKEN` set in the environment:

```sh
npm install -g @bongos/core   # global → the `bongos` command, then `bongos init`
npm install @bongos/client    # in a project that calls the API
```

Without a valid token + org membership the install 404s — that is the private gate working.

## Provisioning: registry pull vs vendored tarball (task 2090)

Provisioning defaults to installing the core from a **vendored tarball** committed into each instance repo (task 2053) — offline, needs no token, and stays the default/fallback until the registry path is proven on a real greenfield standup. The registry pull is **opt-in and fail-soft**:

- **Turn it on** by setting `PROVISION_CORE_FROM_REGISTRY=1` in the control-plane runner's environment (e.g. `/etc/cloudbongos/box.env`) **and** providing a read-only `NPM_TOKEN` (a Classic **Automation** token — read-only — from the paid `bongos` org). With both present, the standalone scaffold pins `@bongos/core@<version>` from the registry and writes an env-fed `.npmrc` (`_authToken=<redacted> instead of vendoring a tarball; `npm ci` then pulls the private package (the token is inherited from the runner env — never committed).
- **Fail-soft**: if the flag is set but `NPM_TOKEN` is absent, provisioning logs a notice and **falls back to the vendored tarball**, so a tokenless standup still works.
- **Directly**: `bongos init --registry-core` scaffolds the registry shape (caret pin + `.npmrc`; generates the lockfile when `NPM_TOKEN` is set). `bongos upgrade --to <v> --registry` bumps a consumer to a registry version. Both are mutually exclusive with the vendored `--vendor-core` / `--from` inputs.

A tokenless registry `npm ci` 404s cleanly (`E404 … @bongos/core … could not be found or you do not have permission to access it`) — the expected pre-launch outcome.

> **Proven end-to-end (2026-07-08, task 2118 / blocker 71).** A real `bongos init --registry-core` scaffold, with a valid read-only token in `NPM_TOKEN`, resolved `@bongos/core@1.17.0` straight from `registry.npmjs.org` and generated a reproducible `package-lock.json`. Both legs are confirmed: the registry pull works with a token and fails closed (404) without one. Provisioning still defaults to the vendored tarball until an owner explicitly sets `PROVISION_CORE_FROM_REGISTRY=1` on a live runner.

## Going public at launch

Pick either — both keep the daily `bongos` command working:

- **Flip the same scoped packages public** (simplest):
  ```sh
  npm access public @bongos/core
  npm access public @bongos/client
  ```
  (Or change `publishConfig.access` to `"public"` and republish.) Public installs need no token; the paid seats can be dropped.
- **Also publish the unscoped vanity name** for `npm install -g cloudbongos` — that is [task 2025](https://example.com/builders#/task/2025) (rename in `package-core.js`/`upgrade.js` + docs), done at launch.
