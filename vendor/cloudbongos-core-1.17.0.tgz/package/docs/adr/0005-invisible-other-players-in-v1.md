# 0005 — Other players are invisible in V1

- **Status:** Accepted
- **Date:** 2026-05-08
- **Deciders:** Lars

## Context

The world is shared and persistent — every visitor lands in the same world, and their actions persist. The most obvious feature flowing from "shared world" is "you can see other players walking around."

Showing other players in real time means:

- The server broadcasts every player's position to every other player on every tick
- The client renders an arbitrary number of remote-player sprites with smooth interpolation
- The wire protocol carries continuous position deltas, not just intent events
- Reconnect, disconnect, late-join, and view-frustum culling all need handling

That is meaningfully more network traffic and meaningfully more client/server complexity than V1's "one player at a time, in their own window of the world" experience.

## Decision

In V1, **other players are invisible**. The world is shared and persistent on the server side — `world_events` records everyone's actions, the 100-seat cap is enforced, queue admission is real — but the client renders only the local player and the static world.

The persistence and presence of other players is felt **indirectly**: through changes to the world they make (when V1 ships world-mutating actions), and through being placed in a queue when 100 are already in.

## Alternatives considered

- **Visible other players from V1.** Doable but trades several days of network protocol + rendering work against the rest of V1's scope. Rejected to keep V1 small.
- **Visible only at the same tile / proximity flicker.** Half-measure that adds the network cost of broadcasting positions without delivering the social experience cleanly. Rejected.
- **Show silhouettes / shadows / ghosts.** Same network cost, marginal experience gain. Rejected.

## Consequences

- **The V1 networking problem shrinks dramatically.** No position broadcast, no remote-sprite rendering, no interpolation logic. Wire protocol is intent-only (move, interact).
- **Loneliness in V1 is real.** Players know the world is shared (the queue is proof) but the moment-to-moment experience is solo. We accept this for V1 because the discovery-of-an-ancient-secret tone partly suits a quiet, solitary first encounter.
- **V2 candidate parked in `limitations/backlog.md`.** "Visible other players" is the highest-value next feature once V1 is shipped; lifting this limit defines V2's scope.
- **Persistent world-state work done for V1 is not wasted** — adding visible players in V2 is purely additive to the protocol; the existing event log and identity model carry forward unchanged.
