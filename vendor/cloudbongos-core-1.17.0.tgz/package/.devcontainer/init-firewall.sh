#!/usr/bin/env bash
# init-firewall.sh — default-deny outbound firewall for the Amazonprimea Dev Box.
#
# ADR 0031 §3 + §6: the box is an org-controlled, egress-restricted surface. This
# script flips the container to default-DROP and then allow-lists ONLY the hosts
# the OTB toolchain legitimately needs. Everything else is blocked, so a builder
# session (or a compromised dependency) cannot quietly exfiltrate to an arbitrary
# host.
#
# Mechanism (mirrors Anthropic's reference init-firewall.sh):
#   1. Resolve every allow-listed host to IPs WHILE egress is still open.
#   2. Stuff them into an `ipset` (hash:net so GitHub's CIDR ranges fit).
#   3. Flip INPUT/OUTPUT/FORWARD to DROP, then re-allow loopback, established
#      connections, DNS, SSH, and OUTPUT to the ipset.
#   4. Verify: a blocked host must fail; an allow-listed host must succeed.
#
# Allow-list (and WHY each is here — keep this tight, every addition is egress):
#   - GitHub  (api.github.com/meta ranges) ......... git push/pull, `gh`
#   - npm registry (registry.npmjs.org) ............ `npm ci`
#   - Anthropic API (api.anthropic.com + telemetry)  the brain (tokens), Claude Code
#   - amazonprimea.com + staging ................... the GDS API (/api/gds/* CLI)   [OTB]
#   - generativelanguage.googleapis.com ............ the pixel-art pipeline (Gemini) [OTB]
#   - pypi.org + files.pythonhosted.org ............ `pip install` art deps          [OTB]
#
# Runs as root via `sudo` from the devcontainer postStartCommand. Needs the
# NET_ADMIN + NET_RAW capabilities (granted by runArgs in devcontainer.json).
#
# Fail posture: FAIL-CLOSED by default. If the rules cannot be applied or the
# verification fails, the script exits non-zero. Set FIREWALL_OPTIONAL=1 to
# downgrade a cap/permission failure to a loud warning that still lets the
# container boot — intended ONLY for a laptop Docker host that won't grant
# NET_ADMIN (where the builder is already root of their own machine, so egress
# lockdown is advisory anyway — see ADR 0031 §6 "honest limit"). The DO box
# (#598) sets FIREWALL_OPTIONAL unset, so it always enforces.

set -euo pipefail
IFS=$'\n\t'

OPTIONAL="${FIREWALL_OPTIONAL:-0}"

# Hosts to allow-list by name (resolved via dig at runtime). GitHub is handled
# separately via its published meta ranges. Keep this list minimal.
ALLOWED_HOSTS=(
  "registry.npmjs.org"
  "api.anthropic.com"
  "statsig.anthropic.com"
  "sentry.io"
  "amazonprimea.com"
  "staging.amazonprimea.com"
  "generativelanguage.googleapis.com"
  "pypi.org"
  "files.pythonhosted.org"
)

log()  { echo "[firewall] $*"; }
die() {
  # Honor the documented escape hatch: a cap/permission failure on a laptop
  # host downgrades to a warning instead of bricking container startup.
  # The bypass is env-driven, so it can't be access-controlled from inside the
  # script — the mitigation is a LOUD, greppable audit line so any use is
  # visible in container logs / log aggregation. On the org DO box this must
  # never be set; if this banner appears there, investigate.
  if [ "$OPTIONAL" = "1" ]; then
    log "==================== SECURITY AUDIT ===================="
    log "egress firewall DISABLED via FIREWALL_OPTIONAL=1"
    log "  reason: $*"
    log "  the box is running WITHOUT default-deny egress (laptop-only escape hatch)"
    log "======================================================="
    exit 0
  fi
  log "ERROR: $*"
  log "If this host genuinely cannot grant NET_ADMIN (e.g. a restricted laptop Docker),"
  log "re-run with FIREWALL_OPTIONAL=1 to boot without egress lockdown."
  exit 1
}

# Pre-flight: we must be root and have the iptables/ipset tooling + caps.
if [ "$(id -u)" -ne 0 ]; then
  die "must run as root (expected: sudo $0)"
fi
command -v iptables >/dev/null 2>&1 || die "iptables not installed"
command -v ipset    >/dev/null 2>&1 || die "ipset not installed"
command -v dig      >/dev/null 2>&1 || die "dig (dnsutils) not installed"

# A NET_ADMIN probe: try a harmless list. If the kernel refuses, we lack the cap.
if ! iptables -L >/dev/null 2>&1; then
  die "cannot manage iptables (NET_ADMIN capability missing?)"
fi

log "resolving allow-list while egress is still open…"

# Fresh ipset. hash:net so we can store both single IPs and CIDR ranges.
# create -exist + flush (not destroy+create): on a manual re-run an iptables
# OUTPUT rule may still reference the set, which makes `destroy` fail. Flushing
# empties it in place while keeping the object valid.
ipset create allowed-domains hash:net -exist
ipset flush allowed-domains

add_ip() {
  # Validate it looks like an IPv4 (or CIDR) before adding, so a bad DNS answer
  # can't inject garbage into the set.
  local ip="$1"
  if [[ "$ip" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}(/[0-9]{1,2})?$ ]]; then
    ipset add allowed-domains "$ip" 2>/dev/null || true
  fi
}

# --- GitHub: use the published meta ranges (covers github.com, api, git, web) -
log "  + GitHub meta ranges"
gh_meta="$(curl -fsS --max-time 20 https://api.github.com/meta || true)"
if [ -n "$gh_meta" ] && command -v jq >/dev/null 2>&1; then
  # .web + .api + .git are the egress-relevant range groups.
  while read -r cidr; do
    [ -n "$cidr" ] && add_ip "$cidr"
  done < <(echo "$gh_meta" | jq -r '(.web // []) + (.api // []) + (.git // []) | .[]' 2>/dev/null | grep -E '^[0-9]+\.' || true)
else
  # Fallback: resolve the hostnames directly if the meta API is unavailable.
  log "    (meta API unavailable — falling back to direct resolution)"
  for h in github.com api.github.com codeload.github.com objects.githubusercontent.com; do
    while read -r ip; do add_ip "$ip"; done < <(dig +short +noall +answer A "$h" 2>/dev/null | grep -E '^[0-9]+\.' || true)
  done
fi

# --- Everything else: resolve by name -----------------------------------------
for host in "${ALLOWED_HOSTS[@]}"; do
  log "  + $host"
  while read -r ip; do
    add_ip "$ip"
  done < <(dig +short +noall +answer A "$host" 2>/dev/null | grep -E '^[0-9]+\.' || true)
done

# --- Host networking: keep the container reachable from / to its Docker host --
# Allow the host gateway + the container's own /24 so SSH in, the dev server,
# and DNS-to-the-Docker-resolver keep working after we flip to DROP.
host_ip="$(ip route | awk '/default/ {print $3; exit}')"
if [ -n "${host_ip:-}" ]; then
  host_net="$(echo "$host_ip" | sed 's/\.[0-9]*$/.0\/24/')"
  log "  + host network ${host_net}"
  add_ip "$host_net"
fi

n="$(ipset list allowed-domains | grep -cE '^[0-9]+\.' || true)"
log "allow-list built: ${n} entries"
[ "$n" -gt 0 ] || die "allow-list is empty — refusing to flip to default-DROP (would sever everything)"

log "applying default-deny policy…"

# Flush prior rules so re-runs are idempotent.
iptables -F
iptables -X 2>/dev/null || true

# Loopback — always.
iptables -A INPUT  -i lo -j ACCEPT
iptables -A OUTPUT -o lo -j ACCEPT

# Established/related return traffic.
iptables -A INPUT  -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# DNS — keep resolution working at runtime (long-running procs re-resolve).
iptables -A OUTPUT -p udp --dport 53 -j ACCEPT
iptables -A OUTPUT -p tcp --dport 53 -j ACCEPT

# SSH — the Desktop/Remote-Control on-ramp (ADR 0031 §1).
iptables -A INPUT  -p tcp --dport 22 -j ACCEPT
iptables -A OUTPUT -p tcp --dport 22 -j ACCEPT

# The actual allow-list: outbound only to resolved, vetted IPs.
iptables -A OUTPUT -m set --match-set allowed-domains dst -j ACCEPT

# Default DROP for everything not explicitly allowed above.
iptables -P INPUT   DROP
iptables -P FORWARD DROP
iptables -P OUTPUT  DROP

log "verifying…"

# A blocked host MUST fail (proves the deny is real).
if curl -fsS --max-time 6 https://example.com >/dev/null 2>&1; then
  die "verification FAILED: example.com is reachable but should be blocked"
fi
log "  ✓ blocked host (example.com) is unreachable"

# An allow-listed host MUST succeed (proves we didn't sever everything).
if ! curl -fsS --max-time 10 https://api.github.com/zen >/dev/null 2>&1; then
  die "verification FAILED: api.github.com is unreachable but should be allowed"
fi
log "  ✓ allow-listed host (api.github.com) is reachable"

# Our own GDS API must be reachable (the CLI depends on it). Non-fatal warn:
# the host may be mid-deploy; the firewall correctness is already proven above.
if curl -fsS --max-time 10 https://amazonprimea.com/healthz 2>/dev/null | grep -q '^ok$'; then
  log "  ✓ GDS API (amazonprimea.com) is reachable"
else
  log "  ! GDS API healthz did not return ok (host may be redeploying) — allow rule is in place"
fi

log "default-deny firewall active."
