# ADR 0034 — `thetes`: a 4th live rank for graduated newcomers, with auto-graduation after 3 ships

**Date:** 2026-06-05
**Context:** GDS-V3, task [#692](https://example.com/builders#/task/692). Amends [ADR 0018](<redacted>.md) (the three-rank model). Companion to [ADR 0016](<redacted>.md) (server-enforced permissions) and the newcomer-supply work (the `newcomer-generator` routine). Role-sync mirrors it to Discord per [ADR 0033](<redacted>.md).
**Status:** Accepted + shipped.
**Track:** `internal` (dev-system / builder onboarding).

## Problem

A new builder defaults to `xenos`, the sandboxed entry rank, which can claim **only** tasks flagged `newcomer_friendly`. That pool is chronically under-supplied: a fresh Xenos repeatedly arrives to an empty queue, files some ideas (which a Xenos cannot even promote — `PATCH /inbox` is Metic+), and finds the queue still empty. Builder 25 hit exactly this loop. The supply-side fix (a generator that tops up `newcomer_friendly` tasks) helps, but it fights physics: it must perpetually feed *every* newcomer's *entire* tenure.

The jump out of the sandbox was also all-or-nothing: `xenos` → `metic`, where Metic carries real trust (idea triage, blocker resolution, red-team filing, planning/priority, claiming sensitive infra). That is too big a grant to hand out just so someone can pick up ordinary work, so it stayed gated behind a manual Archon decision — leaving newcomers stuck in the starved sandbox in the meantime.

## Decision

Add **`thetes`** as a 4th LIVE rank between `xenos` and `metic`, and **time-box the sandbox**: a Xenos auto-graduates to Thetes after shipping a few tasks.

### 1. The ladder gains a tier

`xenos (1) < thetes (2) < metic (3) < archon (4)` — the `REQUIRES_RANK_TIER` map in `src/bongos/db.js`. `thetes` was already a reserved value in the `builders.rank` CHECK enum (migration 023), so no `builders` schema change was needed; migration `068` only widens the inverse gate `tasks.requires_rank` to accept `'thetes'`.

### 2. What Thetes can and cannot do

- **Can:** claim the **entire general queue** — any task whose `requires_rank` is the default `'xenos'` — with **no** `newcomer_friendly` restriction. This is the whole point: a Thetes draws from the large pool, not the starved newcomer pool.
- **Cannot:** anything scope-shaping or trust-bearing. It is blocked from tasks raised to `requires_rank='metic'/'archon'`, and — because `requireRank()` is **exact-set membership** (`src/bongos/auth.js`), not tier comparison — it inherits **none** of Metic's route grants (idea triage, blocker resolution, red-team, planning/priority, task create/edit). Those stay Metic+ with zero code change.

This asymmetry is what makes the next decision safe.

### 3. Auto-graduation is automatic, bounded, and low-risk

A Xenos is promoted to Thetes the moment their **3rd** task reaches `shipped` (merged + deployed). It happens server-side, **inside the ship transaction** (`db.shipTask` → `db.maybeAutoGraduateToThetes`), atomic with the ship. The count is `COUNT(*)` of the builder's tasks at `status='shipped'` **attributed via `tasks.shipped_by`**, and the promotion is rank-guarded (only a current `xenos`), so it is idempotent — it fires exactly once, and a non-Xenos never re-promotes.

> **Trigger note (corrected in [#704](https://example.com/builders#/task/704)):** the original [#692](https://example.com/builders#/task/692) cut graduated at `confirmed` (credits-earned). The Archon rule is "after 3 tasks are **successfully shipped**," so the trigger moved from the confirm paths to `shipTask`, keyed on `shipped` status + `shipped_by` attribution.

**`thetes` is reachable two ways.** The automatic 3-shipped-tasks graduation above, AND a deliberate Archon promotion via `PATCH /builders/:id/rank` (e.g. to fast-track a builder the Archon already trusts to roam the queue). Both are valid; they coexist. (A short-lived [#704](https://example.com/builders#/task/704) cut wrongly refused manual set-to-thetes; [#706](https://example.com/builders#/task/706) removed that block — the Archon must be able to grant the rank directly.)

Auto-promotion of *rank* normally raises a trust-boundary flag (ADR 0016: rank is authority). It is acceptable here precisely because **graduating to Thetes grants no authority** — only breadth of claiming. The dangerous grant (Thetes → Metic) remains a deliberate Archon promotion through the single rank chokepoint (`PATCH /builders/:id/rank`). So the machine can hand out "you may now pick up normal work" but never "you may now shape scope or touch sensitive infra."

The promotion reuses the existing rank-change machinery (refactored into a shared in-transaction core `_applyRankChangeTx`): it writes the same `credit_log` `rank_change` audit row (here tagged `auto-graduation: N shipped tasks`), earns the standard +5 promotion ceremony delta, does **not** revoke sessions (promotions never do), and fires the post-commit box-access reconcile.

## Consequences

- **The newcomer-supply problem shrinks to a 3-task window.** The `newcomer-generator` now only has to keep the queue stocked for a builder's first three ships, not their whole tenure. Starvation after that is structurally impossible — Thetes draws from the general queue.
- **`metic` is now also marked LIVE** in the onboarding rank-ladder diagram. The diagram fact-extractor (`diagram-facts.wiredRanks`) gained a 5th signal — membership in `REQUIRES_RANK_TIER` — which is the honest definition of "this rank participates in the live claim gate." Previously `metic` was wired-in-spirit (skills said "Metic+") but the extractor missed it.
- **Exact-set `requireRank` is load-bearing.** Adding a rank *below* an existing gated rank is safe only because the gates name their allowed ranks explicitly. A tier-based `requireRank` would have silently granted Thetes everything ≥ its tier. This is now documented as the reason the exact-set design stays.
- **`RANKS` array order is load-bearing too.** `setBuilderRank` derives promotion-vs-demotion from `RANKS.indexOf`; `thetes` had to move to sit between `metic` and `xenos` so `xenos→thetes` reads as a promotion and `thetes→metic` as a further promotion.
- **Reversibility.** A mis-graduated builder is demoted through the normal Archon path; demotion revokes their sessions, so the lower rank takes effect on their next request.

## Alternatives considered

- **Just raise the newcomer-queue target / fix supply only.** Treats the symptom. A shared pool of N newcomer tasks is always racing consumption; time-boxing the sandbox removes the dependency entirely for everyone past their 3rd ship.
- **Auto-promote `xenos` straight to `metic`.** Rejected: Metic carries triage/trust/red-team/infra powers no automatic rule should hand out. The new intermediate rank is exactly the "breadth without trust" tier that makes auto-promotion safe.
- **Promote by drachmae or karma instead of ship count.** Rejected for v1: ship count is the most legible "you've proven you can land work" signal and is already the credit-landing event. A richer policy can layer on later.
