# ADR 0046 — Sandbox-first review in the dev-box ship flow

**Date:** 2026-06-11
**Context:** GDS-V3, task [#927](https://example.com/builders#/task/927). Builds directly on [ADR 0044](<redacted>.md) (the per-box live game preview / "sandbox") and the three-state ship lifecycle in `scripts/gds/ship.js` (Phase 5). Companion to [ADR 0031](<redacted>.md) (dev boxes) and [ADR 0016](<redacted>.md) (the gate is a workflow aid, not an authority surface).
**Status:** Accepted.
**Track:** `internal` (dev-system / builder experience).

## Problem

ADR 0044 gave every named-tunnel dev box a live sandbox (`sandbox-<login>.example.com`) serving the box's `/workspace` working tree — but nothing in the development flow *uses* it. A builder on a box can still run `/builder-ship` on a game change they have never seen running, and the pipeline carries it straight toward prod. The sandbox exists; the methodology doesn't ask for it. Lars's directive (2026-06-11): anytime a builder is on a dev box, they should **first stage their work on their sandbox to see it, have the opportunity to suggest changes, and only then decide to complete it and ship to the main game**.

## Decision

**Make staging-and-reviewing on the sandbox a first-class, enforced step of the dev-box ship flow.** Two pieces:

### 1. `/builder-stage` — staging as a named verb (`scripts/gds/sandbox-stage.js`)

Staging = restart `box-game-preview.service` so the sandbox serves the current `/workspace` working tree, health-check `127.0.0.1:3000`, and write a **staged marker** (`otb-sandbox-staged.json` in the OS temp dir) recording a SHA-256 stamp of exactly what was staged. The stamp is a **content hash scoped to the previewable game surfaces** (`git ls-files` + `git hash-object` over `public/`, `src/world/`, `src/rooms/`, `server.js`, tracked + untracked): editing a game file — committed or not — changes it, while editing docs/GDS files or merely `git add`/committing the *same* content does not. So "staged" can never silently mean "staged some older version of the game", and the natural stage → review → commit → ship flow keeps the marker fresh. The command prints the sandbox URL and tells the builder to review before shipping. Sub-commands: `status` (is the sandbox current?), `url`.

### 2. The ship gate — `ship.js` checks the marker before the claim resolves

`shipMain()` runs the gate after local verification (scanner + smoke + empty-diff guard) and **before** `POST /claims/:id/resolve` — i.e. before anything counts, so an abort leaves the claim active and the builder iterates freely. Decision table (pure `decideShipGate()`, unit-tested):

| Condition | Action |
|---|---|
| `--skip-stage` | skip (escape hatch; not routine) |
| not a dev box (no `/etc/otb/box.env`) | skip — laptop/operator sessions unchanged |
| diff touches no previewable game surface | skip — the sandbox shows the game; GDS/doc/infra diffs have nothing to look at there |
| box on the quick tunnel (no `BOX_PREVIEW_HOSTNAME`) | skip with notice — ADR 0044 already scopes the sandbox to named-tunnel boxes |
| staged marker matches the current tree stamp | pass — already staged + reviewable; proceed |
| stale/absent marker, **interactive TTY** | stage now, print the URL, ask: "Reviewed on the sandbox — ship this to the main game? [y/N]" — No aborts with the claim intact |
| stale/absent marker, **non-interactive** | stage so the sandbox shows the work, then **abort with the claim intact and the review URL** — never hangs on stdin, never silently skips the review. This is the dominant path: a builder's Claude session runs `ship.js` through a non-TTY shell, so the agent relays the URL, the human reviews (and suggests changes), and the re-run passes on the now-fresh marker |

"Previewable game surfaces" = `public/`, `src/world/`, `src/rooms/`, `server.js` — the paths the sandbox host actually renders (host-routing sends `sandbox-*` to the game). The check covers both the committed diff **and** uncommitted working-tree edits, since the sandbox serves the working tree.

### Failure posture: the gate is a review aid, not a wall

If staging itself fails (service won't start, health-check times out), the ship **warns loudly and continues**. The hard quality gates remain the scanner, smoke, and the grader panel; a broken preview service must not be able to brick shipping. Likewise the gate runs client-side in `ship.js` by design — it shapes the cooperative builder's workflow; it is not a trust boundary (ADR 0016: server-side rank checks and the grader are what enforce).

## Alternatives considered

- **Server-side enforcement (refuse `resolve` without a staged attestation).** Rejected: the server cannot verify what a builder's box showed them — the attestation would be client-claimed anyway, adding schema + API surface for no real guarantee. Workflow nudges belong client-side; trust stays where ADR 0016 put it.
- **Gate inside `/builder-ship`'s skill prose only (no code).** Rejected: skills guide the agent but nothing re-checks; the point is that an un-staged game change *reliably* pauses for review.
- **Always require review for every diff.** Rejected: the sandbox renders the game; staging a `docs/` or GDS change shows nothing and just adds a restart + prompt of pure friction.

## Consequences

- The dev-box loop becomes: edit → `/builder-stage` → review at `sandbox-<login>` → iterate → `/builder-ship` (gate passes on the fresh marker) → main game. A builder who skips straight to ship gets staged + paused once, in-line.
- The non-interactive abort is deliberately bypassable by an immediate re-run (the first run staged, so the marker is fresh). That is acceptable: the gate is cooperative workflow shaping, and the agent in between is instructed to put the URL in front of the human. A truly autonomous box run that must not pause passes `--skip-stage` explicitly.
- Laptop sessions (no box.env) are completely unaffected — including the operator's own ships and `/merge-mode`.
- `--skip-stage` exists for genuine breakage; like `--skip-grade` it is an escape hatch, not a routine flag.
- The marker lives in the box's temp dir — it is per-box, survives within a boot, and is naturally invalidated by edits (stamp mismatch). No DB schema, no new API surface, $0.

## Amendment — 2026-06-13, task [#1048](https://example.com/builders#/task/1048): record the approval + position the link in chat

Lars's directive (2026-06-13), after the gate shipped: (1) the sandbox link must be **positioned prominently in chat** when a change is ready to review, and (2) the builder's review-and-approve must be **recorded**, not left as an ephemeral marker. Both are now built; this amendment supersedes two specific stances above.

- **Prominent in-chat link.** `runShipGate` now prints a delimited `🔍 REVIEW REQUIRED` block with the sandbox URL alone on its own line (both the dominant non-TTY `stage_abort` path and the TTY prompt), and the `/builder-ship` skill instructs the agent to surface that URL as a standalone, clickable callout in chat — never buried in command output. The "agent relays the URL" hand-off in the Decision table is unchanged in mechanism; only its presentation is now first-class.

- **Recorded self-approval (supersedes "no DB schema, no new API surface").** The approval is now a durable fact. When the builder approves a staged game change — a TTY `y`, or an explicit `--approved` re-run on the non-TTY path — `ship.js` threads `{ stamp, url, method }` through the existing `POST /claims/:id/resolve` call (no new endpoint); the server stamps `by` + `at` authoritatively and persists the blob to a new `tasks.sandbox_review jsonb` column (migration 093). The original ADR argued *against* persisting the attestation because the server "cannot verify what a builder's box showed them." That reasoning still holds for *verification* — this record is an explicit, server-attributed **sign-off** ("builder X approved this exact game-surface stamp at time T"), which is a real and useful audit fact, not a claim that review happened. The scope is unchanged: **dev-box + named-tunnel + game-surface only, self-approval (no second approver), failure-open.**

- **The `--approved` flag records a sign-off; it never bypasses review.** It is honored only when the current game state is already staged-fresh (`decideShipGate → 'pass'`) — i.e. a re-run after a prior stage. A stale/absent marker still stages and pauses, so there is nothing to "pre-approve." A bare fresh-marker re-run *without* `--approved` still ships (back-compat / failure-open) but records nothing and prints a nudge.

- **Cost:** one nullable `jsonb` column + a field on an existing request body. Still no new endpoint; ~$0.

## Amendment — 2026-06-14, task [#1056](https://example.com/builders#/task/1056): the gate (and [#1048](https://example.com/builders#/task/1048)'s link + recorded approval) now also cover LOCAL clones

ADR 0044/0052 gave dev boxes a sandbox; the gate above and [#1048](https://example.com/builders#/task/1048)'s prominent link + recorded self-approval were written for that box path. Builders working on a full **local** clone (laptop) now get the identical loop — served privately at `http://localhost:<port>` (default 3100, `$OTB_PREVIEW_PORT` to override), **no Cloudflare tunnel, no public URL, $0** — via `scripts/gds/local-preview.js` (`npm run preview`) running the same ADR 0052 game-only entry (`src/preview-server.js`). Lars's directive (2026-06-14): "make the sandbox available for those also building locally" + "follow 1048 practice for the local sandbox as well."

- **One resolver, two contexts.** `resolvePreviewContext()` in `sandbox-stage.js` returns a uniform `{ kind, url, healthUrl, restart }` — **box** (keyed by `/etc/otb/box.env`) or **local** (keyed by the presence of `src/preview-server.js`). The whole gate flows through it unchanged: `decideShipGate`'s `onBox` became `gateActive` (box OR local), `stage()` (re)starts the resolved preview, and [#1048](https://example.com/builders#/task/1048)'s `🔍 REVIEW REQUIRED` block + the `{ stamp, url, method }` recorded approval carry the **local** URL; the marker carries `kind:'local'`.
- **Enforcement parity (supersedes "Laptop sessions … are completely unaffected").** A game-surface ship from a full local clone now stages + pauses for review exactly as on a box, and a TTY `y` / `--approved` re-run records the same durable self-approval. The `--skip-stage` escape hatch is unchanged. A **partial** clone with no game (`src/preview-server.js` absent) still has no sandbox and is unaffected, and **`/merge-mode` is still unaffected** (it lands `confirmed` tasks outside `shipMain`). This does mean the operator's own laptop game-surface ships are now gated too — consistent with "enforced like the box"; `--skip-stage` covers the exceptions.
- **Cost:** $0 — localhost, no tunnel, no new server surface (reuses [#1048](https://example.com/builders#/task/1048)'s `tasks.sandbox_review` + resolve field).
