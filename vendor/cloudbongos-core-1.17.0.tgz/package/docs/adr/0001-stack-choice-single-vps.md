# 0001 — Stack choice: single VPS + Node + Postgres + Colyseus + Caddy + Phaser

- **Status:** Accepted
- **Date:** 2026-05-08
- **Deciders:** Lars

## Context

Off the Boats V1 needs a persistent shared world for up to 100 concurrent players, browser-played, tile-based, with real-money purchases. The total budget for build + first year is $5,000. Monthly recurring cost must stay low and bootstrap-friendly.

We needed an architecture that:

1. Could host a real-time multiplayer game without a dedicated managed game-server SaaS
2. Could persist world state durably
3. Could be operated by one non-software-engineer with Claude as the pair-programmer
4. Would not lock us into per-MAU pricing or per-GB egress at high volume

## Decision

We will run the entire V1 stack on a **single VPS** with the following components:

- **Hosting:** DigitalOcean droplet, Ubuntu 24.04 LTS (see [0002](./<redacted>.md))
- **Reverse proxy / TLS:** Caddy (originally for Let's Encrypt; superseded by [0003](./<redacted>.md))
- **Runtime:** Node.js 22 LTS
- **Database:** PostgreSQL 16 (system package)
- **Game server:** Colyseus 0.16 — open-source authoritative-server framework over WebSockets
- **Web framework:** Express 4 — for static file serving + healthz; shares the Node process with Colyseus
- **Browser engine:** Phaser 3 — tile-based 2D game engine with broad community support

Everything runs on one droplet behind one Caddy instance. Same Node process serves Express HTTP and Colyseus WebSockets. Postgres is local on the same machine over a Unix socket.

## Alternatives considered

- **Managed game server (Photon, PlayFab, Hathora).** Per-CCU pricing scales linearly with success and is opaque at the budget level we need. Rejected on cost predictability.
- **Serverless (Lambda + DynamoDB + API Gateway WebSockets).** No native long-lived game-room concept; Lambda cold starts are hostile to a tile-tick game; DynamoDB pricing is hard to predict at the access patterns a world event log generates. Rejected on fit.
- **Multi-machine architecture (separate web, app, db tiers).** Pure overhead at 100-concurrent-user scale. Rejected as premature.
- **Unity/Unreal client.** Browser-first is a hard requirement of the brand experience ("hit the site, walk into the world"). Rejected.

## Consequences

- **Single point of failure** — the droplet is the entire production environment. Documented as a current-version limitation.
- **Vertical scaling only** — to grow beyond 100 concurrent or beyond a single world, the architecture changes meaningfully. By design — V2 is the place to address it if needed.
- **Cheap and predictable** — ~$14/mo for the droplet; everything else is OSS or already paid for (domain). Big runway against the $5K.
- **Operable by one person** — no Kubernetes, no service mesh, no CI/CD pipeline. `git push` + `~/deploy.sh` is the entire deploy story.
- **No staging environment** — production is the only environment. Acceptable while there are no users; revisit before launch.
