# ADR 0085 — Builders are uncapped by default (remove the default per-builder monthly spend cap)

- **Status:** Accepted
- **Date:** 2026-06-23
- **Track:** internal
- **Builds on:** [ADR 0016](<redacted>.md) (the Archon override stays server-enforced), [ADR 0054](<redacted>.md) (session token cost — the spend this cap measured)
- **Reverses:** the default-cap half of GDS-V3 criterion **C3** (V3.R84, task [#302](https://example.com/builders#/task/302) — "per-builder monthly budget, Archon-configurable")
- **Task:** [#1499](https://example.com/builders#/task/1499)

## Context

GDS-V3 criterion C3 (task 302) gave every builder a **month-to-date spend cap**: `cost_log` API/compute spend attributed to the builder since `date_trunc('month', now())`, compared against `builders.monthly_budget_usd`. When that column is `NULL` (the normal case), `classifyCostStatus()` fell back to a project-wide default of **$50/month**. At 100% the builder's `/me` `cost.level` flips to `'over'`, which **hard-blocks `/builder-ship` (before the grader runs) and the art pipeline**. An Archon could raise a specific builder's ceiling via `PATCH /builders/:id/budget`.

The default was framed in-code as "catch a runaway, not ration normal work." In practice it did the opposite. The dominant entry in a builder's `cost_log` is `session:<redacted> — **the API cost of running the assistant to do the work itself** (auto-captured per [ADR 0028](<redacted>.md)). On Opus, a handful of real sessions costs more than $50:

- Builder 95 (Jackson Rini), created 2026-06-22, hit `over` on day two: **$69.32 MTD across 5 interactive sessions** (largest single session $24.86) vs the $50 default. He was blocked from shipping anything — and every further session he ran to *try* to work pushed him deeper over, since the cost of working is itself the metered quantity.

So the default cap blocked the exact activity it was meant to enable, and would stall **every** productive new builder within a day or two — a structural newcomer trap, not a runaway guard. The owner's directive: *"Builders should have no budget limitations. Remove the default spend cap entirely."*

We considered fuller removal (delete the column, the override endpoint, and all blocking) but the owner chose to **keep a manual brake**: removing the *default* satisfies "no budget limitations" (no builder is capped unless someone deliberately caps them), while retaining the Archon override as a rarely-needed emergency stop on a genuine runaway — consistent with the project's $5K annual budget.

## Decision

**A builder with no explicit budget is uncapped.** `classifyCostStatus(spend, budget)` no longer falls back to a default:

- `budget` is `NULL` / non-finite / `<= 0` → **uncapped**: returns `level: 'ok'`, `budget_mtd_usd: null`, `pct_used: 0`. Nothing blocks. The `DEFAULT_MONTHLY_BUDGET_USD = 50` constant is **removed**.
- `budget` is a **positive number** (an explicit Archon override via `PATCH /builders/:id/budget`) → unchanged: `warn` at ≥80%, `over` at ≥100%, which still blocks ship + art. This is the manual brake.

Spend is **still recorded and surfaced** — the per-builder `cost_log` rows, the `/public/cost-summary` dashboard, and the `/me` `cost` object are all unchanged. This ADR removes *blocking*, not *observability*; the $5K pool is still fully visible.

No schema change (`monthly_budget_usd` stays; `NULL` now means "uncapped" instead of "use the $50 default"). The only behavioral surface is the pure `classifyCostStatus`; every consumer (ship.js, art `cost_ledger.py`, the CLI session ping, the hall banner) already keys off `level`/`budget_mtd_usd`, so they need no logic change — an uncapped builder simply never trips them.

## Consequences

- **Builders are unblocked by default.** No new builder stalls on their own session cost. Existing over-budget builders (e.g. Jackson Rini) are immediately unblocked with no operator action.
- **The brake survives.** An Archon can still cap a specific runaway builder by setting a positive `monthly_budget_usd`; clearing it (`null`) returns them to uncapped.
- **Cost stays honest.** Spend attribution, the savings ledger, and the public dashboard are untouched — we still see exactly where the $5K goes; we just don't gate work on it.
- **Project-wide guards are unaffected.** The separate autonomous-fleet spend brake (`autonomy-gate.js`, `OTB_AUTONOMY_CEILING_USD`) and the art-pipeline `HARD_STOP_USD` ledger cap are independent mechanisms and remain in force.
- **C3's intent narrows** from "every builder has a default ceiling" to "a ceiling is an opt-in, per-builder Archon tool." The onboarding drachmae/karma diagram note is updated to match.
