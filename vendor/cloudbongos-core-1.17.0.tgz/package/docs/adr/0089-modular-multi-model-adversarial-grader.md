# 0089 — Modular, multi-model adversarial grader (open-weight ensemble)

- **Status:** Accepted (direction decided with the owner 2026-06-26; build is task-pending — see Implementation)
- **Date:** 2026-06-26
- **Deciders:** Lars (Archon), Claude

**Builds on:** [ADR 0024](<redacted>.md) (the MAS grader — the worker-panel we extend), [ADR 0083](<redacted>.md) (modular architecture — graders register through the module seam), [ADR 0081](<redacted>.md) (one grader parameterized by work-type), [ADR 0088](<redacted>.md) (the first module-owned specialized grader — the `character_anim` family review), [ADR 0062](<redacted>.md) (neutral-contract adapter pattern — applied here to the *model provider*), [ADR 0016](<redacted>.md) / [ADR 0043](<redacted>.md) (server-enforced trust boundary the gate must not weaken), [ADR 0080](<redacted>.md) (an external model result that gates a ship is a content-injection surface).

**Track:** `internal` (a Cloud Bongos platform capability — the build pipeline's quality gate).

---

## Context

Every shipped task passes a **grader** before it lands: the MAS worker-panel ([ADR 0024](<redacted>.md)) for code (`src/bongos/grader.js` + `src/bongos/grader-workers/`), the Gemini vision review for pixel-art ([ADR 0008](<redacted>.md); `art/pipeline/family_review.py`), and now a module-specific review for animation ([ADR 0088](<redacted>.md)). The gate works and is the backbone of letting AI agents ship unattended. But four limits are now in the way:

1. **The grader is single-vendor.** Both the code panel and the vision review run on a model from the same lab that *built* the work (Claude grades Claude; Gemini grades Gemini-generated art). Today's only mitigation is *cross-family within Anthropic* — Opus author → Sonnet grader (`selectGraderModel`, `src/bongos/grader.js`). The research below shows that an author and a judge from the **same family share correlated blind spots** and the judge **inflates its own family's work by 10–25%**. An independent reviewer from a *different* lineage is the single highest-leverage quality lever we have.

2. **All grading spend rides the Claude bill.** Every worker in the panel is an Opus/Sonnet call. Grading is *additive* to the build spend (the builder already paid Claude to write the code; we pay Claude again to grade it). On a bootstrapped <$5K/yr budget that doubling is real, and it's the wrong place to spend — review is a verification task a cheaper independent model can do well.

3. **There is no clean way for a module to own its grader.** [ADR 0088](<redacted>.md) added an animation grader by *extending the art pipeline in place*; the DINOv2 identity scorer is wired as a Python-only `families.json` flag. Each new work-type bolts its grader on by hand. [ADR 0081](<redacted>.md) already called for "one grader parameterized by type," and [ADR 0083](<redacted>.md) gives us the mechanism (the module seam) — but nothing yet routes grading through it. The owner asked the right question directly: *should a work-type's grader live in that module, or in a general grader module?*

4. **The grader is hard-wired to two work-types (code, vision).** A third (`ui`, [ADR 0081](<redacted>.md)) and a fourth (animation, [ADR 0088](<redacted>.md)) are arriving. A new module (say, audio, or 3D) has no path to grading at all.

### What the research says (mid-2026)

A thorough literature + market sweep this session (sources at the foot of this ADR) produced findings that shape every decision below:

- **Self-preference is real and large.** GPT-4 inflates its own win rate ~10%, Claude-v1 ~25%; the effect is causally tied to a model *recognizing its own outputs* (Zheng 2023; Panickssery 2024). **Use a judge from a different family than the author** — the core argument for open-weight adversaries.
- **A small diverse jury beats one big judge, and is cheaper** (PoLL, Verga 2024: 3 small judges, >7× cheaper, higher human-correlation than a single GPT-4). **But** the 2026 counter-finding matters: *"Nine Judges, Two Effective Votes"* shows panels buy far less independence than their size implies (9 judges ≈ 2 effective votes; returns saturate by ~5), and **family-diversity alone does not guarantee uncorrelated errors** — you must *audit* error-correlation, and aggregation cannot rescue a correlated panel. So: **a small (2–3), deliberately heterogeneous panel, audited for low error-correlation — not a big one.**
- **Aggregating heterogeneous judges needs normalization.** Naively averaging judges on different scales lets a harsh or score-compressed judge silently dominate; **z-score or rank-normalize before combining**, and prefer median / reliability-weighting over naive mean (LLMs-as-Judges survey 2024).
- **Adversarial "find the flaw" framing beats holistic scoring.** Judges prompted to *refute* (and debate setups) surface flaws a rubber-stamp misses (Khan 2024). Our existing default-fail worker prompts already lean this way — we keep and extend it.
- **Binary pass/fail + a forced written critique beats 1–5 Likert.** Judges can't reliably tell a 3 from a 4; scores cluster at 6–7. Our panel already uses a 6.0 threshold + per-worker verdicts — consistent with best practice.
- **Open-weight models are now genuinely good critics.** For code: DeepSeek V3.2/V4 (MIT), Qwen3-Coder (Apache-2.0), GLM-4.6/5 (MIT) score 70–80%+ on SWE-bench Verified; purpose-built judges (Atla Selene, Prometheus 2) are trained specifically for rubric scoring. For vision: Qwen2.5-VL / Qwen3-VL and InternVL3.5 (Apache/MIT) have native-resolution encoders (the key feature for reading small sprites) and rival closed VLMs on MMMU/OCRBench. *Caveat:* several headline 2026 numbers are vendor-reported; treat them as provisional and pin/evaluate the exact checkpoint we adopt.
- **Hosting math is decisive.** A few-thousand-grades/month workload costs **~$1–5/mo** on a pay-per-call API (DeepInfra is consistently cheapest; e.g. Llama-class 70B ≈ $0.10/$0.32 per 1M tokens; DeepSeek/Qwen comparable, with near-free prompt-caching on the fixed rubric). Self-hosting a GPU is **~$200+/mo idle** and never breaks even at our volume. The grader prompt is mostly a *fixed rubric* sent every call — **cheap cached input crushes the bill.**
- **Off-the-shelf frameworks exist but don't fit.** `promptfoo` is the closest (MIT, Node-native, built-in panel voting, vision, points at any open endpoint) — but it was acquired by OpenAI in March 2026, and we already have a sophisticated worker-panel grader of exactly this shape. We **extend our own**, borrowing `promptfoo`'s patterns, rather than adopt a vendor-owned framework against an AGPL/non-profit posture ([ADR 0065](<redacted>.md)).

### Owner decisions (2026-06-26)

Three forks were put to the owner; all three are settled and are the spine of this ADR:

1. **Grader placement:** a **central grading engine** in core; **each module plugs in its own grader** (rubric + critic + evidence-gatherer) through the existing module seam. *Not* a full grader re-implemented per module.
2. **Open-model role:** **ensemble vote** — Claude + one or two open-weight models from different families grade independently and their verdicts combine. *Not* replace-Claude, *not* cascade.
3. **How to run it:** **hosted open-model API** (pay-per-call, e.g. DeepInfra or OpenRouter). *Not* self-hosted GPU, *not* free-tiers-only.

---

## Decision

**Refactor the grader into a central, work-type-parameterized engine that runs an adversarial ensemble of judges drawn from different model families — Claude plus hosted open-weight models — where each module contributes the rubric, critic, and evidence-gatherer for its own work-type through the module seam. Verdicts from heterogeneous judges are normalized and aggregated with a median-plus-hard-veto policy; the panel is kept small and audited for error-independence; deterministic pre-passes remain the authoritative, zero-LLM security gate.**

### 1. A central grading engine; module-contributed graders (placement — owner decision 1)

The **engine lives in core** (`src/bongos/grader.js`, generalized). It owns the invariant loop, which is identical for every work-type:

```
select work-type grader  →  gather evidence  →  run deterministic pre-passes (zero-LLM, authoritative)
   →  run the judge ensemble (each judge scores independently, adversarial posture)
   →  normalize + aggregate verdicts  →  apply the gate (median + hard-veto)
   →  persist grade + per-judge signals + cost  →  promote / fall-through
```

A **module contributes only the three things that are specific to its work-type**, registered through the seam (`api.seams.registerProvider`, [ADR 0083](<redacted>.md)):

- a **rubric** — the named criteria + thresholds for this work-type (the data the art pipeline keeps in `rubric.json`, the code panel in `grader-rubric.json`);
- an **evidence-gatherer** — what the judges see (a git diff for code; a rendered screenshot for `ui`; a sliced frame-set + model sheet for animation);
- optional **specialized critics** — deterministic checks (palette-snap, transition-coherence, DINOv2 identity) or a custom LLM worker, when the generic rubric judge isn't enough.

So the answer to the owner's question — *"under each module, or in a general grader module?"* — is **both, split by concern**: the **orchestration, ensemble, aggregation, gate, persistence, and security pre-passes are central** (write once, consistent everywhere); the **rubric + evidence + specialist critics are module-owned** (the part that genuinely differs). Enable the animation module → its `character_anim` grader is automatically available; disable it → the engine simply has one fewer registered work-type. This is exactly the seam [ADR 0088](<redacted>.md)'s grader and the DINOv2 scorer already want; we are formalizing it as `grader.workType.<key>` providers rather than hand-wiring.

A **grader registry** in core resolves `task.kind` / `discipline` → the registered work-type grader (falling back to the code grader), mirroring the dispatch the art pipeline already does on family `kind`. There is no separate "general grader module" — the generic machinery *is* the core engine; modules register against it.

### 2. An adversarial multi-model ensemble (owner decision 2)

A grade runs a **small panel of independent judges from different model families**, each given the **same rubric and evidence** and an **adversarial "find what's wrong; default to fail if unsure" posture** (extending today's default-fail worker prompts). The panel composition is **config-driven per work-type**, with a default of:

- **Claude** (the incumbent quality bar — kept, never the sole judge).
- **One or two open-weight models from a *different lineage*** — e.g. for code, a DeepSeek (MIT) or Qwen3-Coder (Apache) judge; for vision, a Qwen-VL / InternVL judge independent of Gemini.

Crucially (per the *"Nine Judges"* finding): **the panel is small (2–3 judges) and its members are chosen and *audited* to fail differently** — not maximally large, and not "different vendor" assumed-independent. We add an **error-correlation audit** (§5) so the panel composition is evidence-based, not faith-based.

This generalizes the existing worker panel two ways: the four *lenses* (narc / quality / hacker / efficiency) become *rubric criteria* a judge scores, and the *judges* become a cross-family set. A judge may still be lens-specialized where it pays (e.g. keep a dedicated security worker), but the default is "N cross-family judges over one rubric."

### 3. The model provider is an adapter; run open models via a hosted API (owner decision 3)

Following the [ADR 0062](<redacted>.md)/[ADR 0081](<redacted>.md) neutral-contract pattern, **how a judge's model is called is an adapter behind a `ModelProvider` port**, not hard-coded. `selectGraderModel()` (today a Claude-only `if/else` in `src/bongos/grader.js`) is replaced by a small provider registry:

- **`anthropic`** — the existing Claude path (Anthropic API).
- **`openai-compatible`** — a single adapter that speaks the OpenAI chat-completions shape, which covers **DeepInfra, OpenRouter, Together, Fireworks, Groq, vLLM, and Ollama** by base-URL + key alone. This is the open-weight path.

Default open-model transport: a **hosted pay-per-call API (DeepInfra or OpenRouter)** — no box to run, ~$1–5/mo at our volume (§Cost). The same adapter could point at a self-hosted endpoint later without code change, but self-hosting is explicitly *not* adopted now. **Model choice, provider, base-URL, and panel composition are instance config** (the [ADR 0062](<redacted>.md) host-owned pattern), so any Cloud Bongos instance picks its own judges; this also pre-positions for GDS-V4's per-builder model preferences ([idea #30](https://example.com/builders#/idea/30)).

The open-model key is a new secret (BYOK, like the Gemini art key — [ADR 0073](<redacted>.md)). **Requires the owner's spend go-ahead** before any live call (CLAUDE.md §4).

### 4. Aggregating heterogeneous judges: normalize, then median-plus-hard-veto

Judges on different scales cannot be naively averaged (a harsh or score-compressed judge would silently dominate). The engine:

1. **Normalizes** each judge's per-criterion scores before combining — **z-score or rank-normalize** against that judge's own observed distribution (research finding F42–F44).
2. **Aggregates** with **median** of normalized scores (robust to one outlier judge) for the soft score, and a **hard veto** for safety-critical findings: *any* judge raising a critical/blocker finding fails the gate — preserving today's any-fail-vetoes behavior for the things that must never slip (security, completion). This keeps the gate *strict* (a single credible "this is broken" stops a ship) while making the *soft* score robust.
3. **Position/order mitigations** are applied where a judge compares options (randomize criterion order; for any pairwise step, run both orders and average).

The exact policy (veto thresholds, weights, whether to reliability-weight a judge down after it proves unreliable) is **config in the rubric**, so it tunes per work-type without code change.

### 5. Error-correlation auditing (the panel must fail *differently*)

Because aggregation cannot manufacture independence the panel doesn't have, we **measure it**. A periodic offline job (a new scheduled routine) replays a labeled set of past grades through each candidate judge and computes **pairwise error-correlation + per-judge Cohen's κ against the human/owner ground truth** (the confirm/reject decisions already in `grade_attempts` + owner overrides). Output: which judges add real independent signal, which are redundant, which are miscalibrated. **Panel composition is chosen from this evidence**, not assumed. This is the structural answer to *"Nine Judges, Two Effective Votes."*

### 6. Deterministic pre-passes stay authoritative and zero-LLM (security)

The two deterministic server-side guards — route-rank ([ADR 0016](<redacted>.md)) and permission-path ([ADR 0043](<redacted>.md)) — **remain exactly as they are**: zero-LLM, server-re-run on authoritative data, downgrade-only. **No LLM verdict — Claude or open — can ever upgrade a deterministic fail to pass.** The ensemble grades *quality*; the deterministic gate enforces the *trust boundary*. An external model's verdict that gates a ship is a content-injection surface ([ADR 0080](<redacted>.md)): so open-model verdicts are (a) advisory-plus-veto only, never sole authority over a protected path; (b) logged with model id + provider + raw response in `signals` for audit; (c) subject to the same server-side re-verification envelope as the Claude panel. For pixel-exact properties (palette, grid, dimensions) the **deterministic checks remain the authority** — VLMs are documented to misread fine detail; the vision judge is for aesthetic/semantic critique only ([ADR 0088](<redacted>.md) already draws this line).

### 7. Reuse, don't rebuild

The worker-contract (`buildPrompt` / `extractJson` / `computeVerdict`), the `runWorker` parallel runner, the `task_grades` + `grade_attempts` schema, the trivial-diff fast-path, and the server-side guard envelope are **kept**. This ADR generalizes their *inputs* (which model, which rubric, which evidence) — it does not throw them away. The content-addressed LLM cache ([ADR 0077](<redacted>.md)) applies unchanged and now memoizes open-model calls too.

---

## Consequences

**Positive**

- **Genuinely independent review.** A different-lineage judge removes the self-preference inflation (10–25%) that same-family grading can't — the owner's primary goal.
- **Cheaper, better-placed spend.** Open judges at ~pennies/grade move verification off the Claude bill; caching the fixed rubric makes it nearly free. Net grading cost likely *drops* while robustness *rises*.
- **A clean module story.** New work-types (audio, 3D, copy) register a rubric + evidence + critic and get the full ensemble gate for free. Animation/UI/DINOv2 stop being hand-wired special cases.
- **Vendor-independent and portable.** The `ModelProvider` + per-instance config means no lock-in; any instance picks its own judges; aligns with the AGPL/non-profit posture.
- **Evidence-based panel.** The error-correlation audit keeps the jury honest instead of assuming diversity.

**Negative / risks**

- **More moving parts.** A model registry, an aggregation layer, and a new provider are net new surface. Mitigated by reusing the existing panel machinery and shipping behind a flag.
- **Open-model reliability + drift.** Hosted endpoints can rate-limit, deprecate a model, or change behavior; vendor benchmark numbers are provisional. Mitigated by: Claude always in the panel (a hard floor on quality), the error-correlation audit catching a judge that degrades, and graceful-degrade (an unreachable open judge drops to a logged note, never a false pass).
- **A new external trust surface.** An open-model verdict influences shipping. Bounded by §6 (advisory+veto, never sole authority over protected paths; deterministic gate unchanged; full logging).
- **Calibration work.** Heterogeneous normalization + thresholds need tuning against the labeled set before the open judges get vote weight. Mitigated by rolling out **advisory-only first** (open judges grade and log, but don't yet gate), then promoting to voting once the audit shows they agree with the owner.

---

## Alternatives considered

- **Replace Claude with open models entirely** (cheapest). Rejected by the owner — loses Claude's review quality and leans wholly on provisional open-model numbers. Claude stays as the quality floor.
- **Cascade (cheap open model first, Claude only on disagreement).** Rejected by the owner for the default — more moving parts and harder-to-predict behavior than a flat small ensemble. (It remains a possible *future* cost optimization behind the same provider abstraction.)
- **Self-host the open models on a GPU box.** Rejected — ~$200+/mo idle, never breaks even at our volume; competes with the game server. The adapter leaves the door open if privacy ever demands it.
- **Adopt `promptfoo` (or another framework) wholesale.** Rejected — we already have a worker-panel grader of this exact shape; `promptfoo` is now OpenAI-owned, against our governance posture. We borrow its patterns (panel voting, open-endpoint judges) and extend our own.
- **A separate top-level "grader module."** Rejected — it would either re-implement the core loop (duplication) or *be* the core loop (then it's just core). The split in §1 (central engine + module-contributed rubric/evidence/critic) is cleaner and matches [ADR 0083](<redacted>.md).
- **A big jury (5–9 judges) for maximum robustness.** Rejected on the *"Nine Judges"* evidence — returns saturate by ~5 and correlated errors gut large panels; a small audited panel is both cheaper and more honest.

---

## Cost analysis

Grading volume is roughly one panel per shipped task. At a few thousand grades/month, with each grade ~3K input (mostly the fixed, cacheable rubric) + ~1K output per open judge:

- **DeepInfra**, Llama/Qwen/DeepSeek-class judge: ≈ $0.0006/call → **~$1–3/mo** for the open-judge leg, with prompt-caching driving input cost toward zero.
- **Claude leg** is the existing spend (unchanged, or *reduced* if some lenses move to the cheaper open judge).
- **Self-host** would be **~$200+/mo** — rejected.

Net: the new capability is **additive single-digit dollars/month**, well inside the budget, and likely net-neutral-to-negative on total grading spend once open judges absorb load Claude carries today. One new secret (open-model API key); owner spend approval required before the first live call.

---

## Implementation (task-pending)

A build cluster under GDS-V4 (or its successor), staged so nothing destabilizes the live gate:

1. **`ModelProvider` port + `openai-compatible` adapter** — generalize `selectGraderModel`; add provider registry + per-instance config; BYOK open-model key. (No behavior change; Claude still the only judge.)
2. **Heterogeneous aggregation layer** — z-score/rank normalization + median + hard-veto, config-driven in the rubric. (Still Claude-only; proves the math.)
3. **Grader registry + work-type seam** — `grader.workType.<key>` providers; route `task.kind` → rubric + evidence-gatherer + critics; migrate the code panel, the art/vision review ([ADR 0008](<redacted>.md)/[ADR 0088](<redacted>.md)), and the `ui` path ([ADR 0081](<redacted>.md)) onto it.
4. **Add the first open judge — advisory only** — it grades and logs to `signals`, but does not gate. Pick the checkpoint by live evaluation, not vendor numbers.
5. **Error-correlation audit routine** — replay labeled grades; report κ + pairwise error-correlation; choose panel composition.
6. **Promote open judges to voting** — once the audit shows agreement with owner decisions; tune veto thresholds.
7. **Vision ensemble** — add an open VLM (Qwen-VL / InternVL) as an independent second opinion to Gemini for art/animation, deterministic checks still authoritative.

Roll out behind a flag (the [ADR 0079](<redacted>.md) "build disabled, arm later" pattern); the deterministic security gate is never flagged off.

---

## Sources

Open-weight code models & licenses: DeepSeek V3.2/V4 (MIT, ~70–80% SWE-bench), Qwen3-Coder-Next (Apache-2.0), GLM-4.6/5 (MIT), Devstral Small 2 (Apache-2.0), purpose-built judges Atla Selene 1 / Prometheus 2 — HF model cards, mistral.ai, swebench.com, livecodebench.github.io. Hosting/pricing: deepinfra.com/pricing, openrouter.ai/pricing, together.ai/pricing, api-docs.deepseek.com (cached-input ~98% off); self-host break-even via runpod.io/pricing. LLM-as-judge: Zheng 2023 (arXiv 2306.05685), Wang 2023 position bias (2305.17926), Panickssery 2024 self-recognition (2404.13076), G-Eval (2303.16634), PoLL/Verga 2024 (2404.18796), *Nine Judges, Two Effective Votes* 2026 (2605.29800), LLMs-as-Judges survey (2412.05579), Khan 2024 debate (2402.06782), Hamel Husain (hamel.dev/blog/posts/llm-judge). Open VLMs: Qwen2.5-VL/Qwen3-VL (Apache), InternVL3.5 (Apache/MIT, ~77.7% MMMU), Pixtral (Apache) — native-resolution encoders the key feature for small sprites; VLM-judges rank better than they score (Multimodal RewardBench ~70–76% ceiling). Frameworks: promptfoo (MIT, OpenAI-acquired 03/2026), Opik (Apache), Inspect AI (MIT) — none fit better than extending our own panel.
