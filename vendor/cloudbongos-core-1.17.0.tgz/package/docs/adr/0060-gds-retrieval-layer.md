# ADR 0060 — GDS retrieval layer: Postgres-resident, lexical-first, rank-scoped, fail-open

- **Status:** Accepted
- **Date:** 2026-06-16
- **Track:** internal
- **Builds on:** [ADR 0016](<redacted>.md) (server-enforced permissions — the read posture this index must never bypass), [ADR 0043](<redacted>.md) (sub-Metic stay out of the permission/methodology core), [ADR 0024](<redacted>.md) (the memory/learning corpus this indexes), [ADR 0010](0010-pms-architecture.md) (the GDS Postgres this lives in)
- **Task:** 940 (V4.R02) — locks the architecture for the GDS-V4 "one-call recall" criterion. Implemented by V4.R06 (migration, [#944](https://example.com/builders#/task/944)), V4.R07 (chunker, [#945](https://example.com/builders#/task/945)), V4.R09/R10 (ingesters, [#947](https://example.com/builders#/task/947)/[#948](https://example.com/builders#/task/948)), V4.R11 (search route, [#949](https://example.com/builders#/task/949)), V4.R12 (scoping + isolation suite, [#950](https://example.com/builders#/task/950)); the embedding layer is gated behind the V4.R24 eval ([#962](https://example.com/builders#/task/962)).

## Context

A builder starting a session re-discovers the same project knowledge by hand every time: which ADR covers X, which session log hit this footgun, which task already shipped this. The 2026-06-12 friction analysis of the BFG session corpus put "rediscovery / wrong-path" at the top of the time sinks. The GDS-V4 headline is **one-call recall**: any session, from any machine, can ask "what do we know about X?" and get the relevant docs + DB prose back in one call — *without* the recall layer ever becoming a side-channel that leaks content a builder isn't allowed to read.

Two hard constraints frame every choice below:

1. **Budget + ops (CLAUDE.md §4).** $5k/year, one ~$14/mo droplet, one Node process, one Postgres. A retrieval stack that adds a managed vector DB, a separate search service, or a GPU box is off the table unless lexical-in-Postgres demonstrably can't do the job.
2. **The trust boundary ([ADR 0016](<redacted>.md) / [ADR 0043](<redacted>.md)).** Some indexed content is rank-gated (permission-core docs are Metic+; a builder's own memory is theirs alone). A search index is a classic read-side bypass: if it returns a snippet of a doc the caller can't otherwise read, the index just defeated the boundary. Scoping is therefore a **first-class, server-enforced** property of the index, not a filter bolted on later.

The 2026-06-12 research report ("GDS retrieval architecture") surveyed the options and recommended **lexical-first, in Postgres**: Postgres ships full-text search (`tsvector`/`tsquery`) and trigram fuzzy match (`pg_trgm`) in the box we already run; the corpus (a few thousand markdown chunks + DB prose rows) is tiny by search standards; and embeddings buy little until a *measured* lexical gap justifies their cost and operational weight. This ADR locks that in.

## Decision

### 1. Substrate — one table in the existing Postgres, no new service

All searchable content is chunked into one table, `search_chunks`, in the GDS Postgres. No new process, no managed service, no network hop. Full-text and fuzzy match run as SQL against this table.

### 2. Schema (`search_chunks`, migration 103 / [#944](https://example.com/builders#/task/944))

```
search_chunks
  id            bigserial primary key
  source_kind   text     not null         -- 'doc' | 'db'  (markdown file vs DB-prose row)
  source_ref    text     not null         -- e.g. 'docs/adr/0016-....md' or 'task:431' / 'learning:53'
  chunk_index   int      not null          -- ordinal within the source (0-based)
  heading_path  text                       -- breadcrumb: 'CLAUDE.md > §8 Versioning > Working rules'
  title         text                       -- the source's human title (for result display)
  body          text     not null          -- the chunk text (what gets shown as a snippet)
  min_rank      text     not null default 'xenos'  -- LOWEST rank that may see this chunk (scoping, §6)
  owner_builder_id bigint references builders(id)  -- non-null ⟺ a per-builder private chunk (e.g. memory); else NULL = shared
  content_hash  text     not null          -- sha256 of body; ingestion delta key (skip unchanged)
  tsv           tsvector                    -- generated/maintained FTS vector over title+heading_path+body
  created_at    timestamptz not null default now()
  updated_at    timestamptz not null default now()
  unique (source_kind, source_ref, chunk_index)
```

Indexes: a **GIN** index on `tsv` (FTS) and a **GIN `gin_trgm_ops`** index on `body` (trigram fuzzy). `pg_trgm` is enabled via `CREATE EXTENSION IF NOT EXISTS pg_trgm` in the same migration (ships with standard Postgres contrib; no new package). A btree on `(source_kind, source_ref)` supports idempotent re-ingest + delete-by-source.

### 3. Chunking — heading-aware with breadcrumbs (V4.R07 / [#945](https://example.com/builders#/task/945))

Markdown is split on heading boundaries (not fixed byte windows), so a chunk is a coherent section. Each chunk carries a `heading_path` breadcrumb (`File > H1 > H2 > H3`) so a result is self-locating and the snippet has context. Front-matter is parsed (not indexed as body). Over-long sections are sub-split on paragraph boundaries with the breadcrumb preserved. The chunker is a **pure module** (`src/bongos/search-chunker.js`) so both ingesters and the test suite drive it without I/O.

### 4. Ingestion — deploy hook (repo) + nightly timer (DB prose)

- **Repo markdown** (V4.R09 / [#947](https://example.com/builders#/task/947)): a deploy-hook step (`scripts/gds/search-ingest-md.js`) walks the repo's docs/markdown, chunks each file, and upserts. Delta by `content_hash` — unchanged chunks are skipped; vanished sources are deleted. Runs on every deploy so the index tracks `main`.
- **DB prose** (V4.R10 / [#948](https://example.com/builders#/task/948)): a nightly timer (`scripts/gds/search-ingest-db.js`) ingests prose-bearing DB rows — task descriptions/value summaries, learnings, session-log summaries, recent shipped-task summaries — with a recency boost. Nightly is fresh enough for DB prose; the deploy hook keeps docs current intra-day.

Each ingested chunk is stamped with the `min_rank` of its source (§6).

### 5. Query — lexical hybrid fused with RRF (V4.R11 / [#949](https://example.com/builders#/task/949))

`POST /api/gds/search { q, limit? }` runs **two** retrievers and fuses them:

1. **FTS leg** — `websearch_to_tsquery` against `tsv`, ranked by `ts_rank_cd`.
2. **Trigram leg** — `body % q` / `similarity(body, q)` via `pg_trgm`, which catches typos, partial tokens, and identifier fragments FTS stems away.

Results are fused with **Reciprocal Rank Fusion** (RRF: `score = Σ 1/(k + rank_i)`, k=60) — rank-based, so the two legs' incomparable score scales don't need normalizing, and a chunk ranked well by *either* leg surfaces. RRF is computed in SQL (a CTE per leg + a fused aggregate) so there's one round-trip. The response returns `{ source_kind, source_ref, heading_path, title, snippet, score }[]`.

### 6. Scoping — per-chunk `min_rank` + owner, server-enforced (V4.R12 / [#950](https://example.com/builders#/task/950))

This is the load-bearing security property, mirroring [`src/bongos/routes/memory.js`](../../src/bongos/routes/memory.js)'s posture:

- Every query is filtered **in the SQL WHERE clause** (not post-hoc in JS) by the caller's **live, server-resolved rank** (`req.builder.rank`, read fresh per request — never from input): `min_rank` must be ≤ the caller's rank in the ladder.
- A chunk with a non-null `owner_builder_id` (a per-builder private chunk, e.g. memory) is returned **only** to that owner — `owner_builder_id IS NULL OR owner_builder_id = req.builder.id`. There is no parameter to name another builder; the owner is always the authenticated session.
- Permission-core docs (the [ADR 0043](<redacted>.md) protected set: trust-boundary docs, rank/authz, the ship/grade/deploy pipeline) are ingested at `min_rank='metic'` so a Xenos/Thetes search can never return a snippet of them.
- **No public/unauthenticated surface.** `POST /api/gds/search` is `requireBuilder`. The public read API ([`src/bongos/routes/public.js`](../../src/bongos/routes/public.js)) gains nothing here.
- A dedicated isolation suite (`tests/search_isolation.mjs`, in the style of `tests/memory_isolation.mjs`) proves: a sub-Metic query never returns a `min_rank='metic'` chunk; a builder never returns another builder's owned chunk; the filter is in SQL, not a JS post-filter that a future refactor could drop.

### 7. Fail-open to lexical-only

The (future, V4.R24-gated) embedding/semantic leg is **additive and fail-open**: if embeddings are absent, disabled, or error, search degrades to the lexical legs above — it never hard-fails a query. Lexical-first means the system is fully useful with zero embedding infrastructure; embeddings are a later, measured upgrade, not a dependency.

## Consequences

- **Zero new infra / monthly cost.** Search is SQL against the existing Postgres. No vector DB, no search service, no GPU.
- **The index can never be a read-side bypass.** Scoping is enforced server-side in SQL against the live rank + authenticated owner, identical in spirit to the memory router. The isolation suite is the regression guard.
- **Lexical is the floor, embeddings are the option.** We ship a useful recall layer now; the embedding go/no-go is a *measured* decision (V4.R24 [#962](https://example.com/builders#/task/962)) against a golden eval set (V4.R01 [#939](https://example.com/builders#/task/939)), and even if adopted it fails open to this.
- **Freshness is bounded + visible.** Docs track `main` on deploy; DB prose is nightly. Staleness monitoring + a `/watch` tile (V4.R36 [#972](https://example.com/builders#/task/972)) surface a stalled ingest rather than letting it rot silently.
- **`search_chunks` fattens the nightly `pg_dump`.** Reviewed under V4.R37 ([#973](https://example.com/builders#/task/973)); chunks are derivable from `main` + DB, so the backup could exclude them if size warrants.

## Alternatives considered (rejected)

- **ParadeDB / `pg_search` (BM25 in Postgres).** A real BM25 index would beat `ts_rank`, but it's a non-core extension that must be compiled/installed on the droplet — operational weight and a deploy-time dependency for a corpus small enough that `ts_rank_cd` + trigram + RRF is plenty. Rejected on ops cost vs marginal quality. Revisit only if the golden-set eval shows lexical ranking is the bottleneck.
- **Standalone vector DB (Qdrant / Weaviate / Pinecone).** A separate always-on service (or per-query SaaS spend) for a few-thousand-chunk corpus — squarely against the budget posture, and it splits the source of truth out of Postgres. Rejected.
- **Embeddings now (pgvector from day one).** Embeddings cost API spend per ingest + per query and add a provider dependency, for unproven recall gain on a small, jargon-dense corpus where exact-term + trigram match is strong. Deferred behind a measured gate (V4.R24), and even then layered on (fail-open), not depended on.
- **Local embedding model on the droplet.** A ~$14/mo shared CPU droplet has no headroom to host an embedding model without degrading the game server. Rejected; if embeddings are adopted they go through a serverless provider (the V4.R30 [#966](https://example.com/builders#/task/966) decision), consistent with the LLM-agnostic research ([#1069](https://example.com/builders#/task/1069)) "serverless, not local" finding.
- **Cross-encoder reranker.** A reranker over the fused top-k would lift precision but adds a model call per query (latency + spend) for a marginal gain at this corpus size. Out of scope; RRF over two lexical legs is the v1 ranker.
- **Filter scoping in application code (post-query).** Fetch top-k, then drop chunks the caller can't see in JS. Rejected outright: it's the exact read-side-bypass failure mode — a post-filter is one refactor away from leaking, and it can under-fill the result page. Scoping lives in the SQL WHERE clause so an unauthorized chunk is never selected in the first place.
