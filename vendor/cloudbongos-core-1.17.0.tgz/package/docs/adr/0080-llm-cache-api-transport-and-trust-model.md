# ADR 0080 — LLM-cache API transport + trust model

**Status:** Accepted (2026-06-21) · task [#1381](https://example.com/builders#/task/1381) · transport for the content-addressed cache of [ADR 0077](<redacted>.md); savings ledger contract per [ADR 0075](<redacted>.md) / `migrations/124_cost_baseline.sql`; reuses the rank trust boundary of [ADR 0016](<redacted>.md)

## Context

System 5 ([ADR 0077](<redacted>.md)) memoizes idempotent model runs in the `llm_cache` Postgres table via `src/bongos/llm-cache.js` (`lookup`/`store`/`recordSaving`), all of which use a **direct `pg` pool**. But its two consumers — `architect-audit.js` and `onboarding-analyze.js` — run as CLI/cron on **builder machines**, where the pool is unreachable (peer-socket only; TCP is scram-only). So every cache op silently degraded to miss/no-store and the cache **could never hit organically** (verified empirically in the System-5 effectiveness eval, task [#1372](https://example.com/builders#/task/1372): 0 rows, 0 hits, despite correct logic — proven only when the DB was reached via a forwarded socket).

The fix is a transport: reach the cache DB from any consumer machine. The hard part is **trust** — a cache *store* writes a `result_stdout` that a later run **replays at $0 and trusts** (for `architect-audit` it becomes `audit_md` written to `docs/audits/` and `seed_ideas` filed to `idea_inbox`). An open store endpoint is a content-injection vector into the planning pipeline and a metrics-integrity vector into the public savings number.

## Decision

**Expose the cache over the GDS API; keep the in-process pool as the server fast path; inject the API transport into the consumers — never statically couple the core to the CLI layer.**

- **`src/bongos/routes/llm-cache.js`** exposes `POST /api/gds/llm-cache/lookup` and `POST /api/gds/llm-cache/store`, each mapping 1:1 onto the existing `llm-cache.js` DB helper (the route never reimplements SQL). `/store` mounts its own 512 KB `express.json` (a full subagent stdout exceeds the global 64 KB cap; `routes.js` skips the global parser for that path).
- **`llm-cache.js` self-routes.** `lookup`/`store` try the pool first (`poolReachable()` — a memoized `SELECT 1`; `true` is sticky, `false` is **never** memoized so a transient boot blip can't permanently disable the server cache), then fall back to an **injected** `apiCall` (`setApiFallback(fn)`). The consumers — which already import `cli-lib` — inject `apiCall`; the core never statically requires the CLI layer (that would drag session/fetch plumbing into the always-on server and cross the core↔host boundary the fitness gate guards). Best-effort is preserved end-to-end: any pool/network/auth error degrades to miss/no-store and **never throws** (the fallback passes `allowUnauthenticated:true` so an expired session can't `process.exit` the audit it rides on).

### Trust model (the load-bearing part)

| Control | What it stops |
|---|---|
| **Metic+ gate** on both routes (`requireRank('metic','archon')`, read live per-request — [ADR 0016](<redacted>.md)) | Xenos/Thetes seeding a result a high-value audit later replays. There is no legitimate sub-Metic consumer. |
| **`cache_key` must be `/^[0-9a-f]{64}$/`** | malformed / SQL-shaped keys; a key is a sha256 by construction. |
| **`task_type` ∈ the registered `NORMALIZERS`** | caching arbitrary (non-idempotent) producers; bounds stores to the known idempotent ones. |
| **`owner_builder_id` pinned to `req.builder.id`** (client value ignored) | a caller falsifying write-attribution. (The cache is **shared-on-read by content address** — `lookup` keys on `cache_key` only, not on owner. Isolation comes from the key itself: an entry is only readable by someone who can reconstruct its exact `prompt+model+task_type+scope_sha`, and only at Metic+ — not from an owner filter.) |
| **`scope_sha` in the key** (pre-existing) | blast radius: a poisoned entry is only ever replayed for the exact `(prompt, model, task_type, git-tree)` it was stored under — a changed tree misses. |
| **No `/record-saving` route — `recordSaving` stays pool-only** | the migration-124 contract: the saving lands in the **public** `cost_baseline` → `/public/cost-summary`, so it must be a server-side-priced figure, never a client dollar amount. |
| audit middleware + rate limiter (automatic) | a forensic record of every store; poisoning velocity capped at 30 writes/min/IP. |

### The savings-booking gap (deliberate, interim)

`result_cost_usd` on `/store` is **clamped** (`[0, OTB_LLM_CACHE_MAX_COST_USD]`, default $10) and stored **only as informational metadata** on the internal `llm_cache` row — it is **never booked to the public ledger**. Because there is no API path for `recordSaving`, an off-server hit **records the hit** (`hit_count` bumped in `lookup`) but **does not book a dollar saving**. This honors the migration-124 contract ("`baseline_usd` is ALWAYS computed server-side from token counts via `priceUsage()` — NEVER a client-supplied dollar figure") by booking *nothing* rather than an unverified client figure.

**Follow-up (filed):** have the consumers forward the subagent envelope's token `usage` so `/store` can re-price the saving server-side via `priceUsage`, then book *that* into `cost_baseline`. Until then, System 5's realized savings show as **hit counts, not dollars** — which is the honest state.

## Consequences

- The cache becomes functional from any builder machine: an unchanged-input re-run replays at $0 with `hit_count++`, from the laptop/box where the audit actually runs.
- The public savings number stays at $0 for off-server hits until the re-pricing follow-up lands — by design, so the first real numbers are trustworthy.
- A poisoned store is bounded to Metic+ actors, one immutable tree-snapshot of one scope, audit-logged, and rate-limited. The grader being bypassed (`GRADER_BYPASS_ENABLED=1`) is irrelevant here — the cache rides `runSubagent`, the spawn primitive, not the grading panel.
- Organic hit rate is expected to be **low** (an audit must re-run over an unchanged tree before a relevant commit lands), so this is a correctness/enablement fix, not a large dollar lever — consistent with the System-5 eval's "low end of 2–5% latent."

## Reproduce / verify

- Pure tests (DB-free): `tests/llm-cache.mjs` (transport fallback: pool-unreachable → injected apiCall; `recordSaving` never calls the API), `tests/llm-cache-route.mjs` (hex-key + task_type validation, cost clamp, owner pinning, never-500).
- `node tests/fitness.mjs` → "no route bypasses server-side rank checks (ADR 0016)" passes with the new route's inline `requireRank`.
