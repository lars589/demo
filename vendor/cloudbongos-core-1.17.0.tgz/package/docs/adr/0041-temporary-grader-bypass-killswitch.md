# ADR 0041 — Temporary global grader-bypass kill-switch (`GRADER_BYPASS_ENABLED`)

- **Status:** Accepted. Implemented in [#853](https://example.com/builders#/task/853).
- **Date:** 2026-06-07
- **Track:** `internal` (dev-system / shipping pipeline)
- **Builds on:** [ADR 0016](<redacted>.md) (server-enforced permissions / trust boundary), [ADR 0024](<redacted>.md) (the grader)

## Context

The subagent quality grader gates the `completed → confirmed` transition: a task only earns credits and advances toward `shipped` when a passing grade is recorded (`db.applyGrade`). The only existing bypass is the per-ship `--skip-grade` flag, which reroutes to `POST /tasks/:id/confirm` — and that endpoint is **Archon-only** ([#231](https://example.com/builders#/task/231)) precisely so a builder can't push their own work past a failed grade.

That gate becomes a problem during a **grader outage**. When the LLM grader can't run at all (e.g. a provider-wide 429 — as happened repeatedly through early June, resetting Jun 8 3pm ET), *no* non-Archon builder can land work: they can't get a passing grade, and they can't self-confirm. Builders (e.g. builder 25 with outstanding completed tasks) are stuck until either the outage clears or an Archon manually confirms each task one by one.

Lars asked to **temporarily allow everyone to ship without running the grader agents**.

## Decision

Add a **server-side, default-OFF environment kill-switch**: `GRADER_BYPASS_ENABLED`. When — and only when — it is exactly `'1'`:

1. **`POST /api/gds/tasks/:id/confirm`** relaxes from Archon-only to **any authenticated builder**. The endpoint logs every bypass confirm (`[gds] grader-bypass confirm: builder N …`) so the audit trail records it. `confirmTask` still credits the **claim holder**, not the confirmer ([#661](https://example.com/builders#/task/661)), so this is not a credit-self-dealing vector.
2. **`GET /api/gds/me`** surfaces `grader_bypass: true`.
3. **`scripts/gds/ship.js`** reads that flag and, for *every* builder, auto-takes the existing `--skip-grade` confirm path (no subagent grader spawned) with a printed notice.

The flag is read **live on each request** — there is no caching. Flipping the env and redeploying is the entire on/off control; turning it off immediately re-arms the Archon-only gate and the normal grader flow.

### Why this honors the trust boundary ([ADR 0016](<redacted>.md))

The relaxation is **server-side and default-OFF**. A builder editing local files (CLAUDE.md, ship.js, skills) cannot turn it on — only an operator with droplet env + deploy access can. When the env is unset, the system behaves exactly as before. The bypass is a deliberate, operator-controlled, logged, *temporary* widening — not a standing grant.

## Consequences

- **Positive:** During a grader outage, all builders keep shipping with a single operator flag; no per-task Archon babysitting. One switch, fully reversible.
- **Negative / risk:** While ON, the quality gate is effectively off for everyone — work lands unverified. This is acceptable only as an outage measure, not a steady state.
- **Operating rule:** Treat the flag as a circuit breaker. Turn it **OFF** as soon as the grader is healthy again (the grader 429 resets Jun 8 3pm ET), then `node scripts/gds/ship.js <id> --regrade` the tasks that landed under the bypass to attach a real grade record — consistent with the standing "prefer re-grade over override" rule.

## Operator runbook

- **Turn ON:** set `GRADER_BYPASS_ENABLED=1` in the droplet service env (`/etc/example/*.env` or the systemd unit), restart the Node process / redeploy.
- **Turn OFF:** remove the var (or set it to anything other than `'1'`), restart/redeploy. The Archon-only confirm gate and normal grader flow resume on the next request.
- **After OFF:** `--regrade` the bypassed tasks for a real grade record.
