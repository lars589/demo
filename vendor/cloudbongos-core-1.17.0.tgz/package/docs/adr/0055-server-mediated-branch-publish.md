# ADR 0055 — Server-mediated branch publish (the dev box holds no GitHub credential)

**Date:** 2026-06-13
**Context:** GDS, task [#1025](https://example.com/builders#/task/1025). A live "can I publish from a dev box?" test failed even after CI self-deploy ([#859](https://example.com/builders#/task/859) / [ADR 0042](<redacted>.md)) went live. Sits at the intersection of [ADR 0042](<redacted>.md) (ci deploy mode), [ADR 0053](0053-scoped-dev-box-session.md) (box-scoped session, [#919](https://example.com/builders#/task/919)), and the box on-ramp ([ADR 0038](<redacted>.md) browser-only builders, [ADR 0044](<redacted>.md), [ADR 0046](<redacted>.md) sandbox-first ship gate / [#927](https://example.com/builders#/task/927), which expects `/builder-ship` to run *on* a box). Governed by the trust boundary in [ADR 0016](<redacted>.md).
**Status:** Accepted.
**Track:** `internal` (development system / builder dev boxes + ship pipeline).

## Problem

A builder on a provisioned cloud dev box **cannot publish/ship** in `ci` deploy mode. Two independent, by-design controls combine to block it, and neither was reconciled when both shipped on 2026-06-13:

1. **The box's GDS session is box-scoped.** Per [ADR 0053](0053-scoped-dev-box-session.md) the baked token is `source='box'` — deny-by-default, reaching only 4 bootstrap endpoints. `/builder-start`, claim, grade, ship all return `403 box_scope`.
2. **The box has no GitHub push credential.** In `ci` mode, `ship.js ciLand()` publishes by `git push origin <branch>` + `gh pr create` + `gh pr merge --auto`. The box has a **credential-less HTTPS** origin (`box-source-fetch.sh` scrubs the clone token by design), no `gh` CLI, no `~/.git-credentials`, no `GH_TOKEN`. `git ls-remote` fails with exit 128.

CI self-deploy ([#859](https://example.com/builders#/task/859)) fixed only the **last** leg — Actions deploys `main`→prod, so no machine holds the droplet key. It did nothing for the two **earlier** legs (a usable session + getting the branch onto GitHub), and [ADR 0053](0053-scoped-dev-box-session.md) deliberately *tightened* the first. The dev-box vision assumes ship-from-box works; nobody wired the box for `ci`-mode publishing. The server itself holds **no** GitHub push credential today (the only GitHub-related secret is the droplet SSH key inside Actions for `deploy-prod.yml`).

## Decision

**The box never holds a GitHub push credential. It uploads its branch to the GDS, and the server pushes it.**

### 1. The box re-auths first (the box-scope model is untouched)

A box-scoped token still cannot ship. The builder runs **`/builder-reauth`** (the existing UI-first browser device flow — [ADR 0053](0053-scoped-dev-box-session.md) §1) to mint a normal `cli` session. That real session — not the baked box token — authorizes the publish.

### 2. A new authenticated publish endpoint, NOT box-scoped

- `POST /api/gds/tasks/:id/publish-branch` — `auth.requireBuilder` + `gateTaskOwnership` (the same [#871](https://example.com/builders#/task/871) gate as `/grade`/`/confirm`/`/ship`), **deliberately without `auth.allowBoxScope`**, so a box-scoped session is `403 box_scope`. Accepts the branch as a **thin git bundle** (base64, `origin/main..HEAD`), `head_sha`, and `value_summary`. The server: writes the bundle to a per-request temp dir, fast `git clone --bare --local` of its own checkout for `main`'s objects (no network, no worktree touch → never races the `deploy-prod.yml` reset), unbundles, **verifies the bundle tip == the claimed `head_sha`** (binds the pushed code to the already-graded sha), then `git push` to GitHub via a **one-shot `x-access-token:<redacted> URL** (never persisted, never logged — the `box-source-fetch.sh` pattern), opens the PR, and enables auto-merge.
- `GET /api/gds/tasks/:id/publish-status?branch=…` — ownership-gated; the server derives PR + deploy state live from GitHub so `ship.js` confirms the land WITHOUT `gh` on the box. No DB column added.
- Implementation: [`src/bongos/github-push.js`](../../src/bongos/github-push.js) (push/PR/status via `execFile` arg-arrays + raw `fetch`, all behind test seams), routes in [`src/bongos/routes/tasks.js`](../../src/bongos/routes/tasks.js), the bundle body bypasses the global 64 KB JSON cap via the skip-list in [`src/bongos/routes.js`](../../src/bongos/routes.js) (route-scoped 32 MB parser + a 20 MB decoded-byte cap).

### 3. `ship.js` chooses the path automatically

`ciLand` splits into `ciLandLocal` (today's `git`+`gh`, byte-for-byte — laptop unchanged) and `ciLandServer` (bundle → `publish-branch` → poll `publish-status`). `pushVia()` picks: `OTB_PUSH_VIA_SERVER=1/0` overrides; otherwise a machine with an authenticated `gh` (laptop) is `local`, everything else (a dev box) is `server`. `doctor.js` reports the same path and no longer fails on missing `gh` when server-mediated.

### 4. The server credential

A **fine-grained GitHub PAT** scoped to the single repo: `Contents: read/write` + `Pull requests: read/write` + `Actions: read`, set as `GITHUB_PUSH_TOKEN` in the droplet EnvironmentFile ([ADR 0022](0022-secrets-policy.md)). It **cannot** push to branch-protected `main` and **cannot** bypass required checks — a leaked server token can only land code on a feature branch behind the same checks every PR faces. **Inert-safe:** with the token unset the endpoint returns `503 push_unconfigured` and laptops are unaffected.

> **Update (2026-06-13, task 1028 — GitHub App):** the preferred server credential is now a **GitHub App**, not a standing PAT. The server holds only the App private key (`GITHUB_APP_ID` + `GITHUB_APP_INSTALLATION_ID` + `GITHUB_APP_PRIVATE_KEY`) and mints a short-lived (~1h), repo-scoped **installation token** per push window — so there's no standing push secret at rest. `github-push.js resolveToken()` prefers the App and falls back to the PAT (`GITHUB_PUSH_TOKEN`) during cutover; `isConfigured()` is true if **either** is set, so the route's inert-safe `503` is unchanged. The App JWT is RS256-signed with `node:crypto` (no new dependency). Same single-repo scopes (Contents r/w + PR r/w + Actions read) and the same can't-touch-`main` guarantee. **LIVE on prod as of 2026-06-13 (task 1043 cutover, blocker 31 resolved):** the App (App ID 4047551, installation 140135657, `repository_selection=selected`) is installed and its key is set in `/etc/example/web-source.env`; verified that the server mints + uses an installation token (`publish-status` → 200, and a broken key fails loud as `503`/error rather than falling back). The old `GITHUB_PUSH_TOKEN` was **removed** — there is now **no standing push secret at rest**, only the App private key.

## Consequences

- A dev-box builder ships end-to-end: `/builder-reauth` → claim → edit → `/builder-stage` ([ADR 0046](<redacted>.md)) → `/builder-ship`, with the GDS doing the push. The box holds no GitHub credential, so the [ADR 0053](0053-scoped-dev-box-session.md) blast-radius argument still holds.
- The blast radius moves from "box holds a push credential" to "server holds a branch-push-only PAT." This is the direction blocker [#15](https://example.com/builders#/blocker/15) ([SEC #863](https://example.com/builders#/task/863)) already wants — a server identity holding the push credential, not builder machines.
- **Follow-up (hardening) — DONE + LIVE (task 1028 code, task 1043 cutover):** the standing PAT is replaced by a **GitHub App** (the server holds only the App private key and mints short-lived, repo-scoped installation tokens per push). See the *Update* above — the App is live on prod and the PAT has been removed.
- **Residual:** the server verifies the bundle tip == the claimed sha and that the caller holds the claim, but does not cheaply prove every commit in the bundle was authored under the claim — branch protection + required checks on `main` (which the credential cannot bypass) are the real gate, exactly as for any PR.
- **Operator action — DONE (blocker 31, resolved 2026-06-13):** the GitHub App was created and `GITHUB_APP_ID` + `GITHUB_APP_INSTALLATION_ID` + `GITHUB_APP_PRIVATE_KEY` set on the droplet (task 1043); `GITHUB_PUSH_TOKEN` then removed. To rotate the key: generate a new private key in the App's settings, replace `GITHUB_APP_PRIVATE_KEY` (single-line, literal `\n`) in `/etc/example/web-source.env`, restart `example`. To roll back to the PAT: restore `web-source.env.bak-task1043` and set a fresh `GITHUB_PUSH_TOKEN` (with the App vars absent, `resolveToken()` falls back to the PAT).
