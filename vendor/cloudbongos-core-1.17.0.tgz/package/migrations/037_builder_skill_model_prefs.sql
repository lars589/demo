-- 037_builder_skill_model_prefs.sql — per-builder model preferences per skill
-- (V3.R85 / #304).
--
-- One column on `builders`, jsonb, default '{}'. Each entry maps a skill name
-- (the directory under .claude/skills/ — e.g. 'planning-session',
-- 'idea-triage', 'builder-claim') to a model preference token:
--
--   'opus'   — full-strength judgment, default for heavy-judgment skills
--   'sonnet' — middle tier, when judgment is needed but cost matters
--   'haiku'  — light judgment, for nearly-mechanical skills
--   'script' — no LLM at all; the skill runs as a pure script invocation
--              (used to record an intentional "no judgment needed here")
--
-- We keep this as a single jsonb column on `builders` rather than a separate
-- `builder_skill_prefs` table because:
--   - It's per-builder personalized config, not analytics. The natural read
--     path is "what does THIS builder prefer for skill X" — one row by
--     primary key. A table would force a join on every skill invocation.
--   - The shape is sparse and irregular (builders only override skills they
--     care about; defaults handle the rest). jsonb is the right shape.
--   - Migrations to add a new skill don't need a backfill — a missing key
--     just falls back to the system default, which is computed in
--     src/bongos/skill-prefs.js.
--   - V4 will retire the per-skill defaults in favor of per-skill-kind
--     defaults (idea #30); having all prefs in one jsonb makes that
--     reshape one schema-free rewrite of the helper, not a table migration.
--
-- Validation: the API (PATCH /api/gds/me/skill-prefs) enforces the four
-- allowed values + a skill-name allowlist. We deliberately do NOT enforce
-- either as a Postgres CHECK because the allowed skills change as new ones
-- ship — a CHECK would force a code+schema coordinated change every time.
--
-- Idempotent: safe to re-run.

ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS skill_model_prefs jsonb NOT NULL DEFAULT '{}'::jsonb;

-- Bump the migration counter past 037 so the next claim that includes
-- 'migrations/' allocates 038. (Counter was pre-reserved at claim time +
-- bumped by hand to 037; this guarantees future allocs see >= 038.)
UPDATE migration_counter SET next_number = GREATEST(next_number, 38) WHERE id = 1;

INSERT INTO schema_migrations (version) VALUES ('037_builder_skill_model_prefs')
  ON CONFLICT (version) DO NOTHING;
