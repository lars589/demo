'use strict';

// The economy module's kernel PORT registration (BV1.R77 / ADR 0093 §1-2).
//
// economy exposes its credit-allocation + gamification + cost/leaderboard READ
// surface as the `reward` kernel PORT. CORE files that must NOT import a module
// resolve it instead:
//   • the LIFECYCLE (db.applyGrade/confirmTask/claimTask/
//     upsertSessionRecordWithReward) — credit allocation + the claim/ship
//     gamification hooks, each passing its tx `client` (transaction-participant);
//   • the core read routes (routes/me.js, routes/public.js, routes/builders.js,
//     routes/sessions.js) — cost rollups, the leaderboard, achievement getters,
//     streak previews, and the budget setter.
// All reach economy WITHOUT importing it by resolving the `reward` kernel PORT
// this factory registers (ADR 0093 §2: keep the state machine whole, extract the
// capability behind a seam). The provider IS the economy module's reward surface.
//
// Why a route factory for a routeless capability: `mountModuleRoutes` (the loader)
// is the one boot hook that runs BOTH in the live server AND whenever a test
// rebuilds the GDS router — so registering here (not in a poller) is what keeps
// the port present for the route-building tests too. Registration is
// hasProvider-guarded so re-instantiation never trips the seam's single-provider
// duplicate guard. (Mirrors modules/grading/routes/grade.js.)

const express = require('express');
const api = require('../../../src/module-api');
const reward = require('../reward');

function registerSeams() {
  if (!api.hasProvider('reward')) {
    api.registerProvider('reward', reward);
  }
}

module.exports = function buildRewardRouter() {
  registerSeams();
  // No HTTP surface — the reward capability is a pure kernel port. The empty
  // router is only the loader's contributes.routes mount vehicle; returning a
  // valid express.Router() keeps mountModuleRoutes' `router.use(sub)` happy
  // without exposing any endpoint.
  return express.Router();
};
