# 0106 — Goal owner/manager authority: fixed owner (creator), promotable managers, owner-only demotion and transfer

- **Status:** Accepted
- **Date:** 2026-07-03
- **Deciders:** jaxri (Metic, owner request), Claude

**Builds on / amends:** [ADR 0086](<redacted>.md) (goal-scoped work hierarchy — this ADR refines its membership-role semantics), [ADR 0016](<redacted>.md) (server-enforced rank boundary — unchanged), [ADR 0090](<redacted>.md) (Metic authoring powers — the rank floor this ADR reuses for ownership).

**Track:** `internal` (GDS / methodology — a Cloud Bongos platform capability).

---

## Context

Migration 160 gave `goal_members` a `role ∈ {lead, member}` column, but the only
role-assignment path was the Archon admission route (`POST /goals/:id/members`).
Task [#1735](https://example.com/builders#/task/1735) was specced as "lead
self-management" with **leads as equals**: any lead promotes/demotes any lead,
"transfer lead" = promote-then-self-demote, invariant "never below one lead."

Mid-build, the owner request refined the model into a fixed hierarchy: the goal
**creator is the owner**; owners promote **managers**; managers hold the owner's
powers *except* goal disposition; and creation stays rank-gated. Three decisions
were made explicitly with the requester:

1. **No delete.** Goals are never hard-deleted (the GDS is a permanent ledger);
   archive stays as it is today (any Metic+ member, reversible).
2. **Ownership is transferable**, owner-only (plus the Archon arm).
3. **Demotion is owner-only.** Managers promote members up; only the owner (or
   an Archon) demotes a manager back down.

## Decision

Two authority layers, deliberately different *kinds*:

| Layer | Where it lives | Powers |
|---|---|---|
| **Owner** | `goals.created_by` — a column, **not** a role row. Set at create; moved only by explicit transfer. | Everything: promote, demote, transfer. |
| **Manager** | `goal_members.role = 'lead'` (the hall renders it "manager"). | Owner-equivalent except: cannot demote a manager, cannot transfer ownership. |

- **Creator becomes owner at create** — `db.createGoal` also upserts the
  creator's `lead` membership row in the same statement, so the owner always
  appears in their own member list. A one-shot module migration
  (`<redacted>`) backfills pre-existing goals' creators the
  same way. Goals with `created_by NULL` (the migration-160 system defaults)
  have **no owner by design**; Archons act as one. Deliberately **no
  earliest-member fallback** in the backfill — promoting someone on an
  ownerless goal would grant authority nobody asked for (fail-closed).
- **`PATCH /goals/:id/members/:builderId {role}`** — the role-change surface.
  Middleware is `requireBuilder` only; the wall is the in-handler PURE ordered
  gate (`authorizeMemberRoleChange`, the `authorizeGoalTaskCreate` precedent):
  goal exists → goal open → actor is owner|manager|Archon → target is a member
  → no-op same-role → demotions owner|Archon-only → **the owner's row is never
  demotable** (`owner_role_fixed` — owner authority is `created_by`, so a
  demoted owner row would just lie to the member list; transfer first). The DB
  write (`setGoalMemberRole`) re-asserts the owner guard **inside the UPDATE**
  so a race cannot demote an owner.
- **`POST /goals/:id/transfer {builder_id}`** — owner (or Archon) hands the
  goal over. The old owner keeps their `lead` row (drops to manager, not out);
  the new owner's membership upserts to `lead` in the same statement that moves
  `created_by`. **The new owner must be Metic+**: goal creation is Metic+
  ([ADR 0086](<redacted>.md) / R57), ownership is
  creator-equivalent authority, and this also keeps the protected-scope
  membership wall intact (a protected-scope goal requires Metic+ members).
- **Creation rank gate: unchanged.** `POST /goals` was already
  `requireRank('metic','archon')` (Archon-only for protected scope) — the
  owner request's "only Archons or Metics can create" was already enforced.
- **Pins:** both new routes are pinned `any-builder` in
  `route-rank-check.MODULE_EXPECTED_RANKS['lifecycle']` — like the authoring
  keystone, the wall is in-handler, and the pin makes an accidental
  `requireRank` re-gate (or a gate removal) a red build.

## Consequences

- The "never below one lead" invariant from the original task spec is **gone**
  — it existed to keep *someone* in charge, and a fixed owner does that job
  with less machinery. Manager count may legitimately be zero.
- The hall Goals page can light up role controls (owner/manager framing) and a
  transfer action; task [#1736](https://example.com/builders#/task/1736)'s
  conflict-resolution actions gate on owner/manager instead of "lead."
- "Delete goal" remains a non-feature. If it is ever wanted, it must come back
  through a new ADR (archive semantics already cover retirement).
- A demoted-to-member ex-manager retains plain membership (join/leave/author
  within scope) — demotion is not expulsion.
