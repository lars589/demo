# Recipe: Claude Design loop

> End-to-end guide for the repo ↔ Claude Design sync cycle.
> ADR: [ADR 0081](../adr/<redacted>.md).
> Adapter: `src/ui/adapters/claude-design/index.js`.
> CLI: `scripts/gds/design-sync.js`.
> Skill: `.claude/skills/design-sync/SKILL.md`.

---

## When to use this

- Starting a UI sprint and want Claude Design to prototype from real tokens, not approximations.
- Tokens or surfaces changed and the Claude Design project is stale.
- A Claude Design prototype is done and you want to land the generated code as a GDS task.

---

## Prerequisites

- **Rank: Metic+** (design-sync routes are Metic-gated server-side).
- **Claimed GDS task** — use this for the handoff step. If you're just exporting, no claim is required; a claim is required when you `export()` and commit the generated code.
- **DesignSync MCP** — the `mcp__DesignSync__*` tools must be available in your session.

---

## 1. Build the token bundle

```bash
node scripts/gds/design-sync.js
```

Output (JSON on stdout):

```json
{
  "bundlePath": "/tmp/otb-design-bundle-XXXXX",
  "files": [
    "tokens/colors.html",
    "tokens/typography.html",
    "tokens/spacing.html",
    "tokens/radii.html",
    "tokens.css",
    "tokens.json",
    "surfaces.json"
  ],
  "surfaceIds": ["hall-ui", "status-ui"],
  "summary": "bundle → /tmp/otb-design-bundle-XXXXX · 2 surface(s) · tokens: colors, typography, spacing, radii"
}
```

**To scope to one surface:**
```bash
node scripts/gds/design-sync.js --surface hall-ui
```

---

## 2. Push to Claude Design

Use the DesignSync MCP tool in your Claude Code session:

```
list_projects      → pick the OTB project (or create "Off the Boats — Design System")
finalize_plan      → stage all files from manifest.files, rooted at bundlePath
write_files        → push the bundle
```

After the push:
- Token preview cards appear under **Design System** → **Tokens** (colors / typography / spacing / radii).
- `tokens.css` is available for prototype stylesheets as `--dt-<group>-<key>` CSS vars.
- `surfaces.json` tells Claude Design which surfaces exist.

---

## 3. Prototype in Claude Design

Claude Design can now reference the token cards. Typical workflow:

1. Open Claude Design → select the OTB project.
2. Describe the UI: "Build a task-card component matching the token palette."
3. Claude Design generates HTML/CSS/JS using `--dt-*` vars.
4. Iterate until the prototype is ready.

---

## 4. Land the handoff as a GDS task

When Claude Design's output is ready:

**a. Claim a GDS task** (if not already done).

**b. Run the export step** — either via the skill or directly:

```js
const adapter = require('./src/ui/adapters/claude-design/index.js');
const result = await adapter.export({
  repoRoot: process.cwd(),
  surfaceId: 'hall-ui',
  toolOutput: { files: [
    { path: 'components/TaskCard.js', content: '...' },
    { path: 'components/TaskCard.css', content: '...' },
  ]},
  taskId: '1234',
});
// result: { filePaths, commitMessage, designSourcesUpdated, warnings }
```

The adapter writes files to `src/ui/<surfaceId>/` and updates `config/design-sources.json` with the sync timestamp.

**c. Commit + ship.**

```bash
git add src/ui/hall-ui/ config/design-sources.json
git commit -m "ui(hall-ui): Claude Design export (task 1234)"
node scripts/gds/ship.js 1234 --notes "..." --summary "..."
```

---

## Iterating

- Re-run `node scripts/gds/design-sync.js` + re-push whenever tokens change.
- The `export()` call is **idempotent** — files with identical content are skipped.
- `config/design-sources.json` tracks which surface was last synced, by which tool, and when.

---

## Coexisting with Figma

If a surface is Figma-canonical, its `config/design-sources.json` entry will have `"tool": "figma"`. The Claude Design adapter will still work on that surface, but treat the result as an experimental branch — the Figma-canonical surface won't round-trip cleanly. For code-canonical surfaces (the default), Claude Design is the right tool.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `design-sync: repoRoot is required` | Run from the repo root: `node scripts/gds/design-sync.js` |
| `design-tokens.neutral.json` missing | Run from a checkout that includes `config/`. |
| `path-escape` error from `export()` | Claude Design sent a path with `../` — reject that output and re-prompt. |
| Bundle is stale after token edit | Re-run `node scripts/gds/design-sync.js` and re-push. |
| DesignSync MCP not available | The MCP tool is session-specific — check your Claude Code session config. |
