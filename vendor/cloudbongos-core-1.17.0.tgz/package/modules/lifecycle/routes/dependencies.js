// src/bongos/routes/dependencies.js — the polymorphic dependency edge's HTTP surface
// (ADR 0086 §5, BV1.R62 / task 1516).
//
// One "blocked-until-done" edge over {task, goal, criterion}. The task->task subset
// keeps its historical API (POST/PUT/DELETE /tasks/:id/dependencies in tasks.js);
// THIS router creates/removes edges that involve a goal or criterion — the new
// cross-tier coordination contract. A dependency is a REFERENCE, not a grant: it
// never widens module scope, so cross-goal / cross-version edges are allowed. The
// claim gate (db.unsatisfiedDeps) and the auto-promotion triggers resolve them.
//
// rank: archon. Authoring a cross-tier dependency reshapes execution order across
// shared workspaces; it stays owner-gated (the same posture as the Archon-only task
// dependency mutations in tasks.js). route-rank-check.EXPECTED_RANKS pins it.

const express = require('express');
// Intra-module + the published doorway — a module never requires a core internal.
const api = require('../../../src/module-api');
const auth = api;
const db = require('../db');

const KINDS = ['task', 'goal', 'criterion'];

// Validate + coerce the 4-tuple edge body. Ids may arrive as JSON numbers or numeric
// strings (pg serializes bigint as a string). Returns { fromKind, fromId, toKind,
// toId } or null when it has already sent a 400.
function parseEdge(req, res) {
  const fromKind = req.body.from_kind;
  const toKind = req.body.to_kind;
  if (!KINDS.includes(fromKind) || !KINDS.includes(toKind)) {
    res.fail('bad_kind', 400, { valid: KINDS });
    return null;
  }
  const fromId = Number(req.body.from_id);
  const toId = Number(req.body.to_id);
  if (!Number.isInteger(fromId) || fromId <= 0 || !Number.isInteger(toId) || toId <= 0) {
    res.fail('bad_id', { status: 400, message: 'from_id and to_id must be positive integers.' });
    return null;
  }
  return { fromKind, fromId, toKind, toId };
}

function mapDepError(err, res, tag) {
  if (err && err.code === 'SELF_DEP') return res.fail('self_dep', 400);
  if (err && err.code === 'BAD_KIND') return res.fail('bad_kind', 400, { valid: KINDS });
  if (err && err.code === 'NODE_NOT_FOUND') return res.fail('node_not_found', 404);
  if (err && err.code === 'CYCLE') return res.fail('cycle', 409, { path: err.path });
  console.error(`[gds] ${tag}`, err);
  return res.fail('dependency_op_failed', { status: 500, message: 'internal error' });
}

module.exports = function buildDependenciesRouter() {
  const router = express.Router();

  // POST /dependencies — create an edge "from is blocked until to is done".
  // rank: archon.
  router.post('/dependencies', auth.requireBuilder, auth.requireRank('archon'), async (req, res) => {
    const edge = parseEdge(req, res);
    if (!edge) return;
    try {
      const dependency = await db.addDependency(edge.fromKind, edge.fromId, edge.toKind, edge.toId);
      return res.status(201).json({ ok: true, dependency });
    } catch (err) {
      return mapDepError(err, res, 'POST /dependencies');
    }
  });

  // DELETE /dependencies — remove an edge (body carries the 4-tuple).
  // rank: archon.
  router.delete('/dependencies', auth.requireBuilder, auth.requireRank('archon'), async (req, res) => {
    const edge = parseEdge(req, res);
    if (!edge) return;
    try {
      const removed = await db.removeDependency(edge.fromKind, edge.fromId, edge.toKind, edge.toId);
      if (!removed) return res.fail('dependency_not_found', 404);
      return res.json({ ok: true });
    } catch (err) {
      return mapDepError(err, res, 'DELETE /dependencies');
    }
  });

  return router;
};
