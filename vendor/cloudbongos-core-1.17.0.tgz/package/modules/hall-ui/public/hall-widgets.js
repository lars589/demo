// hall-widgets.js — the CORE builders'-hall widget registrations (BV1.R75, ADR 0062 §4).
//
// Every widget — core here, module-contributed from a module's own client script —
// registers into the window.OTB hall-widget registry (dom-utils.js), and builders.js
// mounts the registered set into the shell's view containers (task 1723 redesign):
//   view: 'home' | 'standing' | 'achievements' | 'leaderboard'  (default 'home')
//   zone: a finer mount target inside the Home view
//         ('home-banner' | 'home-stats' | 'home-band' | 'home-main')
// Both fields ride the registry entry untouched; builders.js resolves them to the
// #zone-* containers in index.html and falls back to <main> when absent, so a
// module widget written before the redesign still lands (on Home).
//
// Each widget owns its skeleton markup. mount(host) stamps that skeleton into the
// registry-made <section>; builders.js then wires data to the same element ids it
// always has (#profile-body, #recent-ships, …) — the data-rendering code is
// untouched by design. A fitness check (scripts/gds/fitness.js
// checkHallSectionRegistry) asserts index.html hardcodes no <section class="scroll">
// in <main> — the registry is the single source of truth for what the hall shows.
(function () {
  'use strict';
  // Instance currency label (window.__BRANDING__ is injected synchronously in
  // <head>, before this script) — never a hardcoded unit (ADR 0062 §3).
  function curLabel(caps) { var b = window.__BRANDING__ || {}; var l = (b.currency && b.currency.label) || 'credits'; return caps ? l.charAt(0).toUpperCase() + l.slice(1) : l; }
  if (!window.OTB || typeof window.OTB.contributeHallWidget !== 'function') return;
  const reg = window.OTB.contributeHallWidget;

  // setHtml — stamp a widget's skeleton into its host <section>. The host element
  // already carries the section's stable id + class (builders.js creates it from the
  // registry entry), so the skeleton is just the inner content.
  const w = (id, label, order, html, opts) =>
    reg(Object.assign({
      id, label, order,
      mount(host) { host.innerHTML = html; },
    }, opts || {}));

  /* ---------------- Home ---------------- */

  // 0. First-visit welcome banner — V3.R77 (#296). Pre-graduation only; dismissable.
  w('welcome-scroll', 'Welcome', 0,
    '<button type="button" class="welcome__minimize" id="welcome-minimize" aria-label="Minimize the welcome panel" title="Minimize">−</button>' +
    '<h2 id="welcome-h" class="scroll__h">Welcome</h2>' +
    '<div class="welcome" id="welcome-body"><div class="profile__placeholder">…</div></div>',
    { view: 'home', zone: 'home-banner', welcomeChip: true, sectionClass: 'scroll scroll--welcome', labelledby: 'welcome-h', hiddenByDefault: true });

  // 0b. Onboarding checklist — V3.R75 (#294).
  w('onboarding-scroll', 'Getting started', 10,
    '<h2 id="onboarding-h" class="scroll__h">Getting started</h2>' +
    '<p class="scroll__lede">A short path to finding your feet. Tick the steps you’ve done; the rest are tracked for you.</p>' +
    '<ol class="onboarding-list" id="onboarding-list"><li class="onboarding-item onboarding-item--placeholder">…</li></ol>' +
    '<p class="ledger__note" id="onboarding-status" hidden></p>',
    { view: 'home', zone: 'home-banner', labelledby: 'onboarding-h', hiddenByDefault: true });

  // 0c. Quick stats — headline numbers for the Home dashboard (task 1723).
  // Filled by builders.js: credits + karma + rank from /me (renderProfile),
  // shipped count once the ships feed settles (renderRecentShips).
  w('home-stats', 'Overview', 15,
    '<h2 id="home-stats-h" class="sr-only">Overview</h2>' +
    '<div class="stat-row" id="home-stats-row">' +
      '<div class="stat-tile"><span class="stat-tile__label" data-currency-label="caps">Credits</span><span class="stat-tile__num" id="stat-credits">—</span></div>' +
      '<div class="stat-tile"><span class="stat-tile__label">Shipped</span><span class="stat-tile__num" id="stat-shipped">—</span><span class="stat-tile__sub" id="stat-shipped-sub"></span></div>' +
      '<div class="stat-tile"><span class="stat-tile__label">Karma</span><span class="stat-tile__num" id="stat-karma">—</span><span class="stat-tile__sub" id="stat-karma-sub"></span></div>' +
      '<div class="stat-tile"><span class="stat-tile__label">Rank</span><span class="stat-tile__num stat-tile__num--badge" id="stat-rank">—</span><span class="stat-tile__sub" id="stat-rank-sub"></span></div>' +
    '</div>',
    { view: 'home', zone: 'home-stats', sectionClass: 'scroll scroll--bare', labelledby: 'home-stats-h', hiddenByDefault: true });

  // 0d. Standing summary card — left half of the Home band (task 1723). Filled by
  // builders.js renderProfile from the same /me payload as the full Standing view.
  w('home-standing', 'Standing', 18,
    '<h2 id="home-standing-h" class="scroll__h">Standing</h2>' +
    '<div id="home-standing-body"><div class="profile__placeholder">…</div></div>' +
    '<p class="card-foot"><a href="#standing">View full standing →</a></p>',
    { view: 'home', zone: 'home-band', labelledby: 'home-standing-h', hiddenByDefault: true });

  // (Goals — goals.js registers itself into the other half of the Home band.)

  // 0e. Recent work — compact 5-row table (task 1723). Filled by builders.js
  // renderRecentShips from the same feed as the full Your-work table.
  w('home-recent', 'Recent work', 28,
    '<h2 id="home-recent-h" class="scroll__h">Recent work</h2>' +
    '<table class="ledger" id="home-recent-table"><thead><tr><th>№</th><th>Work</th><th data-currency-label="caps">Credits</th><th>Shipped</th></tr></thead>' +
    '<tbody><tr><td colspan="4" class="ledger__empty">…</td></tr></tbody></table>' +
    '<p class="card-foot"><a href="#standing">All your work →</a></p>',
    { view: 'home', zone: 'home-main', labelledby: 'home-recent-h', hiddenByDefault: true });

  /* ---------------- Standing ---------------- */

  // 1. Profile — the identity band at the top of Standing (#726).
  w('profile-scroll', 'Profile', 20,
    '<h2 id="profile-h" class="sr-only">Profile</h2>' +
    '<div class="profile" id="profile-body"><div class="profile__placeholder">…</div></div>',
    { view: 'standing', sectionClass: 'scroll scroll--profile', labelledby: 'profile-h' });

  // 2. WORKS — recent ships.
  w('ships-scroll', 'Your work', 30,
    '<h2 id="ships-h" class="scroll__h">Your work</h2>' +
    '<div class="filters">' +
      '<label class="filter"><span>Window</span><select id="f-ships-window">' +
        '<option value="7">Last 7 days</option><option value="30">Last 30 days</option>' +
        '<option value="90">Last 90 days</option><option value="all" selected>All time</option>' +
      '</select></label>' +
      '<label class="filter"><span>Version</span><select id="f-ships-version"><option value="">— any —</option></select></label>' +
      '<label class="filter"><span>Sort</span><select id="f-ships-sort">' +
        '<option value="recent">most recent first</option><option value="oldest">oldest first</option>' +
        '<option value="drachmae-high" data-currency-tmpl="highest {label}">highest credits</option>' +
        '<option value="drachmae-low" data-currency-tmpl="lowest {label}">lowest credits</option>' +
      '</select></label>' +
      '<span id="ships-count" aria-live="polite" class="filter__count"></span>' +
    '</div>' +
    '<table class="ledger" id="recent-ships"><thead><tr><th>№</th><th>Work</th><th data-currency-label="caps">Credits</th><th>Shipped</th></tr></thead>' +
    '<tbody><tr><td colspan="4" class="ledger__empty">…</td></tr></tbody></table>' +
    '<div class="pager" id="ships-pager" hidden>' +
      '<button class="btn-ghost" id="ships-prev" disabled>← earlier</button>' +
      '<span id="ships-range" class="pager__range">1–10</span>' +
      '<button class="btn-ghost" id="ships-next">later →</button>' +
    '</div>',
    { view: 'standing', labelledby: 'ships-h' });

  // 3. CURVE — the builder's development curve (V3.R72 #291, C5).
  w('analytics-scroll', 'Progress', 40,
    '<h2 id="curve-h" class="scroll__h">Progress</h2>' +
    '<p class="scroll__lede">How your output has changed over time — work shipped, cost and time per work, and how reviews held up. <span id="curve-scope-note"></span></p>' +
    '<div class="curve" id="curve-body">' +
      '<div class="profile__placeholder" id="curve-empty" style="display:none;">Not enough shipped work yet to chart.</div>' +
      '<div class="curve__headline" id="curve-headline"></div>' +
      '<div class="curve__grid" id="curve-grid"></div>' +
      '<div class="curve__kinds" id="curve-kinds"></div>' +
    '</div>',
    { view: 'standing', labelledby: 'curve-h', hiddenByDefault: true });

  // 4. MARKS — review quality of recent output.
  w('grades-scroll', 'Reviews', 50,
    '<h2 id="marks-h" class="scroll__h">Reviews</h2>' +
    '<div class="profile__placeholder" id="marks-empty" style="display:none;">No work reviewed yet.</div>' +
    '<table class="ledger" id="recent-grades"><thead><tr><th>№</th><th>Work</th><th>Score</th><th>Verdict</th><th>Reviewed</th></tr></thead>' +
    '<tbody><tr><td colspan="5" class="ledger__empty">…</td></tr></tbody></table>' +
    '<p class="ledger__note" id="grades-rolling-note" hidden></p>',
    { view: 'standing', labelledby: 'marks-h' });

  // 5. KARMA feed — V3.R26 (#246). Hidden until /me returns karma data.
  w('karma-scroll', 'Karma', 60,
    '<h2 id="karma-h" class="scroll__h">Karma</h2>' +
    '<p class="scroll__lede">Karma rewards good citizenship — ratified ideas, peer recognition, approvals. Distinct from ' + curLabel() + ', which counts work shipped.</p>' +
    '<table class="ledger" id="karma-feed"><thead><tr><th>When</th><th>Delta</th><th>Reason</th><th>Granted by</th></tr></thead>' +
    '<tbody><tr><td colspan="4" class="ledger__empty">…</td></tr></tbody></table>',
    { view: 'standing', labelledby: 'karma-h', hiddenByDefault: true });

  // 5b. Peer acclaim — V3.R25 (#245). Hidden until data.
  w('acclaim-scroll', 'Peer recognition', 70,
    '<h2 id="acclaim-h" class="scroll__h">Peer recognition</h2>' +
    '<p class="scroll__lede">Recognize your peers’ finished work. A vote up (+) or down (−) shapes their karma after a one-week cooling period. You can’t vote on your own work.</p>' +
    '<table class="ledger" id="acclaim-feed"><thead><tr><th>Work</th><th>By</th><th>Votes</th><th>Your vote</th></tr></thead>' +
    '<tbody><tr><td colspan="4" class="ledger__empty">…</td></tr></tbody></table>',
    { view: 'standing', labelledby: 'acclaim-h', hiddenByDefault: true });

  // 6. BOUNTY — red-team rewards payout table (V3.R65 #284).
  w('bounty-scroll', 'Security bounties', 80,
    '<h2 id="bounty-h" class="scroll__h">Security bounties</h2>' +
    '<p class="scroll__lede">Find a flaw in the system’s own walls and report it — rewards are paid in ' + curLabel() + ' by severity. The numbers below are the live reward schedule. <a href="/diagrams">See how it fits the whole.</a></p>' +
    '<table class="ledger" id="bounty-table"><thead><tr><th>Severity</th><th data-currency-label="caps">Credits</th><th>What counts</th></tr></thead>' +
    '<tbody><tr><td colspan="3" class="ledger__empty">…</td></tr></tbody></table>',
    { view: 'standing', labelledby: 'bounty-h' });

  /* ---------------- Achievements ---------------- */

  // 7. Achievements — long-term progression (#726).
  w('honours-scroll', 'Achievements', 85,
    '<h2 id="ach-h" class="sr-only">Achievements</h2>' +
    '<p class="scroll__lede">Eight achievements recognize sustained contribution. Earned ones are highlighted; the rest show what’s left to do.</p>' +
    '<div class="ach-grid" id="ach-grid"><div class="profile__placeholder">…</div></div>',
    { view: 'achievements', sectionClass: 'scroll scroll--bare', labelledby: 'ach-h' });

  /* ---------------- Leaderboard ---------------- */

  // 8. Leaderboard.
  w('leaderboard-scroll', 'Leaderboard', 90,
    '<h2 id="lb-h" class="sr-only">Leaderboard</h2>' +
    '<table class="ledger" id="leaderboard"><thead><tr>' +
      '<th>Place</th><th>Builder</th>' +
      '<th class="ledger__sortable" id="lb-sort-rank" aria-sort="none" title="Sort by rank">Rank</th>' +
      '<th class="ledger__sortable" id="lb-sort-drachmae" aria-sort="descending" title="Sort by ' + curLabel() + ' (work shipped)" data-currency-label="caps">Credits</th>' +
      '<th class="ledger__sortable" id="lb-sort-karma" aria-sort="none" title="Sort by karma (peer recognition + approvals)">Karma</th>' +
    '</tr></thead><tbody><tr><td colspan="5" class="ledger__empty">…</td></tr></tbody></table>' +
    '<div class="pager">' +
      '<button class="btn-ghost" id="lb-prev" disabled>← earlier</button>' +
      '<span id="lb-range" class="pager__range">1–10</span>' +
      '<button class="btn-ghost" id="lb-next">later →</button>' +
    '</div>',
    { view: 'leaderboard', labelledby: 'lb-h' });
})();
