# 0090 — Metic gains task authoring: create / promote / edit + dependency & criteria shaping

- **Status:** Accepted
- **Date:** 2026-06-26
- **Deciders:** Lars (Archon), Claude

**Builds on / amends:** [ADR 0016](<redacted>.md) (server-enforced rank boundary — unchanged), [ADR 0018](<redacted>.md) (three-rank model — this ADR re-ranks one row of its table), [ADR 0034](<redacted>.md) (Thetes graduated-newcomer rank), [ADR 0086](<redacted>.md) (goal-scoped work hierarchy — the safer, scope-bounded path this ADR sits beside).

**Track:** `internal` (GDS / methodology — a Cloud Bongos platform capability).

---

## Context

Under the three-rank model ([ADR 0018](<redacted>.md)), **task authoring was Archon-only**: `POST /tasks`, `PATCH /tasks/:id`, `POST /tasks/:id/promote`, and the task↔dependency / task↔criterion CRUD all carried `requireRank('archon')`. A Metic — the Archon-approved *working* rank — could already do the higher-trust judgment work of **idea triage** (`PATCH /inbox/:id`), **blocker review**, and **planning/priority sessions**, but could not turn the ideas they triaged into the tasks those ideas became. They had to hand each one back to the Archon to author.

That is an incoherent trust line. A rank trusted to decide *which ideas become work* (triage) but not trusted to *write the work down* (author a task) creates a bottleneck precisely at the Archon, for no security gain — the Metic already directs the plan; they just can't record it.

Lars's directive (2026-06-26): **"If a Metic can run idea triage, they should be able to seed tasks."** Allow Metics to create, promote, and edit tasks now; setting rank and closing versions stay Archon. Explicitly: *"we can tighten up security later."*

This is deliberately broader and simpler than [ADR 0086](<redacted>.md), which solves the *lower-rank* (xenos/thetes) version of the same problem with a tightly scoped, module-bounded `POST /goals/:id/tasks` grant. ADR 0086's careful scope-subset wall is the right tool for letting an *untrusted* builder author within a fence; for the *trusted* Metic, the owner chose the blunt grant: full task authoring, no fence.

## Decision

Re-rank these `src/bongos/routes/tasks.js` gates from `requireRank('archon')` to `requireRank('metic', 'archon')`:

| Route | Was | Now |
|---|---|---|
| `POST /tasks` (create) | archon | **metic+** |
| `PATCH /tasks/:id` (edit, incl. `newcomer_friendly`) | archon | **metic+** |
| `POST /tasks/:id/promote` (backlog→ready) | archon | **metic+** |
| `POST /tasks/:id/dependencies` (add edge) | archon | **metic+** |
| `DELETE /tasks/:id/dependencies/:depId` | archon | **metic+** |
| `PUT /tasks/:id/dependencies` (replace set) | archon | **metic+** |
| `POST /tasks/:id/criteria` (link criterion) | archon | **metic+** |
| `DELETE /tasks/:id/criteria/:criterionId` | archon | **metic+** |

The dependency + criteria CRUD move alongside create/edit so a Metic can fully **shape** a task they author — without them, a Metic could mint a task but not order it (deps gate claiming) or make it count toward a version (`/status` rolls up via criterion links). "Full task shaping" was Lars's chosen scope when offered create/edit/promote-only vs. the broader set.

`requireRank('metic', 'archon')` uses the existing threshold semantics ([#591](https://example.com/builders#/task/591)): the floor is `metic`, so `metic`, `archon`, and the divine tiers above pass; `thetes`/`xenos` and everything below the floor are denied (fail-closed). Thetes/Xenos still author nothing directly — they file ideas, and (per ADR 0086) may author goal-scoped tasks only within a module fence.

### Two `PATCH /tasks/:id` fields are security controls, not planning fields

Opening `PATCH /tasks/:id` to Metic also exposes two fields that were previously gated *only* by the route being Archon-only — neither had a field-level check. We split them by what they actually are:

- **`requires_rank`** stays open to Metic. `db.updateTaskRequiresRank` clamps the value **up** to the auto-derived floor ([ADR 0084](<redacted>.md)), so a Metic can only *raise* who may claim a task — never open a sensitive task to a lower rank. Raising a claim floor grants the Metic nothing; it is genuine task-shaping ("this needs a higher rank").
- **`security_sensitive`** stays **Archon-only**, enforced by a new in-handler `rankMeetsThreshold(rank, ['archon'])` check in the PATCH handler. It is a security control, not a planning field: it suppresses the ship→Discord broadcast (routes it to the Archon-only `#security-ship-feed`, task 990) and feeds the auto-derived rank floor. Letting a Metic flip an existing task to `security_sensitive: false` would lower a flag-only-sensitive task's floor and un-suppress its broadcast — a weakening of an existing control, outside "author/shape a task." Setting it at **create** time (`POST /tasks`) is left open to Metic: a brand-new task has no existing sensitivity to clear, and setting the flag *on* only ratchets restriction up.

### What stays Archon-only

- **Setting rank** (`PATCH /builders/:id/rank`) and **closing versions** — the two authorities Lars named as never-delegated.
- `POST /tasks/:id/abandon` (terminal scope removal — the inverse of promote; a destructive lifecycle kill).
- `POST /tasks/:id/confirm` (grader-bypass — must not let a builder push their own work past a failed grade — [#231](https://example.com/builders#/task/231)).
- The **cross-tier polymorphic** `POST|DELETE /dependencies` and goal-scope edges ([ADR 0086](<redacted>.md) §5) — reshaping `{task,goal,criterion}` order across shared workspaces is a wider blast radius than wiring one task's own deps, and stays pinned Archon.
- `POST /versions`, peer-vote tally, override-request adjudication, newcomer-restock.

### Downgrade protection

`POST /tasks` and `POST /tasks/:id/promote` are pinned in `EXPECTED_RANKS` (`src/bongos/route-rank-check.js`); both pins move to `metic+archon` in lockstep. A *silent further downgrade* (e.g. to any-builder) on either remains a hard CI fail. The route's `// rank:` annotation is updated to match the middleware, keeping the route-rank audit (`tests/route_rank_check.mjs`, the `unit` gate's fitness check) green.

## Consequences

- **Metics can now run the full triage→author loop** — promote an idea to a task and shape it — without the Archon. The delegation bottleneck at the owner is removed for the trusted working rank.
- **Larger trusted surface.** A Metic is now a `requireRank('metic')` away from authoring any task in any open version (subject to the per-task `requires_rank` floor on *claiming*, [ADR 0084](<redacted>.md), which is unaffected). This is the "tighten later" debt Lars accepted: there is no per-version, per-module, or per-goal fence on a Metic's authoring the way ADR 0086 fences a lower rank. A future ADR can narrow this (e.g. fold Metic authoring into the goal-scope model) without re-litigating the principle.
- **ADR 0018's table changes.** Its row *"Create / promote / edit tasks, deps, confirm, done-when scope — Metic ❌ / Archon ✅"* is now split: create/promote/edit/deps are ✅ for Metic; confirm and version-scope stay ❌. The ADR 0018 file is annotated with a pointer here rather than rewritten (ADRs are append-only history).
- **ADR 0086 still stands** for xenos/thetes — its module-scoped `POST /goals/:id/tasks` grant is the only authoring path for sub-Metic ranks, and its scope-subset + protected-path walls are untouched. This ADR only widens the *Metic* line.
- **Trust boundary intact** ([ADR 0016](<redacted>.md)): enforcement is still server-side, per-request, no cache. Editing a doc or `CLAUDE.md` grants nothing; the route's `requireRank('metic','archon')` is the authority.

## Alternatives considered

- **Create/edit/promote only, leave deps + criteria Archon.** Rejected (Lars chose full shaping): a Metic who can create a task but not wire its dependencies or criterion links produces half-formed tasks the Archon must finish — re-introducing the bottleneck one level down.
- **Use the ADR 0086 goal-scoped path for Metics too.** Sound, and the likely "tighten later" destination, but heavier than the owner wanted now: it requires a goal to exist and a module scope to be set before a Metic can author. Lars opted for the direct grant and explicit deferral.
- **Promote the relevant builders to Archon instead.** Rejected: Archon also carries rank-setting, version-close, grader-bypass, and infra — far more than "author tasks." The whole point of Metic is breadth-of-work without those keys.
