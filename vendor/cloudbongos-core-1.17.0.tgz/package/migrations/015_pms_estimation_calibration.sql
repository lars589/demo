-- 015_pms_estimation_calibration.sql — per-kind estimate calibration.
--
-- Problem (investigated 2026-05-11, idea #25, task #198):
--   Across 109 shipped tasks with actuals, median actual/est ratio is 0.03
--   (mean 0.14, p90 0.10). Estimates are sized for humans but the work is
--   Claude-executed — they run ~30× faster than the prior assumes. The
--   optimizer's `est_minutes <= timeBudgetMin` filter rejects tasks that
--   would actually fit; displayed estimates create false expectations.
--
-- Fix:
--   `pms_calibrated_minutes(est, kind)` returns est × per-kind median ratio
--   computed live from shipped+confirmed tasks (the smoke-filter row
--   pattern from view 006 is preserved). Three-tier fallback:
--     1. ≥5 same-kind samples → use kind-specific median.
--     2. ≥10 total samples    → use overall median (kind has too little data).
--     3. <10 total samples    → return raw est (cold-start; trust the human).
--   Returning NULL for NULL/zero est. Result is GREATEST(1, …) so we never
--   tell a builder "0 minutes".
--
--   `claimable_tasks` and `tasks_session_fit` are rebuilt to expose
--   `est_minutes_calibrated` and to compute `credits_per_minute` from
--   the calibrated number rather than the raw input.
--
-- Selection follow-on (src/pms/optimizer.js):
--   `est_minutes <= timeBudgetMin` becomes
--   `COALESCE(est_minutes_calibrated, est_minutes) <= timeBudgetMin`.
--
-- Idempotent: CREATE OR REPLACE for function + views.

CREATE OR REPLACE FUNCTION pms_calibrated_minutes(est integer, in_kind text)
RETURNS integer
LANGUAGE sql
STABLE
AS $$
  WITH ratios AS (
    SELECT t.kind,
           t.actual_minutes::numeric / t.est_minutes AS r
      FROM tasks t
     WHERE t.status IN ('shipped', 'confirmed')
       AND t.actual_minutes IS NOT NULL
       AND t.est_minutes IS NOT NULL
       AND t.est_minutes > 0
       AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
  ),
  kind_stats AS (
    SELECT percentile_cont(0.5) WITHIN GROUP (ORDER BY r)::numeric AS median,
           COUNT(*)::integer AS n
      FROM ratios
     WHERE kind = in_kind
  ),
  overall_stats AS (
    SELECT percentile_cont(0.5) WITHIN GROUP (ORDER BY r)::numeric AS median,
           COUNT(*)::integer AS n
      FROM ratios
  )
  SELECT CASE
    WHEN est IS NULL OR est <= 0 THEN NULL
    WHEN (SELECT n FROM kind_stats) >= 5 THEN
      GREATEST(1, ROUND(est * (SELECT median FROM kind_stats))::integer)
    WHEN (SELECT n FROM overall_stats) >= 10 THEN
      GREATEST(1, ROUND(est * (SELECT median FROM overall_stats))::integer)
    ELSE est
  END;
$$;

-- Companion summary function for transparency / debugging. Returns the
-- ratios table used by pms_calibrated_minutes. Not used in production
-- selection — only by smoke tests, /builder-start --debug, and any future
-- status-page transparency row (deferred follow-up).
CREATE OR REPLACE FUNCTION pms_calibration_summary()
RETURNS TABLE (kind text, median_ratio numeric, sample_size integer)
LANGUAGE sql
STABLE
AS $$
  WITH ratios AS (
    SELECT t.kind,
           t.actual_minutes::numeric / t.est_minutes AS r
      FROM tasks t
     WHERE t.status IN ('shipped', 'confirmed')
       AND t.actual_minutes IS NOT NULL
       AND t.est_minutes IS NOT NULL
       AND t.est_minutes > 0
       AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
  )
  SELECT kind,
         ROUND(percentile_cont(0.5) WITHIN GROUP (ORDER BY r)::numeric, 4) AS median_ratio,
         COUNT(*)::integer AS sample_size
    FROM ratios
   GROUP BY kind
   ORDER BY sample_size DESC, kind;
$$;

-- Rebuild claimable_tasks to expose est_minutes_calibrated. Same WHERE
-- clauses as 006 — only the SELECT list changes.
DROP VIEW IF EXISTS claimable_tasks;
CREATE VIEW claimable_tasks AS
SELECT t.*,
       pms_calibrated_minutes(t.est_minutes, t.kind) AS est_minutes_calibrated
  FROM tasks t
 WHERE t.status = 'ready'
   AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
   AND NOT EXISTS (
     SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id
   )
   AND NOT EXISTS (
     SELECT 1 FROM claims c
       JOIN tasks t2 ON t2.id = c.task_id
      WHERE c.released_at IS NULL
        AND t2.touches && t.touches
   );

-- Rebuild tasks_session_fit to compute credits_per_minute against the
-- calibrated estimate (was: raw est_minutes). Also exposes
-- est_minutes_calibrated so consumers can display it. Uses DROP+CREATE
-- rather than OR REPLACE because adding a column mid-SELECT-list isn't
-- supported by CREATE OR REPLACE VIEW. No dependent views (verified
-- against pg_depend at migration-write time).
DROP VIEW IF EXISTS tasks_session_fit;
CREATE VIEW tasks_session_fit AS
SELECT t.*,
  CASE
    WHEN t.automation_tag = 'overnight-safe' AND COALESCE(t.manual_degree, 5) <= 2
         AND NOT EXISTS (SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id)
      THEN ARRAY['autonomous','check-in','active']
    WHEN t.automation_tag = 'live-only' OR COALESCE(t.manual_degree, 5) >= 4
      THEN ARRAY['active']
    ELSE ARRAY['check-in','active']
  END AS fits_session_modes,
  pms_calibrated_minutes(t.est_minutes, t.kind) AS est_minutes_calibrated,
  CASE
    WHEN t.credits_reward > 0
     AND pms_calibrated_minutes(t.est_minutes, t.kind) IS NOT NULL
     AND pms_calibrated_minutes(t.est_minutes, t.kind) > 0
    THEN ROUND(t.credits_reward::numeric / pms_calibrated_minutes(t.est_minutes, t.kind), 3)
    ELSE NULL
  END AS credits_per_minute
FROM tasks t;

INSERT INTO schema_migrations (version) VALUES ('015_pms_estimation_calibration')
  ON CONFLICT (version) DO NOTHING;
