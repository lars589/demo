'use strict';

// modules/lifecycle/pollers/publish-reconciler.js — the loader poller entry for
// the confirmed→shipped auto-heal sweep (BV1.R86 / ADR 0093 §1).
//
// Was `publishReconciler.start()` / `.stop()` hardcoded in server.js; now a
// loader-started POLLER (contributes.pollers:["publish-reconciler"]), exactly the
// inversion the autonomy carve (routine-timers) made for its weekly timer. The
// loader's startModulePollers requires THIS file and calls start(deps) at boot /
// stop() at shutdown — failure-isolated, non-blocking. server.js no longer reaches
// into the lifecycle module to start it. The reconciler resolves the economy
// `reward` port for the cost sweep and its github-push/conflict-resolve siblings
// for the merge land — all module-internal.

const reconciler = require('../publish-reconciler');

module.exports = {
  start: (deps = {}) => reconciler.start(deps),
  stop: () => reconciler.stop(),
};
