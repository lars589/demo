# ADR 0072 — Bongos app ships Mac-signed + notarized first; Windows code signing deferred (reuse the Dev Box app's signing posture)

**Date:** 2026-06-20
**Context:** Bongos App `BONGOS-V1` / criterion C1 (signed-installable), task [#1296](https://example.com/builders#/task/1296) (`BV1.R01`). Builds on [ADR 0045](<redacted>.md) (the Dev Box desktop app) and [ADR 0004](0004-example-name-and-trademark-acceptance.md) (brand discipline). The bongos app forks the Dev Box app's Electron shell ([#1298](https://example.com/builders#/task/1298) `BV1.R03`), so it inherits that app's signing machinery; this ADR pins which parts it inherits now and which it defers.
**Status:** Accepted.
**Track:** `internal` (development system → the Cloud Bongos desktop app line; bongos succeeds the GDS after GDS-V4).

## Problem — an unsigned mic + screen app reads as hostile

Bongos is a floating OS toolbar that asks for **Screen Recording + Microphone** on first run. An unsigned app making those requests is treated as hostile by the OS: on macOS the permission grants may not persist across launches (and arm64 won't launch at all without at least an ad-hoc signature), and on Windows SmartScreen blocks the first launch outright. So a code-signing path is a launch gate, and `R01` exists to **decide** that path up front so packaging (`R15`/`R16`) is unblocked — not to leave it open until packaging time.

The Dev Box app already walked this road ([ADR 0045](<redacted>.md)):

- **macOS — solved and wired.** `.github/workflows/build-devbox-app.yml` carries an *inert-until-armed* Mac signing block: with no secrets it builds unsigned (ad-hoc); arming is purely adding repo secrets (`MAC_CSC_LINK` + `MAC_CSC_KEY_PASSWORD`, plus optional `MAC_NOTARIZE_*` for notarization) — no workflow edit. The secrets are bound to the cert env vars **only on the trusted `main` ref** (the SR-13/SR-14 hardening, [#993](https://example.com/builders#/task/993)) so a `claude/**` feature branch can never exfiltrate the Developer ID cert. A post-build `dmgbuild` re-package (task [#1235](https://example.com/builders#/task/1235)) preserves notarization while fixing the install-window backdrop.
- **Windows — never resolved.** Windows signing stays unwired pending a cert-vendor decision: blocker [#20](https://example.com/builders#/blocker/20) (Azure Trusted Signing vs. a traditional EV cert). Today Dev Box Windows users get the SmartScreen "More info → Run anyway" first-run friction, documented in the hall onboarding copy.

(The committed `devbox-app/electron-builder.yml` header comment still says "no Apple Developer ID… in the budget yet." That comment is **stale** — the CI workflow is the live truth, and the only signing blocker still open is the Windows-only [#20](https://example.com/builders#/blocker/20). Corrected as a side-note below.)

## Decision (owner — Lars)

**Ship the bongos app Mac-signed + notarized only at first; defer Windows code signing — the same posture as the Dev Box app.** Concretely:

1. **macOS — reuse the Dev Box app's signing identity verbatim.** No new Apple Developer ID, no separate cert. The bongos build workflow (authored in `R15`/`R16`) copies the Dev Box app's inert-until-armed Mac block — `CSC_LINK` / `CSC_KEY_PASSWORD` + `APPLE_ID` / `APPLE_APP_SPECIFIC_PASSWORD` / `APPLE_TEAM_ID`, **`main`-ref-gated** per SR-13/SR-14 — so the same Developer ID that signs Dev Box signs bongos. Sign **and** notarize for a Gatekeeper-clean first launch.
2. **Windows — defer, do not block V1.** Bongos does **not** acquire a Windows code-signing cert as part of `BONGOS-V1`. It ships either Mac-only at first, or with an **unsigned** Windows build carrying the same "More info → Run anyway" onboarding copy the Dev Box app uses. Windows signing rides the **existing** decision in blocker [#20](https://example.com/builders#/blocker/20) — there is no separate bongos Windows-cert decision and no new spend now.
3. **One cert decision, two apps.** When blocker [#20](https://example.com/builders#/blocker/20) resolves (Azure Trusted Signing vs. EV) it resolves for **both** apps at once — the absorbed Dev Box module and the bongos toolbar share the umbrella app's installer ([#1298](https://example.com/builders#/task/1298)), so Windows signing arms once for the whole umbrella.

This satisfies `R01`'s done-when: the Windows approach is decided (explicit interim "Mac-signed only" recorded here), and the Mac path is confirmed to reuse the existing Dev Box Apple Developer ID rather than minting a new one.

## Consequences

- **`R15` (electron-builder signing config) and `R16` (branded download + updater) inherit the Dev Box pattern, not a fresh design.** They copy the inert-until-armed Mac block and its `main`-ref-only secret gating verbatim into the umbrella build workflow. Re-deriving signing from scratch in those tasks is wasted work — point them at `.github/workflows/build-devbox-app.yml` and this ADR.
- **Budget: $0 new recurring cost from this decision.** It rides the Apple Developer ID already paid for Dev Box and explicitly declines a Windows cert for now (CLAUDE.md §4 — any new recurring cost needs the owner's go-ahead; this defers it).
- **Windows users see first-run friction until [#20](https://example.com/builders#/blocker/20) resolves.** Acceptable for V1: the early audience is Mac-first (the owner + the existing Dev Box builders), and the SmartScreen "Run anyway" copy is already written and proven for Dev Box.
- **The bongos app must not mint a second Apple Developer ID or duplicate the Mac signing block as a sibling.** Reuse is the rule — the umbrella app is one signed app ([#1298](https://example.com/builders#/task/1298)), one Developer ID, one notarization flow.
- **Side-note / cleanup, not in scope here:** `devbox-app/electron-builder.yml`'s "UNSIGNED for now — no Apple Developer ID" header comment contradicts the armed CI workflow and the closed-Apple / open-Windows blocker state. Worth a one-line fix under a Dev Box-scoped claim; flagged, not done here (this is a `decision` task touching `bongos-app/`, not `devbox-app/`).
