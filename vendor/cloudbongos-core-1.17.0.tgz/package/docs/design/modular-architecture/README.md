# Cloud Bongos — Modular Architecture (design research)

Five reports from the **2026-06-21 modular-architecture design session**, filed as durable markdown so they live in version control rather than as ephemeral Claude artifacts.

> **Status: pre-red-team draft.** These are research/design reports, not a decision record. A formal numbered ADR follows once they've been red-teamed. Filed under `docs/design/` (not `docs/adr/`) on purpose — the ADR numbering is in flux (0079→0081 collisions), so the number is assigned later on an up-to-date worktree.

| # | Doc | What it answers |
|---|-----|-----------------|
| 00 | [Research report](00-research-report.md) | Industry best practice on packaging, plugins, theming, and AI-agent scoping (cited) |
| 01 | [Architecture](01-architecture.md) | The concrete core+modules design; why not a rewrite; the migration path |
| 02 | [Module map](02-module-map.md) | Where the ~95k LOC live; how finely to cut the core; the decided roster |
| 03 | [Builder flows](03-builder-flows.md) | What the dev box can access; why the structure never blocks a builder |
| 04 | [Module lifecycle & maintenance](04-module-lifecycle.md) | How modules interact (seams) and stay healthy as code grows |

## The decided model (one paragraph)

A small **kernel** (auth, rank, db-pool, the loader, the seam registry, trust primitives, config/identity, analytics, the trusted publish path) plus **~16 modules** (lifecycle, economy, grading, memory, onboarding, ideas, builder-settings, sessions/BFG, autonomy/MAS, security, hall-UI, status-UI + game/art-pipeline/discord/dev-box). Modules **never import each other** — they interact through **kernel-mediated seams** (ports + events). Boundaries are held by **CI fitness functions** so the structure can't rot as it grows. It stays **single-package, single-process, no-bundler** — modularity is a separate axis from packaging/runtime/build. It is built via an incremental **strangler migration**, not a ground-up rewrite.

## How the boundaries were drawn

Not by intuition. The module lines come from a **`require()`-graph scan of all 111 files in `src/bongos`** (see [02](02-module-map.md)) — the kernel is confirmed by in-degree (auth 35, db 28, pool 24, _helpers 23, then a cliff), and the lifecycle cluster is confirmed by direct edges (`tasks → grader`, `tasks → github-push`, `tasks → ship-broadcast`).

## Provenance & confidence

- The research report (00) is **partial** — its synthesis step was cut by an org Claude spend limit; 12 claims passed full adversarial verification, the rest are sourced-but-not-triple-verified. It's a cited starting point, not an exhaustive survey.
- The architecture, map, flows, and lifecycle docs are **synthesis + codebase-grounded** (read at commit `cc8a5e0`).
- Related: memory `project-modular-architecture-scoping`. Builds on **ADR 0080** (project-extensible module system), **0062** (instance decoupling), **0061** (context layers), **0016** (trust boundary), **0049** (parallel-safety contract).
