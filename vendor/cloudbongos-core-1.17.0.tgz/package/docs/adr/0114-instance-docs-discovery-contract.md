# ADR 0114 — Instance docs-discovery contract (how an agent finds its hall + docs from config alone)

**Date:** 2026-07-04
**Status:** Accepted.
**Context:** [task 2005](https://builders.example.com#/task/2005) (BONGOS-V1, from the 2026-07-04 CLAUDE.md review, bullet 6). Companion to [ADR 0062](<redacted>.md) (core↔host split), [ADR 0109](<redacted>.md) (self-describing OpenAPI + hosted `/docs`), and [ADR 0029](<redacted>.md) (off-box status page).

## Problem

CLAUDE.md tells an agent to "read docs on your instance's builders' hall (`domains.buildersOrigin`)," but nothing *pins* how a fresh, self-hosted instance's agent reliably locates its doc surfaces. The pointer was one line of prose citing one config key — hand-waving, not a contract. A second instance standing up on its own domain needs to resolve "where are my hall, my rendered docs, my status page?" **from config alone, with no hard-coded `example` anywhere.** Today the pieces exist but were never named together as the discovery contract:

- `config/branding.json` `domains.{publicOrigin,buildersOrigin,statusOrigin}` — the config source of truth.
- `/docs` + `/docs/openapi.json` — the rendered API reference + machine spec ([ADR 0109](<redacted>.md)), served on the instance's own origin.
- `GET <publicOrigin>/api/bongos` (and the permanent `/api/gds` alias) — the machine-discovery index (task 1918), CORS-open + unauthenticated, which answered with `docs`/`openapi` pointers but **not** the hall or status origins.

## Decision

Pin a three-layer docs-discovery contract. Every layer is derivable from config or from a single unauthenticated call — no host is ever hard-coded.

1. **Config is the source of truth.** `config/branding.json` `domains` carries the surfaces:
   - `domains.buildersOrigin` — the **builders' hall**: the canonical doc-reading surface (task/idea/blocker refs render as working links; the primer + generated diagrams + repo docs render there).
   - `domains.publicOrigin` — the **instance origin**: `/docs` renders the API reference and `/docs/openapi.json` is the machine-readable OpenAPI 3.1 spec.
   - `domains.statusOrigin` — the **status page**: the off-box fallback for project state when the hall is down ([ADR 0029](<redacted>.md)), though it does not render full docs.
2. **The machine-discovery index is the zero-config entry point.** `GET <publicOrigin>/api/bongos` (and the permanent `/api/gds` alias) returns a small JSON map that now advertises the doc surfaces themselves — `hall`, `status`, and `public` origins alongside `docs`/`openapi`. An agent or client that knows only *one* origin (or reaches the API root by accident) can bootstrap every other doc surface from that single response, with no config file and no hard-coded host.
3. **Resolution order for an agent.** (a) Read `config/branding.json` `domains` when the checkout is present; (b) otherwise `GET <origin>/api/bongos` and read `hall`/`status`/`docs`; (c) the hall is the canonical doc surface, the status page the outage fallback, `/docs` the API reference. `github.com` is the code host only — never the doc-reading surface (a bare `#NNN` mis-autolinks there).

## Consequences

- **The discovery index gains `hall`/`status`/`public`** (`src/bongos/serve-internal.js`). This is the concrete "resolve with no hard-coded example" guarantee: the values come from `branding().domains`, so a second instance's index advertises *its* origins automatically.
- **`docs/branding-contract.md`** documents the docs-discovery contract so a fresh instance knows these `domains.*` fields are load-bearing, not decorative.
- **CLAUDE.md's preamble references this ADR** instead of hand-waving a single config key.
- **No new required config field** — the contract formalizes the existing `domains.{publicOrigin,buildersOrigin,statusOrigin}` keys. `buildersOrigin`/`statusOrigin` stay optional in the contract (an instance may ship without a hall/status surface); when absent the index returns `null` for that pointer and the agent falls back to `/docs` on `publicOrigin`.
- **Portability, not behavior.** No endpoint semantics change; the index adds fields (back-compatible). The [ADR 0016](<redacted>.md) trust boundary is untouched — the index names only public locations and remains unauthenticated.
