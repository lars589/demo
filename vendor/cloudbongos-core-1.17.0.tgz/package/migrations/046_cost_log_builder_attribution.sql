-- 046_cost_log_builder_attribution.sql — V3.R11 (#91): per-builder cost attribution.
--
-- Background
-- ----------
-- Until now, cost_log rows carried no builder identity. Spend was attributable
-- by task (when task_id was set) and by category, but the dashboard could not
-- show "who spent what." That was acceptable while a single shared Google AI
-- Studio key fed every builder's pipeline — there was nobody to attribute *to*.
--
-- V3.R11 (#91) flips that: each builder now registers their own Gemini key
-- during /builder-setup, and the art pipeline knows which builder is making
-- each call. This migration gives cost_log a place to record it.
--
-- Design choices
-- --------------
-- * Nullable column. Historical rows pre-date the feature; we must not
--   invalidate them. New writes are expected to populate it (the route auto-
--   fills from the authed builder when no body field is provided).
-- * ON DELETE SET NULL — if a builder row is ever deleted, the cost survives;
--   it just becomes attributed to "unknown" rather than vanishing.
-- * Index on (builder_id, recorded_at DESC) for the dashboard's per-builder
--   timeline query. The leading column is builder_id so the WHERE clause
--   selects a builder cheaply; the trailing recorded_at DESC matches the
--   "newest first" sort.
--
-- Acceptance
-- ----------
-- A fresh builder registering their key, running the art pipeline, and POSTing
-- to /api/gds/cost has their builder_id stamped onto each row. The public
-- /cost-summary endpoint exposes a by_builder aggregate that the status page
-- renders alongside the existing by_category and by_track splits.

ALTER TABLE cost_log
  ADD COLUMN IF NOT EXISTS builder_id bigint
    REFERENCES builders(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_cost_log_builder_recorded
  ON cost_log (builder_id, recorded_at DESC)
  WHERE builder_id IS NOT NULL;

INSERT INTO schema_migrations (version) VALUES ('046_cost_log_builder_attribution')
  ON CONFLICT (version) DO NOTHING;
