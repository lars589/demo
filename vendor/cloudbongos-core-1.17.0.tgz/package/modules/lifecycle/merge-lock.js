// Shared advisory mutex for the SINGLE shared `main` worktree.
// (task 1146 / ADR 0058: this comment is a needs_trust gate-surface change used to
//  verify the automatic gatekeeper auto-merges a trusted author's PR with no owner click.)
//
// Both ship.js's autoMerge() and the /merge-mode skill mutate the same main
// worktree (REPO_ROOT). #462 (criterion C4) added a lockfile so two concurrent
// SHIPS could no longer collide — but the lock lived inside ship.js, so
// /merge-mode (which mutates the same tree by hand) never participated. This
// module extracts the lock so BOTH surfaces share ONE mutex: ship-vs-ship,
// ship-vs-merge-mode, and merge-mode-vs-merge-mode are all serialized.
// (V3.R50 / #269, criterion C6.)
//
// The lock is a plain file at <repoRoot>/.git/otb-automerge.lock. We don't use
// flock(2): ships and merge runs happen on macOS, where flock over an
// iCloud-synced filesystem is unreliable, and the holder may be a short-lived
// CLI process (the manual /merge-mode case has no long-lived owner). The file
// records three lines:
//   line 1: holder pid  (0 for a manual/CLI hold with no long-lived process)
//   line 2: epoch-ms timestamp when acquired
//   line 3: mode  ('auto' | 'manual')
//
// Staleness / liveness — a held lock is reclaimable when:
//   - auto  : the holder pid is dead OR the stamp is older than AUTO_STALE_MS
//             (a crashed automated ship that never released).
//   - manual: only by time (MANUAL_STALE_MS). A manual hold has no stable pid
//             (the CLI process that wrote it has already exited), so we trust
//             the operator to release() and fall back to a generous timeout if
//             they walk away mid-merge.
//
// Back-compat: a two-line lockfile written by the pre-#269 ship.js (pid\nts) is
// read as mode='auto', so a ship mid-flight during the deploy of this change is
// not disrupted.
//
// ⚠️ SYNCHRONOUS / CLI-ONLY. acquire() busy-waits (up to waitMs) and the
// internal sleepSync() blocks the thread via Atomics.wait — by design, because
// the only callers are execSync-style CLI scripts (ship.js auto-merge, the
// merge-lock.js CLI) that have no event loop to yield to. **Do NOT import this
// module from an Express route handler or any code on the request path** — a
// blocking acquire would stall the Node event loop for the whole process. If a
// route ever needs to inspect the lock, add a non-blocking readLock()-only
// helper rather than calling acquire(). sleepSync is intentionally NOT exported
// for this reason.

const fs = require('node:fs');
const path = require('node:path');
const { execSync } = require('node:child_process');

const AUTO_STALE_MS = 10 * 60 * 1000; // crashed automated ship
const MANUAL_STALE_MS = 30 * 60 * 1000; // operator walked away mid-merge-mode
const INDEX_LOCK_GRACE_MS = 60 * 1000; // a git index.lock younger than this may be a LIVE op

function lockPath(repoRoot) {
  return path.join(repoRoot, '.git', 'otb-automerge.lock');
}

// Synchronous sleep without spawning a process (ship.js is execSync-style and
// has no event loop to yield to while it holds the merge critical section).
function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

function pidAlive(pid) {
  // pid <= 1 is never one of OUR holders: auto holds write process.pid (always
  // > 1) and manual holds write 0 (and are reclaimed by time, not liveness).
  // Rejecting pid 1 here also closes the theoretical case where a hand-crafted
  // lockfile names pid 1 (init/launchd, always alive → EPERM) to look
  // perpetually held; such a lock is now reclaimed immediately rather than
  // lingering until AUTO_STALE_MS.
  if (!Number.isInteger(pid) || pid <= 1) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return e.code === 'EPERM'; // EPERM: exists, not ours. ESRCH: dead.
  }
}

// Parse the lockfile into { pid, ts, mode } or null if absent/unreadable.
function readLock(repoRoot) {
  try {
    const [p, t, m] = fs.readFileSync(lockPath(repoRoot), 'utf8').split('\n');
    const pid = parseInt(p, 10);
    const ts = parseInt(t, 10) || 0;
    const mode = m && m.trim() === 'manual' ? 'manual' : 'auto';
    return { pid: Number.isFinite(pid) ? pid : NaN, ts, mode };
  } catch (_) {
    return null;
  }
}

// Repair the shared main worktree after reclaiming a STALE lock. The prior
// holder is, by definition of stale, dead or abandoned — and a holder that
// crashed mid-merge leaves wreckage the NEXT holder would otherwise inherit:
//   - an orphaned git `.git/index.lock` (every git write then fails with
//     "Another git process seems to be running"), and/or
//   - a half-applied merge (MERGE_HEAD + a dirty index full of staged changes)
//     that wedges `mainWorktreeBusy()` and `git merge --ff-only` for everyone.
// (Real incident 2026-06-01: a crashed /merge-mode run left 830 staged
// deletions + an orphaned index.lock, wedging the queue for 30 min.)
//
// This ONLY runs on the stale-reclaim path, so it never touches a live holder's
// tree. It is best-effort: every step is guarded so a repair hiccup can't block
// the reclaim. `runner` (execSync) and `now` are injectable for tests.
//
// Safety of `reset --hard origin/main`: REPO_ROOT is the throwaway shared main
// worktree that only ever holds `main` (all feature work lives in per-builder
// worktrees), and the dead holder's local merge was never pushed — so resetting
// to the fetched origin/main loses no committed, reachable work. Gated on being
// mid-merge or dirty to avoid gratuitous churn on a clean reclaim.
function recoverWorktree(repoRoot, { now = Date.now, runner = execSync } = {}) {
  const run = (cmd) =>
    runner(cmd, { cwd: repoRoot, stdio: ['ignore', 'pipe', 'ignore'], encoding: 'utf8' });
  const tryRun = (cmd) => {
    try { run(cmd); return true; } catch (_) { return false; }
  };

  // 1. Clear an ORPHANED git index.lock — but only if it's old enough that no
  //    live git process could still own it. A fresh lock means a live op
  //    (possibly a holder that just acquired after us); never yank that.
  try {
    const lk = path.join(repoRoot, '.git', 'index.lock');
    const st = fs.statSync(lk); // throws ENOENT when absent → nothing to clear
    if (now() - st.mtimeMs > INDEX_LOCK_GRACE_MS) fs.unlinkSync(lk);
  } catch (_) {
    /* absent, racing a live op, or unreadable — leave it */
  }

  // 2. Abort a half-applied merge and drop the dead holder's staged changes so
  //    the next holder starts from a clean origin/main.
  let midMerge = false;
  try { run('git rev-parse -q --verify MERGE_HEAD'); midMerge = true; } catch (_) { /* not mid-merge */ }
  let dirty = false;
  try { dirty = run('git status --porcelain').trim().length > 0; } catch (_) { /* unknown — treat as clean */ }
  if (midMerge) tryRun('git merge --abort');
  if (midMerge || dirty) {
    tryRun('git fetch origin main');
    tryRun('git reset --hard origin/main');
  }
}

// Is a held lock reclaimable right now? `now` is injectable for tests.
function isStale(rec, now = Date.now()) {
  if (!rec) return true;
  const window = rec.mode === 'manual' ? MANUAL_STALE_MS : AUTO_STALE_MS;
  if (now - rec.ts > window) return true;
  if (rec.mode === 'manual') return false; // time-based only — no stable pid
  return !pidAlive(rec.pid);
}

// Acquire the exclusive merge lock. Returns true (caller MUST release() on
// every exit path) or false if a live holder keeps it past the wait window
// (caller bails to /merge-mode). Reclaims a stale lock automatically.
//
// opts:
//   waitMs : how long to wait for a live holder before giving up (default 30s)
//   mode   : 'auto' (a process-backed ship) | 'manual' (a CLI/operator hold)
//   pid    : holder pid to record (default process.pid; pass 0 for manual)
//   sleep  : injectable sleeper (tests)
//   now    : injectable clock (tests)
function acquire(repoRoot, opts = {}) {
  const {
    waitMs = 30000,
    mode = 'auto',
    pid = process.pid,
    sleep = sleepSync,
    now = Date.now,
    recover = recoverWorktree,
  } = opts;
  const p = lockPath(repoRoot);
  const deadline = now() + waitMs;
  for (;;) {
    try {
      const fd = fs.openSync(p, 'wx'); // create-exclusive; EEXIST if held
      fs.writeSync(fd, `${pid}\n${now()}\n${mode}\n`);
      fs.closeSync(fd);
      return true;
    } catch (e) {
      if (e.code !== 'EEXIST') throw e;
      const rec = readLock(repoRoot);
      if (isStale(rec, now())) {
        let reclaimed = false;
        try {
          fs.unlinkSync(p);
          reclaimed = true;
        } catch (_) {
          /* someone else reclaimed it first — retry */
        }
        // Only repair the worktree if WE won the unlink — otherwise a freshly
        // arrived live holder now owns it and its (clean) tree must be left be.
        if (reclaimed) {
          try { recover(repoRoot, { now }); } catch (_) { /* best-effort */ }
        }
        continue; // reclaimed — retry the create immediately
      }
      if (now() >= deadline) return false; // live holder; gave up waiting
      sleep(2000);
    }
  }
}

// Release the lock. By default only the recording process (auto holds) or any
// caller of a manual hold may remove it — defensive against a stolen-stale
// race where we reclaimed someone else's lock and they later try to release.
//   pid   : the releasing process (default process.pid)
//   force : remove regardless of owner (emergency operator escape hatch)
function release(repoRoot, opts = {}) {
  const { pid = process.pid, force = false } = opts;
  try {
    const rec = readLock(repoRoot);
    if (!rec) return;
    if (force || rec.mode === 'manual' || rec.pid === pid) {
      fs.unlinkSync(lockPath(repoRoot));
    }
  } catch (_) {
    /* already gone */
  }
}

// ---------- the cross-machine tier: server-side merge lease (task 585 / idea 124) ----------
//
// Everything above is machine-LOCAL: a filesystem mutex on ONE checkout of main. When builders
// ship from DIFFERENT physical machines (each with its own checkout), that lock can't serialize
// them. The cross-machine tier is a TTL'd DB lease (src/bongos/db.js acquireMergeLease /
// releaseMergeLease / mergeLeaseStatus), handed out by the GDS API at merge time. This helper is
// the composition point: a multi-machine ship takes the server lease FIRST (one machine merges at
// a time), then the local file lock above.
//
// async + DEPENDENCY-INJECTED `lease` backend, deliberately: this module must stay require-able by
// the SYNC CLI path (ship.js, the merge-lock CLI) WITHOUT pulling in db.js + a pg pool, and the
// server lease only matters for server-mediated / multi-machine ships. The caller injects
//   lease = { acquire({key,holder,ttlSeconds}) -> {acquired,holder,expires_at}, release({key,holder}) }
// (src/bongos/db.js satisfies this shape). With no backend, runs the fn directly — the file lock still
// serializes the single-machine case. Throws MERGE_LEASE_HELD if another machine holds the lease.
async function withServerMergeLease(holder, fn, { lease, key = 'main', ttlSeconds = 600 } = {}) {
  if (!lease || typeof lease.acquire !== 'function') return fn();
  const res = await lease.acquire({ key, holder, ttlSeconds });
  if (!res || !res.acquired) {
    const err = new Error(`merge lease for '${key}' held by ${res?.holder ?? 'another machine'} until ${res?.expires_at ?? '?'}`);
    err.code = 'MERGE_LEASE_HELD';
    throw err;
  }
  try {
    return await fn();
  } finally {
    try { await lease.release({ key, holder }); } catch (_) { /* TTL reclaims it — best-effort */ }
  }
}

module.exports = {
  AUTO_STALE_MS,
  MANUAL_STALE_MS,
  INDEX_LOCK_GRACE_MS,
  lockPath,
  pidAlive,
  readLock,
  isStale,
  recoverWorktree,
  acquire,
  release,
  withServerMergeLease,
};
