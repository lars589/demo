# ADR 0048 — "Works in Progress" information-architecture split: work board owns it, status mirrors a thin slice

- **Status:** Accepted
- **Date:** 2026-06-12
- **Task:** [#938](https://example.com/builders#/task/938)
- **Supersedes presentation choices in:** the versions render on `public-status/` (PMS-V2 [#41](https://example.com/builders#/task/41) done-when checklist; Phase 5 / [#94](https://example.com/builders#/task/94) three-segment bar)

## Context

Two surfaces independently rendered a "Works in Progress" section, both reading the same public `/api/gds/public/progress` feed:

- **status.example.com** (`public-status/`) — a public, no-auth, off-box mirror (ADR 0029). It showed every version with name, track tag, a 3-segment lifecycle bar, a "% complete" line, and an expandable done-when criteria checklist.
- **The builders' work board** (`public-builders/work.html`, `builders.example.com/work`) — sign-in-gated. Its "Works in Progress" section (`#wip-scroll`) was authored to be the source of truth (live in-flight claims + the same bars) **but the section carried a `hidden` attribute that no code ever removed**, so it never displayed — the page jumped straight to the claimable queue.

Lars asked that the work board become the canonical home of Works in Progress, and that the public status page keep only a thin mirror: the **active** endeavours, **title + short description only** — "as we are saying it should stay there."

## Decision

1. **The work board is the canonical home.** Unhide `#wip-scroll`. It shows, for **every** version: title, short description, the 3-segment progress bar, and the done-when criteria checklist — plus the live "borne by hand right now" in-flight table. (Fixing the never-unhidden bug is part of this.)

2. **The public status page is a thin mirror.** It shows only **active** endeavours, each as **title + short description**. No bars, no counts, no criteria. The now-dead version-bar and done-when CSS/JS on `public-status/` is removed.

3. **"Active" = underway, not past, and actually started.** A version qualifies when `status NOT IN ('shipped','frozen')` **and** it has at least one `done_when_criteria` seeded (`criteria_count > 0`). The criteria-count test is what excludes a *future placeholder* — e.g. the next-version stub created at version close (GDS-V4 today), which has no criteria yet — without needing a new schema flag. When that version is scoped in a planning session and gains criteria, it appears on the public board automatically.

4. **"Short description" reuses `versions.done_when`.** No new column. `done_when` is the senate-voice narrative of what a version *is*; the criteria checklist (a separate `done_when_criteria` table) is "their criteria." The two map cleanly onto "short description" and "criteria," so no data model change was needed. `db.versionProgress()` now also returns `done_when` and `criteria_count` (a `db.js`-only join — no migration).

## Consequences

- The public page no longer leaks per-version progress detail; it reads as a short, dignified list of what the city is building. Builders who want the full picture (bars, criteria, in-flight) go to the work board.
- The two surfaces still cannot share rendering code: `public-status/` is copied byte-identical to the off-box GitHub Pages mirror (ADR 0029) and cannot import from `public-builders/`. They remain parallel implementations of a shared **data** contract (`/api/gds/public/progress` + `/versions/:id/done-when`).
- A version with an empty `done_when` shows as a bare title on both surfaces. V2 and V3 had empty `done_when`; short descriptions were written for them as part of [#938](https://example.com/builders#/task/938).
- The "future placeholder" rule is conventional, not enforced: a version is hidden from the public board precisely while it has zero criteria. This is the desired lifecycle (scope it → it shows), but it does mean seeding a single criterion makes a version public.
