# ADR 0128 — Provisioning runner privilege + DB-auth model (`PROVISION_SUDO`)

**Status:** Accepted — implemented 2026-07-05 (task [#2066](https://example.com/builders#/task/2066), BONGOS-V1, goal 35 / criterion `project-creation-flow`).

## Context

[ADR 0111](<redacted>.md) built `scripts/gds/provision.js` — the control-plane runner that drains `provisioning_intents` and composes the [cloudbongos-standup](../recipes/cloudbongos-standup.md) runbook (createdb → GDS-only migrate → per-instance `/etc/<slug>/web.env` → systemd unit → per-instance Caddy snippet → `/healthz`). It was written injectable + dry-run-default and unit-tested, **but never run end-to-end** — every existing co-located instance (`emersonian-circles`, the vanity doors) was hand-wired by an operator. The 2026-07-05 first real greenfield standup attempt ([#2053](https://example.com/builders#/task/2053)–[#2056](https://example.com/builders#/task/2056)) surfaced three ops gaps. Two were resolved on-box (Cloudflare token scope → [ADR 0126](<redacted>.md); the Caddy on-demand-TLS global that the live `/etc/caddy/Caddyfile` lacked). This ADR is the third, load-bearing one.

`provision-intent-runner.service` runs as **`User=lars`** (a non-root user). But every mutating step assumed a privilege the runner does not have when driven headlessly:

- **`/etc` writes** — `web.env` (`/etc/<slug>/`), the systemd unit (`/etc/systemd/system/`), and the Caddy snippet (`/etc/caddy/sites/`) went through a bare `fs.writeFileSync`. Confirmed on the box: `lars` cannot write under `/etc` (`mkdir /etc/_provtest` → `EACCES`).
- **`systemctl` / `caddy` reloads** — `daemon-reload`, `enable --now`, `reload caddy`, `disable --now` ran without `sudo`.
- **`createdb` + `migrate`** — both authenticate to Postgres by **peer auth as the running user**. On this box `lars` is *not* a usable PG role (the app connects via `DATABASE_URL`), so `createdb <slug>` and `migrate.sh`'s `psql` both fail.

Two things additionally made a naive "just add `sudo`" fix silently fail: the unit set **`NoNewPrivileges=true`** (which sets `PR_SET_NO_NEW_PRIVS` and *blocks the setuid `sudo` binary from escalating at all*), and `sudo` resets the environment (so a bare `sudo -u postgres PGDATABASE=x ./migrate.sh` would have `sudo` parse `PGDATABASE=x` as a command).

The whole point is that this runner must NOT bake operator identity into behavior ([ADR 0016](<redacted>.md)), tests must stay hermetic (no shell/DB/network), and the same code drives co-tenant, standalone, and (via cloud-init) dedicated shapes.

## Decision

Add a single config knob, **`PROVISION_SUDO=1`** (alias `PROVISION_PRIVILEGED=1`), read once into `CONFIG.privileged`. **Default OFF** preserves the exact current behavior (bare commands, direct `fs` writes) — so tests, a root context, and the co-tenant-legacy path are byte-for-byte unaffected. When ON, exactly the privileged steps escalate, and **dry-run still logs the exact command** either way:

- **`/etc` writes** → the body is staged in a temp file (`os.tmpdir()`, lars-writable) and placed atomically with **`sudo install -D -m <mode> <tmp> <dest>`** (`-D` creates the parent dir, e.g. `/etc/<slug>/`; `-m` sets the mode). The install runs through the *same* injected `exec`, so it shares the dry-run/apply + logging path. `makeWriteFile` escalates only when a call opts in with `{ sudo: true }` — the three `/etc` destinations do; the scaffold's temp/`.gitignore` writes (under `/tmp` and `/srv/<slug>`) stay direct.
- **`systemctl` / `rm` under `/etc`** → `sudo`-prefixed at the call site (`provisionInstance` + `teardownInstance`).
- **`createdb` + `migrate`** → run as the **postgres** OS user (`sudo -u postgres …`), which peer-auths as the PG superuser (the Ubuntu default) — so the runner never needs `lars` to be a PG role. `migrate` passes its env via `env PGDATABASE=… MEDUSA_GDS_ONLY=1` and runs the script via `bash …` so the vars survive `sudo`'s env reset. Applies to both the co-tenant (`migrateCmd`) and standalone (`standaloneMigrateCmd`) legs.

`infra/provision-intent-runner.service` is updated to make the model operational: **`Environment=PROVISION_SUDO=1`** turns the knob on for the deployed runner, and **`NoNewPrivileges=false`** (with an explanatory comment) is required — a `true` value silently defeats every `sudo` above. `PrivateTmp=true` stays (the `sudo install` temp files live in the service's private `/tmp`, which its sudo children share).

**Preconditions** (operational, documented — the same class as "the runner holds the DO/CF tokens"):

1. The runner's user has **passwordless sudo** on the control-plane box (true on `REDACTED_IP`).
2. The checkout `migrate` runs from must be **readable by the `postgres` OS user** (on `REDACTED_IP` the standalone base is `/srv/cloudbongos`, world-traversable — *not* under a `700` home).

## Consequences

- **Goal-35 automation can complete end-to-end** — this was the blocker for the real greenfield standup ([#2056](https://example.com/builders#/task/2056)) and criterion `project-creation-flow`.
- **No blast radius when off.** The knob defaults false; all 30 pre-existing unit tests stay green, and any non-runner invocation (a CLI dry-run, a root context) is unchanged. 8 new tests pin both the escalated command shapes (`sudo -u postgres createdb`, `env`+`bash` migrate, `sudo install -D -m`, `sudo systemctl`) and the *absence* of any `sudo` in the default path.
- **The runner is intentionally less sandboxed** (`NoNewPrivileges=false`, sudo enabled). Accepted: this runner is already the sole holder of the DO/Cloudflare tokens and performs inherently privileged control-plane ops; least-privilege here means *explicit, per-step* `sudo` (not running the whole process as root).
- **The dedicated-droplet cloud-init path is deliberately unchanged** (`dedicatedUserData`). It runs as root on a fresh droplet — a different privilege + file-perms model — and is out of the co-tenant/standalone scope this task exercised; escalating it is a separate change.
- **Follow-ups noted from the standup:** the live `/etc/caddy/Caddyfile` drifts from `infra/Caddyfile` with no auto-sync (a deploy-time reconcile is worth considering); the migrate-as-postgres readable-checkout precondition should be asserted by the box provisioning, not just documented.

## Alternatives considered

- **Grant `lars` a PG login role + writable `/etc`.** Rejected: non-portable per-box setup, and it weakens the trust boundary — the runner shouldn't *own* `/etc` or be a standing PG superuser; `sudo -u postgres` is scoped to the two DB commands.
- **Run the whole runner as root** (`User=root`). Rejected: over-privileged for the many non-privileged steps (git, npm, node, healthz, the DNS hook). Per-step `sudo` keeps the default footprint small and every escalation greppable.
- **Do createdb/migrate via the app `DATABASE_URL` connection** instead of `sudo -u postgres`. A valid option the task description named, and one an instance may adopt — but the runner doesn't hold the app DB creds today and the standup env uses peer auth, so `sudo -u postgres` is the portable default. Left open for a future instance that wires DB creds into the runner's box.env.
