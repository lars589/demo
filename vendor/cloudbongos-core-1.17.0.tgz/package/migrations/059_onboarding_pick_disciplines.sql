-- 059_onboarding_pick_disciplines.sql — 2026-05-30: reshape the onboarding path.
--
-- Two changes to the onboarding state machine that migration 045 established:
--
--   1. Remove 'first_vote_received'. Gating graduation on a peer upvote is too
--      much to ask of a brand-new builder — they can graduate before anyone
--      has had a chance to vote on their work. The stage is dropped from the
--      allowed-stage set.
--
--   2. Add 'pick_disciplines'. New builders now choose the kind of work they
--      want (creative / engineering / both) as an explicit onboarding step,
--      wired to the existing builders.preferred_disciplines column (migration
--      027). The application layer (src/bongos/onboarding-state.js STAGES) places
--      it after 'primer_read' and before 'first_start' so the choice is made
--      before the builder surveys the works on offer.
--
-- The DB only validates enum membership of current_stage; ordering lives in
-- the app layer. So this migration just swaps the CHECK constraint's allowed
-- set and re-homes any rows currently parked at the removed stage.
--
-- Grandfathering: a builder sitting at current_stage='first_vote_received' has
-- already cleared every stage that mattered in the old model (auth → ship).
-- Rather than re-prompt them through the reshaped path, we promote them
-- straight to 'graduated' and stamp completed_at. completed_stages[] is an
-- audit array (not CHECK-constrained per element), so the lingering
-- 'first_vote_received' entry there is harmless and left as-is.
--
-- Idempotent: safe to re-run.

BEGIN;

-- 1. Re-home rows parked at the removed stage BEFORE swapping the constraint,
--    or the new CHECK would reject them.
UPDATE builder_onboarding_state
   SET current_stage = 'graduated',
       completed_at  = COALESCE(completed_at, now())
 WHERE current_stage = 'first_vote_received';

-- 2. Swap the stage enum: drop the old constraint (if present) and add the new
--    one. Names match migration 045 so re-running is clean.
ALTER TABLE builder_onboarding_state
  DROP CONSTRAINT IF EXISTS builder_onboarding_state_stage_enum;

ALTER TABLE builder_onboarding_state
  ADD CONSTRAINT builder_onboarding_state_stage_enum
  CHECK (current_stage IN (
    'auth_complete',
    'primer_read',
    'pick_disciplines',
    'first_start',
    'first_claim',
    'first_ship',
    'graduated'
  ));

INSERT INTO schema_migrations (version) VALUES ('059_onboarding_pick_disciplines')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
