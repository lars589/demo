-- Migration 112 — drop the product|internal track CHECK on versions (ADR 0062 §3/§5, task 1191).
--
-- The track taxonomy is now INSTANCE CONFIG (config/branding.json "tracks"), validated in the API
-- (src/bongos/routes/tasks.js validTracks()), not a hardcoded 2-value DB constraint. The column stays
-- NOT NULL — a version still HAS a track — but any value the instance configures is allowed.
--
-- Live prod unaffected: existing 'product'/'internal' rows stay valid; this only LOOSENS. The drop
-- is name-independent (finds the track CHECK by its definition) so it works regardless of the
-- auto-generated constraint name, and is a no-op if it was already dropped.

DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT conname
      FROM pg_constraint
     WHERE conrelid = 'versions'::regclass
       AND contype = 'c'
       AND pg_get_constraintdef(oid) ILIKE '%track%'
  LOOP
    EXECUTE format('ALTER TABLE versions DROP CONSTRAINT %I', r.conname);
  END LOOP;
END $$;

INSERT INTO schema_migrations (version) VALUES ('112_drop_track_check') ON CONFLICT DO NOTHING;
