# ADR 0056 — Version-control the prod deploy script as a reviewable mirror, and retry the post-restart healthcheck

**Date:** 2026-06-13
**Context:** GDS, task [#1026](https://example.com/builders#/task/1026) (follow-up to [#1025](https://example.com/builders#/task/1025)). Builds on [ADR 0042](<redacted>.md) (ci deploy mode — `deploy-prod.yml` SSHes the droplet's `~/deploy.sh`) and [ADR 0043](<redacted>.md) (the forced-command lock on the deploy key).
**Status:** Accepted.
**Track:** `internal` (development system / deploy pipeline).

## Problem

On 2026-06-13, `deploy-prod` run 27468951859 (merge `447a58de`) reported **failure** — `Process completed with exit code 7`, immediately after `==> service: active`. The deploy had actually **succeeded** (live `/version` + external `/healthz` confirmed prod on the new commit). The cause: the in-script healthcheck in the droplet's `~/deploy.sh` was

```sh
sudo systemctl restart example
sleep 1
ACTIVE=$(systemctl is-active example)   # systemd "active" ≠ port bound
...
CODE=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:3000/healthz)
[ "$CODE" = "200" ] || exit 1
```

`systemctl restart` returns once systemd considers the unit *active*, but the Node process may not have bound `127.0.0.1:3000` yet. A fixed `sleep 1` + a **single** curl raced that bind. When curl couldn't connect it exited 7, and under `set -e` the **command substitution itself** aborted the script — *before* the `==> /healthz:` line even printed. Exit 7 (curl "failed to connect") propagated to the SSH caller, so the Actions step went red.

Two compounding issues:

1. **A false failure on a healthy deploy.** In `ci` mode ([ADR 0042](<redacted>.md)) `ship.js pollCiDeploy` / `publish-status` reads `conclusion=failure` and **cannot auto-advance `confirmed → shipped`** — every ci ship that hits the race needs a manual `POST /tasks/:id/ship` (had to for [#1025](https://example.com/builders#/task/1025)).
2. **The authoritative deploy script lived only on the droplet.** Prod's `~/deploy.sh` was hand-maintained at `/home/lars/deploy.sh`, un-versioned and un-reviewed — which is exactly why this race went unnoticed. (Staging's analogue, `scripts/deploy/deploy-staging.sh`, *is* in the repo and installed by `deploy-staging.yml` — but it carried the **same** single-curl bug, just manifesting as a clean `fail` rather than exit 7 because its `if ! curl … | grep` form suppresses `set -e`.)

## Decision

### 1. Retry the post-restart healthcheck with short backoff

Poll localhost `/healthz` up to **15× at 1s** before concluding failure (matching the cadence of `ship.js pollCiDeploy`). The load-bearing detail is `… ) || CODE=000`, which keeps a connection failure from tripping `set -e` so a slow bind **retries** instead of dying on the first miss; `--max-time 5` bounds a hang; a real failure still exits 1 with the last 30 journal lines. Applied to **both** the prod script and `scripts/deploy/deploy-staging.sh`.

### 2. Mirror the prod deploy script in the repo (but do NOT auto-install it)

`scripts/deploy/deploy-prod.sh` is now the **version-controlled source-of-truth mirror** of `/home/lars/deploy.sh` — byte-faithful, so `diff <(ssh droplet cat deploy.sh) scripts/deploy/deploy-prod.sh` is empty. This makes the authoritative deploy logic reviewable + diffable and stops the silent drift that hid this bug.

It is **not** auto-scp'd onto the droplet the way `deploy-staging.yml` installs `deploy-staging.sh`, and that asymmetry is deliberate: the prod CI deploy key (`otb-ci-deploy-prod`) is **forced-command-locked** in the droplet's `~/.ssh/authorized_keys` —
`command="/home/lars/deploy.sh",no-pty,no-agent-forwarding,no-port-forwarding,no-X11-forwarding` ([ADR 0042](<redacted>.md)/[0043](<redacted>.md)). That lock means the CI runner can **only** trigger a deploy, never run `scp` or any other command — a trust-boundary control we will **not** weaken just to auto-sync a script. So prod stays hand-installed by an operator (with a non-forced key) whenever the mirror changes:

```sh
scp scripts/deploy/deploy-prod.sh lars@REDACTED_IP:deploy.sh
```

The mirror's header documents this install contract.

## Consequences

- **A slow service bind no longer fails a successful prod deploy** — ci ships auto-advance `confirmed → shipped` without a manual `POST /tasks/:id/ship`.
- **The prod deploy script is reviewable in the repo** for the first time; the forced-command control is preserved intact.
- **One manual step remains:** the mirror is the source of truth but is not auto-installed; an operator must reinstall it on change (loud `diff` makes drift visible). Wiring a safe auto-install for prod (e.g. a tightly-scoped second key, or a server-mediated path) is left as a future improvement — out of scope for this bugfix.
- `provision-staging.sh` has the same single-curl pattern but is a one-time, human-supervised step (not a per-deploy CI hot path); left unchanged, noted as a possible follow-up.

## Verification

Faithful copies of the new loop, exercised three ways:

- **Dead port:** retries then exits **1** cleanly (no exit 7) — proves the `set -e` safety.
- **Live prod port (on the droplet):** 200 on attempt 1, exit 0.
- **Slow bind (port binds mid-loop):** retries through the connection failures, catches 200 on attempt 5, exit 0 — the exact incident class.

The fixed script was installed to the droplet (atomic rename; prior version backed up to `~/deploy.sh.bak-task1026`), parses cleanly there, and is byte-identical to the repo mirror.
