# ADR 0020 — Security model — public stub (full ADR is server-side)

**Date:** 2026-05-28
**Context:** Task [#287](https://example.com/builders#/task/287) (V3.R68), GDS-V3 criterion C9. Companion to [ADR 0019](<redacted>.md) (bounty table), [ADR 0018](<redacted>.md) (rank model), [ADR 0016](<redacted>.md) (server-enforced trust boundary).
**Status:** Accepted.

## Problem

A security ADR worth writing is a security ADR worth attacking. The threat model — every authenticated surface, every privileged write, every assumption the server-enforced trust boundary leans on, and the specific defenses each leg relies on — is the most attacker-useful document in the project. Committing the full version to the public repo would hand a roadmap to anyone clipping the project.

But we *also* need this document to exist and be readable by trusted builders (Archon, Metic) — otherwise the system has no shared model of how it defends itself, and every new privileged route ends up reinventing the threat-list ad hoc. The red-team bounty (criterion C9) only makes sense if Metics know roughly where the surface is.

We've already adopted [ADR 0016](<redacted>.md): authority lives on the server, not in the repo. The same logic applies to the security ADR itself — its content should live where its enforcement does.

## Decision

The **full security ADR is server-side**, served by a Metic+-gated endpoint and stored *outside this repo*. This file is the **public stub**: enough framing that a reader (or future builder) understands the structure and knows where to look, but with no specifics an attacker could weaponize.

### What lives where

| Surface | Where | Who reads it |
|---|---|---|
| Public stub (this file) | `docs/adr/<redacted>.md`, in the repo | anyone with the repo |
| Full security ADR | A markdown file on the droplet at the path named by `GDS_SECURITY_ADR_PATH` (recommended: `/etc/example/security-adr.md`, owned by the deploy user, `chmod 600`) | the server process, on read; Metic+ via API |
| Public read endpoint | none | — |
| Authenticated read endpoint | `GET /api/gds/security/adr` — `requireBuilder` + `requireRank('metic','archon')` — returns the markdown body verbatim under `{ adr_md, source: <path>, fetched_at }` | Metic, Archon |
| Missing-file handling | If `GDS_SECURITY_ADR_PATH` is unset or the file is unreadable, the endpoint returns `404 { error: 'security_adr_not_provisioned', hint: '…' }` with the same rank gate in front (so existence-or-not isn't leaked to a Xenos) | — |

### What's in the full ADR (categories, not contents)

The full ADR is structured as:

1. **Trust boundary mechanics** — the actual implementation of [ADR 0016](<redacted>.md) per route: which routes are gated, by what rank, where the rank read lives in the request lifecycle, and what fails closed.
2. **Threat model** — the set of attackers we model (sandboxed builder, malicious Metic, leaked GitHub OAuth, supply-chain compromise, lost laptop) and what each can and cannot do under the current design.
3. **Defense-in-depth inventory** — per privileged surface, the specific layers in front of it (rank check + audit log + rate limit + input validation + content TTL + …) and why each layer was chosen. This is the section that would most directly aid an attacker.
4. **Known weaknesses** — the specific places where a defense is thinner than we'd like, with the reasons we haven't fixed them yet (deferred to a later version, cost/benefit, etc.). Highest sensitivity.
5. **Red-team bounty alignment** — how a confirmed vulnerability_report maps onto the table in [ADR 0019](<redacted>.md), where the auto-confirmation path lives (R67/R68), and which surfaces are explicit invitations vs. out-of-scope (e.g. droplet-host vulns vs. application vulns).

Each section is updated when the underlying mechanism changes. The full ADR is the *living* document; this stub is the *pointer*.

### Why not just chmod the repo file?

The Example repo is on GitHub. Marking a single file private is awkward (git history exposes it; collaborators see everything). The cleanest available primitive is "the file is on the droplet, the server reads it, the API gates access." That collapses to the same trust boundary [ADR 0016](<redacted>.md) already enforces for everything else.

### This is not security-through-obscurity

The defense doesn't depend on the ADR's secrecy. Every protection mentioned in the full ADR is independently enforced in code (rank middleware, audit log, input validation, etc.). Withholding the document raises the cost of an attacker's reconnaissance — it doesn't *create* the defense. The bounty table ([ADR 0019](<redacted>.md)) names the gain for the attacker who reverse-engineers it anyway: a high-severity finding pays out 1000 drachmae. The system *wants* serious red-teamers; what it doesn't want is to hand them the map for free.

## Alternatives considered

- **Commit the full ADR to the repo.** Simplest. Rejected for the reason above: highest-leverage document for an attacker.
- **Encrypted file in the repo (e.g. age-encrypted blob).** Possible, but key-management overhead for every Metic + the encrypted blob is still public. The trust boundary already gives us "authenticated reads," so reusing it is cheaper.
- **Private companion repo.** Considered. Adds a second-repo coordination problem (every Metic needs access; secrets-in-repo policy needs to cover two repos; CI doesn't see it). The droplet-file approach concentrates surface area without sacrificing access.
- **Notion/Google Doc.** Rejected for the same reason all project state lives in the GDS + git: third-party SaaS dependencies for canonical authority drift over time. The droplet is already the source of truth for everything else server-side.

## Consequences

- The full security ADR exists at `GDS_SECURITY_ADR_PATH` on the droplet, not in the repo. Provisioning is a one-time Archon action; the file persists across deploys (it lives outside the repo working tree).
- New builders see the public stub (this file) when reading the ADR index. The stub tells them how to read the full ADR once promoted to Metic+.
- Any change to the *real* defenses (new gated route, new redaction rule, new rate-limit knob) updates the full ADR on the droplet. Significant structural changes (new threat-model attacker, new defense category) also update this public stub.
- The `GET /api/gds/security/adr` endpoint exists *now* (V3.R68 / [#287](https://example.com/builders#/task/287)) but returns the not-provisioned placeholder until an Archon writes the file. That's intentional — the endpoint is the contract, the file is the content.
- A Xenos hitting the endpoint sees `403 rank_forbidden` whether or not the file is provisioned — the rank gate runs before the file-existence check, so existence of the document isn't leaked downward.

## Cross-references

- [ADR 0016](<redacted>.md) — the server-enforced trust boundary the security model rests on.
- [ADR 0018](<redacted>.md) — the three-rank model whose gates the security ADR documents.
- [ADR 0019](<redacted>.md) — the payout table a confirmed vulnerability_report maps onto.
- Migration [<redacted>.sql](../../migrations/<redacted>.sql) — the report intake table (R63).
- Migration [033_audit_log.sql](../../migrations/033_audit_log.sql) — the audit ledger every privileged write lands in (R35).
