# `docs/recipes/` — long-form operational recipes

> **Renamed from `learnings/` in Phase 2b** (2026-05-10). The folder used to hold a mix of long-form guides and short-form rules; the dual-write with the GDS `learnings` table made the split confusing. Now: this folder = long-form recipes (multi-page operational guides); the DB `learnings` table = short-form per-rule learnings (rule + why + how-to-apply).

This folder holds **things we have already discovered the hard way and need to write up at length**. Read the relevant file before you do similar work, and you will not repeat the discovery.

A "recipe" is not a limitation (something the project cannot do). It is a multi-page operational guide for a workflow that's known to be tricky — the pixel-art pipeline, ops gotchas, deployment runbooks. For a one-paragraph rule like "TextEdit defaults to RTF — pass via `textutil -convert txt`," capture it via `node scripts/gds/learning-capture.js` instead; it goes into the DB and surfaces automatically on `/builder-claim` for relevant tasks.

## What goes here

- Ops gotchas — non-obvious behavior of a tool or service we use (Postgres, Caddy, Cloudflare, Colyseus, the Mac toolchain, etc.)
- Recovery recipes — when X breaks in Y way, here is what to do
- Sequencing notes — when running operation A, do B first, otherwise C happens
- Tool-version traps — pinned versions and *why* they are pinned

## What does not go here

- Architectural decisions → [`docs/adr/`](../../docs/adr/)
- Things the project cannot do → [`limitations/`](../../limitations/)
- Things stuck on the prompter's input → [`blockers/`](../../blockers/)

## Read order while working

If you are about to deploy, edit infra, touch the database, or change the runtime stack — open the relevant file in this folder first. Each file is organized by topic so you can skim to the section you need.

## When to add a new learning

Anytime you spend more than ~10 minutes diagnosing something that turned out to have a non-obvious cause, write it down here. The cost of a 5-minute write-up is much less than the cost of the *next* session re-discovering the same thing.

A good learning entry has:

- **Symptom** — what looked broken
- **Root cause** — what was actually happening
- **Fix** — exact steps to recover
- **Why it bites** — what about the tool's defaults makes this happen, so future-you can spot the pattern
