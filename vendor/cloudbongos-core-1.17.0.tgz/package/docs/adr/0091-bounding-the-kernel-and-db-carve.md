# ADR 0091 — Bounding the kernel and carving `db.js` per-domain (Config-B core decomposition)

**Status:** Accepted (2026-06-26) · task [#1570](https://example.com/builders#/task/1570) (BV1.R67) · criterion **C7 `gds-core-modularized`** (BONGOS-V1) · planning [session 2026-06-26](../session-logs/<redacted>.md)

**Amends:** [ADR 0083](<redacted>.md) — the strangler build plan. ADR 0083 §"The four module moves" cut the four *feature* modules (dev-box, game, discord, art-pipeline) around an undifferentiated core. This ADR extends the same strangler to the **core itself**: it bounds the kernel as a real artifact and defines how a *core domain* becomes a module. It changes nothing about 0083's five rules, the loader, or the fitness ratchet — it gives the "kernel" 0083 kept referring to a concrete file roster, and the "carve `db.js` per-domain" 0083 mentioned ([02 §3](../design/modular-architecture/02-module-map.md)) a mechanism.

**Builds on:** [ADR 0016](<redacted>.md) (server-enforced rank boundary — the kernel *is* the trust boundary), [ADR 0043](<redacted>.md) (protected paths), [ADR 0086](<redacted>.md) (module-scope-map), [ADR 0062](<redacted>.md) (core↔host split — same "neutral contract, swappable behind it" shape).

**Relates to:** [ADR 0095](<redacted>.md) — the *findability* complement to this ADR's *structural* scoping (authored alongside it): 0091 bounds how much an agent loads (kernel + per-domain modules); 0095 helps the agent find the right place within it (docstrings, greppability, retrieval). The module-header doc-comment convention 0095 adopts is authored per module the carve here defines.

---

## Context

ADR 0083's Config A moved the four feature modules — the *least*-coupled ~26% of the tree — into `modules/<key>/`. The audit that opened C7 ([planning 2026-06-26](../session-logs/<redacted>.md)) found the remaining ~70% ("core") is **not one thing**: it is ~8–10 cohesive domains sitting on a small (~3.5k-LOC) trust kernel ([02 §1](../design/modular-architecture/02-module-map.md)), but nothing in the code marks where the kernel ends and a domain begins. Three concrete symptoms:

1. **The "kernel" is unbounded.** `fitness.js` `KERNEL_FILES` (`fitness.js:449-456`) is only the **6 module-system-machinery files** (`module-api`, `modules`, `module-seams`, the three `module-loader/*`). The real trust kernel — `auth.js`, `route-rank-check.js`, `permission-path-check.js`, `pool.js`, `secret-box.js`, config/identity — is nowhere named, so no fitness check guards it and no one can say "is this file kernel?" with a yes/no answer.
2. **`db.js` is a 6063-LOC monolith** (383 exports, `require`d by 23 files) spanning every domain — builder identity, audit, tasks/claims/versions, memory search, grade-attempt logs, security docs, merge leases. It is the single biggest blocker to per-module AI-scoping: a "work on memory" task drags the whole file into context.
3. **The doorway leaks domain queries.** `src/module-api.js` re-exports `getBuilderById`/`createTask`/`insertAuditLog`/`getBuilderGeminiKeyRow`/`setBuilderBoxBlocked`/`captureIdea` (`module-api.js:86-103`). Some of those (identity, audit, rank) are genuinely kernel; others (`createTask`, gemini keys, box-blocked, `captureIdea`) are **domain** capabilities the kernel should not own. There is also **no `withTx`** on the doorway, so a carved domain that needs a transaction (memory does — `memory.js:107,198,441` run raw `client.query('BEGIN')`) has no kernel-blessed way to get one.

This ADR settles the three questions C7's tranche-1 tasks (R68–R74) each execute: **what is the kernel**, **how does a carved domain own its SQL**, and **what does the doorway expose**.

---

## Decision

### 1. The kernel is a bounded, enumerated file roster

The **kernel** is the trust boundary + identity + the module-system machinery — the *only* code a core-domain module may reach, and only through `src/module-api.js`. It is exactly this roster (this list replaces the 6-file `KERNEL_FILES` in `fitness.js`, the R70 ratchet):

| Concern | Files | Why kernel |
|---|---|---|
| **Authz gates** | `src/bongos/auth.js` | `requireBuilder`/`requireRank`/`rankMeetsThreshold`/`allowBoxScope`/`requireBfgPrincipal` — the ADR 0016 boundary every route composes |
| **Trust classification** | `src/bongos/route-rank-check.js`, `src/bongos/permission-path-check.js` | deterministic route→rank + protected-path matching (the "unknown write = blocker" rule + `PROTECTED_GLOBS`, ADR 0043) — cross-cutting, enforced by composition, never "called" by a domain ([02 §5](../design/modular-architecture/02-module-map.md)) |
| **Secret primitive** | `src/bongos/secret-box.js` | AES-256-GCM box for per-builder secrets at rest |
| **Data substrate** | `src/bongos/pool.js`, **`src/bongos/db-kernel.js`** *(new, R69)* | the singleton pool + `withTx` + the genuinely-kernel `builders`-identity / `audit_log` / rank-ladder slice carved out of `db.js` |
| **Config / identity** | `src/instance-config.js`, `src/branding.js`, `src/build-info.js` | host context a module reads, never hardcodes (ADR 0062) |
| **Shared route helpers** | `src/bongos/routes/_helpers.js` | `validateOrRespond`/`LIMITS` — the request validators the doorway re-exports so a module's routes don't vendor their own |
| **Module-system machinery** | `src/module-api.js`, `src/modules.js`, `src/module-seams.js`, `src/module-loader/{loader,manifest-schema,semver}.js`, `src/bongos/module-scope-map.js` | the doorway, registry, seam switchboard, disk loader, and the module→path scope map (ADR 0086) |

**Everything else in `src/bongos/` is a domain**, destined to become a module (memory, grading, economy, onboarding, ideas, builder-settings, sessions/BFG, security, …) or to stay inside the **lifecycle** state machine (tasks/claims/versions/ship — explicitly **not** split, [02 §4](../design/modular-architecture/02-module-map.md)). The roster is a **ratchet, not a wish**: R70 adds `KERNEL_FILES` = this list **and** a check that no kernel file `require`s a soon-to-be-module domain, so a regression is a red build. `db-kernel.js` joins the roster when R69 creates it; until then the roster is the trust files above (all confirmed present at this commit).

### 2. `db.js` is carved per-domain — the module owns its SQL, the kernel owns identity/audit/tx

The carve pattern is **already proven** by the discord move (`modules/discord/db.js`, BV1.R47) and the game move (`modules/game/db.js`). C7 ratifies it as *the* mechanism every core-domain carve copies:

- A carved domain module ships its own `modules/<key>/db.js` that **requires only `../../src/module-api.js`** and reaches Postgres through the doorway's `pool` (and `withTx` — see Decision §3). Its domain queries are **lifted verbatim** out of `src/bongos/db.js` and **deleted from core** (`db.js` shrinks by that slice). The module re-exports any kernel helpers it consumes (e.g. `insertAuditLog`) off the doorway behind the *same* `db.*` namespace, so the module's own files keep `const db = require('./db')` unchanged.
- **`db.js` shrinks toward two residues:** (a) the **kernel slice** — builder identity (`getBuilderById`), audit (`insertAuditLog`), the rank ladder (`LIVE_RANK_LADDER`), and `withTx` — extracted to `src/bongos/db-kernel.js` (R69) which the doorway re-exports; and (b) the **lifecycle** state-machine queries (tasks/claims/versions/ship), which stay in core because the lifecycle is not a module.
- **Boundary-forced duplication is allowed and documented.** Where core *and* a module both need a query against a shared table, the module vendors its own copy (the discord `getDiscordLink`/`recordApplause` precedent) rather than importing core — a module can never `require` core internals. Each such twin carries a "keep in sync" note in the module's `CLAUDE.md`.
- **Migrations stay additive + namespaced** (ADR 0083 §Module-owned migrations, unchanged). Carving *code* does not move *tables*; a domain's tables are reached through the pool and only ever extended by `modules/<key>/migrations/` going forward. No data moves, no down-path.

R69 proves the pattern on **one reference slice**; R72 (memory) and R73 (grading) are the first two real carves.

### 3. The doorway exposes kernel capabilities permanently and domain capabilities only as marked, temporary re-exports

`src/module-api.js` is classified into three buckets. R68 executes the move and bumps `CORE_VERSION` minor (additive: `withTx`).

- **Kernel — stays, permanently** (these legitimately belong to the kernel): all auth gates; `pool`/`getPool`/`instanceDbName`; **`withTx`** *(new)*; `secretBox`; `getBuilderById` (identity), `insertAuditLog` (audit), `LIVE_RANK_LADDER` (rank); all config/identity (`branding`/`resolveEnv`/`config*`); all seams; `buildInfo`/`validateOrRespond`/`LIMITS`; `logger`. After R69 these resolve through `db-kernel.js`, not the monolith.
- **Domain leak — relocate to the owning module's `db.js` slice** (the module exists today; it just lacks a slice): `setBuilderBoxBlocked` → `modules/dev-box/db.js`; `getBuilderGeminiKeyRow`/`setBuilderGeminiKey`/`clearBuilderGeminiKey` → `modules/art-pipeline/db.js`. R68 deletes these doorway re-exports and the module owns the query (R69 pattern). This severs the last `dev-box`/`art-pipeline` → core-`db.js` dependency.
- **Domain leak — temporary, behind a `pending-seam` note** (the owning domain is *not* carved in tranche 1, so a clean home does not exist yet): `createTask` (lifecycle), `captureIdea` (ideas), `VOTABLE_TASK_STATUSES` (lifecycle/task-classifier). These **stay on the doorway** for now, each tagged in `module-api.js` as "DOMAIN capability, not kernel — relocates behind a `lifecycle.*` / `ideas.*` port when that domain is carved (tranche 2)." Pretending they're kernel is the thing to avoid; deleting them now would break the discord module (its `db.js` consumes all three). The honest state — *known leak, named owner, tracked* — is what the ADR records.

**Why `createTask` is not just made a port now:** the consumer (discord-bugs filing a task) is real, but the *provider* (a lifecycle module) does not exist until tranche 2. Registering a `lifecycle.createTask` port with core itself as the provider would be ceremony with no boundary benefit while lifecycle is still core. The port lands when lifecycle is carved; until then the doorway re-export *is* the seam, explicitly marked.

### 4. A capability the lifecycle invokes resolves through a kernel PORT, never a direct import

The lifecycle (tasks/claims/versions/ship) stays whole, but the capabilities it *calls* are extracted. `routes/tasks.js` (the ship path) currently `require`s `grader.js` directly — a core→domain edge once grading is a module. R73 replaces it with the seam: grading `registerProvider('grade', …)` at boot; the lifecycle does `resolve('grade')(…)` at ship. This proves the design's load-bearing pattern — *keep the state machine, extract the capability behind a seam* ([04 §1](../design/modular-architecture/04-module-lifecycle.md), [02 §4](../design/modular-architecture/02-module-map.md)) — and closes the audit's "ports were illustrative-only" gap.

---

## The sub-task shape (C7 tranche 1 — seeded, dependency-wired)

This ADR's deliverable is the decision above **plus** the carve broken into claimable steps. Already seeded under C7 ([planning 2026-06-26](../session-logs/<redacted>.md)); dependency edges authoritative:

| Task | Delivers | Depends on |
|---|---|---|
| **R67** ([#1570](https://example.com/builders#/task/1570)) | *this ADR* — kernel roster + carve strategy + doorway classification | — |
| **R68** ([#1571](https://example.com/builders#/task/1571)) | doorway: add `withTx`; relocate the dev-box/art domain leaks; mark the lifecycle/ideas leaks; `CORE_VERSION` minor bump | R67 |
| **R69** ([#1572](https://example.com/builders#/task/1572)) | the per-domain db-slice pattern + extract `db-kernel.js` (identity/audit/rank/tx) as the reference slice | R67, R68 |
| **R70** ([#1573](https://example.com/builders#/task/1573)) | fitness: `KERNEL_FILES` = the real roster (§1) + "kernel imports no domain" check | R67 |
| **R71** ([#1574](https://example.com/builders#/task/1574)) | register `memory` + `grading` keys in `module-scope-map.js`; widen goal 10 scope | R67 |
| **R72** ([#1575](https://example.com/builders#/task/1575)) | carve `memory` → `modules/memory/` (memory·search·search-chunker·learnings + db slice) | R69, R71 |
| **R73** ([#1576](https://example.com/builders#/task/1576)) | carve `grading` → `modules/grading/`; lifecycle resolves `grade` via a kernel PORT | R68, R69, R71 |
| **R74** ([#1578](https://example.com/builders#/task/1578)) | proof: memory + grading live as modules, `db.js` shrank, kernel bounded + fitness green, OTB byte-identical | R72, R73 |

**Proof of equivalence at every step** (ADR 0083 / 0062 discipline): after each carve, OTB behaves **byte-for-byte the same**. That is the per-task done-when.

**Tranche-1 status: PROVEN** (R74, [#1578](https://example.com/builders#/task/1578)). The five claims above are demonstrated, in one re-runnable command, by [`scripts/gds/coreB-carve-proof.sh`](../../scripts/gds/coreB-carve-proof.sh): memory + grading are loader-discovered modules; `db-kernel.js` + the memory query slice left the `db.js` monolith; `KERNEL_FILES` is the bounded 17-file roster with zero fitness hard-failures (incl. the three ENFORCING C7 boundary checks); grading resolves through the `grade` kernel port (`seams.resolveOptional('grade')`) with no core→grader import; and the 27 DB-free tests exercising the carved surfaces pass unchanged (byte-identical). The ongoing guard is CI — `fitness.js` (the kernel-imports-no-domain ratchet flips red at zero leaks) + `run-unit-tests.js` on every PR; the script is the consolidated demonstration, not a new gate. Tranche 2 (the remaining ~8 core domains) stays deferred per owner until greenlit.

---

## Consequences

**Positive.** The kernel becomes a yes/no artifact a fitness check guards (R70) — the trust boundary stops being "wherever the trust code happens to sit." `db.js` shrinks toward the lifecycle + a small kernel slice, so a core-domain task loads its module + the doorway, not a 6k-LOC monolith (the AI-scoping payoff Config A could not deliver). The doorway stops lying about what is kernel. The `grade`-via-port move makes the seam mechanism real instead of illustrative.

**Negative / cost.** More boundaries to enforce (mitigated: fitness, not reviewers). `db.js` carving is delicate — a missed call site is a runtime break, so each carve verifies byte-identical behavior + runs the smoke suite. The honest "temporary doorway leak" bucket (Decision §3, third group) is real debt — but *named, owned, and tracked* debt, retired when tranche 2 carves lifecycle/ideas. Touching `module-api.js`, `fitness.js`, `db.js`, and `route-rank-check.js`/`permission-path-check.js` (kernel trust surfaces) means owner Gate approval is expected on those PRs — the boundary working as designed.

**Neutral.** Single-package / single-process / no-bundler preserved (ADR 0083 unchanged). Tranche 2 (the other ~8 core domains: economy, onboarding, ideas, builder-settings, sessions/BFG, security, the UIs, lifecycle-as-its-own-module) is deferred per owner — this ADR proves the pattern on the two cleanest-slicing domains first.

---

## Alternatives considered

- **Leave the kernel implicit (status quo) — rejected.** "The kernel is whatever the trust code happens to be" cannot be fitness-enforced and gives an AI agent no answer to "is this file kernel?" Bounding it is the precondition for every later check.
- **Carve `db.js` by splitting the file in place (sections, not modules) — rejected.** Section comments already exist and did nothing for coupling or scoping; only moving a slice *out* to `modules/<key>/db.js` (behind the doorway) severs the dependency and shrinks the context an agent loads.
- **Make every doorway leak a port immediately — rejected for tranche 1.** A port with core as its own provider is ceremony with no boundary benefit until the providing domain is actually a module. Mark the leak, carve the domain, *then* add the port (R73 does exactly this for `grade`, where the provider genuinely becomes a module).
- **Split the lifecycle state machine into per-route modules (Config C) — rejected** (ADR 0083 already; restated because the `db.js` carve makes it tempting). tasks/claims/versions/ship are one coupled cluster; forcing them apart fights cohesion. Extract the *capabilities* (grade, reward), keep the *machine*.
