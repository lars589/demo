# ADR 0070 — Deterministic delivery of in-session cards (hook-delivered, read-only vs mutating)

- **Status:** Accepted
- **Date:** 2026-06-20
- **Track:** internal
- **Builds on:** the deterministic-card lineage — task 1273 (script owns the card markup, same shape every session), task 1279 (per-builder "render widgets" knob; OFF ⇒ no HTML), task 1282 (in-band `[otb-card]` relay directive so the contract doesn't live only in the skill). Hook discipline mirrors [`.claude/hooks/conductor.js`](../../.claude/hooks/conductor.js) (the `UserPromptSubmit` MAS Conductor, [ADR 0024](<redacted>.md)).
- **Task:** [#1288](https://example.com/builders#/task/1288)

## Context

A session review found the `/builder-start` "pane" rendering unreliably. The card's *content* had been deterministic since tasks 1273/1279/1282 — `start.js` owns the markup — but its *delivery* was not. The skill asked the model to run a multi-step routine every session: detect whether `show_widget` exists → call `read_me` → run the script → branch on the first character of stdout → parse stderr directives → render. Every step is a place a probabilistic model can diverge.

The sharpest failure is structural, not behavioral. The exported session ran on a **cloud/remote** surface where the `mcp__visualize` server (which provides `show_widget`/`read_me`) **was not present at all** — so the skill's documented "normal case in the app" path was impossible, and the model either called a missing tool or dumped raw HTML as text. The same class of miss happens whenever the model "summarizes" instead of relaying.

We confirmed the hook boundary against the Claude Code docs:

- A hook **cannot** render UI or call an MCP tool (`show_widget`), and **cannot** detect which tools/MCP servers exist in the session (no tool manifest reaches a hook). Only the model can emit the visible card, and only the model knows its own tool set.
- `UserPromptSubmit` (and `SessionStart`/`UserPromptExpansion`) inject **stdout as context**; `PostToolUse` injects model-visible context via **`hookSpecificOutput.additionalContext`** (placed next to the tool result, read on the next model request).

So fully-deterministic *pixels* are not achievable today. The achievable win is to move the deterministic 5 of the 6 steps **out of the model and into a hook**, leaving the model only the irreducible "emit" step — with the finished card and a one-step directive handed to it.

## Decision

Make card **delivery** deterministic via hooks, and split the vehicle by whether the owning script **mutates state** — because that determines whether a hook may run it.

1. **Read-only cards** (`/builder-start`, `/status`; future: `/recall`) → **[`session-cards.js`](../../.claude/hooks/session-cards.js)**, a `UserPromptSubmit` hook. On a matching intent it runs the script's `--hook` mode, which emits a one-fetch JSON envelope `{widgets_enabled, html, markdown, warnings}`, and injects the finished card + a one-step "render this once" directive. Registry-driven: adding a read-only card is one `CARDS` entry (a matcher, a script, an arg-extractor). Safe to pre-run because these scripts only fetch + render.

2. **Mutating / lifecycle cards** (`/builder-claim`, `/builder-ship`; `release` matched, emits none today) → **[`lifecycle-card.js`](../../.claude/hooks/lifecycle-card.js)**, a `PostToolUse`/Bash hook. These **must never be pre-run** — claiming or shipping as a side effect of merely typing would be catastrophic. Instead the model runs the script itself; the hook fires immediately after, reads the `[otb-card-html] <path>` marker the shared emitter ([`src/bongos/ship-card.js`](../../src/bongos/ship-card.js)) wrote, reads that file, and injects the card + directive next to the tool result.

Both hooks honor the task-1279 widgets knob (OFF ⇒ no HTML injected, the plain-text card stands), carry **exactly two** fence markers around each payload (no extraction ambiguity), and follow the standard hook discipline: silent-fail (any miss/parse/IO error → exit 0, no output), zero model calls, a kill-switch (`OTB_SESSION_CARDS_OFF`) and the `OTB_SUBAGENT` guard. The skills (`builder-start`, `status`, `builder-claim`, `builder-ship`) are slimmed to **defer to the injected directive**, keeping their old run-the-script logic as the fallback when no directive appears (hook disabled, an older checkout, or a silent failure).

## Consequences

- **Reliability up across every surface.** The card data + render instruction reach the model deterministically on app, cloud/remote, plain terminal, and cron — independent of whether `show_widget` exists. Where it doesn't, the directive says "paste the markdown," so the failure mode becomes a plain card instead of a broken widget or a raw-HTML dump.
- **Interactivity preserved.** The rich, click-to-claim / click-to-drill widget still renders where `show_widget` exists; it's now a reliable enhancement rather than the sole, fragile path.
- **The render is still a model action.** This is a hard platform limit — a hook can instruct but cannot force a tool call. Reliability equals the model's compliance with an unmissable, pre-computed instruction (high), not a hard guarantee. If a forced-render primitive ever exists, `/feedback` is the channel.
- **Token cost.** When widgets are ON the hook injects both the HTML and the markdown form (it can't detect `show_widget`, so the model must be able to branch). Bounded: it fires only on an explicit card intent, not every prompt.
- **`/status` gained a card.** It previously emitted freeform text the skill was told to "interpret + relay" (per-session improvisation); it now owns a deterministic widget + markdown card, and its stale default version was bumped `GDS-V3` → `GDS-V4` (GDS-V3 is closed).

## Alternatives considered

- **Bulletproof the skill only** (reword so markdown is the default, widget the exception). Improves the odds but leaves delivery a model decision — same failure class, just rarer. Rejected as a mitigation, not a fix; kept as the fallback layer.
- **Auto-render at `SessionStart`.** Rejected: a builder runs many parallel sessions, so a card on every session open is noise. Delivery fires on explicit intent instead.
- **One hook for both events.** Rejected: read-only (pre-run on intent) and mutating (post-run on tool use) have genuinely different trigger logic; two single-responsibility hooks read more clearly than one dispatching on `hook_event_name`.
