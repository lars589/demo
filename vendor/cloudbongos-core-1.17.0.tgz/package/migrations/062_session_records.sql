-- 062_session_records.sql — BFG session-inefficiency evaluator, sub-phase 6D.1
-- (ADR 0027). Stores a compact, secret-scrubbed digest of each shipped Claude
-- Code session so the BFG (a LOCAL Claude Code routine — 6D.3) can search the
-- corpus (6D.2) and deep-dive the wasteful ones.
--
-- Design note (privacy + size): the heavy transcript CONTENT is never uploaded.
-- Each row holds per-turn METADATA (role, tool name, error flag, token usage,
-- content length) + short secret-scrubbed snippets + token aggregates. That
-- keeps rows small (KB, not MB) and the secret surface minimal — ADR 0027's
-- "scrubbed, retention-bounded" posture.
--
-- Write path: scripts/gds/ship.js uploads via POST /api/gds/sessions on a
-- successful ship (best-effort, non-blocking). Deduped per session_id — a
-- session that ships multiple tasks upserts once, accumulating task_ids.
-- Read path (6D.2, separate task): self-serve read of one's OWN sessions + an
-- Archon-gated (BFG-principal when 6C.1 lands) cross-builder search.

CREATE TABLE IF NOT EXISTS session_records (
  id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  session_id       text NOT NULL UNIQUE,             -- Claude Code CLAUDE_CODE_SESSION_ID
  builder_id       bigint NOT NULL REFERENCES builders(id),
  task_ids         bigint[] NOT NULL DEFAULT '{}',   -- tasks shipped from this session
  drachmae_earned  integer NOT NULL DEFAULT 0,       -- credit_log delta attributable to the session
  total_tokens     bigint NOT NULL DEFAULT 0,        -- summed transcript usage (in + out + cache)
  duration_seconds integer,                           -- transcript first -> last timestamp
  started_at       timestamptz,
  ended_at         timestamptz,
  uploaded_at      timestamptz NOT NULL DEFAULT now(),
  detail           jsonb NOT NULL DEFAULT '[]'::jsonb, -- per-turn metadata + short scrubbed snippets
  metrics          jsonb NOT NULL DEFAULT '{}'::jsonb  -- derived aggregates (turns, tool errors, token buckets)
);

CREATE INDEX IF NOT EXISTS idx_session_records_builder  ON session_records (builder_id);
CREATE INDEX IF NOT EXISTS idx_session_records_uploaded ON session_records (uploaded_at DESC);
