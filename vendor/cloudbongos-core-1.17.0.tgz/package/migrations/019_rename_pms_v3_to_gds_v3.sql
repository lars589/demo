-- 019_rename_pms_v3_to_gds_v3.sql
--
-- V3.R01: rename the in-flight version's ID from `PMS-V3` to `GDS-V3`, and
-- rename the related `pms-shipper` achievement to `gds-shipper`.
--
-- PMS-V1 and PMS-V2 are intentionally NOT renamed — those versions shipped
-- under those names and their archives in `limitations/pms-v*-shipped.md`
-- are immutable historical records. Going forward (V3 onward), the system
-- is the Game Development System (GDS); future versions are GDS-V4, GDS-V5,
-- etc.
--
-- The version id `versions(id)` is a TEXT primary key referenced by FK from
-- `tasks`, `done_when_criteria`, and `idea_inbox`. The `achievements(id)`
-- primary key is referenced by FK from `builder_achievements`. Neither FK
-- was declared with `ON UPDATE CASCADE`, so we drop them, rewrite all the
-- relevant tables in one transaction, and re-add them at the end.
--
-- `source_ref` strings that were seeded as `pms-v3-r##` are rewritten to
-- `gds-v3-r##` for consistency (these are internal audit identifiers — no
-- user-visible surface).

BEGIN;

-- ─────────────────────────────────────────────────────────────────────────
-- 1. Versions rename: PMS-V3 → GDS-V3
-- ─────────────────────────────────────────────────────────────────────────

ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_version_id_fkey;
ALTER TABLE done_when_criteria DROP CONSTRAINT IF EXISTS done_when_criteria_version_id_fkey;
ALTER TABLE idea_inbox DROP CONSTRAINT IF EXISTS idea_inbox_suggested_version_fkey;

UPDATE versions SET id = 'GDS-V3' WHERE id = 'PMS-V3';

UPDATE tasks SET version_id = 'GDS-V3' WHERE version_id = 'PMS-V3';
UPDATE done_when_criteria SET version_id = 'GDS-V3' WHERE version_id = 'PMS-V3';
UPDATE idea_inbox SET suggested_version = 'GDS-V3' WHERE suggested_version = 'PMS-V3';

-- Rewrite V3 planning-seed source_refs (pms-v3-r## → gds-v3-r##)
UPDATE tasks SET source_ref = REPLACE(source_ref, 'pms-v3-', 'gds-v3-') WHERE source_ref LIKE 'pms-v3-%';

ALTER TABLE tasks ADD CONSTRAINT tasks_version_id_fkey FOREIGN KEY (version_id) REFERENCES versions(id);
ALTER TABLE done_when_criteria ADD CONSTRAINT done_when_criteria_version_id_fkey FOREIGN KEY (version_id) REFERENCES versions(id);
ALTER TABLE idea_inbox ADD CONSTRAINT idea_inbox_suggested_version_fkey FOREIGN KEY (suggested_version) REFERENCES versions(id);

-- ─────────────────────────────────────────────────────────────────────────
-- 2. Achievement rename: pms-shipper → gds-shipper
--    Display name also updates ("PMS Shipper" → "GDS Shipper") for the UI.
-- ─────────────────────────────────────────────────────────────────────────

ALTER TABLE builder_achievements DROP CONSTRAINT IF EXISTS builder_achievements_achievement_id_fkey;

UPDATE achievements
   SET id = 'gds-shipper',
       name = 'GDS Shipper'
 WHERE id = 'pms-shipper';

UPDATE builder_achievements
   SET achievement_id = 'gds-shipper'
 WHERE achievement_id = 'pms-shipper';

ALTER TABLE builder_achievements
  ADD CONSTRAINT builder_achievements_achievement_id_fkey
  FOREIGN KEY (achievement_id) REFERENCES achievements(id);

COMMIT;
