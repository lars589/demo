# ADR 0044 — Per-box live game preview (the builder sandbox)

**Date:** 2026-06-10
**Context:** GDS-V3, task [#897](https://example.com/builders#/task/897) (this ADR + the tunnel mechanism), wired into provisioning under [#898](https://example.com/builders#/task/898), hardware-verified under [#899](https://example.com/builders#/task/899). Companion to [ADR 0031](<redacted>.md) (per-builder DigitalOcean box substrate), [ADR 0038](<redacted>.md) (the box's ttyd terminal over a Cloudflare Tunnel — the mechanism this extends), and [ADR 0016](<redacted>.md) (the web tier only *asks*; the control plane holds infra power).
**Status:** Accepted. Mechanism implemented under [#897](https://example.com/builders#/task/897).
**Track:** `internal` (dev-system / builder experience).

## Problem

A builder working on the **game** (`public/`, `src/world/`, `src/rooms/`, the art tiles) has no way to *see their change running* before it ships. The only live instance of Off the Boats is production at `example.com`. So the loop today is: edit → ship through the grader/merge/deploy pipeline → look at prod. That is slow, it puts unreviewed game changes one mistake away from players, and a browser-only (Chromebook) builder has no local machine to run the game on at all.

What a builder wants is a **sandbox**: run the game live *on their own dev box* and open it in a browser to review the change — never touching the prod server.

## Decision

**Serve the box's own `node server.js` over a second ingress route on the builder's existing per-box Cloudflare named tunnel, at a stable hostname `sandbox-<login>.example.com`. Run it degraded (no Postgres on the box). Give the builder a `box-preview` command in their terminal to restart it after edits.**

This reuses the entire ADR 0038 substrate — the box already runs a `cloudflared` named tunnel ([#771](https://example.com/builders#/task/771)) with an outbound-only connector. A Cloudflare named tunnel can carry **multiple ingress rules on one connector**, so the game rides the same tunnel the terminal already uses; no second tunnel process, no new connector token.

### 1. Degraded-DB — the game runs with no Postgres

`server.js` binds `127.0.0.1:3000` and needs **no env vars and no DB to boot**. The game tables (`world_events`, `players`) are touched only lazily at runtime, and every call is failure-tolerant (`safeLog` swallows event-log errors; `loadOrCreatePlayer` falls through to a default spawn on a DB error). So `node server.js` on a box with no Postgres serves a **fully playable world** — you can walk, see every tile / world / container / art change, exercise movement and rooms — you just don't get position persistence across reloads or an event log.

For *reviewing a change to the game* that is the right trade. Installing + seeding Postgres on every box (the alternative) is heavier provisioning for persistence the preview doesn't need, especially while the game has no login or purchase loop (V1 limits still hold). Full persistence is a deliberate future follow-up, not a precondition.

### 2. Exposure — a second ingress route, stable apex hostname

The box's named tunnel gains a second ingress rule: `sandbox-<login>.example.com → http://127.0.0.1:3000`, alongside the existing `term-<login>.example.com → 127.0.0.1:7681` (ttyd). Both are **one-label hostnames under the apex**, so Cloudflare's free Universal SSL covers them with no paid certificate — the same constraint that forced the apex (not `dev.*`) terminal hostname in [#771](https://example.com/builders#/task/771). A proxied CNAME for the preview host is upserted next to the terminal's.

Host-based routing in `server.js` keys on the leading subdomain label: `status.*` → dashboard, `builders.*` → hall, **everything else → the game**. `sandbox-<login>` matches neither prefix, so it falls through to the game with zero routing changes. The Colyseus WebSocket rides the same HTTP server, so the world works over the tunnel unchanged.

### 3. The box-side units

- **`box-game-preview.service`** — a systemd unit running `node /workspace/server.js` with `HOST=127.0.0.1 PORT=3000`, `Restart=always`. Modeled on `box-terminal.service`. It depends on the `/workspace` source clone, so it is enabled by `box-source-fetch.sh` after the clone (not at first boot like ttyd), under [#898](https://example.com/builders#/task/898).
- **`/usr/local/bin/box-preview`** — a baked wrapper the builder runs in their ttyd terminal: `box-preview status` (is it up + the URL), `box-preview restart` (pick up edits), `box-preview logs` (server output). Baked to `/usr/local/bin` so it works regardless of the rank-gated sparse checkout (a Xenos box has no `scripts/` or `.claude/`, idea [#213](https://example.com/builders#/idea/213)).

### 4. The edit → preview loop

The preview is a long-running service so the URL is always live while the box is up. To see a change: edit in the terminal → `box-preview restart` → refresh the browser tab. (A file-watcher auto-restart is a possible future nicety; an explicit restart is predictable and cheap.)

## Trust boundary

Unchanged from ADR 0016 / 0038. The Cloudflare API token that creates the tunnel + DNS lives **only on the control plane** (`scripts/gds/box.js`, the prod droplet's `box.env`), never the web tier. The preview is a *second instance* of the same Node app the box already clones — it holds no prod credentials and cannot reach the prod DB (it has none), so a builder previewing their own branch is fully isolated from production data. The preview hostname is per-builder and only fronts that builder's box.

One consequence to note: because `/api/gds/*` mounts ahead of host-routing in `server.js`, the preview hostname also exposes the box's *own* GDS API surface — but that process has no DB and no OAuth secrets, so it is inert. Acceptable for the sandbox; flagged here so a future reviewer isn't surprised.

## Cost

**$0 added.** Reuses the existing per-box tunnel and connector (Cloudflare Zero Trust free tier). No new droplet, no Postgres, no second tunnel process, no paid certificate (apex one-label host under free Universal SSL).

## Consequences

- A builder can review game changes live in a browser, isolated from prod — the core ask.
- Browser-only (Chromebook) builders get a real preview with no local machine.
- The named-tunnel path is required (the tokenless quick tunnel carries only one port). Boxes on the quick-tunnel default do not get a preview until the operator sets `BOX_NAMED_TUNNEL=1` — consistent with the ADR 0038 named-tunnel upgrade story.
- No persistence in the preview (deliberate; see §1). Position resets on reload; no event log.
- Mechanism (this task, [#897](https://example.com/builders#/task/897)) ships and is unit-tested ahead of the provisioning wiring ([#898](https://example.com/builders#/task/898)) and hardware verification ([#899](https://example.com/builders#/task/899)) — the [#760](https://example.com/builders#/task/760) → [#771](https://example.com/builders#/task/771) pattern.
