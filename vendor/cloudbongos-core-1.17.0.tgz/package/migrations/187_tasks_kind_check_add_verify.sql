-- 187_tasks_kind_check_add_verify.sql
-- App/DB enum drift fix. The application's VALID_KINDS gained 'verify' (kind='verify'
-- verification tasks — the ADR-0088/#1053 premature-confirm guard), but the DB
-- `tasks_kind_check` constraint (added in migration 006) was never updated to match.
-- So `POST /tasks` with kind='verify' passed app validation, then violated the CHECK
-- on INSERT and returned 500 create_failed. Surfaced landing the BONGOS-V1 Governance
-- goal — 4 proof tasks (kind='verify') 500'd and fell back to 'infra'.
--
-- Core + platform-universal (a schema constraint every instance needs, NOT OTB
-- scope-truth) → lives in migrations/ root, applies on every deploy. Idempotent:
-- drop-if-exists then re-add with the full current kind set (mirrors VALID_KINDS in
-- modules/lifecycle/task-classifier.js). A drop+re-add re-validates existing rows,
-- all of which already hold a valid kind.

ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_kind_check;
ALTER TABLE tasks ADD CONSTRAINT tasks_kind_check
  CHECK (kind IN (
    'feature','bug','infra','refactor','spike',
    'learning-capture','cleanup','decision','blocker-resolution',
    'verify','unclassified'
  ));
