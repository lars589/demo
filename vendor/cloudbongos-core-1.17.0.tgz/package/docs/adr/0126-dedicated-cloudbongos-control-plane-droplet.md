# ADR 0126 — Dedicated cloudbongos.com control-plane droplet (infra split from the co-hosting box)

**Status:** Accepted — implemented 2026-07-05 (task [#2063](https://example.com/builders#/task/2063)).

## Context

cloudbongos.com (Customer 0, the vanilla dogfood instance — [ADR 0062](<redacted>.md) §2, [`docs/recipes/cloudbongos-standup.md`](../recipes/cloudbongos-standup.md)) ran as a **co-tenant on the OTB game droplet** (`REDACTED_IP`): same checkout, port 3002, its own `cloudbongos` DB. The token-holding **control plane** lived on that same box — `/etc/example/box.env` holds the account's DigitalOcean token **and** the Cloudflare token, drained by `scripts/gds/provision.js` (the instance provisioner, [ADR 0111](<redacted>.md)) and `scripts/gds/box.js` (dev boxes).

That co-location is the weak point in the trust posture: the powerful, account-wide cloud tokens sat on the **same machine** as the game and any co-hosted third-party instance (`emersonian-circles.`, `staging.`). A compromise of any co-hosted workload could reach <redacted> and droplet creation. The existing plan ([ADR 0100](<redacted>.md)/[0108](<redacted>.md), spine R84→R89) only separated cloudbongos.com as a *side effect* of the deferred "Example split" (R89, [#1728](https://example.com/builders#/task/1728)), keeping it co-tenant "for cost" until then.

The owner elected to pull the **infrastructure** separation forward, explicitly accepting a second droplet's cost, for the security division.

## Decision

Run cloudbongos.com on its **own dedicated droplet** that is also the **sole token-holding control plane**:

- **New droplet** `cloudbongos` — DigitalOcean `REDACTED_IP`, nyc3, `s-1vcpu-2gb` ($12/mo), Ubuntu 24.04, tagged `cloudbongos-control` (deliberately **not** `PROVISION_TAG`, so the provisioning reconciler never treats the control plane as a disposable instance).
- **Structural SSH separation** — reached only via a dedicated `cloudbongos_ed25519` key, distinct from the example box's key.
- **Own stack** — Node 22 / PostgreSQL 16 / Caddy, IPv6 egress disabled (so the IPv4-locked Cloudflare token can never be spuriously rejected — `checkDnsTokenScope` uses plain `fetch` with no `-4`, unlike `infra/box-dns-cloudflare.sh`).
- **Holds the tokens** — `/etc/cloudbongos/box.env` (mode 600) carries a **new account-wide Cloudflare token** (Edit-zone-DNS, all zones, IP-locked to `REDACTED_IP`) + the DigitalOcean token. This is the box that provisions instance subdomains for the hosting/provisioning module ([ADR 0111](<redacted>.md) §2 — tokens on the control plane, never the web tier; mirrors [ADR 0031](<redacted>.md) §6).
- **The co-hosting box** (the former OTB droplet, `REDACTED_IP`) stays as-is for the game + co-hosted project instances; the cloudbongos co-tenant unit was removed.

The checkout is still a clone of `example-owner/example` running `src/platform-server.js` with `GDS_BRANDING_FILE=config/branding.cloudbongos.json` (a **lift-and-shift**, not the ADR 0108 pinned-`@cloudbongos/core` standalone model — that remains the longer-term shape).

## Consequences

- The account-wide cloud tokens no longer sit next to the game or third-party workloads — the division the owner asked for. This also **de-risks R89**: cloudbongos.com is already infra-decoupled, so splitting Example can't break it.
- cloudbongos.com's data was migrated (pg_dump → restore) and DNS cut over (apex + `builders.` + `status.` A records → `REDACTED_IP`, kept proxied); `emersonian-circles.`/`staging.` deliberately stayed on the co-hosting box.
- **Not yet done (tracked):** the co-hosting box **still holds its own DO token + a narrow (example.com-locked) CF token** for dev-box (`box.js`) + `provision-intent-runner` duties — reaching "zero cloud tokens on the co-hosting box" needs dev-box + instance orchestration to move to this control plane first (`provision.js` does local ops today; remote-orchestrating co-tenant workloads is unbuilt) — task [#2065](https://example.com/builders#/task/2065). The new box has **no deploy automation** yet (it won't track `main` until wired) — task [#2064](https://example.com/builders#/task/2064). The old `cloudbongos` DB is retained on the co-hosting box as a rollback net until a bake period passes.
- No hardening drop-in on `cloudbongos.service` yet (mirror `infra/example.service.d/hardening.conf` once proven — the standup recipe's standing note).
