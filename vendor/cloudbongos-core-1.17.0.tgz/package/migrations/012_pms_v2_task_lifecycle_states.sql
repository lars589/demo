-- Phase 5: expand task lifecycle from one terminal state to three.
--
-- Before:  active → shipped               (one /builder-ship call did everything)
-- After:   active → completed → confirmed → shipped
--
--   completed — builder declared the work done; on their local branch only;
--               PMS recorded the ship.
--   confirmed — automated verification passed (touches[] scanner clean +
--               smoke tests green); credits land here. Branch may or may not
--               be on origin yet.
--   shipped   — branch merged to main + deployed; visible on production.
--
-- Decisions (per Lars 2026-05-10):
--   1. Credits land on confirmed (not completed, not shipped).
--   2. completed → confirmed is automatic when scanner+smoke pass.
--   3. confirmed → shipped runs /merge-mode immediately (auto-merge attempted;
--      if conflicts, task stays at confirmed for manual /merge-mode resolution).
--
-- Existing tasks at status='shipped' stay shipped (they are already in prod).

-- 1. Loosen the tasks.status CHECK constraint to admit the two new states.
ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_status_check;

ALTER TABLE tasks ADD CONSTRAINT tasks_status_check
  CHECK (status IN (
    'backlog', 'ready', 'active', 'blocked',
    'completed', 'confirmed',
    'shipped', 'abandoned'
  ));

-- 2. Rebuild version_progress to count completed + confirmed + shipped as
-- "done" (any state where the builder has declared the work complete).
-- Rationale: from the project's progress-bar perspective, work that is
-- completed-but-not-yet-merged shouldn't show up as "in flight" — it IS done
-- from the builder's standpoint. The shipped/completed/confirmed split is
-- visible on the public dashboard via separate counts (added in a follow-up
-- view or rendered client-side).
DROP VIEW IF EXISTS version_progress;
CREATE VIEW version_progress AS
SELECT v.id AS version_id,
       v.name,
       v.track,
       v.status,
       count(*) FILTER (
         WHERE t.status IN ('completed', 'confirmed', 'shipped')
           AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
           AND NOT EXISTS (SELECT 1 FROM tasks c WHERE c.parent_task_id = t.id)
       ) AS shipped_count,
       count(*) FILTER (
         WHERE t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
           AND NOT EXISTS (SELECT 1 FROM tasks c WHERE c.parent_task_id = t.id)
       ) AS total_count,
       COALESCE(SUM(CASE
         WHEN t.status IN ('completed', 'confirmed', 'shipped')
              AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
              AND NOT EXISTS (SELECT 1 FROM tasks c WHERE c.parent_task_id = t.id)
         THEN (6 - COALESCE(t.priority, 5))
         ELSE 0 END), 0) AS shipped_weight,
       COALESCE(SUM(CASE
         WHEN t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
              AND NOT EXISTS (SELECT 1 FROM tasks c WHERE c.parent_task_id = t.id)
         THEN (6 - COALESCE(t.priority, 5))
         ELSE 0 END), 0) AS total_weight
  FROM versions v
  LEFT JOIN tasks t ON t.version_id = v.id
 GROUP BY v.id, v.name, v.track, v.status;

-- 3. Companion view: lifecycle_breakdown — separate counts per state so the
-- public dashboard can render an honest "shipped vs in-flight" panel.
CREATE OR REPLACE VIEW version_lifecycle_breakdown AS
SELECT v.id AS version_id,
       v.name,
       v.track,
       count(*) FILTER (WHERE t.status = 'completed'
                          AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\') AS completed_count,
       count(*) FILTER (WHERE t.status = 'confirmed'
                          AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\') AS confirmed_count,
       count(*) FILTER (WHERE t.status = 'shipped'
                          AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\') AS shipped_count
  FROM versions v
  LEFT JOIN tasks t ON t.version_id = v.id
 GROUP BY v.id, v.name, v.track;
