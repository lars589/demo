# ADR 0111 — Instance hosting + domains as a Cloud Bongos module: the `provisioning` module boundary + the self-host / managed split

- **Status:** Accepted (boundary + split decided with the owner; build is task-pending — see §Consequences for the seeded tasks)
- **Date:** 2026-07-03
- **Track:** internal (a portable Cloud Bongos platform capability)
- **Task:** [#1485](https://example.com/builders#/task/1485) (BONGOS-V1, goal 26 — *Cloud Bongos productization and self-host*) — "spec the module boundary + the self-host vs managed split **before** tasking."
- **Deciders:** Lars (Archon), Claude
- **Consolidates:** idea [#345](https://example.com/builders#/idea/345) (owner — *"offer hosting + domain services directly as a module when people start a Cloud Bongos project… configured with the API"*) + idea [#303](https://example.com/builders#/idea/303) (owner, deferred from the 2026-06-17 planning — *optional managed-hosting layer: operate branded instances for owners, push updates centrally, same self-host artifact*).
- **Decides:** (1) that "hosting + domains" ships as a **new `provisioning` module** (NOT the ADR 0092 `hosting` key — see disambiguation below), and its boundary; (2) how the web tier provisions real infra **without holding cloud credentials**; (3) what "provision an instance" composes; (4) domain + TLS handling; (5) the **self-host vs managed split** — both run the identical artifact, and what actually differs; (6) the cost posture; (7) sequencing.
- **Builds on:** [ADR 0062](<redacted>.md) (core↔host instance model), [ADR 0108](<redacted>.md) (the core as a versioned npm dependency — "the same self-host artifact"), [ADR 0065](<redacted>.md) §2 (managed hosting is a service *on top of* the same AGPL artifact), [ADR 0031](<redacted>.md) (the dev-box lifecycle — the reusable provisioning substrate + trust-boundary pattern), [ADR 0083](<redacted>.md) (the module system this ships as), [ADR 0016](<redacted>.md) (server-enforced trust boundary the module must never weaken), [ADR 0100](<redacted>.md) §3 (per-repo GDS — locked; a managed fleet sits *above* it).
- **Relationship to [ADR 0092](<redacted>.md) (name-collision, resolved):** ADR 0092's `hosting` module answers *"where do compute/storage **workloads** run"* (LLM inference, imagegen, embeddings, training, blob storage — brokered to a target such as the warehouse GPU box). **This ADR is a different layer:** *"stand up + operate a whole Cloud Bongos **instance's own infrastructure** — server, database, domain, DNS, TLS."* Same English word "hosting", two concerns. To avoid the "contribution seam" naming-collision lesson ([ADR 0107](<redacted>.md) §Context), this module takes the distinct key **`provisioning`**; ADR 0092 keeps `hosting`. This ADR does **not** re-open or supersede 0092.

---

## Context

**What the ideas ask for.** Today, standing up a Cloud Bongos instance still leaves the owner with an irreducibly-manual infrastructure checklist. Idea 345 wants those steps offered *as a module, configured via the API*, so an owner doesn't manage infra by hand. Idea 303 wants an optional layer where Cloud Bongos *operates* branded instances for owners and pushes updates centrally — explicitly on the *same self-host artifact*.

**What already exists (the reusable substrate).**

- **The instance model is real and proven.** cloudbongos.com is a live second instance (shipped 2026-06-21): its own database, its own process/port, neutral branding, zero game code, **$0/mo extra** because it co-tenants the existing $14/mo droplet ([`docs/recipes/cloudbongos-standup.md`](../recipes/cloudbongos-standup.md)). An instance = a branding pack + enabled modules + owner/repo/OAuth binding + its own DB ([ADR 0062](<redacted>.md) §2).
- **"The same self-host artifact" is defined.** [ADR 0108](<redacted>.md): the core is packaged as `@cloudbongos/core` (`scripts/gds/package-core.js`, `core_version 1.14.0`, pinned by `tree_sha256`) and consumed as a versioned npm dependency via `resolveCoreRoot()`/`resolveInstanceRoot()` in `src/instance-config.js`. Central updates = `bongos upgrade` (a version-pin bump → `npm ci` → migrate → restart) — **O(1) per instance, not an O(instances × drift) merge**. (`bongos upgrade` is a stub until R86; the channel is specified, not yet exercised.)
- **`bongos init` scaffolds a project** (`scripts/gds/init.js`): an interview writes lean `config/branding.json` / `config/modules.json` / `config/hierarchy.json` overrides, materialises `.claude/`, seeds a first version + goal, and — critically — files the **irreducibly-manual owner steps as tracked kickoff tasks** rather than pretending launch is one command: register a GitHub OAuth app, first owner sign-in (seats the founding Archon), confirm the repo binding, and "production topology: TLS, real origins, managed Postgres." **That kickoff list is precisely the surface this module automates.**
- **Programmatic infra provisioning already works — for dev boxes.** The dev-box lifecycle ([ADR 0031](<redacted>.md)) creates/parks/wakes/destroys DigitalOcean droplets (`modules/dev-box/do-api.js`, DO API v2, dry-run by default), manages Cloudflare DNS records (`infra/box-dns-cloudflare.sh` — UPSERT + a blackhole-on-retire that avoids NXDOMAIN caching), boots servers unattended via cloud-init, and prices resources from a `SIZE_CATALOG` cost ledger. **This is the exact machinery a hosting module needs**, one layer up (a whole instance instead of a builder's box).
- **The trust-boundary + intent-queue pattern is established and non-negotiable.** Real-money / infra mutations **never** touch the internet-facing web process. The web route only **enqueues an intent** (`box_intents`); a separate **control-plane runner** (`scripts/gds/box.js`, driven by a systemd timer) is the *sole holder* of the cloud provider tokens, which live in a chmod-600 `/etc/<inst>/box.env` loaded via `EnvironmentFile=` — structurally out of reach of the web tier ([ADR 0016](<redacted>.md), [ADR 0031](<redacted>.md) §9.4).
- **The module contract is settled** ([`docs/modules-contract.md`](../modules-contract.md), [ADR 0083](<redacted>.md)): `module.json` manifest, `default:false` optional modules, one-way import boundary (a module reaches core only through `src/module-api.js`; never another module), rank-gated write routes (fitness-enforced), and module-owned namespaced migrations.

**The gaps (net-new work).** No single command turns the [`cloudbongos-standup.md`](../recipes/cloudbongos-standup.md) runbook into an automated provision. No **domain purchase/registration** capability exists (only DNS-*record* management on existing zones). Per-apex **TLS** is a manual Cloudflare Origin-Cert console step (the least-automated leg). There is no per-instance managed-DB provisioning at scale, no **billing/metering** (only a box *cost ledger*), and no **central fleet control plane** — per-repo GDS is locked ([ADR 0100](<redacted>.md) §3), so "instances Cloud Bongos operates" would be a new operator layer *above* the individual GDS DBs.

**The budget DNA that constrains this.** $5K total for build + first year; cheapest-viable-by-default; any high fixed monthly cost needs an ADR + a cheaper fallback ([CLAUDE.md §4](../../CLAUDE.md)). The project has twice rejected always-on control planes on cost grounds — Coder and a container pool were both declined in [ADR 0031](<redacted>.md) in favour of snapshot-and-park with fixed cost ≈ $0. A hosting module inherits that DNA: **near-zero fixed cost when idle.**

---

## Decision

### 1. Ship it as a new `provisioning` module — the boundary

A new, portable, **`default:false`** module `modules/provisioning/` (`coreVersion: "^1.14.0"`), scaffolded with `bongos module new provisioning`. It **owns the web-tier request + state surface** for standing up and operating instance infrastructure, and nothing more.

**It owns:**
- **Tables** (namespaced `provisioning_*`, additive-only, in `modules/provisioning/migrations/provisioning_NNN_*.sql`):
  - `provisioning_instances` — one row per instance the owner is provisioning/operating: owner, target ref, hosting shape (co-tenant | dedicated droplet), domain, DB name, allocated port, tier, lifecycle status, cost estimate.
  - `provisioning_intents` — the enqueue queue (the `box_intents` analogue) the control-plane runner drains.
  - `provisioning_events` — an append-only audit/log of provisioning actions.
- **HTTP routes** (`contributes.routes`, mounted under `/api/bongos` + the `/api/gds` alias), each self-rank-gated:
  - own-scoped: create a provisioning request, read own instance state/cost, request teardown;
  - Archon-scoped: the fleet roster + cost ledger + force actions (the `/boxes` Archon precedent).
- Optionally a hall **`uiSection`** (an "Instances" panel — own-scoped for owners, fleet view for Archon), reusing the dev-box UI pattern.
- A **port it provides**, e.g. `provisioning.instanceState`, so other code can read instance status via `seams.resolveOptional` without importing this module.

**It does NOT own** (hard boundary — the trust-boundary rule, §2): the cloud provider tokens, the code that calls DigitalOcean/Cloudflare/a registrar, or any privileged shell/SSH. Those live only on the control plane. It also does not own the *game*, *branding*, or *the instance's own GDS data* — an instance provisioned by this module is a normal Cloud Bongos instance with its own DB ([ADR 0100](<redacted>.md) §3).

### 2. The web tier enqueues intents; a control-plane runner holds the tokens

Mirror the dev-box split exactly. A provisioning API call **writes a `provisioning_intents` row and returns** — it never calls a cloud API. A new control-plane CLI **`scripts/gds/provision.js`** (a sibling of `box.js`, deliberately *outside* the module import boundary so it may reuse control-plane code directly) is the **sole token-holder**; a systemd timer runs `provision.js run-intents --apply` on the control plane. Tokens live in the existing chmod-600 `/etc/<inst>/box.env` (or a sibling), loaded via `EnvironmentFile=`, **never** in the web process. The runner is **idempotent + dry-run-by-default** (the `box.js` / `do-api.js` posture), with fleet tagging + drift reconciliation so a leaked droplet/DNS record is detectable.

**Shared provider clients, no module→module import.** The DigitalOcean v2 client (`do-api.js`) and the Cloudflare DNS logic (`box-dns-cloudflare.sh`) that `provision.js` needs currently live inside `modules/dev-box/`. Because a module may not import another module, and both `box.js` and `provision.js` are control-plane CLIs (which *may* require code directly), the build extracts these into a **shared control-plane location** both CLIs use (a `scripts/gds/` or `infra/` client), rather than duplicating them. This is a small, mechanical refactor that leaves dev-box behaviour byte-identical.

### 3. What "provision an instance" composes

The runner automates the [`cloudbongos-standup.md`](../recipes/cloudbongos-standup.md) runbook into one idempotent flow. Each step is classified by how automatable it is:

| Step | Automatable? | How |
|---|---|---|
| Server (co-tenant process **or** a dedicated droplet) | **Yes** | Co-tenant: allocate a port + DB on an existing box (the cloudbongos.com shape, $0 extra). Dedicated: `do-api.js` `createDroplet` + cloud-init (the box precedent). |
| Database | **Yes** | `createdb <inst>` + GDS-only `migrate.sh` (`MEDUSA_GDS_ONLY=1`, instance seeds off — [ADR 0105](<redacted>.md)). |
| App config + secrets | **Yes** | Write `config/branding.json`/`modules.json`/`hierarchy.json` (from the init spec) + a per-instance `/etc/<inst>/web.env` (chmod 600). |
| Process/service | **Yes** | Install + enable a per-instance systemd unit (the `cloudbongos.service` template). |
| DNS | **Yes** | Cloudflare A-record UPSERT via the shared client (§2/§4). |
| TLS | **Yes** (new approach) | Caddy on-demand ACME for the new host (§4) — removes the manual Origin-Cert leg. |
| Reverse proxy | **Yes** | Add the Caddy site block + reload. |
| **GitHub OAuth app** | **Assisted** | GitHub has no clean API to *create* an OAuth app; the runner generates exact instructions + captures the client id/secret the owner pastes back. Stays a guided step. |
| **First owner sign-in** | **Manual** | A human must sign in once to seat the founding Archon (config alone seats no one). Inherent. |
| **Domain registration** | **Deferred** | See §4 — bring-your-own-domain first; registrar-API purchase is a later task. |

### 4. Domains: bring-your-own first; TLS via on-demand ACME

- **V1 = bring-your-own-domain.** The owner already owns a domain (or a delegated zone); the module manages **DNS records** on it via the shared Cloudflare client (the box precedent). **Domain *purchase/registration*** via a registrar API is genuinely net-new and is **deferred to its own later task** — it is not on the V1 critical path.
- **TLS via Caddy on-demand ACME (Let's Encrypt) for provisioned hosts**, instead of per-apex Cloudflare Origin Certs. The existing example.com/cloudbongos.com apexes keep their Origin Certs unchanged; **newly provisioned** hosts get automatic certificates with no manual console step. This directly eliminates "the single least-automated leg" the standup runbook calls out. (On-demand TLS must be allow-listed to hostnames the module actually provisioned, so it can't be abused to mint certs for arbitrary names.)

### 5. The self-host vs managed split

**Both run the identical `@cloudbongos/core` artifact ([ADR 0108](<redacted>.md)).** Managed is not a fork, not open-core, not a proprietary layer — it is self-host + (a) the provisioning module pointed at Cloud Bongos's own infra, and (b) a central operator driving the *existing* `bongos upgrade` channel. This is exactly the posture [ADR 0065](<redacted>.md) §2 already recorded ("*a service offered on top of the same AGPL artifact — it does not change the artifact's license or the non-profit posture*").

| Dimension | **Self-host** | **Managed** (idea 303) |
|---|---|---|
| Artifact | identical `@cloudbongos/core` (pinned npm dep) | identical |
| Whose cloud account/tokens | the **owner's** (their DO/Cloudflare/registrar tokens, held on **their** control plane) | **Cloud Bongos's** tokens on Cloud Bongos infra |
| Control plane | the owner's own (their box runs `provision.js`) | a **central fleet control plane** — greenfield; sits *above* per-instance GDS DBs ([ADR 0100](<redacted>.md) §3) |
| The `provisioning` module | same module, enabled, configured with the owner's target | same module, target = Cloud Bongos infra |
| Updates | owner runs `bongos upgrade` | operator drives `bongos upgrade` across the fleet (same channel) |
| Billing | owner pays their own cloud bill directly | Cloud Bongos meters → invoices → collects (**deferred**, §6) |
| Licensing | AGPL; owner owes source to *their* users only if they modify + serve | AGPL; operator owes source (satisfied by the public mirror) |
| Buildable | **now**, on the shipped configurable-root substrate | **after** Mercury (R85) + a real `bongos upgrade` (R86) |

**The one-sentence rule:** *self-host and managed run the same artifact and the same provisioning module; the only differences are **whose credentials** the control plane holds and **who operates** it.*

### 6. Cost posture

Inherit the budget DNA. **Default to the cheapest shape** — a co-tenant process + DB on an existing droplet ($0 new spend, the cloudbongos.com model) — and only graduate an instance to a dedicated droplet when justified. Idle dedicated instances follow the **snapshot-and-park** precedent (fixed cost ≈ $0). Reuse the `SIZE_CATALOG` per-size USD table for **cost visibility** in `provisioning_instances`. **Billing/metering/invoicing is out of scope for the module's first cut** and is a separate deferred track (it also depends on the V3 Stripe work); the managed layer needs it, self-host does not.

### 7. Sequencing

- **Self-host provisioning is buildable now** — the configurable-root substrate (ADR 0108 W1–W4) and the box lifecycle are shipped. The module + runner + DNS/TLS + `bongos init` wiring do not wait on anything.
- **The managed layer is deferred** (idea 303 was always "post-C8, optional"). It is gated on **R85 (Mercury — the first real second-repo consumer on a pinned core; [#1689](https://example.com/builders#/task/1689))** proving the two-repo path end-to-end, and **R86 (a real `bongos upgrade` channel; [#1690](https://example.com/builders#/task/1690))**. The managed *fleet control plane* is itself a spec-first task, not a straight build.

---

## Alternatives considered

- **Reuse the `hosting` key / fold into [ADR 0092](<redacted>.md).** Rejected — 0092 is compute/storage *workload* brokering; conflating "where my inference runs" with "where my instance runs" would muddy both boundaries (the [ADR 0107](<redacted>.md) naming-collision lesson). Distinct `provisioning` key.
- **Provision directly from the web tier (let it hold DO/CF tokens).** Rejected — violates the [ADR 0016](<redacted>.md)/[ADR 0031](<redacted>.md) trust boundary. The intent-queue + control-plane runner is mandatory, not stylistic.
- **A full standing control plane per the Coder model.** Rejected on cost — the exact trade [ADR 0031](<redacted>.md) already declined. Systemd-timer-drained intents keep idle fixed cost ≈ $0.
- **Per-apex Cloudflare Origin Certs (automate the console step).** Rejected in favour of Caddy on-demand ACME — less bespoke, no Cloudflare-console dependency, and it removes the manual leg outright. Existing apexes keep their Origin Certs.
- **Domain purchase in V1.** Deferred — bring-your-own-domain covers the common case; registrar-API integration is additive and shouldn't gate the module.
- **Build managed first.** Rejected — it depends on unshipped Mercury + the upgrade channel, and idea 303 was always the optional later layer.

---

## Consequences

- **Unblocks the self-host productization arm of goal 26** — the manual [`cloudbongos-standup.md`](../recipes/cloudbongos-standup.md) checklist becomes an owner-driven, API-configured flow (idea 345 delivered), with the two irreducibly-human steps (OAuth-app creation, first sign-in) clearly demarcated.
- **The trust boundary is preserved** — the internet-facing process gains a provisioning surface but still holds no cloud credentials; all real infra mutation stays on the control plane.
- **`bongos init` gains an infra arm** — its infra answers flow into a provisioning request instead of only filing manual kickoff tasks.
- **Deferred / risks:** the **managed fleet control plane** is genuinely greenfield and sits above the locked per-repo GDS model — it needs its own spec once Mercury lands. **Billing/metering** is greenfield (no capability today). **Domain registration** is deferred. On-demand TLS must be hostname-allow-listed to what was actually provisioned. `bongos upgrade` is still a stub (R86).
- **Licensing unchanged** — managed is a service on the same AGPL artifact ([ADR 0065](<redacted>.md) §2); no open-core, no relicensing.
- **Follow-up tasks seeded** under BONGOS-V1 / goal 26 (idempotent seeder `scripts/gds/seed-provisioning-tasks.js`, `source_ref = <redacted>*`):
  1. **Scaffold the `provisioning` module** — manifest + `provisioning_*` tables + the web-tier intent/state routes (own + Archon), no token handling. *(buildable now)*
  2. **Extract the shared DO + Cloudflare control-plane clients** so `box.js` and `provision.js` reuse them without a module→module import (dev-box byte-identical). *(buildable now; enables 3)*
  3. **`scripts/gds/provision.js` control-plane runner + systemd timer** — drains `provisioning_intents`; composes server→DB→migrate→env→service→Caddy→healthz; idempotent, dry-run-default, drift-reconciling. *(deps: 1, 2)*
  4. **Automated DNS + Caddy on-demand ACME TLS** for a provisioned host. *(deps: 2, 3)*
  5. **Wire provisioning into `bongos init`** — infra answers → a provisioning request; keep OAuth-app + first-sign-in as guided/manual. *(deps: 1, 3)*
  6. **Hall UI "Instances" panel** — own-scoped for owners, Archon fleet view + cost. *(deps: 1)*
  7. **Spec the managed fleet control plane** (idea 303) — the central operator above per-instance GDS that stands up branded instances on Cloud Bongos infra and drives `bongos upgrade` across the fleet. *(spec-first; gated on R85 [#1689](https://example.com/builders#/task/1689) + R86 [#1690](https://example.com/builders#/task/1690))*
  8. **Managed billing/metering** — meter provisioned resources → invoice → payment. *(deferred; deps: 7)*
