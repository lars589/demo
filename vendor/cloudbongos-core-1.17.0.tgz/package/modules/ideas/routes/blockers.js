const express = require('express');
// Carved into modules/ideas/ (BV1.R78 / ADR 0093 §1): auth gates + request
// validators reach through the published doorway; `blockers` is an intra-module
// sibling — a module never requires a core internal.
const api = require('../../../src/module-api');
const blockers = require('../blockers');
const { validateOrRespond, LIMITS, parseId } = api;

module.exports = function buildBlockersRouter() {
  const router = express.Router();

  // List currently-open blockers + the tasks each is blocking.
  // Public: anyone landing on /builders or status.amazonprimea.com can see
  // what's stuck on Lars.
  // rank: public — open blocker list; documented "Public: anyone landing on /builders
  // or status.amazonprimea.com can see what's stuck on Lars" in the handler comment above.
  router.get('/blockers', async (req, res) => {
    try {
      // R14 (#2001 / ADR 0119): the open-blocker list is public + grows with the
      // project — cap it via the shared helper (was unbounded). `page` is additive
      // (readers of .blockers are unchanged); total lets a caller know to page.
      const { limit, offset } = api.parsePagination(req);
      const all = await blockers.listOpenBlockers();
      res.set('Cache-Control', 'public, max-age=60');
      res.json({ blockers: all.slice(offset, offset + limit), page: api.pageMeta(limit, offset, all.length) });
    } catch (err) {
      console.error('[gds] GET /blockers', err);
      res.fail('list_failed', { status: 500, message: 'internal error' });
    }
  });

  // rank: any-builder — single blocker detail read.
  router.get('/blockers/:id', api.requireBuilder, async (req, res) => {
    const id = parseId(req, res, { code: 'bad_id' });
    if (id === null) return;
    const blocker = await blockers.getBlocker(id);
    if (!blocker) return res.fail('blocker_not_found', 404);
    res.json({ blocker });
  });

  // rank: any-builder — FILE a blocker (contribution, not resolution).
  router.post('/blockers', api.requireBuilder, async (req, res) => {
    if (validateOrRespond(req, res, {
      title: { required: true, type: 'string', maxLength: LIMITS.TITLE, minLength: 1 },
      body_md: { type: 'string', maxLength: LIMITS.DESCRIPTION },
      source: { type: 'string', maxLength: LIMITS.SOURCE },
      source_ref: { type: 'string', maxLength: LIMITS.SOURCE_REF },
    })) return;
    const body = req.body || {};
    try {
      const blocker = await blockers.createBlocker({
        title: body.title,
        bodyMd: body.body_md ?? '',
        source: body.source ?? 'manual',
        sourceRef: body.source_ref ?? null,
      });
      if (!blocker) {
        // ON CONFLICT — same (source, source_ref) already captured.
        return res.status(200).json({ skipped: true, reason: 'duplicate_source_ref' });
      }
      res.status(201).json({ blocker });
    } catch (err) {
      if (err.code === 'TITLE_REQUIRED') return res.fail('title_required', 400);
      console.error('[gds] POST /blockers', err);
      res.fail('create_failed', { status: 500, message: 'internal error' });
    }
  });

  // Resolve. Auto-promotes any blocked tasks linked via task_blockers.
  // Metic+ (#360 / ADR 0018): blocker review is one of the operations C2
  // assigns to Metic, so this widened from archon-only to metic+archon when the
  // three-rank model went live. Any builder can still FILE a blocker (POST
  // /blockers above); a Xenos cannot resolve or link them.
  // rank: metic+archon — blocker review (auto-promotes linked blocked tasks);
  // criterion C2 / #360 / ADR 0018.
  router.post('/blockers/:id/resolve', api.requireBuilder, api.requireRank('metic', 'archon'), async (req, res) => {
    if (validateOrRespond(req, res, {
      resolution_note: { type: 'string', maxLength: LIMITS.NOTES },
    })) return;
    const id = parseId(req, res, { code: 'bad_id' });
    if (id === null) return;
    try {
      const result = await blockers.resolveBlocker({
        id,
        builderId: req.builder.id,
        resolutionNote: req.body?.resolution_note ?? null,
      });
      res.json(result);
    } catch (err) {
      if (err.code === 'BLOCKER_NOT_OPEN') {
        return res.fail('blocker_not_open', 409);
      }
      console.error('[gds] POST /blockers/:id/resolve', err);
      res.fail('resolve_failed', { status: 500, message: 'internal error' });
    }
  });

  // Link an existing blocker to a task (puts the task in 'blocked' status if
  // it's currently 'backlog' or 'ready'). Metic+ (#360 / ADR 0018) — same
  // blocker-review grant as resolve above.
  // rank: metic+archon — link a blocker to a task; same blocker-review grant as resolve.
  router.post('/blockers/:id/link', api.requireBuilder, api.requireRank('metic', 'archon'), async (req, res) => {
    if (validateOrRespond(req, res, {
      task_id: { required: true },  // accept number or stringified number; coerced below
    })) return;
    const id = parseId(req, res, { code: 'bad_id' });
    if (id === null) return;
    const taskId = Number(req.body?.task_id);
    if (!Number.isFinite(taskId)) return res.fail('task_id_required', 400);
    try {
      await blockers.linkBlockerToTask({ blockerId: id, taskId });
      res.json({ ok: true });
    } catch (err) {
      console.error('[gds] POST /blockers/:id/link', err);
      res.fail('link_failed', { status: 500, message: 'internal error' });
    }
  });

  return router;
};
