// public-builders/gate.js — The Gate (/builders/gate).
//
// Archon-only approval view for gate-surface PRs (task 1179, ADR 0058 amendment).
// A pull request that touches the build's protected machinery is held by the
// gate-review CI check until the owner approves. This page lists every such PR
// with WHY it was stopped (the same classifier the CI runs), and an Approve
// button that records the owner's seal (a server-set gate-owner-approved status)
// and re-runs the check so the PR merges.
//
// Like The Watch + The Harbor, this reads /api/bongos/me to show a Sealed notice for
// non-Archons — DEFENCE IN DEPTH only. GET /gate-approvals + POST
// /gate-approvals/:pr/approve are ALSO archon-gated server-side (ADR 0016), and
// the page itself is gated by server.js requireArchonPage. On 401 → web sign-in.

(() => {
  'use strict';

  const API = '/api/bongos';
  // Generated typed client (task 1996 / R09), served as window.BongosClient by
  // /lib/bongos-client.js. baseUrl:'' passes the full `${API}${path}` URLs below
  // through unchanged; result-mode ({ status, ok, data }) preserves control flow 1:1.
  const api = window.BongosClient.createClient({ baseUrl: '', credentials: 'same-origin', throwOnError: false });
  const { escapeHtml, fmtInt } = window.OTB;
  const toast = (msg) => window.OTB.toast(msg);

  // ---- fetch helpers (mirror harbor.js / watch.js) -------------------------

  async function fetchJson(path) {
    const res = await api.request('GET', `${API}${path}`);
    if (res.status === 401) { window.location.assign(`${API}/auth/web/start`); throw { kind: '401' }; }
    if (res.status === 403) { throw { kind: '403' }; }
    if (!res.ok) throw new Error(`${path} → ${res.status}`);
    return res.data;
  }

  async function sendJson(method, path, body) {
    const res = await api.request(method, `${API}${path}`, { body: body || {} });
    if (res.status === 401) { window.location.assign(`${API}/auth/web/start`); throw { kind: '401' }; }
    const data = res.data || {};
    if (!res.ok) throw new Error(data.message || data.error || `${path} → ${res.status}`);
    return data;
  }

  // ---- formatters ----------------------------------------------------------

  const shortSha = (s) => (typeof s === 'string' ? s.slice(0, 7) : '');
  const VERDICT_LABEL = { escalate: 'Hard floor', needs_trust: 'Needs trust', pass: 'Clear' };
  const verdictLabel = (v) => VERDICT_LABEL[v] || (v || 'held');

  // ---- modal (mirrors harbor) ----------------------------------------------

  function closeModal() {
    const root = document.getElementById('gate-modal-root');
    if (root) root.innerHTML = '';
  }

  function openModal({ title, bodyHtml, confirmLabel, onConfirm }) {
    const root = document.getElementById('gate-modal-root');
    root.innerHTML = '';
    const bg = document.createElement('div');
    bg.className = 'gate-modal-bg';
    bg.innerHTML =
      `<div class="gate-modal" role="dialog" aria-modal="true">
        <h2>${escapeHtml(title)}</h2>
        ${bodyHtml}
        <div class="gate-modal__actions">
          <button class="gate-btn gate-btn--ghost" data-act="cancel">Cancel</button>
          <button class="gate-btn" data-act="confirm">${escapeHtml(confirmLabel)}</button>
        </div>
      </div>`;
    bg.addEventListener('click', (e) => { if (e.target === bg) closeModal(); });
    bg.querySelector('[data-act=cancel]').addEventListener('click', closeModal);
    bg.querySelector('[data-act=confirm]').addEventListener('click', () => onConfirm(bg));
    root.appendChild(bg);
  }

  // ---- actions -------------------------------------------------------------

  function confirmApprove(pr) {
    const floors = (pr.reasons || []).filter((r) => r.hard_floor).map((r) => r.path);
    const what = floors.length
      ? `the hard-floor surface ${floors.slice(0, 3).map((p) => `<code>${escapeHtml(p)}</code>`).join(', ')}`
      : 'a protected build surface';
    openModal({
      title: `Approve PR #${pr.number}?`,
      bodyHtml:
        `<p>Record your owner approval for <strong>${escapeHtml(pr.title || `PR #${pr.number}`)}</strong>${pr.task ? ` (task ${pr.task})` : ''}.</p>
         <p>This clears ${what}. The gate check re-runs and the PR merges once it goes green. Your approval applies only to commit <code>${escapeHtml(shortSha(pr.head_sha))}</code> — a later push must be re-approved.</p>`,
      confirmLabel: 'Approve & re-run',
      onConfirm: async (modal) => {
        const btn = modal.querySelector('[data-act=confirm]');
        if (btn) { btn.disabled = true; btn.textContent = 'Approving…'; }
        try {
          const r = await sendJson('POST', `/gate-approvals/${pr.number}/approve`, {});
          toast(r.message || 'Approval recorded.');
          closeModal();
          load();
        } catch (err) {
          if (err && err.kind === '401') return;
          if (btn) { btn.disabled = false; btn.textContent = 'Approve & re-run'; }
          toast(`Could not approve: ${err.message || err}`);
        }
      },
    });
  }

  // ---- render --------------------------------------------------------------

  function renderCrate(pr) {
    const mod = pr.verdict === 'needs_trust' ? 'needs_trust' : 'escalate';
    const reasonsHtml = (pr.reasons || []).map((r) =>
      `<li><code>${escapeHtml(r.path)}</code> — <span class="${r.hard_floor ? 'floor' : ''}">${r.hard_floor ? '⚑ ' : ''}${escapeHtml(r.reason)}</span></li>`
    ).join('') || '<li>This PR is held by the gate-review check.</li>';

    const files = pr.files || [];
    const shownFiles = files.slice(0, 12).map((f) => `<code>${escapeHtml(f.path)}</code>`).join(' · ');
    const moreFiles = files.length > 12 ? ` · +${files.length - 12} more` : '';
    const filesHtml = files.length
      ? `<p class="gate-files">Changed files (${files.length}): ${shownFiles}${moreFiles}</p>`
      : '';

    const taskHtml = pr.task
      ? `<a href="/#/task/${encodeURIComponent(pr.task)}">task ${escapeHtml(String(pr.task))}</a> · `
      : '';
    const trustedPill = pr.author_trusted
      ? `<span class="gate-pill gate-pill--trusted">author trusted</span>` : '';

    const actionsHtml = pr.already_approved
      ? `<span class="gate-approved-note">✓ Approved — re-check pending.</span>`
      : `<button class="gate-btn" data-act="approve">Approve</button>`;

    const el = document.createElement('article');
    el.className = `gate-crate gate-crate--${mod}`;
    el.innerHTML =
      `<div class="gate-crate__seal" aria-hidden="true"></div>
       <div class="gate-crate__body">
         <div class="gate-crate__head">
           <span class="gate-crate__title"><a href="${escapeHtml(pr.url)}" target="_blank" rel="noopener">${escapeHtml(pr.title || `PR #${pr.number}`)}</a></span>
           <span>
             <span class="gate-pill gate-pill--${mod}">${escapeHtml(verdictLabel(pr.verdict))}</span>
             ${trustedPill}
           </span>
         </div>
         <p class="gate-crate__meta">
           ${taskHtml}<a href="${escapeHtml(pr.url)}" target="_blank" rel="noopener">#${escapeHtml(String(pr.number))}</a>
           · by ${escapeHtml(pr.author || 'unknown')} · <code>${escapeHtml(shortSha(pr.head_sha))}</code>
           · <a href="${escapeHtml(pr.url)}/files" target="_blank" rel="noopener">view diff ↗</a>
         </p>
         <ul class="gate-reasons">${reasonsHtml}</ul>
         ${filesHtml}
         <div class="gate-actions">${actionsHtml}</div>
       </div>`;

    const approveBtn = el.querySelector('[data-act=approve]');
    if (approveBtn) approveBtn.addEventListener('click', () => confirmApprove(pr));
    return el;
  }

  function renderSummary(awaiting) {
    const floors = awaiting.filter((p) => p.verdict === 'escalate').length;
    const trust = awaiting.filter((p) => p.verdict === 'needs_trust').length;
    const stats = [
      ['Awaiting your approval', fmtInt(awaiting.length)],
      ['Hard-floor holds', fmtInt(floors)],
      ['Trust holds', fmtInt(trust)],
    ];
    document.getElementById('gate-summary').innerHTML = stats.map(([label, value]) =>
      `<div class="gate-stat"><div class="gate-stat__label">${escapeHtml(label)}</div><div class="gate-stat__value">${value}</div></div>`).join('');
  }

  async function load() {
    const list = document.getElementById('gate-list');
    const checkingEl = document.getElementById('gate-checking');
    let resp;
    try {
      resp = await fetchJson('/gate-approvals');
    } catch (err) {
      if (err && err.kind === '401') return;
      if (err && err.kind === '403') { showSealed(); return; }
      list.innerHTML = `<p class="gate-empty">Could not load held pull requests just now.</p>`;
      return;
    }

    const awaiting = resp.awaiting || [];
    renderSummary(awaiting);

    if (awaiting.length === 0) {
      list.innerHTML = `<p class="gate-empty">Nothing is waiting — no held changes need your approval.</p>`;
    } else {
      list.innerHTML = '';
      for (const pr of awaiting) list.appendChild(renderCrate(pr));
    }

    if (resp.checking > 0) {
      checkingEl.hidden = false;
      checkingEl.textContent = `${resp.checking} more PR${resp.checking === 1 ? '' : 's'} still being checked — refresh shortly.`;
    } else {
      checkingEl.hidden = true;
    }
  }

  function showSealed() {
    document.getElementById('gate-sealed').hidden = false;
    document.getElementById('gate-body').hidden = true;
    document.getElementById('gate-sub').textContent = 'Restricted.';
  }

  async function init() {
    // Confirm rank=archon for a friendly sealed notice; the server gates the page
    // + every endpoint regardless (cosmetic defence-in-depth).
    let me;
    try {
      me = await fetchJson('/me');
    } catch (err) {
      if (err && err.kind === '401') return;
      if (err && err.kind === '403') { showSealed(); return; }
      me = null;
    }
    const rank = (me && (me.builder || me).rank || '').toLowerCase();
    if (rank !== 'archon') { showSealed(); return; }

    document.getElementById('gate-sub').textContent = 'Changes touching protected build surfaces, held for your approval.';
    document.getElementById('gate-body').hidden = false;
    await load();
  }

  init();
})();
