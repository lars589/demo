-- 039_newcomer_friendly_column.sql — V3.R15: tasks.newcomer_friendly column +
-- view-level filter + Xenos claim-policy error code.
--
-- Context: V3.R15 (#239) was planned as the row-level "newcomer-friendly task"
-- gate for the Xenos rank. In parallel, #360 / ADR 0018 (migration 029) shipped
-- the same idea under the name `xenos_claimable`. Now V3.R15 closes by:
--
--   1. Renaming `xenos_claimable` → `newcomer_friendly` (the task's canonical
--      name — describes the *property of the task*, not "who is allowed").
--      This is a pure rename: the column already has DEFAULT false and the
--      existing values are preserved.
--
--   2. Rebuilding `claimable_tasks` and `tasks_session_fit` so the renamed
--      column flows through `SELECT t.*`. (Same body as migration 028 — the
--      only change is the implicit column list.)
--
--   3. View-level filter is realized in `db.js` listClaimableTasks: when the
--      caller is a Xenos, the SELECT adds `WHERE newcomer_friendly = true`.
--      The view itself stays builder-agnostic — applying the per-rank filter
--      inside the view body isn't possible (views can't read session context).
--      Belt-and-braces: `claimTask` still re-checks at claim time and returns
--      `rank_too_low_for_task` (the V3.R15 error code; XENOS_RESTRICTED is kept
--      as a code-side alias for callers on the pre-rename release).
--
--   4. Tag at least 3 currently-open backlog tasks as newcomer_friendly=true so
--      the queue isn't empty when a Xenos arrives. Done inline at the bottom.
--
-- Idempotent: safe to re-run. The rename uses an IF EXISTS guard; the view
-- rebuilds DROP+CREATE. The tagging UPDATE is keyed on still-open backlog rows
-- so re-runs don't churn shipped tasks.

-- 1. RENAME the column. Use a DO block so re-runs are safe whether or not the
-- rename has already happened.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_name = 'tasks' AND column_name = 'xenos_claimable'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_name = 'tasks' AND column_name = 'newcomer_friendly'
  ) THEN
    ALTER TABLE tasks RENAME COLUMN xenos_claimable TO newcomer_friendly;
  END IF;
END $$;

-- Defensive add — only fires if a fresh DB skipped migration 029 entirely.
ALTER TABLE tasks
  ADD COLUMN IF NOT EXISTS newcomer_friendly boolean NOT NULL DEFAULT false;

-- 2. Rebuild the two SELECT t.* views so the renamed column flows through.
-- Same bodies as migration 028.

DROP VIEW IF EXISTS claimable_tasks;
CREATE VIEW claimable_tasks AS
SELECT t.*,
       pms_calibrated_minutes(t.est_minutes, t.kind) AS est_minutes_calibrated
  FROM tasks t
 WHERE t.status = 'ready'
   AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
   AND NOT EXISTS (
     SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id
   )
   AND NOT EXISTS (
     SELECT 1 FROM claims c
       JOIN tasks t2 ON t2.id = c.task_id
      WHERE c.released_at IS NULL
        AND t2.touches && t.touches
   );

DROP VIEW IF EXISTS tasks_session_fit;
CREATE VIEW tasks_session_fit AS
SELECT t.*,
  CASE
    WHEN t.automation_tag = 'overnight-safe' AND COALESCE(t.manual_degree, 5) <= 2
         AND NOT EXISTS (SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id)
      THEN ARRAY['autonomous','check-in','active']
    WHEN t.automation_tag = 'live-only' OR COALESCE(t.manual_degree, 5) >= 4
      THEN ARRAY['active']
    ELSE ARRAY['check-in','active']
  END AS fits_session_modes,
  pms_calibrated_minutes(t.est_minutes, t.kind) AS est_minutes_calibrated,
  CASE
    WHEN t.credits_reward > 0
     AND pms_calibrated_minutes(t.est_minutes, t.kind) IS NOT NULL
     AND pms_calibrated_minutes(t.est_minutes, t.kind) > 0
    THEN ROUND(t.credits_reward::numeric / pms_calibrated_minutes(t.est_minutes, t.kind), 3)
    ELSE NULL
  END AS credits_per_minute
FROM tasks t;

-- 4. Tag at least 3 currently-open V3 backlog tasks as newcomer_friendly so a
-- freshly-onboarded Xenos has something safe to claim. Pick small, well-scoped
-- cleanup/docs work — anything mechanical and low-stakes. Match titles to
-- specific shipped concepts (renumbering, docs polish, small cleanups) so the
-- set is stable across DB states. Use NOT-already-set guard so re-runs are
-- no-ops.
--
-- Three specific picks (all V3.R* tasks, all kind in ('cleanup','docs'), all
-- short or unestimated):
--   - any V3.R*-prefixed task with kind='docs' and status='backlog'
--   - any V3.R*-prefixed task with kind='cleanup' and status='backlog'
--   - any V3.R*-prefixed task with est_minutes<=45 and status='backlog'
-- LIMIT 3 from the union; pick smallest est_minutes first. The select-into
-- pattern stays safe even when the DB has zero matching rows (the UPDATE
-- simply touches nothing).
WITH candidates AS (
  SELECT id
    FROM tasks
   WHERE status = 'backlog'
     AND version_id = 'GDS-V3'
     AND newcomer_friendly = false
     AND (
       kind IN ('cleanup', 'docs')
       OR (est_minutes IS NOT NULL AND est_minutes <= 45)
     )
   ORDER BY COALESCE(est_minutes, 999), id
   LIMIT 3
)
UPDATE tasks SET newcomer_friendly = true, updated_at = now()
 WHERE id IN (SELECT id FROM candidates);

INSERT INTO schema_migrations (version) VALUES ('039_newcomer_friendly_column')
  ON CONFLICT (version) DO NOTHING;
