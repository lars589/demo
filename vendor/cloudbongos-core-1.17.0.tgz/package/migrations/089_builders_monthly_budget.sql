-- migration 089: per-builder monthly spend budget (V3.R84 / task 302, criterion C3)
--
-- C3 wants each builder to ship under their OWN cost ceiling, with a soft-cap
-- warning before they hit it and a hard-cap refusal at it. This column is the
-- per-builder override; NULL means "use the project default"
-- (cost.DEFAULT_MONTHLY_BUDGET_USD) so the global default can move without a
-- migration. An Archon sets a non-null value via PATCH /builders/:id/budget to
-- raise or lower a specific builder's ceiling.
--
-- Spend is month-to-date over cost_log.recorded_at (date_trunc('month', now())),
-- attributed by cost_log.builder_id (migration 046). No new spend column — the
-- ledger already records every dollar; this only stores the ceiling.

ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS monthly_budget_usd numeric;

-- Counter hygiene: keep the migration-number allocator above this file so the
-- next reservation can't collide with 089.
UPDATE migration_counter SET next_number = GREATEST(next_number, 90) WHERE id = 1;
