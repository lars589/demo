# ADR 0127 — Cross-box fleet observability on the control-plane droplet

Status: Accepted (2026-07-05, task [#2059](https://example.com/builders#/task/2059))

## Context

Task 2020 stood up Grafana + Prometheus on the co-hosting box, scraping that one
box's Bongos API. The owner then re-scoped it: the exported metrics (`gds_http`,
`gds_tasks`, `gds_claims`, `gds_builders`, `gds_auth_failures`) measure the **Bongos
platform API**, not any single game — so the dashboards are *platform* observability
and belong on the **cloudbongos** domain, watching **every** instance, not a
project-specific one.

Then [ADR 0126](<redacted>.md) moved
cloudbongos.com onto a dedicated **control-plane droplet** (REDACTED_IP) that
holds the account-wide Cloudflare token and serves `*.cloudbongos.com`. That split
the fleet across two droplets:

- **control-plane box** (REDACTED_IP): `cloudbongos` instance.
- **co-hosting box** (REDACTED_IP): `example` (the game) + `emersonian-circles`.

So platform observability must (a) live where a `metrics.cloudbongos.com` surface
belongs — the control-plane box (it has the cloudbongos origin cert + Caddy + the
DNS token), and (b) scrape instances on **both** boxes. The apps' `/metrics`
exporters bind `127.0.0.1` only, and a remote scrape normally needs a `METRICS_TOKEN`
(Bearer). Both droplets share a DigitalOcean **private VPC** (`10.108.0.0/20`).

## Decision

- **Grafana + Prometheus run on the control-plane box.** `metrics.cloudbongos.com`
  (proxied A record → REDACTED_IP, on the `*.cloudbongos.com` origin cert) is
  reverse-proxied to Grafana, Archon-only (Caddy `basic_auth` + Grafana admin login).
- **Prometheus scrapes the whole fleet with a per-`project` label.** `cloudbongos`
  is local (`127.0.0.1:3002`). The co-hosting box's instances are scraped **over the
  private VPC** via two tiny `socat` TCP forwarders on that box (`metrics-fwd-*`
  systemd units) bound to its private IP (`10.108.0.2:9101→127.0.0.1:3000`,
  `:9102→:3004`), **ufw-locked to the control-plane box's private IP** only.
- **socat (raw TCP relay), not a Caddy/token proxy, for the cross-box hop.** A raw
  relay preserves the exporter's loopback-with-no-`X-Forwarded-For` semantics, so the
  app serves metrics **without a token and without a restart**. The security boundary
  is the private VPC + the ufw allow-list (only the control-plane box) + the fact that
  the control-plane box is already the most-trusted host in the fleet. The exporter's
  `METRICS_TOKEN` Bearer path is **reserved for future off-VPC / dedicated-droplet
  instances**, which can't use a private forwarder.
- Dashboards gain a `project` template variable; every query filters by
  `project=~"$project"` (default All), so each panel shows one instance or the fleet.

## Consequences

- **+** Clean separation matching ADR 0126: the cloudbongos-branded metrics surface
  lives on the cloudbongos box, not the game box. One fleet-wide pane. Neither
  Prometheus nor Grafana is publicly bound; the cross-box hop never leaves the VPC.
  No live-game restart was needed to wire it.
- **−** Each socat forwarder exposes the **whole** app port (not just `/metrics`) to
  the control-plane box over the VPC. Accepted: ufw restricts the source to the one
  trusted control-plane IP, the traffic stays on the private VPC, and a compromise of
  the control-plane box is already game-over (it holds the account-wide CF + DO
  tokens). A `/metrics`-only exposure would require a Caddy proxy + `METRICS_TOKEN` +
  restarting the instances — not worth it for this trust posture.
- **−** Cross-box scraping depends on the DO VPC + the `metrics-fwd-*` units + ufw
  rules on the co-hosting box. If that box is re-provisioned, re-add them (see
  [`infra/grafana/README.md`](../../infra/grafana/README.md)).
- **Follow-up:** token-based (or DNS-SD) discovery for provisioned / dedicated-droplet
  instances — the general hosting-module case, not yet wired.
