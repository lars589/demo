# ADR 0075 — Per-system cost attribution + the savings counterfactual ledger

**Status:** Accepted (2026-06-20) · tasks [#1343](https://example.com/builders#/task/1343) [#1344](https://example.com/builders#/task/1344) [#1345](https://example.com/builders#/task/1345) [#1346](https://example.com/builders#/task/1346) · System 1 of the Cloud Bongos LLM-reduction redesign (spike [#1326](https://example.com/builders#/task/1326))

## Context

The 2026-06-20 efficiency audit ([`docs/audits/gds-efficiency-2026-06-20.md`](../audits/gds-efficiency-2026-06-20.md)) found real spend ~2× the annual budget, with **~82% concentrated in a few dozen Opus "marathon" sessions** whose cost is overwhelmingly `cache_read` (a growing context re-billed every turn for hours). But that finding was an **inference**: the ledger could not prove it, because `cost_log` lumped every LLM call into one untagged `amount_usd` row with no tier breakdown, and the price table had drifted to Opus 4.1 rates (3× too high). You cannot greenlight, tune, or defend a cut you cannot see — so the redesign's first system makes the spend *queryable per call-site and per tier*, and gives every later system a dollar-denominated place to prove its savings.

## Decision

Four shipped changes turn the inference into instrumentation:

1. **1M-pricing correction (task 1343).** `llm-pricing.js` is corrected to the live Anthropic list rates — opus (4.8/4.7) **$5 in / $25 out**, sonnet (4.6) $3/$15, haiku (4.5) $1/$5 — **flat across the full 1M window with no long-context premium** (verified against the platform models/pricing page). There is deliberately **no `>200K` tier table**: do not add one unless Anthropic introduces a long-context surcharge. `priceUsage()` now also returns a per-tier `components` split (fresh input / cache-read / cache-write 5m+1h / output) that it previously computed and discarded.

2. **Source taxonomy (task 1344).** The single legacy `source='session'` `cost_log` row is split into **two call-site-tagged rows per session**, distinct on the `(source, source_ref)` idempotency index:
   - `session:<redacted> — the builder's own transcript (`source_ref = <session-id>`).
   - `session:<redacted> — that session's ad-hoc Agent/Task subagents (`source_ref = <session-id>:sub`); grader-signature transcripts stay excluded (already captured via the [#486](https://example.com/builders#/task/486) worker envelope — the ADR 0028 non-double-count invariant).
   - A **cron-launched** session sets `OTB_COST_CRON_ROUTINE=<name>`, so its rows are tagged `cron:<routine>:interactive` / `cron:<routine>:subagent`. Wiring each routine to export this var is follow-on (System 4); until then cron sessions fall back to `session:*`.

   Each row carries a four-tier USD split persisted in new **nullable** `cost_log` columns (migration 123): `fresh_input_usd`, `cache_read_usd`, `cache_write_usd` (5m+1h summed), `output_usd`. For session/cron rows the four sum to `amount_usd` by construction; legacy and non-LLM rows (manual/infra/`box-lifecycle` compute) stay NULL.

3. **The savings counterfactual ledger (task 1345).** A tiny new table `cost_baseline` (migration 124) is where each later system records what a run cost (`amount_usd`) versus what it *would* have cost had the system not acted (`baseline_usd`), tagged by `system`. **Contract: `baseline_usd` is ALWAYS computed server-side from real token counts via `priceUsage()` — never a client-supplied dollar figure** (the same trust rule as the cost-plus reward, ADR 0054). The saving is `SUM(baseline_usd − amount_usd)` grouped by system. `db.costSummary()` gains three **additive** blocks — `by_source`, `by_tier` (with the headline `cache_read_pct`), and `savings` — shaped by a pure, unit-tested module (`cost-summary-shape.js`).

4. **Additive endpoint contract.** All of the above surfaces through the **unchanged** `GET /api/gds/public/cost-summary` passthrough: every pre-existing key keeps its exact shape; the new keys are added alongside. The `savings` query is guarded against a missing `cost_baseline` table (`42P01`) so a pre-migration window degrades to empty savings rather than 500ing the public status dashboard. The audit (`cost.js auditCostAttribution` / `formatAuditReport`, task 1346) folds in `by_source`, the `cache_read` share of LLM-priced spend, and per-system `eliminated_usd`, plus a **tripwire** (`savings_without_baseline`) that warns when a system appears in the savings ledger with no `priceUsage` baseline behind it — a saving that cannot be verified.

## Consequences

- The 82%-cache_read claim is now a column (`cost_log.cache_read_usd`) and a headline (`by_tier.cache_read_pct`), not an inference — the baseline System 2 reads and must move.
- Every later system (2–5) reports its savings into one comparable, server-priced ledger; "we saved X" becomes a query, not a slide.
- **Migrations 123 + 124 are additive only** (nullable columns / a new table / indexes) and must deploy *before or with* the code (the morning `~/deploy.sh` runs migrations then restarts, so co-deploy is safe; the guard covers any gap).
- The historical `cost_log` is still ~3× overstated on the pre-correction opus rows, and the drachma reward over-paid ~3× for opus work before task 1343. **Recomputing/backfilling that history is an owner decision** (clawing back reward history is explicitly out of scope for the overnight build) — the correction fixes spend and rewards going forward only.
- The cron-source tags are inert until the cron routines export `OTB_COST_CRON_ROUTINE` (System 4 wires them); session-cost.js reading the var is the mechanism, not the wiring.

## Reproduce / verify

- Live: `node scripts/gds/api.js GET /api/gds/public/cost-summary` → now carries `by_source`, `by_tier`, `savings`.
- Pure tests (DB-free): `tests/llm-pricing.mjs`, `tests/session_cost.mjs`, `tests/cost_summary_shape.mjs`, `tests/cost.mjs`.
