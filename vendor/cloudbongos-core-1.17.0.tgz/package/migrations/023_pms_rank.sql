-- V3.R05 (#106): Builder rank system — ancient-Greek hierarchy.
--
-- Authority lives in ONE place: builders.rank, on the production DB, checked
-- server-side per request with no caching (see ADR 0016). This migration adds
-- the rank column; the FOUNDING admin is no longer hard-coded here. It is seated
-- at first enrollment from instance config (the configured firstAdmin), idempotent
-- and only while no Archon exists yet — see src/bongos/auth.js maybeSeatFirstAdmin
-- (ADR 0062 R62 / task 1201). This keeps the build-system core free of any one
-- instance's owner identity; the live instance was already seated by the original
-- form of this migration, so prod is unaffected.
--
-- Live ranks for V3: Archon + Thetes. The full enum is reserved up front so
-- future ranks (the reserved ladder in task #106) don't need a schema change —
-- adding a rank to the live set later is a code-only change (route grants),
-- never a migration.

ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS rank text NOT NULL DEFAULT 'thetes'
    CHECK (rank IN (
      -- Divine — above-the-system
      'olympian', 'hermes', 'oracle', 'demigod',
      -- Citizen — the working ladder (archon + thetes LIVE in V3)
      'archon', 'strategos', 'boule', 'aristoi', 'hippeis', 'zeugitai', 'thetes',
      -- Outsider / sub-citizen — sandboxed
      'metic', 'xenos', 'periokoi', 'doulos', 'helot'
    ));

-- No founding-admin literal here (R62 / task 1201): a fresh install seats its
-- configured firstAdmin in code, at that account's first enrollment, only while
-- no Archon exists. Every builder defaults to 'thetes' via the column default.
