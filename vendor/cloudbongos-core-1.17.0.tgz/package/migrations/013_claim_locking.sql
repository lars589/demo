-- Claim session lock — closes the cross-session claim-interference hole
-- described 2026-05-11.
--
-- The bug: builder has claim A active in session-A (terminal 1). Session-B
-- (terminal 2) calls /builder-release — same builder_id passes the existing
-- NOT_YOUR_CLAIM check — drops claim A, then claims a conflicting task.
-- Session-A has no idea its claim was released and keeps working. Both
-- sessions advance changes to the same files; only one wins at ship time.
--
-- Fix: record which session created each claim. The resolve endpoint
-- enforces that only the creator session can ship or release it. A different
-- terminal (different session token) gets CLAIM_SESSION_MISMATCH (403).
-- Use --force on /builder-release as an emergency escape hatch when the
-- original terminal is gone.
--
-- Parallel non-conflicting claims (different touches[]) are still allowed —
-- this change only prevents cross-session resolve, not cross-session claiming.
ALTER TABLE claims
  ADD COLUMN IF NOT EXISTS creator_session_id bigint REFERENCES builder_sessions(id);

INSERT INTO schema_migrations (version) VALUES ('013_claim_locking')
  ON CONFLICT (version) DO NOTHING;
