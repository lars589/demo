# ADR 0120 — Pay drachmae on land (not on confirm) + a builder-owned rebase gate

**Date:** 2026-07-04
**Status:** Accepted
**Discipline:** engineer (GDS / economy + lifecycle)
**Task:** [#2035](https://example.com/builders#/task/2035) (BONGOS-V1)

## Context — the problem

The per-task drachmae reward is awarded in **`confirmTask`** (`modules/lifecycle/db.js`,
`reward.insertMultipliedConfirmCredit`, `credit_log.reason = 'task.confirmed'`) — at the
`completed → confirmed` transition. Confirmed means *verified + credited*, but the code is
**not yet on `main`**: the merge to `main` + deploy is the later `confirmed → shipped`
transition, run by the auto-lander / `publish-reconciler`.

So a builder is paid the moment they declare done and pass verification — **before their
code lands.** When the branch then can't merge (stale after a big codebase change, a real
conflict, or never pushed at all), the task strands at `confirmed` indefinitely with **no
consequence to the builder**: they already have the drachmae, and nothing stops them
claiming new work while the stranded branch rots.

This is not hypothetical. On 2026-07-04 the confirmed queue held ~17 tasks across three
builders — several never pushed to the remote at all (the commits lived only on the
builder's machine), one 154 commits behind `main` across the `src/gds → src/bongos`
rename. Only the original builder can rebase their own stranded branch; but the incentive
structure gave them no reason to, and no one else *can*. The reward was decoupled from the
outcome we actually want (landed code).

## Decision

Re-couple reward and queue-access to **landed code**, in four parts.

1. **Pay on land, not on confirm.** Move BOTH reward writes from the `confirmed`
   transition to the `shipped` (merged-to-`main`) transition:
   - the per-task credit (`insertMultipliedConfirmCredit` + the idea-promotion bonus), and
   - the cost-plus session-token reward ([ADR 0054](<redacted>.md)).

   The award becomes idempotent on ship (`credit_log.reason = 'task.shipped'`, guarded by a
   uniqueness check per task, mirroring today's confirm-time guard). **The happy path barely
   changes:** a clean PR auto-merges within a minute or two of confirm, so the credit lands
   almost immediately. The teeth only bite when a task strands — no landed code, no drachmae.

2. **A stalled land becomes the builder's own chore (`needs_rebase`).** The
   `publish-reconciler` already detects why a confirmed task won't land — `merge_conflict`,
   a failing required check against current `main`, or no pushed branch. After the normal
   auto-land grace (the reconciler's existing retries + the [ADR 0082](<redacted>.md)
   generated-file self-heal) is exhausted, it flags the task `needs_rebase = true`, attributed
   to the **claim holder** (the builder who did the work — the same attribution rule as
   `confirmTask`, task 661). This is a signal, not a status change: the task stays `confirmed`
   (its work is done), it is simply marked as awaiting *its builder's* rebase.

3. **A `needs_rebase` task blocks that builder's NEW claims — not their existing ones.**
   `claimTask` / `POST /claims` gains a precondition: refuse a **new** claim
   (`409 { error: 'REBASE_REQUIRED' }`, naming the offending task(s)) when the builder has
   any `needs_rebase` task. Their already-active claims still resolve/ship normally — we
   don't freeze in-flight work, we only stop them taking on *more* while a landing chore is
   outstanding. Since the reward is now contingent on landing (part 1), the builder is
   motivated to clear it; since it gates their queue, they can't walk away from it.

4. **One-time clawback + re-gate for the existing confirmed backlog.** A migration reverses
   the `task.confirmed` credit deltas for every task currently at `status = 'confirmed'`
   (a compensating negative `credit_log` row per task, `reason = 'task.confirmed_reversal'`,
   so the `builders.total_credits` trigger rolls it back; achievements already unlocked are
   left intact — reversing gamification is punitive and messy) and sets `needs_rebase = true`
   on those tasks. This applies the new incentive to the work that stranded under the old
   rule, rather than grandfathering it. It hits every affected builder, the owner included.

Together: **a builder's pay AND their ability to pick up new work both hinge on their code
being on `main`** — and the rebase after a big codebase change falls on the one person who
can do it.

## Consequences

- **Good behavior is unaffected.** Clean work still auto-lands in minutes and pays out then;
  most builders never see `needs_rebase` or the gate.
- **Stranding now has teeth.** No landed code → no drachmae, and a stalled land blocks new
  claims until the builder rebases (or releases the task, forfeiting its reward).
- **The credit ledger tells the truth.** `credit_log` credits now correspond to code that is
  actually on `main`, not to verified-but-unlanded branches.
- **Retroactive sting.** The clawback reverses already-shown drachmae for currently-stranded
  tasks. This is intentional (it creates the pressure) and is applied uniformly, but it will
  feel punitive to builders who were paid under the old rule. The reversal is fully re-earnable:
  land the task and the `task.shipped` credit books.
- **A genuinely un-rebaseable task must have an exit.** A builder blocked by a task they
  truly cannot land can `release` it (freeing it, forfeiting the reward) to unblock their
  queue — so no one is ever permanently stuck.
- **New surfaces to keep honest.** `needs_rebase` is a new lifecycle signal the reconciler
  writes and the claim gate + hall/CLI read; the reward-timing move touches the economy
  `reward` port and the sessions reward path. All are covered by the seeded tasks' tests.

## Alternatives considered

- **Keep paying at confirm, add only the gate.** Rejected: the reward is the strongest lever;
  leaving it at confirm means a stranded task still paid out, so the builder's only cost is a
  queue block they can dodge by releasing — weak alignment.
- **Soft gate (warn, don't block).** Rejected per the owner's call: a warning is ignorable and
  stranded work kept accumulating exactly because nothing enforced it.
- **Grandfather the existing confirmed backlog.** Rejected per the owner's call: it would leave
  the current stranded tasks paid-and-unblocked, precisely the state this ADR exists to end.
- **Only per-task credit waits for land; session reward stays at confirm.** Rejected per the
  owner's call in favor of fullest alignment — nothing pays until the code is on `main`.

## Implementation

Seeded as tasks under this ADR (dependencies noted): pay-on-land (economy + lifecycle) →
`needs_rebase` state + reconciler flag (lifecycle + migration) → claim gate (lifecycle/claims)
→ clawback migration (depends on pay-on-land being live) → hall + `/builder-start` surfacing →
tests. See the [#2035](https://example.com/builders#/task/2035) dependency graph.
