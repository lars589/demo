-- migrations/093_tasks_sandbox_review.sql
-- Task #1048 (GDS-V4) — record the builder's sandbox self-approval as a durable
-- fact on the task. ADR 0046 follow-up.
--
-- The sandbox-first review gate (#927, ADR 0046) previously recorded the
-- "reviewed on the sandbox and approved" decision ONLY in an ephemeral temp-dir
-- marker (otb-sandbox-staged.json) that vanished after the ship — nothing
-- durable said this exact game build was reviewed and signed off. Lars's
-- 2026-06-13 directive: that approval must be recorded. We persist it as a small
-- JSONB blob on the task, written by db.resolveClaim from the value ship.js
-- threads through POST /claims/:id/resolve.
--
-- Shape (server stamps `by`/`at` authoritatively; the rest is client-supplied):
--   { "by": "<github_login>", "at": "<iso8601>", "stamp": "<sha256>",
--     "url": "https://sandbox-<login>.amazonprimea.com", "method": "tty"|"flag" }
-- NULL = no sandbox review recorded for this task (laptop ship, non-game diff,
-- quick-tunnel box, --skip-stage, or a fresh-marker re-run without --approved).
--
-- Idempotent + re-runnable.

ALTER TABLE tasks
  ADD COLUMN IF NOT EXISTS sandbox_review jsonb;
