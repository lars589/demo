# 0026 — The BFG: documentation/memory hygiene + cross-builder learning + transparent correction

- **Status:** Accepted + Shipped. Phase 6 of the MAS is **built** — implemented in [`modules/sessions/bfg.js`](../../modules/sessions/bfg.js) (`scoreMemoryQuality`, `extractTransferablePatterns`, `buildCorrection`, …; carved into the `sessions` module at BV1.R82 / ADR 0093 §1).
- **Date:** 2026-05-30
- **Deciders:** Lars Kristensen (Archon), Claude
- **Track:** `internal` (GDS)
- **Context task:** GDS-V3 [#441](https://example.com/builders#/task/441) (this design task — ADR + task breakdown only; no implementation).

> **Numbering note:** this ADR was authored as `0025` but renumbered to **0026** on the same day, after a merge from `main` surfaced an already-shipped [`0025` — Offsite backup vendor](<redacted>.md) (task [#415](https://example.com/builders#/task/415)). The shipped ADR keeps `0025`; this one moves. The backlog implementation tasks **[#442](https://example.com/builders#/task/442)–[#448](https://example.com/builders#/task/448)** were filed *before* the renumber and so reference this ADR as "ADR 0025" in their descriptions (the GDS has no description-edit endpoint and there was no DB access to correct them in-session). The sub-phase labels (**6A.1 … 6C.3**) are stable and unambiguous — when a task says "ADR 0025 section 6A.1", read **this** ADR (0026), section 6A.1.
- **Extends:** [ADR 0024 — Multi-Agent System architecture](<redacted>.md) (the BFG is its Phase 6); [ADR 0024 — Cloneable repo + local-first memory](<redacted>.md) (the `builder_memory` store this operates on); [ADR 0016 — Trust boundary](<redacted>.md) (this ADR deliberately and narrowly *punctures* the no-cross-builder-write rule — recorded here as a conscious exception). Touches the karma model ([migration 040](../../migrations/040_builder_karma.sql)) and the memory schema ([migration 054](../../migrations/054_builder_memory.sql)).

## Context

The **BFG** is the post-ship / pre-cron role in the MAS ([ADR 0024-mas](<redacted>.md)). Its Phase-6 charter there was deliberately narrow: *"memory hygiene — audit CLAUDE.md claims against DB reality, prune stale references, verify `[[links]]` resolve."* No code has been written yet.

On 2026-05-30 Lars expanded the BFG's remit to **two standing objectives**:

1. **Cleanliness of all documentation** — `*.md`, memory files, and anything doc-shaped that lives in the DB. The index must not drift from reality.
2. **The best, most "creative/intelligent" building experience for builders.** The mechanism Lars named: read every builder's memory, evaluate *how* they interact with the system, and when a builder is performing well, study their memory and propose to other builders what they should adopt. The BFG may also **plant "dreams"** — write a memory directly into another builder's store when it's an obvious improvement — and apply **corrections** to misbehaving builders.

This ADR records the architecture and, critically, the **boundaries** that turn that intent into something safe to build.

### What the substrate already gives us

- **Builder memory is server-canonical and per-builder isolated** — [`builder_memory`](../../src/bongos/routes/memory.js), `PRIMARY KEY (builder_id, path)`. The *only* cross-builder access that exists today is an **Archon-only, audit-logged, read-only** forensic path. **There is no cross-builder *write* path at all** — that was a conscious decision ([ADR 0016](<redacted>.md), [ADR 0024-memory](<redacted>.md) §4).
- **Karma** ([`karma_log`](../../migrations/040_builder_karma.sql)) is the existing good-citizenship reputation ledger (append-only, `granted_by` records who drove a delta, `NULL` = system).
- **Cron roles** live as `SKILL.md` files under [`.claude/scheduled-tasks/`](../../.claude/scheduled-tasks/); the read-only `overnight-code-review` routine is the closest existing pattern.

## Decision

The BFG gains three capability clusters (6A / 6B / 6C), built as independently-shippable sub-phases. Two cross-cutting rules govern all of them:

- **The BFG is a privileged *system* agent, not a rank bypass.** Its cross-builder powers are the existing Archon-forensic-read posture, extended to a narrow audited write. They are bound to a dedicated **BFG service principal** (a `builders` row flagged as system: cannot claim work, cannot earn drachmae) and are reachable *only* by that principal — never exposed on a self-serve route. No human or agent builder can ask the system to "read/write another builder's memory." **This is an enforcement requirement, not prose intent:** 6C.1's write endpoint must gate on the *exact principal identity*, not on rank — an Archon token (or any rank-escalated / stolen token) must be rejected at the write endpoint, and that refusal must be covered by a test. "Never exposed on a self-serve route" is a property the implementation has to encode, not a promise the ADR can keep on its own.
- **Every cross-builder operation — read *and* write — writes an `audit_log` row.** Writes are additionally **namespaced and attributed** so a builder can always see, and delete, exactly what the BFG put there. Nothing the BFG writes ever masquerades as the builder's own note.

### 6A — Hygiene (the original charter, widened)

Read-only auditor. Findings land as `idea_inbox` rows (one per finding, like `overnight-code-review`) plus a `docs/audits/bfg-<date>.md` report. The BFG **never** auto-mutates code or DB state — it reports.

- **Doc ↔ reality:** CLAUDE.md claims vs DB (`shipped` task IDs cited, version statuses, the rank enum, drachmae/karma model), `[[link]]` resolution, ADR cross-reference integrity + numbering gaps, `docs/file-map.md` vs the actual tree, onboarding-diagram `assertions.json` vs live facts.
- **Memory hygiene:** within each builder's *own* memory dir — dangling `[[links]]`, stale frontmatter, internal contradictions, duplicate facts (the same discipline the `consolidate-memory` skill applies, but agent-driven rather than human-invoked).
- **DB cleanliness:** cached-counter vs ledger drift (`builders.karma` vs `karma_log`, `total_credits` vs `credit_log`), orphaned rows, long-stale `idea_inbox` / `blockers`. Reported, never silently "fixed."

### 6B — Cross-builder learning ("read the room")

- **Read all builders' memory** through a BFG-principal-only, per-read audit-logged endpoint (same shape as the Archon forensic read).
- **Score interaction quality** by blending objective GDS signals (ships, grader pass rate, rework/abandon rate, karma, drachmae, methodology adherence visible in `audit_log` + conductor traces) with memory-quality heuristics.
- **Extract *transferable* patterns** from top performers — working habits and durable lessons, **not** builder-specific secrets, PII, or anything that only makes sense in that builder's context.
- **Propagate** as adoption suggestions to other builders (delivered via the 6C write path as clearly-marked BFG entries, or surfaced in the audit report).

### 6C — Dreams & correction (the write path — the load-bearing part)

This sub-phase creates the **first cross-builder memory write capability** in the system. It is the deliberate, bounded exception to [ADR 0016](<redacted>.md).

**Dreams (beneficial writes).** Lars chose **direct write** (audited + visible) over propose-only, for immediacy. The BFG writes the entry directly into the target builder's memory, constrained by:
- a dedicated, clearly-marked location — e.g. `bfg/dream-<slug>.md` (or a fenced `## BFG dreams` block) — never overwriting a builder's own files;
- frontmatter `type: bfg-dream`, `author: BFG`, `source_builder`, `date`, `rationale`;
- an `audit_log` row per write (`action: 'bfg_dream_write'`, target builder, path, rationale);
- self-announcing content — the builder always sees it is BFG-authored and can delete it.

**Correction (misbehaving builders).** Lars's explicit call: **transparent, attributed correction — NOT covert sabotage.** A correction is:
- a **visible BFG-authored corrective note** (`type: bfg-correction`) stating the observed behavior, the rule it broke, and the expected change; plus
- a **negative `karma_log` delta** with `reason: 'bfg_correction'`, `granted_by` = the BFG principal.

> **Explicit non-goal — "nightmares" are rejected.** The original framing imagined the BFG planting *false or harmful* memories to covertly *worsen* a builder's experience. The system will **never** write deceptive or deliberately-degrading content into anyone's memory. A tool whose purpose is to sabotage a builder through deception is out of scope by design; "documenting it" does not make covert sabotage acceptable. Correction is honest, visible, and reversible — same steering effect, no deception. This clause is the durable record of *why* the capability stops here.

### Identity & invocation

The BFG runs as a `SKILL.md` scheduled routine (post-ship / pre-cron cadence) and can be nudged by the Phase-4 Conductor on index-doc edits. The cross-builder endpoints (6B read, 6C write) are gated to the BFG service principal server-side. The Phase-4 dispatch path treats the BFG as a read-mostly agent; only the 6C routine, running as the principal, may write.

### Phase plan (created as backlog tasks by [#441](https://example.com/builders#/task/441))

| Sub-phase | Scope | Earns it |
|---|---|---|
| **6A.1** | Read-only hygiene auditor: doc↔reality + `[[link]]`/ADR/file-map checks → `idea_inbox` + `docs/audits/bfg-<date>.md`. As a `SKILL.md` routine. | The index stops drifting; zero new write surface. Ship this first. |
| **6A.2** | Extend the auditor with memory-hygiene + DB cached-vs-ledger drift checks (still report-only). | Hygiene covers all three artifact classes. |
| **6B.1** | BFG-principal-only, audit-logged cross-builder memory **read** endpoint + interaction-quality scorer. | "Read the room" exists; reuses the forensic-read audit pattern. |
| **6B.2** | Transferable-pattern extraction from top performers + adoption-suggestion generation. | Good practice propagates; the "most creative experience" objective gets teeth. |
| **6C.1** | Migration: BFG service principal (system builder, no-claim/no-drachmae) + cross-builder memory **write** endpoint (audited, namespaced, attributed) + `karma_log` reason `bfg_correction`. | The write substrate + trust-boundary exception land in one reviewable unit. |
| **6C.2** | Wire dream-writes + transparent corrections into the BFG routine; kill-switch; builder-visible attribution; delete affordance. | Dreams + correction work end-to-end, safely. |
| **6C.3** | Update [ADR 0024-mas](<redacted>.md) Phase-6 row + CLAUDE.md MAS index line. (Deferred out of [#441](https://example.com/builders#/task/441) — `CLAUDE.md` / `0024` are held by the active Phase-4 claim `#439`.) | The index reflects the shipped BFG. |

Each sub-phase must answer "is this earning its tokens?" before the next is built — the Musk gate, same as [ADR 0024-mas](<redacted>.md).

> **Sibling capability cluster — 6D (session-inefficiency evaluator), recorded in [ADR 0027](<redacted>.md).** The 6A/6B/6C clusters above cover the BFG's *hygiene* and *cross-builder memory learning* objectives. A later, separately-chartered cluster — **6D** — serves the same "best building experience" objective from a different angle: it ingests uploaded session transcripts and auto-runs the #506-style post-mortem across all sessions to surface systemic build-process waste (and mine top performers for good practice). It reuses this charter's §6C transparent-note path to deliver per-builder findings. See [ADR 0027](<redacted>.md); build tasks GDS-V4 [#540](https://example.com/builders#/task/540)–[#545](https://example.com/builders#/task/545).

## Alternatives considered

- **Covert "nightmares" (rejected).** The original ask imagined planting *false or harmful* memories to covertly worsen a misbehaving builder. Rejected outright: it is deception that causes real harm (wasted work, decisions seeded by lies), it has no consent, and an audit trail does not redeem it. Transparent correction (a visible, attributed note + a karma dock) achieves the same steering with none of that. This is the load-bearing rejection of this ADR.
- **Propose-only writes vs direct writes.** Propose-only (the BFG drops a clearly-marked *suggestion* the builder must accept) best preserves the isolation/consent spirit. Lars chose **direct write** for immediacy on "obvious improvements." We keep the consent spirit alive through visible attribution + namespaced files + delete-ability + per-write audit, and accept the residual risk (memory changing between sessions) in §Consequences.
- **Karma-only correction (no memory write).** Considered: never touch a misbehaving builder's memory, only dock karma + flag for Archon. Rejected as the *default* because a karma delta alone doesn't tell the builder *what* to change; the visible corrective note carries the actionable feedback. (Karma-only remains the right move when there's nothing constructive to write.)
- **Amend ADR 0024 vs a standalone ADR.** The BFG is Phase 6 of [ADR 0024-mas](<redacted>.md), so amending it was the obvious option. Chosen instead to write a standalone ADR because the new **cross-builder write path is a trust-boundary decision** that extends [ADR 0016](<redacted>.md) — significant enough to deserve its own record rather than a table-row footnote.
- **Vector store / semantic memory for hygiene + 6B scoring.** Deferred, consistent with [ADR 0024-mas](<redacted>.md)'s own "vector-store implementation deferred" call. The current markdown `MEMORY.md` graph + frontmatter is sufficient for 6A/6B; revisit only if manual + heuristic analysis proves insufficient.

## Consequences

**Good:**
- The index, memory, and DB stop drifting — a standing agent watches *current truth*, complementing the Architect's *future structure* (the boundary ADR 0024-mas drew).
- Good practice propagates across builders instead of dying in one builder's memory.
- The trust boundary stays *legible*: there is exactly one new cross-builder write path, bound to one system principal, fully audited and builder-visible.

**Bad / accepted:**
- **The isolation invariant is no longer absolute.** A builder's memory can change between sessions without their action. Mitigation: visible attribution + namespaced files + delete-ability + per-write audit. This residual risk is accepted in exchange for the immediacy Lars chose; revisit if it bites.
- A BFG service principal is a new privileged identity — a new thing to secure. It must never be claimable or loginable as a normal builder.
- Cross-builder reads touch every builder's memory; the audit trail is the only thing making that legible. The auditor must not leak one builder's private memory into another's via 6B extraction (the "transferable, not specific" rule is load-bearing, not advisory).

**Reversibility:**
- 6A is pure addition (a read-only routine) — delete the skill to revert.
- 6C is reversible by disabling the write endpoint (kill-switch) and deleting BFG-namespaced memory files; the `audit_log` makes every write enumerable for cleanup.

## References

- [ADR 0024 — Multi-Agent System architecture](<redacted>.md) — the BFG is Phase 6
- [ADR 0024 — Cloneable repo + local-first memory](<redacted>.md) — the `builder_memory` store + §4 isolation
- [ADR 0016 — Trust boundary](<redacted>.md) — the rule this ADR narrowly excepts
- [migration 040](../../migrations/040_builder_karma.sql) — karma ledger (correction deltas)
- [migration 054](../../migrations/054_builder_memory.sql) — memory schema (read + write target)
