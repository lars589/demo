-- lifecycle_001_goal_first_leads.sql — backfill goal OWNERS into the member list
-- (task 1735). The goal authority model: the OWNER is goals.created_by (fixed at
-- create, moved only by POST /goals/:id/transfer); goal_members.role 'lead' is
-- the MANAGER tier the hall renders. From now on db.createGoal inserts the
-- creator's lead row atomically; this brings the goals created before that rule
-- up to the same shape so owners appear in their own member lists.
--
-- Goals with created_by NULL (the migration-160 default "<version> — general"
-- goals) have NO owner by design — Archons act as one via the gates' archon arm.
-- Deliberately NO earliest-member fallback: promoting a member to manager on an
-- ownerless goal would grant authority nobody asked for (fail-closed).
--
-- Data-only (no schema change), idempotent (the upsert converges), and
-- replay-safe on a fresh DB (zero goals → zero rows; no builder id is
-- hard-coded — learning 1238).

BEGIN;

INSERT INTO goal_members (goal_id, builder_id, role)
SELECT g.id, g.created_by, 'lead'
  FROM goals g
 WHERE g.created_by IS NOT NULL
ON CONFLICT (goal_id, builder_id) DO UPDATE SET role = 'lead';

INSERT INTO schema_migrations (version) VALUES ('lifecycle_001_goal_first_leads')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
