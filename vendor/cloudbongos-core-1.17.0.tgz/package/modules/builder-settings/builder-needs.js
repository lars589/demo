// src/bongos/builder-needs.js — the one consistent way to flag "the system needs an
// input from you to run" (task 1013 / ADR 0073).
//
// THE PATTERN. Some capabilities need a per-builder input the system can't supply
// itself — today the Gemini image key; tomorrow a Stripe key, a first-party
// Anthropic link, etc. Instead of each one inventing its own banner/prompt, they
// register ONE "need" here. The server computes the live list on /me; every
// surface (the hall Standing card, the CLI session nudge, the point-of-use stop)
// renders the SAME shape. Add a future input = add one entry to NEEDS — the
// renderers don't change.
//
// A need is always in exactly one of three states:
//   'covered'        — the system is handling it for them right now; nothing to
//                      do. (e.g. a newcomer whose image generation we pay for.)
//   'action_needed'  — the system needs them to provide the input NOW or a
//                      capability won't run. This is the one that surfaces loudly.
//   'satisfied'      — they've provided it. Rendered quietly (a ✓) or not at all.
//
// Each need is a small pure function of the builder's context, so this whole
// module is unit-testable with no DB.

'use strict';

// Where a builder goes to provide an input. Same hall origin as the rest of the
// web surfaces; the CLI nudge prints the absolute URL, the web renderers use the
// relative path.
const SETTINGS_PATH = '/settings';

// ---- need: art_key (per-builder Gemini image-generation key) ----------------
//
// ctx.rank                    — live builder rank (xenos|thetes|metic|archon).
// ctx.ownKeySet               — does the builder have their OWN key stored on the
//                               server? (db column gemini_key_enc is non-null).
// ctx.sharedKeyConfigured     — does the server have a shared newcomer key to
//                               give? (art-key.sharedGeminiKeyConfigured()).
//
// States:
//   ownKeySet                       → satisfied (their own key runs the pipeline)
//   newcomer (xenos)                → covered   ("on us while you get started")
//   thetes+ and no own key          → action_needed (coverage has ended)
function artKeyNeed(ctx) {
  const rank = ctx.rank || null;
  const isNewcomer = rank === 'xenos';
  const base = {
    id: 'art_key',
    title: 'Image-generation key',
    // What the input is FOR, in plain words — the same line on every surface.
    what: 'The art pipeline draws your tiles and sprites with Google AI Studio (Gemini).',
    learn_more_url: 'https://aistudio.google.com/app/apikey',
  };

  if (ctx.ownKeySet) {
    return {
      ...base,
      state: 'satisfied',
      severity: 'info',
      message: 'Your own image key is set — art runs on it.',
      action: null,
    };
  }

  if (isNewcomer) {
    // "We cover it for them" — reassuring, and it foreshadows the hand-off so the
    // later action_needed is never a surprise (Lars's chosen tone, 2026-06-20).
    return {
      ...base,
      state: 'covered',
      severity: 'info',
      title: 'Image generation — on us',
      message: 'While you find your feet, we cover the cost of generating art — nothing to set up. When you reach Thetes you\'ll add your own key, and we\'ll remind you then.',
      action: null,
    };
  }

  // Thetes+ with no own key: our free coverage has ended. Art won't run until
  // they add their own key. The message is rank-neutral on purpose (task 1392):
  // it fires for every tier past the covered Xenos floor — Thetes, Metic, and
  // Archon — so it must not name a single rank (an Archon was shown "graduated
  // to Thetes", the wrong rank).
  return {
    ...base,
    state: 'action_needed',
    severity: 'action',
    message: 'Your free art coverage has ended, so image generation now runs on your own key (you pay only for what you make). Add it to keep making art.',
    action: { label: 'Add your key', href: `${SETTINGS_PATH}#art-key` },
  };
}

// The registry. To add a future input the system needs from a builder, append a
// pure (ctx) => need|null function here — every renderer picks it up for free.
const NEEDS = [artKeyNeed];

// Compute the live list for a builder. `ctx` carries everything the need
// functions read (see each need's doc). Returns:
//   { items: Need[], action_needed_count, has_action_needed }
// items is ordered: action_needed first (loudest), then covered, then satisfied,
// so any renderer that takes "the first one" gets the most urgent.
function computeNeeds(ctx = {}) {
  const items = NEEDS.map((fn) => fn(ctx)).filter(Boolean);
  const order = { action_needed: 0, covered: 1, satisfied: 2 };
  items.sort((a, b) => (order[a.state] ?? 9) - (order[b.state] ?? 9));
  const actionNeeded = items.filter((n) => n.state === 'action_needed');
  return {
    items,
    action_needed_count: actionNeeded.length,
    has_action_needed: actionNeeded.length > 0,
  };
}

module.exports = {
  computeNeeds,
  // exported for tests / direct reuse
  artKeyNeed,
  SETTINGS_PATH,
};
