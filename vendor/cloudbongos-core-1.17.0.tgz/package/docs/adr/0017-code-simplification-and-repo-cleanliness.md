# 0017 — Code simplification & repo cleanliness as a maintained property

- **Status:** Accepted
- **Date:** 2026-05-27
- **Deciders:** Lars Kristensen (Archon), Claude
- **Track:** `internal` (GDS)
- **Context task:** GDS-V3 [#351](https://example.com/builders#/task/351) (V3.R90). Parent of [#352](https://example.com/builders#/task/352) (V3.R91, substrate), [#353](https://example.com/builders#/task/353) (V3.R92, grader economy lens), [#354](https://example.com/builders#/task/354) (V3.R93, reward), [#355](https://example.com/builders#/task/355) (V3.R94, janitor). Plan: `~/.claude/plans/i-believe-that-a-valiant-giraffe.md`.

## Context

AI-written code accrues bulk. It over-writes, reaches for abstraction it doesn't need, and leaves dead code behind — and then the same agent struggles to read and edit its own output later. The cheaper it is to keep the codebase small and legible, the more reliably an autonomous builder can keep shipping into it. Simplicity is therefore not a stylistic preference here; it is a precondition for the GDS scaling to multiple builders without the repo collapsing under its own weight.

Three gaps make simplicity hard to sustain today:

1. **Simplicity is invisible to the reward system.** The ship-time grader (`src/bongos/grader.js`) scores exactly two axes — `functional_fidelity` and `code_quality` (threshold 6.0, both must pass). Neither measures economy, diff size, or complexity. Diff stats are *already computed* at ship time (`scripts/gds/ship.js` `computeDiffShortstat` → stored in `task_grades.signals.diff_stats`) but never scored.
2. **The incentive is backwards.** `src/bongos/streak.js` *excludes* `kind='cleanup'` from streak credit — the system mildly penalizes the exact work we want to encourage.
3. **Cleanliness is reactive and weak.** `/merge-mode` only merges already-built branches. The `overnight-code-review` routine flags dead code as a low-priority, high-confidence afterthought. There is no complexity / dead-code / lint tooling anywhere — `package.json` carried only `"start"` and zero devDependencies before this ADR.

## Decision

We will treat simplicity the way the GDS already treats correctness: **prevent it inline, reward it, and maintain it autonomously.** Three layers, sharing one cheap measurement substrate:

- **PREVENT** ([#353](https://example.com/builders#/task/353)/V3.R92) — the grader gains an *economy* lens at ship time: it judges whether the change is the simplest one that achieves the task, penalizing unnecessary abstraction, premature generalization, duplicated/dead code, and diffs larger than the task warrants. Caught at the cheapest moment, while the author still has full context.
- **REWARD** ([#354](https://example.com/builders#/task/354)/V3.R93) — stop excluding `cleanup` from streaks; credit net-negative ships (more lines removed than added); add a "Subtractor" achievement. Simplification becomes a rewarded act, not an unpaid chore.
- **MAINTAIN** ([#355](https://example.com/builders#/task/355)/V3.R94) — a weekly autonomous `repo-simplify-sweep` routine measures the repo, files findings to `idea_inbox`, and auto-fixes a *narrow, safe class* (confirmed dead files) end-to-end so builders never have to think about it.

All three read one substrate ([#352](https://example.com/builders#/task/352)/V3.R91, `scripts/gds/repo-metrics.js` + a `repo_health_snapshots` table + a `/public/repo-health` surface): per-file size, LOC growth by directory, dead-code counts, and branch hygiene.

### Advisory first, then a gate (the economy score)

The economy score ships **advisory first**: recorded on every grade (as a sub-score in `task_grades.rubric_scores`, jsonb — no migration) and feeding `code_quality`, but **not** independently hard-blocking. A legitimately large-but-necessary feature must not be blocked on day one by an uncalibrated threshold. After a few weeks of real scores, a follow-up task promotes economy to a third both-must-pass axis at the existing `grader.js` gate. This mirrors how every gate in this system earned its teeth — measure, calibrate, then enforce.

### Adopt knip as the dead-code detector

We will adopt **knip** (dev-only) as the one tool the substrate and janitor lean on. Rationale:

- **It targets the exact failure mode.** Unused exports and unreferenced files are the residue of AI over-writing — code written, then orphaned. Reliable dead-file/dead-export detection is genuinely hard to hand-roll (it requires building and walking the import graph); knip does it.
- **Zero production cost.** knip is in `devDependencies`. The droplet deploy runs `npm ci --omit=dev`, so knip and its dependency tree never reach production. No runtime, no monthly cost — consistent with the $5K budget posture. (Its transitive dev-tree does carry npm-audit advisories; these are dev-only and are the concern of the dependency-scan task V3.R38, not prod.)
- **Config lives in `package.json`, not a new file.** knip reads a `"knip"` key in `package.json`. Embedding it there — rather than adding a root `knip.json` — keeps the footprint minimal, which is the very ethos this ADR encodes. (The task description floated `knip.json`; the package.json key is the simpler in-scope choice and is what shipped.)

The committed config declares entry points (CLI scripts, tests, the browser `public/game/main.js`, the status/builders pages) and the project globs, and lists `phaser` + `colyseus.js` under `ignoreDependencies` because those are loaded as vendored browser globals via `<script>` tags (`public/index.html`), not statically imported — so knip would otherwise report them as unused. The config was trimmed to remove every pattern knip flagged as redundant; it now emits no configuration hints.

### Baseline knip run (the "first janitor backlog") — and a precision rule it taught us

Running knip against the current repo produced:

- **Unused files (2, high precision):** `src/bongos/active-claims.js` (referenced only in seed-script *prose*, never `require`d) and `src/bongos/pulse.js` (referenced only by the separate CLI `scripts/gds/pulse.js` via an HTTP route, never imported). Both are genuine orphan candidates. They are **not** removed under this task — V3.R90's scope (`touches: docs/adr/, package.json, package-lock.json`) excludes editing `src/`. They are recorded here as the first janitor backlog for V3.R94 to triage/remove.
- **"Unused exports" (143, low precision in this repo):** dominated by **false positives**. This codebase is largely CommonJS consumed via namespace member-access (`const db = require('./db'); db.createTask(...)`), which knip cannot statically trace, so it reports the individual exports as unused even though they are called. Spot-verified: `createTask` is invoked from `src/bongos/routes/tasks.js`.
- **"Unlisted binaries (1): knip":** an artifact of running via `npx` with no local `node_modules`; it resolves once `npm ci` installs knip into `node_modules/.bin`. Not a real finding.

**The precision rule this establishes (load-bearing for V3.R94):** the janitor's **autonomous auto-fix class is restricted to unused *files* (and, later, confirmed unused *dependencies*)** — high-precision, reversible deletions. Unused-*export* findings are **advisory only**: filed for human/triage review, never auto-removed, because under CommonJS namespace access they are unreliable. This is exactly why the janitor auto-fixes a deliberately narrow class and files everything judgment-heavy.

## Alternatives considered

- **ESLint / a full linter instead of knip.** Rejected as the first tool. ESLint enforces style and catches per-file lint issues but does not build a project-wide reachability graph, so it does not find orphaned files or cross-module dead exports — the actual AI-residue problem. A linter may still be adopted later for a different purpose; it is not a substitute here.
- **Hand-rolled dead-code detection (git/grep heuristics only).** Rejected for the dead-code signal. Reliable unused-export/unreferenced-file detection means parsing and walking the import graph; a grep heuristic is crude and misses re-exports, dynamic paths, and the CJS cases knip at least surfaces. We *do* keep git/`wc` shell-outs for the cheap size/growth/branch-hygiene metrics in the substrate — those don't need a tool.
- **Make the economy score a hard gate immediately.** Rejected. An uncalibrated simplicity threshold would block legitimately large features on day one and erode trust in the grader. Advisory-first, then harden, is the safer path and matches precedent.
- **Keep cleanliness purely reactive (extend `/merge-mode` or `overnight-code-review`).** Rejected as insufficient. The user's explicit goal is that builders should *not* have to think about cleanliness; a reactive merge tool and a correctness-first review routine do not actively reduce bulk. A dedicated, scheduled, partly-autonomous janitor is the mechanism that removes the human from the loop.

## Consequences

**Good:**
- Simplicity becomes measured (substrate), rewarded (incentive flip), prevented (grader), and maintained (janitor) — four reinforcing pressures instead of zero.
- The first tool in a zero-tooling repo is a deliberately scoped, dev-only one with no production or monthly cost.
- The baseline run already produced a concrete, verified backlog and a precision rule that de-risks the janitor's autonomy.

**Costs / commitments:**
- knip's dev dependency tree adds npm-audit surface (dev-only; owned by V3.R38, not prod).
- The economy gate must actually be hardened after calibration, or it stays a toothless number — a follow-up task tracks this (filed under V3.R92).
- The janitor's auto-fix autonomy is bounded by the precision rule above; broadening it beyond unused files/dependencies would need its own decision, because export-level and refactor-level "simplifications" are not safe to apply unattended in a CJS codebase.

**Operationally:**
- Run dead-code detection with `npm run knip`. For the trustworthy signal, scope to files/dependencies (`knip --include files,dependencies`); treat the exports report as advisory.
- The ADR index that records permissions/architecture decisions is `docs/adr/README.md`; this ADR is indexed there. (CLAUDE.md references ADRs in prose but is not edited here — it is outside this task's declared `touches`.)
