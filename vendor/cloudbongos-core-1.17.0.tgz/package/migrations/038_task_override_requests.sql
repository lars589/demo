-- 038_task_override_requests.sql — V3.R74 (#293).
--
-- When the subagent grader rejects a ship (functional_fidelity or code_quality
-- below threshold, or confidence too low), the task stays at 'completed' — no
-- credits, no auto-merge. Most of the time the grader is right; sometimes it's
-- wrong (false negative on diff shape, scoring drift, mis-read intent). The
-- builder needs a path to ask an Archon to override the failed grade.
--
-- Today the only override path is POST /tasks/:id/confirm — but that's
-- Archon-only by route guard, so a Metic stuck on a bad grade has nothing
-- between them and "ping Lars in chat." This table is the request queue.
--
-- Lifecycle: open → approved | denied (terminal; row is the audit trail).
-- On 'approved', the same transaction flips the task to confirmed and pays
-- out credits via the existing confirmTask path. The override decision row
-- captures who approved and why.
--
-- Per-task uniqueness: only ONE open request at a time per task. Once decided,
-- the row stays for forensics but a new request can be opened (e.g. the task
-- was re-graded and failed again).

CREATE TABLE IF NOT EXISTS task_override_requests (
  id                          bigserial PRIMARY KEY,
  task_id                     bigint NOT NULL REFERENCES tasks(id),
  requested_by_builder_id     bigint NOT NULL REFERENCES builders(id),
  rationale                   text NOT NULL,
  status                      text NOT NULL DEFAULT 'open'
                                CHECK (status IN ('open', 'approved', 'denied')),
  decided_by_builder_id       bigint REFERENCES builders(id),
  decided_at                  timestamptz,
  decision_note               text,
  created_at                  timestamptz NOT NULL DEFAULT now()
);

-- Archon queue lookup: "open requests, newest first."
CREATE INDEX IF NOT EXISTS idx_task_override_requests_open
  ON task_override_requests (created_at DESC)
  WHERE status = 'open';

-- Per-task lookup (when surfacing on a task detail page).
CREATE INDEX IF NOT EXISTS idx_task_override_requests_task
  ON task_override_requests (task_id, created_at DESC);

-- At most one open request per task. Enforced as a partial unique index on
-- task_id so historical rows (approved/denied) don't conflict.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_task_override_requests_open_per_task
  ON task_override_requests (task_id)
  WHERE status = 'open';

INSERT INTO schema_migrations (version) VALUES ('038_task_override_requests')
  ON CONFLICT (version) DO NOTHING;
