# ADR 0031 — Cloud dev environments for builders (hybrid: Claude Desktop → SSH → containerized DigitalOcean box)

**Date:** 2026-06-04
**Context:** GDS-V3, task [#595](https://example.com/builders#/task/595) (claim `#477`). Feeds done-when criteria **C1** (`onboarding ≤ 2h`) and **C8** (`cloneable repo / local-first memory, server-canonical on ship`). Companion to [ADR 0016](<redacted>.md) (trust boundary — same server-enforced posture), [ADR 0018](<redacted>.md) (Xenos → Metic → Archon), [ADR 0022](0022-secrets-policy.md) (no secrets in repo — precondition for a cloneable box), [ADR 0024](<redacted>.md) (memory follows the builder — unchanged by where the box runs), and [ADR 0002](<redacted>.md) (we already run on DigitalOcean).
**Status:** Accepted. *Decision recorded this session; implementation tasks to be seeded separately (see the Implementation sub-tasks at the end).*
**Track:** `internal` (dev-system architecture).

> This is a decision record, not an implementation. Nothing here is built yet. The point is to lock the shape so a future session can build it without relitigating the design.

## Problem

Today there is exactly one builder (`example-owner`) on one laptop. GDS-V3 opens the system to many builders, and "every builder runs Claude Code locally" has two problems we want to solve *before* we onboard people:

1. **Accessibility.** Local-only requires each builder to own a capable computer (RAM, disk, CPU) *and* hand-install a toolchain (Homebrew, Node 22, Python 3.10, a native `sharp` build, env vars). That toolchain step is the single biggest onboarding failure today, and it's exactly the kind of thing the non-engineer audience we want to attract cannot debug. It directly blocks the C1 "onboard in ≤2h" goal.
2. **Cost at scale.** Builders will eventually be **paid real money per task**, and the project runs on a ~$5,000/yr budget. We want builders to bear and optimize their own tooling cost (so the incentive to be efficient sits with them), without the org taking on a fixed per-builder cost that grows linearly and untenably with headcount.

The decisive reframe (established during scoping): **two very different costs get bundled as "the cost of running Claude," and they differ by 10–100×.**

- **Inference** — what the AI model costs to *think* (Claude tokens). **$400–1,200+/mo** for a heavy builder. This is the dominant cost, and it is already remote (Anthropic's servers).
- **Compute / "the box"** — the machine that holds the repo and runs the dev server + art pipeline. **~$3–30/mo.** This is what "local vs cloud" is actually about. It is the *small* cost.

So the cost lever that matters is **inference, not the box.** The box can be a near-trivial, bounded line item. This single fact shapes every choice below.

## The mental model (preserve this for onboarding)

> This explainer is the canonical "how you'll run Claude" framing. It now lives in the onboarding primer — see [`docs/onboarding/primer.md`](../onboarding/primer.md) § "Where your work runs — screen, worker, brain" — so new builders meet it on day one. It was carried there during the ADR 0035 primer rewrite ([#718](https://example.com/builders#/task/718)); keep the two in sync if you revise the model (task 601).

Claude Code is **three pieces that can live in different places**:

1. **The screen** (the interface) — the window you look at and type into. **Always on your device** (the Claude Desktop app, or a browser tab). It just displays files/diffs and sends prompts.
2. **The worker** (the agent) — the part that opens files, runs commands, edits code, runs the dev server. Runs in **one place you choose.**
3. **The brain** (the AI model) — the intelligence. **Always on Anthropic's servers**, no matter what. This is the "inference" the subscription pays for.

You only ever choose **where the worker goes**. The screen is always local; the brain is always Anthropic's.

```
   YOUR DEVICE                  THE BOX (worker)                ANTHROPIC
   ┌───────────┐   SSH /        ┌────────────────────┐          ┌──────────┐
   │  screen   │── Remote ─────▶│ containerized DO box│──tokens─▶│  brain   │
   │ (Desktop/ │   Control      │ repo · dev server · │◀─────────│ (model)  │
   │  browser) │◀──────────────▶│ art pipeline · git  │          └──────────┘
   └───────────┘                └─────────┬───────────┘
                                          │ HTTPS (GDS API) · git push (GitHub)
                                          ▼
                                 GDS Postgres · GitHub (private repo) · CI deploy
```

In our model the device is a **window**, the **box** is where the code lives and the work happens, and **Anthropic's servers** are the brain. The repo never lands on the builder's personal disk.

## Decision

We will adopt a **hybrid** model with a single shared foundation. In plain terms: **a clean Claude Desktop GUI on the builder's own device, driving Claude Code on an org-controlled, containerized DigitalOcean box, with the builder bringing their own Claude subscription.**

### 1. UI — Claude Desktop is the primary interface

> **Superseded in part (2026-06-06, [ADR 0038](<redacted>.md)):** the thin-device `claude rc` always-on-service on-ramp described in the Thin-device bullet below is retired. Headless `claude rc` can't bootstrap (Trusted-Devices enrollment is interactive-only); the browser-only on-ramp is now a box-served `ttyd` web terminal over an outbound Cloudflare Tunnel where the builder runs normal interactive `claude`. See [ADR 0038](<redacted>.md) (and [ADR 0040](<redacted>.md) for in-session Remote Control as the default browser experience). The Desktop→SSH and Local paths below are unchanged.

Most builders want a clean GUI, not a terminal or an IDE. The redesigned Claude Desktop app (April 2026) has a **Code** tab whose session **Environment** selector offers three mutually-exclusive choices for *where the worker runs*: **Local**, **Remote** (Anthropic-managed cloud VM), and **SSH** (a machine the org controls). We build on **SSH**.

- **Desktop builders (Mac/Windows): Claude Desktop → SSH → our box.** Point-and-click; Desktop auto-installs Claude Code on the remote on first connect. We pre-distribute and lock the connection via Desktop **managed settings** (`sshConfigs` + `sshHostAllowlist`) so a non-technical builder sees exactly one approved box ("Example Dev Box") and cannot misconfigure or wander off it.
- **Thin-device builders (Chromebook/iPad/phone): browser/mobile → Remote Control → the same box.** On the web (`claude.ai/code`) the "your own box" path is **Remote Control**: `claude rc` runs on the box (as an always-on service) and the builder drives it from the browser. Same destination as SSH, different on-ramp. *Caveat: Claude Desktop is macOS/Windows-only — a literal Chromebook uses the web/Remote-Control path, not the Desktop app.*
- **Power users:** Claude Desktop **Local** (native toolchain on a capable machine) or the VS Code dev-container flow remain available off the same container spec (§3). Not the default.

### 2. Execution substrate — an org-controlled, containerized DigitalOcean box, one per builder

The worker runs on a **DigitalOcean droplet (or a container on a DO host) that the org controls**, reached over SSH/Remote-Control. **One box per builder** (a shared box collides on files, ports, the DB connection, and breaks per-builder isolation). DigitalOcean over GitHub Codespaces — see §7 and Alternatives.

### 3. The container — the box is defined as code

The box is defined by a **`devcontainer.json` + Dockerfile** committed to the repo: base Linux + Node 22 + Python 3.10 and the five art-pipeline libs + `sharp` build deps + git + Anthropic's Claude Code container feature (which installs Claude Code and a **default-deny outbound firewall** allow-listing only the Anthropic API, GitHub, and npm). Today's `setup-builder.sh` work folds into the container's first-run step; `doctor.js` becomes its health check. There is **no containerization in the repo today** — this is greenfield. The same spec runs identically on a DO box, on a laptop (Docker Desktop), or in Codespaces — so the substrate stays portable and we are not locked to DO.

### 4. Inference — bring-your-own Claude subscription, no API key

Every builder authenticates Claude Code with **their own Pro/Max subscription**. The org provisions **no shared Anthropic API key.** This is both the cheapest path (a flat subscription is 15–30× cheaper than per-token API for heavy users) and the cleanest contributor model (the 1099 "bring your own tools" arrangement). It also means the org's inference cost is **$0**.

- **Interactive sessions** (Desktop-SSH or web-Remote-Control) are "ordinary use of Claude Code" under Anthropic's terms — subscription auth is permitted, and the consumer GUI/Remote-Control paths do **not** accept API keys anyway.
- **Autonomous runs** (`overnight-builder`, MAS dispatch) are launched **as scheduled Claude Code sessions under a subscription**, which the decider judges to be ordinary Claude Code use, not the prohibited Agent-SDK/`--bare`/shared-key path. *Residual risk (recorded, accepted): unattended subscription sessions could trip Anthropic's abuse heuristics, and a 15 Jun 2026 change alters how subscription-based automation draws credits. Re-verify before scaling the autonomous lane; this is the one place an API key might later become unavoidable.*

### 5. Cost & access model — org fronts an auto-suspended starter box; builders self-fund from earnings

Two rules dissolve the "front every box (linear cost) vs. gate by payment (barrier)" dilemma:

**(a) Auto-suspend is mandatory.** A box that runs only while the builder is working costs **~$3–6/mo** instead of ~$24–30/mo always-on. DigitalOcean has no native auto-suspend, so we **build it** (snapshot-and-park on idle, recreate on demand, or a Coder layer — see Open questions below). Dormant/abandoned boxes get de-provisioned (a stale-claim-style sweep).

**(b) Cost follows proven value, not signup** — riding the existing rank ladder + onboarding funnel:

| Stage | How they work | Org cost | Builder cost |
|---|---|---|---|
| **Newcomer** (Xenos / onboarding) | Org provisions an **auto-suspended starter box** so there is zero payment barrier to begin | A bounded ~$5/active-newcomer (suspends when idle; de-provisioned if dormant) | Just their Claude subscription |
| **Proven** (graduated → Metic) | Keeps a box | Transitions toward $0 | **Self-funds** (own DO account, or org provisions + rebills via the `costs` table, deducted from drachmae/earnings) |
| **Established** | Own box, runs it how they like | **$0** | Self-funds (1099 own-tools) |

The barrier to *start* is zero (org pays the first box, per the decision to **not** use Anthropic's Cloud VM for onboarding). Real cost attaches only to builders who are earning. **Scale math:** naïve 100 builders × $30 always-on ≈ $36k/yr (untenable); this model ≈ $0 ongoing + a small bounded starter-box pool. None of it needs new machinery — it rides the rank ladder, the onboarding funnel, the drachmae/credits system, and the cost-logging we already have.

### 6. Security — the container is the rank-gated source-access boundary

The repo is **private** (today under a personal account — see §7; a move to a GitHub Organization would change the enforcement options below). Putting the worker on a box we control, reached only through the GUI, turns repo access from *"every builder holds a permanent local clone forever"* into *"access is to a box we own — gated, revocable, audited, egress-restricted."*

- **Gate source access by rank.** Below a chosen rank: no box, no source. The box (not the builder) holds the scoped GitHub credential; below-rank builders have no direct clone rights. Extends the [ADR 0016](<redacted>.md) trust boundary from "writes are gated" to "source access is gated."
- **No permanent local copy** (the code lives on the box; SSH/Remote-Control bypass any local folder).
- **Central revocation + clean offboarding** (revoke rank → de-provision box → source access gone).
- **Prod deploy moves to CI** (GitHub Actions, like staging already is), so **no builder box ever holds the production droplet SSH key.**
- **Honest limit (recorded):** an authorized, logged-in builder can still read/copy code they have a session on. This is defense-in-depth, revocation, and audit — **not** insider-proof DRM.

### 7. Substrate — DigitalOcean, not Codespaces

**DigitalOcean** is the org substrate because it fits the decisions above:

- **Clean fit for Claude Desktop SSH** (a real IP/port/key) and for an always-on `claude rc` service; Codespaces' SSH is a `gh` CLI tunnel (no stable host) and its 30-min auto-suspend kills `claude rc`.
- **Full host control** → we are root, the builder is a guest, so the firewall/lockdown/idle policy are *enforceable*. On a **personal** repo, Codespaces gives the collaborator root of their own box and the org **cannot enforce** environment/network/idle policy (those are <redacted> features).
- **Org can fund the first box.** On a personal repo, GitHub bills the Codespace *creator* and a personal account has **no mechanism to pay on a collaborator's behalf** — directly incompatible with the "org pays the first box" decision (it would require converting to a paid GitHub Org, which then flips billing org-wide).
- **Unified stack** (we already run DO; existing deploy tooling) and **flexible billing** (org account or the builder's own DO account).
- **Escape hatch:** because the devcontainer is portable, a VS-Code-preferring builder may **self-fund their own Codespaces** off the same spec. Codespaces is an opt-in individual lane, not the foundation.

## Alternatives considered

- **Fully remote with centralized inference (org runs everything on one provider + a shared API key).** Rejected. Centralizing inference forces the 15–30× more expensive per-token rate onto the org and concentrates provider/price/sunset risk (cf. AWS Cloud9's 2024 closure) — exactly the margin pressure we want to avoid. The hybrid contains "fully remote" as one configuration without forcing centralized inference.
- **GitHub Codespaces as the org substrate.** Rejected as the *default* (kept as an opt-in self-funded lane). On our private *personal* repo it preserves access-control and revocation (those live in GitHub permissions, independent of who pays) but **loses enforced environment control** (the collaborator is root), is **awkward to drive from Claude Desktop**, its auto-suspend **kills Remote Control**, and the org **cannot pay the first box**. Its genuine strengths (native self-funding, native auto-suspend, zero ops) collide with three firmer priorities (Desktop-first UI, org-funded onboarding, enforced control).
- **Anthropic-managed Cloud VM for onboarding.** Rejected by the decider. Though free to the org (runs on the builder's subscription), it is ephemeral, GitHub-centric, network-restricted, cannot host our full stack, and cannot cleanly SSH out to deploy. We pay for a real starter box instead.
- **Pure bring-your-own box (builder creates + pays from day one).** Rejected as the entry path — it reintroduces the payment/signup barrier that suppresses early growth. It is the *destination* (the "established" stage), not the on-ramp.
- **Shared org Anthropic API key.** Rejected — 15–30× costlier than subscriptions and the wrong side of the headless-use terms. BYO-subscription is both cheaper and cleaner.
- **Keep local-only.** Rejected — it fails C1 (toolchain install is the worst onboarding burden) and excludes builders without capable hardware.

## Consequences

**Good:**
- Onboarding drops from "install a toolchain and hope" to "open Claude Desktop, pick the Example Dev Box" — the direct lever on C1 (≤2h).
- Org inference cost = $0 (BYO subscription); org compute cost ≈ $0 ongoing (auto-suspend + self-funding), bounded by a small starter-box pool.
- The container is a real security upgrade: rank-gated source access, no permanent local clones, central revocation, clean offboarding, egress restriction — strengthening [ADR 0016](<redacted>.md).
- The box stays portable (devcontainer), so we are not locked to DigitalOcean, and VS-Code power-users can self-fund Codespaces off the same spec.
- [ADR 0024](<redacted>.md) memory sync is unaffected — it keys on `builder_id`, not on where the box runs.

**Costs / what it commits us to:**
- Real build work: author + test the devcontainer across a DO box and a laptop (the `sharp` native build is the usual snag), build the auto-suspend automation (DO has none native), wire prod-deploy to CI, build rank-gated box provisioning, and write the onboarding primer page.
- An ongoing operational surface: per-builder box lifecycle (provision, suspend, de-provision), managed-settings distribution, and the `claude rc` service for thin-device builders.
- The autonomous-lane ToS posture (§4) is a judgment call with a recorded residual risk to re-verify.

**Operationally:**
- Auto-suspend and prod-deploy-to-CI should land before the first non-Lars builder, or the cost and security properties this ADR promises aren't real yet.
- The onboarding repo-access wrinkle (see Open questions) must be resolved before a Xenos's starter box is provisioned.

## Open questions (flagged, not blocking)

1. **Per-builder box ownership transition.** Mechanics of moving a builder from the org-funded starter box to self-funding — recreate on their own DO account vs. org-provisions-and-rebills via the `costs` table. Lean: rebill-via-drachmae for simplicity; revisit.
2. **Onboarding repo-access scoping.** ✅ **RESOLVED 2026-06-05 ([#600](https://example.com/builders#/task/600)) — rank-gated, server-issued, fetched-not-baked.** A Xenos box sparse-checks out only the safe surface; full creds arrive at graduation; the box fetches a scoped credential gated on live rank rather than holding a baked one. See the resolution note below.
3. **Auto-suspend implementation.** ✅ **RESOLVED 2026-06-04 ([#598](https://example.com/builders#/task/598)) — snapshot-and-park, NOT Coder.** See the resolution note below.
4. **Thin-device on-ramp friction.** ✅ **RESOLVED 2026-06-06 ([#701](https://example.com/builders#/task/701)) — box reports its pairing link UP to the GDS; the builder reads it from the web.** See §9.4 below.
5. **Codespaces self-fund lane.** Confirm (empirically) that a collaborator self-funds on the private personal repo, and decide whether to actively support the VS-Code lane or merely allow it.
6. **Desktop SSH on the chosen DO image.** SSH-to-macOS/Linux and the redesign are recent (April 2026, parts research-preview); pin versions and verify on the actual image before rollout.

## Open-question resolutions

### §9.2 — Onboarding repo-access scoping: rank-gated, server-issued, fetched-not-baked (2026-06-05, [#600](https://example.com/builders#/task/600))

**Decision: the box holds NO baked credential — it fetches a rank-scoped clone spec from the GDS at boot + on a cron, gated on the builder's LIVE rank.** This extends the [ADR 0016](<redacted>.md) trust boundary from "writes are gated" to "source is gated": `GET /api/gds/box/source-access` (`requireBuilder`; the scope + allow/deny decided inside from the live DB rank, not a static `requireRank`) returns either a 403 or a scope-appropriate spec + a short-lived, operator-supplied credential.

- **Scope by rank** (`src/bongos/box-access.js`, `boxScopeForRank` from [#598](https://example.com/builders#/task/598)): **Xenos → `starter`** (cone-mode sparse-checkout of `.devcontainer`, `art`, `docs`, `public-status`, `generative-ideas.md` — the "first tasks on a scoped surface" this question asked for); **Metic+ → `full`**. Graduation rescopes the box (the box re-clones the full surface on its next refresh). Fail-closed: any unknown scope collapses to `starter`.
- **Credential is fetched, never baked** (`src/bongos/box-credential.js`, env-backed default; the secret lives in the prod env per [ADR 0022](0022-secrets-policy.md), `configured:false` until set). The box clones via a one-shot authenticated URL then scrubs the token from `.git/config` (`infra/box-source-fetch.sh`). Because access is re-checked live on every fetch, **revocation is instant at the credential layer** — a demoted/deactivated builder is 403'd on their next refresh.
- **The clawback (clean offboarding).** `setBuilderRank` / `deactivateBuilder` flag a box reconcile post-commit; `scripts/gds/box.js reconcile` deprovisions below-floor / inactive boxes and rescopes graduated ones. Credential revocation is instant; droplet teardown is the async control-plane half. Every grant/denial/reconcile is audited to `box_events`.
- **Honest limit (recorded, unchanged from §6).** Git cannot sub-path-scope a single private repo and sparse-checkout is client-side, so the default `starter` surface is **defense-in-depth + audit + revocation, not insider-proof DRM**. A HARD boundary is available via `BOX_SOURCE_STARTER_REPO_URL` (a physically separate starter repo) — left as an operator choice.

Operator runbook: `docs/recipes/managed-settings-remote-control.md` Part 4. **The <redacted> leg (a live box fetching + sparse-cloning against a configured GitHub credential) is unverified on hardware** — same posture as [#598](https://example.com/builders#/task/598)/[#599](https://example.com/builders#/task/599); the decision core, the route, the clawback, the cloud-init injection, and the box-side script are verified hermetically (`tests/box_access.mjs`, `scripts/gds/smoke-box.sh`).

### §9.3 — Auto-suspend: snapshot-and-park, not a Coder control-plane (2026-06-04, [#598](https://example.com/builders#/task/598))

**Decision: build snapshot-and-park.** When a box goes idle, snapshot the droplet then **destroy** it; recreate from the snapshot on demand. Implemented in `scripts/gds/box.js` (the lifecycle CLI), `src/bongos/boxes.js` (the pure decision core), `src/bongos/do-api.js` (the DO client), the `builder_boxes` + `box_events` tables (migration 067), and two control-plane sweeps (`box-idle-suspend` every 15 min, `box-dormant-reclaim` daily).

**Why not Coder.** Coder is a full control-plane: it needs an **always-on droplet to host it** (~$12–24/mo fixed) plus its own Postgres, auth, and an upgrade treadmill. That is exactly the *builder-count-independent fixed cost* this ADR's §5 cost model is built to avoid, and a heavy new operational surface for a project that has one builder today. Snapshot-and-park rides `doctl`/the DO API + the existing systemd-timer sweep pattern (it is the direct analogue of `stale-claim-release`), so its fixed cost is ≈ $0 — a parked box costs only its snapshot (~$0.30/mo for a ~5 GB image) instead of ~$24/mo running. Coder's genuine wins (a polished per-workspace model, web terminal) are not things we need: the UI is Claude Desktop (§1), and the per-builder model is one droplet keyed by `builder_id` in our own table.

**The DO footgun this encodes.** A *powered-off* DigitalOcean droplet **still bills** (its disk/resources stay reserved). So "park" is not "power off" — it is snapshot → **destroy**, keeping only the cheap snapshot; "wake" is recreate-from-snapshot. This is why the schema's `droplet_id`/`ip` are NULL while parked but `snapshot_id` persists, and why a box accrues compute cost only while `state='active'`.

**Stable hostname (handoff to [#599](https://example.com/builders#/task/599)).** A recreated droplet gets a new IP. The lifecycle records a per-builder `hostname` (`box-<login>.dev.example.com`) and offers a `BOX_DNS_HOOK` to repoint it on each wake; the actual Desktop managed-settings cutover to that hostname is [#599](https://example.com/builders#/task/599).

## Decision update — container pool rejected; droplet-per-builder confirmed; hardware status (2026-06-06, [#699](https://example.com/builders#/task/699))

Two things were settled this session.

### Newcomer substrate: a shared-host container pool was investigated and REJECTED.

The question raised: should the Xenos/newcomer substrate be a **pool of containers packed onto a shared host** (denser, cheaper) instead of the §2 one-droplet-per-builder model? Investigated via two research threads plus a hardware check. Findings:

- **Plain Docker is not a security boundary for this workload.** Builders run an AI agent executing arbitrary code — "hostile by default." Containers share one host kernel, so a single kernel/`runc` escape exposes every co-tenant's source, scoped credential, and Claude session. The escape cadence is roughly annual (runc "Leaky Vessels" Jan 2024; a runc CVE cluster Nov 2025, several of which **bypass AppArmor/SELinux**; Dirty-Pipe-class kernel LPEs every 1–2 years). Revealed preference confirms it: every vendor that runs strangers' untrusted code — AWS Lambda/Fargate, Fly.io, e2b, Vercel, CodeSandbox (Firecracker), Modal, Google Cloud Run (gVisor) — moved **off** plain Docker.
- **A *secure* pool needs gVisor or Firecracker/Kata microVMs**, plus the full in-container hardening checklist, plus a placement/pool manager, plus snapshot-suspend to reclaim idle RAM. DO **does** expose `/dev/kvm` (verified on the prod droplet: `vmx` flag, `kvm_intel` loaded), so microVMs are technically viable here.
- **The cost win is real but modest, and the "less middleware" premise is inverted.** The ~$0/idle-container economics depend on scale-to-zero *plain* containers, which security forbids. Secure warm cost ≈ $1.65–2.65/tenant/mo (≈ $0.30–0.60 with Firecracker snapshot-suspend) vs ≈ $5–12 for a per-builder droplet — i.e. cheaper only at dozens of concurrent newcomers. And the droplet model gets isolation **free** from the VM boundary, whereas the pool must *re-engineer* isolation (security runtime + pool manager + snapshot orchestration) — strictly **more** to build and run, plus a hard network-isolation requirement (a pool host co-locating many builders' credentials must not be able to reach the control plane / GDS Postgres).

**Decision: droplet-per-builder only — §2's "one box per builder" stands unqualified. The container pool is rejected.** At one builder it earns nothing; it pays off only at scale, and even then trades dollars for multi-tenant security engineering. Revisit *only* if concurrent-newcomer volume reaches the dozens **and** the gVisor/microVM security work is funded. (Sources: [runc Nov-2025 CVEs](https://www.sysdig.com/blog/runc-container-escape-vulnerabilities), [container-isolation consensus](https://www.aquasec.com/blog/container-isolation/), [microVM isolation 2026](https://emirb.github.io/blog/microvm-2026/).)

### Hardware-verification status (sharpens the §9.2 note).

- **The §9.3 lifecycle ([#598](https://example.com/builders#/task/598)) is verified on real hardware (2026-06-04).** `box_events` records a full `provision → park → wake → deprovision` cycle that day (droplets `575387789`/`575388325`, snapshot `231499516`). **Operator gotcha:** the first attempt failed with `DO POST /droplets … missing the required permission tag:create` — the `DO_API_TOKEN` must carry **tag-create** scope (use a Full-Access token, or a custom token that includes tag write).
- **The [#685](https://example.com/builders#/task/685) builder-side `connect.sh` is verified on a real Mac (2026-06-06)** — GitHub device sign-in, `~/.ssh/otb_builder` key generation + registration, and `managed-settings.json` install all succeeded end-to-end.
- **Still unverified on hardware:** the §9.2 ([#600](https://example.com/builders#/task/600)) source-fetch leg (sparse clone against a configured GitHub credential — `BOX_REPO_URL`/credential were not set), the operator `box.js onboard` welcome-packet on a live box, and the actual Claude Desktop **connect to a running box**. The token was removed after the 2026-06-04 run, so no `box.env` is currently configured.

### The real remaining onboarding gap → ✅ CLOSED ([#701](https://example.com/builders#/task/701), 2026-06-06).

Droplet-vs-pool was a *backend* choice; it did not address the newcomer on-ramp. For a non-technical / Chromebook builder, three server-side pieces were unbuilt: **auto-provision** (no builder-held DO token, no manual operator CLI), **wake-on-connect** (a returning builder's parked box wakes itself), and the **web/Chromebook Remote-Control pairing** path. All three shipped under [#701](https://example.com/builders#/task/701) — see §9.4.

### §9.4 — Box onboarding middleware: an intent queue, never the DO token in the web process (2026-06-06, [#701](https://example.com/builders#/task/701))

> **Superseded in part (2026-06-06, [ADR 0038](<redacted>.md)):** the `claude rc` Remote-Control pairing path in this section — `infra/box-report-pairing.sh`, the `box/pairing` + `box/pairing-link` routes, and the "box reports its link UP" Chromebook flow — is retired. `claude rc` can't run headless on a box (see ADR 0038 *Problem*). The browser-only on-ramp is now a box-served `ttyd` web terminal over a Cloudflare Tunnel. The intent-queue / `box/ensure` auto-provision + wake-on-connect machinery below is **unaffected**.

**Decision: the web process records a REQUEST (an "intent"); the control-plane runner executes it.** The hard constraint (§6 + the `routes/box.js` header) is that the internet-facing Node process must never hold `DO_API_TOKEN` — a stolen builder token could otherwise spin up or destroy infrastructure. So [#701](https://example.com/builders#/task/701) does NOT move provisioning into the web tier. Instead:

- **Auto-provision + wake-on-connect = one primitive: `POST /api/gds/box/ensure`** (`requireBuilder`; allow/deny + the chosen action decided inside from the builder's LIVE rank+status via `boxes.decideEnsureAction`, mirroring `/box/source-access`). It writes a row to the new **`box_intents`** queue (migration 070): `provision` when the builder has no box (auto-provision), `wake` when their box is parked (wake-on-connect), a no-op heartbeat when already active. At most ONE open intent per builder (a partial unique index), so a flaky Chromebook tab can't pile up duplicates.
- **The control-plane runner drains the queue.** `scripts/gds/box.js run-intents --apply`, on a 1-minute `box-intent-runner.timer` (the same systemd-timer pattern as the idle/dormant sweeps), claims each pending intent (`FOR UPDATE SKIP LOCKED`) and calls the SAME `cmdProvision`/`cmdWake` an operator uses — with a small attempt cap so a poison intent retires to `error` rather than looping. The web tier stays powerless over infra; it can only ask.
- **Web/Chromebook pairing: the box reports its link UP.** A Chromebook has no Claude Desktop, so its on-ramp is the `claude rc` Remote-Control pairing link — which previously existed only in the box's journal (reachable only via SSH, defeating the purpose). Now `infra/box-report-pairing.sh` (a 1-min box cron, authenticated as the builder via the GDS token already on the box) POSTs the current link to **`POST /api/gds/box/pairing`** (stored on `builder_boxes.remote_pairing_url`, only while the box is `active`), and the builder reads it from the browser via **`GET /api/gds/box/pairing-link`** (returned only to the box's own builder). The Chromebook flow: `POST /box/ensure` → poll `GET /box/pairing-link` until a link appears → open it.

**Honest limit (recorded).** The server-side decision core (`decideEnsureAction`, the intent queue, the three routes, the runner) is verified hermetically (`tests/boxes.mjs` 33 assertions, `scripts/gds/smoke-box.sh`). The **live legs are unverified on hardware** — same posture as §9.2/§9.3: a real box actually being auto-provisioned by the timer, a parked box waking on `ensure`, and `claude rc` publishing a real pairing link that reaches the browser. The `box-intent-runner.timer` + `box-report-pairing` cron must be installed on the control plane / baked into the box (the cloud-init wires the box cron; the operator installs the control-plane timer per the lifecycle recipe).

## Implementation sub-tasks (proposed — to be seeded in a planning/triage session)

Not yet created; listed so the build session has a starting decomposition.

| Proposed task | What it builds | Criterion |
|---|---|---|
| Devcontainer foundation | `devcontainer.json` + Dockerfile (Node 22, Python + art libs, `sharp` deps, Claude Code feature + firewall); fold in `setup-builder.sh`; `doctor.js` as health check | C1 |
| Prod-deploy to CI | Move prod deploy to GitHub Actions (mirror `deploy-staging.yml`) so no builder box holds the droplet key | C8 / security |
| DO box provisioning + auto-suspend | Per-builder box provision, idle snapshot/park + recreate, dormant de-provision; rank-gated | C1 / cost |
| Managed-settings + Remote Control service | Distribute the locked `sshConfigs`/`sshHostAllowlist`; always-on `claude rc` for thin devices | C1 |
| Rank-gated source access | Box holds the scoped GitHub credential; access granted/revoked by rank; offboarding clawback | C2 / C7 / C9 |
| Onboarding primer page ✅ | **Done** — the §"mental model" explainer lives in [`docs/onboarding/primer.md`](../onboarding/primer.md) § "Where your work runs" (extracted in the ADR 0035 rewrite, [#718](https://example.com/builders#/task/718); closed by task 601) | C1 |
| Cost passthrough wiring | Org-funded starter → self-fund transition via `costs`/drachmae | cost |
