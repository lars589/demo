# ADR 0113 — Per-builder art sandbox (task 885): descope to the Studio only, superseded by ADR 0044/0052

**Date:** 2026-07-03
**Context:** [task 885](https://example.com/builders#/task/885) ("Per-builder art sandbox + sprite studio"), goal 25 (builder experience). Companion to [ADR 0044](<redacted>.md) (per-box live game preview), [ADR 0052](<redacted>.md) (game-only preview entry, every rank), and [ADR 0083](<redacted>.md) (the game's carve into `modules/game/`).
**Status:** Accepted.
**Track:** `internal` (builder experience / dev box).

## Problem

Task 885 was filed 2026-06-09 with a full 8-part build plan: a walkable single-player preview reached by skipping the multiplayer connect, a static file server + systemd unit for `sandbox-<login>.example.com`, a `cf-tunnel.js` multi-ingress change, box-provisioning wiring, a "reset to main" script, and a sprite/animation studio — plus retiring the frozen `staging.example.com` environment as "Part C".

By the time this session picked the task up (2026-07-03), the plan had gone stale on two independent axes:

1. **Most of it already shipped, differently, one day later.** ADR 0044 (2026-06-10, task [#897](https://example.com/builders#/task/897)) already gives every full-clone box a live `sandbox-<login>.example.com` — not a static-file simplification, but the box's own real game server (`box-game-preview.service`, degraded-DB, real Colyseus rooms) over the same Cloudflare named tunnel the terminal already uses. ADR 0052 (2026-06-13, task [#1001](https://example.com/builders#/task/1001)/[#1002](https://example.com/builders#/task/1002)) then widened it to every rank via a dedicated game-only entry (`src/preview-server.js`) and put the game paths in the starter sparse clone. So task 885's Part A1 (walkable preview) and Part B (static server + systemd unit + `cf-tunnel.js` multi-ingress + provisioning wiring) describe infrastructure that exists already, under a different, better design (a real multiplayer world instead of an offline single-player mode) and a different hostname/tunnel mechanism than the one it proposed building.
2. **The repo moved underneath it.** The game client the plan's touches\[\] pointed at (`public/game/scenes/WorldScene.js`, `public/game/player/Player.js`, `src/bongos/cf-tunnel.js`, `src/bongos/routes/box.js`, `src/bongos/boxes.js`) was carved into modules under ADR 0083/0093: the game now lives at `modules/game/public/game/...`, the tunnel CLI at `scripts/gds/cf-tunnel.js`, and the box routes/db at `modules/dev-box/{boxes.js,routes/box.js}`. None of the file paths in the original breakdown table resolve today.

Separately, task 885's Part C ("retire the frozen staging env") directly contradicts a standing decision: `docs/recipes/staging-environment.md` records a deliberate **defer-not-delete** call from 2026-05-29 — staging was frozen (not torn down) specifically because re-provisioning it later costs real time, and the environment costs ~$0/mo idle. Task 885 re-proposing its removal, a week later, with no reference to that decision, is exactly the kind of drift this ADR exists to catch before code gets written against it.

## Decision

**Descope task 885 to the one part of its plan that is still real, unbuilt, and non-duplicative: the sprite/animation Studio.** Everything else in the original breakdown is either already shipped (Parts A1/B, under ADR 0044/0052) or conflicts with a standing decision (Part C, staging) and is dropped from this task's scope without re-litigating it here.

The Studio — a sprite/animation reviewer at `/studio` (pick a sprite, play its walk cycle, flip direction, step frames, zoom, swap background) — has no existing equivalent. It gets built as a *viewer that imports the game's own code*, attached to the **existing** sandbox rather than a new one:

- It layers onto `modules/game/public/` as a static page (`studio.html` + `game/studio/studio.js`), served automatically by the `express.static(GAME_PUBLIC, …)` mount both `server.js` and `src/preview-server.js` already have — no new server, tunnel, or systemd unit. The precedent is `/art` (task 1262's generated-art gallery), already living in `src/preview-server.js` as an explicit route; `/studio` needs no explicit route at all since it's a static page, not a per-request render.
- It auto-discovers sprites from `/assets/tiles/manifest.json` (the same cache `tilePalette.js:preloadTilePalette` already loads) and uses the game's own key helpers (`PLAYER_DIRS`/`WALK_FRAMES`/`playerTextureKey`/`playerWalkTextureKey` in `modules/game/public/game/player/playerSprite.js`) so new sprites need zero studio edits.
- The one shared extraction task 885 correctly identified is still needed: the right-facing mirror logic in `Player._applyIdleTexture`/`_applyWalkTexture` (`modules/game/public/game/player/Player.js:59-79`) becomes `modules/game/public/game/player/spriteFacing.js`, called by both `Player.js` and the studio — a behavior-preserving refactor, not new logic.

This is filed as [a single new child task](https://example.com/builders#/task/885) under 885 rather than the original 8, since the remaining scope is small enough not to need a multi-task breakdown.

## Consequences

- No duplicate sandbox mechanism, no `cf-tunnel.js` change, no new systemd unit, no provisioning rewiring — the existing ADR 0044/0052 sandbox is left alone.
- Staging stays frozen-not-deleted, unchanged from the 2026-05-29 decision; if retiring it is still wanted, that needs its own task that references (and explicitly overrides, with reasoning) that decision — not a drive-by line item in an unrelated epic.
- The Studio ships as a small, self-contained addition: two new static files + one extraction + (if wanted) a prod-only gate so `/studio` doesn't show up as a public game page — left to the child task's judgment, since the `/art` precedent already runs unguarded on the sandbox and the studio is no more sensitive.
- Future planning-session epics that embed a multi-task breakdown table should be re-validated against current `git log`/file layout before their child tasks are minted, not executed mechanically — this is the second time in this repo a stale breakdown table was caught only by checking the live repo first (companion precedent: the ADR 0088 dependency backfill session).

## Alternatives considered

- **Execute the original 8-task breakdown as written** — rejected: would build a second, weaker sandbox mechanism (static files, offline single-player) alongside the real one (live degraded-DB multiplayer) that already serves the same hostname, and would reopen the staging-retirement decision without cause.
- **Silently drop task 885** — rejected: the Studio idea is genuinely good and still unbuilt; dropping the whole task would lose it.
