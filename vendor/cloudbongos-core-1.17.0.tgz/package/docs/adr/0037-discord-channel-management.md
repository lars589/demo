# ADR 0037 — Bot-managed Discord channels from a config file, Archon-gated commands

**Status:** Accepted — 2026-06-06
**Context task:** [#727](https://example.com/builders#/task/727) (GDS-V3). Absorbs idea_inbox [#200](https://example.com/builders#/idea/200) ("discord builders channel role access auto managed by the example bot").
**Companions:** [ADR 0032](0032-discord-mirror-of-gds.md) (Discord = one-way window into the GDS), [ADR 0033](<redacted>.md) (the bot is a service principal, never an authority), [ADR 0016](<redacted>.md) (the trust boundary), [ADR 0026 §6C](<redacted>.md) (the <redacted> write pattern this reuses).

## Context

The Example Discord has a fixed channel layout (PUBLIC: welcome, ship-news, agora, support; BUILDERS: ship-feed, ideas, red-team, planning, archon-only). Until now those channels were created and described by hand. Lars asked for two things:

1. The bot should **create and edit channels itself** (topics, and which ranks may see each channel — the access question from idea [#200](https://example.com/builders#/idea/200)).
2. **Lower ranks cannot command the bot.** Any *command* that makes the bot act must be **Archon-only**; the bot's **passive** features (ship-feed applause counting, #ideas inbound filing, rank role badges) stay open to everyone, as designed in ADR 0033.

The risk this design must avoid is the one ADR 0016 closes: a Discord action becoming an authority. Channel layout is cosmetic, but "the bot edits the server on command" is still a command surface that must be gated where it is load-bearing — the server, against the live `builders.rank`.

## Decision

**1. The channel layout is a repo config file, not bot state.** `docs/discord/channels.json` is the single source of truth: each category/channel declares its `name`, `topic`, and `view` (who may see it — `everyone` or a rank name, where a rank grants that rank and every rank above it). Because changing channels means editing a repo file and merging it, and merging is itself rank-gated, the layout is **Archon-gated by construction**.

**2. The bot reconciles one-way (config → Discord), best-effort, never destructive.** `src/bongos/discord-channels.js` matches existing channels by **slug** (emoji + separators stripped, lowercased — so `📯-ship-news` matches `ship-news`), edits topics + view-permissions **in place**, and creates anything missing. It **never deletes** a channel. This mirrors role-sync (ADR 0033 §4): read the repo, write Discord, no path back. View-permissions are applied as Discord permission overwrites for the `VIEW_CHANNEL` bit only — every other permission bit on a channel, and every unmanaged role's overwrite, is preserved.

**3. The command surface is Archon-only, server-enforced.** `src/bongos/routes/discord.js` exposes `GET /api/gds/discord/channels/plan` (dry run) and `POST /api/gds/discord/channels/reconcile` (apply), both behind `requireBuilder` + `requireRank('archon')`. A Metic, Thetes, Xenos, or unauthenticated caller gets a 403. The CLI (`scripts/gds/discord-channels.js plan|apply`) is a thin wrapper over these routes, so the gate stays on the server — a builder editing local files cannot bypass it (ADR 0016).

**4. The passive sweep is kill-switched, default OFF.** The bot also reconciles channels on connect + every 6h, but only when `DISCORD_CHANNELS_MANAGED=true` (mirrors `BFG_WRITE_ENABLED`, fail-closed). With the switch off, channels are touched **only** by an explicit Archon command. This stops the bot from surprise-editing a guild the moment it connects.

**5. Passive engagement features are untouched.** Applause, #ideas inbound, and role badges remain open to all ranks. "Lower ranks can't use the bot" means **they can't command it**, not that they can't be served by it.

## Access mapping (defaults — editable in the config)

| Channel | view | Who sees it |
|---|---|---|
| welcome, ship-news, agora, support | `everyone` | all (players included) |
| ship-feed | `everyone` | all — keeps the ADR 0033 §3 "anyone can applaud" rule true |
| ideas | `everyone` | all — keeps inbound open; attribution still requires a link |
| red-team | `metic` | Metic + Archon (matches `/builder-redteam`) |
| planning | `metic` | Metic + Archon (matches the planning/priority skills) |
| archon-only | `archon` | Archon only |

These live in `channels.json` and are reviewed/changed by editing that file.

## Consequences

- **Trust boundary holds.** Channels are a cosmetic reflection of an Archon-reviewed file; the command that applies them re-checks live rank server-side. The bot never decides anything.
- **Go-live prerequisite (human, browser).** The bot must hold Discord's **Manage Channels** permission and sit above the managed channels — same shape as the Manage Roles prereq in ADR 0033. Without it, reconcile ops 403 and are logged; the GDS is unaffected. Tracked as a blocker on [#727](https://example.com/builders#/task/727).
- **Live verification deferred.** The pure planner is fully unit-tested (`tests/discord_channels.mjs`); real channel edits require the bot on + Manage Channels and are verified at go-live.

## Alternatives considered

- **Discord slash command (`/channel create`).** Rejected for now — a new in-Discord command surface to secure, when the repo config already gives an Archon-gated, reviewable, version-controlled source of truth.
- **Pure Discord role permissions, no bot.** Rejected — it would make Discord roles the authority for "who can change channels," exactly the inversion ADR 0016 forbids; and it can't keep topics/structure honest.
- **Bot writes with its own authority / no kill-switch.** Rejected — re-opens ADR 0016 and risks a connect-time surprise edit. The command gate + default-OFF passive sweep is the whole point.
