# Recipe — Memory sync conflicts: policy + clobber recovery

> **Filed by:** task [#277](https://example.com/builders#/task/277) (V3.R58), GDS-V3 criterion C8. Documents the conflict policy chosen by the R04 spike ([ADR 0024](../adr/<redacted>.md) §3) and implemented across [#274](https://example.com/builders#/task/274) (push), [#275](https://example.com/builders#/task/275) (pull), [#276](https://example.com/builders#/task/276) (isolation). Recovery leans on the backup pipeline from [#281](https://example.com/builders#/task/281) ([`memory-backup.md`](memory-backup.md)).

## The policy in one line

**Last-write-wins, per file, server clock authoritative.** No merge, no rejection, no warning.

## How sync works (so the policy makes sense)

Memory is **local-first, server-canonical on ship**. There are exactly two sync moments — no background polling, no mid-session sync:

| Trigger | Direction | What happens |
|---|---|---|
| `/builder-ship` succeeds ([#274](https://example.com/builders#/task/274) R55) | **push** local → server | `POST /api/gds/memory/sync` upserts each local memory file into `builder_memory`. Every file is written unconditionally — the **last push to land wins**. |
| `SessionStart` / `/builder-start` ([#275](https://example.com/builders#/task/275) R56) | **pull** server → local | client reports its newest local `mtime`; `GET /api/gds/memory/since?mtime=…` returns files the server holds that are **newer**; client writes them over local copies. |

The stored `mtime` is the client's reported file mtime and is **advisory** — used only by the pull side's newer-than check. The server's own `updated_at` (trigger-maintained) is the authority for "when did this row actually change." A client cannot win a conflict by forging a future mtime: an unparseable mtime is normalized to `NULL`, and the server clock governs.

`builder_id` is the GitHub user, not a session — so "two different builders racing on the same file" is impossible by construction. Every conflict below is **one builder, more than one machine or session**.

## Edge cases

### 1. Same file edited in two parallel sessions (two machines / two worktrees)

Builder edits `MEMORY.md` on the desktop and, in a parallel session, on the laptop. Both ship.

- Both sessions push. **Whichever push lands at the server second overwrites the first** — the server now holds exactly one version (the later push). No merge is attempted; the earlier push's content is gone from the server.
- The "losing" machine still has its own local copy until its **next** `SessionStart` pull, which then overwrites it with the server's surviving version. After that pull, both machines agree.
- **Net:** one version survives end-to-end; the other is lost. Lost-write window ≈ one session boundary. If the lost version mattered, recover it from backup (below).

> Practical avoidance: don't run two live sessions editing the same memory file. Memory edits are cheap to redo; the system optimizes for "never half-merge a plausible-but-broken file" over "never lose a keystroke."

### 2. Server has a newer version than local

Builder shipped from the laptop yesterday (server now newer), then opens the desktop today.

- `SessionStart` pull sees the server's `mtime` is newer than the desktop's local copy and **writes the server version over the local file**. Desktop is now current. This is the intended path — it's how memory "follows you between machines."
- Risk only arises if the desktop had **unpushed local edits older** (by mtime) than the server's version — those would be overwritten on pull. In normal use local edits are the newest thing, so this is rare; when it bites, recover from backup.

### 3. Local newer than server (the common, non-conflict case)

Local edits since the last ship are newer; on next `/builder-ship` they push and become canonical. No conflict. This is the steady state.

## Operator recovery — restore a clobbered file from backup

When a builder confirms a real clobber, the lost version is recoverable from any `pg_dump` taken **before** the overwrite (nightly local, 30-day retention; weekly offsite, 4-week — see [`memory-backup.md`](memory-backup.md) / [`gds-db-backup.md`](gds-db-backup.md)). The dump must predate the bad push.

```bash
# 1. Restore a pre-clobber dump into a sandbox (NON-destructive to prod).
DUMP=/var/backups/gds/example-<ts-before-the-clobber>.sql.gz
sudo -u postgres dropdb --if-exists example_recover
sudo -u postgres createdb example_recover
gunzip -c "$DUMP" | sudo -u postgres psql -q -d example_recover

# 2. Extract the old content to a FILE (never paste content inline — see the
#    warning below). -tA = unaligned, no headers; one file's content out.
#    (Archon-run, on the droplet; this is the one place reading content is OK —
#     it's a deliberate recovery, logged by this recipe's existence.)
sudo -u postgres psql -d example_recover -tAc \
  "SELECT content FROM builder_memory WHERE builder_id=<id> AND path='<path>';" \
  > /tmp/recovered.txt

# 3. Hand the file back to the builder. Two ways:
#    (a) PREFERRED — give them /tmp/recovered.txt; they drop it into their local
#        memory dir and /builder-ship to re-push it. Keeps the builder as the
#        author of their own memory, and the push path recomputes sha256/byte_len.
#    (b) Archon writes it straight into prod IF the builder can't. Load the
#        content from the FILE via a bound parameter — do NOT inline it into the
#        SQL (a naive dollar-quote breaks if the content itself contains the
#        quote tag, and string-pasting risks injection during a high-stress run):
sudo -u postgres psql -d example \
  -v content="$(cat /tmp/recovered.txt)" \
  -c "INSERT INTO builder_memory (builder_id, path, content, sha256, byte_len)
      VALUES (<id>, '<path>', :'content', encode(sha256(:'content'::bytea),'hex'),
              octet_length(:'content'))
      ON CONFLICT (builder_id, path) DO UPDATE
        SET content=EXCLUDED.content, sha256=EXCLUDED.sha256, byte_len=EXCLUDED.byte_len;"
#    (`:'content'` is psql variable interpolation with proper literal quoting —
#     safe for arbitrary content, and sha256/byte_len are recomputed in-SQL so
#     they can't drift from the restored bytes.)

# 4. Clean up the sandbox and the temp file.
sudo -u postgres dropdb example_recover && rm -f /tmp/recovered.txt
```

> **Privacy note:** another builder's memory is private ([#276](https://example.com/builders#/task/276) R57 isolation; Archon forensic reads are audit-logged). Recovery is the builder's own file, or an explicitly-authorized Archon action — never a casual cross-builder read. Prefer path (a) so the builder re-pushes their own content.

## Why not something smarter? (rejected alternatives, from ADR 0024 §3)

- **Three-way markdown merge** — rejected: a half-merged `MEMORY.md` that *looks* plausible but is structurally broken is worse than a clean lose-one. Revisit in V4 only if real collisions show up in V3.
- **Optimistic concurrency** (reject stale-base pushes, force pull-first) — rejected: builders would just `--force` around it. Last-write-wins + a backup recovery path is simpler and handles the rare bad case.

## See also

- [ADR 0024](../adr/<redacted>.md) §3 — the decision + rejected alternatives.
- [`memory-backup.md`](memory-backup.md) — backup cadence + the restore drill the recovery above relies on.
- [`gds-db-backup.md`](gds-db-backup.md) — the underlying dump/offsite pipeline.
