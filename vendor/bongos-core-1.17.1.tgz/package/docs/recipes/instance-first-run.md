# First run: clone → working instance

> The one-shot path from `git clone` of a **standalone Cloud Bongos instance repo**
> (ADR 0108 — a repo that pins `@cloudbongos/core` as a dependency, e.g. `example-owner/demo`)
> to a session that can actually claim + ship work. This is for a **builder joining an
> existing instance**; standing up a *new* instance is `/new-project` (`bongos onboard`).

## Why this recipe exists

A cloned instance repo ships `config/` + `package.json` + a vendored core tarball, but
**not** the installed engine. Until you install it there is no `bongos` binary and no
`scripts/gds/…`, so every `/builder-*` skill fails. An agent that presses on in that
state has no tools of its own and can fall back on whatever *other* Cloud Bongos instance
the machine is signed in to — which is how a `demo` clone once offered to write a task
into the wrong live backlog (2026-07-08). The session-start hook now prints these same
steps when it detects an uninstalled instance (task 2105); the wrong-instance write it
used to risk is refused outright (task 2102).

## The steps

From the repo root, in order:

```bash
# 1. Install the engine (the vendored core → node_modules + the `bongos` bin).
#    No registry auth needed: the dependency is a local file: tarball.
npm install

# 2. Sign in to THIS instance (one browser click — no code to paste).
#    Use the instance's own origin — the one in config/branding.json → domains.publicOrigin.
npx bongos login https://<this-instance-origin>

# 3. Confirm you're wired up: this lists what you can claim right now.
npx bongos start
```

That's it — `bongos claim <id>` / `bongos ship` now work, scoped to this instance.

## Notes

- **Sign in to the RIGHT instance.** `bongos login <url>` writes a per-instance session
  (`session.api_base`), and the CLI **refuses to act** if the session it would use belongs
  to a different instance than this repo is configured for (task 2102). If you see that
  refusal, re-run `bongos login` with *this* instance's origin.
- **Which origin?** `config/branding.json` → `domains.publicOrigin`. `GET <origin>/api/bongos`
  also re-advertises an instance's own hall/status/docs origins (the docs-discovery contract,
  ADR 0114).
- **Invite-only by default.** A brand-new GitHub account isn't admitted until an Archon
  approves it; `bongos login` files the request and waits, then finishes sign-in.
- **The engine lives in the package, not the repo.** `bongos` resolves the heavy CLI inside
  `node_modules/@cloudbongos/core`; that's why step 1 must come first. On a machine with the
  core installed globally you can drop the `npx`.
