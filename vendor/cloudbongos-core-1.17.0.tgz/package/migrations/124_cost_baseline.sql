-- 124_cost_baseline.sql — the savings counterfactual ledger (GDS-V4 task 1345,
-- System 1: Cost Attribution & Savings Ledger).
--
-- Every later LLM-reduction system (compaction, value-gate, deterministic cron,
-- LLM cache) needs to PROVE its savings in dollars, not assert them. This tiny
-- table is where each records a counterfactual: "this run cost amount_usd; had
-- the system not acted it would have cost baseline_usd". The saving is
-- SUM(baseline_usd - amount_usd) grouped by system tag (db.costSummary().savings,
-- surfaced on /public/cost-summary).
--
-- CONTRACT (enforced by the writing code, not the schema): baseline_usd is
-- ALWAYS computed server-side from token counts via src/bongos/llm-pricing.js
-- priceUsage() — NEVER a client-supplied dollar figure (the same trust rule as
-- the cost-plus reward, ADR 0054). A system records here only what it can price
-- from real usage.
--
--   system        — the system/lever claiming the saving, e.g.
--                   'system2:compaction', 'system5:llm-cache'. Free text tag.
--   baseline_usd  — counterfactual cost had the system NOT acted (priced).
--   amount_usd    — what it actually cost (priced; 0 for a full elimination).
--   source_ref    — per-event idempotency key (e.g. a tree-SHA or session id).
--   description   — optional human note.
--
-- Idempotent unique index on (system, source_ref) so a system can safely
-- re-record the same event without double-counting (mirrors cost_log's pattern).
-- Additive, new table, safe to re-run.

CREATE TABLE IF NOT EXISTS cost_baseline (
  id           bigserial PRIMARY KEY,
  system       text NOT NULL,
  baseline_usd numeric NOT NULL,
  amount_usd   numeric NOT NULL DEFAULT 0,
  source_ref   text,
  description  text,
  task_id      integer,
  builder_id   integer,
  recorded_at  timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS uniq_cost_baseline_system_ref
  ON cost_baseline (system, source_ref)
  WHERE source_ref IS NOT NULL;

INSERT INTO schema_migrations (version) VALUES ('124_cost_baseline')
  ON CONFLICT (version) DO NOTHING;
