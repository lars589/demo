# Releasing the Dev Box desktop app

How a new version of OTB Dev Box (`devbox-app/`, ADR 0045) reaches builders.
The chain: CI builds installers → operator publishes them to the PUBLIC
releases repo → a one-line config bump re-points the branded
`/downloads/devbox/*` redirects. Nothing binary ever rides the git deploy.

## 0. What's where

- **Source:** `devbox-app/` in the main (private) repo.
- **CI:** `.github/workflows/build-devbox-app.yml` — builds on every push
  touching `devbox-app/**` (mac dmg arm64+x64 on macos-14, NSIS exe x64+arm64 on
  windows-latest) and uploads workflow artifacts. No publishing from CI.
- **Public releases repo:** named in `config/devbox-app.json`
  (`releases_repo`). Assets live on GitHub releases there; GitHub's CDN
  serves the downloads, $0.
- **Branded URLs:** `https://example.com/downloads/devbox/<target>`
  (302 → release asset; targets `mac-arm64`, `mac-x64`, `win-x64`, `win-arm64` + aliases)
  and `/downloads/devbox/latest.json` (what the app's update check reads).
  Server side: `src/devbox-downloads.js`, mounted in `server.js`.
- **Install-window backdrop ([#912](https://example.com/builders#/task/912), fixed in [#1235](https://example.com/builders#/task/1235)):** the on-brand
  Greek-coast art is `build-resources/dmg-background.png` (+ `@2x`), drawn by
  `scripts/gen-dmg-backdrop.py`. Committed art — re-run that script + commit if you change
  the layout/copy. **The DMG is NOT styled by electron-builder.** electron-builder writes a
  `.DS_Store` whose background reference includes a modern `pBBk` bookmark that Finder on
  macOS ≥ Sonoma/Sequoia (verified white on 15.7.4) cannot resolve — so its install window
  renders solid white even though the image is embedded (this is exactly what shipped broken
  in v1.0.5/v1.0.6; it is NOT a Finder cache and NOT an OS limitation — macOS renders DMG
  backgrounds fine). Instead, the CI step **"Apply install-window backdrop (dmgbuild)"**
  (`scripts/apply-dmg-backdrop.sh` + `scripts/dmgbuild-settings.py`) re-packages the
  signed+notarized `.app` out of electron-builder's DMG into the final DMG with
  [`dmgbuild`](https://pypi.org/project/dmgbuild/), which writes an alias-only `.DS_Store`
  (no `pBBk`) that DOES resolve and render. `dmgbuild` is headless (no Finder), so it runs in
  CI; the `.app` is copied verbatim with `ditto`, so notarization is preserved; the DMG is an
  unsigned carrier either way. Keep the icon coords + window/iconSize in
  `scripts/dmgbuild-settings.py` matched to `electron-builder.yml` and the art's wells
  (180,198 / 480,198, 660×400, size 100). **Verify after a mac release:** mount the published
  arm64 DMG and confirm the backdrop draws — quick non-Finder check:
  `hdiutil attach <dmg> -nobrowse -readonly -mountpoint /tmp/m && python3 -c "d=open('/tmp/m/.DS_Store','rb').read(); print('renders:', b'pBBk' not in d and b'.background' in d)"`
  (`pBBk` must be **absent**).

## 1. Cut a release

1. Bump `devbox-app/package.json` version (e.g. `1.1.0`) and regenerate
   icons only if they changed (`npm run icons`).
2. Push the branch; wait for `build-devbox-app` to go green.
3. Download the artifacts:
   ```
   gh run download -R example-owner/example -n devbox-app-mac -D /tmp/devbox-rel
   gh run download -R example-owner/example -n devbox-app-win -D /tmp/devbox-rel
   ```
   (or build the mac side locally: `cd devbox-app && npm run dist:mac`).
4. Publish to the public releases repo (tag = `v<version>`, must match what
   `src/devbox-downloads.js` composes):
   ```
   gh release create v1.1.0 -R example-owner/example-devbox \
     --title "OTB Dev Box v1.1.0" --notes "…" /tmp/devbox-rel/*.dmg /tmp/devbox-rel/*.exe
   ```
5. Update `config/devbox-app.json`: `version` + the four asset filenames
   (they embed the version — `tests/devbox_downloads.mjs` fails the gate on a
   half-bumped config).
6. Ship the config change through the normal GDS flow. **Bumping `config/devbox-app.json`
   `version` is what triggers the in-app update banner in the field ([#924](https://example.com/builders#/task/924))** — running
   apps poll `GET /downloads/devbox/version`, compare it to their own `package.json`
   version with a proper semver compare (`devbox-app/src/updater.js`), and show
   "Update available — v<x>" + a one-click Update button only when the published
   version is STRICTLY newer. Apps re-check on open and every 12h, so a running app
   surfaces a new release within ~12h (sooner if reopened). The config version must
   therefore be ≥ the shipped `package.json` version, or no one is offered the update.
   The hall `/settings` download card reads the same endpoint to show "Latest version: vX".

## 2. Verify after deploy

```
curl -sI https://example.com/downloads/devbox/mac-arm64 | grep -i location
curl -s  https://example.com/downloads/devbox/version     # { version, assets:{target:url} } — the app's update-check payload
curl -s  https://example.com/downloads/devbox/latest.json # { version, assets:{target:{file,url}} } — the downloads page payload
curl -sIL https://example.com/downloads/devbox/win-x64 -o /dev/null -w '%{http_code}\n'   # expect 200
```

## Gotchas

- **The tag and asset filenames must match the config exactly** — the
  redirect is `releases/download/v<version>/<asset>`; a renamed asset 404s.
- **Unsigned builds:** until the Apple Developer ID / Windows cert decision
  (open blocker), keep the "Open Anyway" / SmartScreen copy in the hall
  onboarding + settings pages accurate. When certs land: sign + notarize in
  CI, then revisit real auto-update.
- **`devbox-app/build-resources/`** is committed source (the app icon); the
  name avoids the root `.gitignore`'s global `build/` rule. Output goes to
  `devbox-app/dist/` (ignored).
- **The releases repo is public** — never attach anything but the installers
  (no env files, no maps, no internal docs).
