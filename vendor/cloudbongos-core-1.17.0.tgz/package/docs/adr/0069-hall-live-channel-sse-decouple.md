# ADR 0069 — Builders-hall live updates move from Colyseus WebSocket to SSE

- **Status:** Accepted
- **Date:** 2026-06-20
- **Deciders:** task [#1194](https://example.com/builders#/task/1194) (V4.R55) — part of the Cloud Bongos standalone-instance work (C8, [ADR 0062](<redacted>.md))
- **Track:** `internal` (the builders hall)
- **Supersedes:** the *transport* decision of [ADR 0030](<redacted>.md) §2 (WebSocket/Colyseus). The change-signal layer of ADR 0030 (Postgres `NOTIFY` + `src/bongos/live-channel.js`) is **unchanged** and still authoritative.

## Context

[ADR 0030](<redacted>.md) gave the hall live updates in two layers: a transport-agnostic change-signal (a statement-level `NOTIFY` trigger relayed by one persistent `LISTEN` connection in `live-channel.js`) and a **delivery transport** — a broadcast-only Colyseus room (`builders_hall`) riding the game's existing WebSocket server. ADR 0030 explicitly considered SSE, called it "arguably the textbook fit for a receive-only dashboard," and rejected it for one reason only: to **reuse the game's already-proxy-proven Colyseus stack** rather than stand up a second long-lived-connection mechanism.

That reason is exactly what the Cloud Bongos decoupling (C8) removes. The GDS-only entrypoint (`src/platform-server.js`, [R51](<redacted>.md)) boots the build platform with **no Colyseus in the process**. A `builders_hall` room cannot exist there, so on a game-less instance the hall's only live feature was dead — it would freeze at load exactly as it did before ADR 0030. The transport was load-bearing on the game runtime, which a standalone Cloud Bongos instance does not have.

## Decision

Move the hall live transport to **Server-Sent Events**: `GET /api/gds/live` (`src/bongos/routes/live.js`), mounted **unconditionally** in the GDS router (`buildGdsRouter`). Because that router mounts in *both* entrypoints (`server.js` and `platform-server.js`), the hall refreshes live whether or not the game is in the process — which is the R55 done-when.

- **Signal layer untouched.** The endpoint `subscribe()`s to the same `live-channel.js` relay the room used. Triggers, channel, and fan-out logic are identical (ADR 0030 §1 still governs them).
- **Same zero-leak contract.** It emits an opaque `nudge` event with an empty `{}` body — never the relay's `{table, op}` (leaking internal table names was a hacker-dispatch finding on [#569](https://example.com/builders#/task/569)). The hall re-runs its authenticated per-panel fetches on any nudge, so access control stays where the data is.
- **Auth + abuse control.** `requireBuilder` gates the stream (mirrors the room's [#983](https://example.com/builders#/task/983) signed-in requirement; the `gds_session` cookie rides the same-origin `EventSource` GET). A per-IP concurrent-connection cap is kept **inline** in the route — deliberately *not* imported from `src/rooms/hall-join-guard.js` — so the GDS live channel carries **zero game-code dependency**, which is the point of R55.
- **Client simplifies.** `public-builders/builders.js` opens an `EventSource` instead of joining a Colyseus room. `EventSource` reconnects natively, so the manual 4 s rejoin backoff is gone; the debounced `loadAll()`, the don't-clobber-active-input guard, and the `visibilitychange` backstop are kept. The hall no longer loads `/vendor/colyseus.js`.
- **Dead code removed.** `src/rooms/BuildersHallRoom.js`, `src/rooms/hall-join-guard.js`, and `tests/builders_hall_room.mjs` are deleted; `server.js` no longer defines `builders_hall`. The game still serves `/vendor/colyseus.js` for itself — only the hall stopped depending on it.

## Alternatives considered

- **Keep the Colyseus room AND add SSE (pick per boot).** Rejected: it leaves two parallel live mechanisms — precisely the "second long-lived-connection style" ADR 0030 wanted to avoid — and doubles the maintenance surface for a tiny internal feature. SSE works in both boots, so the room is pure dead weight after the client rewire.
- **A raw `ws` endpoint instead of SSE.** Rejected: the channel is strictly receive-only, so WebSocket's bidirectionality buys nothing, and `ws` would reintroduce a long-lived-connection lib and a hand-rolled reconnect/heartbeat the browser's `EventSource` gives for free.

## Consequences

- The hall is live on a game-less Cloud Bongos boot — the executable R55 done-when lives in `tests/platform_boot.mjs` (`GET /api/gds/live` is mounted + auth-gated, not 404) and `tests/live_sse.mjs` (SSE framing, bare-nudge no-leak, per-IP cap).
- One fewer long-lived-connection style on the internal surface; the hall's realtime path no longer touches the game runtime.
- SSE must traverse Caddy → Cloudflare. It rides plain HTTP with `Cache-Control: no-cache, no-transform` + `X-Accel-Buffering: no`, and a 25 s heartbeat comment keeps the stream under Cloudflare's ~100 s idle timeout.
- If a future change ever puts row data on this channel, the `requireBuilder` gate already in place must stay (ADR 0030's "add an `onAuth` gate first" caveat is satisfied by construction here).
