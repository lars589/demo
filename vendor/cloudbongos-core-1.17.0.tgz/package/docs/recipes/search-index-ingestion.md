# Recipe — GDS search-index ingestion (repo markdown)

How the `search_chunks` index (the recall layer, [ADR 0060](../adr/0060-gds-retrieval-layer.md)) gets populated from repo markdown, and how to operate it. Read before touching `scripts/gds/search-ingest-md.js` or the deploy hook.

> The query side is [`src/bongos/search.js`](../../src/bongos/search.js) + [`POST /api/gds/search`](../../src/bongos/routes/search.js) ([#949](https://example.com/builders#/task/949)); rank/owner scoping + its isolation suite are [#950](https://example.com/builders#/task/950). Ingestion has two halves: **repo markdown** (this recipe's first sections — [#947](https://example.com/builders#/task/947), the deploy hook) and **DB prose** (the [DB-prose nightly](#db-prose-nightly-timer) section below — [#948](https://example.com/builders#/task/948), a systemd timer).

## What it does

`node scripts/gds/search-ingest-md.js` walks the repo's markdown (~226 files), chunks each file via the heading-aware chunker ([`src/bongos/search-chunker.js`](../../src/bongos/search-chunker.js)), and upserts the chunks into `search_chunks`:

- **Delta-driven.** Each chunk's `content_hash` (sha256 of its body) is the change key. The upsert's `ON CONFLICT … DO UPDATE … WHERE content_hash IS DISTINCT FROM EXCLUDED.content_hash` makes an unchanged chunk a **no-op** (no row rewrite). A re-run over an unchanged tree writes nothing.
- **Prunes shrinkage.** If a file loses sections, chunks beyond the new count are deleted; if a file is removed from the tree entirely, all its chunks are deleted (`source_kind='doc' AND source_ref NOT IN (present)`).
- **Scopes by rank.** Most docs are `min_rank='xenos'` (shared). Read-sensitive documentation surfaces are tagged `min_rank='metic'` so a sub-Metic search can never surface them ([ADR 0060](../adr/0060-gds-retrieval-layer.md) §6 / [ADR 0043](../adr/<redacted>.md)). The metic set is curated in `SENSITIVE_DOC_GLOBS`: `docs/canonical-permissions.md`, `docs/security/`, `docs/audits/`, and the two trust-boundary ADRs (0016, 0043). **`CLAUDE.md` is deliberately `xenos`** — it's write-protected but the universal read-public onboarding index. Docs are never owner-scoped (`owner_builder_id` stays NULL); per-builder private content is the DB-prose ingester's job (memory rows).

## When it runs

A **non-blocking step in the prod deploy** ([`scripts/deploy/deploy-prod.sh`](../../scripts/deploy/deploy-prod.sh), mirrored in the droplet's hand-maintained `~/deploy.sh`), after the code update + migrations + healthz, where the new markdown and the DB are both on disk. It's wrapped `timeout 60 … || echo "…deploy unaffected"` — **an ingest failure never fails a deploy**; the next deploy (or a manual run) catches up.

> ⚠️ `scripts/deploy/deploy-prod.sh` is a **byte-faithful mirror** of the droplet's `~/deploy.sh`, which is **hand-maintained and NOT auto-installed** (the ci deploy key is forced-command-locked — [ADR 0042](../adr/<redacted>.md)/[0043](../adr/<redacted>.md)). When you change the mirror, **re-apply the same edit to `~/deploy.sh` on the droplet by hand** (`ssh lars@REDACTED_IP`), or the deploy hook won't actually run there. (Same caveat as the [prod deploy-script mirror](../../docs/recipes/ops-gotchas.md) note.)

## Operating it

```bash
# Dry-run: report file/chunk counts + which sources are metic-tagged. No DB, no writes.
node scripts/gds/search-ingest-md.js --dry-run

# Full ingest (writes to search_chunks). Idempotent — safe to re-run; unchanged
# chunks are skipped. Run on the droplet (DB on the local socket) or anywhere the
# GDS Postgres env (PGHOST/PGDATABASE) resolves.
node scripts/gds/search-ingest-md.js

# Initial backfill after first deploy of the recall layer: just run the full
# ingest once on the droplet — it indexes the whole corpus from empty.
```

Output reports `inserted / updated / unchanged / pruned / deleted_sources_chunks` so you can see the delta. A first run over an empty index inserts everything; subsequent runs over an unchanged tree report all-unchanged.

## DB prose (nightly timer)

`node scripts/gds/search-ingest-db.js` indexes the prose that lives in the DB, not in git, as `source_kind='db'`: task descriptions + value summaries (`task:<id>`), learnings (`learning:<id>`), idea inbox (`idea:<id>`), done-when criteria (`criterion:<id>`), blockers (`blocker:<id>`), session-log notes (`session_log:<id>`), grade notes (`grade:<id>`), per-builder memory (`memory:<builder>:<path>`), and recent git commit subjects (`commit:<sha>`). Same delta-by-content_hash + prune-vanished behavior as the repo-md ingester.

Security ([ADR 0060](../adr/0060-gds-retrieval-layer.md) §6 / [ADR 0016](../adr/<redacted>.md) / [ADR 0022](../adr/0022-secrets-policy.md)):

- **`builder_memory` is owner-scoped** — each chunk carries `owner_builder_id`, so a builder's private memory only ever surfaces to that builder (the search route's owner filter, [#950](https://example.com/builders#/task/950)).
- **`security_sensitive` tasks are tagged `min_rank='metic'`**.
- **`vulnerability_reports` + `security_reports` are excluded entirely** — raw security findings don't belong in a broadly-searchable index.
- **Session/memory/grade text is scrubbed** through `ship.js` `scrubSecrets` (known shapes + high-entropy) before storage — the index must never hold a leaked credential.

It runs on a **nightly systemd timer** ([`infra/search-index-db.timer`](../../infra/search-index-db.timer) → [`infra/search-index-db.service`](../../infra/search-index-db.service), 03:30 UTC, 30 min before the pg_dump so they don't contend), modeled on `gds-db-backup`. DB prose changes more slowly than docs, so nightly is fresh enough; the repo-md half stays intra-day via the deploy hook.

**Operator install (one-time, on the droplet):**

```bash
# Copy the units into place, reload, enable + start the timer, then run once.
sudo cp /home/lars/example/infra/search-index-db.{service,timer} /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now search-index-db.timer
systemctl list-timers search-index-db.timer          # confirm it's scheduled
sudo systemctl start search-index-db.service          # initial backfill now (don't wait for 03:30)
journalctl -u search-index-db.service -n 20 --no-pager # check the run
```

## Gotchas

- **`node` must be on PATH** in the deploy shell (it is — systemd runs the app via node). The script connects via the shared `src/db.js` pool (the same Postgres the app uses), so it needs the GDS env, not a token.
- **The index lags the merge by one deploy** for any doc changed in a PR that doesn't itself trigger a deploy — acceptable; the deploy hook re-indexes on every prod deploy, and the [staleness monitor + /watch tile](https://example.com/builders) (`#972`) surfaces a stalled index.
- **Don't lower the chunk size** without re-checking the eval set ([#939](https://example.com/builders#/task/939)) — chunk granularity affects recall quality and (later) embedding cost.
