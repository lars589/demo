# 0008 — Family-based tile generation with deterministic-first review

- **Status:** Accepted
- **Date:** 2026-05-09
- **Deciders:** Lars
- **Supersedes (in part):** the per-tile generation flow described in the Phase-1 pixel-art pipeline (see [docs/recipes/pixel-art-pipeline.md](../recipes/pixel-art-pipeline.md)), which remains in service for atomic tiles that have not yet been migrated.

## Context

The first pixel-art pipeline ([§7 of CLAUDE.md](../../CLAUDE.md), the original `art/pipeline/orchestrator.py`) generates one tile per call. Each call to the image API has no memory of any other call. This worked acceptably for unrelated atomic tiles (a rock, a single olive tree) but failed structurally for any tile-set whose members must visually cohere:

- The 4-direction player sprite produced **four different-looking characters** — different body sizes, different clothing colors, different hair. Worst-case pairwise palette overlap was 0.29; worst-case dominant-color overlap was 0.00; silhouette pixel counts ranged from 177 to 900 across the four directions.
- The vendor was likewise produced as an unconnected one-off.
- Transition tiles (grass-to-sand edges) and any future autotile path / road / border family would have failed the same way: tiles that *must* line up at seams cannot be generated independently and expected to fit.

The review system was scoring tiles in isolation against a 9-criterion rubric. None of the criteria measured cross-tile coherence. A tile could earn 9.5/10 individually while being entirely incompatible with its declared neighbors.

We needed an architecture that:

1. Forces sibling tiles to be drawn together so they share a single style anchor.
2. Mechanically validates that adjacent tiles match at their edges (and that character frames depict the same individual).
3. Reduces — not increases — total cost per produced tile.
4. Lets Lars approve atomic-swap publish before any tile lands in `art/generated/tiles/`.
5. Stays inside the per-project $80 cap ($79.96 remaining at the time of this ADR).

## Decision

Make the **family** — not the tile — the unit of generation.

A *family* is a coordinated set of members produced as a single image-gen call against a layout grid. Members are sliced out of the returned sheet and post-processed individually.

Concretely:

- New schema: `art/template/families.json`. Each family declares `kind`, `layout`, `members[]`, `shared_style`, and optional per-family threshold overrides. Defaults inherit from a top-level `defaults` block.
- New pipeline modules under `art/pipeline/`:
  - `family_loader.py` — schema loading with defaults inheritance.
  - `family_generator.py` — sheet prompt builder, single-call generation, slicer + post-process.
  - `family_checks.py` — deterministic family-level coherence checks (silhouette area / height CV, palette Jaccard, dominant-color overlap, luminance EMD, self-seam, edge contracts).
  - `family_review.py` — Gemini family-coherence review, scored on family-level criteria (`family_consistency`, `character_identity`, `grid_alignment`, `firered_match`, `mythic_greek`).
  - `family_orchestrator.py` — full retry loop with anchor-refinement on failure.
- Review ordering: **deterministic checks run first. The Gemini review only runs if they pass.** Failures produce numeric fix-hints fed back into the next prompt.
- Publishing is gated behind an explicit `--publish` flag — never automatic. Atomic-swap into `art/generated/tiles/` only happens when Lars approves.
- The old per-tile pipeline is left in service for the 22 atomic tiles that have not yet been migrated. Migration happens family by family as we rebuild the affected zones.

The first family migrated was `player_character` (4-direction sprite, 2×2 layout, 7.0/5.0 thresholds). Result: **passed in one attempt**, Gemini review 8.6→9.0/10, deterministic gate 5/5, total cost $0.078 across two runs (initial + publish run). All five coherence metrics improved by an order of magnitude versus the per-tile output.

## Alternatives considered

- **Keep per-tile generation, add a cross-tile coherence rubric criterion.** Rejected — no Gemini review can fix what's broken at generation time. The model has no way to draw "the same character" twice when called twice with no shared memory.
- **Generate one canonical front-facing sprite, derive the other facings via prompt engineering.** Rejected — fragile, model-dependent, and can't generalize to non-character families like paths.
- **Generate the whole tile-set in one giant sheet (all 23 tiles).** Rejected — the model cannot maintain coherence at that scale, and a single failure would invalidate every tile. Family granularity is the natural unit: small enough to coordinate, large enough to enforce sibling identity.
- **Keep doing per-tile and live with the inconsistency.** Rejected on Lars's first feedback. The "four different characters" failure was visible in-game.
- **Defer the architecture work and ship V1 with placeholder art.** Rejected — V1's brand promise depends on the world feeling crafted. Inconsistent characters undermine that on the first frame the visitor sees.

## Consequences

### Positive

- **Sibling coherence is now generation-time, not review-time.** The model is forced to draw identity-consistent siblings; verification is bookkeeping.
- **Cost per produced tile dropped.** One sheet call (~$0.04) replaces N independent calls (~$0.04 each) plus N independent Gemini reviews. Empirical: the player_character set produced for $0.04 instead of ~$0.16.
- **Failure feedback is numeric and specific.** "Silhouette area CV 0.67 > 0.35, make the character the same size in every cell" is something the next prompt can act on. "Make the characters look more like the same person" was not.
- **Per-family policy** lets us tune thresholds per family kind without code changes.
- **Atomic-swap publishing** prevents half-migrated states. Old tiles stay live until the new family fully passes.

### Negative / costs

- **Higher prompt complexity.** Sheet prompts are longer and more constrained; small errors in the layout description waste an attempt.
- **Sheet aspect ratio constrained by API wrappers.** Nano Banana's wrapper does not currently expose aspect-ratio control, so 1×N layouts are riskier than 2×2 / square layouts. We default to 2×2 for 4-member families until this is resolved.
- **Schema migration must continue.** The 22 non-character tiles still live in the old `vocabulary.json` shape. Migration is incremental, not all-at-once. We carry both shapes during the transition.
- **Threshold tuning is now its own ongoing task.** Per-family overrides need calibration data from real runs across kinds before defaults are trustworthy.

### Operational rules adopted with this decision

1. **The family is the unit of regeneration.** When a member of a family looks wrong, regenerate the whole family — never one cell — to preserve sibling coherence.
2. **Deterministic checks run before Gemini.** No Gemini family-review call fires on a family that fails the deterministic gate.
3. **Publish requires explicit human approval.** No `--publish` flag → no atomic swap into `art/generated/tiles/`.
4. **Per-family threshold overrides live in `families.json`.** Code reads them; no ad-hoc threshold edits in pipeline modules.
5. **Lowered thresholds during phase-1 are temporary.** The `_threshold_note` field on a family records the reason and the ramp condition. Ramp back to defaults after enough family runs to know the real ceiling.

## What this does not change

- The locked 64-color palette (see Phase-0 pipeline notes) remains authoritative. Palette-quantize still runs on every output cell.
- The reference cluster overview (`art/template/cluster_overview.png`) remains the "what FireRed looks like" image passed to the reviewer.
- The cost ledger (`cost_ledger.py`, $80 hard stop) remains the financial gate.
- The style guide (`art/template/style_guide.md`) remains the durable accumulator of Lars's directional feedback. Sheet prompts continue to consume it.
- The procedural fallback (`procedural_fallback.py`) remains available for ground-tile families. Character families have no procedural fallback; the recovery path is anchor-refinement instead.
