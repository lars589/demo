# Hardware-verifying the Dev Box app on Windows (Parallels runbook)

The app's logic is covered by the stub self-test (`OTB_DEVBOX_AUTOFLOW`, see
`devbox-app/README.md`), but four things only a real Windows session can
prove: the UAC elevation write of the Claude Desktop connection file, the
`icacls` SSH-key lock, native notifications + tray behavior, and the full
switch-on → <redacted> → switch-off loop. This runbook walks a
tester through all of them in ~20 minutes. Written for **Windows 11 in
Parallels on an Apple-silicon Mac** (that's ARM64 Windows — use the ARM
build); everything applies unchanged to a physical PC.

## 0. Setup

- Windows 11 VM up to date; **Claude Desktop for Windows** installed inside
  the VM and signed in.
- A GitHub account that's an approved builder (the test account
  @largekristensen-svg is ideal — it has lived the broken flow).
- Sign into the builders' hall once in the VM's browser (Edge/Chrome
  *inside* Windows, not the Mac side): `https://builders.example.com`.
- Parallels quirks that bite this test:
  - Do the whole test **inside the VM** — if the pairing browser tab opens on
    the macOS side you're testing the wrong machine's cookies.
  - Windows "Do not disturb" / Focus suppresses toast notifications — turn it
    off (Settings → System → Notifications) or step 5 can't be judged.
  - The VM clock must be right (Parallels usually syncs it) — TLS and the
    10-minute pairing TTL both care.

## 1. Download + install (tests: branded redirect, SmartScreen path)

1. In the VM browser: `https://example.com/downloads/devbox/win-arm64`
   (Parallels = ARM64 Windows; on an Intel PC use `win-x64`).
2. Expect the browser to warn about an uncommon download — keep it.
3. Run the installer. **SmartScreen will interpose** (unsigned until blocker
   [#18](https://example.com/builders#/task/18)'s Windows half): "Windows protected your PC" → **More info** → **Run
   anyway**. ✅ Record that this matches the onboarding copy's wording.
4. One-click install; the app launches itself and the panel window opens.
   ✅ The tray (bottom-right, may be behind the ^ chevron) shows the
   container icon.
   - ARM64 check: Task Manager → Details → `OTB Dev Box.exe` → the
     Architecture column should say **ARM64**, not x64-emulated (column may
     need enabling via right-click on the headers).

## 2. Pairing sign-in (tests: app-pair flow on Windows)

1. Click **Sign in through the hall**. ✅ The default browser opens
   `/builders/pair?code=XXXX-XXXX`; the code on the page matches the code in
   the panel.
2. Click **Approve — sign the app in as me**. ✅ Within ~5s the panel flips
   to signed-in (the @login shows in the header) with no further input.
3. ✅ A "Signed in" toast notification appears.
4. ✅ `%USERPROFILE%\.config\otb\gds-session.json` now exists.

## 3. SSH key + Claude Desktop connection file (tests: icacls, UAC write)

Right after sign-in the app generates/registers the key and asks to install
the Claude Desktop connection file:

1. In PowerShell:
   ```powershell
   icacls $env:USERPROFILE\.ssh\otb_builder
   ```
   ✅ Exactly one ACE — your user with full control. **No** `BUILTIN\Users`
   or `Everyone` lines (the 644-key bug the old flow shipped).
2. ```powershell
   Get-Content $env:USERPROFILE\.claude\settings.json
   ```
   ✅ Contains an `sshConfigs` entry `name` = "Example Dev Box",
   `sshHost` = `root@box-<your-login>.dev.example.com`. Since v1.0.3
   (#910) THIS per-user file is what makes the environment appear in the
   picker — written with **no elevation**; "✓ Claude Desktop is linked"
   refers to it.
3. ✅ A **UAC prompt** may also appear once — that's the OPTIONAL hardening
   layer (the system `managed-settings.json` host allowlist, written to both
   `C:\Program Files\ClaudeCode\` and `C:\ProgramData\ClaudeCode\`).
   Declining it does NOT break the link — the panel must still show
   "✓ Claude Desktop is linked".

## 4. The switch (tests: box lifecycle end-to-end)

1. Flip the switch ON. ✅ Status walks `Raising thy box…` (a first-ever box
   shows the one-time Archon-approval wait instead — the panel says so).
2. ✅ Within ~3 min: status **ON**, host/size rows fill in, a "Your dev box
   is ready" toast fires, the tray icon switches to the filled variant.
3. ✅ **Open the browser terminal** works (ttyd page, user `otb`, password
   from the panel's copy row).
4. ✅ `Get-Content $env:USERPROFILE\.ssh\known_hosts` contains fresh
   `box-<login>.dev.example.com` lines (the app replaces them each
   activation — the Desktop ssh2 fix). Since v1.0.2 (#909) the panel shows
   this live: "✓ Box identity pinned" (it retries by itself while the box's
   SSH service boots; a stuck "not pinned yet" row has a **Retry now**
   button). If it never pins, read the app log:
   `Get-Content $env:APPDATA\otb-devbox-app\devbox.log -Tail 30`.

## 5. Claude Desktop connect (the step the old flow could never reach)

1. **Restart Claude Desktop** inside the VM (it reads managed-settings at
   launch).
2. Code tab → Environment picker. ✅ **"Example Dev Box"** is listed.
3. Select it. ✅ It connects with **no host-verification error** (this is the
   known_hosts fix paying off) and lands in `/workspace`.
4. Ask Claude something trivial (`ls`) to prove the session is live.

## 6. Switch off + idle behavior

1. Flip the switch OFF. ✅ `Resting thy box…` → OFF within ~2 min; tray icon
   back to outline; "Your dev box closed" toast.
2. (Optional, 15 min) Flip ON, never connect, walk away. ✅ The box
   self-reclaims (~10–15 min idle sweep) and the panel flips itself off with
   the "closed after sitting idle" notification — the app deliberately sends
   no keep-alive.
3. Quit via tray right-click → Quit. Relaunch. ✅ Still signed in (no
   re-pairing), state re-syncs.

## Recording results

File outcomes against the verification task in the GDS. For any failure
grab: the panel state, `%TEMP%`/console output if launched from a terminal
(`& "$env:LOCALAPPDATA\Programs\OTB Dev Box\OTB Dev Box.exe"` shows logs),
the relevant PowerShell output from steps 3–4, and a screenshot. The fastest
diagnosis channel is the box-side state: `GET /api/gds/box/me` via
`node scripts/gds/api.js` from any authed checkout.

## Known-unsigned caveats (until blocker #18 lands)

SmartScreen "Run anyway" (step 1) and the unsigned-publisher UAC dialog
(step 3) are EXPECTED today. When the Windows signing decision lands (Azure
Trusted Signing vs EV cert), re-run steps 1 and 3 — both prompts should then
name the verified publisher, and the SmartScreen interstitial disappears.
