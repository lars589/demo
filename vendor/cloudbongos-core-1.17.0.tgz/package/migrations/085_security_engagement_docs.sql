-- migration 085: security_docs — Archon-only sensitive security documents
--
-- task 991 (owner decision: "in the repo but Archon-gated → Archon-only server
-- route"). The DATED security engagement reports (exploit-detail red-team
-- reports — full repro, evidence, the attacker cookbook) must NOT live as files
-- in the git clone: the repo is cloned in full onto every Metic+ dev box
-- (threat-model §6.3), so a committed exploit report is an attacker cookbook on
-- every box. Instead the report bodies live here in the prod DB and are served
-- ONLY to Archons via GET /api/gds/security/docs/:slug (requireRank('archon')).
-- The SAFE conceptual docs (threat-model.md, the README) stay in docs/security/;
-- only the dated exploit reports move to this table. See ADR 0020 (the full
-- operational threat model is intentionally kept off-repo) and threat-model §6.3.
--
-- This is a doc store: content_md is deliberately uncapped at the schema layer
-- (full reports run tens of KB) — the route layer applies an explicit large cap,
-- NOT the small LIMITS.DESCRIPTION used for task/report fields.
--
-- No seed: the director uploads each dated report after deploy via the POST
-- route (slug e.g. 2026-06-12-newbuilder-redteam), so no exploit content ever
-- touches the repo or a migration.

CREATE TABLE IF NOT EXISTS security_docs (
  id         bigserial PRIMARY KEY,
  slug       text UNIQUE NOT NULL,
  title      text NOT NULL,
  content_md text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Counter hygiene: 086_rename_disciplines.sql is already on main, so push the
-- allocator floor above it (to 88) — the next reservation must not collide with
-- 085, 086, or a not-yet-merged 087.
UPDATE migration_counter SET next_number = GREATEST(next_number, 88) WHERE id = 1;
