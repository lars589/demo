# 0006 — Singleton WorldRoom + sibling QueueRoom (instead of Colyseus default room sharding)

- **Status:** Accepted
- **Date:** 2026-05-08
- **Deciders:** Lars

## Context

V1 requires a single shared persistent world capped at 100 concurrent players, with overflow placed in a FIFO queue.

Colyseus's default behavior on `joinOrCreate` with `maxClients=100` is to **spin up a second room of the same type** when the first one fills. That gives you sharded worlds, not a queue. We want everyone in the same world; the 101st player should wait, not enter a parallel universe.

## Decision

We will run **one and only one `WorldRoom` instance**, pre-created at server boot via `matchMaker.createRoom`. The client first attempts `client.join('world')` (existing-only — never creates a new one). If that fails because the room is full, it falls back to `client.joinOrCreate('queue')`, joining a sibling **`QueueRoom`** with no client cap.

The two rooms communicate via an in-process **seat bus** (`src/seats.js`) — a small EventEmitter + counter that tracks free seats. When a player leaves the WorldRoom, the seat bus emits an event; the QueueRoom catches it and admits the head of the queue with an `admit` message. The admitted client leaves the queue and joins the world.

## Alternatives considered

- **Default Colyseus sharding (multiple WorldRoom instances).** Cheap to set up, breaks the "one shared world" premise of the project. Rejected on product grounds.
- **Increase `maxClients` arbitrarily and rate-limit at the application layer.** Pushes the queue logic into application code without the affordances of a separate room (no separate state schema, no separate message handlers). Messier.
- **External queue (Redis, RabbitMQ).** Premature for V1's single-process architecture. Adds an operational dependency for no benefit at this scale.

## Consequences

- **`seats.js` is in-process** — the seat counter is a JavaScript variable. A multi-process or multi-droplet world will need this counter to live in Redis or another shared coordinator. Logged as a current-version limitation.
- **Admit→world-join race exists but is unhandled gracefully** — if a queued player is admitted but loses the seat to a direct-joiner before their world join completes, they fall back to re-queuing. Acceptable at V1 traffic; could starve the queue head under heavy load. Logged as a current-version limitation.
- **Queue eviction on browser close is automatic** — Colyseus's `onLeave` fires on socket drop, and the seat bus releases the slot.
- **Stable, predictable shape for a future migration to a multi-process world** — when scaling becomes real, the migration path is "swap `seats.js` for a Redis-backed equivalent" rather than "rewrite the matchmaking layer."
