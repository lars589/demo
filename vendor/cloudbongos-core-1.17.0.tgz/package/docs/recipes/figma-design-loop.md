# Recipe: Figma round-trip loop

> End-to-end guide for the repo ↔ Figma sync cycle — the human escape hatch in ADR 0081.
> ADR: [ADR 0081](../adr/<redacted>.md).
> Adapter: `src/ui/adapters/figma/index.js`.
> CLI: `scripts/gds/figma-design-sync.js`.
> Skill: `.claude/skills/figma-design-sync/SKILL.md`.
>
> Not to be confused with `otb-figma-sync` (pixel-art tile review, a separate Figma file, a separate concern).

---

## When to use this

- A designer wants to make a manual edit to a UI surface directly in Figma (the "human escape hatch").
- Tokens or surfaces changed and the Figma file is stale — push before the designer opens it.
- A Figma edit is done (via Code Connect or a raw canvas change) and you want to land it as a GDS task.

---

## Prerequisites

- **Rank: Metic+** for the handoff step (task authoring / commit under a claim).
- **Claimed GDS task** — required when you `export()` and commit the generated code.
- **Figma MCP write capability** in your session (`mcp__figma__*` write tools, or `use_figma`). Read-only tools alone are not enough to push. If unavailable, stop and surface the gap rather than faking the push — see `otb-figma-sync`'s own capability check for the same pattern.

---

## 1. Build the push plan

```bash
node scripts/gds/figma-design-sync.js
```

Output (JSON on stdout):

```json
{
  "planPath": "/tmp/otb-figma-plan-XXXXX",
  "files": ["figma-plan.json", "surfaces.json", "tokens.json"],
  "surfaceIds": ["hall-ui", "status-ui"],
  "summary": "plan → /tmp/otb-figma-plan-XXXXX · 2 surface(s) · frames: colors, typography, 2 surface ref(s)"
}
```

**To scope to one surface:**
```bash
node scripts/gds/figma-design-sync.js --surface hall-ui
```

`figma-plan.json` describes the frames to create — a color-swatch frame, a typography-specimen frame, and one reference frame per surface (naming its current tool + source URL).

---

## 2. Push to Figma

Confirm the target Figma file with the builder — this skill does not hard-code a file id (unlike `otb-figma-sync`, which is locked to the pixel-art tile file). Then use the live Figma MCP write tool to realize each `figma-plan.json` frame as real nodes: rectangles for swatches, text nodes for typography specimens.

---

## 3. A designer edits in Figma

The designer opens the pushed frames (or an existing component) and makes a manual change.

---

## 4. Land the edit as a GDS task

**a. Claim a GDS task** (if not already done).

**b. Run the export step.** Figma hands back one of two shapes:

**Code Connect output (ready code):**
```js
const adapter = require('./src/ui/adapters/figma/index.js');
const result = await adapter.export({
  repoRoot: process.cwd(),
  surfaceId: 'hall-ui',
  toolOutput: { files: [{ path: 'TaskCard.js', content: '...' }] },
  taskId: '1234',
});
```

**Raw Figma MCP node snapshot (no Code Connect mapping):**
```js
const result = await adapter.export({
  repoRoot: process.cwd(),
  surfaceId: 'hall-ui',
  toolOutput: { snapshot: { nodes: [/* Figma node objects: id, name, type, absoluteBoundingBox, fills, children, characters */] } },
  taskId: '1234',
});
```

The adapter translates frames/text/solid-fill rectangles into `.js` + `.css` files, preferring a `--dt-color-*` token reference over a raw hex when the fill matches a known token. A node with an image or vector fill comes back in `result.warnings` telling you to export it as an asset under `assets/ui/<surfaceId>/` instead of code — never silently dropped, never forced into code it can't represent.

**c. Commit + ship.**

```bash
git add src/ui/hall-ui/ config/design-sources.json
git commit -m "ui(hall-ui): Figma export (task 1234)"
node scripts/gds/ship.js 1234 --notes "..." --summary "..."
```

---

## Iterating

- Re-run `node scripts/gds/figma-design-sync.js` + re-push whenever tokens change, so the designer never opens a stale file.
- The `export()` call is **idempotent** — files with identical content are skipped.
- `config/design-sources.json` tracks which surface was last synced, by which tool, and when.

---

## Code-canonical vs. Figma-canonical

Code-canonical is the default: the repo is authoritative, the Figma file is a synced view. A surface may be flagged `"figmaCanonical": true` in its `config/design-sources.json` entry (docs/design-contract.md §3.4) as an explicit exception for a design-system foundation a dedicated designer actively iterates on in Figma. All other surfaces stay code-canonical.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `figma export: repoRoot is required` | Run from the repo root. |
| `path-escape` error from `export()` | The Figma output named a path with `../` — reject it and re-check the surfaceId. |
| Warning: "not code-representable" | Expected for icons/illustrations/freeform canvas art — export it as an asset under `assets/ui/<surfaceId>/` instead of forcing it into code. |
| Warning: "no matching design token" | The designer used a color outside the token palette — either add it to `config/design-tokens.json` or accept the raw hex. |
| Figma MCP write tool not available | Session-specific — stop and surface the gap rather than faking the sync (see `otb-figma-sync`'s capability check for the same pattern). |
| Plan is stale after a token edit | Re-run `node scripts/gds/figma-design-sync.js` and re-push. |
