'use strict';

// modules/builder-settings/db.js — the builder-PREFS db slice carved out of the
// core src/bongos/db.js monolith (BV1.R80 / ADR 0093 §1). The five per-builder
// preference jsonb columns on `builders` — skill_model_prefs (037), sound_prefs
// (075), behavior_prefs (119, the wandering + render knobs share it), and
// event_sound_prefs (164) — are read/written here. OTB byte-identical: the eight
// helpers are the verbatim db.js functions; ONLY the pool require changed — it
// now reaches the shared Postgres pool through the published doorway
// (src/module-api.js) instead of `../db`, the per-domain db-slice pattern ADR
// 0091 §2 established (memory.js / economy cost.js precedent).
//
// The shapers that turn these raw blobs into effective values stay intra-module
// siblings (skill-prefs.js / sound-prefs.js / wandering-prefs.js / render-prefs.js
// / event-sound-prefs.js). The `builders` table itself stays a CORE table — this
// module owns only the prefs QUERIES, never the schema (the additive-migration
// rule: a NEW builder-settings column would still live here, namespaced).

const { pool } = require('../../src/module-api');

// Read a builder's skill_model_prefs jsonb column (migration 037 / V3.R85).
// Returns a plain object — empty {} when no preferences are set. Callers
// resolve the effective per-skill pick via skill-prefs.js (this helper is
// just the DB read).
async function getBuilderSkillPrefs(builderId) {
  const { rows } = await pool.query(
    `SELECT skill_model_prefs FROM builders WHERE id = $1`,
    [builderId]
  );
  return rows[0]?.skill_model_prefs ?? {};
}

// Replace a builder's skill_model_prefs jsonb (migration 037 / V3.R85).
// Caller is expected to have already validated the shape via
// skillPrefs.validatePatch + applied it via skillPrefs.applyPatch — this
// helper just writes the final object verbatim. Returns the saved object.
async function setBuilderSkillPrefs(builderId, prefs) {
  const payload = prefs && typeof prefs === 'object' && !Array.isArray(prefs) ? prefs : {};
  const { rows } = await pool.query(
    `UPDATE builders
        SET skill_model_prefs = $2::jsonb
      WHERE id = $1
      RETURNING skill_model_prefs`,
    [builderId, JSON.stringify(payload)]
  );
  return rows[0]?.skill_model_prefs ?? {};
}

// Read a builder's sound_prefs jsonb (migration 075 / V3.R91, #786). Returns a
// plain object — empty {} when no preferences are set. Callers resolve the
// effective per-sound on/off via sound-prefs.js (this helper is just the read).
async function getBuilderSoundPrefs(builderId) {
  const { rows } = await pool.query(
    `SELECT sound_prefs FROM builders WHERE id = $1`,
    [builderId]
  );
  return rows[0]?.sound_prefs ?? {};
}

// Replace a builder's sound_prefs jsonb (migration 075 / V3.R91). Caller is
// expected to have validated the shape via soundPrefs.validatePatch + applied
// it via soundPrefs.applyPatch — this helper just writes the final object
// verbatim. Returns the saved object.
async function setBuilderSoundPrefs(builderId, prefs) {
  const payload = prefs && typeof prefs === 'object' && !Array.isArray(prefs) ? prefs : {};
  const { rows } = await pool.query(
    `UPDATE builders
        SET sound_prefs = $2::jsonb
      WHERE id = $1
      RETURNING sound_prefs`,
    [builderId, JSON.stringify(payload)]
  );
  return rows[0]?.sound_prefs ?? {};
}

// Read a builder's behavior_prefs jsonb (migration 119, task 1268). Returns a
// plain object — empty {} when no preferences are set. Callers resolve the
// effective level via wandering-prefs.js (this helper is just the DB read).
async function getBuilderBehaviorPrefs(builderId) {
  const { rows } = await pool.query(
    `SELECT behavior_prefs FROM builders WHERE id = $1`,
    [builderId]
  );
  return rows[0]?.behavior_prefs ?? {};
}

// Replace a builder's behavior_prefs jsonb (migration 119). Caller is expected
// to have validated the shape via wanderingPrefs.validatePatch + applied it via
// wanderingPrefs.applyPatch — this helper just writes the final object verbatim.
// Returns the saved object.
async function setBuilderBehaviorPrefs(builderId, prefs) {
  const payload = prefs && typeof prefs === 'object' && !Array.isArray(prefs) ? prefs : {};
  const { rows } = await pool.query(
    `UPDATE builders
        SET behavior_prefs = $2::jsonb
      WHERE id = $1
      RETURNING behavior_prefs`,
    [builderId, JSON.stringify(payload)]
  );
  return rows[0]?.behavior_prefs ?? {};
}

// Read a builder's event_sound_prefs jsonb (migration 164, task 582). Returns a
// plain object — empty {} when no preferences are set. Callers resolve the
// effective per-event variant via event-sound-prefs.js.
async function getBuilderEventSoundPrefs(builderId) {
  const { rows } = await pool.query(
    `SELECT event_sound_prefs FROM builders WHERE id = $1`,
    [builderId]
  );
  return rows[0]?.event_sound_prefs ?? {};
}

// Replace a builder's event_sound_prefs jsonb (migration 164). Caller is
// expected to have validated + applied the patch — this helper just writes
// the final object verbatim. Returns the saved object.
async function setBuilderEventSoundPrefs(builderId, prefs) {
  const payload = prefs && typeof prefs === 'object' && !Array.isArray(prefs) ? prefs : {};
  const { rows } = await pool.query(
    `UPDATE builders
        SET event_sound_prefs = $2::jsonb
      WHERE id = $1
      RETURNING event_sound_prefs`,
    [builderId, JSON.stringify(payload)]
  );
  return rows[0]?.event_sound_prefs ?? {};
}

// Read a builder's display_name (the free label shown next to their work in the
// hall — header, leaderboard, work feed). Stable identity stays github_login/id;
// this is just the rendered name. Returns the string, or null if no such row.
// (task 1669 — the self-service display-name editor.)
async function getBuilderDisplayName(builderId) {
  const { rows } = await pool.query(
    `SELECT display_name FROM builders WHERE id = $1`,
    [builderId]
  );
  return rows[0]?.display_name ?? null;
}

// Set a builder's display_name (task 1669). Caller is expected to have already
// validated + trimmed the value via display-name.js's validate() — this helper
// writes it verbatim and returns the saved string. Own-scoped: the route only
// ever passes the AUTHENTICATED builder's id. display_name is `text NOT NULL`
// (migration 003), so a validated non-empty string is always a legal write.
async function setBuilderDisplayName(builderId, displayName) {
  const { rows } = await pool.query(
    `UPDATE builders
        SET display_name = $2
      WHERE id = $1
      RETURNING display_name`,
    [builderId, displayName]
  );
  return rows[0]?.display_name ?? null;
}

module.exports = {
  getBuilderSkillPrefs,
  setBuilderSkillPrefs,
  getBuilderSoundPrefs,
  setBuilderSoundPrefs,
  getBuilderBehaviorPrefs,
  setBuilderBehaviorPrefs,
  getBuilderEventSoundPrefs,
  setBuilderEventSoundPrefs,
  getBuilderDisplayName,
  setBuilderDisplayName,
};
