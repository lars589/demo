-- 160_goal_tier.sql — the Goal tier (ADR 0086 §2, BV1.R56 / task 1510).
--
-- Phase 2 of the goal-scoped work hierarchy: the one genuinely-new tier, sitting
-- between `versions` and `done_when_criteria`. A goal is a SHARED, joinable,
-- module-scoped workspace — membership (not a single assignee) is what later
-- grants bounded task authoring within the goal's `scope_modules` wall (R57/R60).
--
-- This migration is PURELY ADDITIVE and changes no behaviour: it creates the two
-- new tables, adds a nullable `goal_id` to `done_when_criteria` and `tasks`, and
-- backfills every existing criterion under a per-version default "<version> —
-- general" goal so the not-yet-built `/status` rollup (R58) has a goal to roll up
-- through. No route references a goal yet, so OTB behaves identically.
--
-- created_by is NULLABLE and the backfilled default goals leave it NULL =
-- system-attributed (Archon-owned in practice); a migration must never hard-code
-- a specific builder id (fresh-DB replay safety — see learning 1238). The backfill
-- is data-safe on a fresh DB too: INSERT..SELECT FROM versions yields zero rows if
-- no versions are seeded yet, and the UPDATE then touches nothing.
--
-- Idempotent: tables/columns use IF NOT EXISTS; the default-goal insert is guarded
-- by NOT EXISTS on (version_id, title); the criterion link only fills NULLs.

BEGIN;

-- 1. goals — the new tier. scope_modules is the wall (module keys from
--    module-scope-map.js, R54); empty for the Archon-owned default goals.
CREATE TABLE IF NOT EXISTS goals (
  id                    bigserial PRIMARY KEY,
  version_id            text NOT NULL REFERENCES versions(id),
  title                 text NOT NULL,
  description           text,
  scope_modules         text[] NOT NULL DEFAULT '{}',
  status                text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'achieved', 'archived')),
  created_by            bigint REFERENCES builders(id),   -- NULL = system-attributed
  succeeded_by_goal_id  bigint REFERENCES goals(id),      -- rescope carry-forward
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_goals_version ON goals (version_id);

-- 2. goal_members — many builders <-> one goal; membership grants the (later)
--    bounded authoring authority. lead|member roles; one row per (goal, builder).
CREATE TABLE IF NOT EXISTS goal_members (
  goal_id     bigint NOT NULL REFERENCES goals(id) ON DELETE CASCADE,
  builder_id  bigint NOT NULL REFERENCES builders(id) ON DELETE CASCADE,
  role        text NOT NULL DEFAULT 'member' CHECK (role IN ('lead', 'member')),
  joined_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (goal_id, builder_id)
);

CREATE INDEX IF NOT EXISTS idx_goal_members_builder ON goal_members (builder_id);

-- 3. done_when_criteria re-parent under goals (nullable; backfilled below).
ALTER TABLE done_when_criteria
  ADD COLUMN IF NOT EXISTS goal_id bigint REFERENCES goals(id);

-- 4. tasks gain goal_id (nullable — a task may exist with no goal, as today).
ALTER TABLE tasks
  ADD COLUMN IF NOT EXISTS goal_id bigint REFERENCES goals(id);

-- 5. Backfill: one default "<version> — general" goal per version, then link
--    every still-unlinked criterion of that version to it. Idempotent.
INSERT INTO goals (version_id, title, description, status, scope_modules)
SELECT v.id,
       v.id || ' — general',
       'Default catch-all goal for ' || v.id || ', auto-created by migration 160 (ADR 0086 §2). '
         || 'Holds the criteria that predate the goal tier; Archon-owned, members empty.',
       'open',
       '{}'
  FROM versions v
 WHERE NOT EXISTS (
   SELECT 1 FROM goals g
    WHERE g.version_id = v.id
      AND g.title = v.id || ' — general'
 );

UPDATE done_when_criteria c
   SET goal_id = g.id
  FROM goals g
 WHERE g.version_id = c.version_id
   AND g.title = c.version_id || ' — general'
   AND c.goal_id IS NULL;

INSERT INTO schema_migrations (version) VALUES ('160_goal_tier')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
