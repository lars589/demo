# Code of Conduct

## Our pledge

We — contributors, maintainers, and the owners of Cloud Bongos instances — pledge to make participation in the project and its community a harassment-free experience for everyone, regardless of age, body size, visible or invisible disability, ethnicity, sex characteristics, gender identity and expression, level of experience, education, socioeconomic status, nationality, personal appearance, race, religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive, and healthy community.

> Cloud Bongos is an AI-first platform: much of the day-to-day building is done by AI agents. This Code of Conduct governs the **human** participants — owners, reviewers, and contributors — and the standards they hold themselves and the agents they direct to.

## Our standards

Examples of behavior that contributes to a positive environment:

- Demonstrating empathy and kindness toward other people.
- Being respectful of differing opinions, viewpoints, and experiences.
- Giving and gracefully accepting constructive feedback.
- Accepting responsibility, apologizing to those affected by our mistakes, and learning from the experience.
- Focusing on what is best for the community and the project.

Examples of unacceptable behavior:

- The use of sexualized language or imagery, and sexual attention or advances of any kind.
- Trolling, insulting or derogatory comments, and personal or political attacks.
- Public or private harassment.
- Publishing others' private information (such as a physical or email address) without their explicit permission.
- Directing AI agents under your control to harass, dox, deceive, or otherwise harm others.
- Other conduct which could reasonably be considered inappropriate in a professional setting.

## Enforcement responsibilities

Instance owners (Archon rank) are responsible for clarifying and enforcing the standards of acceptable behavior on their instance and will take appropriate and fair corrective action in response to any behavior they deem inappropriate, threatening, offensive, or harmful.

Owners have the right and responsibility to remove, edit, or reject contributions, comments, commits, code, and other artifacts that are not aligned with this Code of Conduct, and will communicate reasons for moderation decisions when appropriate.

## Scope

This Code of Conduct applies within all project and community spaces, and also applies when an individual is officially representing the project or community in public spaces.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to the owners of the relevant Cloud Bongos instance. All complaints will be reviewed and investigated promptly and fairly. Owners are obligated to respect the privacy and security of the reporter of any incident.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org), version 2.1, available at <https://www.contributor-covenant.org/version/2/1/code_of_conduct.html>, with additions specific to an AI-first project.
