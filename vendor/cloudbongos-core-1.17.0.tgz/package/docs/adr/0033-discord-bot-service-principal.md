# ADR 0033 — Discord bot as a service principal (account-linking, both-mode upvoting, role-sync, inbound retirement)

**Date:** 2026-06-04
**Context:** GDS-V3, task [#619](https://example.com/builders#/task/619). Phase 3 of the Discord integration begun in [ADR 0032](0032-discord-mirror-of-gds.md) ([#607](https://example.com/builders#/task/607)). Where Phase 2 was a one-way webhook (no identity, no inbound), Phase 3 adds a **bot** — a persistent connection that reads reactions/messages and assigns roles — which means Discord *actions* now trigger GDS *writes*. That lands on the trust boundary. Companion to [ADR 0016](<redacted>.md) (the boundary), [ADR 0026](<redacted>.md) (the service-principal + identity-gate pattern this reuses), [ADR 0018](<redacted>.md) (the ranks role-sync mirrors), [ADR 0022](0022-secrets-policy.md) (bot token + OAuth secret), and [ADR 0008](0008-google-chat-oauth-user-auth.md) (the inbound path this retires).
**Status:** Accepted (design). Implementation seeded as separate sub-tasks (listed at the end); nothing here is built yet. Foundation build is blocked on creating the Discord bot application.
**Track:** `internal` (dev-system / team communication).

> A decision record, not an implementation. The point is to lock the shape — especially the authorization model — so the build can proceed in reviewable pieces without relitigating the trust question each time.

## Problem

ADR 0032 established that Discord is a one-way mirror of the GDS. Phase 2 honored that trivially: a webhook only ever posts *out*. Phase 3's features all push the other way:

- **Upvoting** — a reaction in Discord should feed the vote/karma system.
- **Role-sync** — builder ranks should appear as Discord role badges.
- **Inbound** — team messages in Discord should become ideas, retiring the Google Chat inbound path.

The first and third make a **Discord event cause a GDS write**. Naively, a bot with a database connection could just write karma or votes. That would re-open exactly the hole [ADR 0016](<redacted>.md) closes: an actor *outside* the trust boundary deciding authoritative state. We need a design where the bot can act **without ever becoming an authority**.

## Decision

### 1. The bot is a service principal — trusted for identity, never for authorization

The bot authenticates to the GDS as a dedicated **service principal** (`system_role = 'discord_bot'`), gated by a `requireDiscordBot` middleware that checks that exact identity — **not** a rank. This is the same shape the BFG cross-builder write path uses ([ADR 0026 §6C](<redacted>.md)): a stolen or rank-escalated *human* token has `system_role = NULL` and is rejected; only the bot principal's row passes.

The principal is trusted for **one** thing: asserting "this Discord user, who reacted/posted, is linked builder X." It is **never** trusted to decide what X may do. Every write the bot triggers re-derives authorization from **X's live `builders.rank`** server-side, through the same guards the web/CLI paths use. The bot cannot escalate; at most it can mis-report *which linked user* acted, and that blast radius is bounded (below).

Every bot-triggered write is recorded in `audit_log`, tagged with the originating surface (`discord_bot`) and the asserted Discord user id, so bot-originated peer-votes are distinguishable from direct web/CLI votes during forensic review. (The `audit_log` cited as a control below must carry this surface field — F1 adds it.)

### 2. Account-linking is UI-first and self-asserted

A Discord user becomes "trusted as builder X" only when **X personally links it**: signed into the `/builders` hall (already GitHub-authed), X clicks **Link Discord**, approves a standard Discord OAuth2 sign-in (`identify` scope), and the server stores the `(builder_id ↔ discord_user_id)` pair in a new `discord_links` table. **CSRF protection is mandatory:** the authorize request carries a one-time, unguessable **`state`** parameter bound to X's session (the same protection the existing GitHub web flow uses — `buildAuthorizeUrl(state, …)` in `auth.js`), and `/discord/callback` **rejects any request whose `state` doesn't match**. Without it, an attacker could trick a logged-in builder's browser into a forged callback carrying an attacker-controlled `code`, silently linking the *attacker's* Discord account to the *victim's* builder row — after which every attacker reaction would cast peer-votes as the victim. The `state` check closes that vector; it is a hard requirement of F2, not an option. An **Unlink** affordance is always present. No tokens, no terminal — per the project's <redacted> rule. Because the mapping comes from the *user's own OAuth*, not from the bot, the bot is not trusted to *invent* mappings — only to report which (already-linked) user fired an event.

### 3. Upvoting — both modes, cleanly separated

A 👍 on a shipped item in **#ship-feed** flows: bot → `requireDiscordBot` endpoint with `{discord_user_id, target_task_id}`. The server resolves the link and branches:

- **Linked builder is Metic+ and not the author** → cast a **real peer-vote** through the *existing* `peer_votes` path, re-enforcing every guard server-side: Metic+ only, anti-self-vote, the 7-day karma lag, the tallied-freeze. (Identical authorization to `POST /tasks/:id/vote`.)
- **Anyone else** (player, Xenos, unlinked, or self-vote) → record a **cosmetic applause** in a separate `discord_applause` store that **never touches `karma_log`**.

The two stores are disjoint by construction: applause is engagement flavor; karma is earned only through the rank-gated path. A Xenos's enthusiasm shows as applause and changes no reputation.

### 4. Role-sync is one-way (GDS → Discord)

On rank change, on link, and on a periodic reconcile, the bot sets the member's Discord role (Xenos / Metic / Archon) from `builders.rank`. This is read-only against the GDS and write-only against Discord — it can never feed authority back in. It makes the role badges *honest* (the point of ADR 0032 §2). Requires the bot to hold **Manage Roles** and to sit above the managed roles in Discord's hierarchy.

### 5. Inbound retirement

The bot listens on a designated channel, files messages into `idea_inbox` via the existing file-idea path (attributed to the linked builder when known), and then the Google Chat **inbound** machinery is retired: the `SessionStart` `poll.js` hook, the `chat-intake-daily` routine, and the `chat-inbox.md` flow. (`scripts/chat/` can then be deleted entirely — outbound already moved in [#607](https://example.com/builders#/task/607).) Requires the **Message Content** intent.

### Hosting & secrets

The bot runs **in-process** in the existing Node server as a module, behind a `DISCORD_BOT_ENABLED` kill-switch (default **off**, fail-closed — like `BFG_WRITE_ENABLED`), with reconnect handling. Adds the `discord.js` dependency. Cost is **~$0** (it rides the droplet we already pay for; Discord is free).

**Secret-deployment note (differs from Phase 2):** the Phase 2 webhook ran on the operator's laptop during `/builder-ship`, so its secret stayed local. The bot runs **on the droplet** (a persistent gateway connection), so the **bot token + Discord OAuth client secret must live on the droplet** (systemd `EnvironmentFile`), per [ADR 0022](0022-secrets-policy.md) — not only in `~/.config/otb/`. This is the first Discord secret the droplet needs.

## Consequences

- The trust boundary holds: the bot maps identity; the GDS still decides. The one invariant to defend in review is **"every bot-triggered write re-checks the linked builder's live rank."**
- Discord role badges become continuously honest (auto-synced from the DB).
- Google Chat is fully retired once inbound lands; `scripts/chat/` is removed then.
- New surface area to own: a `discord.js` dependency, an always-on connection (reconnect/rate-limit handling), and a droplet-side secret.
- A compromised bot could forge "user X reacted," yielding at most a spurious Metic+ peer-vote — bounded by the anti-self-vote guard, the visible 7-day karma lag, and the `audit_log`, and revocable by the `DISCORD_BOT_ENABLED` kill-switch.

## Alternatives considered

- **Bot writes karma/votes directly (its own DB access).** Rejected — it makes the bot an authority and re-opens [ADR 0016](<redacted>.md). The principal + per-write rank re-check is the whole point.
- **Trust Discord roles for authorization.** Rejected outright (ADR 0016 / 0032 §2): roles are cosmetic reflections, never keys.
- **Map Discord→builder by matching usernames (no OAuth link).** Rejected — unverified and spoofable; identity must be self-asserted by the builder.
- **A separate bot process / service.** Considered; in-process behind a kill-switch is simpler for one droplet. Revisit if the connection destabilizes the web process.
- **Applause feeds karma (single mode).** Rejected — it would let unranked enthusiasm mint reputation. Keeping applause cosmetic and disjoint from `karma_log` is the load-bearing separation of decision [#3](https://example.com/builders#/task/3).

## Implementation sub-tasks (seeded separately)

1. **F1 — Foundation** (no live bot needed): a new migration (next free number at build time) adding `discord_links`, `discord_applause`, the `discord_bot` service principal, and the `audit_log` originating-surface field + `requireDiscordBot` gate + db helpers + unit tests.
2. **F2 — Account-linking web flow** (needs OAuth creds): Discord OAuth start/callback routes + Link/Unlink UI on the hall.
3. **F3 — Bot process** (needs bot token): `discord.js` client, `DISCORD_BOT_ENABLED`-gated, droplet EnvironmentFile, connection + reconnect.
4. **F4 — Upvoting** (needs F1–F3): reaction handler → bot-principal endpoint (real peer-vote if Metic+, else applause).
5. **F5 — Role-sync** (needs F1–F3 + Manage Roles): rank → Discord role on change/link/reconcile.
6. **F6 — Inbound** (needs F3): message handler → `idea_inbox`; retire Google Chat inbound + delete `scripts/chat/`.

**Prerequisite (human, browser):** create the Discord bot application — bot token, OAuth2 client id/secret, the Server Members + Message Content + Guild Message Reactions intents, and the Manage Roles permission. Gates F2/F3 onward.
