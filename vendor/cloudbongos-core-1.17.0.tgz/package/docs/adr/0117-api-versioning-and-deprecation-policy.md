# ADR 0117 — API versioning + deprecation policy

**Date:** 2026-07-04
**Status:** Accepted (policy; R05 of goal 36).
**Context:** [task 1992](https://builders.example.com#/task/1992) (BONGOS-V1, goal 36 "Robust, versioned, easy-to-call public API", criterion `api-versioning`). This is the **policy**; the mount + aliasing that implements it is R06 ([task 1993](https://builders.example.com#/task/1993)). Builds on the API-prefix chokepoint ([`src/gds/api-prefix.js`](../../src/gds/api-prefix.js), task 1918/1919), the self-describing OpenAPI + hosted `/docs` ([ADR 0109](<redacted>.md)), and the docs-discovery contract ([ADR 0114](<redacted>.md)).

## Problem

The API (212 endpoints) is served at `/api/bongos` (canonical) with `/api/gds` as a permanent silent alias. Neither is a **version** — they are *prefix* names. There is no version marker in the path, no written definition of what a breaking change is, and no deprecation policy. So today any change — a removed field, a tightened validation, a changed status code — can silently break a self-hoster's integration, a shipped Dev Box binary, or the status dashboard, with no signalling and no migration window. Two things also get conflated: the **software version** (OpenAPI `info.version` = the core package semver, which moves every release) and the **API contract version** (which should move only on a breaking change). A caller must be able to pin to a contract that won't shift under it.

## Decision

**1. An explicit version segment in the path: `/api/bongos/v1/…`.** The version is a path marker (`v1`, `v2`, …) immediately after the prefix — coarse-grained (a whole-surface major), the shape almost every caller finds easiest to pin and reason about. It is the **contract** version, distinct from the package semver.

**2. Today's unversioned paths are PERMANENT aliases pinned to v1.** `/api/bongos/<x>` and `/api/gds/<x>` keep working forever and resolve to **v1** semantics. This extends the existing permanent-`/api/gds`-alias decision (`api-prefix.js`): shipped Dev Box desktop binaries, live boxes, and the separately-hosted status-dashboard mirror all call unversioned `/api/gds/…` and **cannot be force-updated**, so their surface can never be removed.

The load-bearing safety rule: **an unversioned path never silently jumps major versions.** When v2 ships, it mounts at `/api/bongos/v2/…`; the unversioned alias **stays pinned to v1**. An old caller keeps getting v1 behaviour; only a caller that explicitly asks for `/v2/` gets the new contract. Breaking changes therefore reach only opted-in callers.

**3. What counts as a breaking change** (bumps the major → new `/vN`):

- Removing or renaming an endpoint, a request/response field, or an error `code`.
- Changing a field's type, or an endpoint's success status code.
- Adding a newly-*required* request field, or tightening validation to reject input that was previously accepted.
- Narrowing auth/rank so a call that used to succeed now 403s.
- Changing a default that alters a response's shape/size (e.g. a pagination default).

**Non-breaking** (ships within the current version, no bump):

- Adding an endpoint, an *optional* request field, or a new response field.
- Adding a new error `code` **within an existing category** (the ADR 0116 envelope means a caller already handles unknown codes by category, so this is safe).
- Relaxing validation; adding an optional query param.

**4. Deprecation window.** A version, once superseded, lives **≥ 180 days** past its successor's GA before it may be removed. While deprecated it returns RFC 8594 `Deprecation: true` + `Sunset: <date>` response headers and is marked deprecated in the OpenAPI spec + `/docs`. The **unversioned alias is exempt** — it is permanent (rule 2), never sunset. Only explicitly-versioned prefixes (`/v1`, `/v2`, …) are subject to the window. Removal of a sunset version is itself a tracked, announced task (build-broadcast to the team channel), never silent.

**5. The version is discoverable.** The OpenAPI spec grows a `servers` entry for `…/v1` and an `x-api-version: "v1"` marker; `info.version` continues to track the **package** semver (unchanged — it is the software build, not the contract). The machine-discovery index (`GET <publicOrigin>/api/bongos`, ADR 0114) advertises the current + supported contract versions. `/docs` states the version. `api-prefix.js` grows the version constant so the whole surface reads it from one chokepoint (the R06 implementation).

## Consequences

- A self-hoster or external program pins `…/v1/…` and is guaranteed a stable contract for ≥ 180 days past any successor; unversioned/legacy callers never break at all.
- Day one is a no-op for every existing consumer: R06 mounts the current surface at `/v1` and aliases the unversioned paths into it, so nothing changes behaviourally — the version just becomes *nameable*.
- Shipping a breaking change is now a deliberate, expensive, announced act (a new `/vN` + a deprecation clock), not an accident — which is the whole point.
- The contract/package split means routine releases (bug fixes, new endpoints) never churn the version a caller pinned.

## Rejected

- **Header-based versioning (`Accept: application/vnd.bongos.v1+json`).** Invisible in a URL, harder to `curl`, easy to forget → callers silently get the default. A path segment is self-evident and cache-friendly. (The AI-agent + self-hoster audience copies URLs, not header incantations.)
- **Per-endpoint / semver-in-path versioning (`/v1.2.3/`).** Too fine-grained; callers would chase patch versions. Whole-surface majors match how the contract actually breaks.
- **No version, "just don't break it."** The status quo — which is exactly the problem: no signal, no window, no way to pin.
- **Sunsetting the unversioned alias too.** Would break un-updatable shipped binaries; the permanent-alias precedent (`api-prefix.js`) is deliberate and kept.
- **Reusing `info.version` (package semver) as the API version.** Conflates software build with contract; every release would look like a version change.
