-- V3.R25 (#245) — builder-on-builder peer votes on confirmed/shipped work.
--
-- Criterion C2 (karma signal sourcing): karma (migration 040) needs a
-- continuous peer input. Every confirmed/shipped task can be voted on by other
-- Metic+ builders: +1 = good work, -1 = concerns. A weekly tally folds the net
-- votes into karma_log rows for the SHIPPING builder.
--
-- Anti-retaliation by design — two guards:
--   1. Anti-self-vote: enforced in the route (a CHECK can't see tasks.shipped_by
--      from here). 403 if voter == task.shipped_by.
--   2. 7-day karma lag: the weekly tally only folds votes that are ≥ 7 days old
--      (recorded_at <= now() - 7d). A vote cast today can't move karma until
--      next week, so retaliation cycles have no immediate payoff. tallied_at
--      marks a vote as already folded so it's never double-counted; once a vote
--      is tallied it's frozen (the route refuses to change it).
--
-- Feeds R26 (#246) which surfaces karma on the profile + leaderboard.

CREATE TABLE IF NOT EXISTS peer_votes (
  id                bigserial PRIMARY KEY,
  voter_builder_id  bigint NOT NULL REFERENCES builders(id),
  target_task_id    bigint NOT NULL REFERENCES tasks(id),
  vote              integer NOT NULL CHECK (vote IN (-1, 1)),  -- 0 = cleared = row deleted
  recorded_at       timestamptz NOT NULL DEFAULT now(),
  tallied_at        timestamptz,  -- NULL = not yet folded into karma; set by the weekly tally
  UNIQUE (voter_builder_id, target_task_id)
);

-- Net-votes-per-task read (feed + single task display).
CREATE INDEX IF NOT EXISTS idx_peer_votes_target ON peer_votes (target_task_id);
-- Weekly tally hot path: matured, not-yet-folded votes.
CREATE INDEX IF NOT EXISTS idx_peer_votes_untallied ON peer_votes (recorded_at) WHERE tallied_at IS NULL;

-- Supports the acclaim feed (GET /tasks/peer-votes/feed): a partial, functional
-- index whose predicate matches the feed's WHERE (confirmed/shipped, attributed)
-- and whose ordering matches its sort — COALESCE(shipped_at, updated_at) DESC —
-- so the feed reads the top rows from the index instead of scanning + sorting
-- every historical task. Without it, cost grows linearly with project history.
CREATE INDEX IF NOT EXISTS idx_tasks_votable_recent
  ON tasks ((COALESCE(shipped_at, updated_at)) DESC)
  WHERE status IN ('confirmed', 'shipped') AND shipped_by IS NOT NULL;
