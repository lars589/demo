// public-builders/harbor.js — the Harbor (/builders/harbor).
//
// Archon-only dev-box management view (idea 257 / task 1163). Every builder's
// dev box is rendered as a card on the dock; an Archon can close any box and
// block a builder from opening new ones.
//
// Like the Watch page, this reads /api/bongos/me to learn the viewer's rank and
// shows an Archons-only notice otherwise — DEFENCE IN DEPTH only. The data + mutation
// endpoints (/boxes, /boxes/:id/close, /boxes/:id/block) are ALSO archon-gated
// server-side (ADR 0016), and the page itself is gated by server.js
// requireArchonPage. On a 401 it redirects into the web sign-in flow.

(() => {
  'use strict';

  const API = '/api/bongos';
  // Generated typed client (task 1996 / R09), served as window.BongosClient by
  // /lib/bongos-client.js. baseUrl:'' passes the full `${API}${path}` URLs below
  // through unchanged; result-mode ({ status, ok, data }) preserves control flow 1:1.
  const api = window.BongosClient.createClient({ baseUrl: '', credentials: 'same-origin', throwOnError: false });
  const { escapeHtml, fmtInt } = window.OTB;
  const rankLabel = (rank) => window.OTB.rankLabel(rank, { empty: '' });
  const toast = (msg) => window.OTB.toast(msg);

  // States that hold a droplet/snapshot worth reclaiming — mirrors the server's
  // boxes.canTransition('deprovision', …). A box in one of these can be
  // closed; the rest (none/destroyed/provisioning) have nothing to deprovision.
  const CLOSEABLE = new Set(['active', 'parking', 'parked', 'waking', 'error']);

  // ---- fetch helpers (mirror watch.js) -------------------------------------

  async function fetchJson(path) {
    const res = await api.request('GET', `${API}${path}`);
    if (res.status === 401) { window.location.assign(`${API}/auth/web/start`); throw { kind: '401' }; }
    if (res.status === 403) { throw { kind: '403' }; }
    if (!res.ok) throw new Error(`${path} → ${res.status}`);
    return res.data;
  }

  async function sendJson(method, path, body) {
    const res = await api.request(method, `${API}${path}`, { body: body || {} });
    if (res.status === 401) { window.location.assign(`${API}/auth/web/start`); throw { kind: '401' }; }
    const data = res.data || {};
    if (!res.ok) throw new Error(data.message || data.error || `${path} → ${res.status}`);
    return data;
  }

  // ---- formatters ----------------------------------------------------------

  // ISO → "3h 12m" / "2d 4h" / "8m" elapsed-since. "—" for empty/bad input.
  function fmtAgo(iso) {
    if (!iso) return '—';
    const t = new Date(iso).getTime();
    if (!Number.isFinite(t)) return '—';
    let s = Math.max(0, Math.round((Date.now() - t) / 1000));
    const d = Math.floor(s / 86400); s -= d * 86400;
    const h = Math.floor(s / 3600); s -= h * 3600;
    const m = Math.floor(s / 60);
    if (d > 0) return `${d}d ${h}h`;
    if (h > 0) return `${h}h ${m}m`;
    return `${m}m`;
  }

  function fmtUsd(n) {
    const v = Number(n);
    if (!Number.isFinite(v)) return '$0.00';
    return `$${v.toFixed(2)}`;
  }

  // Map a box state (+ block flag) to its card styling + pill label.
  function stateStyle(state, blocked) {
    if (blocked) return { mod: 'blocked', pill: 'blocked', pillMod: 'blocked' };
    switch (state) {
      case 'active': return { mod: 'active', pill: 'active', pillMod: 'active' };
      case 'parked': return { mod: 'parked', pill: 'parked', pillMod: '' };
      case 'provisioning':
      case 'waking':
      case 'parking': return { mod: 'pending', pill: state, pillMod: 'pending' };
      case 'error': return { mod: 'error', pill: 'error', pillMod: '' };
      default: return { mod: 'gone', pill: state || 'none', pillMod: '' };
    }
  }

  // ---- modal ---------------------------------------------------------------

  function closeModal() {
    const root = document.getElementById('harbor-modal-root');
    if (root) root.innerHTML = '';
  }

  // Build a modal. `fields` is optional extra HTML (inputs). onConfirm receives
  // the modal element so the caller can read its inputs.
  function openModal({ title, bodyHtml, confirmLabel, danger, onConfirm }) {
    const root = document.getElementById('harbor-modal-root');
    root.innerHTML = '';
    const bg = document.createElement('div');
    bg.className = 'harbor-modal-bg';
    bg.innerHTML =
      `<div class="harbor-modal" role="dialog" aria-modal="true">
        <h2>${escapeHtml(title)}</h2>
        ${bodyHtml}
        <div class="harbor-modal__actions">
          <button class="harbor-btn" data-act="cancel">Cancel</button>
          <button class="harbor-btn ${danger ? 'harbor-btn--danger' : ''}" data-act="confirm">${escapeHtml(confirmLabel)}</button>
        </div>
      </div>`;
    bg.addEventListener('click', (e) => { if (e.target === bg) closeModal(); });
    bg.querySelector('[data-act=cancel]').addEventListener('click', closeModal);
    bg.querySelector('[data-act=confirm]').addEventListener('click', () => onConfirm(bg));
    root.appendChild(bg);
  }

  // ---- actions -------------------------------------------------------------

  function confirmClose(box) {
    const who = box.builder.github_login || `#${box.builder.id}`;
    const verb = box.state === 'parked' ? 'destroy the snapshot of' : 'close';
    openModal({
      title: `Close ${who}'s box?`,
      bodyHtml: `<p>This will ${verb} <strong>${escapeHtml(who)}</strong>'s dev box (state: ${escapeHtml(box.state)}). Any uncommitted work on that box is lost. The box is destroyed; the builder can open a fresh one unless they are also blocked.</p>
         <p>A fresh box has a <strong>new SSH identity</strong>. If their Claude Desktop later says &ldquo;Host denied&rdquo; or asks for a password, tell them to fully restart Desktop (it re-pins) or press Repair — not to keep rebuilding, which only rotates the identity again.</p>`,
      confirmLabel: 'Close box',
      danger: true,
      onConfirm: async () => {
        try {
          const r = await sendJson('POST', `/boxes/${box.builder.id}/close`, {});
          toast(r.message || 'Close queued.');
          closeModal();
          load();
        } catch (err) {
          if (err && err.kind === '401') return;
          toast(`Could not close: ${err.message || err}`);
        }
      },
    });
  }

  function confirmBlock(box) {
    const who = box.builder.github_login || `#${box.builder.id}`;
    const hasLiveBox = CLOSEABLE.has(box.state);
    openModal({
      title: `Bar ${who} from opening boxes?`,
      bodyHtml:
        `<p>${escapeHtml(who)} will not be able to open or wake a dev box until you unblock them. A box they already have running is left alone unless you also close it below.</p>
         <label for="harbor-block-reason">Reason (shown to the builder)</label>
         <textarea id="harbor-block-reason" rows="2" placeholder="e.g. runaway cost — paused pending review"></textarea>
         ${hasLiveBox ? `<label class="harbor-modal__check"><input type="checkbox" id="harbor-block-close"> Also close the box they have running now (state: ${escapeHtml(box.state)})</label>` : ''}`,
      confirmLabel: 'Block builder',
      danger: true,
      onConfirm: async (modal) => {
        const reason = (modal.querySelector('#harbor-block-reason') || {}).value || '';
        const closeEl = modal.querySelector('#harbor-block-close');
        try {
          const r = await sendJson('PATCH', `/boxes/${box.builder.id}/block`, {
            blocked: true,
            reason: reason.trim() || undefined,
            close_current: !!(closeEl && closeEl.checked),
          });
          toast(r.close_queued ? 'Builder blocked — running box will be closed.' : 'Builder blocked.');
          closeModal();
          load();
        } catch (err) {
          if (err && err.kind === '401') return;
          toast(`Could not block: ${err.message || err}`);
        }
      },
    });
  }

  function confirmUnblock(box) {
    const who = box.builder.github_login || `#${box.builder.id}`;
    openModal({
      title: `Lift the block on ${who}?`,
      bodyHtml: `<p>${escapeHtml(who)} will be able to open dev boxes again.</p>`,
      confirmLabel: 'Unblock',
      danger: false,
      onConfirm: async () => {
        try {
          await sendJson('PATCH', `/boxes/${box.builder.id}/block`, { blocked: false });
          toast('Block lifted.');
          closeModal();
          load();
        } catch (err) {
          if (err && err.kind === '401') return;
          toast(`Could not unblock: ${err.message || err}`);
        }
      },
    });
  }

  // ---- render --------------------------------------------------------------

  function renderContainer(box, costByBuilder) {
    const blocked = box.blocked && box.blocked.is;
    const st = stateStyle(box.state, blocked);
    const who = escapeHtml(box.builder.github_login || `#${box.builder.id}`);
    const rank = rankLabel(box.builder.rank);
    const cost = costByBuilder.get(String(box.builder.id));

    const rows = [];
    if (box.region || box.size_slug) {
      rows.push(['Make', escapeHtml([box.region, box.size_slug].filter(Boolean).join(' · '))]);
    }
    if (box.ip && box.state === 'active') rows.push(['IP', escapeHtml(box.ip)]);
    if (box.state === 'active') {
      rows.push(['Up for', fmtAgo(box.provisioned_at)]);
      rows.push(['Idle', `${fmtAgo(box.last_activity_at)}${box.claude_active ? ' · claude live' : ''}`]);
    } else if (box.state === 'parked') {
      rows.push(['Parked', fmtAgo(box.parked_at)]);
    } else if (CLOSEABLE.has(box.state)) {
      rows.push(['State since', fmtAgo(box.last_activity_at || box.provisioned_at)]);
    }
    rows.push(['Cost', cost != null ? fmtUsd(cost) : fmtUsd(box.compute_cost_usd)]);

    const rowsHtml = rows.map(([k, v]) =>
      `<li><span class="k">${escapeHtml(k)}</span><span class="v">${v}</span></li>`).join('');

    const blockedNote = blocked
      ? `<p class="harbor-blocked-note">Barred from opening boxes${box.blocked.reason ? `: ${escapeHtml(box.blocked.reason)}` : '.'}</p>`
      : '';

    const closeable = CLOSEABLE.has(box.state);
    const closeLabel = box.state === 'parked' ? 'Destroy' : 'Close';
    const actions = [];
    if (closeable) actions.push(`<button class="harbor-btn harbor-btn--danger" data-act="close">${closeLabel}</button>`);
    actions.push(blocked
      ? `<button class="harbor-btn" data-act="unblock">Unblock</button>`
      : `<button class="harbor-btn" data-act="block">Block</button>`);

    const el = document.createElement('article');
    el.className = `harbor-container harbor-container--${st.mod}`;
    el.innerHTML =
      `<div class="harbor-container__roof" aria-hidden="true"></div>
       <div class="harbor-container__body">
         <div class="harbor-container__head">
           <span class="harbor-container__who">${who}<span class="harbor-container__rank">${escapeHtml(rank)}</span></span>
           <span class="harbor-pill harbor-pill--${st.pillMod}">${escapeHtml(st.pill)}</span>
         </div>
         <ul class="harbor-rows">${rowsHtml}</ul>
         ${blockedNote}
         <div class="harbor-actions">${actions.join('')}</div>
       </div>`;

    const closeBtn = el.querySelector('[data-act=close]');
    if (closeBtn) closeBtn.addEventListener('click', () => confirmClose(box));
    const blockBtn = el.querySelector('[data-act=block]');
    if (blockBtn) blockBtn.addEventListener('click', () => confirmBlock(box));
    const unblockBtn = el.querySelector('[data-act=unblock]');
    if (unblockBtn) unblockBtn.addEventListener('click', () => confirmUnblock(box));
    return el;
  }

  function renderSummary(boxes, totalUsd) {
    const afloat = boxes.filter((b) => CLOSEABLE.has(b.state)).length;
    const active = boxes.filter((b) => b.state === 'active').length;
    const blocked = boxes.filter((b) => b.blocked && b.blocked.is).length;
    const stats = [
      ['Boxes live', fmtInt(afloat)],
      ['Active now', fmtInt(active)],
      ['Blocked builders', fmtInt(blocked)],
      ['Total cost', fmtUsd(totalUsd)],
    ];
    document.getElementById('harbor-summary').innerHTML = stats.map(([label, value]) =>
      `<div class="harbor-stat"><div class="harbor-stat__label">${escapeHtml(label)}</div><div class="harbor-stat__value">${value}</div></div>`).join('');
  }

  // Sort: live boxes first, then parked, then everything else;
  // within a group, most-recently-touched first (the API already orders by
  // updated_at desc, so a stable sort by group preserves that).
  function sortBoxes(boxes) {
    const rank = (b) => (b.state === 'active' ? 0 : CLOSEABLE.has(b.state) ? 1 : (b.blocked && b.blocked.is) ? 2 : 3);
    return boxes.map((b, i) => [b, i]).sort((a, z) => (rank(a[0]) - rank(z[0])) || (a[1] - z[1])).map((p) => p[0]);
  }

  async function load() {
    const dock = document.getElementById('harbor-dock');
    let boxesResp, ledger;
    try {
      [boxesResp, ledger] = await Promise.all([
        fetchJson('/boxes'),
        fetchJson('/boxes/cost-ledger').catch(() => ({ totals_by_builder: [] })),
      ]);
    } catch (err) {
      if (err && err.kind === '401') return;
      if (err && err.kind === '403') { showSealed(); return; }
      dock.innerHTML = `<p class="harbor-empty">Could not load dev boxes just now.</p>`;
      return;
    }

    const boxes = boxesResp.boxes || [];
    const costByBuilder = new Map();
    let totalUsd = 0;
    for (const row of (ledger.totals_by_builder || [])) {
      const usd = Number(row.total_usd) || 0;
      costByBuilder.set(String(row.builder_id), usd);
      totalUsd += usd;
    }

    renderSummary(boxes, totalUsd);

    if (boxes.length === 0) {
      dock.innerHTML = `<p class="harbor-empty">No dev boxes yet — no builder has opened one.</p>`;
      return;
    }
    dock.innerHTML = '';
    for (const box of sortBoxes(boxes)) dock.appendChild(renderContainer(box, costByBuilder));
  }

  function showSealed() {
    document.getElementById('harbor-sealed').hidden = false;
    document.getElementById('harbor-body').hidden = true;
    document.getElementById('harbor-sub').textContent = 'Archons only.';
  }

  async function init() {
    // Confirm rank=archon for a friendly Archons-only notice; the server gates
    // the page + every endpoint regardless (this is cosmetic defence-in-depth).
    let me;
    try {
      me = await fetchJson('/me');
    } catch (err) {
      if (err && err.kind === '401') return;        // redirected to sign-in
      if (err && err.kind === '403') { showSealed(); return; }
      me = null;
    }
    const rank = (me && (me.builder || me).rank || '').toLowerCase();
    if (rank !== 'archon') { showSealed(); return; }

    document.getElementById('harbor-sub').textContent = 'Each builder’s dev box at a glance.';
    document.getElementById('harbor-body').hidden = false;
    await load();
  }

  init();
})();
