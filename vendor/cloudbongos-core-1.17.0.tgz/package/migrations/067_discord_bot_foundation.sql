-- 067_discord_bot_foundation.sql — Discord bot service principal + account
-- linking + cosmetic applause + audit surface (Discord Phase 3 F1, ADR 0033).
--
-- Foundation for the Phase 3 bot. The bot is a SERVICE PRINCIPAL, gated by
-- identity (builders.system_role='discord_bot'), NEVER by rank — the same
-- pattern as the BFG principal (migration 065 / ADR 0026 §6C). It is trusted
-- only to assert "this Discord user, who reacted/posted, is linked builder X";
-- every write it triggers re-checks X's live rank server-side (ADR 0033 §1).
--
-- Decision-independent substrate: needs no live bot. Account linking (F2), the
-- bot process (F3), upvoting (F4), role-sync (F5) and inbound (F6) build on top.

-- 1. Widen the system_role allowlist to admit the discord_bot principal. The
--    CHECK was introduced by migration 065 ('bfg' only); adding a new system
--    principal widens it in its own migration — an intentional, reviewable act
--    (065's own note). Drop-then-add is idempotent on re-run, and every existing
--    row (NULL for humans, 'bfg' for the BFG) already satisfies the wider set.
ALTER TABLE builders DROP CONSTRAINT IF EXISTS builders_system_role_check;
ALTER TABLE builders
  ADD CONSTRAINT builders_system_role_check
  CHECK (system_role IS NULL OR system_role IN ('bfg', 'discord_bot'));

-- 2. The Discord bot service principal. Mirrors the BFG principal exactly:
--    * cannot claim work — status='inactive' trips the db.claimTask guard;
--    * cannot earn drachmae — it never claims/ships, and rank='xenos' carries
--      no authority anyway;
--    * is not loginable — github_id 'system:discord_bot' is non-numeric, so the
--      GitHub OAuth upsert (numeric ids) can never produce or authenticate it.
--    The bot authenticates via a session token minted out-of-band (F3); the
--    requireDiscordBot gate keys on system_role='discord_bot', not rank.
--    Idempotent via NOT EXISTS (the #476 hardcoded-natural-key guard).
INSERT INTO builders (github_id, github_login, display_name, rank, status, system_role)
SELECT 'system:discord_bot', 'discord-bot-system', 'Discord Bot (system)', 'xenos', 'inactive', 'discord_bot'
WHERE NOT EXISTS (SELECT 1 FROM builders WHERE system_role = 'discord_bot');

-- 3. Account links: builder <-> Discord user, 1:1 both ways. A row exists only
--    because the builder PERSONALLY linked their Discord via the UI-first OAuth
--    flow (F2) — the bot never invents a mapping (ADR 0033 §2). PRIMARY KEY
--    (builder_id) = at most one Discord per builder; UNIQUE (discord_user_id) =
--    at most one builder per Discord. ON DELETE CASCADE: offboarding drops it.
CREATE TABLE IF NOT EXISTS discord_links (
  builder_id       bigint      NOT NULL PRIMARY KEY REFERENCES builders(id) ON DELETE CASCADE,
  discord_user_id  text        NOT NULL UNIQUE,
  linked_at        timestamptz NOT NULL DEFAULT now()
);

-- 4. Cosmetic applause — the "everyone" half of both-mode upvoting (ADR 0033
--    §3). A reaction by anyone (player, Xenos, unlinked, self) lands here and
--    NEVER touches karma_log. One applause per Discord user per target task;
--    re-reacting is a harmless no-op (ON CONFLICT DO NOTHING in the helper).
--    discord_user_id is stored raw (no FK to discord_links) precisely because
--    applause does NOT require a link — that is the point of the cosmetic tier.
CREATE TABLE IF NOT EXISTS discord_applause (
  id               bigserial   PRIMARY KEY,
  target_task_id   bigint      NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  discord_user_id  text        NOT NULL,
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (target_task_id, discord_user_id)
);
CREATE INDEX IF NOT EXISTS idx_discord_applause_task ON discord_applause (target_task_id);

-- 5. Audit surface (ADR 0033 §1 + the grader's forensic note). NULL for direct
--    human web/CLI writes; set to the system-principal id (e.g. 'discord_bot')
--    for principal-originated writes, so "all bot-originated writes" is a clean
--    WHERE clause for forensic review. Populated by the bot endpoints (F4);
--    additive + nullable, so existing audit rows are unaffected.
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS surface text;
COMMENT ON COLUMN audit_log.surface IS
  'Originating surface: NULL for direct human web/CLI writes, or a system principal id (e.g. discord_bot, bfg). Lets forensic review distinguish principal-originated writes (ADR 0033).';
