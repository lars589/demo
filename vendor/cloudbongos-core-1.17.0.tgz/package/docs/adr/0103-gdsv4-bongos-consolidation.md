# 0103 — Consolidate GDS-V4 into BONGOS-V1; split the Bongos desktop app into its own goal

- **Status:** Accepted
- **Date:** 2026-07-02
- **Deciders:** Lars (owner) · Claude (Opus 4.8)
- **Track:** `internal` (Cloud Bongos)
- **Relates to:** [ADR 0064](<redacted>.md) (Medusa → Cloud Bongos), [ADR 0062](<redacted>.md) (core ↔ host / instance model), [ADR 0087](<redacted>.md) (the Bongos desktop app absorbs Dev Box), [ADR 0095](<redacted>.md) (grep-over-embeddings — retires the C1 recall arm). Executed by migration `<redacted>.sql` under task [#1709](https://example.com/builders#/task/1709).

## Context

The internal track carried **two live versions at once** — `GDS-V4` (534 tasks, ~114 open) and `BONGOS-V1` (130 tasks, ~14 open) — with no clean divide between them. Both were, in practice, Cloud Bongos platform work. Worse, `BONGOS-V1` was *titled* "Bongos App — V1" but its goals were platform concerns (core modularization, the animation module), while the actual **Bongos desktop app** (`bongos-app/` — the feedback-capture tool that also absorbs the Dev Box switch, [ADR 0087](<redacted>.md)) had its tasks scattered across *both* versions. Two parallel internal versions + an app/platform naming inversion made "what's the live internal version?" and "is this app work or platform work?" both unanswerable from the ledger.

A task-by-task triage of GDS-V4's 114 open tasks (with the owner, 2026-07-02) also found dead work: the C1 semantic-search/embeddings arm (superseded by [ADR 0095](<redacted>.md)'s decision that agents navigate by grep, not embeddings), old V3-era grader tasks (superseded by the shipped 4-worker grader panel + [ADR 0089](<redacted>.md)), and the T-NNN task-ref migration (the hall-link convention already works and is enforced).

## Decision

1. **One go-forward internal version.** `BONGOS-V1` becomes the single Cloud Bongos **platform** version (renamed "Cloud Bongos — platform (V1)", status `building`). All still-relevant open GDS-V4 work carries into it.
2. **`GDS-V4` is frozen, not shipped.** It was absorbed, not delivered; `frozen` avoids a false 100% and lets its in-flight tail (10 `confirmed` + 1 `active`) finish landing as its final history. Its `shipped`/`abandoned` rows stay attributed to GDS-V4 as the archive of what it delivered.
3. **The Bongos desktop app becomes its own goal** ("Bongos desktop app") under BONGOS-V1, with every app task reparented to it (mascot, branded download + auto-update, the cloudbongos.com landing page, feedback capture, the Dev Box desktop switch). The app is a component *of* the platform version, not a peer version — matching the owner's framing. The code carve `bongos-app/` → `modules/bongos-app/` is tracked as a follow-up task under this goal.
4. **Prune the superseded.** Abandon the C1 embeddings arm (939, 962, 966–971, 1221), the old V3 grader tasks (201, 202, 242, 292, 388, 490, 492), and the T-NNN migration (753, 754, 755) — 19 tasks. Move the two misfiled game-art tasks (586, 587) to product `V2`.
5. **Sever the 758→753 dependency edge** so task 758 (kept) is not left permanently unclaimable by an abandoned dependency.

## Consequences

- `/status` now defaults to `BONGOS-V1` (was `GDS-V4`); the CLAUDE.md version-framing is updated to match.
- The reorg is a **data migration** (182), applied atomically on deploy — reversible by construction (only status/version/goal/edge mutations; the pre-state is snapshotted in the task-1709 notes and the GDS DB dump).
- The recall/embeddings headline in the old GDS-V4 framing is retired; the endorsed findability path (docstrings, greppability, the repo-map) continues under BONGOS-V1 as the C2 cluster.
- **Process gap surfaced:** this consolidation was blocked for hours because the nightly DB backup had failed silently for 12 days (an orphaned superuser-owned table broke pg_dump; fixed under task [#1711](https://example.com/builders#/task/1711)). A version-consolidation should verify a fresh restore point exists *first*.
