# 0095 — Cross-agent context management: adopt docstrings now, defer the portability layer

- **Status:** Accepted
- **Date:** 2026-06-27
- **Deciders:** Lars (owner) · Claude (Opus 4.8)
- **Track:** `internal` (Cloud Bongos / context + retrieval)
- **Relates to:** [ADR 0083](<redacted>.md) / [ADR 0091](<redacted>.md) — the modular decomposition is the *structural* half of low-context AI navigation; this ADR is the *findability* half (see Context). Also [ADR 0094](<redacted>.md) (the codebase map), [ADR 0061](<redacted>.md) / [ADR 0063](<redacted>.md) (the context layers it feeds). Companion: [ADR 0095-a](<redacted>.md) — adopts the memory/retrieval *concepts* and explicitly defers the grep-vs-semantic decision to this ADR (the two collided on `0095` in parallel; see the index note).

## Context

Cloud Bongos is an AI-first build platform, and today its agent-facing surface is shaped almost entirely for one tool — Claude Code: the always-loaded root `CLAUDE.md` ([ADR 0061](<redacted>.md)), the `.claude/` skills + hooks, a lexical-first retrieval layer ([ADR 0060](0060-gds-retrieval-layer.md)), and a generated repo-map ([ADR 0063](<redacted>.md)). The owner wants Cloud Bongos instances to be editable across many agentic coding tools (Claude Code, OpenAI Codex, Cursor, …). That raises two questions a future version must answer:

1. **Retrieval** — how do we make a repo navigable by tools that find code by literal text search ("grep"), and is a meaning-based ("semantic") retrieval layer worth its recurring cost and index-drift?
2. **Portability** — how should the agent-facing contract (instructions, commands, enforcement, capabilities) be structured so it isn't hardwired to one tool?

We did extensive research (two parallel passes, ~50 sources) to inform both. This ADR records the findings as durable framing, but the owner has deliberately scoped the *committed* decision narrow: **adopt docstrings now; everything else is captured as deferred future-decision content, not a commitment.**

The durable findings:

- **Agents navigate by grep, not embeddings.** Claude Code, Codex, and Cursor all default to literal search (generate query → grep → read → iterate). Anthropic and Sourcegraph both *removed* embedding indexes from their code tools (precision on exact identifiers, freshness/anti-staleness, privacy, cost); Cursor keeps embeddings but only *alongside* grep and fights staleness with incremental Merkle-tree re-indexing. So a literal-search-friendly repo is the high-leverage, low-cost target.
- **Greppability is mostly free, write-time discipline that doesn't rot:** distinctive (not generic) names, "the Grep Test" (never construct or dispatch identifiers dynamically), one concept = one name (don't re-case across boundaries), unique whole log/error strings, flat namespaces. Generic identifiers are the single biggest documented retrieval-killer for agents.
- **The best "semantic layer" is meaning written into the source.** Docstrings, module headers, READMEs, and ADRs co-locate concept words with the symbol — which helps grep, agentic search, *and* any future embedding, at zero recurring cost and zero index-drift (the "index" is the version-controlled text). OTB already has the structural half (the generated repo-map with a CI freshness gate) and the ADR/README half; the missing piece is per-symbol/per-module docstrings + consistent concept vocabulary.
- **Cross-tool portability is an adapter problem** — one canonical source per concern + thin per-tool adapters: instructions → an `AGENTS.md`-style canonical file with thin per-tool pointers; commands → plain CLI (already true — slash-commands wrap `scripts/gds/*.js`); enforcement → server/git/CI, never tool hooks (already true — the trust boundary, [ADR 0016](<redacted>.md)); capabilities → MCP (already cross-tool). This is the [ADR 0062](<redacted>.md) / [0081](<redacted>.md) core↔host / swappable-adapter pattern applied to the agent surface.
- **The Cloud Bongos shape:** *how a repo is managed for agents* becomes a project-init **profile** that provisions the right adapter set (which context files, which command wrappers, which retrieval posture, which enforcement). It is a start-of-project decision because naming conventions and whether to stand up an embedding pipeline are expensive to retrofit.

**Relationship to the modular decomposition ([ADR 0083](<redacted>.md) / [ADR 0091](<redacted>.md)).** These were authored alongside this ADR and are the *other half* of the same goal — an AI agent that navigates the codebase at low context cost. The decomposition bounds *how much* an agent must load: a domain becomes a module reached through one doorway, not a 6k-LOC monolith (0091's explicit "AI-scoping payoff"). This ADR is the complementary *findability* layer — meaning written into the source so the agent locates the right module/symbol by search. They compose directly: **the module-header doc-comments decided here are authored per module precisely because 0091 makes the module the unit of scoping**, and each sits beside that module's nested `CLAUDE.md` and the generated repo-map ([ADR 0063](<redacted>.md)). The deferred `AGENTS.md` adapter + per-project agent profile are likewise the agent-surface counterpart to 0091's core↔module boundaries.

## Decision

**We will adopt docstrings and module-header doc-comments as a project convention.** This is the one change ratified here.

- Every public function/class and each module gets a short natural-language doc-comment describing *what it does and why it exists* (not how), using the concept words a human would search for and naming key collaborating symbols.
- Rationale: this is the zero-recurring-cost, zero-index-drift core of semantic findability. Meaning lives in the version-controlled source, so it helps literal/grep search, agentic search, and any future embedding alike — with no separate index to pay for or keep fresh.
- It is a *convention*, rolled out incrementally (new + touched code adopts it by default; high-traffic modules backfilled opportunistically), not a big-bang backfill. Follow-on task [#1654](https://example.com/builders#/task/1654) tracks wiring it into the conventions guidance and an initial backfill; whether to add a non-blocking lint/fitness nudge is left to that task (not ship-blocking without owner sign-off).

Everything else from the research is recorded below as **deferred** — explicitly *not* decided here.

## Alternatives considered

*Per the owner's scope, these are live options for a future planning session, not rejected ones. Captured so the research isn't re-done.*

- **Stand up a semantic / embedding retrieval layer now.** Deferred. Embeddings earn their keep mainly on large codebases / pure concept-queries and carry recurring cost + index-drift; the leading tools dropped them or only augment grep with them. If ever pursued: local embedding model + embedded store (e.g. sqlite-vec) + incremental, content-hash, git-hook re-indexing, run *alongside* grep (hybrid), never instead. ([ADR 0060](0060-gds-retrieval-layer.md) already deferred embeddings behind a measured gate — this corroborates it.)
- **Adopt an `AGENTS.md` cross-tool adapter layer** (one canonical instructions file + thin `CLAUDE.md` / `.cursor/rules` / `copilot-instructions` pointers, generated from a single source). Deferred — likely the highest-value *next* step, but a design decision in its own right (canonical-vs-adapter split; import vs symlink vs generator).
- **Adopt explicit greppability conventions** (distinctive names, the Grep Test, flat namespaces, unique log strings) as a written, possibly lint-enforced standard. Deferred — strong candidate; pairs naturally with the AGENTS.md work.
- **Adopt an `AIDEV-NOTE:` anchor-comment convention** (greppable inline notes for landmines and the "why"), guarded by a density / overdue fitness check so it can't rot. Deferred — high agent payoff, but it is *planted maintenance debt* and is only safe with the CI guard, so it needs deliberate design.
- **Make a "retrieval & agent profile" a Cloud Bongos init setting** that deploys a different set of agents / skills / context-files / enforcement per project. Deferred — the owner flagged this as a serious, start-of-project-level platform decision; needs its own scoping.

## Consequences

- **Now:** a low-cost convention that improves human readability, grep/agentic retrieval, and any future semantic layer simultaneously — no infra, no drift. The cost is authoring discipline; a stale doc-comment can mislead, mitigated by the same "update the comment when you change the code" rule we already apply to anchors.
- **Preserved:** the research and the five deferred options are recorded here so a future GDS-V4 / Cloud Bongos planning session starts from them instead of re-researching. This ADR is framing + one decision; it deliberately does **not** commit the platform to the adapter layer, embeddings, or the per-project profile.
- **Follow-on:** task [#1654](https://example.com/builders#/task/1654) (docstring rollout). The deferred items remain unticketed by design until the owner chooses to scope them.

## C4 — `<private>` content-exclusion marker (shipped, task [#1661](https://example.com/builders#/task/1661))

An agent can wrap sensitive content in a `<private>…</private>` fence so it **never** enters the memory/learning store nor the recall index — the explicit, write-time opt-out that reinforces the trust boundary ([ADR 0016](<redacted>.md)) and complements the BFG transcript scrub: secrets, permission-core internals, and sub-Metic-sensitive material fenced out *at the source*.

Implementation (all in `modules/memory`): a pure `stripPrivate()` in `search-chunker.js` removes every `<private>…</private>` region and is applied at **every** ingest/persist entry point — `storeMemoryFile`, `storeMemoryFilesBatch`, and the BFG cross-builder `bfgWriteMemoryFile` in `memory.js`; `createLearning` in `learnings.js` (title + body); and `chunkMarkdown` (the recall index) itself. The match is **case-insensitive and whitespace-tolerant** (`<private>`, `<PRIVATE>`, `< private >`) and **fail-closed**: an unbalanced `<private>` with no matching close strips to end-of-content, so a half-typed marker can't leak the secret it was meant to hide. A learning whose entire body is fenced strips to empty and is rejected like any other empty body.
