'use strict';

// Discord #bugs → GDS tasks (kind='bug') — Phase 3 F8 (ADR 0033 §F8, ADR 0047).
//
// The bot turns a message posted in the designated #bugs channel into a GDS
// task with kind='bug', STRAIGHT THROUGH — no idea_inbox, no triage step. This
// is the deliberate difference from #ideas (discord-inbound.js): a bug is a
// small fix a builder wants to drop without context-switching, and it becomes
// claimable work directly.
//
// ANTI-ABUSE GUARD (ADR 0047 — the red-team resolution). Creating claimable
// work with no triage gate is an injection surface, so this path is guarded in
// depth, all server-side, all fail-closed:
//   1. LINKED-BUILDER-ONLY. An unlinked Discord author cannot create a task —
//      their message is ignored (not filed). Unlike #ideas (which captures
//      unattributed), making *claimable work* requires being an accountable,
//      known builder. This is the single biggest lever.
//   2. RANK-AWARE LANDING. A linked Metic+ builder's bug lands 'ready'
//      (instantly claimable — the true straight-through path their trust earns).
//      A linked Xenos/Thetes builder's bug lands 'backlog' (needs a one-click
//      Metic+ promote, like any other backlog task). Mirrors the trust ladder
//      used everywhere else in the GDS.
//   3. PER-BUILDER RATE-LIMIT. At most N bug-tasks per builder per rolling hour
//      (counted from audit_log). Over-limit filings are ignored AND audited so
//      a spammer surfaces in forensics / the red-team view.
//   4. BODY SCREEN. Empty / too-short / text-free messages are ignored before
//      any DB write; title + body are capped to the GDS limits.
//
// TRUST BOUNDARY (ADR 0016 / ADR 0033 §1): the bot asserts only WHO posted
// (the linked builder); the landing state is decided server-side from that
// builder's LIVE rank, never from anything in the message. The bot grants
// nothing. Every filing — and every rate-limit rejection — is audited with
// surface='discord_bot'.
//
// Requires (go-live): the Message Content PRIVILEGED intent + a pinned
// DISCORD_BUGS_CHANNEL_ID. Inert until both are set.

const db = require('./db');
const { auditDiscordBot } = require('./discord-audit');
const auth = require('./auth');
const attachments = require('./bug-attachments');
const { combineParts, createMessageAggregator } = require('./discord-message-buffer');
const { LIMITS } = require('../../src/module-api');

// Ranks whose bugs land 'ready' (instantly claimable). Everyone else linked
// lands 'backlog'. Metic+ — matches REQUIRES_RANK_TIER >= metic in db.js.
const READY_RANKS = new Set(['metic', 'archon']);

// Smallest message we'll treat as a real bug report. Anything shorter is noise.
const MIN_BUG_CHARS = 8;

// Default rate-limit: bug-tasks one builder may create per rolling hour. Env
// DISCORD_BUGS_RATE_PER_HOUR overrides (a number); falls back to this.
const DEFAULT_RATE_PER_HOUR = 5;

// Default GDS version a filed bug is filed under. Most builder-filed bugs are
// about the dev system; an Archon can re-home a game bug to a product version.
// Env DISCORD_BUGS_VERSION_ID overrides.
const DEFAULT_BUGS_VERSION_ID = 'GDS-V3';

// Modest reward for fixing a drive-by bug. Env DISCORD_BUGS_CREDITS overrides.
const DEFAULT_BUGS_CREDITS = 10;

// Auto-pairing window: consecutive #bugs messages from the SAME author within
// this window are combined into ONE bug-task (so "screenshot" + "here's what
// happened" posted seconds apart — in either order — become one report, not
// two). Env DISCORD_BUGS_PAIR_WINDOW_MS overrides.
const DEFAULT_PAIR_WINDOW_MS = 45 * 1000;

// Title for a bug that arrives as image(s) with no usable text.
const SCREENSHOT_TITLE = 'Bug report (screenshot)';

function rateLimitPerHour(env = process.env) {
  const n = Number(env.DISCORD_BUGS_RATE_PER_HOUR);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : DEFAULT_RATE_PER_HOUR;
}

function bugsVersionId(env = process.env) {
  return env.DISCORD_BUGS_VERSION_ID || DEFAULT_BUGS_VERSION_ID;
}

function bugsCredits(env = process.env) {
  const n = Number(env.DISCORD_BUGS_CREDITS);
  return Number.isFinite(n) && n >= 0 ? Math.floor(n) : DEFAULT_BUGS_CREDITS;
}

function pairWindowMs(env = process.env) {
  const n = Number(env.DISCORD_BUGS_PAIR_WINDOW_MS);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : DEFAULT_PAIR_WINDOW_MS;
}

// PURE — decide where a bug lands from the reporter's LIVE rank. Metic+ →
// 'ready' (straight-through, claimable now); any other linked rank → 'backlog'
// (a Metic+ promotes it, the lightweight confirm gate). Unit-tested.
function decideBugLanding(rank) {
  return READY_RANKS.has(String(rank || '').toLowerCase()) ? 'ready' : 'backlog';
}

// PURE — screen + shape a raw message into { ok, title, bodyMd } or
// { ok:false, reason }. The body screen rejects blank / too-short / text-free
// (no letters) messages before any DB write — UNLESS the message carries
// image(s): an image is content, so an image-only bug is allowed through with a
// default title. Title = first non-empty line (capped) or the screenshot
// title; body = full message text (capped, possibly empty). Unit-tested.
function screenBug(content, { hasImages = false } = {}) {
  const trimmed = typeof content === 'string' ? content.trim() : '';
  const hasText = trimmed.length >= MIN_BUG_CHARS && /[a-zA-Z]/.test(trimmed);

  if (!hasText && !hasImages) {
    if (!trimmed) return { ok: false, reason: 'empty' };
    if (trimmed.length < MIN_BUG_CHARS) return { ok: false, reason: 'too_short' };
    return { ok: false, reason: 'no_text' };
  }

  const cap = LIMITS.TITLE;
  let title;
  if (trimmed) {
    const firstLine = (trimmed.split('\n').find((l) => l.trim()) || trimmed).trim();
    title = firstLine.length > cap ? `${firstLine.slice(0, cap - 1)}…` : firstLine;
  } else {
    title = SCREENSHOT_TITLE;
  }
  const bodyMd = trimmed.length > LIMITS.DESCRIPTION ? trimmed.slice(0, LIMITS.DESCRIPTION) : trimmed;
  return { ok: true, title, bodyMd };
}

const realDeps = {
  getBuilderByDiscordUserId: db.getBuilderByDiscordUserId,
  countRecentDiscordBugFilings: db.countRecentDiscordBugFilings,
  createTask: db.createTask,
  insertAuditLog: db.insertAuditLog,
  persistImages: attachments.persistImages,
};

// File one inbound #bugs message as a GDS task (kind='bug'). NEVER throws (the
// caller is a gateway event handler). Returns a small status object for
// logging/tests. `config` is injectable so tests don't touch process.env.
async function recordInboundBug({ discordUserId, content, imageUrls = [], messageId }, deps = realDeps, config = {}) {
  if (!auth.isValidDiscordUserId(discordUserId)) {
    return { outcome: 'ignored', reason: 'bad_discord_user_id' };
  }
  const hasImages = Array.isArray(imageUrls) && imageUrls.length > 0;
  const screened = screenBug(content, { hasImages });
  if (!screened.ok) return { outcome: 'ignored', reason: screened.reason };

  const limit = config.rateLimitPerHour ?? rateLimitPerHour();
  const versionId = config.versionId ?? bugsVersionId();
  const credits = config.credits ?? bugsCredits();

  try {
    // (1) LINKED-BUILDER-ONLY. No linked builder → reject (do not file). An
    // unlinked author cannot inject claimable work.
    const builder = await deps.getBuilderByDiscordUserId(discordUserId);
    if (!builder) return { outcome: 'ignored', reason: 'unlinked' };

    // (3) PER-BUILDER RATE-LIMIT. Count this builder's bug filings in the last
    // hour; over the cap → reject AND audit (so a spammer is visible in
    // forensics / the red-team view), but never throw.
    const sinceIso = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    let recent = 0;
    let countFailed = false;
    try {
      recent = await deps.countRecentDiscordBugFilings(builder.id, sinceIso);
    } catch (e) {
      // L4 (red-team 2026-06-12): FAIL CLOSED on a count error. The old behaviour
      // proceeded ("fail-open"), which let a DB error be used to slip past the
      // per-builder limit. A failed count means we cannot prove the caller is
      // under the cap, so treat it as rate-limited (deny) and audit it. Never
      // throw — the caller is a gateway event handler.
      console.error('[discord-bot] bug rate-limit count failed (denying — fail-closed):', e.message);
      countFailed = true;
    }
    if (countFailed || recent >= limit) {
      const reason = countFailed ? 'rate_limit_count_error' : 'rate_limited';
      await auditDiscordBot(deps, {
        builderId: builder.id,
        route: 'discord:bugs',
        requestBodyRedacted: { discord_user_id: discordUserId, message_id: messageId, rejected: reason, recent },
        responseStatus: 429,
        logLabel: 'bug rate-limit audit failed',
      });
      return { outcome: 'ignored', reason, recent };
    }

    // (2) RANK-AWARE LANDING — decided from the LIVE rank, never the message.
    const status = decideBugLanding(builder.rank);

    // Re-host any images on our server (durable — Discord CDN links expire). The
    // guard (host allowlist + content-type + magic-byte sniff + size/count caps)
    // lives in bug-attachments.persistImages; refused images are skipped, not
    // fatal. A persist failure must not lose the report.
    let stored = [];
    if (hasImages) {
      try {
        stored = await deps.persistImages(imageUrls, { messageId });
      } catch (e) {
        console.error('[discord-bot] bug image persist failed (filing without images):', e.message);
      }
    }

    // Provenance footer so a claimer knows where the bug came from + who to ask.
    // The raw Discord snowflake is NOT embedded (it lives in the Archon-only
    // audit_log); only the builder login. Then the durable attachment links.
    const origin = `\n\n— reported from Discord #bugs by ${builder.github_login}`;
    let description = `${screened.bodyMd}${origin}`;
    if (stored.length > 0) {
      const imgs = stored.map((s, i) => `![attachment ${i + 1}](${s.url})`).join('\n');
      description += `\n\nAttachments (${stored.length}):\n${imgs}`;
    }
    description = description.slice(0, LIMITS.DESCRIPTION);

    const task = await deps.createTask({
      versionId,
      title: screened.title,
      description,
      status,
      kind: 'bug',
      priority: 3,
      creditsReward: credits,
      source: 'discord:bugs',
      sourceRef: `discord:${messageId}`,
    });

    await auditDiscordBot(deps, {
      builderId: builder.id,
      route: 'discord:bugs',
      requestBodyRedacted: { discord_user_id: discordUserId, message_id: messageId, task_id: task.id, status, images: stored.length },
      responseStatus: 201,
      logLabel: 'bug audit-log write failed',
    });

    return { outcome: 'filed', taskId: task.id, status, builderId: builder.id, images: stored.length };
  } catch (err) {
    console.error('[discord-bot] recordInboundBug failed:', err.message);
    return { outcome: 'error', error: err.message };
  }
}

// Auto-pairing aggregator for #bugs — a thin wrapper over the shared
// per-author burst aggregator (discord-message-buffer.js) that supplies the
// #bugs default window. onFlush files the combined burst as ONE bug.
function createBugAggregator({ onFlush, windowMs = pairWindowMs(), timers = global } = {}) {
  return createMessageAggregator({ onFlush, windowMs, timers });
}

module.exports = {
  screenBug,
  decideBugLanding,
  recordInboundBug,
  combineParts,
  createBugAggregator,
  realDeps,
  rateLimitPerHour,
  bugsVersionId,
  bugsCredits,
  pairWindowMs,
};
