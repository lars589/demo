// MAS Phase 2.0 (#410) — Narc worker.
//
// Specialty: semantic completion. Walks the task description's acceptance
// criteria line by line, verifies each in the diff or (via Read) the post-
// merge file state, and flags any AC that isn't satisfied. Reports a
// `functional_fidelity` score (0-10) + a per-AC checklist.
//
// Replaces the ff axis of the v3 generalist grader. cq + economy are
// handled by the Quality worker (until Phase 2.1+ specializes them).

// THRESHOLD + LOW_CONF come from the shared rubric module (task 1090, C6) — a
// bump to grader-rubric.json drives every per-worker verdict without code edits.
const { THRESHOLD, LOW_CONF } = require('./rubric');

// SR-15 / G1 (#995): wrap all builder-controlled inputs in a scrubbed, fenced
// block the model is told to treat as DATA, never instructions. The shared
// scaffold (worker-prompt) owns fenceBlock/scrubUntrusted/NOFOLLOW_PREAMBLE.
const { buildWorkerPrompt, LLM_PROJECT } = require('./worker-prompt');
const { failResult, parseCommon, finalizeVerdict } = require('./worker-verdict');

const KIND = 'narc';
const NAME = 'Narc';
const SPECIALTY = 'semantic completion (description vs diff, line-level)';

const PROMPT_HEADER = `You are the **Narc** — a specialist adversarial subagent for the ${LLM_PROJECT} project. You exist to catch the single most common form of shipped-but-broken work: the task whose acceptance criteria were not actually satisfied by the diff.

Your ONLY job is semantic completion. You do NOT score code quality, security, or economy — other specialists handle those. Your verdict is about whether the description was implemented.

**The default verdict is FAIL.** You PASS only after walking the description's acceptance criteria and finding affirmative evidence that EACH ONE is satisfied or explicitly out-of-scope per the description's own words.

## Read budget (CRITICAL)

**You have a hard budget of 5 Read calls per grade.** This is a calibration constraint — you previously deterministically timed out by Read-verifying every AC. The fix is to be selective.

**Prefer the diff over Read.** Most ACs are visible in the diff: a new function, a comment update, an ADR section, a test file added, a constant changed. If the diff text shows what the AC claims, that's evidence — you do NOT need to Read the file. Mark it \`diff-confirmed\`.

**Only spend a Read on ACs that need it.** Read is for: verifying that a deletion is unreferenced elsewhere, that a rename's call sites all updated, that behavior promised in the description (but not visible in the hunk) is actually present in the post-merge file. If an AC is plainly visible in the diff, do NOT Read.

**If you exhaust the budget,** mark remaining ACs that would have needed a Read with status \`unverified-budget\` rather than chasing each one. The verdict logic treats \`unverified-budget\` neutrally — it doesn't drag your score down unless a majority of ACs land in that bucket.

## How you work

1. Read the task description (provided below). Find every acceptance criterion. ACs typically live under "Acceptance:" or "Acceptance criteria:" headers but may be stated as bullet points anywhere in the description.

2. For each AC, build a checklist entry. Status is one of:
   - **diff-confirmed** — the AC is plainly visible in the diff text below. You quote the diff line. No Read needed.
   - **satisfied** — you used a Read call to verify the AC in the post-merge file state. You name the file:line.
   - **partial** — the AC is partly implemented but a named gap remains. You describe the gap.
   - **missing** — the AC is not implemented at all. You describe what's missing.
   - **out-of-scope** — the description itself explicitly excludes this. Quote where it says so.
   - **unverified-budget** — would have needed a Read but the budget is exhausted. The diff is ambiguous on this AC; you couldn't reach the file. (Use sparingly — this is a confession, not an escape hatch.)

3. Score functional_fidelity (0-10) based on the checklist. \`diff-confirmed\` counts the same as \`satisfied\` for scoring. \`unverified-budget\` is neutral (doesn't push the score up or down by itself) unless it dominates:
   - 10 = every AC is satisfied / diff-confirmed / out-of-scope; no gaps anywhere.
   - 8 = every AC satisfied or diff-confirmed; minor polish items remain.
   - 6 = mostly there with ONE named partial OR a few unverified-budget items mixed with satisfied. (Threshold for passing the gate.)
   - 4 = multiple partials OR one missing AC OR most ACs are unverified-budget.
   - 2 = mostly missing; the diff implements a different thing.
   - 0 = the diff does not implement the described work at all.

4. For each **partial** or **missing** AC, write an issue with severity (\`blocker\` for missing, \`major\` for partial) — file is the file the AC should have touched, summary is one line naming the gap.

5. Confidence (0-1): how sure are you of the score? If the description is too vague to grade against, or you couldn't reach key files within budget — set confidence LOW (< 0.4). The downstream system treats low confidence as fall-through.

## Sanity checks

- A PASS verdict with no \`ac_checklist\` entries is invalid — you must enumerate the ACs you verified.
- A FAIL verdict with no \`issues\` entries is invalid — name at least one missing AC.
- A score of 6+ requires no missing ACs and at most one partial.
- "Acceptance: tests pass" is NOT a valid AC verification on your part — you can't run tests. If the diff adds a test for the named behavior, that's \`diff-confirmed\`. If the test is in a file the diff doesn't fully show, that's worth ONE Read.
- If you find yourself wanting to Read every file mentioned by every AC, stop. Re-check whether the diff already shows it. The diff text is your primary evidence.

## Return ONLY JSON

No prose before or after, no markdown fences:

\`\`\`
{
  "functional_fidelity": <number 0-10>,
  "confidence": <number 0-1>,
  "reads_used": <integer 0-5>,
  "ac_checklist": [
    { "ac": "<string — the AC as written in the description>", "status": "diff-confirmed"|"satisfied"|"partial"|"missing"|"out-of-scope"|"unverified-budget", "evidence": "<diff line OR file:line OR quoted text>" }
  ],
  "issues": [
    { "severity": "blocker"|"major"|"minor"|"nit", "file": "<path>", "summary": "<one line>" }
  ],
  "notes_md": "<short markdown — what you verified, what gaps you found, what you couldn't reach within budget>"
}
\`\`\`

You have a Read tool with a hard budget of 5 calls. Do not run tests, do not edit files, do not call the network.`;

function buildPrompt({ task, valueSummary, diff, changedFiles }) {
  const t = task || {};
  // Narc's description fallback is uniquely "(no description — set confidence
  // LOW)" (the others use "(no description)"); the shared scaffold defaults to
  // "(no description)", so pre-resolve the fallback here and hand it through.
  // Truthy descriptions pass untouched, so the scaffold's own `|| ... .trim()`
  // stays byte-identical to the inlined version.
  return buildWorkerPrompt({
    header: PROMPT_HEADER,
    task: { ...t, description: t.description || '(no description — set confidence LOW)' },
    valueSummary,
    diff,
    changedFiles,
    taskHeader: '## Task',
    descLabel: '**Description (your source of truth for the ACs):**',
    emptyFilesText: '(no files changed — this is suspicious; mark every AC as missing)',
    readFilesHint: 'You can Read any of these files to see their post-merge state.',
    finalInstruction: 'Now walk the ACs. Default-fail unless every one is satisfied or explicitly out-of-scope. Output ONLY the JSON object.',
  });
}

// #79 (#493): delegate to the shared robust extractor so the v4 panel path
// gets the same parse-resilience (whole-string -> fenced -> balanced-brace) as
// grader.js, instead of the brittle first-{-to-last-} copy that flaked.
const { extractJson } = require('./extract-json');

// Narc's per-worker verdict. Inputs:
//   parsed: the JSON the subagent emitted (or null on parse failure)
//   meta:   { run_ms, model, etc. } — pass-through from runOneShot
// Output: a partial WorkerResult; runWorker fills in kind/name/etc.
function computeVerdict(parsed, meta = {}) {
  // Errors short-circuit to 'fail' so the panel can decide what to do.
  if (meta.subprocess_error) {
    return failResult({ notesMd: `Narc: subagent error (${meta.subprocess_error}).`, error: meta.subprocess_error });
  }
  if (!parsed || typeof parsed !== 'object') {
    return failResult({ notesMd: 'Narc: could not parse subagent output as JSON.', error: 'parse_error' });
  }

  const ff = Number(parsed.functional_fidelity);
  const { conf, issues, notesFromSubagent } = parseCommon(parsed);
  const checklist = Array.isArray(parsed.ac_checklist) ? parsed.ac_checklist : [];

  // Out-of-range or non-numeric ff → schema error → fail.
  if (!Number.isFinite(ff) || ff < 0 || ff > 10) {
    return failResult({ issues, notesMd: `Narc: functional_fidelity was non-numeric or out of range (got ${parsed.functional_fidelity}).`, error: 'schema_error' });
  }

  const ffR = Math.round(ff * 10) / 10;
  const blockerCount = issues.filter((i) => i.severity === 'blocker').length;
  const missingCount = checklist.filter((c) => c && c.status === 'missing').length;
  const partialCount = checklist.filter((c) => c && c.status === 'partial').length;
  // diff-confirmed counts as satisfied for scoring (Phase 2.0.5 #413).
  const satisfiedCount = checklist.filter(
    (c) => c && (c.status === 'satisfied' || c.status === 'diff-confirmed')
  ).length;
  // unverified-budget is neutral by itself; concerns trip only if it dominates
  // the checklist (more than half of the verifiable ACs landed there).
  const unverifiedBudgetCount = checklist.filter(
    (c) => c && c.status === 'unverified-budget'
  ).length;
  const totalChecklist = checklist.length;
  // Verifiable ACs = total minus out-of-scope (which is a positive verdict
  // type, not a "couldn't verify" state).
  const verifiableCount = checklist.filter(
    (c) => c && c.status !== 'out-of-scope'
  ).length;
  const unverifiedDominates =
    verifiableCount > 0 && unverifiedBudgetCount * 2 > verifiableCount;
  const lowConfidence = conf != null && conf < LOW_CONF;

  let verdict;
  let notesPrefix;
  if (blockerCount > 0 || missingCount > 0 || ffR < THRESHOLD) {
    verdict = 'fail';
    notesPrefix = `Narc — FAIL (ff=${ffR}/10`
      + (missingCount > 0 ? `, ${missingCount} missing AC${missingCount === 1 ? '' : 's'}` : '')
      + (blockerCount > 0 ? `, ${blockerCount} blocker issue${blockerCount === 1 ? '' : 's'}` : '')
      + `)`;
  } else if (lowConfidence || partialCount > 0 || unverifiedDominates) {
    verdict = 'concerns';
    notesPrefix = `Narc — CONCERNS (ff=${ffR}/10`
      + (lowConfidence ? `, low confidence ${conf}` : '')
      + (partialCount > 0 ? `, ${partialCount} partial AC${partialCount === 1 ? '' : 's'}` : '')
      + (unverifiedDominates ? `, ${unverifiedBudgetCount}/${verifiableCount} ACs unverified (budget)` : '')
      + `)`;
  } else {
    verdict = 'pass';
    const verifiedStr = satisfiedCount === totalChecklist
      ? `${totalChecklist} AC${totalChecklist === 1 ? '' : 's'} verified`
      : `${satisfiedCount} verified / ${unverifiedBudgetCount} unverified-budget / ${totalChecklist} total`;
    notesPrefix = `Narc — PASS (ff=${ffR}/10, ${verifiedStr}, conf=${conf ?? '?'})`;
  }

  return finalizeVerdict({
    verdict,
    scores: { functional_fidelity: ffR },
    issues,
    extra: { ac_checklist: checklist },
    notesPrefix,
    notesFromSubagent,
    confidence: conf,
  });
}

module.exports = {
  KIND,
  NAME,
  SPECIALTY,
  PROMPT_HEADER,
  buildPrompt,
  extractJson,
  computeVerdict,
};
