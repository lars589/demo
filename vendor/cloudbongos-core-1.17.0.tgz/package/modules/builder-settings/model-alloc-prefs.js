// modules/builder-settings/model-alloc-prefs.js — per-builder / per-instance
// MODEL ALLOCATION (task 2011 / BONGOS-V1).
//
// The subagent model-routing policy (main session = top tier; subagents default
// to the development tier, routine plumbing to the cheap tier; "no Sonnet") was
// a hardcoded TABLE in CLAUDE.md §2 — it rots as model names change and is the
// same class of leak as the reward formula (task 2009). This makes the tier
// VALUES settings-driven: an INSTANCE default (`config/branding.json` `models`)
// with an optional PER-BUILDER override (behavior_prefs `model_allocation`),
// resolved over the code defaults. §2 keeps only the stable SHAPE + rationale
// and points here; changing a tier no longer needs a doc edit.
//
// PURE lib (the wandering/interaction-prefs pattern): it takes the instance
// default as a param (the route reads `branding().models` via the doorway and
// passes it), so it stays testable with no global-config read.

const RESERVED_KEY = 'model_allocation';

// Tier vocabulary — mirrors skill-prefs.ALLOWED_MODELS (minus 'script', which is
// a per-skill escape hatch, not a session tier). Ordered cheap→capable for UIs.
const ALLOWED_TIERS = Object.freeze(['haiku', 'sonnet', 'opus', 'fable']);

// The allocation slots + their code defaults (the current §2 policy verbatim):
// the main interactive session runs top-tier; subagents default to the
// development tier; routine plumbing (known-path GDS/DB reads) drops to cheap.
const SLOTS = Object.freeze({
  main: { label: 'Main interactive session', default: 'opus', blurb: 'The session the builder sits in front of.' },
  subagentDefault: { label: 'Subagents (default)', default: 'opus', blurb: 'Research, audits, code review, design, code that ships, parallel build sessions.' },
  subagentRoutine: { label: 'Subagents (routine plumbing)', default: 'haiku', blurb: 'Mechanical known-path GDS/DB ops: list, fetch-by-id, log a cost row, read a known file.' },
});

const SLOT_KEYS = Object.keys(SLOTS);

function isValidTier(t) {
  return typeof t === 'string' && ALLOWED_TIERS.includes(t);
}

// Sanitize a raw slot→tier map to known slots + valid tiers.
function sanitize(raw) {
  const out = {};
  if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
    for (const k of SLOT_KEYS) if (isValidTier(raw[k])) out[k] = raw[k];
  }
  return out;
}

function codeDefaults() {
  const out = {};
  for (const k of SLOT_KEYS) out[k] = SLOTS[k].default;
  return out;
}

// The builder's stored override (behavior_prefs.model_allocation), sanitized.
function storedOverride(behaviorPrefs) {
  return sanitize(behaviorPrefs && behaviorPrefs[RESERVED_KEY]);
}

// The instance default (branding.models), sanitized. Passed in by the route.
function instanceDefault(instanceModels) {
  return sanitize(instanceModels);
}

// Effective allocation: builder override → instance default → code default,
// per slot. This is what the agent consults when spawning subagents.
function effectiveAllocation(behaviorPrefs, instanceModels) {
  const override = storedOverride(behaviorPrefs);
  const inst = instanceDefault(instanceModels);
  const code = codeDefaults();
  const out = {};
  for (const k of SLOT_KEYS) out[k] = override[k] || inst[k] || code[k];
  return out;
}

// A compact human/agent-facing guidance line for the effective allocation.
function contractFor(behaviorPrefs, instanceModels) {
  const eff = effectiveAllocation(behaviorPrefs, instanceModels);
  return `Model allocation — main session: ${eff.main}; subagents default: ${eff.subagentDefault}, routine plumbing: ${eff.subagentRoutine}. Set the Agent \`model\` param explicitly per this allocation.`;
}

// The catalog the /settings UI renders.
function slotCatalog() {
  return SLOT_KEYS.map((k) => ({
    slot: k,
    label: SLOTS[k].label,
    blurb: SLOTS[k].blurb,
    code_default: SLOTS[k].default,
    tiers: ALLOWED_TIERS.slice(),
  }));
}

// Everything /me + /settings need in one object.
function describeForApi(behaviorPrefs, instanceModels) {
  return {
    slots: slotCatalog(),
    allowed_tiers: ALLOWED_TIERS.slice(),
    code_defaults: codeDefaults(),
    instance_default: instanceDefault(instanceModels),
    override: storedOverride(behaviorPrefs),
    effective: effectiveAllocation(behaviorPrefs, instanceModels),
    contract: contractFor(behaviorPrefs, instanceModels),
  };
}

// Validate a PATCH body: { <slot>: <tier> | null }. null clears the override for
// that slot (fall back to instance/code default). Unknown slot / bad tier → 422.
function validatePatch(body) {
  if (body == null || typeof body !== 'object' || Array.isArray(body)) {
    return { ok: false, errors: [{ error: 'body_must_be_object' }] };
  }
  const errors = [];
  const patch = {};
  for (const [key, value] of Object.entries(body)) {
    if (!SLOT_KEYS.includes(key)) { errors.push({ error: 'unknown_slot', slot: key }); continue; }
    if (value === null) { patch[key] = null; continue; }
    if (!isValidTier(value)) { errors.push({ error: 'bad_tier', slot: key, allowed: ALLOWED_TIERS }); continue; }
    patch[key] = value;
  }
  if (errors.length) return { ok: false, errors };
  return { ok: true, patch };
}

// Merge a validated patch into the stored override (null clears). Pure.
function applyPatch(stored, patch) {
  const next = { ...(stored || {}) };
  for (const [k, v] of Object.entries(patch)) {
    if (v === null) delete next[k];
    else next[k] = v;
  }
  return next;
}

module.exports = {
  RESERVED_KEY,
  ALLOWED_TIERS,
  SLOTS,
  SLOT_KEYS,
  isValidTier,
  codeDefaults,
  storedOverride,
  instanceDefault,
  effectiveAllocation,
  contractFor,
  slotCatalog,
  describeForApi,
  validatePatch,
  applyPatch,
};
