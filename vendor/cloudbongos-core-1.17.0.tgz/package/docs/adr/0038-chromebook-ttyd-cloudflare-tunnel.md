# ADR 0038 — Chromebook / browser on-ramp via a box-hosted ttyd web terminal over a Cloudflare Tunnel

**Date:** 2026-06-06
**Context:** GDS-V3, task [#760](https://example.com/builders#/task/760). Feeds done-when criterion **C1** (`a Metic onboards in ≤ 2h`) by restoring a *working* thin-device on-ramp. Companion to [ADR 0031](<redacted>.md) (the per-builder DigitalOcean box substrate), [ADR 0035](<redacted>.md) (the three onboarding paths), [ADR 0016](<redacted>.md) (server-enforced trust boundary — the web tier only *asks*, never holds infra power), and [ADR 0022](0022-secrets-policy.md) (no secrets in repo).
**Status:** Accepted. **Supersedes the Remote-Control (path 3) approach** in [ADR 0035](<redacted>.md) Path 3 and [ADR 0031](<redacted>.md) §1 / §9.4 (the `claude rc` thin-device on-ramp). Implemented this session under [#760](https://example.com/builders#/task/760).

> **Update (2026-06-07, [ADR 0040](<redacted>.md)):** the "Remote Control is unfixable" conclusion below was specific to running RC *headless, as a background service*. Once this ADR's ttyd web terminal put a real human at a real PTY, Remote Control works — started in-session with `/remote-control` (not the standalone `claude rc`). RC is now the **default** browser-only experience (shipped in [#807](https://example.com/builders#/task/807)); the ttyd terminal is its one-time launchpad. The blockers in *Problem* still hold for *headless* RC. See ADR 0040.
**Track:** `internal` (dev-system / builder onboarding).

## Problem

A per-builder cloud dev box ([ADR 0031](<redacted>.md)) is reached two ways: Mac/Windows builders via Claude Desktop + SSH (works), and Chromebook / browser-only builders via — originally — Claude's **Remote Control** (`claude rc`) running as a headless systemd service (`infra/claude-rc.service`), with the box publishing a claude.ai pairing link UP to the GDS so the builder reaches it from a browser ([ADR 0031](<redacted>.md) §9.4, [#701](https://example.com/builders#/task/701)).

Task [#745](https://example.com/builders#/task/745) leg-5 verification-tested that path on hardware and found it **broken end to end**. This session's research (June 2026, Claude Code CLI v2.1.x) confirmed it is **not** fixable by plumbing — there are three hard blockers, all on Anthropic's side and by design:

1. **Trusted Devices is interactive-only.** "Trusted Devices for Remote Control" is an org/account policy that requires interactive `/login` device enrollment in a TTY. There is no headless / baked-credential / env-var enrollment path. Observed live: `claude rc` errors `Your organization requires Trusted Devices for Remote Control, but this device is not enrolled. Please run /login in Claude Code to enroll this device.`
2. **`claude rc` needs a controlling TTY.** It requires a controlling TTY and only renders the pairing URL to a TTY. A systemd service has none, so the URL is never captured.
3. **Remote Control needs full-scope subscription OAuth.** Every non-interactive auth path (`ANTHROPIC_API_KEY`, `claude setup-token` / `CLAUDE_CODE_OAUTH_TOKEN`, `apiKeyHelper`) is inference-only and is **explicitly excluded** from Remote Control.

Net: a headless box can never bootstrap `claude rc`, and a no-SSH Chromebook builder cannot perform the interactive enrollment *on* the box either. Dead end.

## Decision

**Drop `claude rc` entirely. The box serves its OWN browser session: a `ttyd` web terminal, exposed through an outbound-only Cloudflare Tunnel, dropping the builder into a real interactive shell where they run NORMAL `claude`.**

### 1. ttyd — a real browser-backed PTY on the box

`ttyd` (a lightweight web-terminal daemon) binds to `127.0.0.1:7681`, basic-auth protected with a per-box generated password, and drops the builder into an interactive login shell in `/workspace`. The builder runs ordinary interactive `claude` inside it.

This dissolves all three blockers because there is now a **real human at a real browser-backed PTY**. So `/login` (the OAuth flow opens in the builder's own browser tab), workspace-trust acceptance, **and** Trusted-Devices enrollment all just work — the exact interactive steps that are impossible headlessly.

### 2. Exposure — an outbound-only Cloudflare Tunnel, $0 added cost

A `cloudflared` Cloudflare Tunnel routes the builder's browser to the local ttyd. The box opens **no inbound port** — preserving the firewall posture that made `claude rc`'s outbound websocket attractive in the first place, but this one actually works. Two modes:

- **(a) Quick tunnel (default).** A tokenless tunnel at a random `https://<id>.trycloudflare.com` that needs **zero operator secrets**.
- **(b) Named tunnel (production upgrade).** A stable, branded hostname on `*.dev.example.com` when the operator configures a connector token — the documented production upgrade.

Cloudflare Tunnel is free (Zero Trust free tier, 50 users) — **$0 added cost**.

### 3. Delivery — reuse the existing trust-boundary-safe plumbing

The box reports its current terminal URL + credential UP to the GDS (`POST /api/gds/box/terminal`, authenticated as the builder via the on-box GDS token); the builder reads them from the browser (`GET /api/gds/box/terminal`, own-resource only, `requireBuilder`). This is the same shape as the migration 070 / [#701](https://example.com/builders#/task/701) pairing path, renamed from the old `/box/pairing(-link)`. New DB columns `terminal_url` / `terminal_credential` / `terminal_at` (migration 073); the old `remote_pairing_*` columns are **deprecated in place**.

### 4. Security model

- **Localhost binding.** ttyd binds to `127.0.0.1` — only the tunnel reaches it.
- **Basic auth.** HTTP basic auth with a per-box random password, stored mode-600 at `/etc/otb/terminal-credential` and persisted in the box snapshot across park/wake.
- **Secret containment.** The credential is returned ONLY to the box's own builder via `GET /box/terminal`; it never appears on any public surface or in `box_events`.
- **Revocation.** Rides the existing rank/status gate + box reconcile: a demoted/deactivated builder loses source access and the box is deprovisioned ([ADR 0031](<redacted>.md) §9.2).
- **Defense in depth.** An unguessable tunnel URL **and** basic auth, both over HTTPS.

## Consequences

**Good:**
- Works on any browser, including a literal Chromebook.
- No new operator secret in the default (quick-tunnel) path.
- No inbound ports — the box's egress-restricted firewall posture is preserved.
- Reuses the existing GDS plumbing (intent queue + report-up/read-down), no new subsystem.
- The builder gets the full real Claude Code TUI; `claude` auth/enrollment is a normal browser click rather than an impossible headless step.

**Trade-offs / honest limits:**
- **Quick-tunnel URLs are random and change on each `cloudflared` restart.** Handled — the box re-reports the URL each boot, the same ephemeral-URL-per-boot shape the old claude-rc reporter used.
- **`trycloudflare.com` is positioned for testing, not production SLA** — hence the named-tunnel upgrade for scale.
- **The per-box basic-auth password is long-lived** (until box rebuild) rather than single-use.
- **ttyd adds a tiny always-on service** on the box.

**Files:**
- Added: `infra/box-terminal.service` (ttyd unit), `infra/cloudflared.service` + `infra/cloudflared-run.sh` (tunnel, both modes), `infra/box-report-terminal.sh` (reporter), cloud-init install + wiring, migration 073, `src/bongos/boxes.js` `setTerminalAccess`, `src/bongos/routes/box.js` `GET/POST /box/terminal`.
- Deleted: `infra/claude-rc.service`, `infra/get-pairing-link.sh`, `infra/box-report-pairing.sh`.

**Follow-up:**
- **Named-tunnel automation — DONE ([#771](https://example.com/builders#/task/771)).** The control plane creates the per-builder named tunnel + proxied DNS CNAME (`term-<login>.example.com → <id>.cfargotunnel.com`) via the Cloudflare API token and bakes `BOX_TUNNEL_TOKEN` + `BOX_TERMINAL_HOSTNAME` into the box's `/etc/otb/box.env` on `provision`, tearing both down on `deprovision`. OPT-IN (`BOX_NAMED_TUNNEL=1`, default OFF → quick tunnel). Client: `src/bongos/cf-tunnel.js` (mirrors `do-api.js` — injectable fetch, dry-run default, **forces IPv4** since the CF token is IP-locked); orchestration in `scripts/gds/box.js`. See the recipe's "Named-tunnel automation" section.
- **Hardware-verified live ([#771](https://example.com/builders#/task/771)).** Provisioned a real box: tunnel create + ingress + CNAME + token-bake + teardown all confirmed against the live Cloudflare account; `https://term-example-owner.example.com` served ttyd through the tunnel (401 without creds, 200 with). The walk surfaced three fixes now landed: **(a)** IPv4-pinning in `cf-tunnel.js`; **(b)** the apex-not-`dev.*` hostname default — free Universal SSL covers `*.example.com` (one label) but not a two-label `dev.*` host, which fails TLS at the edge; **(c)** masking the Ubuntu `ttyd` apt package's own auto-started, **credential-less** `ttyd.service` (it grabbed port 7681 → our unit crash-looped *and* an auth-less terminal would have been exposed through the tunnel).
- **⚠ OPEN — browser-only bootstrap gap.** The terminal units live in the repo, so they only start after `box-source-fetch` clones, which needs the builder's GDS token on the box. A pure browser-only builder has no first-boot way to place that token → terminal never comes up for them (works once a token is seeded via SSH/operator). Fix: bring ttyd up at first boot independent of the clone (cloud-init writes the unit inline). Tracked as a follow-up.

---

## Spike findings (2026-06-28, task 852)

**The spike question:** *"the browser-terminal can't run interactive `claude` because Ink (Claude Code's TUI) needs a raw-mode TTY that ttyd's pipe can't provide."*

**Verdict: the premise is false. ttyd is NOT a pipe — it is a real PTY, and interactive `claude` (the Ink TUI, including raw mode) runs in it. This is the path we shipped and run in production today.** The "can't run interactive claude" symptoms that motivated this spike were real, but they were misdiagnosed: every one of them traced to something *other* than raw-mode capability, and each already has a landed fix. Below is the root-cause walk so this doesn't get re-investigated.

### Root cause — why "Ink needs raw-mode, ttyd can't provide it" is wrong

`ttyd` does not pipe stdio. For each browser connection it allocates a **real kernel pseudo-terminal** via `forkpty()` and runs the login shell as the PTY's session leader. A kernel PTY is exactly the device on which `termios` raw mode (`cfmakeraw` / `ECHO`/`ICANON` cleared) is defined — it is the *same* mechanism a local `xterm` or `ssh` session uses. The browser side (xterm.js over a websocket) is the *display*; the program on the box still talks to a genuine `/dev/pts/N`. So:

- `isatty(0/1) === true` inside the ttyd shell, and a program that calls `tcsetattr` to enter raw mode succeeds.
- Ink (which puts the terminal in raw mode for keypress-by-keypress input) therefore works — there is nothing about ttyd's transport that prevents it.

A genuine pipe (`cmd | claude`, or a `systemd` service with no controlling terminal) is the case where raw mode fails — `ENOTTY`, no `tcsetattr`. **That is the headless `claude rc` case ADR 0038 originally killed, not the ttyd case.** The spike title conflated the two: the *headless service* had no PTY; the *ttyd terminal a human sits at* has a full one. ADR 0040 already recorded the live confirmation that plain interactive `claude` runs in the ttyd terminal on the prod box.

### What actually broke "interactive claude in the browser terminal" — and the real fixes (all landed)

The symptoms people read as "the TUI won't run / freezes / refuses to start" were these, none of them raw-mode:

1. **`claude` refused to start as root (looked like "TUI won't launch").** The box's `defaultMode=bypassPermissions` (task 1251) makes Claude Code refuse to run as root unless `IS_SANDBOX=1`. The droplet *is* an isolated sandbox. **Fix (task 1314):** `Environment=IS_SANDBOX=1` pinned for the whole ttyd process tree in `infra/box-terminal.service`.
2. **The TUI froze mid-session (looked like "raw-mode input is dead").** Claude Code's own startup `git` (and any git a hook spawns) hits the token-less `https://github.com` origin of the rank-gated `/workspace` clone, and `git` opens `/dev/tty` for a `Username for 'https://github.com':` prompt *even with stdin redirected* — grabbing the ttyd PTY and hanging the Ink UI until killed. **Fix (task 854):** `Environment=GIT_TERMINAL_PROMPT=0` for the ttyd tree, so the remote-touching git fails fast instead of prompting (credentialed paths — `box-source-fetch`, ship — are unaffected).
3. **`/remote-control` (the next step after a working TUI) reported "Workspace not trusted."** This is the *standalone* `claude rc` shell command's trust mis-check ([anthropics/claude-code#35817](https://github.com/anthropics/claude-code/issues/35817)), not a ttyd or raw-mode problem. **Fix (ADR 0040):** start Remote Control with the in-session **`/remote-control` slash command** from inside an already-trusted `claude`, never the standalone `claude rc`.
4. **Session died when the tab closed (looked like an unstable terminal).** ttyd SIGHUPs its child on disconnect, killing a bare login shell + its `claude`. **Fix (task 893):** the launcher wraps the shell in a `tmux new-session -A` "otb" session, so a disconnect only detaches the client; the running `claude` survives on the box and the next connect reattaches.

### What was tried / ruled out

- **Ruled out: "ttyd transport can't carry raw mode."** Contradicted by the PTY mechanism above and by the live prod runs recorded in ADR 0040 and codified in `infra/box-terminal.service` (which the box has run in production through park/wake cycles). No raw-mode-specific failure was ever reproduced once the four issues above were fixed.
- **Ruled out: switching terminal daemons (gotty / wetty / xterm.js-over-a-different-ws).** They all use the same `forkpty()` PTY model; swapping would not change raw-mode behaviour and would throw away the credential-race / tmux-persistence / first-boot hardening already baked into the ttyd unit. No reason to migrate.
- **Confirmed working path:** ttyd → real PTY → `tmux` "otb" → `claude` (auto-launched by `otb-box-launch`) → interactive Ink TUI → `/remote-control` to hand off to the Claude web/mobile app (ADR 0040). This is the shipped browser-only on-ramp.

### Recommended next step

**No infra change. Accept and document that interactive `claude` works in the ttyd terminal — the "raw-mode" framing of task 852 is closed as a misdiagnosis.** The four real issues are already fixed in `infra/box-terminal.service` and ADR 0040; this section is the durable record so the false "Ink needs a raw-mode TTY ttyd can't provide" hypothesis is not re-opened. The only genuinely open terminal item remains the **browser-only bootstrap gap** noted just above (ttyd coming up before the GDS token is on the box), which is independent of raw mode and tracked separately.
