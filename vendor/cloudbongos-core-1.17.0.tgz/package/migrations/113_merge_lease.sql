-- Migration 113 — server-side merge lease (task 585 / idea 124).
--
-- A TTL'd advisory lease keyed on the merge target ("main"), so builders shipping from DIFFERENT
-- physical machines serialize their main-mutating merges. merge-lock.js handles the intra-machine
-- (single-checkout) case with a filesystem lock; this is the cross-machine counterpart, handed out
-- by the GDS API (src/bongos/db.js acquireMergeLease/releaseMergeLease). A dead holder's lease is
-- reclaimed automatically once expires_at passes — no reaper needed. Single-row-per-key table.

CREATE TABLE IF NOT EXISTS merge_lease (
  key         text PRIMARY KEY,
  holder      text        NOT NULL,
  acquired_at timestamptz NOT NULL DEFAULT now(),
  expires_at  timestamptz NOT NULL
);

INSERT INTO schema_migrations (version) VALUES ('113_merge_lease') ON CONFLICT DO NOTHING;
