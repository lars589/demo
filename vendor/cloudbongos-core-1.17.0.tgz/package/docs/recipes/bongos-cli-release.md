# Releasing the standalone `bongos` CLI

How the compiled `bongos` binaries get built, published, and installed — the
"no Node, no repo" on-ramp (task [#1248](https://example.com/builders#/task/1248), V4.R81).
Mirrors the Dev Box app release flow ([`devbox-app-release.md`](devbox-app-release.md)):
**CI builds, the operator publishes to a public releases repo, the server serves
branded redirects.** There is no cross-repo write token in CI — publishing is a
deliberate operator step.

## The moving parts

| Piece | Where | Role |
|---|---|---|
| Build wrapper | [`scripts/gds/build-bongos.js`](../../scripts/gds/build-bongos.js) | `bun build --compile` → per-platform binaries in `dist/` |
| CI | [`.github/workflows/build-bongos-cli.yml`](../../.github/workflows/build-bongos-cli.yml) | runs the wrapper, uploads `bongos-cli-binaries` artifacts (no publish) |
| Release pointer | [`config/bongos-cli.json`](../../config/bongos-cli.json) | `releases_repo` + `version` + per-target asset filenames |
| Redirects | [`src/bongos-downloads.js`](../../src/bongos-downloads.js) → `/downloads/bongos/*` in [`serve-internal.js`](../../src/bongos/serve-internal.js) | `/downloads/bongos/<target>` 302s to the release asset; `/version` + `/latest.json` for update-checks |
| Installer | [`infra/bongos-install.sh`](../../infra/bongos-install.sh) + [`.ps1`](../../infra/bongos-install.ps1) | served (origin-pinned) at `/downloads/bongos/install.sh` / `.ps1` |
| Package managers | [`packaging/homebrew/bongos.rb`](../../packaging/homebrew/bongos.rb), [`packaging/scoop/bongos.json`](../../packaging/scoop/bongos.json) | brew/scoop templates (fill sha256 at release) |

## What the user runs

```sh
# macOS / Linux — no Node required:
curl -fsSL https://example.com/downloads/bongos/install.sh | sh
# Windows (PowerShell):
irm https://example.com/downloads/bongos/install.ps1 | iex
# or, once the tap/bucket is published:
brew install example-owner/bongos/bongos          # macOS/Linux
scoop bucket add bongos https://github.com/example-owner/scoop-bongos; scoop install bongos
```

Then: `bongos login <instance-url>` → `bongos code` / `bongos shell` onto a dev box.

## One-time owner setup (tracked as the open blocker on [#1248](https://example.com/builders#/task/1248))

1. **Create a PUBLIC releases repo** — `example-owner/example-bongos` (matches `config/bongos-cli.json`'s `releases_repo`). Public so GitHub's release CDN serves the downloads at $0; it holds ONLY the binaries, never source.
2. *(optional, for brew/scoop)* create the tap repo `example-owner/homebrew-bongos` and/or the bucket `lars689/scoop-bongos`.
3. *(optional)* point `get.bongos.dev` at the instance with a DNS CNAME → `example.com`, so the branded `curl -fsSL https://get.bongos.dev | sh` works (it just proxies `/downloads/bongos/install.sh`).

## Cutting a release

1. **Bump** `config/bongos-cli.json`: `version` + every `assets.*` filename to the new version. (Claim a task; this rides the normal ship flow.)
2. **Push** → `build-bongos-cli.yml` runs and produces the `bongos-cli-binaries` artifact. Wait for green.
3. **Download** the artifacts:
   ```sh
   gh run download -R example-owner/example --name bongos-cli-binaries --dir dist
   ```
4. **Publish** them as a `v<version>` release on the public repo:
   ```sh
   gh release create v0.1.0 -R example-owner/example-bongos --title "bongos v0.1.0" --notes "Standalone bongos CLI" dist/bongos-*
   ```
   The tag and asset filenames MUST match `config/bongos-cli.json` exactly — the redirect is `releases/download/v<version>/<asset>`; a renamed asset 404s.
5. *(package managers)* compute `shasum -a 256 dist/bongos-*`, fill the `sha256`/`hash` fields in `packaging/homebrew/bongos.rb` + `packaging/scoop/bongos.json`, and copy them to the tap/bucket repos.
6. **Ship** the `config/bongos-cli.json` bump. The `/downloads/bongos/*` redirects follow within a minute of deploy.

Verify: `curl -fsSL https://example.com/downloads/bongos/version` shows the new version, and `curl -fsSL .../install.sh | sh` installs a working binary.

## The binary architecture (why some verbs aren't in it)

`bin/bongos.js` is one dispatcher with two runtimes ([task 1248](https://example.com/builders#/task/1248)):

- **repo / `npm i -g`** → runs under `node`; spawns each sibling `scripts/gds/*.js` (unchanged).
- **compiled binary** → `process.execPath` is the `bongos` binary (no `node`, no scripts on disk), so it dispatches the **bundled on-ramp verbs in-process**: `login`/`setup`, `reauth`, `box`, `shell`, `code`, `init`. The heavy work verbs (`ship`/`claim`/`start`/`status`/`recall`/`cost`/`release`/`module`/`package-core`) and `doctor` are **not** bundled — they need a full repo + git to run, and pulling their dependency trees in would bloat the binary. Run those on a dev box (`bongos code`/`shell`) or in a clone (where `npm i -g` gives the full CLI). A bare-binary user who invokes one gets a clear "get onto a real environment first" message.

Follow-ups (not blocking the first release): SHA-pin `oven-sh/setup-bun`, code-sign the mac/win binaries, and expand the bundled verb set if a self-host workflow needs more offline.
