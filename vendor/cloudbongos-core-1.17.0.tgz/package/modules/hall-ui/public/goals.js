// goals.js — the "Goals Thou Pursuest" hall section (BV1.R80; was BV1.R78/R79).
//
// SIMPLIFIED main-hall view: shows ONLY the goals the builder has JOINED, at a
// glance (title + status + progress). Browsing, joining, and leaving goals — and
// reading a goal's criteria — moved to the Work Board (/work), where goals sit
// under their version (ADR 0086 hierarchy: Version -> Goals -> Criteria -> Tasks).
//
// Reads GET /goals (list) + GET /goals/:id (membership + criteria counts). Registers
// into the window.OTB hall-widget registry (dom-utils.js) like the core set. Lives in
// the hall's own served dir, so it serves on both the apex and the builders subdomain.
(function () {
  'use strict';
  if (!window.OTB || typeof window.OTB.contributeHallWidget !== 'function') return;
  const { escapeHtml } = window.OTB;
  const API = '/api/bongos';
  // The generated typed client (task 1996 / R09), served as window.BongosClient by
  // /lib/bongos-client.js (injected into every hall page's <head>). baseUrl:'' passes
  // the full same-origin paths this file already builds through unchanged; result-mode
  // ({ status, ok, data }) preserves the status-inspecting control flow below 1:1.
  const api = window.BongosClient.createClient({ baseUrl: '', credentials: 'same-origin', throwOnError: false });

  async function getJSON(path, { softAuth = false } = {}) {
    const res = await api.request('GET', path);
    if (res.status === 401) {
      if (softAuth) { const e = new Error('auth-needed'); e.code = 'auth-needed'; throw e; }
      window.location.assign(`${API}/auth/web/start`);
      throw new Error('redirecting to auth');
    }
    if (!res.ok) throw new Error(`${path} → ${res.status}`);
    return res.data;
  }

  let host = null;
  let myId = null;
  const sameId = (a, b) => a != null && b != null && String(a) === String(b);

  // Small progress ring: satisfied / total criteria.
  function ring(satisfied, total, achieved) {
    const pct = total > 0 ? satisfied / total : (achieved ? 1 : 0);
    const r = 16;
    const circ = 2 * Math.PI * r;
    const dash = (pct * circ).toFixed(1);
    const gap = (circ - pct * circ).toFixed(1);
    const stroke = achieved ? 'var(--accent-deep)' : 'var(--accent)';
    return `<svg class="goal-ring" width="42" height="42" viewBox="0 0 42 42" role="img" aria-label="${satisfied} of ${total} criteria satisfied">
        <circle cx="21" cy="21" r="${r}" fill="none" stroke="var(--rule-soft)" stroke-width="4"></circle>
        <circle cx="21" cy="21" r="${r}" fill="none" stroke="${stroke}" stroke-width="4" stroke-linecap="round" stroke-dasharray="${dash} ${gap}" transform="rotate(-90 21 21)"></circle>
        <text x="21" y="25" text-anchor="middle" class="goal-ring__label">${satisfied}/${total}</text>
      </svg>`;
  }

  function statusBadge(status) {
    const cls = status === 'achieved' ? 'goal-badge--achieved'
      : (status === 'archived' ? 'goal-badge--archived' : 'goal-badge--open');
    return `<span class="goal-badge ${cls}">${escapeHtml(status)}</span>`;
  }

  function row(detail) {
    const g = detail.goal;
    const crit = Array.isArray(detail.criteria) ? detail.criteria : [];
    const sat = crit.filter((c) => c.satisfied).length;
    const achieved = g.status === 'achieved';
    // Whole row links to the goal's detail (hash-routed on the Goals page — its
    // boot() runs route() on load, so a direct #/goal/N opens the detail). The
    // <a> carries the row's flex so the entire row is the click target (task 1751).
    const href = `/goals#/goal/${encodeURIComponent(g.id)}`;
    return `<li class="goal-mine">
        <a class="goal-mine__link" href="${href}" title="Open ${escapeHtml(g.title || 'goal')}"
           style="flex:1;display:flex;align-items:center;gap:12px;min-width:0;color:inherit;text-decoration:none;">
          <span class="goal-mine__ring">${ring(sat, crit.length, achieved)}</span>
          <span class="goal-mine__title">${escapeHtml(g.title || 'Untitled goal')}</span>
          <span class="goal-mine__meta"><span class="goal-mine__ver">${escapeHtml(g.version_id || '')}</span>${statusBadge(g.status)}</span>
        </a>
      </li>`;
  }

  function render(joined) {
    const body = host.querySelector('#goals-body');
    if (!joined.length) {
      body.innerHTML = '<p class="goal-empty">You haven’t joined any goals yet. <a href="/goals">Browse goals →</a></p>';
      return;
    }
    body.innerHTML = `<ul class="goal-mine-list">${joined.map(row).join('')}</ul>` +
      '<p class="goal-mine__foot card-foot"><a href="/goals">All goals →</a></p>';
  }

  const SKELETON =
    '<h2 id="goals-h" class="scroll__h">Goals</h2>' +
    '<p class="scroll__lede">The shared goals you’ve joined. Browse, join, and leave goals — and read their criteria — on the <a href="/goals">Goals page</a>.</p>' +
    '<div id="goals-body"><div class="profile__placeholder">Loading your goals…</div></div>';

  async function load() {
    if (!host) return;
    try {
      if (myId == null) {
        const me = await getJSON(`${API}/me`, { softAuth: true }).catch(() => null);
        myId = me && me.builder ? me.builder.id : null;
      }
      const gres = await getJSON(`${API}/goals`);
      const candidates = (gres.goals || []).filter((g) => g.status !== 'archived');
      const details = (await Promise.all(candidates.map((g) =>
        getJSON(`${API}/goals/${encodeURIComponent(g.id)}`).catch(() => null)))).filter(Boolean);
      const joined = details.filter((d) => (d.members || []).some((m) => sameId(m.builder_id, myId)));
      render(joined);
    } catch (err) {
      const body = host.querySelector('#goals-body');
      if (body) body.innerHTML = '<p class="goal-empty">Goals couldn’t be loaded just now. Refresh to try again.</p>';
      console.error('[hall] goals load failed', err);
    }
  }

  function mount(hostEl) {
    host = hostEl;
    host.innerHTML = SKELETON;
    load();
  }

  window.OTB.contributeHallWidget({ id: 'goals-scroll', label: 'Goals', order: 25, mount, labelledby: 'goals-h', view: 'home', zone: 'home-band' });
})();
