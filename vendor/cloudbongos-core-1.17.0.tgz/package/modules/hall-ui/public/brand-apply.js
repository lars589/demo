// brand-apply.js — apply the instance branding pack to the hall's static markup
// (R56 task 1195, ADR 0062 §3). The pack is injected synchronously as
// window.__BRANDING__ by the server (src/bongos/serve-internal.js); this fills the
// markup that can't read it inline.
//
// R56 handles the configurable CURRENCY LABEL: any element carrying
// `data-currency-label` has its text replaced with branding.currency.label.
//   <span data-currency-label>drachmae</span>        → the label, lowercase
//   <span data-currency-label="caps">Drachmae</span> → the label, Capitalized
// For a label embedded in a phrase (e.g. an <option>), use a template carrying
// {label} (lowercase) / {Label} (Capitalized) placeholders:
//   <option data-currency-tmpl="highest {label}">highest drachmae</option>
// The element's existing text is the no-JS / pre-load fallback. For OTB the
// configured label IS "drachmae", so nothing visibly changes; a differently
// branded instance sees its own unit. R57 (task 1196) extends window.__BRANDING__
// to the full pack and this file grows to apply identity/theme/copy too.
(function () {
  'use strict';
  var brand = (typeof window !== 'undefined' && window.__BRANDING__) || null;

  function capitalize(s) {
    return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
  }

  function applyCurrencyLabels(root) {
    if (!brand || !brand.currency || !brand.currency.label) return;
    var label = brand.currency.label;
    var Label = capitalize(label);
    var scope = root || document;
    var nodes = scope.querySelectorAll('[data-currency-label]');
    for (var i = 0; i < nodes.length; i++) {
      nodes[i].textContent = nodes[i].getAttribute('data-currency-label') === 'caps' ? Label : label;
    }
    var tmpls = scope.querySelectorAll('[data-currency-tmpl]');
    for (var j = 0; j < tmpls.length; j++) {
      tmpls[j].textContent = tmpls[j].getAttribute('data-currency-tmpl')
        .replace(/\{label\}/g, label).replace(/\{Label\}/g, Label);
    }
  }

  // BV1.R75 (ADR 0062 §4): drive the hall index page's chrome — <title>, <h1>, and
  // meta description — from the branding pack so the reskin reaches the browser tab,
  // not just the page body. copy.hallName is the hall's name ("Builders' Hall");
  // identity.productName / worldName is the instance ("Off the Boats" / "Amazonprimea").
  // The static markup is the no-JS / pre-load fallback. SCOPED to the hall index via
  // the #hall-h1 marker: the other hall pages (sessions/watch/work) carry their own
  // page-specific titles + headings and must keep them — gating on #hall-h1 leaves
  // them untouched. Re-skinning those pages' chrome is its own (future) carve.
  function applyPageChrome() {
    if (!brand) return;
    var h1 = document.getElementById('hall-h1');
    if (!h1) return; // not the hall index — leave this page's chrome alone
    var hallName = (brand.copy && brand.copy.hallName) || '';
    var product = (brand.identity && (brand.identity.productName || brand.identity.worldName)) || '';
    if (hallName) {
      // Tab title: "<Hall> — <Product>" when both are known, else whichever exists.
      document.title = product ? hallName + ' — ' + product : hallName;
      h1.textContent = hallName;
    }
    if (product) {
      var desc = document.querySelector('meta[name="description"]');
      if (desc) {
        desc.setAttribute('content',
          'The builder hub for ' + product + '. Standing, achievements, and work waiting to be claimed.');
      }
    }
  }

  // Expose a tiny accessor so JS-rendered strings can read the label without
  // re-reading window.__BRANDING__ everywhere (and so a future test can stub it).
  function currencyLabel(opts) {
    var label = (brand && brand.currency && brand.currency.label) || 'credits';
    return opts && opts.caps ? capitalize(label) : label;
  }

  // task 1957 — a task's drachmae is an ESTIMATE (credits_reward, assigned at
  // creation) until the task SETTLES. Credits only land at 'confirmed' and
  // persist through 'shipped'; from that point the real payout is credits_awarded
  // (the ledger sum the task API surfaces). These helpers centralize the
  // "estimate vs actual" decision so every task surface renders it identically:
  // unsettled → the estimate with a "<Currency> Est." label; settled → the actual
  // ledger payout with a plain "<Currency>" label.
  function taskSettled(task) {
    var s = task && task.status;
    return s === 'confirmed' || s === 'shipped';
  }
  function taskCreditValue(task) {
    if (!task) return null;
    if (taskSettled(task)) {
      var awarded = Number(task.credits_awarded);
      // Settled with a real ledger payout → show it. If a settled task has no
      // ledger record (0 — legacy pre-ledger tasks, or reward-exempt), fall back
      // to the estimate rather than showing a misleading "0".
      if (isFinite(awarded) && awarded > 0) return awarded;
    }
    return task.credits_reward;
  }
  function taskCreditLabel(task, opts) {
    var base = currencyLabel(opts);
    return taskSettled(task) ? base : base + ' Est.';
  }

  window.OTBBranding = {
    currencyLabel: currencyLabel,
    taskSettled: taskSettled,
    taskCreditValue: taskCreditValue,
    taskCreditLabel: taskCreditLabel,
    applyCurrencyLabels: applyCurrencyLabels,
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { applyCurrencyLabels(document); applyPageChrome(); });
  } else {
    applyCurrencyLabels(document);
    applyPageChrome();
  }
})();
