# ADR 0102 — Finish bounding the kernel: LLM-cost as kernel-adjacent infra, identity/auth carve, flip Check 12 to ENFORCING

**Status:** Accepted (2026-07-02) · **Supersedes the WARN-mode deferral in** [ADR 0091](<redacted>.md) §1,§3 / [ADR 0093](<redacted>.md)

## Context

ADR 0091 §1 defined the kernel boundary — every file in `fitness.js` `KERNEL_FILES` must import only the kernel + grandfathered infra. Its enforcer, fitness **Check 12 ("kernel imports no domain")**, shipped as a **WARN-mode ratchet**: it *reported* the tracked kernel→domain leaks but `hardFail: false`, "flips to a red build at zero." It never reached zero, so the boundary stayed advisory. At the start of this work there were **7 tracked leaks**:

- `src/module-api.js` (the doorway) → `./gds/db` ×4 — Gemini-key storage (×3) + `builderRollingAvgGrade` (×1)
- `src/module-api.js` → `./gds/llm-cache`, `./gds/llm-pricing` (×2)
- `src/bongos/auth.js` → `./db` (×1)

The 2020-era framing (ADR 0093) parked `llm-cache`/`llm-pricing` "until an llm-infra module exists." Revisiting that: building such a module is a needless seam.

## Decision

**Clear all 7 leaks and flip Check 12 to a hard gate** (`hardFail` when findings > 0), so any future kernel→domain import reds the build.

1. **LLM-cost is kernel-adjacent infra, not a domain module.** `llm-cache.js` (a best-effort, dependency-injected content-addressed cache) and `llm-pricing.js` (a pure token→USD pricing table) carry no domain logic and are consumed by core, the grading module, and the CLI cost tooling *alike* — the same cross-cutting category as the pg pool and `path-match.js`, which are already in `KERNEL_IMPORT_ALLOWLIST`. Add both there. This clears leaks 5–6 with **no file moves and no new module core would have to depend on anyway.**

2. **Carve the identity/auth/admission cluster into `db-kernel.js`.** `upsertBuilder`, `seatFirstAdminIfUnclaimed`, `getBuilderByGithubId`, `hasInvitedAccessRequest`, `createSession`, `lookupSession`, `SESSION_TTL_MS`, and the `RANKS` vocabulary move from the `db.js` residue into the bounded kernel slice (they are kernel identity/authz primitives; `auth.js` — a `KERNEL_FILE` — resolves them there). `db.js` re-imports and re-exports every name, so its other importers and internal uses (e.g. `setBuilderRank`'s `RANKS.indexOf`) are byte-identical. Clears leak 7. (`RANKS` stays TWINNED with `modules/lifecycle/db.js` — the twin now pairs with db-kernel.)

3. **Push the doorway's remaining domain re-exports behind ports.** Gemini-key storage → the `art-pipeline` module + its port; `builderRollingAvgGrade` → the `grading` module + the `grade` port. The doorway stops importing `./gds/db`. Clears leaks 1–4.

4. **Flip `<redacted>`** to report `violations` + `hardFail: findings.length > 0`.

## Consequences

- The kernel↔domain boundary becomes a **hard, self-defending CI gate** — the ratchet can no longer silently rot (the same class of gap this session's audit found in the C9 proof and self-host hardware-verify).
- `db.js` shrinks toward being purely the social-twin + security-docs + credential residue; `db-kernel.js` is now the identity/auth/rank/audit/tx slice in full.
- Landed incrementally (llm-infra classification → auth carve → Gemini port → grade port → flip), each verified against `fitness.js` + the unit suite + a live vanilla `docker compose up` (auth still 401s cleanly). Test stubs that mocked `db.lookupSession` were repointed to `db-kernel`.

## Alternatives considered

- **Build an `llm-infra` module for cache+pricing** (the ADR 0093 deferral). Rejected: they are pure cross-cutting infra with no domain state; a module would exist only to be depended on by core anyway, adding a seam and a port for zero isolation benefit. Kernel-adjacent classification is the honest model.
- **Promote the Gemini/grade functions into the kernel.** Rejected: they are art-pipeline / grading *domain* reads over domain tables, not kernel primitives — they belong behind their modules' ports.
