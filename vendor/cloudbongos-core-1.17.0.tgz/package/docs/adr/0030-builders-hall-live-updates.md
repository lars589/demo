# ADR 0030 — Builders-hall live updates via Postgres NOTIFY → WebSocket

- **Status:** Accepted — **transport superseded by [ADR 0069](<redacted>.md)** (the hall now delivers nudges over SSE, not a Colyseus WebSocket room, so it works on a game-less Cloud Bongos boot; R55). The **change-signal layer below (§1 — `NOTIFY` + `src/bongos/live-channel.js`) is unchanged and still authoritative**; only the §2 delivery transport moved.
- **Date:** 2026-06-03
- **Deciders:** task [#569](https://example.com/builders#/task/569) (commissioned by Lars — "these checks aren't very live, need to refresh every time"); transport chosen by Lars (WebSocket)
- **Track:** `internal` (the builders hall)

## Context

The builders hall (`public-builders/`) fetched **every panel exactly once** at `DOMContentLoaded` via `loadAll()` and then never refreshed. Onboarding checklist, standing (drachmae/karma), claimable works, leaderboard, karma feed, bounty table — all frozen until the visitor manually reloaded. The only things that updated without a reload were the two buttons a builder clicks themselves (mark primer read, pick a craft).

The reported symptom: a builder runs `/builder-ship` in the terminal, the "Ship thy first work" onboarding step clears server-side, but the open hall tab keeps showing the stale checklist. The underlying gap is broader than onboarding — the page had **no live-update mechanism at all**.

A large share of the staleness comes from changes the *browser's own actions never caused*: background routines (autonomous builders, the BFG), another builder climbing the leaderboard, and **direct `psql` writes** (which the methodology explicitly treats as first-class work). Any fix that only re-broadcasts from API route handlers would miss all of those.

## Decision

A live-push channel in two layers — a transport-agnostic change-signal, and a WebSocket delivery path.

### 1. Change signal — Postgres `NOTIFY` from statement-level triggers (migration 066)

A single generic trigger function `gds_notify_live()` fires `pg_notify('gds_live', '{"table":…,"op":…}')`. One `AFTER INSERT OR UPDATE OR DELETE … FOR EACH STATEMENT` trigger is attached to each table that backs a live panel: `tasks`, `claims`, `builders`, `builder_onboarding_state`, `credit_log`, `karma_log`.

- **Trigger lives in the DB, below the application** → it catches *every* write path, including direct `psql`. This is the decisive property; it's why the signal is a DB trigger and not an app-layer emit.
- **Statement-level, not row-level** → the payload carries no row data (only table + op), so we don't need `OLD`/`NEW`, and a bulk write coalesces to one nudge instead of N. Negligible overhead on these low-volume internal tables.

The GDS process holds **one persistent `LISTEN` connection** (`src/bongos/live-channel.js`, a dedicated `pg.Client` — *not* a pooled checkout, since `LISTEN` must stay pinned to one connection) and fans each notification out to subscribers. It opens lazily on the first subscriber and closes when the last leaves.

### 2. Transport — a Colyseus WebSocket room, not SSE or a new HTTP route

Delivery to the browser rides the game's **existing Colyseus WebSocket server**. A broadcast-only room `builders_hall` (`src/rooms/BuildersHallRoom.js`, a sibling of `QueueRoom` with no state schema) subscribes to the `live-channel` relay in `onCreate` and `broadcast('nudge', {})` on each notification — an **opaque "something changed" signal**, not the `{table, op}` (see the security note below). The hall page joins via `client.joinOrCreate('builders_hall')` and, on each `nudge`, re-runs `loadAll()` **debounced (~700 ms)** so a burst coalesces into one refresh. The room is `autoDispose: true` — created on the first viewer, disposed (and the `LISTEN` connection dropped) when the last one leaves.

**Why WebSocket / Colyseus** (the chosen option):

- It **reuses infrastructure that already exists and is proven through the Caddy → Cloudflare proxy** — the game has run Colyseus WS in production since V1, so there's no new transport to validate against the edge. The hall is same-origin (`example.com`), so `wss://example.com` and the vendored `/vendor/colyseus.js` client are both already reachable.
- A `Room` is a natural fan-out primitive: `broadcast()` to all members is one call, and Colyseus owns the connection lifecycle.
- It keeps the hall's live path on the **same stack as the rest of the realtime system**, rather than introducing a second long-lived-connection style (SSE) alongside it.

**No row data crosses this channel** — and, after the hacker dispatch on [#569](https://example.com/builders#/task/569), not even the `{table, op}`: the relay passes `{table, op}` to the room internally, but the room broadcasts only an empty `{}` so an unauthenticated client can't read internal table names. The hall ignores the payload regardless (it refreshes on any nudge), so this costs nothing. The room is therefore left **unauthenticated**, matching the game rooms (`world`/`queue`); access control stays where the data actually is, on the authenticated per-panel endpoints the hall re-fetches. The only residual signal is *that* a write happened (a timing oracle) — no more than the public status dashboard already exposes.

### Resilience & client guards

- **Reconnect:** unlike `EventSource`, a Colyseus room doesn't auto-reconnect — so the client retries `joinOrCreate` on `onLeave`/error with a fixed 4 s backoff, and refreshes once on reconnect (it may have missed a nudge while offline).
- **No mid-interaction clobber:** the debounced refresh is deferred (and re-armed) while a user is focused on an input/textarea/select or the tab is hidden, so a nudge can't overwrite unsent input or re-render mid-interaction.
- **Backstop:** the hall also refreshes on tab `visibilitychange` (regaining focus), and re-opens a dropped room then — covering anything missed while the laptop slept.

## Alternatives considered

- **Server-Sent Events (`GET /api/gds/live`)** — initially built. SSE is arguably the textbook fit for a *receive-only* dashboard (no client lib, native auto-reconnect, plain HTTP GET). Rejected in favor of WebSocket to **reuse the game's existing, proxy-proven WS stack** rather than stand up and maintain a second long-lived-connection mechanism. The change-signal layer (NOTIFY + `live-channel.js`) is identical either way, so this was purely a delivery-path choice.
- **Per-table → per-panel routing** — mapping each changed table to a subset of panels instead of a full `loadAll()`. Rejected as fragile: a single task ship touches ~6 panels at once, so the mapping is large and easy to get wrong. A full reload is strictly correct (never misses a derived panel) and cheap (cached GETs, only when something actually changed).
- **Naive client polling** (`setInterval`) — simplest, but either wasteful (polls when nothing changed) or laggy (long interval), and still wouldn't feel live. The push model costs nothing when idle.

## Consequences

- The hall now feels live: finishing a step in the terminal reflects in the open tab within ~1 s, no manual reload.
- New realtime surface: a `builders_hall` Colyseus room + a persistent Postgres `LISTEN` connection (lazy — zero cost when the hall is empty). The hall page now loads `/vendor/colyseus.js`.
- **Deliberate omission:** `peer_votes` (the acclaim feed, which spans all builders and loads fire-and-forget) is *not* triggered — it's the least time-sensitive panel, and keeping it out avoids hall-wide refreshes on every cross-builder vote. Easy to add later.
- Not applied to the public status dashboard (`status.example.com`) — out of scope; that surface already has its own polling cadence.
- The unauthenticated room is acceptable only because the payload is non-sensitive `{table, op}`. If a future change ever puts row data on this channel, it must gain an `onAuth` cookie/session gate first.
