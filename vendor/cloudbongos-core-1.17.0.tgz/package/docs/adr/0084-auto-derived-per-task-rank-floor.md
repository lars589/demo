# 0084 — Auto-derived per-task rank floor (every task is rank-scoped; the claim gate bites)

- **Status:** Accepted
- **Date:** 2026-06-23
- **Deciders:** Lars (Archon), Claude

## Context

Builders must not be able to claim tasks above their rank, and every task should
carry a deliberate rank criterion (Lars's directive, 2026-06-23). The *mechanism*
for the gate already existed and was sound: `tasks.requires_rank` (V3.R82, migration
044; widened to include `thetes` in 068) plus a claim-time check in `db.claimTask` /
`claimTasksBatch` (`rankAllowsTask` → `INSUFFICIENT_RANK` 403) and a belt-and-braces
filter in `listClaimableTasks` that hides over-rank tasks from `/builder-start`.

But the gate never bit. Nothing ever *set* `requires_rank`: `POST /tasks` didn't
accept it, `createTask` didn't write it (so the column took its `NOT NULL DEFAULT
'xenos'`), `PATCH /tasks/:id` couldn't edit it, and the planning-session skill never
emitted it. Net effect: essentially every task sat at `requires_rank='xenos'` — the
floor — so any builder at `thetes` or above could claim anything. The column was
inert; the gate guarded nothing. The hall didn't even display a task's required rank.

## Decision

We will make a task's rank floor **auto-derived, always-set, overridable upward, and
visible**, and backfill the existing board.

- **Derive** the floor from what a task touches plus its sensitivity, reusing the
  *same* protected-path matcher the trust boundary uses
  (`permission-path-check.matchProtected`, ADR 0043).
  `deriveRequiredRank(touches, securitySensitive)`: `security_sensitive` OR any touch
  hitting a `PROTECTED_GLOB` ⇒ `metic`; everything else ⇒ `xenos`. One source of truth
  for "this is sensitive" — the rank/authz/ship-grade/deploy/migration core (exactly
  the paths a sub-Metic builder already cannot push to) floors at Metic; game / art /
  docs / UI work stays open. The rule **never auto-assigns `archon`** — "only the
  Archon may claim this" is a deliberate human statement, not something to infer.
- **Compose with an override** via `highestRank(floor, requested)`: the stored
  `requires_rank` is always `max(floor, requested)`. An explicit value (on create, or
  via `PATCH /tasks/:id`, Archon-only) can only **raise** the bar; a request below the
  derived floor is clamped up (fail-closed). Flipping `security_sensitive` on ratchets
  the floor up in the same atomic UPDATE; it never lowers a floor (an Archon can PATCH
  down to the derived floor explicitly if a task was over-gated).
- **Backfill** (migration 145): every non-terminal task whose `requires_rank` is still
  the `xenos` default rises to `metic` when it is `security_sensitive` or its `touches`
  overlap the protected set. The SQL conditions are generated faithfully from
  `PROTECTED_GLOBS` (all exact-file or dir-prefix, no wildcards), idempotent, raise-only.
- **Surface** the floor as a pill on the builders-hall task card when it is above
  `xenos`.

## Alternatives considered

- **Manual rank at scoping** (the planner picks per task; create requires it). Rejected
  as the *primary* mechanism: it is exactly what silently failed — an optional field
  nobody filled, so the whole board drifted to the floor. Discipline does not scale;
  structure does. (Manual override *upward* is kept, on top of the derived floor.)
- **Just raise the column default** (unset ⇒ gated higher). Rejected: crude — it would
  gate trivial game/art work behind Metic and empty the newcomer/general queue,
  inverting the intent. The sensitivity signal must come from the task, not a blanket
  default.
- **A second sensitivity list for ranks** (independent of the trust boundary). Rejected:
  two lists drift — the SEC [#863](https://example.com/builders#/task/863) failure mode. Reusing `matchProtected` means the claim
  floor and the git-push floor can never disagree.
- **Auto-assign `archon` to the most sensitive paths.** Rejected: an `archon` floor
  means only the owner can ever claim that task, which would starve the board; Metic is
  the right "trusted working rank" floor, and `archon` stays a deliberate manual override.

## Consequences

- Every task now carries a deliberate, enforced rank floor; the existing claim gate
  (`INSUFFICIENT_RANK`) and the `/builder-start` hide finally bite. The change is purely
  in *setting* `requires_rank` — the enforcement code is untouched, and its tests
  (`tests/rank_gate.mjs`) still pass, now extended with `deriveRequiredRank` /
  `highestRank` cases.
- The claim floor and the ADR 0043 git-push floor share one matcher, so a task a
  sub-Metic builder could not push is also one they cannot claim — coherent by
  construction.
- The migration-145 SQL is a *snapshot* of `PROTECTED_GLOBS`; if a wildcard glob is ever
  added, the historical snapshot will not change (new/edited tasks re-derive through the
  JS helper, which is authoritative). The generator asserts no-wildcard to keep the
  snapshot exact.
- An Archon can still gate a task to `archon` by hand (`PATCH requires_rank=archon`) when
  a task genuinely should be owner-only.
- This is a trust-boundary-adjacent change (it sets the per-task claim floor); it rides
  the gate-review hard floor (ADR 0043) and is Archon-authored. See
  [`docs/canonical-permissions.md`](../canonical-permissions.md) (the per-task floor
  section) for the mirror.
