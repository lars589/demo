-- 164_event_sound_prefs.sql — per-builder per-event sound variant selection (task 582).
--
-- Extends the mute-toggle system (migration 075, sound_prefs) to also support
-- variant picking: for each of 5 build events a builder can choose WHICH
-- world-themed sound variant plays (e.g. 'lyre-pluck' vs 'chime-soft' for the
-- user-input event). Schema: { "user-input": "lyre-pluck", ... } where values
-- are variant IDs defined in src/bongos/event-sound-prefs.js.
--
-- NULL/missing key = system default for that event. The two columns compose:
-- the mute-toggle in sound_prefs still wins over the variant — if a builder
-- mutes 'alert' and their user-input event resolves to a variant backed by
-- alert.wav, it will be silent.
--
-- Idempotent: safe to re-run.

ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS event_sound_prefs jsonb NOT NULL DEFAULT '{}'::jsonb;

INSERT INTO schema_migrations (version) VALUES ('164_event_sound_prefs')
  ON CONFLICT (version) DO NOTHING;
