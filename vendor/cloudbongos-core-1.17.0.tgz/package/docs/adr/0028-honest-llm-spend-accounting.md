# ADR 0028 — Honest LLM-spend accounting (grader envelope cost + session transcript pricing)

- **Status:** Accepted
- **Date:** 2026-05-30
- **Deciders:** spike [#483](https://example.com/builders#/task/483) (design), commissioned by spike [#482](https://example.com/builders#/task/482) audit ([docs/audits/<redacted>.md](../audits/<redacted>.md))
- **Supersedes the implicit "log cost manually" posture** that left `cost_log`'s `api` category at $0.60 across the whole project.

## Context

The [#482](https://example.com/builders#/task/482) audit established that the dominant real cost of the project — Claude API/token spend — is essentially uncaptured. `cost_log` has one writer (`db.logCost`) reached only by manual `POST /api/gds/cost` and the art-pipeline backfill. Two large, *automatic* sources of spend land nowhere:

1. **The per-ship grader panel** — 4 workers (Narc, Quality, Hacker, Efficiency), each an Opus/Sonnet `claude -p` subprocess, run on every confirm (149+ GDS-V3 ships).
2. **The interactive builder sessions** — the Opus 4.x 1M-context sessions builders actually work in.

The audit's F4 lesson: a capture that requires a manual step won't happen (17 consecutive $0 days proved it). Capture must be **automatic** and sit at a seam that always executes.

This ADR decides *how* spend is captured for each source. It is the design deliverable of spike [#483](https://example.com/builders#/task/483) and the blocking input for the two implementation tasks ([#486](https://example.com/builders#/task/486) grader; the session-capture task).

## Decision

Capture the two sources at **two different seams**, because their cost data lives in two different places. Do **not** force one mechanism to cover both.

### 1. Grader cost — read it from the subprocess envelope (client-side, exact)

`grader.runSubagent` spawns each worker as `claude -p --print --output-format json` ([src/bongos/grader.js](../../src/bongos/grader.js)). With `--output-format json`, the CLI returns a result envelope that includes **`total_cost_usd`** (and a `usage` block) — *verified* on a real call: `{type, …, total_cost_usd: 0.198, usage, modelUsage}`. The old `extractAssistantResult` parsed only `env.result` and **discarded the cost**.

> **Correction (made during [#486](https://example.com/builders#/task/486) implementation):** the panel does **not** run server-side. `gradeSubagent` is invoked **client-side in `scripts/gds/ship.js`** (and `conductor-dispatch.js`); the server's `/tasks/:id/grade` route only *validates/scores* the result ship.js POSTs. So there is no in-process DB handle at grade time — the cost is logged over HTTP, exactly like the session path. The substance below (exact envelope cost, no pricing table) is unchanged; only the seam moved from `db.logCost` to `POST /api/gds/cost`.

**Decision:** stop discarding it. `runSubagent` now attaches `cost_usd` (from `extractCostUsd(stdout)`); `runWorker` carries it onto each `WorkerResult`; `aggregatePanel`/`aggregateShots` sum it into **`panel_cost_usd`**. After the grade POST succeeds, `ship.js` POSTs one `cost_log` row:

```
POST /api/gds/cost {
  task_id,                          // the task being graded
  amount_usd: panel_cost_usd,       // Σ env.total_cost_usd across workers/shots
  category: 'api',
  source: 'grader',
  source_ref: `grade-${taskId}-${headSha}`,  // idempotent; a new commit = a new row
  // builder_id defaults to the authed shipper server-side
}
```

- **Exact, not estimated** — the CLI computes `total_cost_usd` itself, so no pricing table is needed on this path. This is why the grader path is decoupled from the pricing module below.
- **Idempotent** — `source='grader'` + `source_ref=grade-<task>-<shortSha>` rides the existing `ON CONFLICT (source, source_ref) DO NOTHING`. A re-ship at the **same** HEAD is a no-op; a re-grade after new commits is a distinct row (a real, countable event per ADR 0027's grade-attempt log).
- **Best-effort, never blocks the gate** — the POST runs after the grade is already recorded, checks `.ok`, and only logs a line on failure. A cost-logging failure can never fail or roll back a grade, and it runs on **both** pass and fail (the panel costs money either way).
- **Fallback:** if a future CLI omits `total_cost_usd`, `extractCostUsd` returns null → `panel_cost_usd` is 0 → no row written (graceful degrade). Pricing `env.usage` via the shared module is a possible later fallback; not needed while the envelope carries cost.

### 2. Session cost — price the transcript JSONL (client-side, table-priced)

The interactive session is not a `-p` subprocess, so there is no envelope. But Claude Code writes a per-session transcript at `~/.claude/projects/<encoded-cwd>/<session-id>.jsonl`, and **each assistant turn carries `message.usage`** (`input_tokens`, `output_tokens`, `cache_creation_input_tokens` with a `cache_creation.{ephemeral_5m,ephemeral_1h}` breakdown, `cache_read_input_tokens`) and `message.model`. *(Verified on this machine 2026-05-30: 6/23 lines carried usage; model `claude-opus-4-8`.)*

**Decision:** a client-side script `scripts/gds/session-cost.js` reads a transcript, sums usage per model, prices it via a shared `src/bongos/llm-pricing.js` table, and POSTs one row to `/api/gds/cost` (`category='api'`, `source='session'`, `source_ref=<session-id>`, builder defaults to the authed caller). It runs automatically via a **`SessionEnd` hook** (`.claude/settings.json`).

> **Correction (made during [#560](https://example.com/builders#/task/560) implementation):** the first draft said "wired into the `builder-exit` skill." That was wrong — `builder-exit` is Archon **offboarding** (deactivate a builder), not a per-session seam. The correct seam is the Claude Code **`SessionEnd`** hook, which fires *exactly once* when a session ends and receives `{ session_id, transcript_path, cwd, reason }` on stdin (confirmed against the hooks docs). `Stop` was rejected: it fires at the end of *every* turn (many times per session), so it would need an upsert to avoid undercounting — `SessionEnd` needs none (one POST at end, idempotent `DO NOTHING` on `session_id`). The hook pipes its stdin payload to `session-cost.js`, which is also runnable by hand (`--transcript`/`--session`, or newest-for-cwd) and supports `--dry-run`.

- **Table-priced** — the transcript has tokens, not dollars, so a small auditable `model → $/Mtok` table is required. One file, easy to update when prices change; a `decision`-worthy change gets its own task.
- **Idempotent on session-id** — re-running on the same transcript is a no-op (`ON CONFLICT`). A long session re-run after more turns would need a re-priced delta; v1 keeps it simple: one row per session, written once at exit. (A periodic delta-capture is a later refinement; see Consequences.)
- **`task_id` is null** — a session is not 1:1 with a task (it may span several or none). Session spend is attributed to the **builder**, not a task. Grader spend (path 1) is the task-attributed path. Together they give per-builder totals; only the grader path gives per-task.
- **Pricing model (per Mtok), v1 table** (Anthropic public list, editable):
  | family | input | output | cache-write 5m (1.25×) | cache-write 1h (2×) | cache-read (0.1×) |
  |---|---|---|---|---|---|
  | opus | $15 | $75 | $18.75 | $30 | $1.50 |
  | sonnet | $3 | $15 | $3.75 | $6 | $0.30 |
  | haiku | $0.80 | $4 | $1.00 | $1.60 | $0.08 |

  Family is matched by substring on `message.model` (`opus`/`sonnet`/`haiku`), mirroring `grader.js`'s existing family-token convention. Unknown model → priced at the opus rate (conservative over-estimate) **and** a warning, so an unpriced model is loud, not silently $0.

### 3. Shared pricing module

`src/bongos/llm-pricing.js` exports `priceUsage(model, usage) → usd` and the `PRICES` table. Owned by the session-capture task; imported by the session script and available to the grader as its envelope-absent fallback. Pure, unit-tested, no I/O.

## Source/category conventions (so the audit can reason about completeness)

| source | category | written by | builder_id | task_id |
|---|---|---|---|---|
| `grader` | `api` | `ship.js` → `POST /api/gds/cost` (path 1) | shipper | the graded task |
| `session` | `api` | `POST /api/gds/cost` (path 2) | authed builder | null |
| `art-cost-ledger` | `art`/`api` | backfill import | null (shared) | null |
| `manual` | any | `/builder-cost` | authed builder | optional |

`auditCostAttribution`'s completeness check (the [#485](https://example.com/builders#/task/485) task) keys off these: real `category='api'` spend from `source IN ('grader','session')` should be non-trivial relative to ship volume; if it's ~$0, that is the F1 finding re-detected.

## Capture boundary & non-double-counting ([#562](https://example.com/builders#/task/562), [#563](https://example.com/builders#/task/563))

What the paths read is **disjoint** — confirmed by inspecting the on-disk transcripts:

- **Path 2 (session)** prices the interactive session's transcript — the file the `SessionEnd` hook passes via `transcript_path` (only the interactive model's own turns: verified all `claude-opus-4-8`, **0 sidechain**).
- **Path 1 (grader)** takes its number from each worker's `claude -p` result **envelope** (`total_cost_usd`) — never from a transcript.
- **Path 3 (subagents, [#563](https://example.com/builders#/task/563))** prices this session's ad-hoc `Agent`/`Task` subagents, which persist at `<project-dir>/<session-id>/subagents/...` (a sibling subtree of the main transcript FILE), **skipping any grader-signature transcript** so the envelope-captured grader (path 1) is never re-priced.
- The grader workers DO persist their own transcripts (separate `claude-sonnet-4-6` files), but no path prices a grader transcript. So there is **no double count**.

> **INVARIANT (do not violate):** a grader `claude -p` transcript MUST NOT be priced by the session or subagent paths — its cost is already captured via the envelope (path 1). The grader CAN nest inside a `subagents/` dir (an autonomous-builder subagent that ran a ship), so exclusion is by the **grader-worker signature**, not by location. Both the session fallback and the subagent walk (`priceSubagents`) enforce this; the `SessionEnd` hook is also safe by construction. Any future "price all transcripts" idea must apply the same signature skip.

**Subagent capture ([#563](https://example.com/builders#/task/563)) — closed.** `Agent`/`Task`-tool subagents (e.g. a `claude-code-guide` lookup, an autonomous builder) write to `<session-id>/subagents/agent-*.jsonl`; `session-cost.js` now walks that subtree, prices each non-grader transcript via the same model table, and folds it into the one `source='session'` row (the description breaks out `main` vs `N subagent(s)`). Measured impact on a real session: the two ad-hoc subagents added **$5.45** that previously leaked. With this, the `honest-spend-accounting` criterion (proposal-146) is met for **main session + grader + ad-hoc subagents**. (Residual edge: a subagent killed before its transcript flushes, or one nested under a session that itself never fires `SessionEnd`, is still uncaptured — small, noted, not chased.)

## Consequences

- **Positive:** the `api` category stops being a rounding error; per-builder spend renders real numbers; the grader's own cost becomes visible (and gradeable for efficiency); the audit can detect *missing* spend, not just mis-attribution.
- **Cost:** a small pricing table to maintain (prices drift), and session-capture only fires if the `SessionEnd` hook runs (a session killed before clean exit is uncaptured). The grader path has neither weakness — it's exact and always runs on the ship path.
- **Deliberately deferred (later refinements, not blockers):**
  - **Conductor-dispatch grader spend.** `conductor-dispatch.js` also invokes `gradeSubagent` (mid-flight, advisory — no gate, no credits). Its workers now carry `cost_usd` (free, via the shared `runSubagent` change), but only `ship.js` aggregates+logs it. The dispatch path is lower-volume and not on the credit-bearing ship path, so capturing it is a fast-follow, not a [#486](https://example.com/builders#/task/486) blocker (panel-flagged nit on the [#486](https://example.com/builders#/task/486) re-grade; filed to idea_inbox).
  - Mid-session delta capture (today: one row at exit). A crashed session that never hits `builder-exit` is uncaptured; the Stop hook narrows this.
  - Cost calibration medians à la migration 015 (idea_inbox [#132](https://example.com/builders#/idea/132)) — needs this real data first.
  - Reconciling against the true Anthropic billing API — out of scope; the transcript + envelope are the cheapest honest proxy.

## Implementation tasks

- **[#486](https://example.com/builders#/task/486)** — grader envelope cost → `cost_log` (path 1). Decoupled (no pricing dep).
- **[#560](https://example.com/builders#/task/560)** — `llm-pricing.js` + `session-cost.js` + `SessionEnd`-hook wiring (path 2 + module 3). *(Task title says "builder-exit wiring" — superseded by the SessionEnd seam; see the path-2 correction above.)*
- **[#485](https://example.com/builders#/task/485)** — `auditCostAttribution` completeness check keyed off the source conventions above.
