# Recipe — stand up claudebongos.com + geminibongos.com (vanity doors → cloudbongos.com)

> Brings **claudebongos.com** and **geminibongos.com** live as public "vanity
> doors": each shows the exact Cloud Bongos landing **gate** (`brand/cloud-bongos/gate`),
> rebranded to **"Claude Bongos" / `> claude`** (resp. **"Gemini Bongos" / `> gemini`**)
> at runtime — the visitor still types `bongos`, and on enter the gate redirects
> to **cloudbongos.com**, landing straight on the orbs. Same task also **promotes
> the gate onto the cloudbongos.com apex** (it replaces the buddha placeholder,
> which is what makes the redirect land "on the orbs"). Task
> [#1746](https://example.com/builders#/task/1746).

## Architecture (what we're building)

One gate bundle, three domains, a runtime switch — **no forked copies**. `space.js`
reads `location.hostname`; a door rebrands the entry + redirects on enter, and the
default (cloudbongos.com) reveals the orbs in place. Any future change to the gate
shows up on all three automatically.

| Domain | Serves | On typing `bongos` + enter |
|---|---|---|
| **claudebongos.com** | the gate, rebranded "Claude Bongos" / `> claude` | `→ https://cloudbongos.com/?entered=1` (orbs) |
| **geminibongos.com** | the gate, rebranded "Gemini Bongos" / `> gemini` | `→ https://cloudbongos.com/?entered=1` (orbs) |
| **cloudbongos.com** | the gate, "Cloud Bongos" (**was** the buddha page) | reveals the orbs in place |

Hosting is the **cheapest possible**, same as the staging gate:

| Thing | Value |
|---|---|
| Served by | Caddy `file_server`, web root `/home/lars/example/brand/cloud-bongos` |
| The two doors | **pure static** — no app process, no port, no password |
| cloudbongos.com apex | static gate for `/` + gate assets; **still proxies** `/api`, `/healthz`, etc. to the platform app (`:3002`) so sign-in keeps working |
| TLS | **one new Cloudflare Origin Cert per new domain** — the cloudbongos cert's SANs do NOT cover claudebongos.com / geminibongos.com |
| Cost | **$0/mo** — same droplet, no new process/port |

Why static (not a reverse-proxy block): the gate is plain HTML/CSS/JS + PNGs.
There is nothing to run. The `?entered=1` query flag is how a door hands off — the
gate honors it (only on non-door hosts) to skip its own entry and open the orbs.

Everything in the repo (`space.js`, the `infra/Caddyfile` blocks, the gate art)
auto-deploys to the droplet checkout on merge. What is **NOT** automatic — and is
this recipe — is the per-domain **DNS + Origin Cert** and the **live Caddyfile
merge + reload**. Until those are done, the two domains show a TLS error (expected).

## Phase ① — DNS (Cloudflare, ~1 min per domain)

Both domains are already on Cloudflare. For **each** zone (claudebongos.com,
geminibongos.com):

1. Cloudflare → pick the zone → **DNS** → **Add record**.
2. Type **A**, Name **`@`**, IPv4 **`REDACTED_IP`**, Proxy status **Proxied**
   (orange cloud ON), TTL Auto. Save.
3. Cloudflare → **SSL/TLS** → **Overview** → set encryption mode to **Full (strict)**.

(Optional: add a **`www`** A record → same IP, proxied, if you want `www.` to work.
The Caddyfile blocks are apex-only today; add `www.claudebongos.com` to the site
line if you add the record.)

## Phase ② — Origin Certificate (own domain → own cert)

Each new domain needs its **own** Origin Cert. For **each** zone:

Cloudflare → **SSL/TLS → Origin Server → Create Certificate**:
- Hostnames: `claudebongos.com` **and** `*.claudebongos.com` (resp. the gemini pair)
- Let Cloudflare generate the key; **copy both** the certificate and the private key.

Install on the droplet (operator). Caddy runs as user `caddy` and **must be able to
READ the key** — match the existing `origin.key` ownership (`640 root:caddy`). A
root-only `600` key makes Caddy's reload fail (learned during the cloudbongos
bring-up). The `.crt` can be world-readable.

```bash
# claudebongos
sudo install -m 644 -g caddy /dev/stdin /etc/caddy/claudebongos-origin.crt   # paste cert, Ctrl-D
sudo install -m 640 -g caddy /dev/stdin /etc/caddy/claudebongos-origin.key   # paste key,  Ctrl-D
# geminibongos
sudo install -m 644 -g caddy /dev/stdin /etc/caddy/geminibongos-origin.crt   # paste cert, Ctrl-D
sudo install -m 640 -g caddy /dev/stdin /etc/caddy/geminibongos-origin.key   # paste key,  Ctrl-D
```

## Phase ③ — apply the Caddy blocks + reload

Three blocks ship in `infra/Caddyfile`: the two new **door** blocks
(`claudebongos.com`, `geminibongos.com`) and the **modified `cloudbongos.com`
apex** block (now serves the gate + proxies functional paths). The live
`/etc/caddy/Caddyfile` has drifted slightly from the repo copy, so **do not blindly
`cp` the whole file** — apply the two pieces by hand:

```bash
cd /home/lars/example
git pull   # or wait for the auto-deploy; the brand/ bundle + infra/Caddyfile land here

# 1. Append the two door blocks (idempotent: skip if already present).
grep -q '^claudebongos.com {' /etc/caddy/Caddyfile || \
  awk '/^# ── Claude Bongos \+ Gemini Bongos — vanity DOORS/{p=1} p' infra/Caddyfile \
    | sed '/^# ── Cloud Bongos — STAGING/,$d' >> /etc/caddy/Caddyfile
#   (or just open the file and paste the two blocks from infra/Caddyfile — the
#    awk above copies from the DOORS comment to end-of-file.)

# 2. Modify the LIVE cloudbongos.com apex block. Open the file, find the
#    `cloudbongos.com {` block, and replace its body — the single
#    `reverse_proxy 127.0.0.1:3002 { … }` — with the gate-serving body from
#    infra/Caddyfile (root + @hidden + @gate handle + the catch-all reverse_proxy).
#    Leave builders.cloudbongos.com and status.cloudbongos.com UNTOUCHED.
sudo nano /etc/caddy/Caddyfile

# 3. Validate (as root — it must read the 640 origin keys), then reload.
sudo caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile
sudo systemctl reload caddy   # fails closed on a bad config
```

> A bad config makes `reload` error out and **keep serving the old config** — the
> live sites never go down. If a cert path is wrong, that one site fails to come
> up while the others keep serving.

## Phase ④ — verify

```bash
# from anywhere — the two doors:
curl -sSL https://claudebongos.com/  | grep -o 'space.css\|gate'      # gate HTML served ✓
curl -sSL https://geminibongos.com/  | grep -o 'space.css\|gate'      # gate HTML served ✓
curl -sS -o /dev/null -w '%{http_code}\n' https://claudebongos.com/   # 200 (via the /gate/ redirect) ✓

# cloudbongos.com apex now serves the gate, and the app still answers:
curl -sSL https://cloudbongos.com/   | grep -o 'space.css\|gate'      # gate served at apex ✓
curl -sS  https://cloudbongos.com/healthz                            # "ok" — app still reachable ✓
```

Then open each in **Chrome or Edge** (the live-glass refraction needs Chromium
`backdrop-filter` + SVG displacement; Safari falls back to a plain frost, still
fine):

- `https://claudebongos.com` → gate reads **"Claude Bongos" / `> claude`**. Type
  `bongos`, press enter → you land on **cloudbongos.com showing the orbs**.
- `https://geminibongos.com` → same, **"Gemini Bongos" / `> gemini`**.
- `https://cloudbongos.com` → gate reads "Cloud Bongos"; type `bongos` → orbs in place.
- **Sign-in still works:** `https://builders.cloudbongos.com` → sign in with GitHub
  (the OAuth callback is on the apex, `/api/gds/auth/web/callback`, which the
  catch-all still proxies to `:3002`). If sign-in breaks, the apex `@gate`/`handle`
  split is wrong — recheck step ③.2.

## Rollback

- **Take a door down:** delete its block from `/etc/caddy/Caddyfile`,
  `sudo systemctl reload caddy`, remove the Cloudflare `@` A record.
- **Revert cloudbongos.com to the buddha page:** restore the apex block to the
  single `reverse_proxy 127.0.0.1:3002 { … }` body, reload. The buddha landing
  (`public-landing/index.html`) is untouched in the repo and served again
  immediately.

## Files this recipe uses

- `infra/Caddyfile` — the two door blocks + the modified `cloudbongos.com` apex block.
- `brand/cloud-bongos/gate/space.js` — the runtime hostname switch (branding +
  redirect + `?entered` auto-open).
- `brand/cloud-bongos/` — the gate bundle + the world art it refracts (shared by all three).
