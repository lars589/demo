-- 185_module_upstreaming_goal_wiring.sql
-- ADR 0107 (task 1766) — wire up the "Module upstreaming & catalog" initiative
-- and consolidate the ADR-0103 separation spine under its proper goal.
--
-- WHY A MIGRATION (not the API): the GDS HTTP API exposes POST /goals and
-- goal-less POST /tasks (+ dependencies), but has NO endpoint to (a) attach an
-- existing task to a goal (tasks.goal_id), or (b) reparent an orphan. Those are
-- SQL-only today (the same gap the ADR-0103 consolidation used migration 182
-- for). The goal (id 29) and the 7 ecosystem tasks (1767..1773) + their deps were
-- already created via scripts/gds/seed-module-upstreaming.js; this migration does
-- only the SQL-only finishing.
--
-- ADR 0105 COMPLIANCE: this is a pure MUTATION of existing OTB rows — it INSERTs
-- NO versions/goals/criteria scope-truth, so it cannot pollute or crash a vanilla
-- self-host. Every statement is guarded on its OTB anchor existing, so on any DB
-- that is not this instance it affects ZERO rows (a clean no-op). It is therefore
-- safe to carry in core migrations/ (where it auto-applies on the OTB deploy),
-- unlike the seed files ADR 0105 relocated to migrations/instance/. Re-runnable.

BEGIN;

-- 1. Attach the ecosystem tasks (ADR 0107) to goal 29
--    "Module upstreaming & catalog". No-op unless goal 29 exists (i.e. this is OTB).
--    1767..1773 = the original 7; 1776 = the hall Modules tab + atlas provenance (§9).
UPDATE tasks
   SET goal_id = 29
 WHERE id IN (1767, 1768, 1769, 1770, 1771, 1772, 1773, 1776)
   AND EXISTS (SELECT 1 FROM goals WHERE id = 29);

-- 2. Consolidate the ADR-0103 separation spine under G26
--    "Cloud Bongos productization and self-host": the ADR task (1726),
--    R88 extract-core (1727), and R89 split-Amazonprimea (1728) were orphaned
--    (goal_id NULL). R85 (1689) and R86 (1690) already live under G26.
UPDATE tasks
   SET goal_id = 26
 WHERE id IN (1726, 1727, 1728)
   AND EXISTS (SELECT 1 FROM goals WHERE id = 26);

-- 3. Record the ADR-0103 lineage edge the spine was missing: R88 (extract the
--    core, 1727) depends on R84 (package-core, 1688 — shipped, so already
--    satisfied; this only makes the dependency graph match the ADR's spine).
--    Idempotent via the composite PK.
--    Cycle-safe: this raw INSERT skips the app-level findDependencyCycle guard,
--    but a cycle needs 1688 to (transitively) depend on 1727 — no such reverse
--    edge exists, and 1688 is a shipped/older task whose dep set is settled. The
--    worst case is not corruption but an un-promotable task (the claim gate
--    fail-closes), and here the edge is already-satisfied so even that can't occur.
INSERT INTO dependencies (from_kind, from_id, to_kind, to_id)
SELECT 'task', 1727, 'task', 1688
 WHERE EXISTS (SELECT 1 FROM tasks WHERE id = 1727)
   AND EXISTS (SELECT 1 FROM tasks WHERE id = 1688)
ON CONFLICT DO NOTHING;

-- Self-register so this file is not re-run (the recent-migration convention;
-- migrate.sh also backfills with ON CONFLICT, so this is belt-and-suspenders).
INSERT INTO schema_migrations (version) VALUES ('185_module_upstreaming_goal_wiring')
ON CONFLICT DO NOTHING;

COMMIT;
