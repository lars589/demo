// drachmae.js — the in-hall reader for the "Drachmae & karma" onboarding doc
// (task 1472). Fetches the canonical markdown at /builders/drachmae-and-karma.md
// (mounted from docs/onboarding/drachmae-and-karma.md — single source of truth,
// also the one the primer links to) and renders it with the shared OTBMdReader,
// so builders can read exactly how they get paid without leaving the hall for
// GitHub. Reuses the primer's layout/TOC/progress DOM + primer.css; no ack gate
// (this is reference reading, not an onboarding checkpoint).

(() => {
  'use strict';

  const DOC_URL = '/builders/drachmae-and-karma.md';
  // The doc lives at docs/onboarding/, so relative links resolve against it.
  const DOC_DIR = 'docs/onboarding/';

  let repoBlobBase = null;
  let repoTreeBase = null;

  function $(sel) { return document.querySelector(sel); }

  async function loadRepoInfoBases() {
    try {
      const r = await fetch('/api/gds/public/repo-info', { credentials: 'same-origin' });
      if (!r.ok) return;
      const data = await r.json();
      if (data && typeof data.blob_base === 'string') repoBlobBase = data.blob_base;
      if (data && typeof data.tree_base === 'string') repoTreeBase = data.tree_base;
    } catch (_) { /* links degrade to the original href */ }
  }

  function renderToc(headings) {
    const list = $('#primer-toc-list');
    if (!list) return [];
    const h2s = headings.filter((h) => h.level === 2);
    if (h2s.length === 0) { list.innerHTML = '<li class="primer-toc__placeholder">(no sections)</li>'; return []; }
    const esc = window.OTBMdReader.escapeHtml;
    list.innerHTML = h2s.map((h) =>
      `<li><a href="#${esc(h.id)}" data-section="${esc(h.id)}">${esc(h.text)}</a></li>`
    ).join('');
    return h2s;
  }

  function setupScrollspy(tocSections) {
    if (tocSections.length === 0) return;
    const links = new Map();
    for (const a of document.querySelectorAll('.primer-toc__list a')) links.set(a.dataset.section, a);
    if (links.size === 0) return;
    const READING_LINE_Y = 100;
    let last = null;
    function update() {
      let active = null;
      for (const s of tocSections) {
        const el = document.getElementById(s.id);
        if (!el) continue;
        if (el.getBoundingClientRect().top <= READING_LINE_Y) active = s.id; else break;
      }
      if (active === last) return;
      last = active;
      for (const [id, a] of links) a.classList.toggle('is-active', id === active);
    }
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update, { passive: true });
    update();
  }

  function setupProgressBar(articleEl) {
    const bar = $('#primer-progress-bar');
    if (!bar) return;
    function update() {
      const rect = articleEl.getBoundingClientRect();
      const viewport = window.innerHeight || document.documentElement.clientHeight;
      const scrolled = Math.max(0, -rect.top);
      const frac = rect.height > 0 ? Math.min(1, scrolled / Math.max(1, rect.height - viewport)) : 0;
      bar.style.width = `${Math.round(frac * 100)}%`;
    }
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update, { passive: true });
    update();
  }

  function setupTocToggle() {
    const toc = $('#primer-toc');
    const btn = $('#primer-toc-toggle');
    if (!toc || !btn) return;
    btn.addEventListener('click', () => {
      const open = toc.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    toc.addEventListener('click', (e) => {
      const a = e.target.closest('a[data-section]');
      if (!a) return;
      if (window.matchMedia('(max-width: 760px)').matches) {
        toc.classList.remove('is-open');
        btn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  async function boot() {
    const article = $('#primer-article');
    if (!article || !window.OTBMdReader) return;
    let md;
    try {
      const [mdRes] = await Promise.all([
        fetch(DOC_URL, { credentials: 'same-origin' }),
        loadRepoInfoBases(),
      ]);
      if (!mdRes.ok) throw new Error(`${DOC_URL} → ${mdRes.status}`);
      md = await mdRes.text();
    } catch (err) {
      console.error('[drachmae] failed to load doc', err);
      article.innerHTML = `<p class="primer-loading">Could not load the drachmae guide. <a href="/builders">Go back</a> and try again.</p>`;
      article.removeAttribute('aria-busy');
      return;
    }
    const resolveLinkHref = window.OTBMdReader.makeResolveLinkHref({
      baseDir: DOC_DIR,
      getBlobBase: () => repoBlobBase,
      getTreeBase: () => repoTreeBase,
      diagramsHref: '/builders/diagrams',
    });
    const { html, headings } = window.OTBMdReader.parseMarkdown(md, resolveLinkHref);
    article.innerHTML = html;
    article.removeAttribute('aria-busy');
    const tocSections = renderToc(headings);
    setupTocToggle();
    setupScrollspy(tocSections);
    setupProgressBar(article);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
