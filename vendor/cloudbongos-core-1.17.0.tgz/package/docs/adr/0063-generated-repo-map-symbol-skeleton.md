# ADR 0063 — Generated code symbol skeleton (the repo map)

- **Status:** Accepted
- **Date:** 2026-06-18
- **Track:** internal
- **Builds on:** [ADR 0061](<redacted>.md) (the content charter + nested per-module `CLAUDE.md` — this generates their *factual half*), [ADR 0060](0060-gds-retrieval-layer.md) (the lexical recall layer — this is its structural/code complement), [ADR 0062](<redacted>.md) §9 (Path B, folded into the Medusa portable core)
- **Task:** [#1224](https://example.com/builders#/task/1224) (V4.R75) — Path B of the 2026-06-18 context-cliff plan.

## Context

As an AI-authored repo grows, an agent's ability to make safe changes degrades: it cannot hold the whole tree in context, so it either reads too many files (burning budget) or guesses (drifting). [ADR 0061](<redacted>.md) added nested per-module `CLAUDE.md` docs whose hand-written "Key files / public surface" section is exactly the kind of fact that **drifts** — the moment a function is renamed or a file added, the prose lies, and nothing forces it back into sync.

Path B (the 2026-06-18 research) is the fix: a committed, **generated** symbol skeleton, regenerated mechanically so it cannot drift — the same "generate, don't narrate" discipline `gen-diagrams.js` already applies to the onboarding diagrams (task 357). It gives an agent an **altitude map** (à la Aider's repo map): the most central symbols and per-file signatures, so it can navigate without reading every file. It complements the recall layer ([ADR 0060](0060-gds-retrieval-layer.md)), which indexes *prose* (docs + DB rows) — the repo map indexes *code*.

## Decision

Ship `scripts/gds/gen-repo-map.js`, a deterministic generator that produces two artifacts and is wired into the deploy regen:

1. **`docs/repo-map.md`** — the global altitude map: the top exported symbols ranked by reference frequency, plus per-directory exported signatures.
2. **A delimited generated block** (`<!-- BEGIN/END GENERATED REPO-MAP -->`) injected into each nested `CLAUDE.md` (`src/bongos/`, `src/bongos/routes/`, `scripts/gds/`) — the **factual half**. The hand-written interpretive prose above it (purpose, gotchas, ADR links) is left untouched; only the factual signature list is regenerated, so the two halves can't drift apart.

**Regenerated on every ship** by `regenerateRepoMap()` in `ship.js` (alongside `regenerateDiagrams()`), and gated in CI by `gen-repo-map.js --check` (exit 2 if stale) — the enforcement is Path C / [#1225](https://example.com/builders#/task/1225). Deterministic (no timestamps, stable sort) so `--check` is a clean idempotent gate.

### Why zero-dependency (not tree-sitter, despite the task name)

The task is named "tree-sitter repo map." We use a **zero-dependency line+regex extractor** instead, deliberately:

- **Portability is the whole point.** Paths B+C exist to keep *every* Medusa instance navigable cheaply. A portable-core capability that needs a native `node-gyp` build (`tree-sitter`) or a fetched WASM grammar (`web-tree-sitter`) adds an install/build step to CI and to every dev box — the opposite of the goal, and a recurring source of breakage.
- **The codebase is CommonJS JS**, formatted with col-0 top-level declarations — a regex extractor keyed on that is accurate enough.
- **The output is advisory**, not a compiler input. An imperfect signature in a navigation aid costs nothing; a broken CI build costs every ship.
- **Bootstrap budget** ([CLAUDE.md](../../CLAUDE.md) §4): no new dependency.

`extractFile()` is the seam: a tree-sitter/WASM backend can replace it later for a **polyglot** instance (a Python or Go host) behind the same interface, without touching the ranking or rendering. Until an instance needs more than one language, the regex backend wins on every axis that matters.

### Known limitation: reference frequency is a corpus token tally

"Refs" is the count of a symbol's name across the scanned corpus — a cheap centrality proxy (à la Aider's repo map, minus the PageRank graph). It does **not** resolve scope, so two distinct symbols sharing a name (e.g. several files' exported `start()`) share one count. Ranking only the **exported** surface (cross-file-reachable in CommonJS) plus a generic-name stoplist (`main`/`log`/`err`/…) removes the worst noise; the residual same-name conflation is acceptable for an altitude map and documented here so a reader doesn't over-trust the exact number.

## Consequences

- Nested-doc file/signature lists can no longer silently drift — they're regenerated on every deploy and gated in CI.
- An agent gets a cheap, always-fresh structural map of the codebase, complementing prose recall.
- Scope today: server-side JS (`server.js`, `src/`, `scripts/`, `.claude/hooks/`). Extending coverage (e.g. `public/game/`) or languages is a one-line `SCAN_ROOTS` change / an `extractFile()` backend swap.
- The generator is itself in `scripts/gds/` and so appears in its own map — editing it changes its own skeleton, so a regen+commit must be the last step before shipping any source change (the `--check` gate enforces this).
