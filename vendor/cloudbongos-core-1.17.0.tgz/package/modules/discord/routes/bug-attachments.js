// src/bongos/routes/bug-attachments.js — serve re-hosted #bugs screenshots (task
// #936, follow-on to ADR 0047).
//
// The bot downloads images posted in #bugs and re-hosts them here (durable —
// Discord CDN links expire). A bug-task's description embeds
// /api/bongos/bug-attachments/<file>, so when a builder opens the task in the hall
// the <img> loads from this route. The browser sends the gds_session cookie on
// the same-origin image request, so requireBuilder gates it: builders-only,
// exactly the access posture for the rest of the GDS surface.
//
// rank: the route is auth.requireBuilder — any authenticated builder may VIEW a
// bug screenshot (there's no rank-restricted content here; bugs are builder
// work). Writes happen only via the bot (bug-attachments.js), never this route.

const express = require('express');
const fs = require('node:fs/promises');
const auth = require('../auth');
const attach = require('../bug-attachments');

module.exports = function buildBugAttachmentsRouter() {
  const router = express.Router();

  // GET /api/bongos/bug-attachments/:name — stream one stored image.
  router.get('/bug-attachments/:name', auth.requireBuilder, async (req, res) => {
    const p = attach.resolveSafe(req.params.name);
    if (!p) return res.fail('bad_name', 400);
    try {
      const data = await fs.readFile(p);
      res.setHeader('Content-Type', attach.contentTypeForName(req.params.name));
      // Never let a browser sniff these into something executable, and keep them
      // inline (so they render in the hall) but explicitly not as a download.
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('Content-Disposition', 'inline');
      res.setHeader('Cache-Control', 'private, max-age=86400');
      res.send(data);
    } catch (err) {
      if (err.code === 'ENOENT') return res.fail('not_found', 404);
      console.error('[gds] GET /bug-attachments', err);
      res.fail('read_failed', 500);
    }
  });

  return router;
};
