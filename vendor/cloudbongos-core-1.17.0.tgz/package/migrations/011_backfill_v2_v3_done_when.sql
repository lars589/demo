-- Backfill versions.done_when for PMS-V2 and PMS-V3.
--
-- V1 and PMS-V1 already have done_when populated. PMS-V2 and PMS-V3 were
-- declared without paint-the-picture copy, leaving the status page rows
-- without a senate-voice description of what each version IS. The public
-- status page (status.amazonprimea.com) now renders versions.done_when
-- under each version block (task #119); this migration provides the copy.
--
-- Idempotent: only fills where done_when IS NULL or empty, so re-runs and
-- manual edits are preserved.

UPDATE versions
SET done_when = $body$When this is finished, the citizens building Amazonprimea will keep their works on a themed ledger of their own — naming sessions, claiming tasks in batches, earning laurels for milestones, and seeing each version's scope painted in plain words.$body$
WHERE id = 'PMS-V2'
  AND (done_when IS NULL OR done_when = '');

UPDATE versions
SET done_when = $body$When this is finished, multiple builders will work the city in parallel — each with their own seal, their own shelf of credits, and their own lane of stones to set.$body$
WHERE id = 'PMS-V3'
  AND (done_when IS NULL OR done_when = '');
