-- 126_autonomy_runs.sql — observability for the autonomy precheck (GDS-V4 task
-- 1351, System 3: Value-Gated Autonomous Engagement).
--
-- The $0 deterministic precheck (scripts/gds/autonomy-gate.js) decides, before
-- any model boots, whether a nightly routine should fire (signal present) or skip
-- (no claimable work + main unchanged, or no open ideas, or the autonomous
-- month-to-date spend has hit its ceiling). Every decision — especially every
-- SKIP — lands here so the gate is auditable: "why didn't overnight-builder run
-- last night?" is a query, not a guess. The latest `go` row's head_sha is also
-- the "stored last_head" the next precheck compares origin/main against.
--
-- SYSTEM 3 IS BUILT DISABLED (owner directive): the gate is inert until
-- OTB_AUTONOMY_ENABLED=1, so `enabled` records whether it was armed at decision
-- time. While off, every row is decision='go', reason='disabled' — proving the
-- wiring changes nothing until the owner arms it alongside the grader rework.
--
-- Additive, new table + index, idempotent: safe to re-run.

CREATE TABLE IF NOT EXISTS autonomy_runs (
  id              bigserial PRIMARY KEY,
  routine         text NOT NULL,
  decision        text NOT NULL,            -- 'go' | 'no-go'
  reason          text,
  head_sha        text,
  claimable_count integer,
  enabled         boolean NOT NULL DEFAULT false,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_autonomy_runs_routine ON autonomy_runs (routine, created_at DESC);

INSERT INTO schema_migrations (version) VALUES ('126_autonomy_runs')
  ON CONFLICT (version) DO NOTHING;
