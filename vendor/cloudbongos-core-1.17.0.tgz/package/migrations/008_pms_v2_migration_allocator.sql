-- Pre-allocate migration numbers at claim time.
--
-- When two parallel builders both create a migration at "the next free number,"
-- they pick the same number. The fix: when a task's touches[] contains the
-- sentinel string 'migrations/' (the directory, no specific filename),
-- POST /claims atomically allocates the next number from this counter table
-- and stores it on the claim. The CLI surfaces the number to the builder, who
-- creates `migrations/<NNN>_*.sql` using that prefix.
--
-- Once allocated, a number stays attached to its claim even if the claim is
-- released without shipping. Sequential numbering is not required — gaps are
-- fine.

CREATE TABLE IF NOT EXISTS migration_counter (
  id          INTEGER PRIMARY KEY DEFAULT 1,
  next_number INTEGER NOT NULL,
  CHECK (id = 1)
);

-- Seed: highest existing migration on disk is 008 (this one).
-- Next allocation goes to 009.
INSERT INTO migration_counter (id, next_number)
VALUES (1, 9)
ON CONFLICT (id) DO NOTHING;

ALTER TABLE claims
  ADD COLUMN IF NOT EXISTS reserved_migration_number INTEGER;
