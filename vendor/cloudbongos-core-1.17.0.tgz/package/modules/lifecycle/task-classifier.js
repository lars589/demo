// Heuristic classifier for tasks.kind.
//
// Returns one of:
//   feature, bug, infra, refactor, spike, learning-capture,
//   cleanup, decision, blocker-resolution, unclassified
//
// Strategy:
//   1. If description carries a structured "KIND: <x>" tag near the top,
//      trust it (confidence 0.95).
//   2. Otherwise regex-score over title + description. Highest score wins.
//   3. If no rule matches, return 'feature' (the optimistic default) at
//      confidence 0.5 — POST /tasks treats < 0.5 as unclassified.

const VALID_KINDS = new Set([
  'feature',
  'bug',
  'infra',
  'refactor',
  'spike',
  'learning-capture',
  'cleanup',
  'decision',
  'blocker-resolution',
  // task 1053 (F): a task whose deliverable IS a verification (e.g. a hardware-
  // verify run). Confirming one requires an explicit `verified` attestation that
  // the verification actually passed — not just a passing code grade — so it
  // can't be prematurely confirmed (the #1027 trap). Deliberately NOT auto-
  // classified from title text (a task ABOUT verify tasks would false-positive);
  // a planner opts in by setting kind='verify' (or a `KIND: verify` tag).
  'verify',
  'unclassified',
]);

// Order matters: first match wins per category, but we score across all
// categories and pick the strongest signal.
const RULES = [
  { kind: 'bug',                re: /\b(fix|bug|broken|regression|hotfix|crash)\b/i,             weight: 0.85 },
  { kind: 'refactor',           re: /\b(refactor|rename|restructure|extract)\b/i,                 weight: 0.8  },
  { kind: 'cleanup',            re: /\b(cleanup|clean ?up|dead code|tidy|prune|remove unused)\b/i, weight: 0.8 },
  { kind: 'infra',              re: /\b(schema|migration|deploy|deployment|infra|cron|systemd|caddy|nginx)\b/i, weight: 0.85 },
  { kind: 'spike',              re: /\b(spike|investigate|research|RFC|prototype|explore)\b/i,    weight: 0.8  },
  { kind: 'learning-capture',   re: /\b(learning|gotcha|lesson|postmortem|retrospective)\b/i,     weight: 0.9  },
  { kind: 'decision',           re: /\b(decision|ADR|rationale|architecture decision)\b/i,        weight: 0.9  },
  { kind: 'blocker-resolution', re: /\b(unblock|credentials|api key|access)\b/i, weight: 0.85 },
];

// Instance-specific external-vendor names (a payment processor, a fulfillment
// partner, …) are ALSO a blocker-resolution signal — but they are NOT core
// vocabulary, since a vanilla Cloud Bongos instance integrates no such vendors.
// R59 (task 1198) moves them out of the core rule above and into per-instance
// branding config (branding.vocab.blockerVendors); OTB's config supplies
// ["hermeslines","stripe"]. buildBlockerVendorRe is pure (testable with no I/O);
// the resolved RegExp is cached, and resolution fails to "no vendors" so tooling
// or tests that load no branding simply get the core rule.
function buildBlockerVendorRe(vendors) {
  if (!Array.isArray(vendors) || vendors.length === 0) return null;
  const alt = vendors
    .filter((v) => typeof v === 'string' && v.trim())
    .map((v) => v.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
    .join('|');
  return alt ? new RegExp(`\\b(${alt})\\b`, 'i') : null;
}

let _blockerVendorRe; // undefined = unresolved; null = none for this instance
function blockerVendorRule() {
  if (_blockerVendorRe === undefined) {
    _blockerVendorRe = null;
    try {
      _blockerVendorRe = buildBlockerVendorRe(require('../../src/module-api').branding().vocab?.blockerVendors);
    } catch { /* no branding (tooling/test) → no instance vendors */ }
  }
  return _blockerVendorRe;
}
const _resetVendorCacheForTests = () => { _blockerVendorRe = undefined; };

function extractKindTag(description) {
  if (!description) return null;
  // Match "KIND: <word>" within the first 400 chars; case-insensitive.
  const head = String(description).slice(0, 400);
  const m = head.match(/^\s*KIND\s*:\s*([a-z\-]+)/im);
  if (!m) return null;
  const tag = m[1].toLowerCase().trim();
  if (VALID_KINDS.has(tag) && tag !== 'unclassified') return tag;
  return null;
}

function classifyTaskKind(title, description) {
  const text = `${title || ''} ${description || ''}`;

  // 1. Structured tag wins.
  const tagged = extractKindTag(description);
  if (tagged) return { kind: tagged, confidence: 0.95 };

  // 2. Regex scoring.
  let best = null;
  for (const rule of RULES) {
    if (rule.re.test(text)) {
      if (!best || rule.weight > best.confidence) {
        best = { kind: rule.kind, confidence: rule.weight };
      }
    }
  }
  // Instance vendor names also signal blocker-resolution (R59 — config, not core).
  const vendorRe = blockerVendorRule();
  if (vendorRe && vendorRe.test(text)) {
    if (!best || 0.85 > best.confidence) best = { kind: 'blocker-resolution', confidence: 0.85 };
  }
  if (best) return best;

  // 3. Optimistic default at boundary confidence — caller treats <0.5 as
  //    'unclassified' so we sit it right at 0.5 to bias toward 'feature'
  //    when text gave us nothing.
  return { kind: 'feature', confidence: 0.5 };
}

// -------------------------------------------------------------------------
// Discipline classifier
// -------------------------------------------------------------------------
//
// Orthogonal to kind. Classifies the builder-interest axis (migration 086):
//   engineer      — the prompter is reasoning about algorithms, infra, data
//                   plumbing, dev tooling, scanners, schemas, integrations.
//                   The person guiding the prompt brings software-engineering
//                   experience.
//   artist        — producing or shipping visual artifacts: sprite/tile
//                   generation, palettes, walk animations, aesthetic passes.
//   ideator       — thinking/writing/scoping: quest narrative, world/level
//                   design, lore, briefs, research, naming.
//   unclassified  — signals weak or balanced; hand-triage.
//
// The scoring engine first decides engineer-vs-creative; a creative verdict
// is then split into artist/ideator by splitCreativeDiscipline().
//
// Calibrated against Lars's hand-classifications of 25 tasks (mig 014
// backfill, 2026-05-12). Key insights from those decisions:
//   - Title text matters more than description text. A creative-leaning
//     description ("iterating on art changes") inside an otherwise
//     engineering title ("Dev shortcut: Shift+R") shouldn't tip the result.
//   - Tools that OPERATE ON art (renderers, validators, anti-grid eval,
//     content-hash atlas, walkability BFS) are engineering — the prompter
//     reasons about algorithms, not about how a sprite should look.
//   - Producing or shipping visual artifacts (tilesheet deploy, world PNG
//     snapshot, status page redesign, sprite family migration) is creative —
//     even when the verb sounds infra ("deploy", "push").
//   - Bug fixes, doc rewrites, integrations, achievement evaluators land as
//     engineering regardless of which domain they bug-fix or document.
//
// Scoring model: title text + (description text × 0.4) + touches[] hits,
// summed and capped. The 0.4 description weight is what stops incidental
// creative phrasing in long descriptions from flipping engineering tasks.

// Migration 086 split the old "creative" lane into 'artist' (visual asset
// production) and 'ideator' (thinking/writing/scoping) and renamed
// 'engineering' → 'engineer'. The binary scoring engine below still decides
// engineer-vs-creative; a creative verdict is then disambiguated into
// artist/ideator/ui by splitCreativeDiscipline(). When that split is unclear,
// it returns 'unclassified' (hand-triage) — matching the #615 backfill rule.
//
// Migration 176 (task 1376) added 'ui' — UI/interface DESIGN work (Figma,
// Claude-Design, design systems, layout/wireframes). It splits out of the
// pixel-art `artist` lane (ADR 0079): producing interface designs is a
// distinct discipline from producing pixel-art assets, and routes to its own
// /design work-mode (discipline-modes.json) instead of /paint.
const VALID_DISCIPLINES = new Set(['engineer', 'artist', 'ideator', 'ui', 'unclassified']);

// Numeric field bounds for task creation (POST /tasks). The single source of
// truth: the route schema in routes/tasks.js references these so the validator
// and the claim-time context pack (V4.R04 / sessions-start-knowing) can never
// drift apart. `priority` mirrors the DB CHECK exactly — `tasks_priority_check`
// (priority BETWEEN 1 AND 5, migrations/003_pms.sql) — so a value the validator
// accepts is one the INSERT accepts. (It used to be a laxer 0–100, which let a
// value like 40 pass validation only to fail the DB CHECK with an opaque
// `create_failed` constraint-violation message, and taught the context pack the
// wrong range — task 1233.) `convention` is retained so the pack can surface the
// human-facing "use P1–P5 tiers" label alongside the accepted range.
const TASK_FIELD_BOUNDS = {
  priority: { min: 1, max: 5, convention: { min: 1, max: 5, label: 'P1–P5 planning tiers' } },
  manual_degree: { min: 0, max: 5 },
};

// Task statuses that can receive peer-acclaim votes (a work must be at least
// verified). Canonical home here so routes/tasks.js and discord-reaction.js
// (the vote → applause Discord mirror) share one definition (D1).
const VOTABLE_TASK_STATUSES = new Set(['confirmed', 'shipped']);

// Disambiguation signals for the creative lane (migration 086). Visual
// art-production cues → artist; narrative / design-thinking / writing cues →
// ideator. Scored by distinct-rule hit count over title+description, plus
// touches[] path prefixes; the stronger side wins, ties / no-signal fall to
// 'unclassified' for hand-triage.
const ARTIST_SIGNALS = [
  /\bpixel[-\s]?art\b/i,
  /\btile-?sheets?\b/i,
  /\b(sprites?|spritesheet|atlas|autotile)\b/i,
  /\b(palettes?|paint(ing)?|illustrations?|hue\b|color\s+profile)\b/i,
  /\b(walk\s+(animation|cycle|frames?)|animation\s+frames?)\b/i,
  /\b(visual\s+redesign|aesthetic\s+pass|regen(erate)?\b)\b/i,
];
const IDEATOR_SIGNALS = [
  /\b(quest|narrative|story|dialog(ue)?|NPC|lore)\b/i,
  /\b(scene|level|world|map)\s+design\b/i,
  /\b(style\s+guide|rubric|reviewer)\b/i,
  /\b(scope|scoping|research|brief|naming|writing|feedback|observation|taxonomy)\b/i,
];
// UI/interface DESIGN signals (mig 176 / task 1376). Distinct from pixel-art
// `artist` work: this is interface layout, wireframes, design systems, and the
// Figma / Claude-Design tooling used to produce them. Figma is a UI-design cue
// (it moved here from ARTIST_SIGNALS), so a "Figma redesign of the hall" lands
// as `ui`, not `artist`.
const UI_SIGNALS = [
  /\b(UI|UX)\b/,
  /\b(user\s+(interface|experience)|interface\s+design)\b/i,
  /\b(figma|claude[-\s]?design|design\s+system|design\s+token|wireframes?|mock-?ups?|prototyp(e|ing))\b/i,
  /\b(layout|landing\s+page|component\s+library|responsive|css\s+(redesign|theme)|theming)\b/i,
];
const ARTIST_PATH_PREFIXES = [
  'modules/art-pipeline/template/',
  'modules/art-pipeline/iterations/_families/',
  'modules/art-pipeline/iterations/_autotile/',
  'modules/art-pipeline/generated/',
  'modules/art-pipeline/references/',
  'public/assets/tiles/',
  'public/assets/sprites/',
  'docs/recipes/pixel-art',
];
const IDEATOR_PATH_PREFIXES = ['docs/', 'limitations/', 'generative-ideas'];
// UI-design touches (mig 176 / task 1376): the front-end surfaces a UI-design
// task edits. The status/hall UIs and the game's HTML/CSS chrome are where
// interface-design work lands.
const UI_PATH_PREFIXES = [
  'modules/status-ui/',
  'modules/hall-ui/',
  'public/game/ui/',
  'docs/design/',
];

// Split a 'creative' verdict into 'artist' | 'ideator' | 'ui' | 'unclassified'.
// Three sub-lanes are scored by distinct-rule hit count + touches[] hits; the
// strongest single lane wins. A tie at the top (including 0-0-0) → hand-triage.
function splitCreativeDiscipline(title, description, touches) {
  const text = `${title || ''} ${description || ''}`;
  const artist = ARTIST_SIGNALS.filter((re) => re.test(text)).length
               + countTouchesHits(touches, ARTIST_PATH_PREFIXES);
  const ideator = IDEATOR_SIGNALS.filter((re) => re.test(text)).length
                + countTouchesHits(touches, IDEATOR_PATH_PREFIXES);
  const ui = UI_SIGNALS.filter((re) => re.test(text)).length
           + countTouchesHits(touches, UI_PATH_PREFIXES);
  const ranked = [
    { d: 'artist', n: artist },
    { d: 'ideator', n: ideator },
    { d: 'ui', n: ui },
  ].sort((a, b) => b.n - a.n);
  // No signal anywhere, or the top two are tied → hand-triage.
  if (ranked[0].n === 0 || ranked[0].n === ranked[1].n) return 'unclassified';
  return ranked[0].d;
}

// Title/description text rules. Many of these are deliberately specific
// (e.g. "world snapshot", "family migration") — pure single-word keywords
// like "art" are too noisy to ever be a reliable signal.
const CREATIVE_TEXT_RULES = [
  // Naming a visual artifact being produced or shipped.
  { re: /\b(art\s+completion|asset\s+completion|art\s+done)\b/i,                                  weight: 0.85 },
  { re: /\b(generated\s+(tile|sprite|atlas)|deploy\s+art|push\s+(tile|sprite)sheet|ship\s+art)\b/i,weight: 0.85 },
  { re: /\b(daily\s+PNG|world\s+snapshot|snapshot\s+pipeline|world\s+screenshot)\b/i,             weight: 0.85 },
  { re: /\b(visual\s+redesign|senate-library|themed\s+redesign|aesthetic\s+pass)\b/i,             weight: 0.85 },
  // Higher weight so "family migration" (asset re-generation) beats the
  // generic eng "migration" keyword on the same word.
  { re: /\b(family\s+migration|(sprite|character|player)\s+family|4[-\s]direction\s+family)\b/i,  weight: 0.95 },
  { re: /\b(autotile\s+family|family\s+pipeline|spritesheet)\b/i,                                 weight: 0.75 },
  { re: /\b(regen(erate)?\b|color\s+profile|hue\s+gate)\b/i,                                      weight: 0.75 },
  { re: /\b(pixel\s*art|pixel-art|tilesheet|tile-?sheets?)\b/i,                                   weight: 0.7 },
  // Generic terms — lower weight, lots of overlap with engineering.
  // Plural variants matter ("8 sprites, single family" in walk-anim titles).
  { re: /\b(sprites?|palettes?|paint(ing)?|illustrations?)\b/i,                                   weight: 0.6 },
  // Walk-cycle / animation frame work — character sprite generation.
  { re: /\b(walk\s+animation|animation\s+frames?|walk\s+(cycle|frames?))\b/i,                     weight: 0.75 },
  { re: /\b(quest|narrative|story|dialog(ue)?|NPC)\b/i,                                           weight: 0.65 },
  { re: /\b(scene\s+design|level\s+design|world\s+design|map\s+design)\b/i,                       weight: 0.75 },
  { re: /\b(rubric(?!\s+(fixture|test))|style\s+guide|reviewer)\b/i,                              weight: 0.65 },
  { re: /\b(figma|design\s+template|design\s+system|design\s+token)\b/i,                          weight: 0.6 },
  // UI/interface DESIGN cues (mig 176 / task 1376) — route the creative verdict
  // to the `ui` sub-lane via splitCreativeDiscipline. Kept here (not engineering)
  // so "UI redesign of the hall" / "wireframe the checkout" land creative-first;
  // splitCreativeDiscipline then picks `ui` over `artist`/`ideator`.
  { re: /\b(UI|UX)\s+(design|redesign|pass|polish|refresh|overhaul)\b/i,                          weight: 0.8 },
  { re: /\b(user\s+(interface|experience)|interface\s+design|wireframes?|mock-?ups?)\b/i,         weight: 0.8 },
  { re: /\b(figma|claude[-\s]?design)\b.*\b(redesign|design|layout|screen|mock-?up|wireframe)\b/i, weight: 0.8 },
];

const ENGINEERING_TEXT_RULES = [
  // Algorithm / data-structure work on art (the "tools that operate on art"
  // bucket — these match in art-pipeline tasks and should beat creative
  // path signals from the same task).
  { re: /\b(renderer|compositor|rasterizer)\b/i,                                                  weight: 0.85 },
  { re: /\b(BFS|DFS|FFT|autocorrelation|algorithm(?:ic)?|connectivity(?:\s+check)?)\b/i,          weight: 0.85 },
  { re: /\b(harness|fixtures?|test\s+suite|evaluator|validator|regression\s+test)\b/i,            weight: 0.75 },
  { re: /\b(edge[-\s]variant|seam[-\s]compat|boundary\s+(tile|match))\b/i,                        weight: 0.7 },
  { re: /\b(inventory\s+index|searchable\s+metadata|index\s+(es|ed|file)|lookup)\b/i,             weight: 0.7 },
  { re: /\b(CLI(?:\b|\s)|entry\s+point|command[-\s]line\b)/i,                                     weight: 0.7 },
  // Tool-noun pattern (Lars's heuristic: "who's prompting?"). Words like
  // "scorer", "packer", "loader" name a tool the engineer builds — even
  // when the tool operates on visual assets. These OUT-rank generic
  // creative keywords ("sprite", "tile") in the same title.
  { re: /\b(scorer|packer|loader|detector|inspector|profiler|sweeper)\b/i,                        weight: 0.8 },
  { re: /\b((generator|loader|packer|scorer|detector)\s+module|biome\s+generator|AI\s+(generator|biome))\b/i, weight: 0.85 },
  { re: /\b(perceptual\s+hash|hash\s+diff|score\s+delta|auto[-\s]revert|regression\s+detection)\b/i, weight: 0.85 },
  // Building rubric / gate machinery (vs. running it to make art).
  // Split into separate rules so a title with two of these phrases (e.g.
  // "rubric criterion + hue-range gate") scores ENGINEERING twice.
  { re: /\b(rubric\s+(criterion|gate|rule))\b/i,                                                  weight: 0.85 },
  { re: /\b(enforcement\s+(audit|gate)|rule\s+enforcement)\b/i,                                   weight: 0.8 },
  { re: /\b(hue[-\s]range\s+gates?|color\s+profile\s+(gates?|checks?))\b/i,                       weight: 0.8 },
  // Image-processing standardization is engineering.
  { re: /\b(BG\s+keying|background\s+keying|magenta[-\s]key(?:ing)?|key(?:ing)?\s+(standardization|fix|bug))\b/i, weight: 0.85 },
  // Asset wiring / pipeline plumbing.
  { re: /\b(wire(?:d|s)?\s+\S+\s+(?:into|up|in)\b|atlas\s+(pack(?:er)?|loader)|phaser\s+(loader|atlas))\b/i, weight: 0.8 },
  // Game-engine + framework names — mentioning Phaser / Colyseus / Express
  // is a strong engineering signal regardless of surrounding art vocabulary.
  { re: /\b(Phaser|Colyseus|Express(?:\.js)?|systemd|sharp|Chart\.js)\b/i,                        weight: 0.8 },
  { re: /\b(directory\s+restructure|asset\s+(directory|naming)|naming\s+standardization)\b/i,     weight: 0.75 },
  { re: /\b(retry\s+loop|retry\s+chain|screenshot\s+(scorer|regression|check))\b/i,               weight: 0.75 },
  // Status-page / dashboard content is engineering doc work, not art.
  { re: /\b(version\s+block|page\s+description|status\s+page|paint[-\s]the[-\s]picture)\b/i,      weight: 0.7 },
  // Architecture / dispatch terms.
  { re: /\b(dispatch|object\s+overlay|overlays?(?:\s+(architecture|dispatch|system))?|ADR\b)\b/i, weight: 0.7 },
  // Canvas / image-data bug-fix vocabulary.
  { re: /\b(canvas|key\s+mismatch|opaque\s+(tile|background|pixel)|RGBA?\b|transparency)\b/i,     weight: 0.65 },
  // Data audit / dedup / canonicalization.
  { re: /\b(audit\b(?!\s+(routine|cadence))|de[-\s]?dup(?:e|licate|lication)?|canonical(?:ize)?|schema\s+(audit|cleanup))\b/i, weight: 0.7 },
  // Infra / dev tooling.
  { re: /\b(content[-\s]hash|cloudflare|cache(?:\s+bust|[-\s]bust|d|s)?|TTL|atlas\.json)\b/i,     weight: 0.75 },
  { re: /\b(dev\s+shortcut|hard[-\s]reload|Shift\+R)\b/i,                                         weight: 0.85 },
  { re: /\b(migration|schema|postgres|SQL|index|VIEW|trigger|FK|foreign\s+key)\b/i,               weight: 0.9 },
  { re: /\b(API|endpoint|route|HTTP|cookie|auth|session|webhook|broadcast|integration)\b/i,       weight: 0.75 },
  { re: /\b(infra|deploy(?:ment)?|systemd|caddy|nginx|cron|cert|TLS|host\s+routing)\b/i,          weight: 0.85 },
  { re: /\b(scanner|smoke\s+test|preflight|CI|CD)\b/i,                                            weight: 0.75 },
  { re: /\b(refactor|cleanup|dead\s+code|lint|unused)\b/i,                                        weight: 0.6 },
  // GDS surface — claims, leaderboard, achievements, learnings, backfills.
  { re: /\b(GDS|claim|claims|builder(?:s)?|leaderboard|achievements?|streak|learnings?)\b/i,      weight: 0.75 },
  { re: /\b(evaluator|backfill|seed|import\s+|reconcile)\b/i,                                     weight: 0.7 },
  // Server / wire protocol.
  { re: /\b(server|client|websocket|colyseus|protocol|state\s+sync)\b/i,                          weight: 0.7 },
  { re: /\b(parser|parse|serialize|encode|decode)\b/i,                                            weight: 0.6 },
  { re: /\b(scope\s+file|decoder\s+ring|taxonomy|categorization|labeling)\b/i,                    weight: 0.6 },
  { re: /\b(merge|rebase|conflict|fast-forward|fast\s+forward)\b/i,                               weight: 0.55 },
];

// touches[] prefixes that signal one discipline. Note: modules/art-pipeline/ is
// NOT in CREATIVE_PATH_PREFIXES — that directory holds engineering work on
// art tools (validators, anti-grid eval, content-hash atlas). The actual
// creative output lives in modules/art-pipeline/template/, modules/art-pipeline/iterations/_families/,
// modules/art-pipeline/iterations/_autotile/, modules/art-pipeline/generated/, and public/assets/.
const CREATIVE_PATH_PREFIXES = [
  'modules/art-pipeline/template/',
  'modules/art-pipeline/iterations/_families/',
  'modules/art-pipeline/iterations/_autotile/',
  'modules/art-pipeline/generated/',
  'modules/art-pipeline/references/',
  'public/assets/tiles/',
  'public/assets/sprites/',
  'docs/recipes/pixel-art',
];

const ENGINEERING_PATH_PREFIXES = [
  'migrations/',
  'src/bongos/',
  'src/db.js',
  'src/seats.js',
  'src/rooms/',
  'src/world/',
  'scripts/gds/',
  'scripts/migrate',
  'scripts/snapshots/',
  'infra/',
  'tests/',
  'server.js',
  'modules/art-pipeline/',
  '.claude/skills/builder-',
  '.claude/skills/merge-',
  '.claude/skills/blocker-',
  '.claude/skills/idea-',
  '.claude/skills/otb-builder-',
  'modules/hall-ui/',
  'modules/status-ui/',
  'public/game/net/',
  'public/game/scenes/',
  'public/game/player/',
  'public/game/npcs/',
  'public/game/ui/',
  'limitations/',
  'docs/adr/',
  'CLAUDE.md',
];

const PATH_HIT_WEIGHT = 0.45;
const PATH_HIT_CAP = 0.95;
const DESC_WEIGHT = 0.3;
// Use 0.05 (not 0.10) so float quirks like 0.75 - 0.65 = 0.0999... don't
// flip a meaningful asymmetry into a tie.
const TITLE_DECISIVE_MARGIN = 0.05;
const PHASE2_MIN_STRENGTH = 0.3;
const PHASE2_MIN_MARGIN = 0.15;

// Returns { max, count } where max is the highest matched rule weight and
// count is the number of distinct rules that fired.
//
// Lars's heuristic ("who's prompting?") asks for the strongest single
// signal in the title. We use `max` as the primary decision input, with
// `count` as a tiebreaker when both sides have a single strong match
// (e.g. "Push generated tilesheet to droplet (deploy art)" — both sides
// max at 0.85, but creative has 3 distinct rule hits vs eng's 1).
function scoreText(text, rules) {
  if (!text) return { max: 0, count: 0 };
  let max = 0;
  let count = 0;
  for (const rule of rules) {
    if (rule.re.test(text)) {
      count++;
      if (rule.weight > max) max = rule.weight;
    }
  }
  return { max, count };
}

function countTouchesHits(touches, prefixes) {
  if (!Array.isArray(touches) || touches.length === 0) return 0;
  let hits = 0;
  for (const t of touches) {
    if (typeof t !== 'string') continue;
    if (prefixes.some((p) => t.startsWith(p))) hits++;
  }
  return hits;
}

function scoreTouches(touches, prefixes) {
  const hits = countTouchesHits(touches, prefixes);
  if (hits === 0) return 0;
  return Math.min(PATH_HIT_CAP, hits * PATH_HIT_WEIGHT);
}

function classifyTaskDiscipline(title, description, touches) {
  const titleText = title || '';
  const descText = description || '';

  // Phase 1 — title-first decision via three progressive tiebreakers:
  //   (a) max-rule-weight  — strongest single signal wins if margin ≥ 0.04
  //   (b) match-count      — more distinct rule hits wins if margin ≥ 2
  //   (c) touches hit-count — more path-prefix hits wins if margin ≥ 2
  // Falls to phase 2 only if max-weight signal is too weak to act on.
  const cT = scoreText(titleText, CREATIVE_TEXT_RULES);
  const eT = scoreText(titleText, ENGINEERING_TEXT_RULES);

  if (Math.max(cT.max, eT.max) >= 0.5) {
    // (a) Max-weight margin — use 0.04 to absorb float quirks like
    // 0.95 - 0.9 = 0.04999999999999993.
    if (Math.abs(cT.max - eT.max) >= 0.04) {
      if (cT.max > eT.max) {
        const d = splitCreativeDiscipline(titleText, descText, touches);
        return { discipline: d, confidence: d === 'unclassified' ? 0 : cT.max };
      }
      return { discipline: 'engineer', confidence: eT.max };
    }
    // (b) Same max-weight (e.g. both 0.85). Combine title-rule count and
    // touches[] hit count into a single asymmetry score — a side that
    // dominates both surfaces wins even if neither margin is decisive
    // alone (e.g. #5: 2-vs-1 rule hits AND 1-vs-0 path hits → creative).
    const cHits = countTouchesHits(touches, CREATIVE_PATH_PREFIXES);
    const eHits = countTouchesHits(touches, ENGINEERING_PATH_PREFIXES);
    const cAsym = (cT.count - eT.count) + (cHits - eHits);
    if (Math.abs(cAsym) >= 2) {
      if (cAsym > 0) {
        const d = splitCreativeDiscipline(titleText, descText, touches);
        return { discipline: d, confidence: d === 'unclassified' ? 0 : 0.6 + Math.min(0.3, cAsym * 0.05) };
      }
      return { discipline: 'engineer', confidence: 0.6 + Math.min(0.3, -cAsym * 0.05) };
    }
    return { discipline: 'unclassified', confidence: 0 };
  }

  // Phase 2 — title was weak. Pull in description + touches.
  const cDescR = scoreText(descText, CREATIVE_TEXT_RULES);
  const eDescR = scoreText(descText, ENGINEERING_TEXT_RULES);
  const cPath = scoreTouches(touches, CREATIVE_PATH_PREFIXES);
  const ePath = scoreTouches(touches, ENGINEERING_PATH_PREFIXES);

  const creative = Math.min(1.0, cT.max + cDescR.max * DESC_WEIGHT + cPath * 0.7);
  const engineering = Math.min(1.0, eT.max + eDescR.max * DESC_WEIGHT + ePath * 0.7);

  if (Math.max(creative, engineering) < PHASE2_MIN_STRENGTH) {
    return { discipline: 'unclassified', confidence: 0 };
  }
  if (Math.abs(creative - engineering) < PHASE2_MIN_MARGIN) {
    return { discipline: 'unclassified', confidence: 0 };
  }
  if (creative > engineering) {
    const d = splitCreativeDiscipline(titleText, descText, touches);
    return { discipline: d, confidence: d === 'unclassified' ? 0 : creative };
  }
  return { discipline: 'engineer', confidence: engineering };
}

module.exports = {
  classifyTaskKind,
  classifyTaskDiscipline,
  buildBlockerVendorRe,
  _resetVendorCacheForTests,
  VALID_KINDS,
  VALID_DISCIPLINES,
  VOTABLE_TASK_STATUSES,
  TASK_FIELD_BOUNDS,
};
