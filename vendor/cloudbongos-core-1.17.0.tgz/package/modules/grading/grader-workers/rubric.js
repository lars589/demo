// src/bongos/grader-workers/rubric.js
//
// Single source for the v4 rubric + thresholds (task 1090, C6). The four worker
// modules (narc / quality / hacker / efficiency) each loaded grader-rubric.json
// with a byte-identical block; this centralizes that load so a bump to the
// rubric drives every per-worker verdict without code edits.
//
// Read DIRECTLY from the JSON file (not via grader.js) to avoid a circular
// require: grader.js -> grader-workers/index.js -> the workers -> here.
const path = require('node:path');
const fs = require('node:fs');

const RUBRIC = JSON.parse(
  fs.readFileSync(path.join(__dirname, '..', 'grader-rubric.json'), 'utf8')
);
const V4 = RUBRIC.v4;
const THRESHOLD = V4.threshold;
const LOW_CONF = V4.low_confidence_threshold;

module.exports = { RUBRIC, V4, THRESHOLD, LOW_CONF };
