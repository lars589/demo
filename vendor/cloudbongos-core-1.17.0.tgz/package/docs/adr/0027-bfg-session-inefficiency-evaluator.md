# 0027 — The BFG session-inefficiency evaluator (auto-post-mortem of builder sessions)

- **Status:** Accepted + Shipped. The build (tasks **6D.1–6D.6**) was completed end-to-end — see the [2026-06-02 session log](../session-logs/<redacted>.md); this ADR is the charter it followed.
- **Date:** 2026-06-02
- **Deciders:** Lars Kristensen (Archon), Claude
- **Track:** `internal` (GDS)
- **Context tasks:** GDS-V4 **[#515](https://example.com/builders#/task/515)** (the capability umbrella) · **[#539](https://example.com/builders#/task/539)** (this design task — ADR + task breakdown only, no implementation; mirrors the design-only shape of [#441](<redacted>.md)).
- **Extends:** [ADR 0024 — Multi-Agent System architecture](<redacted>.md) (the BFG is its Phase 6) · [ADR 0026 — The BFG charter](<redacted>.md) (this adds a **new capability cluster, 6D**, to the BFG's "best building experience" objective) · [ADR 0016 — Trust boundary](<redacted>.md) (narrowly extended — session detail now lives server-side and is BFG-readable across builders) · [ADR 0022 — Secrets policy](0022-secrets-policy.md) (scrubbing on upload). Touches `credit_log` (drachmae), `karma_log`, `builders` (rank + tenure), `task_grades` (the upsert-unique gap), `session_logs`.

## Context

On **2026-06-01** Lars asked for a manual evaluation of the **[#506](https://example.com/builders#/task/506)** session — a one-line welcome-copy fix that burned ~90% of its tokens on process ceremony + footgun recovery rather than the actual change. The post-mortem ([session log](../session-logs/<redacted>.md)) produced three concrete systemic fixes — **[#513](https://example.com/builders#/task/513)** (trivial-diff fast-path for the grader), **[#514](https://example.com/builders#/task/514)** (self-explaining API error hints), **[#468](https://example.com/builders#/task/468)** (a stale smoke assertion) — plus a security finding (`#526`).

Lars wants that analysis **automated and run across every session**, to surface systemic build-process waste — and, as the inverse, to mine *top performers'* sessions for transferable good practice (the [ADR 0026](<redacted>.md) §6B objective). This ADR is the design; [#506](https://example.com/builders#/task/506) is the **hand-labeled seed/validation corpus**.

### The substrate problem (and the decision that resolves it)

The two candidate data sources don't overlap:

- **Claude Code transcripts** (`~/.claude/projects/.../*.jsonl`) carry the rich signal — per-turn token usage, tool calls, `is_error` flags, timings — exactly what the manual [#506](https://example.com/builders#/task/506) read. But they live **local, per-builder**, never on the server.
- **The GDS DB trail** (`session_logs`, `claims`, `task_grades`, `cost_log`) is **cross-builder** but coarse: wall-clock, outcomes, final grade — **no token-level detail**.

Two earlier framings were put to Lars and rejected (see Alternatives): a local-only `/session-review` slash command, and a server-side analyzer. **Lars's decision** resolves the substrate problem directly:

> **At ship time, upload the session's details to the server.** The BFG then runs as a **local Claude Code instance** (as it already does for hygiene, [ADR 0026](<redacted>.md) §6A.1) that **calls the server** to search across *all* sessions and deep-dive the interesting ones. The builder never runs anything — findings come to them.

This is the load-bearing choice: the rich data stops being local, so one cross-builder corpus serves both the waste-hunt and the good-practice mine, and the analysis stays where the BFG already lives (a Claude Code routine), not on the always-on $14/mo droplet.

## Decision

A **new BFG capability cluster — 6D** — built as independently-shippable sub-phases. Four parts to the flow; the builder only ever sees part 4.

### 1. Upload on ship (the keystone — 6D.1)

When `/builder-ship` lands a task, `ship.js` locates the active Claude Code session transcript, **scrubs secrets** ([ADR 0022](0022-secrets-policy.md)), and uploads it to a new server-side `session_records` table. Each record carries the fields Lars named, denormalized for query:

| Field | Source |
|---|---|
| `session_id` | the Claude Code `sessionId` |
| `builder_id` | the shipping builder |
| `task_ids[]` | task(s) shipped from this session |
| `drachmae_earned` | the session's `credit_log` delta |
| `total_tokens` | summed transcript `usage` (input + output + cache) |
| `duration_seconds` | transcript first→last timestamp (or `session_logs`) |
| `started_at` / `ended_at` / `uploaded_at` | timestamps |
| `detail` | the **scrubbed** transcript payload (for deep-dive) |
| `metrics` (jsonb) | derived signals (overhead ratio, tool-error count, footgun flags) — computed at upload or lazily |

**Deduped per `session_id`** (a session that ships multiple tasks uploads once; `task_ids` accumulates). The upload is **fail-safe and non-blocking** — a failed or absent upload must *never* block a ship.

### 2. Store + serve — the query surface (6D.2)

The server stores and serves; it does **no analysis**. Two endpoints over `session_records`:

- **Search/filter** by *session* fields (`drachmae_earned`, `total_tokens`, `duration`, the derived metrics) **and joined `builders` fields** — **tenure** (`now − created_at`), **rank**, **karma**, **drachmae** (`total_credits`). So queries like *"rank = Xenos AND tenure < 7d AND overhead > 0.7"* (onboarding friction) or *"karma top-decile"* (good-practice mining) are expressible against one corpus.
- **Fetch one session's** full scrubbed detail for deep-dive.

Cross-builder reads are gated to the **BFG service principal** ([ADR 0026](<redacted>.md) §6B posture — the *exact principal identity*, not rank) and write an **`audit_log` row per read**. A builder may always read their *own* sessions self-serve. Filtering is plain SQL/keyword **for now** (semantic/vector deferred, consistent with [ADR 0024](<redacted>.md)/[0026](<redacted>.md)).

### 3. The BFG routine — local Claude Code, search → deep-dive → reason (6D.3)

A new BFG sub-routine, running as a **local Claude Code instance** (the [`architect-audit.js`](../../scripts/gds/architect-audit.js) / §6A.1 pattern — read-only subagent + deterministic side-effects). It:

1. calls the 6D.2 search to rank **interesting** sessions — high ceremony-vs-work ratio, dense tool-errors, ran-over-estimate, failed-grade, re-claim thrash (and the inverse: high-karma top performers worth learning from);
2. fetches + deep-dives them, computing the two analyses below;
3. writes a `docs/audits/bfg-session-eval-<date>.md` report. **Read-only — it proposes, never mutates.**

**The ceremony-vs-work ratio.** Each assistant turn / tool-call classifies into:
- **work** — edits to files that ended up in the shipped diff; problem-solving toward that diff;
- **ceremony** — GDS claim/ship/release/status/grade plumbing; reading methodology; session-log writing;
- **recovery** — tool errors + the turns spent recovering; retries; re-grades; guess-and-retry.

Ratio = work tokens ÷ total (with a parallel turn-based ratio). [#506](https://example.com/builders#/task/506) ≈ **10 / 90**.

**The footgun taxonomy** (the detector set):
1. repeated tool failures (same tool + error class, ≥2×);
2. empty/trivial-diff grade (panel spawned on no/near-no diff);
3. claim-consumed-on-fail (claim released/abandoned after a failed grade);
4. stale-test red herring (a test/smoke failure whose *fix edits the test*, not the feature);
5. **guess-and-retry on API enums/routes** (GDS API 4xx → retry with changed params) → produced **[#514](https://example.com/builders#/task/514)**;
6. **heavyweight-pipeline-on-trivial-change** (full grader panel on a sub-N-line / copy-only diff) → produced **[#513](https://example.com/builders#/task/513)**.

### 4. Findings to the builder (6D.4)

- **Systemic** build-process fixes → `idea_inbox` rows / backlog tasks (conservative grouping, like §6A.1 and the manual [#506](https://example.com/builders#/task/506) → [#513](https://example.com/builders#/task/513)/[#514](https://example.com/builders#/task/514)/[#468](https://example.com/builders#/task/468)).
- **Per-builder** process findings → delivered to *that* builder via the [ADR 0026](<redacted>.md) **§6C transparent, BFG-authored, attributed note** path (builder-visible, deletable, audit-logged) — for the builder to **evaluate and act on**. The §6C write path is built by 0026's 6C.1/6C.2; 6D.4 wires session findings *into* it and degrades to inbox-only until 6C exists.

The builder-field querying does double duty: it powers the **waste hunt** *and* the charter's **6B good-practice mining** — one corpus, both objectives.

### Trust & privacy (load-bearing)

Uploading session detail means transcripts **now live server-side and are BFG-readable across builders** — today they are local-only. This is a deliberate, narrow extension of [ADR 0016](<redacted>.md), in the same family as [ADR 0026](<redacted>.md)'s cross-builder paths. The safeguards are **enforcement requirements, not prose**:

- **Secrets scrubbed on upload** ([ADR 0022](0022-secrets-policy.md)) — known secret patterns + the builder's own env values redacted *before* the transcript leaves the machine; covered by a test.
- **BFG-principal-only** cross-builder reads (a builder reads only their own self-serve); **`audit_log` row per cross-builder read**.
- **Retention window** — sessions are pruned after a bounded period; the corpus is not hoarded forever.
- **Builder-visible** — a builder can see, and request deletion of, their uploaded sessions.

> **Non-goal — not covert surveillance.** This is not a tool for secretly ranking or punishing builders. Findings are transparent and attributed (the §6C posture). This mirrors [ADR 0026](<redacted>.md)'s explicit rejection of covert "nightmares": the steering is honest, visible, and reversible.

### Validation — the [#506](https://example.com/builders#/task/506) regression gate (6D.5)

The design must reproduce the hand-labeled [#506](https://example.com/builders#/task/506) findings. A scrubbed excerpt of the 2026-06-01 transcript is checked in as a seed fixture; the evaluator must surface:

| [#506](https://example.com/builders#/task/506) manual finding | Detector |
|---|---|
| heavyweight pipeline on a trivial change | footgun [#6](https://example.com/builders#/task/6) → **[#513](https://example.com/builders#/task/513)** |
| guessing at API errors + retrying | footgun [#5](https://example.com/builders#/task/5) → **[#514](https://example.com/builders#/task/514)** |
| stale test sent diagnosis down a rabbit hole | footgun `#4` → **[#468](https://example.com/builders#/task/468)** |
| ~90% of tokens on ceremony | the ceremony-vs-work ratio |

This is the regression gate: classifier/detector changes must keep finding the known issues.

### Phase plan (created as backlog tasks by [#539](https://example.com/builders#/task/539), children of [#515](https://example.com/builders#/task/515))

| Sub-phase | GDS task | Scope | Earns it |
|---|---|---|---|
| **6D.1** | [#540](https://example.com/builders#/task/540) | Upload-on-ship: `session_records` table + POST route + secret-scrub + `ship.js` wiring | The corpus exists; everything depends on it. Ship first. |
| **6D.2** | [#541](https://example.com/builders#/task/541) | Search/query API (session + joined builder fields) + fetch-detail; principal-gated + audited | The corpus is queryable along both waste and good-practice axes. |
| **6D.3** | [#542](https://example.com/builders#/task/542) | BFG local routine: search → deep-dive → ceremony-vs-work + footguns → report | The [#506](https://example.com/builders#/task/506) post-mortem becomes a standing, automatic capability. |
| **6D.4** | [#543](https://example.com/builders#/task/543) | Findings delivery: `idea_inbox` (systemic) + §6C note (per-builder) | Findings reach the builder transparently; loop closes. |
| **6D.5** | [#544](https://example.com/builders#/task/544) | [#506](https://example.com/builders#/task/506) validation/regression harness (seed fixture) | The evaluator provably reproduces the hand-labeled case. |
| **6D.6** | [#545](https://example.com/builders#/task/545) | *(optional)* append-only grade-attempt logging | Re-grade thrash becomes countable — *only if the signal earns its keep.* |

Each sub-phase answers "is this earning its tokens?" before the next — the Musk gate, same as [ADR 0024](<redacted>.md)/[0026](<redacted>.md).

## Alternatives considered

- **Local-only `/session-review` slash command (rejected by Lars).** The first proposal kept the rich data local and had the builder run the review on demand. Rejected: *"I want the average builder to not think about this"* — and a local tool can never see cross-builder sessions. Upload-on-ship + a server corpus replaces it.
- **Server-side analyzer (rejected by Lars).** The second proposal ran the analysis on the server. Rejected: the BFG **runs as a local Claude Code instance**; the server only *stores and serves*. This keeps expensive LLM reasoning off the always-on droplet and matches the BFG's existing identity (a `SKILL.md` routine).
- **Digest-only upload (deferred).** Store just the computed metrics, not the transcript. Rejected for now because the BFG must be able to deep-dive with *new* criteria later — a digest freezes the analysis. Full (scrubbed) transcript chosen, bounded by a retention window. Revisit if storage cost bites.
- **Vector / semantic search over the corpus (deferred).** Consistent with [ADR 0024](<redacted>.md)/[0026](<redacted>.md)'s "vector store deferred." Plain SQL + keyword "for now" (Lars's word).
- **Counting re-grade thrash from `task_grades` (not possible).** `task_grades.task_id` is `UNIQUE` — only the *final* grade survives, so the number of grade attempts isn't persisted. 6D.6 optionally adds append-only grade-attempt logging if that signal proves wanted.

## Consequences

**Good:**
- The [#506](https://example.com/builders#/task/506) post-mortem becomes a **standing, automatic** capability; systemic waste surfaces as `idea_inbox`/tasks without anyone asking.
- **One queryable corpus** serves both the waste hunt and [ADR 0026](<redacted>.md) §6B good-practice propagation.
- Analysis stays a local Claude Code routine — **no new always-on cost** on the droplet.

**Bad / accepted:**
- **Session transcripts now live server-side** — a new sensitive store to secure, scrub, and retain. Mitigated by upload-time scrubbing + principal-gating + audit + retention + builder visibility.
- **The BFG can read across builders' sessions** — the audit trail is what keeps that legible (same residual risk [ADR 0026](<redacted>.md) accepted for memory).
- **`ship.js` gains an upload step** — it must be fast, non-blocking, and fail-safe; a broken upload can never block a ship.

**Reversibility:**
- 6D.1 is additive — stop uploading and drop `session_records` to revert.
- The BFG routine is a deletable `SKILL.md`.
- The retention window auto-prunes the corpus.

## Lineage — GDS-V4 measurement-honesty amendments

The 2026-06-12 friction analysis (1,349 session records, V4.R00) showed the
evaluator's numbers did not reflect real friction. Three GDS-V4 fixes correct it
(criterion `bfg-measures-what-hurts`):

- **Harness-retry split ([#959](https://example.com/builders#/task/959)).** Harness guardrail rejections — an Edit/Write before the file was Read (`File has not been read yet`) or a foreground `Blocked: sleep` — were counted in `tool_error_count`, inflating it and letting benign retries top the `order=tool_errors` ranking. `buildSessionDigest` now classifies them into a separate `harness_retry_count`, leaving `tool_error_count` NET. Because `sessions/search` orders on `metrics->>'tool_error_count'`, the ranking uses the net figure with no route change.
- **Wrong-path / worktree footgun ([#960](https://example.com/builders#/task/960)).** `detectFootguns` gained `wrong_path_worktree` (the corpus's [#1](https://example.com/builders#/task/1) error class, 84 hits) + a `FINDING_TEMPLATES` entry, so the worktree↔main-checkout split surfaces as an actionable idea_inbox finding.
- **Turn-weighted overhead ([#961](https://example.com/builders#/task/961)).** Token weighting scored 150M-token cache-heavy marathons as 97–99% "work" while the turn sequence was hours of ceremony. `computeOverhead` now also reports a turn-weighted ratio, and the verdict is driven off it.

## References

- [ADR 0024 — Multi-Agent System architecture](<redacted>.md) — the BFG is Phase 6
- [ADR 0026 — The BFG charter](<redacted>.md) — 6D extends the "best building experience" objective; §6C is the findings-delivery path
- [ADR 0016 — Trust boundary](<redacted>.md) — the rule this narrowly extends
- [ADR 0022 — Secrets policy](0022-secrets-policy.md) — upload-time scrubbing
- [2026-06-01 #506 post-mortem session log](../session-logs/<redacted>.md) — the hand-labeled seed corpus
- `migrations/003_pms.sql` (`credit_log`, `session_logs`, `claims`), `migrations/016_pms_task_grades.sql` (the upsert-unique grade), `migrations/040_builder_karma.sql` (karma)
- GDS tasks: **[#515](https://example.com/builders#/task/515)** (umbrella) · **[#539](https://example.com/builders#/task/539)** (this design) · **[#540](https://example.com/builders#/task/540)–[#545](https://example.com/builders#/task/545)** (6D.1–6D.6)
