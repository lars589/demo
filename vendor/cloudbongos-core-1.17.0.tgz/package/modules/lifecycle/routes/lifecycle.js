'use strict';

// The lifecycle module's kernel PORT registration (BV1.R86 / ADR 0093 §3).
//
// lifecycle exposes its build-state-machine surface (the retired createTask /
// VOTABLE_TASK_STATUSES / tallyPeerVotes leaks + classifyTaskKind + the work-
// tracking reads) as the `lifecycle` kernel PORT. CORE files that must NOT import
// a module resolve it instead:
//   • the core read routes (routes/public.js, routes/me.js, routes/builders.js) —
//     the version/ship feed, per-builder claims/grades, and the Archon roster;
//   • core cascade-dispatch.js — classifyTaskKind (the dormant System-3 lib);
//   • the ideas/discord/autonomy modules — createTask (newcomer-restock + bug
//     filing), VOTABLE_TASK_STATUSES (discord-reaction), tallyPeerVotes (the
//     autonomy routine-timers poller) — module↔module via the kernel seam.
// All reach lifecycle WITHOUT importing it by resolving this port (ADR 0093 §3:
// the last leak deletion). The provider IS the lifecycle module's surface
// (modules/lifecycle/lifecycle.js).
//
// Why a route factory for a routeless capability: `mountModuleRoutes` (the loader)
// is the one boot hook that runs BOTH in the live server AND whenever a test
// rebuilds the GDS router — so registering here (not in a poller) keeps the port
// present for the route-building tests too. Registration is hasProvider-guarded so
// re-instantiation never trips the seam's single-provider duplicate guard.
// (Mirrors modules/economy/routes/reward.js.)

const express = require('express');
const api = require('../../../src/module-api');
const lifecycle = require('../lifecycle');

function registerSeams() {
  if (!api.hasProvider('lifecycle')) {
    api.registerProvider('lifecycle', lifecycle);
  }
}

module.exports = function buildLifecycleRouter() {
  registerSeams();
  // No HTTP surface — the lifecycle capability is a pure kernel port. The empty
  // router is only the loader's contributes.routes mount vehicle; returning a
  // valid express.Router() keeps mountModuleRoutes' `router.use(sub)` happy
  // without exposing any endpoint.
  return express.Router();
};
