-- economy_001_fix_gds_shipper_description.sql — task #1679.
--
-- Two data fixes for the broken-achievements bug, both idempotent and safe to
-- re-run / no-op on a fresh instance.
--
-- 1) gds-shipper DESCRIPTION still pointed at src/pms/ / scripts/pms/, paths that
--    ceased to exist in the PMS -> GDS rename (V3.R01, migration 019). The
--    EVALUATOR was re-pointed at the time but the seeded description was missed
--    (idea 50). Correct it so the hall, CLI banners, and locked-progress hints
--    describe what actually unlocks the badge.
--
-- 2) BACKFILL the achievements that should already be unlocked. Until this task,
--    the dominant ship path (confirmTask / --skip-grade / grader_bypass) never
--    evaluated achievements, and breaking-the-100c-bar was a boundary check on a
--    credit branch the session reward never hit — so the board was effectively
--    dead (e.g. nobody held breaking-the-100c-bar despite multiple builders far
--    past 100c). The forward fix (state-based reconcile on every ship path) heals
--    builders on their next ship; this backfills everyone NOW, on deploy, so the
--    hall is correct immediately.
--
--    The predicates here are a ONE-SHOT SQL mirror of modules/economy/
--    achievements.js STATE_EVALUATORS. A migration is immutable and runs once, so
--    this copy cannot drift the way the THREE long-lived copies did (idea 44/50);
--    the JS list remains the single forward source of truth. Streak-3/streak-7
--    are intentionally OMITTED here (their timezone-aware consecutive-day math is
--    not worth duplicating in SQL) — they backfill via the JS reconcile on a
--    builder's next ship, or immediately via `node scripts/gds/diagnose-achievements.js --apply`.
--
--    Idempotent: ON CONFLICT DO NOTHING means re-running unlocks nothing new, and
--    the credit bonus is inserted ONLY for rows the INSERT actually created
--    (RETURNING), so totals never double-count. The credit_log trigger rolls each
--    bonus into builders.total_credits exactly as a live unlock would.

UPDATE achievements
   SET description = 'Ship a task whose touches[] include src/bongos/ or scripts/gds/.'
 WHERE id = 'gds-shipper';

WITH eligible AS (
  -- first-claim: has ever claimed
  SELECT b.id AS builder_id, 'first-claim'::text AS achievement_id
    FROM builders b
   WHERE EXISTS (SELECT 1 FROM claims c WHERE c.builder_id = b.id)
  UNION
  -- first-ship: has ever shipped a claim
  SELECT DISTINCT c.builder_id, 'first-ship'
    FROM claims c
   WHERE c.outcome = 'shipped'
  UNION
  -- art-pipeline-shipper: a shipped task touching art/
  SELECT DISTINCT c.builder_id, 'art-pipeline-shipper'
    FROM claims c JOIN tasks t ON t.id = c.task_id
   WHERE c.outcome = 'shipped'
     AND EXISTS (SELECT 1 FROM unnest(t.touches) AS p WHERE p LIKE 'art/%')
  UNION
  -- gds-shipper: a shipped task touching src/bongos/ or scripts/gds/
  SELECT DISTINCT c.builder_id, 'gds-shipper'
    FROM claims c JOIN tasks t ON t.id = c.task_id
   WHERE c.outcome = 'shipped'
     AND EXISTS (SELECT 1 FROM unnest(t.touches) AS p
                  WHERE p LIKE 'src/bongos/%' OR p LIKE 'scripts/gds/%')
  UNION
  -- first-parallel-claim: two shipped claims whose windows overlap
  SELECT DISTINCT a.builder_id, 'first-parallel-claim'
    FROM claims a JOIN claims b2
      ON b2.builder_id = a.builder_id AND b2.id <> a.id
   WHERE a.outcome = 'shipped' AND a.released_at IS NOT NULL
     AND b2.outcome = 'shipped' AND b2.released_at IS NOT NULL
     AND tstzrange(a.claimed_at, a.released_at) && tstzrange(b2.claimed_at, b2.released_at)
  UNION
  -- breaking-the-100c-bar: at or past 100 total credits
  SELECT b.id, 'breaking-the-100c-bar'
    FROM builders b
   WHERE b.total_credits >= 100
  UNION
  -- subtractor: >= 3 net-negative ship bonuses
  SELECT cl.builder_id, 'subtractor'
    FROM credit_log cl
   WHERE cl.reason = 'ship.net_negative'
   GROUP BY cl.builder_id
  HAVING COUNT(*) >= 3
),
ins AS (
  INSERT INTO builder_achievements (builder_id, achievement_id, unlocked_at, unlocked_by_task_id)
  SELECT builder_id, achievement_id, now(), NULL FROM eligible
  ON CONFLICT (builder_id, achievement_id) DO NOTHING
  RETURNING builder_id, achievement_id
)
INSERT INTO credit_log (builder_id, task_id, delta, reason, recorded_at)
SELECT ins.builder_id, NULL, a.credit_bonus, 'achievement.' || ins.achievement_id, now()
  FROM ins JOIN achievements a ON a.id = ins.achievement_id
 WHERE a.credit_bonus > 0;
