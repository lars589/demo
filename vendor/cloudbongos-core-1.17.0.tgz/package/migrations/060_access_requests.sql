-- 060_access_requests.sql — onboarding cold-start (2026-05-30).
--
-- A brand-new person who wants to build has a chicken-and-egg problem: the code
-- lives in a PRIVATE GitHub repo, so they can't do anything until an Archon adds
-- them as a collaborator. Until now there was no way to ask — the welcome copy
-- said "an Archon will give thee the link" with no mechanism behind it, and the
-- Archon was never notified. This table is the request queue that closes that gap.
--
-- It is written by an UNAUTHENTICATED visitor (POST /api/gds/access-requests is
-- the one public write on the GDS) — by definition the requester is outside the
-- system and has no builder row yet. The only thing we capture is what an Archon
-- needs to send the GitHub collaborator invite: the GitHub username, an optional
-- display name, and an optional note. The global IP rate-limiter guards the
-- endpoint against spam; a partial unique index stops a username from piling up
-- duplicate open requests.
--
-- Lifecycle: pending → invited | dismissed (terminal; the row stays as the audit
-- trail). 'invited' = an Archon sent the GitHub invite. 'dismissed' = declined /
-- spam / duplicate. resolved_by_builder_id records which Archon acted.

CREATE TABLE IF NOT EXISTS access_requests (
  id                       bigserial PRIMARY KEY,
  github_login             text NOT NULL,
  display_name             text,
  note                     text,
  status                   text NOT NULL DEFAULT 'pending'
                             CHECK (status IN ('pending', 'invited', 'dismissed')),
  resolved_by_builder_id   bigint REFERENCES builders(id),
  resolved_at              timestamptz,
  created_at               timestamptz NOT NULL DEFAULT now()
);

-- Archon queue lookup: "open requests, newest first."
CREATE INDEX IF NOT EXISTS idx_access_requests_pending
  ON access_requests (created_at DESC)
  WHERE status = 'pending';

-- At most one OPEN request per GitHub login (case-insensitive). Historical
-- rows (invited/dismissed) don't conflict, so a username can re-request after
-- a dismissal.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_access_requests_open_per_login
  ON access_requests (lower(github_login))
  WHERE status = 'pending';

INSERT INTO schema_migrations (version) VALUES ('060_access_requests')
  ON CONFLICT (version) DO NOTHING;
