// GDS done_when_criteria helpers (PMS-V2 task #41, bucket E — Auto-versioning).
//
// Companion to src/bongos/version-close.js (task #42, the gate evaluator). This
// module is the read/write surface for the per-version criterion rows; the
// close-flow gate reads those rows but never writes them.
//
// Schema (migration 006_pms_v2.sql §2):
//   done_when_criteria(
//     id bigserial PK,
//     version_id text  FK versions(id),
//     criterion_id text,
//     criterion_md text,
//     satisfied boolean DEFAULT false,
//     satisfied_by_task_id bigint FK tasks(id),
//     checked_at timestamptz,
//     sort_order integer,
//     UNIQUE (version_id, criterion_id)
//   )
//
// Wired in via modules/lifecycle/routes/done-when.js (the loader mounts it,
// BV1.R86). Three endpoints:
//   GET  /api/gds/versions/:id/done-when                — public, 60s cache
//   POST /api/gds/done-when/:criterionId/satisfy        — auth
//   POST /api/gds/done-when/:criterionId/unsatisfy      — auth

const { pool } = require('../../src/module-api');

// -------------------------------------------------------------------------
// Reads
// -------------------------------------------------------------------------

// Return all criteria for a version, ordered by sort_order then criterion_id.
// Returns [] if the version has no criteria (a version without seeded
// criteria is never "ready to close" — see version-close.js).
async function listCriteria(versionId) {
  if (!versionId || typeof versionId !== 'string') {
    throw new Error('listCriteria: versionId required');
  }
  const { rows } = await pool.query(
    `SELECT id, version_id, criterion_id, criterion_md, satisfied,
            satisfied_by_task_id, checked_at, sort_order, goal_id
       FROM done_when_criteria
      WHERE version_id = $1
      ORDER BY sort_order, criterion_id`,
    [versionId]
  );
  return rows;
}

// All goals for a version (ADR 0086 §2), ordered stably. The goal metadata the
// Version → Goals → Criteria rollup groups under — shared by criterionProgress
// and criteriaGroupedByGoal so the goals query lives in one place.
async function listGoalsForVersion(versionId) {
  const { rows } = await pool.query(
    `SELECT id, title, status, scope_modules
       FROM goals
      WHERE version_id = $1
      ORDER BY created_at, id`,
    [versionId]
  );
  return rows;
}

// Lightweight goal grouping for the public progress surface (the dashboard /
// GET /versions/:id/done-when): the flat criteria PLUS the same criteria grouped
// under their goals, with no per-task rollup (that richer shape is
// criterionProgress, behind GET /versions/:id/progress + the /status skill).
async function criteriaGroupedByGoal(versionId) {
  const [criteria, goalRows] = await Promise.all([
    listCriteria(versionId),
    listGoalsForVersion(versionId),
  ]);
  return { criteria, goals: buildGoals(goalRows, criteria) };
}

// Fetch a single criterion by primary key. Used by the routes to validate
// existence before writing (so a missing id returns 404 instead of a silent
// no-op UPDATE).
async function getCriterion(criterionId) {
  const id = Number(criterionId);
  if (!Number.isFinite(id)) return null;
  const { rows } = await pool.query(
    `SELECT id, version_id, criterion_id, criterion_md, satisfied,
            satisfied_by_task_id, checked_at, sort_order, goal_id
       FROM done_when_criteria
      WHERE id = $1`,
    [id]
  );
  return rows[0] ?? null;
}

// The criterion review queue (ADR 0086 §6 / BV1.R63). Returns every criterion
// that has auto-flagged "met — pending review": NOT yet satisfied, has ≥1 linked
// task (via task_criteria), and EVERY linked task has shipped. Purely DERIVED from
// task_criteria + ship status — no stored column, no manual propose step (the same
// derivation buildCriterionProgress exposes per-criterion, expressed here as a
// focused query so /goal-review can list the whole queue in one call, optionally
// scoped to one version).
//
// Each row carries its goal (title/status) and `is_last_in_goal` — true when this
// is the goal's ONLY remaining unsatisfied criterion, so confirming it will
// auto-achieve the goal (the skill warns the reviewer). A criterion with no goal
// (goal_id NULL) reports is_last_in_goal=false — it can complete no goal.
//
// deps.pool honours the #538 test seam (NODE_ENV==='test' only) so the SQL shape
// is unit-testable with a fake client.
async function listPendingReviewCriteria({ versionId = null } = {}, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `WITH pending AS (
       SELECT c.id, c.version_id, c.criterion_id, c.criterion_md, c.goal_id, c.sort_order,
              count(tc.task_id)::int AS task_total
         FROM done_when_criteria c
         JOIN task_criteria tc ON tc.criterion_id = c.id
         JOIN tasks t          ON t.id = tc.task_id
        WHERE c.satisfied = false
        GROUP BY c.id
       HAVING count(*) FILTER (WHERE t.status <> 'shipped') = 0
     ),
     goal_unsat AS (
       SELECT goal_id, count(*)::int AS unsatisfied
         FROM done_when_criteria
        WHERE satisfied = false AND goal_id IS NOT NULL
        GROUP BY goal_id
     )
     SELECT p.id, p.version_id, p.criterion_id, p.criterion_md, p.goal_id,
            p.sort_order, p.task_total,
            g.title  AS goal_title,
            g.status AS goal_status,
            COALESCE(gu.unsatisfied = 1, false) AS is_last_in_goal
       FROM pending p
       LEFT JOIN goals g       ON g.id = p.goal_id
       LEFT JOIN goal_unsat gu ON gu.goal_id = p.goal_id
      WHERE $1::text IS NULL OR p.version_id = $1
      ORDER BY p.version_id, p.sort_order, p.id`,
    [versionId]
  );
  return rows;
}

// Roll up every criterion for a version together with the tasks that gate it
// (via the task_criteria join table, migration 055) and a status breakdown.
// This is the read behind GET /api/gds/versions/:id/progress and the /status
// skill — it answers "what's left for criterion Cn?" in one query instead of
// the ~10-call prose archaeology that motivated #435.
//
// Returns:
//   {
//     version_id,
//     criteria: [{
//       cnum,                 // 1-based position (the "C8" the prose uses)
//       id, criterion_id, criterion_md, satisfied,
//       tasks: [{ id, title, status }],   // ordered by task id
//       counts: { total, shipped, remaining, <per-status>… },
//       remaining: [{ id, title, status }],  // the not-yet-shipped tasks
//     }],
//     unattributed_tasks: N,  // tasks in this version not linked to any criterion
//   }
//
// `cnum` is computed live from the same (sort_order, criterion_id) ordering the
// backfill used, so it stays correct even if criteria are added or reordered.
async function criterionProgress(versionId) {
  if (!versionId || typeof versionId !== 'string') {
    throw new Error('criterionProgress: versionId required');
  }
  // The two reads are independent — run them concurrently. The second counts
  // tasks in this version that no criterion claims, so /status can be honest
  // about coverage. It uses idx_tasks_version_status (version_id leading).
  const [{ rows }, { rows: unattr }, goalRows] = await Promise.all([
    pool.query(
      `WITH ranked AS (
         SELECT id, version_id, criterion_id, criterion_md, satisfied, goal_id,
                ROW_NUMBER() OVER (ORDER BY sort_order, criterion_id) AS cnum
           FROM done_when_criteria
          WHERE version_id = $1
       )
       SELECT r.cnum, r.id, r.criterion_id, r.criterion_md, r.satisfied, r.goal_id,
              t.id AS task_id, t.title AS task_title, t.status AS task_status
         FROM ranked r
         LEFT JOIN task_criteria tc ON tc.criterion_id = r.id
         LEFT JOIN tasks t          ON t.id = tc.task_id
        ORDER BY r.cnum, t.id`,
      [versionId]
    ),
    pool.query(
      `SELECT count(*)::int AS n
         FROM tasks t
        WHERE t.version_id = $1
          AND NOT EXISTS (SELECT 1 FROM task_criteria tc WHERE tc.task_id = t.id)`,
      [versionId]
    ),
    // Goals for this version (ADR 0086 §2 — the tier criteria re-parent under).
    // ALL goals, including any with no criteria yet (they render gracefully).
    listGoalsForVersion(versionId),
  ]);

  return buildCriterionProgress(versionId, rows, unattr[0]?.n ?? 0, goalRows);
}

// Group the flat criteria under their goals (Version → Goals → Criteria, ADR 0086
// §2). Pure: takes the goal rows (id, title, status, scope_modules) + the built
// criteria, returns the goals[] each carrying its criteria in cnum order. A goal
// with no criteria is kept (renders gracefully). Criteria whose goal_id matches no
// goal row (shouldn't happen post-backfill, but defended) collect under a trailing
// id:null "(ungrouped)" bucket so nothing silently vanishes from the rollup.
function buildGoals(goalRows, criteria) {
  const byGoal = new Map();
  for (const g of goalRows || []) {
    byGoal.set(g.id, {
      id: g.id,
      title: g.title,
      status: g.status,
      scope_modules: g.scope_modules || [],
      criteria: [],
    });
  }
  const ungrouped = [];
  for (const c of criteria) {
    const g = c.goal_id != null ? byGoal.get(c.goal_id) : null;
    (g ? g.criteria : ungrouped).push(c);
  }
  const goals = [...byGoal.values()];
  if (ungrouped.length) {
    goals.push({ id: null, title: '(ungrouped)', status: 'open', scope_modules: [], criteria: ungrouped });
  }
  return goals;
}

// Pure aggregation half of criterionProgress, split out so it's unit-testable
// without a database (tests/criterion_progress.mjs). Takes the flat joined rows
// from the query above — each row is one (criterion, task) pair, and a criterion
// with no linked tasks arrives as a single row with null task_* fields (the
// LEFT JOIN) — and folds them into the per-criterion shape with status counts
// and the not-yet-shipped `remaining` list. Rows are assumed pre-ordered by
// (cnum, task_id); insertion order is preserved.
function buildCriterionProgress(versionId, rows, unattributedCount = 0, goalRows = []) {
  const byCrit = new Map();
  for (const row of rows) {
    let c = byCrit.get(row.id);
    if (!c) {
      c = {
        cnum: Number(row.cnum),
        id: row.id,
        criterion_id: row.criterion_id,
        criterion_md: row.criterion_md,
        satisfied: row.satisfied,
        goal_id: row.goal_id ?? null,
        tasks: [],
      };
      byCrit.set(row.id, c);
    }
    if (row.task_id != null) {
      c.tasks.push({ id: row.task_id, title: row.task_title, status: row.task_status });
    }
  }

  const criteria = [...byCrit.values()].map((c) => {
    const counts = { total: c.tasks.length };
    for (const t of c.tasks) counts[t.status] = (counts[t.status] || 0) + 1;
    const shipped = counts.shipped || 0;
    const remaining = c.tasks.filter((t) => t.status !== 'shipped');
    // Auto-flag (ADR 0086 §6 / BV1.R63): a criterion is "met — pending review"
    // when it has ≥1 linked task and every one has shipped, but it has NOT yet
    // been confirmed (satisfied=false). Purely DERIVED — no stored column, no
    // manual propose step. /goal-review surfaces these for a Metic+ to confirm
    // (→ satisfied) or reject; /status renders the flag inline.
    const pending_review = !c.satisfied && c.tasks.length > 0 && remaining.length === 0;
    return { ...c, counts: { ...counts, shipped, remaining: remaining.length }, remaining, pending_review };
  });

  // Version → Goals → Criteria (ADR 0086 §2). A version is "done" when it HAS
  // goals and every one of them is achieved (an empty-goal version is not done).
  const goals = buildGoals(goalRows, criteria);
  const goalsTotal = goals.length;
  const goalsAchieved = goals.filter((g) => g.status === 'achieved').length;
  const versionDone = goalsTotal > 0 && goalsAchieved === goalsTotal;

  return {
    version_id: versionId,
    criteria,
    goals,
    goals_total: goalsTotal,
    goals_achieved: goalsAchieved,
    version_done: versionDone,
    unattributed_tasks: unattributedCount,
  };
}

// -------------------------------------------------------------------------
// Writes
// -------------------------------------------------------------------------

// Flip a criterion to satisfied=true. checked_at is set to now() so the
// status page can show when the criterion was checked off. satisfiedByTaskId
// is optional; pass it when the operator can name the ship-task that
// fulfilled the criterion (UI improvement, not required by the gate).
//
// Returns the updated row, or null if no row matched.
async function markCriterion(criterionId, satisfiedByTaskId = null) {
  const id = Number(criterionId);
  if (!Number.isFinite(id)) return null;
  const taskId =
    satisfiedByTaskId == null || satisfiedByTaskId === ''
      ? null
      : Number(satisfiedByTaskId);
  if (taskId != null && !Number.isFinite(taskId)) {
    throw new Error('markCriterion: satisfiedByTaskId must be numeric');
  }
  const { rows } = await pool.query(
    `UPDATE done_when_criteria
        SET satisfied             = true,
            satisfied_by_task_id  = $2,
            checked_at            = now()
      WHERE id = $1
      RETURNING id, version_id, criterion_id, criterion_md, satisfied,
                satisfied_by_task_id, checked_at, sort_order, goal_id`,
    [id, taskId]
  );
  return rows[0] ?? null;
}

// Flip a criterion back to satisfied=false. Used for corrections — e.g. a
// criterion was marked done in error, or the work needed to be redone. The
// satisfied_by_task_id pointer is cleared so it doesn't lie; checked_at is
// kept (as an audit trail of when the flip happened).
//
// Returns the updated row, or null if no row matched.
async function unmarkCriterion(criterionId) {
  const id = Number(criterionId);
  if (!Number.isFinite(id)) return null;
  const { rows } = await pool.query(
    `UPDATE done_when_criteria
        SET satisfied             = false,
            satisfied_by_task_id  = NULL,
            checked_at            = now()
      WHERE id = $1
      RETURNING id, version_id, criterion_id, criterion_md, satisfied,
                satisfied_by_task_id, checked_at, sort_order`,
    [id]
  );
  return rows[0] ?? null;
}

module.exports = {
  listCriteria,
  listGoalsForVersion,
  criteriaGroupedByGoal,
  getCriterion,
  listPendingReviewCriteria,
  criterionProgress,
  buildCriterionProgress,
  buildGoals,
  markCriterion,
  unmarkCriterion,
};
