# Failed-ship recovery proof (V4.R38)

**Criterion:** `failed-ship-never-strands` — V4.R38, cross-refs V4.R03 + V4.R08.

This document is the live transcript proof that both failure modes — working-tree-dirty preflight abort and grade fail — leave the task recoverable in ≤1 command, and that `claim_consumed_on_fail` does **not** fire.

---

## Setup

A throwaway staging task ([task 1666](https://example.com/builders#/task/1666)) was created for this walkthrough. It held claim `#1397`, touches `docs/`, and had a single committed change (`docs/architecture.md +2 lines`).

---

## Failure mode 1 — working-tree-dirty (drift fail)

The working tree was dirtied with an uncommitted tracked change before attempting ship:

```
$ echo "# draft" >> docs/architecture.md
$ git status --short
 M docs/architecture.md

$ node scripts/gds/ship.js 1666 --no-surprise
Verifying claim #1397 on task #1666: V4.R38 staging — throwaway proof task
Preflight (working tree + branch freshness)...
  preflight: working tree has uncommitted tracked changes:
    - docs/architecture.md
  Stage + commit these (or revert them) before shipping.
Ship aborted: working-tree-dirty. No claim resolved, no credits awarded.
```

**Result:** task stayed at `active`, claim `#1397` **intact** — not consumed. Recovery: clean the working tree and re-run `ship.js 1666`. Zero extra steps; no re-claim needed.

---

## Failure mode 2 — grade fail (claim consumed, task stranded at `completed`)

The preflight was cleared. Claim resolution was performed (simulating ship.js step 1) directly via the API to land the task at `completed` and consume the claim:

```
POST /api/gds/claims/1397/resolve   → taskStatus: "completed"
```

A failing grade was then POSTed (score 3/10, `passed: false`):

```
POST /api/gds/tasks/1666/grade  { passed: false, score: 3 }
                                → taskStatus: "completed", creditsAwarded: 0
```

At this point: task at `completed`, claim `#1397` consumed, no active claim on 1666.

**Active claims after grade fail:** `#1210, #974` — claim `#1397` is gone.

### Recovery — the ≤1-command proof

```
$ node scripts/gds/ship.js 1666 --no-surprise
Task #1666 is at 'completed' (grade stalled) and you last held the claim
— resuming the grade (no re-claim needed).
Re-grading task #1666: V4.R38 staging — throwaway proof task (ship after test)
  eligibility: you last held this claim (owner)
```

`evaluateResumeAction` (V4.R03, task 941) detected `completed` + last-claim ownership and routed to `resume-grade`. **No "don't have an active claim" error.** `claim_consumed_on_fail` did **not** fire.

The grader ran on the re-grade; it returned another failure (trivial diff, shot errored). The task stayed at `completed`. The builder's path forward remains the same: fix the work, commit, and run `ship.js 1666 --regrade` — still ≤1 command.

---

## V4.R08 — grade-record reuse (unit-test coverage)

The `shouldReuseGrade` predicate (ship.js) and `applyGrade` diff-hash storage (lifecycle/db.js) are covered by 15 unit tests in [`tests/grade_diff_hash.mjs`](../../tests/grade_diff_hash.mjs):

| Test | Branch covered |
|---|---|
| `diffHash` deterministic, hex, null-safe | pure hash helper |
| `shouldReuseGrade` → true: PASS + matching hash | happy-path reuse |
| `shouldReuseGrade` → false: FAIL + same hash | fail never reuses |
| `shouldReuseGrade` → false: PASS + different hash | diff changed → re-grade |
| `shouldReuseGrade` → false: null storedGrade, null hash, no diff_hash | edge cases |
| `applyGrade` stores diff_hash as $10 | DB write |
| `applyGrade` stores null when omitted | backward compat |
| `getTaskGrade` exported | API contract |

End-to-end reuse path (in production, when grader is live): `gradeAndRecord` calls `GET /tasks/:id?include=grade`, checks `shouldReuseGrade(stored, currentHash)`, and on a match re-POSTs the stored PASS result with `reused_from_diff_hash` in signals — skipping the adversarial panel entirely.

> **Note:** The server-side `implausible_pass` guard (confirmed during this walkthrough) correctly rejects direct API attempts to forge a PASS grade, so end-to-end reuse can only be observed with a real grader PASS on an unchanged diff.

---

## Summary

| Failure mode | Claim consumed? | Recovery | Command count |
|---|---|---|---|
| Working-tree-dirty (preflight abort) | **No** — ship aborted before resolve | Fix tree → `ship.js <id>` | 1 |
| Grade fail (completed, claim gone) | Yes — at resolve step | `ship.js <id>` → auto-routes to `resume-grade` | 1 |

`claim_consumed_on_fail` — the session evaluator's footgun detector (regex: `"don't have an active claim" / "no active claim" / "stays at completed"`) — did **not** fire in either case.

Cross-references: V4.R03 ([task 941](https://example.com/builders#/task/941) — `evaluateResumeAction`), V4.R08 ([task 946](https://example.com/builders#/task/946) — diff fingerprint + grade reuse).
