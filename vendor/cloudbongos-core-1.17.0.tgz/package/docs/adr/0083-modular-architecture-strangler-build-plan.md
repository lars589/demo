# ADR 0083 — Practical build plan for the modular architecture (strangler migration)

**Status:** Accepted (2026-06-21) · task [#1405](https://example.com/builders#/task/1405) (BV1.R36) · epic [#1388](https://example.com/builders#/task/1388) (BV1.R34) · spike that produced the design: [#1383](https://example.com/builders#/task/1383) → design research in [`docs/design/modular-architecture/`](../design/modular-architecture/) (5 docs, task [#1401](https://example.com/builders#/task/1401))

**Amended by:** [ADR 0091](<redacted>.md) (2026-06-26, BONGOS-V1 C7) — extends this strangler from the four *feature* modules into the **core itself**: bounds the kernel as an enumerated file roster (the "~3.5k-LOC kernel" this ADR kept referencing), defines the per-domain `db.js` carve mechanism, and classifies what the `src/module-api.js` doorway may expose. Nothing here is reversed; 0091 makes "the kernel" and "carve `db.js` per-domain" concrete.

**Builds on:** [ADR 0062](<redacted>.md) (instance/model decoupling — the core↔host split, §4 module registry, §5 module-owned migrations, §9 fitness functions), [ADR 0061](<redacted>.md) (context layers / nested CLAUDE.md), [ADR 0016](<redacted>.md) (server-enforced rank boundary), [ADR 0043](<redacted>.md) (protected paths), [ADR 0049](<redacted>.md) (`touches[]` advisory).

> **Numbering reconciliation (read this first).** The design docs, the epic [#1388](https://example.com/builders#/task/1388), and task [#1389](https://example.com/builders#/task/1389) all refer to the project-extensible module system as **"ADR 0080"**. That number was taken by the LLM-cache transport ADR ([ADR 0080](<redacted>.md)) before the module-system ADR was written — the same `0079→0081` collision class recorded in project memory. **The module-system decision record is THIS file, ADR 0083.** Where the design docs or those tasks say "ADR 0080 (module system / plugin API)", read "ADR 0083". ADR 0080 is unrelated (it is the LLM cache).

---

## Context

The modular architecture has been **scoped** — five research/design documents under [`docs/design/modular-architecture/`](../design/modular-architecture/) settle *what* to build and *why*. This ADR settles **how we practically build it**: the concrete, sequenced, CI-guarded migration, mapped 1:1 onto claimable GDS tasks.

The design's load-bearing conclusions (not re-argued here — see the design docs):

1. **Reorganize, don't rewrite.** The foundation (trust boundary, GDS ship/grade/deploy pipeline, grader, ~143 migrations) is *sound*; the filing (fused game/core, a ~5.3k-LOC shared `db.js`, flat routes, inline `if (isModuleEnabled())` gates, hardcoded brand strings) is *wrong*. Rewrite when the foundation is wrong; reorganize when the filing is wrong ([01 §5](../design/modular-architecture/01-architecture.md)).
2. **Modularity is one axis of four.** Move *only* modularity (how code is organized). **Stay** single-package, single-process, no-bundler ([01 §1](../design/modular-architecture/01-architecture.md)). Each "stay" has a clean future fork (marketplace → packages; untrusted modules → processes; a UI needing a build → that module owns its build) that this plan does not foreclose.
3. **Boundaries are held by CI fitness functions, not discipline.** In an AI-built system this is decisive: an agent on a module-scoped task *cannot* silently erode the architecture, because a violation is a red build ([04 §3](../design/modular-architecture/04-module-lifecycle.md)).
4. **The roster is ~16 modules + a ~3.5k-LOC kernel**, drawn from a `require()`-graph scan, not intuition ([02](../design/modular-architecture/02-module-map.md)). Sequence **coarse → medium**, stop before fine; **never cut through the lifecycle state machine**.
5. **Modules talk through kernel-mediated seams** (ports + events), never by importing each other ([04 §1](../design/modular-architecture/04-module-lifecycle.md)).

### What already exists (grounded at `cc8a5e0` / `494d1d77`)

The migration is **moving files into `modules/<key>/` and replacing inline gates with a loader** — not inventing the flag layer. The seeds are already in place:

| Seed | Where | Status |
|---|---|---|
| A module registry with a `contributes` map | `src/modules.js` (~240 LOC): `isModuleEnabled`, `enabledDisciplines`, `clientModules`, `loadModules` | **closed** — a hardcoded `KNOWN_MODULES` set of four; the loader opens it |
| Per-instance enablement config | `config/modules.json` (OTB: all four on) over `config/modules.neutral.json` (vanilla: all off) | works; loader keeps reading it |
| Inline mount gates (the lines a loader DELETES) | `server.js:139-143,176-178,186-191` (game rooms, world precreate, discord bot); `src/bongos/routes.js:122-123` (dev-box + discord routers); `src/bongos/routes/instance.js:119` (`devBoxEnabled`) | replace with loader-driven mount |
| Client UI gates | `window.__MODULES__` → `public-builders/dom-utils.js:103` `moduleOn()`; consumed in `builders.js`, `settings.js` | keep; loader keeps injecting `__MODULES__` |
| Fitness gate (6 checks) | `scripts/gds/fitness.js` → `tests/fitness.mjs` → the `unit` CI job (`pr-unit-tests.yml`) | **extend** with the boundary checks |
| One thin route mounter | `src/bongos/routes.js` (`buildGdsRouter()`), single mount at `src/bongos/serve-internal.js:155` | loader composes module routers behind auth here |
| Per-module migrations precedent | `migrations/game/` applied enabled-gated in `scripts/migrate.sh:62-67` (`MEDUSA_GDS_ONLY` gate); `schema_migrations` is **stem-keyed** so moving a file between dirs does **not** re-run it (`migrate.sh:25-26`) | **generalize** to `modules/<key>/migrations/` |
| A GDS-only schema verifier | `scripts/verify-gds-only-schema.sh` (the R52 carve-out test) | generalize per-module |
| The core↔host import-boundary check | `fitness.js` `checkCoreHostBoundary` (`HOST_GAME` regex, empty `GRANDFATHERED` set) | the template for the module-boundary checks |

**There is no `modules/` directory yet.** The kernel (`src/bongos/auth.js`, `pool.js`, `db.js`, `route-rank-check.js`, `permission-path-check.js`, the loader-to-be) stays where it is; modules move *out* around it.

---

## Decision

**Build the whole product into `core + modules` via an incremental strangler migration, one module at a time (most-isolated first), with each step shipping independently and guarded by CI fitness functions. Stay single-package, single-process, no-bundler. Enforce the one-way boundary by composition (the loader owns the mount) and by fitness (a violation is a red build), not by trust.**

The unit of work is a **module** = a vertical slice (its routes, DB tables, UI, skills, agent-context) reachable through **one published doorway** (`src/module-api.js`). The five rules ([01 §3](../design/modular-architecture/01-architecture.md)): (1) one doorway, one direction — modules import `module-api.js` only; core never imports a module; modules never import each other; (2) the host owns the mount; (3) a module owns a vertical slice; (4) shared state is namespaced (`<key>_*` tables, additive migrations); (5) a task is scoped to a module.

### The doorway and the loader

- **`src/module-api.js`** — the stable, **semver'd** import surface, and the *only* core file a module may `require`. It re-exports the kernel capabilities a module legitimately needs: `requireBuilder` / `requireRank` (auth, from `src/bongos/auth.js`), a DB pool accessor (`src/bongos/pool.js`), the **seam registry** (`registerProvider`/`resolve` for ports; `emit`/`on` for events), config/branding/identity (`src/instance-config.js`, `config/branding.json`), and a logger. It carries a `CORE_VERSION` constant. Adding to it is a **minor** semver bump (safe); changing/removing is **major** ([04 §2](../design/modular-architecture/04-module-lifecycle.md)). *(The design docs call this `core/module-api.js`; we site it at `src/module-api.js` to match the existing `src/modules.js` sibling and epic [#1388](https://example.com/builders#/task/1388) step 1. "core/" is the conceptual kernel, not a directory move.)*
- **The loader** — replaces the closed `KNOWN_MODULES` registry in `src/modules.js`. It (a) **discovers** `modules/*/module.json` across roots, (b) **validates** each manifest against a schema, (c) checks `coreVersion` compatibility (fail-closed), (d) **resolves → loads → mounts** each enabled module's route factory **behind kernel-composed auth** (the module ships a route *recipe* + a required rank; the loader wraps audit → `requireBuilder` → `requireRank` around it — [01 §3a](../design/modular-architecture/01-architecture.md)), (e) starts/stops its pollers, (f) applies its migrations (enabled-gated). The existing `isModuleEnabled`/`enabledDisciplines`/`clientModules` exports stay as a **back-compat facade** over the loader so nothing downstream breaks during the move.
- **The seam registry** — the kernel switchboard ([04 §1](../design/modular-architecture/04-module-lifecycle.md)). **Ports** (required capability): the economy module registers a `reward` provider; at ship the lifecycle asks the kernel to resolve `reward` and calls it. **Events** (optional reaction): the lifecycle emits `task.shipped`; discord reacts if it cares. No module ever holds a reference to another.

### How the boundary is enforced (trust = composition + fitness, never trust)

Two layers, composing with the existing rank boundary ([03 §8](../design/modular-architecture/03-builder-flows.md)): **rank** = *what* you may do (server-enforced, live, ADR 0016); **module** = *where* this task's code lands (worktree scope + a ship-time diff⊆module check).

New fitness checks, each a pure `checkXxx()` added to the `CHECKS` array in `fitness.js:285` (riding the `unit` job with **zero workflow changes** — they're picked up by `tests/fitness.mjs`):

1. **core never imports a module** — mirror `checkCoreHostBoundary`: flag any `require()` under the kernel that resolves into `modules/`. Fresh `GRANDFATHERED` set, ratcheted to empty as moves land.
2. **modules import only the published API** — walk each `modules/<key>/`, flag any `require()` resolving into core internals *other than* `src/module-api.js` (reject deep `src/bongos/db`, `src/bongos/auth`, …) and any resolving into a *sibling* module.
3. **every module write-route is rank-gated** — **do not re-implement.** Parameterize `route-rank-check.js`'s `ROUTES_DIR` (`route-rank-check.js:26,151-159`) to *also* walk `modules/**/routes/`; module write-routes then inherit the exact "unknown write = blocker" rule Check 4 already enforces.
4. **core carries no module-specific code** — assert no module key/domain term leaks into kernel files.
5. **module migrations are additive + namespaced** — read `modules/<key>/migrations/`, regex-reject destructive DDL (`DROP TABLE`/`DROP COLUMN`/destructive `ALTER`) and assert a `<key>_`-prefixed object namespace.

Each new check returns `warnings` until the tree is clean, then flips to `violations` (the ratchet). Every check ships with a **negative test** (proves it actually catches a violation) alongside the clean-pass test, mirroring `tests/fitness.mjs`.

### Module-owned migrations

Generalize the working `migrations/game/` precedent ([02 §1 grounded](../design/modular-architecture/02-module-map.md)):

- Teach `scripts/migrate.sh` to discover `modules/*/migrations/*.sql` and apply each **only if its module is enabled** (the `MEDUSA_GDS_ONLY` gate generalized to per-module enablement). `schema_migrations` stays **stem-keyed**, so relocating a migration from `migrations/game/` to `modules/game/migrations/` does **not** re-run it on prod — the existing safety guarantee carries the move for free.
- **Disable preserves data** — the entire mechanism is "don't apply," never "drop." There is no down-migration path and we keep it that way; a disabled module's tables simply are never created (or are left untouched).
- Generalize `scripts/verify-gds-only-schema.sh` into a per-module schema-presence/absence verifier.
- `scripts/migrate.sh` is a **gate HARD-FLOOR** (`gate-review.js`) and `migrations/` is **NEEDS_TRUST + a protected path** (`permission-path-check.js:78-80`): the runner change needs owner sign-off; new `modules/<key>/migrations/` subtrees inherit the protected-path treatment. The loader/migrate change is owner-gated by construction.

### The four module moves — ordered by *measured* isolation

From the `require()`-graph + reference scan (not intuition — [02 §2](../design/modular-architecture/02-module-map.md), confirmed in this ADR's grounding pass):

| Order | Module | Coupling into core | Why this slot |
|---|---|---|---|
| **1** | **dev-box** | **0** refs in `server.js`/`routes.js` bodies; self-contained `box*.js` cluster; box-prefixed tables; routes already flag-gated at `routes.js:122` | **The template move.** Cleanest seam; every later move copies it. Only seam: ~16 read-only box-status lines in `routes/me.js`. |
| **2** | **game** | **0** refs in any `src/bongos/` core file; lives entirely outside `src/bongos/` (`src/rooms/`, `src/world/`, `public/game/`); **already** has `migrations/game/` + a game-less `platform-server.js` | Most pre-separated. Slot 2 only because its server/client render twins must move together and `server.js` carries its static-serve tail + the Colyseus "realtime capability" seam. |
| **3** | **discord** | bot + broadcast cleanly isolatable, but the link/role **UI is woven into core** — `routes/me.js` (63 refs) + `settings.js` (19) | Needs the profile/settings contribution seam first. |
| **4** | **art-pipeline** | **no own router** — its API lives *inside* core `routes/me.js` (art-key, ~32 refs); the `artist` discipline threads through `src/modules.js` `enabledDisciplines()`; ~18k LOC `art/` tree | Hardest clean cut; largest body; last. |

**The recurring seam** across dev-box/discord/art is **`src/bongos/routes/me.js`** (the builder-profile route embeds all three) and **`public-builders/settings.js`** (embeds all three UI panels). A **module→core contribution hook** (a registration callback for profile fields + settings panels) is the prerequisite that lets dev-box/discord/art leave core. Game has *zero* such coupling and needs no profile seam.

### task→module affinity (the follow-on)

The research centerpiece ([00 §6](../design/modular-architecture/00-research-report.md)) — move the unit of work-affinity *up* from file paths to modules. Once the roster exists: a task declares **module affinity**; the agent loads only that module + the published API (smaller context, higher quality); parallel-safety becomes **module-disjointness** (cleaner than path overlap); drift detection becomes semantic ("you said dev-box, you touched game"); and the file-path `touches[]` (ADR 0049, already advisory) **retires** in favor of the module label + a ship-time diff⊆module check. This depends on the full move being done, so it is the **final tier** of this plan, not a precondition.

---

## The build plan → seeded tasks

Each phase maps to a claimable BONGOS-V1 task under criterion **C5 (`module-system-live`)**, dependency-ordered. (Seeded by `scripts/gds/seed-bongos-module-system-tasks.js`, companion migration `144`. R## numbers are assigned sequentially after the current max; the dependency edges below are authoritative.)

| Phase | Task (by role) | Delivers | Depends on |
|---|---|---|---|
| 0 · Doorway | `module-api.js` | the published, semver'd import surface + `CORE_VERSION` + nested CLAUDE.md | — |
| 0 · Doorway | fitness one-way checks | "core never imports a module" + "modules import only the API" (warn-mode; green on empty `modules/`) | module-api.js |
| 1 · Loader | manifest schema + validator | `module.json` schema (key, coreVersion, `contributes`, `provides`/`consumes`, `prerequisites`) + validator | — |
| 1 · Loader | the loader | discover → validate → coreVersion-check → mount-behind-auth → pollers → teardown; back-compat facade over `src/modules.js` | module-api.js, manifest schema |
| 1 · Loader | seam registry | kernel ports (`registerProvider`/`resolve`) + event bus (`emit`/`on`) | module-api.js |
| 2 · First move | profile/settings contribution seam | module→core hook for `routes/me.js` profile fields + `settings.js` panels | seam registry |
| 2 · First move | **move dev-box** → `modules/dev-box/` | move files; delete `routes.js:122` gate; loader mounts; OTB byte-identical | loader, profile seam |
| 3 · Trust | fitness module-route rank gate | parameterize `route-rank-check.js` to walk `modules/**/routes/` | loader |
| 3 · Trust | fitness core-clean + migration checks | "core carries no module code" + "module migrations additive/namespaced" (flip warn→violation) | loader, move dev-box |
| 4 · Migrations | module-owned migrations | generalize `migrate.sh` + `verify-gds-only-schema.sh` to `modules/<key>/migrations/` | loader |
| 5 · More moves | **move discord** → `modules/discord/` | bot/broadcast/routes + link UI via the profile seam | move dev-box, profile seam, module migrations |
| 5 · More moves | **move art-pipeline** → `modules/art-pipeline/` | carve art-key API out of `me.js`; `art/` tree; artist-discipline contribution | move dev-box, profile seam |
| 6 · Game | **move game** → `modules/game/` | rooms/world/`public/game`/`migrations/game`; Colyseus "realtime capability" seam | loader, module migrations |
| 7 · DX | `bongos module new <key>` + `bongos upgrade` | scaffolder (manifest + dirs + nested CLAUDE.md) + coreVersion pre-check | manifest schema, loader |
| 8 · Docs | rewrite `docs/modules-contract.md` + index sweep | plugin-API contract + module-author recipe; CLAUDE.md / file-map / architecture / ADR README | scaffolder, all moves |
| 8 · Proof | live demonstration | scaffold a throwaway module via `bongos module new`, mount it, ship it, OTB byte-identical; fitness catches a deliberate cross-module import | all moves, scaffolder |
| 9 · Follow-on | task→module affinity | `task.module`; module-disjoint parallel-safety; retire `touches[]`; module-scoped agent context | full roster moved |

**Proof of equivalence at every step** (as in ADR 0062's core/host split): after moving a module, OTB behaves **byte-for-byte the same**. That is the per-phase done-when.

---

## Consequences

**Positive.** The architecture becomes self-maintaining (fitness ratchet); AI agents get module-scoped context (higher quality, lower token cost — the research's biggest lever); a host can add/configure modules without forking core (the defining Cloud Bongos capability); parallel-safety gets cleaner (module-disjointness); the trust boundary is *extended* to module routes, never weakened. Each phase ships independently and is individually revertible — merging two modules back is cheap, the ratchet makes splitting safe, so the first cut is never a lock-in.

**Negative / cost.** ~16 boundaries to enforce (mitigated: fitness does it, not reviewers; start coarse). More ceremony per module (a manifest, a nested CLAUDE.md, maybe a seam). The lifecycle state machine must **not** be force-split (the one warning — [02 §4](../design/modular-architecture/02-module-map.md)). Several phases touch gate-protected surfaces (`migrate.sh` HARD-FLOOR, `routes.js`/`server.js`/`fitness.js`/`module-api.js` core trust surfaces) → owner Gate approval + admin-merge are expected on those PRs; this is the boundary working as designed, not friction to remove.

**Neutral.** Single-package / single-process / no-bundler are explicitly preserved; `start` stays `node server.js`. The future forks (packages, process isolation, per-module build) remain open and are deliberately *not* taken now.

---

## Alternatives considered

- **Ground-up rewrite — rejected.** Re-derives the sound parts (auth, ranks, tasks/claims/credits, grader, ship pipeline, ~143 migrations) for no modularity win, with an upside-down risk profile (long no-ship window → big-bang cutover) for a bootstrapped, ship-small, AI-first project ([01 §5](../design/modular-architecture/01-architecture.md)).
- **Coarse config A (~5 units, ADR 0080-as-written) — partially adopted as the *first* step, not the destination.** Proves the loader cheaply, but leaves ~70% of code a blob so AI-scoping barely improves. We ship A then peel medium ([02 §3](../design/modular-architecture/02-module-map.md)).
- **Fine config C (~22+ units, a module per route-group) — rejected.** Fights cohesion (tasks/claims/credits belong together), manifest sprawl, over-engineered for a small team. "As modular as the evidence supports, no finer."
- **Nx / Turborepo / Bazel / workspaces — rejected (for now).** Adds a build/link step for dependency-tree + caching benefits a single-process no-bundler app doesn't need ([00 §8](../design/modular-architecture/00-research-report.md)). In-repo `modules/<key>/` + a manifest + the existing `fitness.js` is the right lightweight choice; `eslint-plugin-boundaries` is the documented escape hatch if import-graph checks outgrow `fitness.js`.
- **In-process plugin sandboxing — deferred (the standard call).** First-party modules are trusted for *process safety*; the boundary that matters (**authz**) is enforced by composition (the loader owns the mount + wraps every entry behind auth the module can't remove) and fitness — *stronger* than Backstage/VS Code treat first-party plugins. True process isolation is the future fork for untrusted modules ([00 §4b](../design/modular-architecture/00-research-report.md)).
