// src/bongos/box-credential.js — source-access credential PROVIDER (ADR 0031 §6, #600).
//
// A dev box holds NO permanent baked credential. It fetches a scope-appropriate
// one from the GDS at boot/refresh (GET /box/source-access). This module is the
// seam for "where that credential comes from", so the route never hardcodes a
// secret and a future GitHub-App / fine-grained-PAT minter can slot in without
// touching the route or the access decision.
//
// ADR 0022 (no secrets in the repo): the credential material lives in the PROD
// ENVIRONMENT, never in this file or any committed file. When the env is unset the
// provider returns { configured:false } and the route returns a spec with
// credential:null + operator guidance — exactly the inert posture #598 ships with
// (BOX_REPO_URL unset → the cloud-init logs guidance instead of cloning).
//
// DEFAULT PROVIDER: env-backed static tokens (operator-supplied), one per scope.
//   BOX_SOURCE_REPO_URL          git remote the box clones (https://github.com/<org>/<repo>.git)
//   BOX_SOURCE_FULL_TOKEN        credential a 'full' box embeds in the clone URL
//   BOX_SOURCE_STARTER_TOKEN     credential a 'starter' box embeds (may equal full;
//                                the SCOPE is then enforced by sparse-checkout + audit)
//   BOX_SOURCE_STARTER_REPO_URL  OPTIONAL separate repo for the starter surface — set
//                                this to make 'starter' a HARD boundary (a physically
//                                separate repo that cannot read the crown jewels) rather
//                                than the default sparse-checkout defense-in-depth
//   BOX_SOURCE_TOKEN_TTL_SECONDS advisory TTL surfaced to the box so it re-fetches
//                                (and thus re-checks live rank — where revocation bites);
//                                default 3600 (1h)
//
// The env-static token is a STOPGAP: a static token is not truly short-lived, so
// central revocation for it relies on the box's refresh cron re-fetching, getting a
// 403 once the builder is demoted, and scrubbing the local credential+clone
// (infra/box-source-fetch.sh does this). A minting provider that returns genuinely
// short-lived tokens is the intended upgrade; the { expiresAt } field already models it.

const DEFAULT_TOKEN_TTL_SECONDS = 3600;

// Build the env-backed provider. Injectable env (for tests) defaulting to
// process.env. Returns { issue(scope, ctx) } where issue() is pure w.r.t. the
// captured env snapshot (no I/O), returning the credential descriptor for a scope.
function makeEnvCredentialProvider(env = process.env) {
  const ttl = (() => {
    const v = env.BOX_SOURCE_TOKEN_TTL_SECONDS;
    const n = v == null || v === '' ? DEFAULT_TOKEN_TTL_SECONDS : Number(v);
    return Number.isFinite(n) && n > 0 ? n : DEFAULT_TOKEN_TTL_SECONDS;
  })();

  function issue(scope /* 'starter' | 'full' */, { nowMs } = {}) {
    const fullUrl = env.BOX_SOURCE_REPO_URL || null;
    const starterUrl = env.BOX_SOURCE_STARTER_REPO_URL || fullUrl;
    const repoUrl = scope === 'full' ? fullUrl : starterUrl;
    const token = scope === 'full'
      ? (env.BOX_SOURCE_FULL_TOKEN || null)
      : (env.BOX_SOURCE_STARTER_TOKEN || env.BOX_SOURCE_FULL_TOKEN || null);

    if (!repoUrl || !token) {
      return {
        configured: false,
        scope,
        repoUrl: repoUrl || null,
        token: null,
        expiresAt: null,
        // A separate starter repo means the boundary is HARD (not just sparse).
        separateStarterRepo: scope !== 'full' && !!env.BOX_SOURCE_STARTER_REPO_URL,
        guidance:
          'source-access credential not configured — set BOX_SOURCE_REPO_URL and ' +
          (scope === 'full' ? 'BOX_SOURCE_FULL_TOKEN' : 'BOX_SOURCE_STARTER_TOKEN (or BOX_SOURCE_FULL_TOKEN)') +
          ' in the prod env (never the repo — ADR 0022).',
      };
    }
    // expiresAt is advisory for the env-static token (the token itself does not
    // expire); it tells the box WHEN to re-fetch, which re-checks live rank.
    const base = Number.isFinite(nowMs) ? nowMs : null;
    return {
      configured: true,
      scope,
      repoUrl,
      token,
      ttlSeconds: ttl,
      expiresAt: base != null ? new Date(base + ttl * 1000).toISOString() : null,
      separateStarterRepo: scope !== 'full' && !!env.BOX_SOURCE_STARTER_REPO_URL,
      guidance: null,
    };
  }

  return { issue };
}

// The process-default provider (reads the live process.env).
const defaultProvider = makeEnvCredentialProvider();

module.exports = {
  DEFAULT_TOKEN_TTL_SECONDS,
  makeEnvCredentialProvider,
  defaultProvider,
};
