-- core_188_goal_visibility_and_membership_requests.sql — private goals + the
-- invite / join-request model (task 1951, ADR 0112).
--
-- Adds goal PRIVACY plus the two-sided membership-request queue a private goal
-- needs. A goal's `visibility` is 'public' (default = today's open-join) or
-- 'private'; a private goal stays VISIBLE in the goal list but non-members can't
-- self-join — they are INVITED (and accept) or REQUEST to join (approved by an
-- owner/manager/Archon). goal_membership_requests is the pending queue for BOTH
-- directions — the access_requests approval-queue pattern (modules/onboarding)
-- applied to goal membership.
--
-- goals is a CORE-owned table (created in 160_goal_tier; ADR 0083 §Decision 5 —
-- a module migration may touch only its own <key>_ objects), so these changes
-- live in core migrations/, core_-namespaced (ADR 0108 §5: a new core migration
-- numbered above LEGACY_BARE_CORE_MAX=187 must be core_-prefixed, else the
-- fitness namespacing check reds the build).
--
-- PURELY ADDITIVE + idempotent: the new column defaults 'public' so every
-- existing goal keeps today's behaviour, and the new table/indexes are IF NOT
-- EXISTS. Fresh-DB-replay safe; no hard-coded builder ids (learning 1238).
-- migrate.sh records this file's stem in schema_migrations (the modern 187
-- pattern — the file does not self-insert).

BEGIN;

-- 1. Goal privacy. Default 'public' = today's open-join semantics, unchanged.
ALTER TABLE goals
  ADD COLUMN IF NOT EXISTS visibility text NOT NULL DEFAULT 'public'
    CHECK (visibility IN ('public', 'private'));

-- 2. The membership-request queue — one row per pending (or resolved) ask, in
--    EITHER direction:
--      kind='invite'  — a goal owner/manager asked builder_id to join; the
--                       invitee accepts/declines it from their inbox.
--      kind='request' — builder_id asked to join a (private) goal; an
--                       owner/manager/Archon approves/denies it.
--    created_by is who OPENED the row (the manager for an invite; the builder
--    themselves for a request); resolved_by is who closed it. Terminal states:
--    'accepted' (→ membership added), 'rejected' (declined/denied),
--    'cancelled' (withdrawn/rescinded by the opener).
CREATE TABLE IF NOT EXISTS goal_membership_requests (
  id           bigserial PRIMARY KEY,
  goal_id      bigint NOT NULL REFERENCES goals(id) ON DELETE CASCADE,
  builder_id   bigint NOT NULL REFERENCES builders(id) ON DELETE CASCADE,
  kind         text NOT NULL CHECK (kind IN ('invite', 'request')),
  status       text NOT NULL DEFAULT 'pending'
                 CHECK (status IN ('pending', 'accepted', 'rejected', 'cancelled')),
  note         text,
  created_by   bigint REFERENCES builders(id),
  resolved_by  bigint REFERENCES builders(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  resolved_at  timestamptz,
  updated_at   timestamptz NOT NULL DEFAULT now()
);

-- At most ONE pending ask per (goal, builder): an invite and a request can't
-- both be open for the same person on the same goal, and neither can pile up
-- duplicates (the access_requests partial-unique precedent). Resolved rows stay
-- as the audit trail and never block a later re-ask.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_goal_membership_requests_pending
  ON goal_membership_requests (goal_id, builder_id)
  WHERE status = 'pending';

-- Inbox reads: "my pending invites/requests" (builder_id) and "this goal's
-- pending queue" (goal_id, status).
CREATE INDEX IF NOT EXISTS idx_goal_membership_requests_builder
  ON goal_membership_requests (builder_id, status);
CREATE INDEX IF NOT EXISTS idx_goal_membership_requests_goal
  ON goal_membership_requests (goal_id, status);

COMMIT;
