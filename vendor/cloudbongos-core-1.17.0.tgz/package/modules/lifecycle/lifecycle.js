'use strict';

// modules/lifecycle/lifecycle.js — the `lifecycle` kernel PORT provider surface
// (BV1.R86 / ADR 0093 §3). The lifecycle is carved last, so by now every
// capability it INVOKES (grade, reward, onboarding) is a port it resolves; this
// is the inverse — the surface CORE and the OTHER modules resolve to reach the
// build state machine without importing modules/lifecycle/ (the one-way rule).
//
// It retires the three ADR-0091 §3 doorway leaks: `createTask`,
// `VOTABLE_TASK_STATUSES`, and `tallyPeerVotes` now live HERE, behind the port,
// not on src/module-api.js. Plus the work-tracking READS the staying-core read
// routes (public/me/builders/analytics) need, and `classifyTaskKind` for the
// dormant System-3 cascade-dispatch in core.
//
// DELEGATES (does not spread) to ./db + ./task-classifier so a test that stubs a
// method on the live module object bites at call time (the economy `reward`
// precedent). Constants are read live via getters for the same reason.

const db = require('./db');
const classifier = require('./task-classifier');

module.exports = {
  // --- retired doorway leaks (ADR 0093 §3) ---------------------------------
  // createTask: the lifecycle task INSERT (consumers: the onboarding newcomer-
  // restock + the discord bug-filing module db slices).
  createTask: (...a) => db.createTask(...a),
  // tallyPeerVotes: the peer-vote→karma weekly fold-in (consumer: the autonomy
  // routine-timers poller — the SAME tx POST /tasks/peer-votes/tally runs).
  tallyPeerVotes: (...a) => db.tallyPeerVotes(...a),
  // VOTABLE_TASK_STATUSES: the votable-status set (consumer: discord-reaction —
  // decide applause vs a real vote). classifyTaskKind: the kind heuristic
  // (consumer: core cascade-dispatch.js, the dormant System-3 lib).
  get VOTABLE_TASK_STATUSES() { return classifier.VOTABLE_TASK_STATUSES; },
  classifyTaskKind: (...a) => classifier.classifyTaskKind(...a),

  // --- work-tracking READS the staying-core read routes resolve --------------
  // public.js (the status surface): version/ship feed + grade trend.
  getTask: (...a) => db.getTask(...a),
  listVersions: (...a) => db.listVersions(...a),
  versionProgress: (...a) => db.versionProgress(...a),
  recentShippedTasks: (...a) => db.recentShippedTasks(...a),
  estimationDriftSummary: (...a) => db.estimationDriftSummary(...a),
  rollingAvgGrade: (...a) => db.rollingAvgGrade(...a),
  gradeTrendByDay: (...a) => db.gradeTrendByDay(...a),
  // me.js (the profile reader): per-builder claims + estimation + grade reads.
  getActiveClaimsForBuilder: (...a) => db.getActiveClaimsForBuilder(...a),
  getEstVsActualRatio: (...a) => db.getEstVsActualRatio(...a),
  recentGradesForBuilder: (...a) => db.recentGradesForBuilder(...a),
  countShippedTasksForBuilder: (...a) => db.countShippedTasksForBuilder(...a),
  recentShippedTasksByBuilder: (...a) => db.recentShippedTasksByBuilder(...a),
  // builders.js (the Archon roster): the roster + stale-claim + per-builder grade.
  getBuildersRoster: (...a) => db.getBuildersRoster(...a),
  getActiveClaimsForBuilderWithStale: (...a) => db.getActiveClaimsForBuilderWithStale(...a),
  gradeByBuilder: (...a) => db.gradeByBuilder(...a),
  // analytics.js (the AI-dev-curve): the builder + ecosystem analytics.
  builderAnalytics: (...a) => db.builderAnalytics(...a),
  ecosystemAnalytics: (...a) => db.ecosystemAnalytics(...a),
};
