-- 032_repo_health_snapshots.sql — measurement substrate for repo cleanliness (V3.R91 / #352).
--
-- Layer 0 (SHARED SUBSTRATE) of the code-simplification plan. One table that
-- `scripts/gds/repo-metrics.js` upserts a daily snapshot into, and that the
-- new /api/gds/public/repo-health read-surface reads back for the status page.
--
-- "You can't manage what you don't measure." This is the single cheap
-- measurement layer that Layers 1 (PREVENT, grader economy lens — #353) and
-- 2 (REWARD — #354) and the future janitor (Layer 3) all build on top of.
--
-- Shape (one row per calendar date, server timezone):
--   snapshot_date   — date key. UNIQUE so reruns the same day upsert, never
--                     duplicate (the idempotency requirement).
--   total_loc       — total tracked JS/MJS line count across the project.
--   loc_by_dir      — jsonb { "src/": n, "public/game/": n, ... } current
--                     line counts per watched directory.
--   largest_files   — jsonb array [{ path, lines }] top-N by size.
--   dead_exports    — int | NULL. knip unused-export count. NULL when knip is
--                     unavailable/unconfigured (degrades gracefully — the rest
--                     of the snapshot still records).
--   dead_files      — int | NULL. knip unused-file count (same NULL semantics).
--   stale_branches  — int. count of unmerged claude/* branches.
--   max_branch_age_days — numeric | NULL. age of the oldest unmerged branch.
--   confirmed_unshipped — int. tasks at status='confirmed' (verified, not yet
--                     on main) — the merge-mode backlog made visible.
--   raw             — jsonb. the full snapshot blob the CLI emitted, for any
--                     future field we surface without a migration.
--   created_at      — when this row was last written.
--
-- Idempotent: CREATE TABLE IF NOT EXISTS; the CLI upserts ON CONFLICT
-- (snapshot_date). Re-running this migration is a no-op.

CREATE TABLE IF NOT EXISTS repo_health_snapshots (
  id                  bigserial PRIMARY KEY,
  snapshot_date       date NOT NULL UNIQUE,
  total_loc           integer,
  loc_by_dir          jsonb NOT NULL DEFAULT '{}'::jsonb,
  largest_files       jsonb NOT NULL DEFAULT '[]'::jsonb,
  dead_exports        integer,
  dead_files          integer,
  stale_branches      integer NOT NULL DEFAULT 0,
  max_branch_age_days numeric,
  confirmed_unshipped integer NOT NULL DEFAULT 0,
  raw                 jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at          timestamptz NOT NULL DEFAULT now()
);

-- Trend queries read the most recent N rows by date.
CREATE INDEX IF NOT EXISTS idx_repo_health_date ON repo_health_snapshots (snapshot_date DESC);

-- Bump the migration counter past 032 so the next claim that includes
-- 'migrations/' allocates 033.
UPDATE migration_counter SET next_number = GREATEST(next_number, 33) WHERE id = 1;

INSERT INTO schema_migrations (version) VALUES ('032_repo_health_snapshots')
  ON CONFLICT (version) DO NOTHING;
