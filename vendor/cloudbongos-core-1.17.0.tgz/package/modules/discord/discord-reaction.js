'use strict';

// Discord reaction → upvote/applause — Phase 3 F4 (ADR 0033 §3).
//
// A 👍 on a shipped item in #ship-feed becomes EITHER a real peer-vote OR a
// cosmetic applause, decided entirely server-side. This module is the single
// enforcement point.
//
// TRUST BOUNDARY (ADR 0016 / 0033 §1) — the one invariant to defend:
//   "every bot-triggered write re-checks the LINKED builder's LIVE rank."
// The Discord bot is a service principal trusted ONLY to assert "this Discord
// user, who reacted, is linked builder X." It is NEVER trusted to decide what X
// may do. We resolve X via the F1 link table (which reads rank FRESH from
// builders), then branch on that live rank — the bot cannot escalate. The worst
// a compromised bot could do is mis-report WHICH linked user reacted, yielding
// at most one spurious Metic+ upvote, bounded by the anti-self guard, the 7-day
// karma lag, and the audit_log (surface='discord_bot').
//
// WHY A FUNCTION, NOT AN HTTP ENDPOINT: F3 put the bot IN-PROCESS (same Node
// server as the GDS). The in-process bot calls this function directly — no
// localhost self-HTTP, no minted bot session token to store/leak. The F1
// `requireDiscordBot` gate remains for any FUTURE external caller, but F4
// doesn't need it. Calling the function directly is both simpler and strictly
// less attack surface than exposing a network endpoint.
//
// BOTH MODES ARE DISJOINT BY CONSTRUCTION (ADR 0033 §3): a real peer-vote folds
// into karma (rank-gated, via the existing peer_votes path); applause lands in
// discord_applause and NEVER touches karma_log. Unranked enthusiasm cannot mint
// reputation.

const { pool } = require('../../src/module-api');
const db = require('./db');
const { auditDiscordBot } = require('./discord-audit');
const auth = require('./auth');
const api = require('../../src/module-api');
// VOTABLE_TASK_STATUSES is the lifecycle module's votable-status set, resolved via
// the `lifecycle` kernel PORT (the doorway leak retired at BV1.R86) — a vote only
// lands on confirmed/shipped work. Resolved at call time (this file runs under the
// discord bot poller, well after the lifecycle port registers at boot). A
// #ship-feed message is always about a shipped task, but we re-check rather than
// trust the channel.
const votableStatuses = () => api.resolveOptional('lifecycle')?.VOTABLE_TASK_STATUSES || new Set();
const VOTING_RANKS = new Set(['metic', 'archon']);

// PURE — extract the GDS task id from a #ship-feed message. The producer
// (ship.js) prefixes each feed line with the task ref, so we anchor to the
// LEADING `#<digits>` token. Anchoring to the start (not anywhere) means a
// summary that itself mentions another "#662" can't hijack the mapping. Returns
// a positive integer, or null if the line carries no leading marker.
function parseShipMarker(content) {
  if (typeof content !== 'string') return null;
  const m = /^\s*#(\d{1,12})\b/.exec(content);
  if (!m) return null;
  const id = Number(m[1]);
  return Number.isInteger(id) && id > 0 ? id : null;
}

// PURE — the vote-vs-applause decision. This is the heart of §3 and is unit-
// tested exhaustively. A reaction earns a REAL peer-vote only when EVERY guard
// the web/CLI vote path enforces is met against the linked builder's LIVE rank:
//   - the Discord user is linked to a builder at all, AND
//   - that builder's current rank is Metic or Archon (Xenos/players can't vote),
//   - the task is votable (confirmed/shipped) and has a shipping builder, AND
//   - the voter is NOT the author (no self-votes).
// Anything else → cosmetic applause. (Identical authorization to
// POST /tasks/:id/vote; intentionally no status/active check the web path lacks,
// because a deactivated builder is already dropped to Xenos and fails the rank
// gate — keeping the two paths byte-for-byte equivalent on authorization.)
function classifyReaction({ builder, task }) {
  if (!task || !votableStatuses().has(task.status)) return 'applause';
  if (task.shipped_by == null) return 'applause';
  if (!builder) return 'applause';                              // unlinked
  if (!VOTING_RANKS.has(builder.rank)) return 'applause';       // player / Xenos
  if (Number(task.shipped_by) === Number(builder.id)) return 'applause'; // self
  return 'peer_vote';
}

// DB — cast/refresh a +1 peer-vote with the SAME tallied-freeze guard as the
// web path (POST /tasks/:id/vote, src/bongos/routes/tasks.js). The conditional
// ON CONFLICT … WHERE peer_votes.tallied_at IS NULL means a vote already folded
// into karma is frozen: the update is filtered out and RETURNING is empty.
// Reactions only ever cast +1 (a 👍); the bot never down-votes or clears here.
async function castBotUpvote({ voterBuilderId, taskId }) {
  const { rowCount } = await pool.query(
    `INSERT INTO peer_votes (voter_builder_id, target_task_id, vote)
     VALUES ($1, $2, 1)
     ON CONFLICT (voter_builder_id, target_task_id)
       DO UPDATE SET vote = 1
         WHERE peer_votes.tallied_at IS NULL
     RETURNING id`,
    [voterBuilderId, taskId]
  );
  // counted=false ⟺ the existing vote was already tallied (frozen) — left as-is.
  return { counted: rowCount > 0 };
}

// DB — fetch the minimal task fields the decision needs, or null.
async function getTask(taskId) {
  const { rows } = await pool.query(
    `SELECT id, status, shipped_by FROM tasks WHERE id = $1`,
    [taskId]
  );
  return rows[0] || null;
}

// The real dependency set. Injected so recordDiscordReaction is unit-testable
// against fakes with NO database (the pure decision is what matters; the DB
// effects are thin wrappers over already-tested F1 helpers + the upsert above).
const realDeps = {
  getBuilderByDiscordUserId: db.getBuilderByDiscordUserId,
  getTask,
  castBotUpvote,
  recordApplause: db.recordApplause,
  insertAuditLog: db.insertAuditLog,
};

// Orchestrate one reaction. NEVER throws — the caller is a gateway event
// handler that must not crash the bot; all failure is caught and returned as
// { outcome: 'error' | 'ignored' }. Every successful write is audited with
// surface='discord_bot' and the asserted Discord user id, so bot-originated
// peer-votes are forensically distinguishable from direct web/CLI votes.
async function recordDiscordReaction({ discordUserId, taskId }, deps = realDeps) {
  // Validate the asserted identity + target BEFORE any DB work (F1 Hacker
  // advisory): a malformed snowflake or bad task id never reaches the tables.
  if (!auth.isValidDiscordUserId(discordUserId)) {
    return { outcome: 'ignored', reason: 'bad_discord_user_id' };
  }
  if (!Number.isInteger(taskId) || taskId <= 0) {
    return { outcome: 'ignored', reason: 'bad_task_id' };
  }

  try {
    // Independent reads — run concurrently (one fewer Postgres round-trip per
    // reaction; F4 efficiency finding).
    const [builder, task] = await Promise.all([
      deps.getBuilderByDiscordUserId(discordUserId),
      deps.getTask(taskId),
    ]);
    if (!task) {
      // No task to attach to — applause has a FK to tasks(id), so there is
      // nothing to record. Ignore rather than error.
      return { outcome: 'ignored', reason: 'task_not_found' };
    }

    const decision = classifyReaction({ builder, task });
    let outcome;
    if (decision === 'peer_vote') {
      const { counted } = await deps.castBotUpvote({ voterBuilderId: builder.id, taskId });
      // A frozen (already-tallied) vote is left untouched — still a peer-vote
      // semantically, just a no-op write. Surface that distinctly for the log.
      outcome = counted ? 'peer_vote' : 'peer_vote_frozen';
    } else {
      await deps.recordApplause({ targetTaskId: taskId, discordUserId });
      outcome = 'applause';
    }

    // Audit every bot-triggered write (ADR 0033 §1). Best-effort: an audit
    // failure must not undo the vote/applause, so it's caught separately.
    await auditDiscordBot(deps, {
      builderId: builder ? builder.id : null,
      route: 'discord:reaction',
      requestBodyRedacted: { discord_user_id: discordUserId, target_task_id: taskId, outcome },
      responseStatus: 200,
      logLabel: 'reaction audit-log write failed',
    });

    return { outcome, builderId: builder ? builder.id : null, taskId };
  } catch (err) {
    console.error('[discord-bot] recordDiscordReaction failed:', err.message);
    return { outcome: 'error', error: err.message };
  }
}

module.exports = {
  // pure (unit-tested)
  parseShipMarker,
  classifyReaction,
  // re-exposed via the lifecycle port (resolved live) for any consumer importing it here.
  get VOTABLE_TASK_STATUSES() { return votableStatuses(); },
  VOTING_RANKS,
  // orchestration + DB
  recordDiscordReaction,
  castBotUpvote,
  getTask,
  realDeps,
};
