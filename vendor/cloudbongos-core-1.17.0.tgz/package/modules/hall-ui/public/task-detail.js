// task-detail.js — the shared, hall-wide record overlay (task 1753), now IDEA +
// BLOCKER only (task 751).
//
// Owns the `#/idea|blocker/N` deep-link overlay for EVERY hall page — the compact
// summary card. `#/task/N` used to open a third, deeper overlay variant here (full
// description, status/version/kind/discipline/priority/min-rank/credits meta, the
// goal it belongs to, touches, blocked-by / blocks dependency links, and Claim +
// Copy-prompt actions); task 751 replaced that with a real page
// (/task/:id — task.js) so a task gets a shareable URL and working back/forward
// instead of a modal. This file now just REDIRECTS `#/task/N` to that page — for
// every `#/task/N` link already written across the codebase (ADRs, session logs,
// CLAUDE.md, scripts/gds/linkify-refs.js's RESOLVER_BASE) to keep resolving.
//
// Self-contained (its own getJSON, no framework), loaded AFTER dom-utils.js on
// each page. It self-boots on DOMContentLoaded and survives the sign-in round-trip
// by stashing the target hash (a logged-out viewer sees a "sign in" card). Any page
// script opens an idea/blocker with `window.OTBTaskDetail.open(id)` — which now
// navigates a TASK id straight to /task/:id — or by setting the hash.
(function () {
  'use strict';
  var API = '/api/bongos';
  // Generated typed client (task 1996 / R09), served as window.BongosClient by
  // /lib/bongos-client.js. baseUrl:'' passes the full same-origin paths this file
  // builds through unchanged; result-mode ({ status, ok, data }) preserves control flow 1:1.
  var api = window.BongosClient.createClient({ baseUrl: '', credentials: 'same-origin', throwOnError: false });
  var AUTH_NEEDED = 'auth-needed';
  var DEEPLINK_RE = /^#\/(task|idea|blocker)\/(\d+)$/;
  var STASH = 'otb-hall-deeplink';

  function fmtRel(iso) {
    if (!iso) return '';
    var sec = (Date.now() - new Date(iso).getTime()) / 1000;
    if (sec < 3600) return Math.max(1, Math.floor(sec / 60)) + 'm ago';
    if (sec < 86400) return Math.floor(sec / 3600) + 'h ago';
    return Math.floor(sec / 86400) + 'd ago';
  }
  // The hall is mounted at "/" on builders.<apex> and at "/builders" on the apex
  // host (same rule work.js's buildPromptForTask / task.js use).
  function hallBase() {
    return location.hostname.startsWith('builders.') ? '' : '/builders';
  }

  async function getJSON(path, opts) {
    var softAuth = opts && opts.softAuth;
    var res = await api.request('GET', path);
    if (res.status === 401) {
      if (softAuth) { var e = new Error('auth-needed'); e.code = AUTH_NEEDED; throw e; }
      window.location.assign(API + '/auth/web/start');
      throw new Error('redirecting to auth');
    }
    if (!res.ok) { var err = new Error(path + ' → ' + res.status); err.status = res.status; throw err; }
    return res.data;
  }

  var toast = function (m) { if (window.OTB && window.OTB.toast) window.OTB.toast(m, { duration: 2600 }); };

  // task 759: idea triage (Metic+) — discard an open idea from the overlay.
  // Cookie-authed PATCH; throws { status, data } on a non-2xx. The server enforces
  // the Metic+ gate (ADR 0018); the button only renders for metic+ below.
  async function patchJSON(path, body) {
    var res = await api.request('PATCH', path, { body: body || {} });
    if (res.status === 401) { window.location.assign(API + '/auth/web/start'); throw new Error('redirecting to auth'); }
    var data = null;
    try { data = res.data; } catch (_) { /* empty / non-JSON */ }
    if (!res.ok) { var err = new Error(path + ' → ' + res.status); err.status = res.status; err.data = data || {}; throw err; }
    return data;
  }

  async function fetchRef(kind, id) {
    if (kind === 'blocker') {
      var db = await getJSON(API + '/blockers/' + encodeURIComponent(id), { softAuth: true });
      var b = db && (db.blocker || db);
      return b && b.id != null ? Object.assign({ kind: kind }, b) : null;
    }
    var di = await getJSON(API + '/inbox/' + encodeURIComponent(id), { softAuth: true });
    var i = di && (di.idea || di);
    return i && i.id != null ? Object.assign({ kind: kind }, i) : null;
  }

  var h = function (tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  };

  function simpleBody(kind, r, viewer) {
    var nodes = [];
    var label = '#' + r.id;
    nodes.push(h('p', 'deeplink-card__kind', kind.toUpperCase()));
    nodes.push(h('p', 'deeplink-card__title', r.title ? label + ' — ' + r.title : label));
    var meta = [];
    if (r.status) meta.push(r.status);
    if (r.version_id) meta.push(r.version_id);
    if (r.priority != null) meta.push('P' + r.priority);
    if (meta.length) nodes.push(h('p', 'deeplink-card__meta', meta.join(' · ')));
    var summary = r.value_summary || r.summary || r.description || r.body_md || r.notes_md;
    if (summary) {
      var d = h('div', 'td-desc');
      d.textContent = String(summary);
      nodes.push(d);
    }
    if (r.shipped_at) nodes.push(h('p', 'deeplink-card__note', 'Shipped ' + fmtRel(r.shipped_at)));

    // task 759: Metic+ idea triage — a Discard control on an OPEN idea, right in
    // the overlay (no /idea-triage skill / LLM in the loop). The button only
    // renders for metic/archon; the server enforces the same gate regardless.
    var rank = (viewer && viewer.rank) ? String(viewer.rank).toLowerCase() : '';
    if (kind === 'idea' && r.status === 'open' && (rank === 'metic' || rank === 'archon')) {
      var actions = h('div', 'td-actions');
      var discardBtn = document.createElement('button');
      discardBtn.type = 'button';
      discardBtn.className = 'td-btn';
      discardBtn.textContent = 'Discard';
      discardBtn.addEventListener('click', function () {
        discardBtn.disabled = true;
        discardBtn.textContent = '…';
        patchJSON(API + '/inbox/' + encodeURIComponent(r.id), { status: 'discarded' })
          .then(function () { toast('Idea ' + label + ' discarded.'); clearLink(); })
          .catch(function (err) {
            if (err && err.message === 'redirecting to auth') return;
            var code = err && err.data && err.data.error;
            toast(code === 'INSUFFICIENT_RANK' || err.status === 403
              ? 'Only Metic+ can triage ideas.'
              : 'Could not discard that idea. Try again.');
            discardBtn.disabled = false;
            discardBtn.textContent = 'Discard';
          });
      });
      actions.appendChild(discardBtn);
      nodes.push(actions);
    }
    return nodes;
  }

  function bodyFor(state) {
    var nodes = [];
    var label = '#' + state.id;
    if (state.loading) { nodes.push(h('p', 'deeplink-card__title', 'Loading ' + label + '…')); return nodes; }
    if (state.needsAuth) {
      nodes.push(h('p', 'deeplink-card__title', label));
      nodes.push(h('p', 'deeplink-card__note', 'Sign in to the Builders’ Hall to view this record.'));
      var a = h('a', 'deeplink-card__link', 'Sign in with GitHub →');
      a.href = API + '/auth/web/start';
      nodes.push(a);
      return nodes;
    }
    if (state.notFound) {
      nodes.push(h('p', 'deeplink-card__title', label + ' — no such ' + state.kind));
      nodes.push(h('p', 'deeplink-card__note', 'Tasks, ideas, and blockers are numbered separately from GitHub pull requests, so this may be a PR rather than a record here.'));
      return nodes;
    }
    if (state.error) {
      nodes.push(h('p', 'deeplink-card__title', 'Could not load ' + label));
      nodes.push(h('p', 'deeplink-card__note', 'Try again in a moment.'));
      return nodes;
    }
    return simpleBody(state.kind, state.ref, state.viewer);
  }

  function dismiss() {
    var c = document.getElementById('deeplink-card');
    if (c) c.remove();
  }
  function clearLink() {
    history.replaceState(null, '', location.pathname + location.search);
    dismiss();
  }
  function render(state) {
    dismiss();
    var overlay = document.createElement('div');
    overlay.id = 'deeplink-card';
    overlay.className = 'deeplink-card';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', state.kind + ' #' + state.id);
    var panel = document.createElement('div');
    panel.className = 'deeplink-card__panel';
    var close = document.createElement('button');
    close.type = 'button';
    close.className = 'deeplink-card__close';
    close.setAttribute('aria-label', 'Close');
    close.textContent = '×';
    close.addEventListener('click', clearLink);
    panel.appendChild(close);
    bodyFor(state).forEach(function (n) { panel.appendChild(n); });
    overlay.appendChild(panel);
    overlay.addEventListener('click', function (e) { if (e.target === overlay) clearLink(); });
    document.body.appendChild(overlay);
  }

  async function resolve() {
    var m = DEEPLINK_RE.exec(location.hash);
    if (!m) { dismiss(); return; }
    var kind = m[1], id = m[2];
    if (kind === 'task') {
      // task 751: the task overlay moved to a real page. Redirect rather than
      // render here so every #/task/N link already written across the codebase
      // (ADRs, session logs, CLAUDE.md, linkify-refs.js's RESOLVER_BASE) keeps
      // resolving, without a second click. replace(), not assign(), so the
      // dead hash URL never lands in browser history.
      location.replace(hallBase() + '/task/' + encodeURIComponent(id));
      return;
    }
    render({ loading: true, kind: kind, id: id });
    try {
      var ref = await fetchRef(kind, id);
      // task 759: probe the viewer's rank only for an idea (so the overlay can
      // offer Metic+ triage). Best-effort — a failure just hides the button.
      var viewer = null;
      if (kind === 'idea' && ref) {
        try {
          var me = await getJSON(API + '/me', { softAuth: true });
          viewer = (me && me.builder) ? me.builder : null;
        } catch (_) { /* cosmetic — server enforces the gate regardless */ }
      }
      render(ref ? { kind: kind, id: id, ref: ref, viewer: viewer } : { kind: kind, id: id, notFound: true });
    } catch (err) {
      if (err && err.code === AUTH_NEEDED) {
        try { sessionStorage.setItem(STASH, location.hash); } catch (_) { /* ignore */ }
        render({ kind: kind, id: id, needsAuth: true });
        return;
      }
      if (err && err.message === 'redirecting to auth') return;
      render({ kind: kind, id: id, error: true });
    }
  }

  window.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && document.getElementById('deeplink-card')) clearLink();
  });
  window.addEventListener('hashchange', resolve);

  function boot() {
    var stashed = null;
    try { stashed = sessionStorage.getItem(STASH); } catch (_) { /* ignore */ }
    if (stashed) {
      try { sessionStorage.removeItem(STASH); } catch (_) { /* ignore */ }
      if (DEEPLINK_RE.test(stashed) && location.hash !== stashed) { location.hash = stashed; return; }
    }
    if (DEEPLINK_RE.test(location.hash)) resolve();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  window.OTBTaskDetail = {
    resolve: resolve,
    // Every existing caller (Work Board's open-detail button + backlog rows,
    // the Goals page) passes a TASK id — navigate straight to the real page
    // rather than round-tripping through the hash redirect above.
    open: function (id) { location.href = hallBase() + '/task/' + encodeURIComponent(id); },
  };
})();
