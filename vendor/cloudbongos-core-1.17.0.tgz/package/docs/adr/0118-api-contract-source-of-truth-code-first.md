# ADR 0118 — API contract source-of-truth: code-first, schema-as-data

**Date:** 2026-07-04
**Status:** Accepted (spike; R07 of goal 36).
**Context:** [task 1994](https://builders.example.com#/task/1994) (BONGOS-V1, goal 36, criteria `api-client-sdk` + `api-validation`). The spike that shapes the SDK (R08–R10) and validation (R11–R12): does the OpenAPI spec become the **source** (schema-first — author schemas, generate routes + validation + client), or stay **generated from code** (code-first) with codegen layered on? Builds on the self-describing OpenAPI generator ([ADR 0109](<redacted>.md), `scripts/gds/gen-api-docs.js`) and the error envelope ([ADR 0116](<redacted>.md)).

## What exists today

`gen-api-docs.js` (ADR 0109) already generates the OpenAPI spec **from the route source**: it walks each `router.METHOD('/path', …)` in `src/gds/routes/` + `modules/*/routes/`, reads the `// rank:` comment for auth, and calls `extractBody()` — which finds the handler's `validateOrRespond(req, res, {schema})` / `validate(req.body, {schema})` call and pulls the schema's top-level **field names**. Measured on the live surface: **212 endpoints; 76 write ops carry a requestBody, 24 do not; `components.schemas` is empty.** So the spec is real and code-derived, but **shallow** — field names, not types/required/enums.

The crucial observation: the per-route **`validate()` schema object is already structured data** (`_helpers.js` — each field rule carries `type`, `required`, `maxLength`, `minLength`, `min`/`max`, `enum`, `itemsType`, `maxItems`). It already drives runtime validation. It is *right there in the code*, richer than what the spec currently emits.

## Decision

**Stay code-first. The per-route `validate()` schema object is the single structured source of truth**; the spec, runtime validation, and the typed client are all *derived* from it — none is hand-authored.

1. **Enrich the generator, don't invert the flow.** Extend `gen-api-docs.js` so `extractBody()` emits the FULL rule set (types, `required`, `enum`, length/range caps) from the `validate()` schema into typed OpenAPI request schemas (and named `components.schemas`), instead of only field names. This closes the 24 undocumented bodies and upgrades the 76 shallow ones to typed schemas — for free, from data that already exists.
2. **One schema, three consumers.** That same `validate()` schema object:
   - **generates** the OpenAPI request schema (this ADR's enrichment),
   - **enforces** the request at runtime (it already does — R11 hardens it to reject unknown fields + cover query params),
   - **types** the generated client (R08, emitted from the enriched spec).
   So "single source of truth" is achieved *within* code-first — the code IS the schema, and everything downstream is generated. No drift, because there is only one authored artifact.
3. **Generate the client from the spec (R08), don't hand-write it.** Once the spec carries typed schemas, a generator (a small in-house emitter, or `openapi-typescript`-class tooling kept to a dev-dependency — cheapest-viable, ADR §4 cost DNA) produces the typed client. The client is a build artifact, never edited by hand.

## Why not schema-first

Schema-first (author OpenAPI/JSON-Schema, generate the route layer + validators + client from it) would mean **rewriting the entire mature 212-endpoint route layer** to be schema-driven, replacing hand-written Express handlers with a schema-bound framework. That is an enormous, high-risk rewrite that throws away a working generator (ADR 0109) to buy a "single source" we can get far more cheaply by treating the existing in-code schema as the source. The AI-first build model (many small claimed tasks against a live API) strongly favours the incremental, low-blast-radius path.

## Refinement of R08–R12 (the spike's sub-task output)

- **R08 (typed client, [#1995](https://builders.example.com#/task/1995)):** (a) enrich `gen-api-docs.js` to emit typed request/response schemas + `components.schemas` from the `validate()` rules; (b) generate a typed client from the enriched spec; (c) publish as an internal package first.
- **R09 (migrate callers, [#1996](https://builders.example.com#/task/1996)):** move the CLI (`cli-lib.apiCall`), the devbox app, and the web UIs onto the client; delete the duplicates. **This is also where the R04 fallout is repaired** — callers that read `data.error` as a string move to the client's typed envelope handling (`error.code`).
- **R10 (external on-ramp, [#1997](https://builders.example.com#/task/1997)):** document token acquisition + a runnable hello-world against the published client.
- **R11 (validation, [#1998](https://builders.example.com#/task/1998)):** harden `validate()` to reject unknown/typo'd fields and cover query params, driven by the same per-route schema the spec advertises; failures return the ADR-0116 envelope (`validation_failed` + `details`).
- **R12 (build check, [#1999](https://builders.example.com#/task/1999)):** a fitness check failing the build when a write route has no spec-bound `validate()` schema (locks the 100% coverage).

## Consequences

- The SDK + validation work becomes incremental enrichment of an existing generator, not a rewrite.
- The `validate()` schema gains a second payoff (it types the spec + client), which incentivises writing it — reinforcing R11/R12's coverage goal.
- The spec stays honest by construction (generated at ship, ADR 0109), so the client + docs can never drift from the routes.

## Rejected

- **Schema-first** — full route-layer rewrite; disproportionate to the goal.
- **Hand-maintained OpenAPI** — drifts from code (ADR 0109 already rejected this).
- **Swapping to a schema-native framework (Fastify/JSON-Schema, tRPC)** — far too invasive for a live 212-endpoint surface; a framework migration, not an API-hardening task.
