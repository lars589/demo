# ADR 0123 — Idle-swept dev boxes lose uncommitted work: an on-box autosave-push, not a VM snapshot

- **Status:** Accepted (the approach + rejected alternatives are decided; the cron script + operator credential wiring are task-pending — see §Consequences for the seeded follow-up). **No autosave code ships in this ADR — it is a SPIKE.**
- **Date:** 2026-07-05
- **Track:** internal (dev-box lifecycle)
- **Task:** [#837](https://example.com/builders#/task/837) — "SPIKE: don't lose uncommitted work when a dev box is reclaimed (idle sweep deprovisions, no snapshot)."
- **Builds on:** [ADR 0031](<redacted>.md) (cloud dev environments), [ADR 0071](<redacted>.md) (confirm-before-destroyed + drift reconcile — the closest prior art; hardens droplet *truthfulness*, not data preservation), [ADR 0043](<redacted>.md) (git/SSH trust boundary — relevant because the fix widens a box credential's scope).

## Problem

`scripts/gds/box.js` `cmdSweepIdle()` → `deprovisionOne()` deletes the droplet outright once `modules/dev-box/boxes.js` `selectIdleBoxes()` decides a box is idle (no heartbeat, no `claude_active`, past `BOX_IDLE_MINUTES`, default 10). **Nothing on this path looks at git status.** Park/snapshot was deliberately removed from the automated idle path (box.js:842-845 — snapshot storage cost with no benefit, since boxes are meant to be ephemeral). So today: idle sweep = hard droplet delete, and any uncommitted tracked work on `/workspace` is gone permanently, with no confirmation step and no way to recover it.

The heartbeat (`infra/box-heartbeat.sh`) that feeds the idle clock is a pure presence signal (SSH/ttyd connection + CPU load) — it has no concept of a dirty working tree. A builder who steps away mid-edit with real uncommitted changes and no active connection gets swept exactly like a builder who is genuinely done.

No existing ADR, blocker, or backlog entry addresses this — ADR 0071 explicitly treats the droplet as disposable and is scoped to infra-state correctness, not data preservation. `sweep-dormant` (parked boxes) is not the acute case: a parked box already has a snapshot from the manual `park` path, so its reclaim destroys a *backup copy*, not live work. The acute path is specifically **active → destroyed** via the idle sweep.

## Decision

**<redacted> from the box, not a VM/droplet snapshot.** Add an on-box cron (sibling to `box-heartbeat.sh`, similar ~5-minute cadence) that, when `/workspace`'s git tree is dirty, commits the tracked changes and pushes them to the box's own claim branch (the `claude/<name>` branch a claimed task already works in per ADR 0097). This bounds data loss to "since the last autosave tick" (~5 min) instead of "since session start," using infrastructure that already exists for a different purpose:

- **Auth pattern is proven.** `infra/box-source-fetch.sh` already does one-shot-credentialed-push semantics for *fetch*: `git remote set-url origin "$AUTH_URL"` → git op → `git remote set-url origin "$REPO_URL"` (credential never persisted in `.git/config`). The autosave cron reuses the identical pattern for a *push*.
- **Credential scope must widen.** `GET /box/source-access` (`modules/dev-box/routes/box.js:422`) mints a scope-appropriate token via `box-credential.js`, but the token today is only ever used to clone/fetch. Whether the operator-configured `BOX_SOURCE_FULL_TOKEN` already carries push scope is unknown from code — it's an operator-supplied env value (`box-credential.js:46-65`). **This is the one real open dependency**: either confirm the existing token already has push scope, or mint a second, push-scoped credential. Because this is a trust-boundary-relevant change (a box gains the ability to write to `origin`, not just read it), the follow-up task must treat it with the same care as ADR 0043 — scoped to the box's own `claude/<name>` branch only (never `main`), audited via the existing `source_grant`/new `autosave_push` event on `box_events`, and gated to the same rank floor that already gates source access.
- **Explicit non-goals.** Gitignored/untracked local-only state (`.env.local`, other per-worktree secrets) is NOT covered — those are meant to be regenerated via `/builder-setup`/`/builder-key`, not preserved. This fix is scoped to tracked-file work loss only.

## Alternatives considered

- **Reintroduce snapshot-before-destroy on the idle path (bring back `park`'s snapshot).** Rejected: this is the exact cost (~$0.30/mo per idle box × fleet size, plus snapshot-restore latency on next wake) the team deliberately removed from the automated path. It also doesn't actually solve the problem faster than a commit — a snapshot still requires the operator (or the builder) to notice and restore it; a pushed branch is immediately visible and diffable from any machine.
- **Control-plane git-status check before sweep (abort deprovision if `/workspace` is dirty).** Rejected: requires giving the control plane a NEW capability (SSH/exec into the box to read git state) that doesn't exist today, and a builder who simply forgets to commit for days would pin their box active-forever, defeating the idle sweep's entire cost-saving purpose. An autosave-push needs no new control-plane capability — it's entirely box-side, symmetric with the existing heartbeat/source-fetch crons.
- **Rely on the manual `/builder-end` git-dirty check alone.** Rejected as the sole mitigation: it already exists (`builder-end` refuses to tear down a dirty worktree) but only fires when a builder explicitly signs off. It has zero relationship to the automatic idle sweep, which is precisely the unguarded path this spike is about.

## Consequences

- Bounds — doesn't eliminate — the loss window to the autosave interval; a crash or sweep in the seconds between an edit and the next tick can still lose that slice. Full elimination would need a snapshot (rejected above) or a live pre-sweep check (rejected above); this is the accepted trade-off.
- Autosaved commits land on the SAME `claude/<name>` claim branch (not a separate `autosave/*` branch), so they show up as ordinary WIP commits a builder squashes/amends before shipping — no new branch-namespace or `/builder-ship` special-casing needed.
- Needs an operator credential decision (push-scope token) before the cron can be built — flagged as the seeded follow-up task's first step, not assumed solved here.
- No code ships from this ADR. Seeded follow-up: implement `infra/box-autosave.sh` (dirty-check + one-shot-credentialed commit+push, mirroring `box-source-fetch.sh`'s credential-scrub pattern) + the operator-side push-credential decision + wiring it into cloud-init alongside the existing heartbeat cron.
