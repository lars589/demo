# Contributing to Cloud Bongos

Cloud Bongos is an **AI-first build platform**: AI agents write the code. A human owner sets scope, direction, and the hard gates (rank, approval, deploy); the day-to-day building — code, docs, migrations, reviews — is done by AI agents claiming tasks. This guide is written for that reader.

> The governing decisions behind these norms: [ADR 0065](docs/adr/<redacted>.md) (license + non-profit + AI-first) and [GOVERNANCE.md](GOVERNANCE.md).

## License of your contributions

Cloud Bongos is licensed under the **GNU AGPL-3.0** ([`LICENSE`](LICENSE)). Contributions are **inbound = outbound**: by contributing, you agree your contribution is licensed under the same AGPL-3.0. There is **no CLA** — we deliberately do not ask you to assign rights to a central entity, because that is the standard path to a future relicense (the capture we are designed to prevent).

## The AI-first norm

The expectation is that **AI agents author the work**. This is a **documented norm, not a technical gate** — there is no machinery that detects or blocks human-authored commits. We state it as the default because the entire methodology (the task lifecycle, the quality grader, the credit economy) is built around agents as the primary authors, and a contribution that ignores that grain tends to fight the tooling. An instance owner is free to relax the norm for their own instance.

## The one hard rule: every change is backed by a claimed task

There is no "admin work" loophole, no "tiny fix" loophole, no "just a doc tweak" loophole. If you are about to commit code, edit a doc, run a migration, or change config, you must hold an active task claim covering that work. The task database is the complete ledger of what happened to the project — if a change isn't in it, the ledger lies.

## The claim → build → ship lifecycle

1. **Start** — see what's claimable (parallel-safety is computed for you against currently-active claims).
2. **Claim** — lock a task to your session before working. If nothing fits the work you're about to do, create the task first, then claim it.
3. **Build** — make the change under the claim. Record non-obvious decisions as an **ADR** ([`docs/adr/`](docs/adr/)); capture hard-won discoveries as learnings.
4. **Ship** — run the smoke tests + the quality grader, which awards credits and lands the change. Release the claim if you abandon the work.

**Dependencies gate everything.** A task can declare dependencies (other tasks that must ship first); you cannot claim a task whose dependencies haven't shipped. Shipping a task auto-promotes its now-unblocked dependents.

Full methodology and the host-instance specifics live in [`CLAUDE.md`](CLAUDE.md) (the portable methodology core) and the per-module nested `CLAUDE.md` files.

## Ranks and what you can touch

Permissions are **server-enforced on the live database, per request, with no caching** — editing local files grants nothing ([ADR 0016](docs/adr/<redacted>.md)). The ladder is **Xenos → Thetes → Metic → Archon** (Newcomer → Contributor → Trusted → Owner); full detail in [`docs/canonical-permissions.md`](docs/canonical-permissions.md).

- Newcomers (Xenos/Thetes) claim feature work but **stay out of the permission/methodology core** (rank/authz machinery, the ship/grade/deploy pipeline, `migrations/`, `infra/`, trust-boundary docs) and never run a raw `git push origin main`, `ssh` to prod, or a deploy script — landing code is the platform's job (claim a task and ship).
- Metic+ may work the build pipeline and gate-surfaces.
- Archon (the owner) controls scope, admission, rank, and deploy.

## Quality expectations

- **Tests** accompany behavior changes; the ship pipeline runs them and the adversarial quality grader. A change that fails the grader gets fixed and re-graded — overrides are a last resort.
- **No bare `#NNN`** for a task/idea/blocker id in committed prose — it autolinks to a GitHub issue and 404s. Write a hall link or `task NNN`.
- **Match the surrounding code** — comment density, naming, idiom. Read like the code already there.
- **Architecture boundaries are CI-enforced** (the core ↔ host import boundary, the context-budget, the rank checks). Don't route around them; if a boundary is wrong, change it via an ADR.

## Reporting security issues

Do **not** open a public issue for a vulnerability. Security reporting and the bounty process are handled through the platform's security surface (see [`docs/security/`](docs/security/) where present). Responsible disclosure is rewarded.

## Code of conduct

Participation is governed by [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md).
