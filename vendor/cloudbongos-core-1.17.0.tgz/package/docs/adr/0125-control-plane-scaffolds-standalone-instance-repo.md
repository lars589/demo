# ADR 0125 — The control plane scaffolds + pushes a standalone instance's repo

**Date:** 2026-07-05
**Status:** Accepted (implements goal 35's `project-creation-flow` criterion; builds on [ADR 0108](<redacted>.md) + [ADR 0111](<redacted>.md)).
**Context:** [task 2055](https://builders.example.com#/task/2055) (BONGOS-V1) — greenfield onboarding gap 3/4, found in the 2026-07-05 end-to-end standup attempt (task 2052).

## Problem

The greenfield "one guided flow" (`bongos init` → provision → OAuth → verify) had a **manual dead-end** between init and provision. `scripts/gds/provision.js` assumed a standalone instance's repo was **already cloned** at `/srv/cloudbongos/<slug>` and **threw** ("standalone instance repo not found … clone … first") otherwise. So an owner who requested an instance (`POST /api/bongos/provisioning/instances`) had to SSH the control plane and hand-clone + hand-scaffold the repo — there was no automation to turn an *empty* GitHub repo into an *installable* Cloud Bongos instance.

## Decision

**The control-plane provisioning runner scaffolds the instance's own repo itself, then commits + pushes it** — replacing the throw with a `scaffoldStandaloneRepo()` leg that runs before the existing code-sync/db/service steps:

1. **clone** the (empty) `target_ref` → `/srv/cloudbongos/<slug>`, forcing the initial branch to `main` (an empty clone has an unborn HEAD).
2. **build** the installable `@cloudbongos/core` tarball from the control-plane checkout (`package-core.js`).
3. **materialize** `config/` + `.claude/` + a `file:`-pinned `package.json` + `package-lock.json` via `bongos init --vendor-core` (the [task 2053](https://builders.example.com#/task/2053) primitive), `--no-seed` (the instance's own DB is seeded by `migrate`, not here).
4. **commit + push** to the instance's `main` (with a `node_modules`-excluding `.gitignore`; the vendored tarball + lockfile stay tracked so `npm ci` resolves the pinned core).

It is **idempotent** (skips once the repo carries a `package.json`) and **dry-run-safe** (every mutation goes through the injected `exec`/`writeFile`).

**Git transport = the existing SSH deploy alias.** The clone/push use `git@<alias>:<owner>/<repo>.git` (default alias `github-deploy`, overridable via `PROVISION_GIT_SSH_ALIAS`) — the **same** transport the control-plane checkout already uses for the platform repo. No secret is interpolated into a command (SSH-key auth), so nothing leaks into journald.

**Operational prerequisite (the one manual grant):** the control plane's deploy public key (`~/.ssh/github_deploy.pub`) must have **write** access to each instance repo. GitHub deploy keys are per-repo, so standing up a new instance requires the owner to add that key (write) to the new repo — a one-time browser step alongside "create the empty repo," mirroring how the platform repo's deploy key is registered.

## Consequences

- **`deploy-instance.sh` already existed** at `scripts/deploy/deploy-instance.sh` (added by [ADR 0108](<redacted>.md) §4 / task 1884 — the task-2055 description predated it). It is the *ongoing* consumer deploy (git pull → `npm ci` → three-root migrate → restart), installed as an instance's own `~/deploy.sh`; the provisioner does the *first-time* standup inline. No duplicate at `infra/` was created.
- A fresh empty GitHub repo now goes from "requested" to "installable + bootable" with **no manual clone/scaffold** — closing the init→provision dead-end.
- The control plane gains a new responsibility (pushing to owner repos). Bounded by the per-repo deploy-key grant above.

## Rejected alternatives

- **A control-plane GitHub PAT / App token over HTTPS.** More scalable than per-repo deploy keys, but (a) embedding a token in a `git` URL risks leaking it into journald / process args, requiring a credential-helper dance, and (b) it introduces a new broad-scoped secret class on the control plane. Deferred — the SSH-alias reuse ships zero new secret machinery. A **GitHub App** (per-repo installation tokens, no long-lived secret) is the scalable end-state and is the natural follow-up when instance count grows.
- **Keep the "clone it yourself first" throw.** That *is* the manual dead-end this task exists to remove.
- **Scaffold from a template repo (fork).** Adds a template-repo to maintain + a fork step; `bongos init --vendor-core` already produces the exact tree from the live core, single-source.
