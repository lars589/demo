// modules/discord/db.js — the discord module's data layer (BV1.R47 / task 1416).
//
// Two halves, behind ONE `db` surface so the moved discord-*.js files keep their
// existing `const db = require('./db')` call sites unchanged:
//
//   • DOMAIN queries the module OWNS — the discord_links / discord_applause
//     tables (created by migration 067) + the discord-bug-filing count over the
//     shared audit_log. These were lifted verbatim from src/bongos/db.js; the module
//     reaches Postgres through the published doorway's `pool` (ADR 0083 — a module
//     never requires a core internal like ../../src/bongos/db).
//
//   • KERNEL db helpers the module CONSUMES — insertAuditLog / createTask /
//     getBuilderById + the LIVE_RANK_LADDER constant — re-exported straight off
//     the doorway so a single `db.*` namespace serves both.
//
// The boundary: this file requires ONLY src/module-api.js. The three DISCORD-ONLY
// queries (getBuilderByDiscordUserId / listDiscordLinks / countRecentDiscordBugFilings)
// were removed from src/bongos/db.js — they live here now. getDiscordLink +
// recordApplause are INTENTIONALLY duplicated: core keeps its copies (the OAuth
// link flow in routes/auth.js + a seed still call them) and this module owns its
// own (a module can't import core db). Both read the same discord_links /
// discord_applause tables.

'use strict';

const api = require('../../src/module-api');
const { pool } = api;

// --- domain: the discord_links / discord_applause tables this module owns ----

async function getBuilderByDiscordUserId(discordUserId) {
  const { rows } = await pool.query(
    `SELECT b.id, b.github_login, b.display_name, b.rank, b.status, b.system_role
       FROM discord_links dl
       JOIN builders b ON b.id = dl.builder_id
      WHERE dl.discord_user_id = $1`,
    [discordUserId]
  );
  return rows[0] || null;
}

async function listDiscordLinks() {
  const { rows } = await pool.query(
    `SELECT builder_id, discord_user_id FROM discord_links ORDER BY builder_id`
  );
  return rows;
}

async function getDiscordLink(builderId) {
  const { rows } = await pool.query(
    `SELECT builder_id, discord_user_id, linked_at FROM discord_links WHERE builder_id = $1`,
    [builderId]
  );
  return rows[0] || null;
}

async function countRecentDiscordBugFilings(builderId, sinceIso) {
  const { rows } = await pool.query(
    `SELECT count(*)::int AS n
       FROM audit_log
      WHERE builder_id = $1
        AND route = 'discord:bugs'
        AND response_status = 201
        AND recorded_at > $2`,
    [builderId, sinceIso]
  );
  return rows[0].n;
}

async function recordApplause({ targetTaskId, discordUserId }) {
  const { rowCount } = await pool.query(
    `INSERT INTO discord_applause (target_task_id, discord_user_id)
     VALUES ($1, $2)
     ON CONFLICT (target_task_id, discord_user_id) DO NOTHING`,
    [targetTaskId, discordUserId]
  );
  return { counted: rowCount > 0 };
}

module.exports = {
  // domain (this module's tables)
  getBuilderByDiscordUserId,
  listDiscordLinks,
  getDiscordLink,
  countRecentDiscordBugFilings,
  recordApplause,
  // kernel db helpers, re-exported off the doorway (one `db.*` namespace)
  insertAuditLog: (...a) => api.insertAuditLog(...a),
  // createTask is a LIFECYCLE write — resolve the `lifecycle` kernel port at call
  // time (the doorway leak retired at BV1.R86); used by discord-bugs (#bugs → task).
  createTask: (...a) => api.resolveOptional('lifecycle').createTask(...a),
  getBuilderById: (...a) => api.getBuilderById(...a),
  get LIVE_RANK_LADDER() { return api.LIVE_RANK_LADDER; },
  // the shared pool, for any module file that wants it via db.pool
  pool,
};
