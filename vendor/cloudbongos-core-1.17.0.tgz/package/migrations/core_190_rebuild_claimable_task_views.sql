-- core_190_rebuild_claimable_task_views.sql — task 2024: goal filter on the
-- Work Board silently drops every task when a real goal is selected.
--
-- Root cause: claimable_tasks and tasks_session_fit are both `SELECT t.*, ...`
-- views over `tasks`. Postgres freezes a `SELECT t.*` view's output column
-- list at CREATE VIEW time — a later `ALTER TABLE tasks ADD COLUMN` does NOT
-- retroactively add that column to the view. The last migration to rebuild
-- these two views was 044 (tasks_requires_rank). Six columns landed on
-- `tasks` since then and never made it into either view:
--   081 needs_migration, 084 security_sensitive, 093 sandbox_review,
--   160 goal_id, 165 module_key, 177 reward_gate_exempt.
-- (086 and 176 correctly skipped a rebuild — they only changed the *values*
-- of an already-projected column, not the column list.)
--
-- `/api/gds/tasks/claimable` (modules/hall-ui/public/work.js) reads goal_id
-- off this exact feed to populate + filter the Work Board's Goal dropdown
-- (task 1755): every row's goal_id comes back undefined, so
-- `String(t.goal_id) !== gFilter` never matches any real goal and picking one
-- empties the list — the reported bug. The other five missing columns are
-- the same class of silent bug, just not yet reported.
--
-- Fix: rebuild both views (DROP+CREATE) with bodies identical to 044's — the
-- `SELECT t.*` wildcard then re-expands to every current column, including
-- the six added since. No WHERE/CASE logic changes.
--
-- Idempotent: safe to re-run.

BEGIN;

DROP VIEW IF EXISTS claimable_tasks;
CREATE VIEW claimable_tasks AS
SELECT t.*,
       pms_calibrated_minutes(t.est_minutes, t.kind) AS est_minutes_calibrated
  FROM tasks t
 WHERE t.status = 'ready'
   AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
   AND NOT EXISTS (
     SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id
   )
   AND NOT EXISTS (
     SELECT 1 FROM claims c
       JOIN tasks t2 ON t2.id = c.task_id
      WHERE c.released_at IS NULL
        AND t2.touches && t.touches
   );

DROP VIEW IF EXISTS tasks_session_fit;
CREATE VIEW tasks_session_fit AS
SELECT t.*,
  CASE
    WHEN t.automation_tag = 'overnight-safe' AND COALESCE(t.manual_degree, 5) <= 2
         AND NOT EXISTS (SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id)
      THEN ARRAY['autonomous','check-in','active']
    WHEN t.automation_tag = 'live-only' OR COALESCE(t.manual_degree, 5) >= 4
      THEN ARRAY['active']
    ELSE ARRAY['check-in','active']
  END AS fits_session_modes,
  pms_calibrated_minutes(t.est_minutes, t.kind) AS est_minutes_calibrated,
  CASE
    WHEN t.credits_reward > 0
     AND pms_calibrated_minutes(t.est_minutes, t.kind) IS NOT NULL
     AND pms_calibrated_minutes(t.est_minutes, t.kind) > 0
    THEN ROUND(t.credits_reward::numeric / pms_calibrated_minutes(t.est_minutes, t.kind), 3)
    ELSE NULL
  END AS credits_per_minute
FROM tasks t;

INSERT INTO schema_migrations (version) VALUES ('core_190_rebuild_claimable_task_views')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
