-- V3.R14 (#238) — onboarding observability columns on builders.
--
-- Two new timestamps on builders so the Archon can see the funnel
-- (signed in → shipped first task) without crawling credit_log and
-- session_logs by hand:
--
--   1. onboarded_at — the moment this builder first crossed the gate.
--      Today that's effectively created_at (first upsert from the
--      GitHub OAuth callback), but we capture it as a separate column
--      so we can move the definition later (e.g. "completed the
--      welcome quest") without rewriting history.
--
--   2. first_ship_at — the moment this builder's first task hit
--      'shipped' (auto-merged + deployed). The gap between
--      onboarded_at and first_ship_at is the *time-to-first-ship* —
--      the single most useful onboarding metric we don't yet
--      surface. Archon roster will render TTFS per builder.
--
-- Backfill strategy:
--   - onboarded_at ← created_at  (the closest proxy we have).
--   - first_ship_at ← MIN(t.shipped_at) WHERE t.shipped_by = b.id
--     across shipped tasks. Builders who haven't shipped stay NULL.
--
-- The write-side bump (shipTask in src/bongos/db.js) is responsible for
-- keeping first_ship_at honest going forward via
-- `UPDATE builders SET first_ship_at = COALESCE(first_ship_at, now())`.

BEGIN;

ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS onboarded_at  timestamptz,
  ADD COLUMN IF NOT EXISTS first_ship_at timestamptz;

-- Backfill onboarded_at from created_at. Idempotent — only fills NULLs,
-- so re-running this migration after a partial run is safe.
UPDATE builders
   SET onboarded_at = created_at
 WHERE onboarded_at IS NULL;

-- Backfill first_ship_at from the earliest shipped task per builder.
-- tasks.shipped_by is the canonical author key set by shipTask; tasks
-- that never reached 'shipped' have shipped_at NULL and are excluded.
UPDATE builders b
   SET first_ship_at = sub.first_ship_at
  FROM (
    SELECT shipped_by AS builder_id, MIN(shipped_at) AS first_ship_at
      FROM tasks
     WHERE shipped_by IS NOT NULL
       AND shipped_at IS NOT NULL
     GROUP BY shipped_by
  ) sub
 WHERE b.id = sub.builder_id
   AND b.first_ship_at IS NULL;

-- Cheap roster sort: builders with the longest time-to-first-ship rise
-- to the top of "still onboarding" queries. Index on (first_ship_at) is
-- sparse (only ships have non-NULL) but the partial-index covering
-- still-onboarding rows is what the Archon roster will hit most often.
CREATE INDEX IF NOT EXISTS idx_builders_first_ship_at
  ON builders (first_ship_at);

CREATE INDEX IF NOT EXISTS idx_builders_still_onboarding
  ON builders (onboarded_at)
  WHERE first_ship_at IS NULL;

COMMIT;
