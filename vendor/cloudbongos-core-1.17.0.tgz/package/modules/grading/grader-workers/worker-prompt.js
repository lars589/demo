// src/bongos/grader-workers/worker-prompt.js
//
// Shared prompt scaffold for the four grader workers (task 1090, C6). All four
// build the SAME fenced structure — NOFOLLOW_PREAMBLE emitted once, the title
// run through scrubUntrusted, and the four untrusted artifacts wrapped in
// fenceBlock (TASK DESCRIPTION, BUILDER VALUE SUMMARY, CHANGED FILE LIST,
// UNIFIED DIFF). Centralizing it keeps the SR-15/#995 prompt-injection fencing
// in ONE auditable place. Per-worker text (header, section labels, the final
// instruction) is passed in; a worker that needs an extra block — Quality's /
// Efficiency's diff-size section, or Hacker's deterministic-findings section —
// builds those lines itself (with its OWN extra scrub where required, e.g.
// Hacker's safe()) and passes them via `afterKindLines` (inserted right after
// the Kind/Discipline line) or `beforeDiffLines` (inserted right before the
// Unified diff). Behavior-neutral: produces the identical string the inlined
// builders produced for the same inputs.
const { fenceBlock, scrubUntrusted, NOFOLLOW_PREAMBLE } = require('./fence');

// The instance's project name for the worker identity lines, so a non-OTB Cloud
// Bongos instance is graded against ITS OWN project instead of a hardcoded "Off
// the Boats" (ADR 0062 §3/§5; the branding contract's llmProjectName field).
// Resolved through the published doorway — the ONE core surface a module may
// require (the modules/grading boundary rule) — never a deep core require.
// Centralized here, the shared scaffold, so all four workers read one source.
// Resolved once at module load (the brand is a per-process singleton); falls back
// to a neutral phrase if branding fails to resolve so a config error never crashes
// the gate.
const LLM_PROJECT = (() => {
  try { return require('../../../src/module-api').branding().llmProjectName || 'this project'; }
  catch { return 'this project'; }
})();

function buildWorkerPrompt({
  header, task, valueSummary, diff, changedFiles,
  taskHeader, descLabel, emptyFilesText, readFilesHint, finalInstruction,
  afterKindLines = [], beforeDiffLines = [],
}) {
  const t = task || {};
  const desc = (t.description || '(no description)').trim();
  const title = (t.title || '(no title)').trim();
  const vs = (valueSummary || '(no value summary)').trim();
  const files = Array.isArray(changedFiles) ? changedFiles : [];
  const diffText = (diff || '(empty diff)').trim();

  const lines = [];
  lines.push(header);
  lines.push('');
  lines.push('---');
  lines.push(NOFOLLOW_PREAMBLE);
  lines.push('');
  lines.push('---');
  lines.push(taskHeader);
  lines.push('');
  lines.push(`**ID:** ${t.id ?? '(unknown)'}`);
  lines.push(`**Title:** ${scrubUntrusted(title)}`);
  lines.push(`**Kind:** ${t.kind ?? 'unclassified'}  ·  **Discipline:** ${t.discipline ?? 'unclassified'}`);
  lines.push(...afterKindLines);
  if (t.version_id) lines.push(`**Version:** ${t.version_id}`);
  lines.push('');
  lines.push(descLabel);
  lines.push('');
  lines.push(...fenceBlock('TASK DESCRIPTION', desc));
  lines.push('');
  lines.push('---');
  lines.push('## Builder\'s value summary');
  lines.push('');
  lines.push(...fenceBlock('BUILDER VALUE SUMMARY', vs));
  lines.push('');
  lines.push('---');
  lines.push(`## Changed files (${files.length})`);
  lines.push('');
  if (files.length === 0) {
    lines.push(emptyFilesText);
  } else {
    lines.push(...fenceBlock('CHANGED FILE LIST', files.map((f) => `- ${f}`).join('\n')));
  }
  lines.push('');
  lines.push(readFilesHint);
  lines.push('');
  lines.push(...beforeDiffLines);
  lines.push('---');
  lines.push('## Unified diff');
  lines.push('');
  lines.push(...fenceBlock('UNIFIED DIFF', diffText));
  lines.push('');
  lines.push(finalInstruction);
  return lines.join('\n');
}

module.exports = { buildWorkerPrompt, LLM_PROJECT };
