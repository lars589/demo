// GDS version-close gate logic (PMS-V2 task #42, bucket E2).
//
// A version is "ready to close" iff BOTH:
//   (a) version_progress.percent_complete >= 80
//   (b) every done_when_criteria row for the version is satisfied
// Both required, per Lars's planning decision (limitations/pms-v2.md
// "Open questions resolved" — Auto-versioning gate).
//
// This module ONLY evaluates the gate and prepares a suggestion. It does
// not close anything. Operator action lives in /builder-version-close
// (separate task #43).

const { pool } = require('../../src/module-api');

const PERCENT_GATE = 80;

async function getProgressRow(versionId) {
  const { rows } = await pool.query(
    `SELECT shipped_count, total_count, shipped_weight, total_weight
       FROM version_progress
      WHERE version_id = $1`,
    [versionId]
  );
  if (rows.length === 0) return null;
  const r = rows[0];
  const total = Number(r.total_weight);
  const shipped = Number(r.shipped_weight);
  return {
    shippedCount: Number(r.shipped_count),
    totalCount: Number(r.total_count),
    percentComplete: total > 0 ? Math.round((shipped / total) * 100) : 0,
  };
}

async function getCriteriaCounts(versionId) {
  const { rows } = await pool.query(
    `SELECT count(*) FILTER (WHERE satisfied) AS satisfied,
            count(*) AS total
       FROM done_when_criteria
      WHERE version_id = $1`,
    [versionId]
  );
  return {
    satisfied: Number(rows[0].satisfied),
    total: Number(rows[0].total),
  };
}

async function getCarryOverCount(versionId) {
  // Mirrors the version_progress filter (migration 017): abandoned is a
  // terminal state, not carry-over. Counting it would re-introduce the same
  // overcounting the view fixes.
  const { rows } = await pool.query(
    `SELECT count(*) AS n
       FROM tasks
      WHERE version_id = $1
        AND status NOT IN ('shipped', 'abandoned')
        AND title NOT LIKE '\\_\\_smoke\\_\\_%' ESCAPE '\\'`,
    [versionId]
  );
  return Number(rows[0].n);
}

// Rich object for the close-flow planner. Always returns the same shape
// even when nothing matches, so callers can render the same template.
async function suggestClose(versionId) {
  const progress = (await getProgressRow(versionId)) || {
    shippedCount: 0,
    totalCount: 0,
    percentComplete: 0,
  };
  const criteria = await getCriteriaCounts(versionId);
  const carryOver = await getCarryOverCount(versionId);
  const ready =
    progress.percentComplete >= PERCENT_GATE &&
    criteria.total > 0 &&
    criteria.satisfied === criteria.total;
  return {
    versionId,
    percentComplete: progress.percentComplete,
    criteriaTotal: criteria.total,
    criteriaSatisfied: criteria.satisfied,
    tasksShipped: progress.shippedCount,
    tasksCarryOver: carryOver,
    ready,
  };
}

// Suggestions for every version still in 'building' status.
// Used by GET /api/gds/versions/close-suggestions and by /builder-start.
async function getCloseSuggestionsForBuildingVersions() {
  const { rows: versions } = await pool.query(
    `SELECT id FROM versions WHERE status = 'building' ORDER BY started_at, id`
  );
  const out = [];
  for (const v of versions) {
    out.push(await suggestClose(v.id));
  }
  return out;
}

module.exports = {
  PERCENT_GATE,
  suggestClose,
  getCloseSuggestionsForBuildingVersions,
};
