# Recipe — stand up cloudbongos.com (Customer 0, the vanilla dogfood instance)

> Brings **cloudbongos.com** live as a real Cloud Bongos instance: the vanilla brand, its own database, no game code — Cloud Bongos running on Cloud Bongos (the C8 proof, [ADR 0062](../adr/<redacted>.md) §2, task [#1374](https://example.com/builders#/task/1374) + the proof ship [#1206](https://example.com/builders#/task/1206)). Owner-only inputs are tracked in blocker [#40](https://example.com/builders#/blocker/40).

## Architecture (what we're building)

Same droplet as OTB (`REDACTED_IP`), **separate process + separate database**, no new monthly cost. One checkout (`/home/lars/example`) runs **two** processes:

| Instance | Entrypoint | Brand | Port | DB | Domain |
|---|---|---|---|---|---|
| OTB (game) | `server.js` | `config/branding.json` (default) | 3000 | `example` | example.com |
| **Cloud Bongos** | `src/platform-server.js` | `config/branding.cloudbongos.json` (via `GDS_BRANDING_FILE`) | **3002** | **`cloudbongos`** | **cloudbongos.com** |

The only difference between the two processes is **environment** — no divergent clone. The brand switch is `src/branding.js`'s `GDS_BRANDING_FILE` knob (task 1374). The landing page is served at the apex by `platform-server.js`; the Hall + status ride `builders.`/`status.` (host routing in `src/bongos/serve-internal.js`).

## Phase ① — DNS  ✅ done

Domain on Cloudflare (Free plan), nameservers switched, **SSL/TLS = Full (strict)**, three **proxied** A records → `REDACTED_IP`:
`cloudbongos.com` (`@`), `builders`, `status`. (Until the origin cert + process are up, the site shows a TLS error — expected.)

## Phase ② — GitHub OAuth App (builder sign-in)

GitHub → Settings → Developer settings → **OAuth Apps** → **New OAuth App**:
- **Application name:** `Cloud Bongos`
- **Homepage URL:** `https://cloudbongos.com`
- **Authorization callback URL:** `https://cloudbongos.com/api/gds/auth/web/callback` (PINNED — `auth.js` `WEB_REDIRECT_ORIGIN`; sign-in begun on `builders.` still calls back to the apex)
- **Enable Device Flow:** ✅ (the CLI login uses it)

Copy the **Client ID** + generate a **Client Secret** → they go in `/etc/cloudbongos/web.env` as `CLOUDBONGOS_GITHUB_CLIENT_ID` / `CLOUDBONGOS_GITHUB_CLIENT_SECRET` (resolved as `<ENVPREFIX>_GITHUB_*`; vanilla envPrefix = `CLOUDBONGOS`).

## Phase ③ — Cloudflare Origin Certificate (own domain → own cert)

cloudbongos.com is a different domain, so it needs its **own** Origin Cert (the example cert's SANs don't cover it). Cloudflare → **SSL/TLS → Origin Server → Create Certificate**:
- Hostnames: `cloudbongos.com` **and** `*.cloudbongos.com`
- Let Cloudflare generate the key; **copy both** the certificate and the private key.

Install on the droplet (operator). **Caddy runs as user `caddy` and must be able to READ the key** — match the existing `origin.key` ownership (`640 root:caddy`). A root-only `600` key makes Caddy's reload fail and loop (the OTB site keeps serving the old config, but the new site never comes up — seen during the first bring-up). The `.crt` can be world-readable.
```bash
sudo install -m 644 -g caddy /dev/stdin /etc/caddy/cloudbongos-origin.crt   # paste cert, Ctrl-D
sudo install -m 640 -g caddy /dev/stdin /etc/caddy/cloudbongos-origin.key   # paste key,  Ctrl-D
```

## Phase ④ — Droplet bring-up (operator)

```bash
# 1. The instance database (peer auth via the local socket, same as OTB)
createdb cloudbongos

# 2. GDS-only schema (skips migrations/game/*.sql — no game tables on this instance)
cd /home/lars/example
PGDATABASE=cloudbongos MEDUSA_GDS_ONLY=1 ./scripts/migrate.sh

# 3. Secrets file (from infra/cloudbongos.env.example)
sudo mkdir -p /etc/cloudbongos
sudo cp infra/cloudbongos.env.example /etc/cloudbongos/web.env
sudo $EDITOR /etc/cloudbongos/web.env       # fill the OAuth client id + secret
sudo chmod 600 /etc/cloudbongos/web.env && sudo chown lars:lars /etc/cloudbongos/web.env

# 4. systemd service (from infra/cloudbongos.service)
sudo cp infra/cloudbongos.service /etc/systemd/system/cloudbongos.service
sudo systemctl daemon-reload
sudo systemctl enable --now cloudbongos
curl -sS http://127.0.0.1:3002/healthz        # → "ok"

# 5. Caddy — the three cloudbongos blocks are in infra/Caddyfile; apply + reload
sudo cp infra/Caddyfile /etc/caddy/Caddyfile  # or merge the cloudbongos blocks in
sudo systemctl reload caddy
```

## Phase ⑤ — Verify + first sign-in

```bash
curl -sS https://cloudbongos.com/healthz              # "ok" (through Cloudflare now)
curl -sS https://cloudbongos.com/ | grep -o 'cloud bongos'   # the landing
```
- `https://cloudbongos.com` → the buddha landing.
- `https://builders.cloudbongos.com` → the Hall. **Sign in with GitHub.** Because the pack sets `firstAdmin: "example-owner"`, that first sign-in auto-seats example-owner as **Owner/Archon** on the (empty) cloudbongos DB — no manual step (`auth.js` `maybeSeatFirstAdmin`).
- `https://status.cloudbongos.com` → the dashboard.

## Deploy automation (important — updated for the dedicated box)

> **This changed with [ADR 0126](../adr/<redacted>.md).** cloudbongos.com no longer runs co-tenant on the OTB box. It runs on its **own dedicated droplet** (`REDACTED_IP`, checkout `<redacted>`) and tracks `main` via a **pull-based `systemd` timer** — [ADR 0129](../adr/<redacted>.md), task [#2064](https://example.com/builders#/task/2064). The co-hosting box's CI deploy no longer touches it. (The historical "wire `sudo systemctl restart cloudbongos` into `~/deploy.sh`" note applied only while it was a co-tenant.)

Once the box exists, the deploy is [`scripts/deploy/deploy-cloudbongos.sh`](../../scripts/deploy/deploy-cloudbongos.sh) fired by [`infra/cloudbongos-deploy.timer`](../../infra/cloudbongos-deploy.timer) every ~2 min: `git fetch` + reset `origin/main` → `npm ci` (if the lockfile changed) → `PGDATABASE=cloudbongos MEDUSA_GDS_ONLY=1 ./scripts/migrate.sh` → `sudo systemctl restart cloudbongos` → 3002 healthz. After the first install it **self-heals** (each run refreshes `/home/lars/deploy.sh` + the units from the checkout).

**One-time bootstrap** (operator, over SSH to the box — the box can't install its own first deploy automation). Run once the deploy files are on `main`:
```bash
# Executed as a STABLE copy outside the checkout (so `git reset --hard` can't
# corrupt the running script — see ADR 0129):
sudo -u lars install -m 0755 <redacted>/scripts/deploy/deploy-cloudbongos.sh /home/lars/deploy.sh
sudo install -m 0644 <redacted>/infra/cloudbongos-deploy.service /etc/systemd/system/
sudo install -m 0644 <redacted>/infra/cloudbongos-deploy.timer   /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now cloudbongos-deploy.timer
# Verify: one forced run brings the box current + smokes the chain
sudo -u lars FORCE_DEPLOY=1 /home/lars/deploy.sh
systemctl list-timers cloudbongos-deploy.timer --no-pager
curl -sS https://cloudbongos.com/healthz     # → "ok"
```

## The C8 proof (task 1206) — ✅ DONE 2026-06-21

With the instance live, **one real task** went through the full lifecycle **on cloudbongos.com** — claim → grade (the real 4-worker panel, PASS) → merge → ship, credits awarded — carrying zero game code: **cloudbongos task [#1](https://example.com/builders#/task/1)** (under version CB-V1), the `GDS_MODULES_FILE` fix that made Customer-0 advertise its modules correctly all-off. That shipped task is the C8 acceptance ("the GDS builds itself"). Full record + the operational mechanics for driving cloudbongos.com's GDS from the CLI: [2026-06-21 — C8 self-build proof](../session-logs/<redacted>.md). Closes task [#1206](https://example.com/builders#/task/1206).

## Files this recipe uses

- `config/branding.cloudbongos.json` — the customer-0 brand pack (deltas over `config/branding.neutral.json`).
- `src/branding.js` — the `GDS_BRANDING_FILE` selector.
- `src/platform-server.js` — GDS-only entrypoint + the apex landing mount.
- `public-landing/index.html` — the landing page (mascot at `public-landing/buddha.png`).
- `infra/cloudbongos.service`, `infra/cloudbongos.env.example`, `infra/Caddyfile` (the cloudbongos blocks).
