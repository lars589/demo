# ADR 0132 — Migrating the co-hosting fleet to the control plane over an SSH DB tunnel

**Status:** Accepted — repo half implemented 2026-07-05 (task [#2071](https://example.com/builders#/task/2071)); **units ship additive + not-enabled — activation is a sequenced operator-op** (see §Activation). Extends [ADR 0130](<redacted>.md); completes the "zero cloud tokens on the co-hosting box" goal of [ADR 0126](<redacted>.md) (task 2065 / blocker 64).

## Context

[ADR 0130](<redacted>.md) shipped the *code* to run `provision.js` from the control plane and remote-exec box steps over SSH. But when we went to actually strip the tokens (blocker 64), the endgame proved **not a switch-flip**. Three findings:

1. **The co-hosting box (`REDACTED_IP`) runs FIVE token-consuming timers, not one.** ADR 0130 addressed only `provision-intent-runner`. The other four are the whole `box.js` **dev-box lifecycle**: `box-intent-runner` (provision/wake, 1-min), `box-idle-suspend` (15-min), `box-drift-reconcile` (hourly), `box-dormant-reclaim` (daily). Each needs the DO token; none were migrated.
2. **Every runner reads its work-queue from the *local* `example` Postgres, which is firewalled to localhost** (`pg_hba`: `host … 127.0.0.1/32 scram-sha-256`; `:5432` is closed to the network — the correct posture). A runner moved to the control plane cannot reach the `box_intents` / `provisioning_intents` queues remotely. This is the real obstacle ADR 0130 did not solve: it moved *box-step execution*, not *queue reading*.
3. **`box.js` needs no code change** — its only shell-outs are `scripts/discord/post.js` and the `BOX_DNS_HOOK` (both present on the control plane with its tokens); everything else is DigitalOcean/Cloudflare HTTP. So the blocker is purely *"how does a control-plane runner reach the example queues."*

At migration time the fleet was **dormant** — 0 live dev-box droplets, 0 hosted co-tenants, empty provisioning queue — so the cutover risk was low, but the dev-box capability is real (builders connect to dev boxes via Claude Desktop), so it must keep working. The owner chose the full migration over a token-strip-and-defer.

## Decision

Give the control plane a secure path into the co-hosting box's `example` Postgres via a **persistent SSH tunnel**, and run **all five runners on the control plane** as `cohost-*` unit variants that read the queues through the tunnel, call the DO/CF APIs with the control-plane tokens, and (for provisioning) remote-exec box steps over SSH per ADR 0130.

### The tunnel

`infra/cohost-db-tunnel.service` holds a long-lived `ssh -N -L 127.0.0.1:5433:127.0.0.1:5432 cohost` (Restart=always, ServerAlive keepalives). The runners set `DATABASE_URL=<redacted> (`pool.js` honors `DATABASE_URL` first), so they read/write the example queues through the encrypted forward. **No Postgres port is ever exposed to the network** — the tunnel terminates at the co-hosting box's own localhost.

**Why a tunnel, not the alternatives.** (a) *Expose Postgres over DO private networking* — still opens a TCP surface + needs `pg_hba`/credential work, and the two droplets aren't guaranteed same-VPC. (b) *A token-signing broker on the co-hosting box* — leaves runners (and thus tokens' blast radius) on the co-hosting box, the opposite of the goal, and is far more code. (c) *Move the queue tables to the cloudbongos DB* — the OTB web tier enqueues them and can't reach the control-plane DB either (firewall symmetry); it splits the game's data. The tunnel keeps the data where it is, moves only execution, and reuses the SSH trust ADR 0130 already needs.

### The DB credential

`pg_hba` already permits `host … 127.0.0.1/32 scram-sha-256`, and the `lars` role had **no password**. Activation sets a scram password on the existing `lars` role (`ALTER ROLE lars WITH PASSWORD …`) and stores it only in the chmod-600 `/etc/cloudbongos/cohost-fleet.env` on the control plane. We reuse `lars` (not a new scoped role) deliberately: it is the **same role the runners already run as** on the co-hosting box (via peer auth), so privileges are identical and nothing can be under-granted. The password widens nothing — the role is reachable only from `127.0.0.1` (the tunnel endpoint), and SSH-as-`lars` is already full box access.

### The units

Eleven files in `infra/`: the tunnel + control-plane variants of all five runners (`cohost-box-intent-runner`, `cohost-box-idle-suspend`, `cohost-box-drift-reconcile`, `cohost-box-dormant-reclaim`, `cohost-provision-intent-runner`) with their timers. Each differs from the co-hosting original only in `WorkingDirectory=/home/lars/cloudbongos`, `EnvironmentFile=/etc/cloudbongos/{box.env,cohost-fleet.env}`, and (provision only) the ADR 0130 remote-exec env pointing `PROVISION_REMOTE_HOST=cohost`. **`cohost-provision-intent-runner` supersedes the confusingly-named `provision-intent-runner-cloudbongos.*` from task 2065** (same design, named for the fleet it drives, wired to the example DB via the tunnel; the old files are deleted). The pre-existing `cloudbongos-provision-intent-runner` (task 2056, local `cloudbongos` DB) is unrelated and stays.

`deploy-cloudbongos.sh` self-heals these units **install-only** (copy + daemon-reload, never enable) so a redeploy/re-provision keeps them fresh without ever auto-activating (ADR 0129 durability, but activation stays manual).

## Security posture

A one-directional **control-plane → co-hosting SSH edge**: the token-holder commands the token-free box, never the reverse. The tunnel + the ADR 0130 remote-exec both ride the single `cohost` key (this box's key in the co-hosting box's `authorized_keys`, restrictable `from="REDACTED_IP"`). After activation + rotation the co-hosting box — the public-facing box that runs the live game — holds **zero account-wide cloud tokens**, which is the whole point (ADR 0126).

## Activation (sequenced operator-op — do NOT reorder)

1. **SSH trust.** On the control plane, generate `~lars/.ssh/cohost_ed25519` + a `cohost` `~/.ssh/config` alias; add its pubkey to `~lars/.ssh/authorized_keys` on the co-hosting box. Verify `sudo -u lars ssh cohost true` from the control plane.
2. **DB password + fleet env.** `ALTER ROLE lars WITH PASSWORD …` on the co-hosting box; write `/etc/cloudbongos/cohost-fleet.env` (chmod 600) with `HOME=/home/lars` + `DATABASE_URL=…@127.0.0.1:5433/example`.
3. **Tunnel up.** `systemctl enable --now cohost-db-tunnel`; verify `psql "$DATABASE_URL" -c 'select 1'` from the control plane.
4. **Enable the 5 `cohost-*` runners** on the control plane AND **disable the 5 generic runners on the co-hosting box in the same window** — never both (double-drain). Run each `cohost-*` once to confirm a clean connect + drain.
5. **Verify** end-to-end via `cohost-box-drift-reconcile` from the control plane (DB read via tunnel + DO API + DB write).
6. **Bake with the tokens still in place** as the rollback net: any problem ⇒ re-enable the co-hosting timers (their tokens still work) and disable the control-plane ones.
7. **Owner, after bake (irreversible, cloud-console — stays blocker 64):** remove `DO_API_TOKEN` + `CLOUDFLARE_API_TOKEN` from `/etc/example/box.env` and **rotate both** in the DigitalOcean + Cloudflare dashboards; then `dropdb cloudbongos` on the co-hosting box (the ADR 0126 rollback DB) once cloudbongos.com has baked healthy on its own droplet.

## Consequences

- The co-hosting box's provisioning/dev-box control moves off it entirely; after step 7 it is token-free.
- One new always-on SSH connection (the tunnel) — negligible cost; auto-reconnects.
- A runner tick that fires while the tunnel is momentarily down just fails its DB connect and retries next tick (1–2 min) — acceptable, no state corruption (`claimNextIntent` is `FOR UPDATE SKIP LOCKED`).
- Rollback is a two-command switch (re-enable co-hosting timers, disable control-plane ones) as long as step 7 hasn't run — which is why the token strip/rotate is gated behind a bake.
