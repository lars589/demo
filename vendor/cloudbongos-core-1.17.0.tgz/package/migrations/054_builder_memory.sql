-- 054_builder_memory.sql — V3.R54 (#273): server-side store for a builder's
-- Claude Code per-session memory dir. Implements ADR 0024 §1 (schema) and is
-- the storage half of §4 (per-builder isolation — enforced at the helper +
-- route layers, with the PRIMARY KEY making cross-builder collisions
-- impossible by construction).
--
-- What "memory" is here (ADR 0024 "What memory means"):
-- ----------------------------------------------------
-- NOT code (git is canonical), NOT work-state (the GDS tables are canonical).
-- This is the third artifact class: the markdown that Claude Code itself writes
-- under ~/.claude/projects/<encoded-project>/memory/*.md (MEMORY.md,
-- feedback_*.md) plus any builder-authored persistent context that isn't a git
-- file and isn't a GDS row. Today it lives only on one laptop; this table is
-- where it becomes server-canonical so it can follow a builder across machines
-- and survive a dead laptop. #274 (push-on-ship) and #275 (pull-on-start) wire
-- the round-trip; this task only lays the table + the helper layer.
--
-- Schema choice — Postgres TEXT, per-file rows (ADR 0024 §1)
-- ---------------------------------------------------------
-- The spike weighed BYTEA-per-file vs object storage (DO Spaces / S3) and chose
-- Postgres TEXT in one new table:
--   * content is TEXT, not BYTEA — memory files are markdown; being readable in
--     `psql` for forensics is a real Archon convenience, and the values are
--     kilobytes.
--   * Object storage was REJECTED: +$5/mo minimum, +an SDK dependency, +a second
--     auth surface, +a second backup story — all to solve a problem (large
--     binary blobs) we don't have. Revisit only if per-file sizes routinely
--     exceed 100 KB or the table passes ~1 GB and pg_dump time becomes painful.
--   * git-backed memory was REJECTED: it would leak one builder's memory diffs
--     into the public repo, contradicting the isolation requirement.
--
-- PRIMARY KEY (builder_id, path): one row per (builder, relative-path). `path`
-- is the path under the builder's memory dir (e.g. 'MEMORY.md',
-- 'feedback_auth_flows_ui_first.md'). A push for an existing (builder_id, path)
-- is an UPSERT (last-write-wins per ADR 0024 §3 — applied in #274's push
-- handler; the table just stores whatever the winning write left).
--
-- Quotas (ADR 0024 §1) are enforced at the HELPER layer (src/bongos/memory.js),
-- not by DB constraints, so the API can return clean 413s with a prune hint:
--   * 1 MB per file        (1000x current observed sizes)
--   * 50 MB per builder    (50,000x current)
--   * 2000 files per builder (defensive)
-- byte_len + sha256 are stored so the pull side (#275) can do cheap
-- newer/changed checks without shipping content, and so the per-builder total
-- can be summed without scanning content.
--
-- Backup (ADR 0024 §5): this is a plain Postgres table, so it rides the GDS
-- DB's nightly pg_dump (stood up by #412) for free. No separate backup story.
--
-- Idempotent: CREATE TABLE IF NOT EXISTS + IF NOT EXISTS indexes + ON CONFLICT
-- DO NOTHING migration row.

CREATE TABLE IF NOT EXISTS builder_memory (
  -- Owner. Every read/write is scoped by this column (ADR 0024 §4). FK so a
  -- row can never reference a ghost builder; ON DELETE CASCADE because a
  -- builder's memory has no meaning once the builder row is gone (unlike
  -- credit_log / cost_log, which preserve history on delete — memory is
  -- mutable scratch, not an audit trail).
  builder_id   bigint NOT NULL REFERENCES builders(id) ON DELETE CASCADE,
  -- Relative path under the builder's memory dir, e.g. 'MEMORY.md'. NOT a
  -- filesystem-absolute path — the local checkout path is hyphen-encoded and
  -- machine-specific (ADR 0024 §5 path-encoding gotcha); memory is keyed by
  -- (builder_id, relative-path) so it restores regardless of where on disk a
  -- checkout lives.
  path         text   NOT NULL CHECK (length(path) > 0),
  -- The file body. TEXT (markdown), not BYTEA — see header.
  content      text   NOT NULL,
  -- Client's reported mtime of the file at push time. The conflict policy
  -- (ADR 0024 §3) is last-write-wins on the SERVER clock; this column records
  -- the source file's mtime for the pull side's newer-than comparison and for
  -- forensics. Defaults to now() so a row is never left without one.
  mtime        timestamptz NOT NULL DEFAULT now(),
  -- Content hash + byte length: let the pull side (#275) detect unchanged files
  -- cheaply and let the helper sum a builder's total bytes without scanning
  -- content.
  sha256       text   NOT NULL,
  byte_len     integer NOT NULL CHECK (byte_len >= 0),
  -- When this row was first stored / last overwritten on the server. Distinct
  -- from mtime (which is the client file's timestamp). updated_at is the
  -- server's truth for "when did the canonical copy last change."
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (builder_id, path)
);

-- Primary access patterns:
--   * fetch one file:  WHERE builder_id = $1 AND path = $2  → served by the PK.
--   * list / sum for a builder: WHERE builder_id = $1       → served by the PK
--     prefix, but an explicit index on (builder_id, updated_at DESC) keeps the
--     "what changed since" pull query (#275) and the "newest first" listing
--     fast without leaning on PK ordering.
CREATE INDEX IF NOT EXISTS idx_builder_memory_builder_updated
  ON builder_memory (builder_id, updated_at DESC);

-- Auto-bump updated_at on every overwrite. Reuses the same trigger function the
-- tasks table uses (pms_touch_updated_at, defined in 003_pms.sql) — one
-- canonical "touch updated_at" function for the whole GDS schema.
DROP TRIGGER IF EXISTS trg_builder_memory_updated_at ON builder_memory;
CREATE TRIGGER trg_builder_memory_updated_at
  BEFORE UPDATE ON builder_memory
  FOR EACH ROW EXECUTE FUNCTION pms_touch_updated_at();

-- Keep the migration counter ahead of 054 so the next claim that includes
-- 'migrations/' allocates 055 (same convention as the recent migrations).
UPDATE migration_counter SET next_number = GREATEST(next_number, 55) WHERE id = 1;

INSERT INTO schema_migrations (version) VALUES ('054_builder_memory')
  ON CONFLICT (version) DO NOTHING;
