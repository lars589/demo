// public-builders/pair.js — the Dev Box desktop app's approve page (#904,
// ADR 0044). The app opened this URL with ?code=<pair_code>; the signed-in
// builder reviews what asked to connect and clicks ONE button. The server
// gate (requireBuilderPage in server.js) has already bounced unauthenticated
// visitors through web sign-in with this URL — code included — as ?return=.
(() => {
  'use strict';

  const API = '/api/bongos';
  // Generated typed client (task 1996 / R09), served as window.BongosClient by
  // /lib/bongos-client.js. baseUrl:'' passes the full `${API}/...` URLs below
  // through unchanged; result-mode ({ status, ok, data }) preserves control flow 1:1.
  const api = window.BongosClient.createClient({ baseUrl: '', credentials: 'same-origin', throwOnError: false });

  // escapeHtml / $ now come from the shared window.OTB toolkit (dom-utils.js,
  // loaded first). The shared $ accepts an optional root arg — a superset of
  // this page's prior single-arg form, so call sites are unchanged.
  const { escapeHtml, $ } = window.OTB;

  function toAuth() {
    const here = window.location.pathname + window.location.search;
    window.location.assign(`${API}/auth/web/start?return=${encodeURIComponent(here)}`);
  }

  const PLATFORM_LABELS = {
    mac: 'macOS', windows: 'Windows', linux: 'Linux', unknown: 'an unknown platform',
  };
  const PLATFORM_GLYPHS = { mac: '⌘', windows: '⊞', linux: '🐧', unknown: '🖥' };

  function renderError(heading, detail) {
    $('#pair-sub').textContent = heading;
    $('#pair-body').innerHTML = `
      <p class="scroll__lede">${escapeHtml(detail)}</p>
      <p class="pair-status pair-status--err">Return to the Dev Box app and click “Connect” again for a fresh code.</p>
    `;
  }

  function renderApproved(login) {
    $('#pair-sub').textContent = 'Approved.';
    $('#pair-body').innerHTML = `
      <p class="scroll__lede">
        The Dev Box app now acts as <strong>@${escapeHtml(login)}</strong>.
        Return to the app — it has already noticed. You can close this tab.
      </p>
      <p class="pair-status pair-status--ok">✓ Approved</p>
    `;
  }

  function renderRequest(info, login) {
    const plat = PLATFORM_LABELS[info.platform] || PLATFORM_LABELS.unknown;
    const glyph = PLATFORM_GLYPHS[info.platform] || PLATFORM_GLYPHS.unknown;
    $('#pair-sub').textContent = 'One click, and the app can act as you.';
    $('#pair-body').innerHTML = `
      <p class="scroll__lede">
        <strong>${escapeHtml(info.device_name)}</strong> on ${escapeHtml(plat)}
        is asking to sign in as <strong>@${escapeHtml(login)}</strong> —
        to start and stop your dev box on your behalf.
      </p>
      <div class="pair-device">
        <span class="pair-device__glyph" aria-hidden="true">${glyph}</span>
        <div>
          <div class="pair-device__name">${escapeHtml(info.device_name)}</div>
          <div class="pair-device__meta">${escapeHtml(plat)} · code <span class="pair-code">${escapeHtml(info.pair_code)}</span></div>
        </div>
      </div>
      <div class="pair-actions">
        <button type="button" class="pair-approve" id="pair-approve-btn">Approve — sign the app in as me</button>
        <span class="pair-status" id="pair-status" role="status" aria-live="polite"></span>
      </div>
    `;
    $('#pair-approve-btn').addEventListener('click', () => approve(info.pair_code, login));
  }

  async function approve(code, login) {
    const btn = $('#pair-approve-btn');
    const status = $('#pair-status');
    btn.disabled = true;
    status.textContent = 'Approving…';
    try {
      const res = await api.request('POST', `${API}/auth/app-pair/approve`, { body: { pair_code: code } });
      if (res.status === 401) return toAuth();
      if (res.status === 404 || res.status === 410) {
        return renderError('Request expired.', 'This pairing code is unknown or has expired (codes last ten minutes).');
      }
      if (res.status === 409) {
        return renderError('Already approved.', 'This pairing was already approved once — a code works exactly one time.');
      }
      if (!res.ok) throw new Error(`approve failed (${res.status})`);
      renderApproved(login);
    } catch (err) {
      btn.disabled = false;
      status.textContent = 'Approval failed — try again.';
      status.className = 'pair-status pair-status--err';
      console.error('[pair]', err);
    }
  }

  async function load() {
    const code = new URLSearchParams(window.location.search).get('code');
    if (!code) {
      return renderError('No code in this link.', 'The link is missing its pairing code.');
    }
    let me;
    try {
      const meRes = await api.request('GET', `${API}/me`);
      if (meRes.status === 401) return toAuth();
      if (!meRes.ok) throw new Error(`/me ${meRes.status}`);
      me = meRes.data;
    } catch (err) {
      console.error('[pair]', err);
      return renderError('Could not reach the server.', 'Could not verify your identity. Reload to try again.');
    }
    try {
      const res = await api.request('GET', `${API}/auth/app-pair/info?code=${encodeURIComponent(code)}`);
      if (res.status === 401) return toAuth();
      if (res.status === 404) {
        return renderError('Request expired.', 'This pairing code is unknown or has expired (codes last ten minutes).');
      }
      if (!res.ok) throw new Error(`info ${res.status}`);
      const info = res.data;
      if (info.status !== 'pending') {
        return renderError('Already approved.', 'This pairing was already approved once — a code works exactly one time.');
      }
      renderRequest(info, me.builder.github_login);
    } catch (err) {
      console.error('[pair]', err);
      renderError('Could not reach the server.', 'Could not read the pairing request. Reload to try again.');
    }
  }

  load();
})();
