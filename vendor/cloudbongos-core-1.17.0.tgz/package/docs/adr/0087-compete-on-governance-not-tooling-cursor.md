# ADR 0087 — Compete with Cursor on governance, not tooling

**Status:** Accepted (2026-06-24) · task [#1505](https://example.com/builders#/task/1505) · **companion to** [ADR 0083](<redacted>.md) (modular-architecture strangler build plan); builds on [ADR 0016](<redacted>.md) (server-enforced trust boundary), [ADR 0043](<redacted>.md) (rank floor on permission paths), [ADR 0061](<redacted>.md) (context-layer decomposition), [ADR 0081](<redacted>.md) (tool-agnostic design layer), [ADR 0024](<redacted>.md) (MAS). **Red-teams** [`docs/design/modular-architecture/`](../design/modular-architecture/).

## Context

Cursor (Anysphere) is Cloud Bongos's primary competitor. The owner's strategic frame: *"We are moving from collaboration into tooling; Cursor is moving from tooling into collaboration. They have a ~$60B headstart."* This ADR records the decisions that came out of a competitive analysis of Cursor's public domain (a 17-agent research workflow — 7 angles, ~250 web fetches, key claims adversarially re-verified against primary sources) run against our modular-architecture design.

**Verified competitor facts (2026-06-24 — fast-moving; re-verify before quoting):**

- **$60B is an acquisition price, not a valuation.** SpaceX agreed to acquire Anysphere all-stock at **$60B**, announced **2026-06-16**, pending a Q3-2026 close, folding Cursor under the xAI umbrella. It superseded a ~$50B April-2026 private round.
- **Scale:** ~$2–4B ARR, ~50,000 enterprise teams, ~64–67% of the Fortune 500, 1M+ daily users.
- **Their real moat is the usage-data → RL flywheel**, *not* model access (which is commoditized — analysts quote "burning $1 to make 90¢"; Anthropic throttled Cursor's Claude access in June 2025). Composer is RL-post-trained on their own users' coding trajectories atop an open base (Kimi K2.5); they are now training a from-scratch model on SpaceX/xAI compute. Plus enterprise switching costs.
- **They explicitly framed their own trajectory** as "from individual tool to org-wide platform" (Oct 2025) and shipped the collaboration layer: Organizations, Team Rules, Slack/GitHub/Linear-triggered agents, Bugbot-in-the-PR-loop, SOC2/SSO/SCIM/RBAC/audit/CMEK.

**The design under review** ([`docs/design/modular-architecture/`](../design/modular-architecture/), now built as ADR 0083) is sound engineering. But it frames **"scope the agent to a module" as the AI-quality *centerpiece*** ([00 §6](../design/modular-architecture/00-research-report.md)). Cursor ran the opposite experiment and has the data: learned, agent-driven retrieval over the *whole* indexed repo (custom embeddings + Merkle sync + chained semantic/grep) measured **+12.5% answer accuracy vs grep alone**, larger on 1,000+ file repos — and their guidance tells users *not* to pin context manually unless they already know what's relevant. That contradicts the design's framing and forces a correction.

## Decision

### 1. Module-affinity is a *boundary*, not a context-quality lever

Module scope answers **where a task's code may land** (ship-time diff⊆module + per-claim worktree). Retrieval answers **what the agent sees**. They are different axes and they *compose* — not compete.

- Treat the module as the agent's **default starting context, not a wall.** Adopt Cursor-style agentic retrieval *within and across* it (chain grep + `/recall` + the generated repo-map). This is consistent with our own [03-builder-flows.md](../design/modular-architecture/03-builder-flows.md): read-access is unwalled; only the *ship-time diff* is enforced.
- **Amends the design docs:** module-affinity is retained as an integrity/confidentiality boundary; its "centerpiece / smaller-context-is-higher-quality" framing is withdrawn.

### 2. Compete on governance, not tooling

Do **not** chase parity on the axes where Cursor is structurally ahead — editing UX (Tab, Fast Apply), model quality (Composer), distribution, scale, or capital. **Concede all of them.** Trying to out-tool a $60B incumbent on a $5k budget is the wrong axis of effort.

Compete where the **platform-native design is structurally ahead and Cursor is *retrofitting* onto client-trust**:

- the **server-enforced rank ladder** (ADR 0016) — authority lives in the DB, re-checked per request; local edits grant zero authority;
- the **immutable GDS ledger** (every claim → grade → ship is a permanent, attributable record);
- **per-claim worktree isolation** (treat it as a *trust-boundary control*, not just a parallelism mechanism);
- **accumulated org memory** (learnings, BFG, per-builder memory/karma).

Modularity itself is **not** a moat — it is commodity hygiene (VS Code, Backstage, Fastify all do it). The **trust + governance substrate is the hard-to-copy asset.** When pitching the self-hostable Cloud Bongos product, lead with *"the audit trail, rank governance, and org memory are yours and hard to leave"* — not the AI features, which any competitor can match.

### 3. Harden the trust boundary against Cursor's CVE classes — during the reorg

Cursor's 2025 RCE record is the canonical failure mode of putting enforcement on a client the agent controls — CurXecute (CVE-2025-54135, RCE via the agent *creating* `.cursor/mcp.json` because creation wasn't gated like editing), MCPoison (CVE-2025-54136, swapping an already-approved command), a case-sensitivity bypass (CVE-2025-59944), a `.cursorignore` bypass (CVE-2025-64110), and the invisible-Unicode "Rules File Backdoor." Our architecture is designed against this (the DB is king; CLAUDE.md is descriptive-only), but the specific bypasses are subtle. Pre-empt the equivalents:

- **Gate file *creation* as strictly as edits** on the permission core, `migrations/`, `infra/`, `.github/workflows/`, `settings.json`, and hook files (a not-yet-existing protected file must not be a creation loophole).
- **Path matching must be case-insensitive AND Unicode-normalized** so a `settings.JSON` or a homoglyph can't slip past the protected-path glob.
- **A fitness check** asserting no agent-authored diff touches a permission-core file without a recorded Gate approval (extends the post-push main-audit, ADR 0043).

Bake these into the **loader + `fitness.js`** while ADR 0083 Phase 0–1 is already touching them — cheapest possible moment, and it defends the one real moat.

## Alternatives considered

- **Out-tool Cursor (chase editing/model/scale parity).** Rejected — we lose on every one of those axes and it spends scarce effort where the headstart is largest.
- **Keep module-scoping as the AI-quality mechanism.** Rejected on Cursor's A/B evidence; retained as a *boundary* only, with retrieval layered on top.
- **Defer CVE-hardening to a later security pass.** Rejected — it is cheapest to fold into the reorg that is already rewiring the loader/fitness, and it protects the differentiator.

## Consequences

- ADR 0083's build plan proceeds unchanged; only the **framing** of module-scoping in the design docs is amended (boundary, not quality lever).
- **Follow-on work (cheap-first), to be filed as tasks under BONGOS-V1:** (a) agentic retrieval within the module default (grep + `/recall` + repo-map chaining); (b) the three trust-boundary hardenings above; (c) a four-way rule-attachment taxonomy (always / glob / agent-requested / manual) on nested module docs, kept as plain markdown (Cursor found *structured* nested rules silently break). Further candidates: a tiered autonomy dial (allowlist + sandbox + cheap-Haiku intent classifier), a pre-push grader review + best-of-N, and worktree-as-shadow-workspace in-turn validation.
- **Strategic messaging** for the self-host/standalone product pivots to governance / audit / org-memory.
- All competitor numbers are dated **2026-06-24**; Cursor ships weekly — treat ARR/valuation/release facts as perishable and re-verify before reuse.

## Provenance

17-agent workflow · 7 research angles (indexing/retrieval, agent capabilities, the teams/collaboration push, rules & context-scoping, security/trust, business & moat, engineering-blog lessons) · ~250 web fetches · riskiest claims adversarially re-verified against primary sources (cursor.com docs/blog, Turbopuffer, Bloomberg/CNBC/TechCrunch, GHSA advisories). The full dimension-by-dimension scorecard and the ranked "what to learn from Cursor" list live in the session log for this task.
