# Governance

How Cloud Bongos is governed, and the commitments that keep it a commons.

Cloud Bongos is an **AI-first build platform**: a human owner sets scope and the hard gates; AI agents claim tasks and write the code. This document describes how the project is run and the promises that protect it from capture. The binding decision behind it is [ADR 0065](docs/adr/<redacted>.md).

## Principles

1. **Open, free, and protected from capture.** Cloud Bongos is released as open source under the **GNU AGPL-3.0** ([`LICENSE`](LICENSE)). The AGPL's §13 (Remote Network Interaction) closes the hosted-closed-fork loophole: anyone who runs a modified Cloud Bongos as a network service must offer that service's complete source to its users. This is the anti-monopoly guarantee — the platform stays a commons even when it is *operated*, not just when it is shipped.

2. **Non-profit.** The project is **not monetized from its contributors**. No one pays to contribute, and no contribution is resold by the project as a proprietary add-on. The in-platform credit/drachmae economy is an **instance-internal** mechanism (an instance rewards its own builders from its own budget) — it is not the project monetizing the commons.

3. **AI-first.** The expectation is that **AI agents write the code**. This is a documented norm, not a technical gate (see [CONTRIBUTING.md](CONTRIBUTING.md)). The whole methodology — the task lifecycle, the quality grader, the session economy — is designed around agents as the primary authors.

4. **No capture path.** There is **no contributor license agreement (CLA)** assigning rights to a central entity, because a CLA is the standard mechanism for later relicensing — exactly the capture move the AGPL + non-profit posture are designed to prevent. Contributions are **inbound = outbound**: you contribute under the same AGPL-3.0 the project carries.

## Who decides what

Authority is **server-enforced**, not document-granted. A builder editing local files (including this one) gains no authority; the platform re-checks rank on the live database, per request, with no caching ([ADR 0016](docs/adr/<redacted>.md)). The rank ladder (kept as the platform's canonical permission model; full detail in [`docs/canonical-permissions.md`](docs/canonical-permissions.md)):

| Rank | Role |
|---|---|
| **Xenos** | Newcomer — can claim starter tasks; kept out of the permission/methodology core. |
| **Thetes** | Contributor — broader task access. |
| **Metic** | Trusted — may touch the build pipeline and gate-surfaces. |
| **Archon** | Owner — sets scope, approves members, controls deploy and the hard gates. |

The **owner (Archon)** of an instance holds final authority over that instance: scope, member admission, rank changes, and deploy. This is per-instance — Cloud Bongos is **one project per install**; there is no central control plane that can override an instance's owner.

## How work happens

All work flows through the task lifecycle (the methodology core, described in [`CLAUDE.md`](CLAUDE.md) and [CONTRIBUTING.md](CONTRIBUTING.md)):

> **claim → build → ship** — every change is backed by a claimed task; shipping runs the smoke + quality gates, awards credits, and lands the change.

Non-obvious decisions are recorded as **ADRs** ([`docs/adr/`](docs/adr/)). Significant scope is set in **planning sessions** that define a version's done-when criteria. The database — not any markdown file — is the source of truth for live state.

## Releasing to the public

The public mirror is **generated** from the private instance-1 repository on a deliberate, **~6-month-delayed** cadence, carrying only the publishable subset (the portable core + platform — never a host's identity, secrets, content, or in-window development). The boundary and the delay are defined in [ADR 0065](docs/adr/<redacted>.md) §4 and implemented by the C9 export pipeline (R71/R72), with a lineage/no-leak proof (R73).

## Changing this document

This document and the commitments in it change the way any other governed decision does: a claimed task, an ADR recording the rationale, and the owner's approval. The license and non-profit posture are foundational — changing them would require a new ADR that explicitly supersedes [ADR 0065](docs/adr/<redacted>.md), and they exist precisely to be hard to quietly undo.
