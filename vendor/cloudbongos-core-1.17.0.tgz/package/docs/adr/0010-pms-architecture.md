# 0010 — Project management system: schema-first, same-process, GitHub-auth, two surfaces

- **Status:** Accepted
- **Date:** 2026-05-09
- **Deciders:** Lars
- **Addendum (V3.R01, 2026-05-13):** "PMS" was renamed to "GDS" (Game Development System) when V3 opened the system to multiple builders. Folder/route/env-var renames: `src/pms/` → `src/bongos/`, `scripts/pms/` → `scripts/gds/`, `/api/pms/*` → `/api/gds/*`, `PMS_GITHUB_*` → `GDS_GITHUB_*`, `PMS_API_BASE` → `GDS_API_BASE`, `pms_session` cookie → `gds_session`, `~/.config/otb/pms-session.json` → `~/.config/otb/gds-session.json`. The version ID `PMS-V3` was also renamed to `GDS-V3` (migration `<redacted>.sql` rewrites `versions`, `tasks`, `done_when_criteria`, `idea_inbox`, plus the `pms-shipper` achievement → `gds-shipper`). Future internal-track versions ship as `GDS-V4`, `GDS-V5`, etc. The version IDs `PMS-V1` and `PMS-V2` are NOT renamed — those versions shipped under those names and their archives in `limitations/pms-v*-shipped.md` are immutable historical records.

  V3.R01 also introduced a transitional `/api/pms/* → /api/gds/*` redirect surface (301 for GET/HEAD, 308 for POST/PATCH/DELETE) so old skill files and cached browser clients would keep working through the rollout. **V3.R01-followup ([#308](https://example.com/builders#/task/308), 2026-05-13) removed that redirect surface** after a repo audit confirmed no caller still hits the legacy path; `/api/pms/*` is now a 404. The read-side back-compat for the `pms_session` cookie, `PMS_GITHUB_*` env vars, and the `~/.config/otb/pms-session.json` file path **continues** (in `src/bongos/auth.js` and `scripts/gds/cli-lib.js`) — those are independent of the URL surface and protect existing local sessions.

  The body of this ADR is preserved unchanged as the original 2026-05-09 decision record.

## Context

The project is structured to be built across many parallel Claude Code sessions, sometimes overnight, sometimes by future human collaborators. To make that work without git merge conflicts and without re-deriving "what's left" every session, we need a real project management system — not a markdown work-board.

Lars wants two surfaces:

1. **`/builders`** — private, gamified workspace for prompt engineers. Lists claimable tasks with explicit parallel-safety, awards in-game credits (1 USD = 1 credit, cash-equivalent), shows leaderboard.
2. **`status.example.com`** — public dashboard for team, investors, and customers. Cost-vs-value charts, version progress, completed-work feed.

Both surfaces share one task/cost/credit ledger.

The system also needs to run inside Claude Code itself — slash commands so a session can claim, ship, and release tasks without leaving the terminal.

## Decision

Build the GDS as a parallel internal track ("PMS-V1") on top of the existing single-droplet stack, with a Postgres-first schema, same-process API and web UI, GitHub OAuth for builder identity, and atomic claim safety enforced at the database layer.

**Key choices:**

1. **Database in existing Postgres 16, new migration `003_pms.sql`.** No new database server. New tables (`builders`, `versions`, `tasks`, `claims`, `cost_log`, `credit_log`, `builder_sessions`, `session_logs`) live alongside `world_events` / `players` in the `example` DB. Same backup story (when backups land), same auth (peer Unix socket).

2. **API in the existing Node/Express process.** New module tree under `src/pms/` mounted at `/api/pms/*`. No new deploy unit, no new systemd service, no new port. Restart cost: same ~2 seconds as a game-server change.

3. **GitHub OAuth for builder identity, two flows:**
   - **CLI** (Claude Code slash commands): GitHub **Device Flow**. No callback URL, no local HTTP server, friendly in a terminal. The CLI gets a verification code, the user pastes it into github.com/login/device, the CLI polls until approved, receives a GitHub access token, and exchanges it with our API for a long-lived session token stored at `~/.config/otb/pms-session.json`.
   - **Web** (`/builders`): standard GitHub OAuth Authorization Code flow with callback to `https://example.com/builders/auth/github/callback`. Sets a session cookie scoped to `/builders`.
   - Both flows produce the same `builder_sessions` row keyed by GitHub user ID. A builder using both surfaces is one builder.

4. **Atomic claim safety at the DB layer.** A partial unique index on `claims (task_id) WHERE released_at IS NULL` makes it physically impossible for two sessions to hold an active claim on the same task. The race goes to whichever transaction commits first; the loser gets a clean constraint violation and picks another task. No application-layer locking, no Redis.

5. **Parallel-safety via `tasks.touches[]` (text array of file/folder paths).** The `claimable_tasks_for_builder()` function returns only tasks whose `touches` array does not overlap with any currently-active claim's task. The builder never has to compute this themselves — the API tells them what is safe to claim *right now*.

6. **Two web surfaces, one process.** `/builders` lives on `example.com`. `status.example.com` is a new Caddy site block on the same droplet, same Node process. Cloudflare DNS gets a new `status` record. The status site is server-rendered HTML + Chart.js, public, no auth, edge-cached.

7. **Server-rendered HTML + small JS for live polling.** Both surfaces. No SPA framework. Polling interval 5 seconds for active claims; status site polls only on user action. This matches the project's existing static-page style and keeps the asset bundle tiny.

8. **Cash-equivalent credits, but redemption is gated.** Phase 1 ships the credit ledger and leaderboard only. No "redeem" button, no transfer mechanism, no payout flow. Before any redemption ships (anywhere from Phase 3 onward), Lars consults a CPA on tax handling and a lawyer on securities/AML posture. The DB is designed to support either path (transfer-only-into-game-currency or cash-equivalent) — the legal posture decides which gets wired up.

9. **Strategic markdown stays.** `current-version.md`, ADRs, learnings, and blockers remain markdown — they are documents, not work units. **Backlog/work tracking moves into the DB.** `limitations/backlog.md` becomes a frozen snapshot for archival once the import script runs; future backlog edits happen via API. `generative-ideas.md` stays as the no-shape capture inbox.

## Alternatives considered

- **Linear or GitHub Issues for internal tracking + a custom public status page.** Cheaper to operate (no schema to maintain). Rejected because the gamification (credits, leaderboard, themed builder profile) and the CLI integration (claim from inside Claude Code) are core to Lars's vision and would be awkward bolted onto Linear's webhooks.
- **Separate microservice for the GDS.** Cleaner boundary, but adds deploy complexity, doubles the systemd unit count, and adds latency between the game server and the GDS API. Rejected — the V1 budget posture says "one process until we have to split."
- **Application-level locking for claims (Redis or in-process).** Works, but adds a coordination layer that the existing single-Node-process architecture doesn't need. Rejected in favor of Postgres unique-constraint enforcement.
- **JWT session tokens.** Slightly more "stateless" than DB-stored tokens, but adds a crypto dependency, key-rotation problem, and doesn't enable revocation. Rejected — random tokens in `builder_sessions` are simpler and revocable.
- **No public status site at all (gamified internal only).** Rejected — Lars wants progress shareable with the team chat, supporters, and eventually players. The cost of `status.example.com` is one more Caddy site block + a few public-read endpoints.
- **Defer cash-equivalent semantics until later.** Considered making Phase 1 store credits as opaque "points" with the cash equivalence decided later. Rejected — the schema cost is identical and "we'll decide later" tends to never decide. The decision is *cash-equivalent stored, redemption legally gated*.

## Consequences

- **Sessions can run in parallel safely.** Two sessions in two worktrees, each holding a claim with disjoint `touches[]`, will not stomp each other. The DB enforces it.
- **One Lars-task to unblock Phase 2 web UI:** register the GitHub OAuth App and hand over Client ID + Secret. Tracked as a blocker.
- **The system can self-bootstrap.** Once Phase 1 ships, all further GDS work is itself tracked in the GDS. The PMS-V1 track lives in `versions` as an entry alongside the game V1 track — internal track and product track run as siblings, sharing the same builder credit pool.
- **Cost-vs-value charts depend on disciplined cost logging.** The `cost_log` table accepts entries from any source — the `art/iterations/cost_ledger.jsonl` import is one source; Anthropic API spend is another (manual until we have a real billing pipeline); droplet/Cloudflare/domain spend is a third. Phase 5 backfills.
- **Legal/tax exposure exists the moment a non-Lars builder earns credits.** Mitigated by gating redemption — credits exist in the DB but cannot be exchanged for anything until the gate is cleared. Until that gate clears, credits are functionally a leaderboard score.
- **Trademark posture extends into the GDS.** "Example" appears in URLs (`status.example.com`, `/builders`) and in builder profiles. Same operating rule as [ADR 0004](0004-example-name-and-trademark-acceptance.md): the civilization name is one config string. URLs are a separate decision; if the name has to change, the subdomain DNS record gets repointed and any in-DB strings that reference the name get re-templated.
- **The methodology gets simpler from a session's perspective.** Today: read CLAUDE.md, read backlog, read blockers, cross-reference current-version, decide what to do. After Phase 1: `/builder-start` returns the answer.
- **Session logs split.** Today the session log lives as prose in CLAUDE.md §13. Going forward, structured per-task session entries land in `session_logs` (queryable, charts-friendly), and CLAUDE.md §13 becomes a generated tail of the most recent few. Older prose continues to compress into `docs/session-log-archive.md`.
