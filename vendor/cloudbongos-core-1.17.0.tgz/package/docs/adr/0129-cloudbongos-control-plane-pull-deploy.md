# ADR 0129 — cloudbongos.com control-plane box deploys by a pull timer, not the CI push

**Status:** Accepted — implemented 2026-07-05 (task [#2064](https://example.com/builders#/task/2064)). Follows [ADR 0126](<redacted>.md).

## Context

The 2026-07-05 dedicated-droplet migration ([ADR 0126](<redacted>.md), task [#2063](https://example.com/builders#/task/2063)) moved cloudbongos.com onto its own box (`REDACTED_IP`, checkout `<redacted>`, `cloudbongos.service`, port 3002). The co-hosting box (`REDACTED_IP`) still auto-deploys **example.com** via [`.github/workflows/deploy-prod.yml`](../../.github/workflows/deploy-prod.yml) (SSH → `~/deploy.sh` on merge to `main`, [ADR 0042](<redacted>.md)). That path only touches the co-hosting box. **Nothing pulled `main` onto the new box**, so cloudbongos.com served its boot-time code and drifted — ADR 0126 §Consequences flagged this as task 2064.

The task allowed either extending the CI push workflow to also target the new box, **or** a pull-based timer on the box.

## Decision

Deploy the control-plane box with a **pull-based systemd timer**, not by extending the CI push.

- [`scripts/deploy/deploy-cloudbongos.sh`](../../scripts/deploy/deploy-cloudbongos.sh) — the deploy: `git fetch` + reset to `origin/main` → `npm ci --omit=dev` (only if `package-lock.json` changed) → `PGDATABASE=cloudbongos MEDUSA_GDS_ONLY=1 ./scripts/migrate.sh` → `sudo systemctl restart cloudbongos` → poll `127.0.0.1:3002/healthz`, then rebuild the gitignored Hall nav surfaces. Idempotent, with a fast no-op exit when `HEAD == origin/main`.
- [`infra/cloudbongos-deploy.service`](../../infra/cloudbongos-deploy.service) + [`infra/cloudbongos-deploy.timer`](../../infra/cloudbongos-deploy.timer) — a `oneshot` service fired every ~2 min (measured from the end of the last run).

### Why pull, not CI push

1. **Blast radius.** The dedicated box exists to shrink the cloud-token / prod-SSH-key exposure (ADR 0126). Extending CI would require storing **this box's** prod SSH key as a GitHub Actions secret — more secret sprawl, against the migration's whole grain. A pull uses the box's **existing** GitHub deploy key (`git@github-deploy:…`), so no new secret leaves the box and the shared `deploy-prod.yml` is untouched.
2. **Convention.** It matches the self-healing `*-runner.timer` units already in `infra/` (e.g. `provision-intent-runner.timer`), and the deploy self-installs its own unit changes on the next run (the [ADR 0110](<redacted>.md) self-heal pattern) — no manual re-install.
3. **Cost of staleness is low.** Worst case is one tick (~2 min) behind `main` for a Customer-0 dogfood instance. The idle-tick cost is a single `git fetch` + SHA compare (the no-op fast path).

### Two deliberate divergences from `deploy-prod.sh`

- **The executed script is a stable copy at `/home/lars/deploy.sh`, not the in-checkout file.** This script `git reset --hard`s its own checkout; a running bash script whose backing file is rewritten mid-run can read garbage. Keeping the executed copy outside the checkout makes the reset harmless — the same reason the co-hosting box hand-installs `deploy-prod.sh`. The copy is refreshed from the checkout at the end of each successful run, so improving the repo script propagates on the next deploy.
- **The SEC [#863](https://example.com/builders#/task/863) main-audit gate is non-fatal here.** On the co-hosting box it is a hard blocker resolving ranks from the *owning* OTB DB. Here `PGDATABASE=cloudbongos`, so it resolves ranks from the cloudbongos builder set (OTB authors are unknown to it) — it can only ever misfire, and the authoritative preventive gate already runs on the co-hosting box + CI against this **same** shared `main` before it advances. So it runs for the signal but never blocks; a spurious abort must not strand cloudbongos.com on stale code — the very failure 2064 fixes.

## Consequences

- cloudbongos.com now tracks `main` within ~2 min of a merge, with no new GitHub secret and no change to the shared prod deploy.
- **One-time bootstrap is unavoidable** (the box can't install its own first deploy automation): an operator installs `/home/lars/deploy.sh` + the two units over SSH once — see [`docs/recipes/cloudbongos-standup.md`](../recipes/cloudbongos-standup.md) §"Deploy automation". After that it self-heals.
- When cloudbongos.com moves to the pinned-`@cloudbongos/core` standalone model ([ADR 0108](<redacted>.md)), this script is the seam that converts `git reset --hard` → `git pull` + `npm ci` (the [`deploy-instance.sh`](../../scripts/deploy/deploy-instance.sh) shape) — a one-file change, not a new pipeline.
- Does not affect task [#2065](https://example.com/builders#/task/2065) (stripping cloud tokens off the co-hosting box); that is orthogonal.
