'use strict';

// The `reward` kernel PORT provider surface (BV1.R77 / ADR 0093 §1-2).
//
// economy registers ONE port — `reward` — that the lifecycle + the core read
// routes resolve. It is a TRANSACTION-PARTICIPANT port for the credit-allocation
// half: the caller (db.applyGrade / confirmTask / upsertSessionRecordWithReward,
// inside its own withTx) passes its tx `client` as the first arg, so the credit
// write commits atomically with the state-machine SQL that stays in the core
// lifecycle (ADR 0093 §2 — extract the capability, keep the state machine). The
// gamification + read half is stateless.
//
// We DELEGATE (do NOT spread) every method so a test that stubs a method on the
// live `achievements`/`credits` object (e.g. tests/grade_attribution.mjs sets
// achievements.evaluateAfterShip = async () => []) still bites at call time —
// a spread would capture the original reference at module-load and ignore the stub.

const credits = require('./credits');
const achievements = require('./achievements');
const cost = require('./cost');
const streak = require('./streak');

module.exports = {
  // credit allocation — transaction-participant: caller passes its tx `client`
  insertMultipliedConfirmCredit: (...a) => credits.insertMultipliedConfirmCredit(...a),
  maybeAwardIdeaPromotionBonus: (...a) => credits.maybeAwardIdeaPromotionBonus(...a),
  awardNetNegativeBonus: (...a) => credits.awardNetNegativeBonus(...a),
  awardSessionTokenReward: (...a) => credits.awardSessionTokenReward(...a),
  // gamification hooks the lifecycle fires at claim/ship
  evaluateAfterClaim: (...a) => achievements.evaluateAfterClaim(...a),
  evaluateAfterShip: (...a) => achievements.evaluateAfterShip(...a),
  evaluateAfterCreditAward: (...a) => achievements.evaluateAfterCreditAward(...a),
  // task 1679: state-based, idempotent reconcile — the durable replacement that
  // fires on EVERY ship path (incl. confirmTask / grader_bypass, which never
  // evaluated achievements before, so most builders only ever got first-claim).
  reconcileBuilderAchievements: (...a) => achievements.reconcileBuilderAchievements(...a),
  // pure helpers + constants (display / tests)
  applyKindMultiplier: (...a) => credits.applyKindMultiplier(...a),
  computeSessionTokenReward: (...a) => credits.computeSessionTokenReward(...a),
  get KIND_MULTIPLIERS() { return credits.KIND_MULTIPLIERS; },
  get IDEA_BONUS_FRACTION() { return credits.IDEA_BONUS_FRACTION; },
  get REWARD_MARGIN_PCT() { return credits.REWARD_MARGIN_PCT; },

  // --- READ surface the core me/public/builders/sessions routes resolve through
  //     this same port (one economy port; the grading precedent registers the
  //     whole module surface on its single port too).
  costSummary: (...a) => cost.costSummary(...a),
  costCalibrationSummary: (...a) => cost.costCalibrationSummary(...a),
  getBuilderCostStatus: (...a) => cost.getBuilderCostStatus(...a),
  setBuilderMonthlyBudget: (...a) => cost.setBuilderMonthlyBudget(...a),
  reconcileSessionCosts: (...a) => cost.reconcileSessionCosts(...a),
  autonomousApiSpendMtd: (...a) => cost.autonomousApiSpendMtd(...a),
  leaderboard: (...a) => credits.leaderboard(...a),
  getLeaderboardWithAchievements: (...a) => achievements.getLeaderboardWithAchievements(...a),
  listAchievements: (...a) => achievements.listAchievements(...a),
  getBuilderAchievements: (...a) => achievements.getBuilderAchievements(...a),
  getLockedAchievementsProgress: (...a) => achievements.getLockedAchievementsProgress(...a),
  sumCreditsForTasks: (...a) => credits.sumCreditsForTasks(...a),
  computeStreak: (...a) => streak.computeStreak(...a),
  wouldExtendStreak: (...a) => streak.wouldExtendStreak(...a),
};
