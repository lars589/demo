const express = require('express');
// Carved into modules/economy/ (BV1.R77 / ADR 0093 §1-2): the leaderboard query
// is an intra-module require — a module never requires a core internal. The
// pagination helpers reach through the published doorway.
const api = require('../../../src/module-api');
const credits = require('../credits');

module.exports = function buildLeaderboardRouter() {
  const router = express.Router();

  // rank: public — leaderboard mirrors the public /public/leaderboard surface;
  // preserved unauthenticated to match current production behavior.
  router.get('/leaderboard', async (req, res) => {
    // task 1750: top 100 — the hall Leaderboard view pages through these, and the
    // "#N on the leaderboard" standing stat needs ranks beyond the top 20.
    // R14 (#2001 / ADR 0119): honor ?limit=&offset= via the shared helper; the
    // default 100 preserves the prior ceiling. The list is small + SQL-LIMIT'd, so
    // fetch offset+limit and slice; `page` is additive (readers of .leaderboard
    // are unchanged).
    const { limit, offset } = api.parsePagination(req, { defaultLimit: 100, maxLimit: 200 });
    const rows = await credits.leaderboard(offset + limit);
    res.json({ leaderboard: rows.slice(offset, offset + limit), page: api.pageMeta(limit, offset) });
  });

  return router;
};
