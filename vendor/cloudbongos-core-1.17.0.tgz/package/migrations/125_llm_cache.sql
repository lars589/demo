-- 125_llm_cache.sql — content-addressed LLM result cache (GDS-V4 task 1358,
-- System 5: Content-Addressed LLM Cache).
--
-- Memoizes idempotent model runs at the shared spawn primitive
-- (grader.runSubagent). An identical (normalized-prompt-hash, model, task_type,
-- git-tree-sha) invocation — e.g. a nightly architect-audit / audit-cron over an
-- UNCHANGED main, or an onboarding-analyze re-run on the same immutable session —
-- returns the stored result with ZERO new tokens. Validity is bound to the git
-- SHA of the embedded inputs (scope_sha), so a stale answer is only ever returned
-- when the inputs are provably unchanged (ADR — task 1360). Cannot touch the
-- interactive marathon (that path does not call runSubagent); this is the
-- residual safety net behind Systems 3 + 4.
--
-- Mirrors the content-addressed convention of migrations/103_search_chunks.sql:
-- one table in the EXISTING GDS Postgres, no new service, no new monthly cost.
--
--   cache_key        — sha256(normalized_prompt | model | task_type | scope_sha);
--                      the PRIMARY KEY (the content address). The store path
--                      upserts ON CONFLICT (cache_key).
--   prompt_hash      — sha256 of the normalized prompt alone (debug / collisions).
--   model            — the model the cached result was produced on (part of the key).
--   task_type        — which normalizer produced the key (architect-audit, …).
--   scope_sha        — git tree-hash of the embedded inputs; the invalidation key.
--   result_stdout    — the cached subagent stdout (the thing we replay on a hit).
--   result_cost_usd  — what the ORIGINAL run cost (priced); a hit replays it at $0
--                      and counts result_cost_usd toward tokens_saved/savings.
--   hit_count        — number of $0 replays served (bumped on each hit).
--   tokens_saved_est — cumulative estimated tokens NOT re-billed across hits.
--   owner_builder_id — nullable; non-null only for a per-builder-private cached run.
--   created_at / last_hit_at / expires_at — lifecycle; expires_at indexed for a
--                      cheap TTL sweep (a future reaper; null = no expiry).
--
-- Additive, new table + index, idempotent: safe to re-run.

CREATE TABLE IF NOT EXISTS llm_cache (
  cache_key        text PRIMARY KEY,
  prompt_hash      text NOT NULL,
  model            text,
  task_type        text,
  scope_sha        text,
  result_stdout    text NOT NULL,
  result_cost_usd  numeric NOT NULL DEFAULT 0,
  hit_count        integer NOT NULL DEFAULT 0,
  tokens_saved_est bigint  NOT NULL DEFAULT 0,
  owner_builder_id integer,
  created_at       timestamptz NOT NULL DEFAULT now(),
  last_hit_at      timestamptz,
  expires_at       timestamptz
);

CREATE INDEX IF NOT EXISTS idx_llm_cache_expires ON llm_cache (expires_at);

INSERT INTO schema_migrations (version) VALUES ('125_llm_cache')
  ON CONFLICT (version) DO NOTHING;
