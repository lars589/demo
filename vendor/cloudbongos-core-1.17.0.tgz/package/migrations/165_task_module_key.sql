-- BV1.R53 — task→module affinity (task 1422).
--
-- A task can be labelled with a module key to declare which module it belongs to.
-- This drives: (1) module-disjointness parallel-safety at claim time (two tasks
-- in the SAME module → conflict; different modules → always safe); (2) claim-time
-- context scoped to that module's directory tree; (3) ship-time diff⊆module
-- drift detection ("you said game, you touched dev-box"); (4) soft deprecation of
-- touches[] for module-bound tasks (module globs supersede predicted file paths).
--
-- No FK or CHECK against a modules registry — module keys are validated in
-- application code against MODULE_SCOPE_MAP, which is the live source of truth.
-- The column is nullable: tasks without a module_key fall back to the existing
-- touches[]-based parallel-safety and context behaviour.

ALTER TABLE tasks ADD COLUMN IF NOT EXISTS module_key text;
