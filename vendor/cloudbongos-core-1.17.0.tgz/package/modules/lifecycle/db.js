// modules/lifecycle/db.js — the LIFECYCLE state-machine data layer (BV1.R86 / ADR
// 0093 §1,§3). The build state machine carved out of the ~6k-LOC src/bongos/db.js
// monolith: versions · goals · tasks · dependencies · criteria · claims · the
// claim→ship→grade→credit lifecycle · overrides · estimation/work analytics ·
// the merge lease · the peer-vote→karma fold-in. This is the "db.js residue" ADR
// 0093 §3 predicted — everything that WASN'T kernel-identity/auth/twin stayed here
// and now lives in the module.
//
// THE BOUNDARY (the one rule): this file reaches core ONLY through the published
// doorway ../../src/module-api.js — the shared pool, withTx, the kernel identity/
// audit/rank helpers, the seam registry (it RESOLVES the `reward` + `onboarding`
// ports as a CONSUMER, exactly like sessions/onboarding resolve `reward`), the
// pure path-match + permission-path matchers, and the offered-disciplines
// resolver. It NEVER requires a core internal or a sibling module directly.
//
// TRANSACTION-PARTICIPANT seams (ADR 0093 §2): claimTask / confirmTask /
// decideOverrideRequest / applyGrade open their own withTx, run the state-machine
// SQL, and call seams.resolveOptional('reward')|('onboarding').*(client, …) inside
// that same tx so the credit/achievement/onboarding writes commit atomically with
// the status flip. The lifecycle keeps the machine; the capability is the port.
//
// Two helpers are DELIBERATELY DUPLICATED with core src/bongos/db.js (ADR 0091 §2,
// "boundary-forced duplication is allowed + documented"): sealSessionLog (core's
// deactivateBuilder writes the same session_logs close row) and _applyRankChangeTx
// + its RANKS / singleRungPromotionError deps (core's Archon-driven setBuilderRank
// runs the same in-tx rank change; here it backs the automatic xenos→thetes
// graduation on ship). Same SQL on both sides; keep them in sync.

'use strict';

const api = require('../../src/module-api');
const { pool, withTx, insertAuditLog, LIVE_RANK_LADDER } = api;
// The seam registry (resolveOptional/emit/emitAsync) — the doorway re-exports it,
// so the module reaches the `reward`/`onboarding` ports + emits kernel events
// (task.shipped, builder.box-reconcile-needed) without importing core.
const seams = api;
// Pure kernel-adjacent matchers via the doorway (never the core file).
const { matchProtected } = api.permissionPathCheck;
const { touchesOverlap } = api.pathMatch;


// ---------------------------------------------------------------------------
// Shared SQL fragments + small pure helpers (task 1087, C3 — dedup audit
// 2026-06-14 §2A/§2B db-tx/db-deep). Each is behavior-neutral: the SQL helpers
// produce strings byte-identical to the inlined copies they replace (modulo
// whitespace, which SQL ignores), and the query helpers run the identical query
// with the identical bound params. Per-site DRIFT that a naive merge would
// break is preserved at the call site (documented per helper).
// ---------------------------------------------------------------------------

// median of a numeric array (sorts a COPY; the caller's array is left intact).
function median(arr) {
  const s = [...arr].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 === 0 ? (s[mid - 1] + s[mid]) / 2 : s[mid];
}

// Smoke tasks (`__smoke__*`) are excluded from every public/analytics feed.
// Unqualified `title` is safe to drop into a `tasks t LEFT JOIN builders b`
// query too, since `builders` has no `title` column (audit §2B db-deep).

const SMOKE_NOT_LIKE = `title NOT LIKE '\\_\\_smoke\\_\\_%' ESCAPE '\\'`;

// stale-claim predicate over (claims c LEFT JOIN session_pulses sp): a claim is
// stale when its last pulse — or, with no pulse, its claim time — is older than
// the `param` ($N) hours value. NOTE: the two pulse.js sweeper copies use
// `interval '1 minute'` (a different unit) in a separate module, so they are
// intentionally NOT shared here (audit §2B db-deep).

const staleClaimHourPredicate = (param) =>
  `(sp.last_pulse_at IS NOT NULL
                    AND sp.last_pulse_at < now() - (${param}::int * interval '1 hour'))
               OR (sp.last_pulse_at IS NULL
                    AND c.claimed_at    < now() - (${param}::int * interval '1 hour'))`;

// grade pass-count fragment: SUM of passed-as-1. `col` is the (possibly
// alias-qualified) boolean column ('passed' or 'g.passed'); pass
// { coalesce: false } for the two sites that omit the COALESCE(...,0) wrap
// (audit §2B db-tx — alias × coalesce are the two preserved drift dimensions).

const gradePassCount = (col, { coalesce = true } = {}) => {
  const inner = `SUM(CASE WHEN ${col} THEN 1 ELSE 0 END)`;
  return coalesce ? `COALESCE(${inner}, 0)::int` : `${inner}::int`;
};

// The shared `bounds`/`days` DAY_SERIES_CTE for the costSummary day-series
// queries moved with costSummary into modules/economy/cost.js (BV1.R77 / ADR
// 0093 §§1-2) — its only two callers left the monolith.

// Seal a session_logs row inside an open transaction (ended_at is NOT NULL in
// the schema, so a "sealed" log = the closing row). `outcome` stays a PARAMETER
// — resolveClaim passes a variable ('shipped'/'partial'/'abandoned'), the two
// release paths pass the literal 'abandoned' (audit §2B db-tx).

async function sealSessionLog(client, { builderId, taskId, claimId, startedAt, outcome, notesMd }) {
  await client.query(
    `INSERT INTO session_logs (builder_id, task_id, claim_id, started_at, ended_at, outcome, notes_md)
     VALUES ($1, $2, $3, $4, now(), $5, $6)`,
    [builderId, taskId, claimId, startedAt, outcome, notesMd]
  );
}

// The builder on the most-recent claim for a task (the worker who did the
// work). Returns null when the task has no claim on record at all — each caller
// supplies its OWN fallback (confirmer / requester / grade-caller) at the call
// site, so that per-site drift is preserved (audit §2B db-deep, #538/#661).

async function mostRecentClaimHolderId(client, taskId) {
  const { rows } = await client.query(
    `SELECT builder_id FROM claims WHERE task_id = $1 ORDER BY claimed_at DESC, id DESC LIMIT 1`,
    [taskId]
  );
  return rows[0]?.builder_id ?? null;
}

// -------------------------------------------------------------------------
// Builders
// -------------------------------------------------------------------------


const RANKS = [
  'olympian', 'hermes', 'oracle', 'demigod',
  'archon', 'strategos', 'boule', 'aristoi', 'hippeis', 'zeugitai',
  'metic', 'thetes', 'xenos', 'periokoi', 'doulos', 'helot',
];

// THETES auto-graduation (#692 / ADR 0034; trigger corrected in #704). A Xenos
// who has this many SUCCESSFULLY SHIPPED tasks (tasks.status='shipped',
// attributed via tasks.shipped_by) is promoted xenos→thetes the moment the Nth
// ship lands. The signal is SHIPPED, not confirmed — a task only counts once it
// is merged + deployed, per the Archon rule "after 3 tasks are successfully
// shipped." Pure decision helper is exported so tests/rank_gate.mjs can exercise
// the threshold without a DB.

const THETES_GRADUATION_THRESHOLD = 3;

function qualifiesForThetesGraduation(rank, shippedCount) {
  return rank === 'xenos' && Number(shippedCount) >= THETES_GRADUATION_THRESHOLD;
}

// GENERAL_QUEUE_RANKS — the live ranks allowed to claim any ready task (the
// whole general queue). Everything NOT in this set is sandboxed (see
// xenosClaimAllowed). Mirrors LIVE_RANK_LADDER minus the sandboxed entry rank
// 'xenos': thetes (graduated newcomer, #692 / ADR 0034) and up.

const GENERAL_QUEUE_RANKS = new Set(['thetes', 'metic', 'archon']);

// xenosClaimAllowed — the row-level half of the three-rank model (#360 / ADR
// 0018; renamed in V3.R15 #239 to newcomer_friendly). The sandboxed entry rank
// may claim a task ONLY if it's been explicitly opened (newcomer_friendly ===
// true); the live general-queue ranks claim any ready task.
//
// #510: FAIL CLOSED. The old test was `if (rank !== 'xenos') return true`, which
// failed OPEN — ANY rank that wasn't the literal string 'xenos' (a reserved rank
// like 'helot', a legacy value, or a future typo) skipped the sandbox and could
// claim any ready task. We now allowlist the live general-queue ranks instead:
// the sandbox applies to 'xenos' AND every reserved/unknown/typo rank. The
// privileged set is {thetes, metic, archon}, NOT just {metic, archon} — thetes
// is the live graduated-newcomer rank (#692 / ADR 0034) and by design claims the
// whole general queue (asserted in tests/rank_gate.mjs). This matches the
// fail-closed posture rankAllowsTask already takes for unknown ranks.
//
// The parameter is named `newcomerFriendly` (the V3.R15 canonical name).
// Pure + exported so tests/rank_gate.mjs can exercise it without a DB; claimTask
// + claimTasksBatch both call it (composed with rankAllowsTask).

function xenosClaimAllowed(rank, newcomerFriendly) {
  if (GENERAL_QUEUE_RANKS.has(rank)) return true;
  return newcomerFriendly === true;
}

// V3.R82 (#301): the INVERSE of newcomer_friendly. Some tasks raise the floor
// instead of opening the door — `requires_rank` is a per-task MINIMUM rank
// that a builder must meet to claim. Default 'xenos' means "no extra gate"
// (any builder can claim, subject to the existing xenos sandbox rule).
//
// The LIVE ranks form an ordered tier (ADR 0018; thetes added #692 / ADR 0034):
//   xenos (1) < thetes (2) < metic (3) < archon (4)
// A 'thetes' clears any requires_rank='xenos' (the default) task — i.e. the
// whole general queue — but is blocked from requires_rank='metic'/'archon'.
// Reserved ranks aren't live — if one is somehow stored on a builder row, we
// fail closed (treat as below xenos / refuse). The DB CHECK on
// tasks.requires_rank enforces the same enum so the column never holds a value
// this helper can't compare.
//
// Pure + exported so tests/rank_gate.mjs can exercise it without a DB.
// claimTask + claimTasksBatch both call it after xenosClaimAllowed; the two
// gates compose without contradiction (see migration 044 for the rationale).

const REQUIRES_RANK_TIER = { xenos: 1, thetes: 2, metic: 3, archon: 4 };

function rankAllowsTask(builderRank, requiredRank) {
  // Tasks default to requires_rank='xenos' (the NOT NULL DEFAULT on the
  // column), so a null/undefined here means "no extra gate" — treat as xenos.
  const needed = REQUIRES_RANK_TIER[requiredRank ?? 'xenos'];
  if (!needed) {
    // Bad value in the column (shouldn't happen — DB CHECK blocks it).
    // Fail closed: refuse the claim so a future rank can't be silently bypassed.
    return false;
  }
  const have = REQUIRES_RANK_TIER[builderRank];
  if (!have) {
    // Builder rank not in the live three. Fail closed.
    return false;
  }
  return have >= needed;
}

// deriveRequiredRank — task 1498 / ADR 0085. The per-task requires_rank floor
// (V3.R82 #301) shipped INERT: no create/edit path ever set it, so every task
// sat at the 'xenos' default and the claim gate never bit. We now DERIVE a floor
// from what a task touches + its sensitivity, reusing the SAME protected-path
// matcher the trust boundary uses (permission-path-check.matchProtected) — one
// source of truth for "this is sensitive" (ADR 0043). A task that touches the
// rank/authz/ship-grade/deploy/migration core, or is flagged security_sensitive,
// floors at 'metic' (the first trusted working rank — exactly the paths a
// sub-Metic builder already cannot push to). Everything else stays 'xenos' (the
// open general queue). NEVER auto-assigns 'archon': "only the Archon may claim
// this" is a deliberate manual override, not something to infer.
// Pure + exported so tests/rank_gate.mjs can exercise it without a DB.

function deriveRequiredRank(touches, securitySensitive) {
  if (securitySensitive === true) return 'metic';
  const files = Array.isArray(touches) ? touches : [];
  if (files.length > 0 && matchProtected(files).length > 0) return 'metic';
  return 'xenos';
}

// highestRank — the higher-authority of two ranks (treating null/undefined/
// unknown as the 'xenos' floor, tier 1). Composes the derived FLOOR with an
// explicit/override rank: stored requires_rank is always max(floor, requested),
// so an override can only RAISE the bar, never drop below the safety floor
// (fail-closed). Pure + exported.

function highestRank(a, b) {
  const ta = REQUIRES_RANK_TIER[a] || 1;
  const tb = REQUIRES_RANK_TIER[b] || 1;
  const winner = ta >= tb ? a : b;
  return REQUIRES_RANK_TIER[winner] ? winner : 'xenos';
}

// LIVE rank ladder, lowest→highest. The promotion ladder for the manual
// one-rung rule (#707). Indexes are 0-based; live tier = index + 1, matching
// REQUIRES_RANK_TIER.
// LIVE_RANK_LADDER moved to ./db-kernel (BV1.R69 / ADR 0091 §2: the rank ladder
// is a kernel primitive). Imported + re-exported at the top of this file; the
// 0-based indexing note above still applies to the uses just below.

// singleRungPromotionError — #707. The Archon rule: a MANUAL promotion may
// advance a builder EXACTLY one live rung at a time (xenos→thetes→metic→archon).
// Returns null when the change is allowed (a one-rung promotion, a demotion, a
// lateral move, or an off-ladder/reserved rank on either side), or a structured
// error object when a promotion skips ≥1 rung (e.g. xenos→metic, thetes→archon).
// Pure + exported so tests/rank_gate.mjs can exercise it without a DB. Only the
// manual chokepoint (setBuilderRank) enforces it; auto-graduation (always +1)
// bypasses it.

function singleRungPromotionError(oldRank, newRank) {
  const a = REQUIRES_RANK_TIER[oldRank];
  const b = REQUIRES_RANK_TIER[newRank];
  if (!a || !b) return null;     // one side is off the live ladder — not our gate
  if (b <= a) return null;       // demotion or lateral — unconstrained here
  if (b - a === 1) return null;  // exactly one rung up — allowed
  return {
    code: 'MULTI_RUNG_PROMOTION',
    from: oldRank,
    to: newRank,
    next_rung: LIVE_RANK_LADDER[a], // rank at tier a+1 (ladder is 0-based)
  };
}

// disambiguateWorktreeName — V3.R51 (#270). Two simultaneously-ACTIVE claims
// must never share a worktree_name: `.claude/worktrees/<name>` is a filesystem
// path, and two live builders pointing at the same one would stomp each other.
// This is NOT a refusal (unlike ALREADY_CLAIMED / TOUCHES_CONFLICT) — we
// silently append a numeric suffix and let the claim succeed, returning the
// disambiguated name so the caller knows what they actually got.
//
// `taken` is the set of worktree_names held by currently-ACTIVE claims only
// (released_at IS NULL). A name freed by a resolved/shipped claim is freely
// reusable WITHOUT a suffix — this is load-bearing for the overnight builder,
// which reuses ONE worktree_name across sequential tasks (it ships, freeing the
// claim, before claiming the next). Keying off historical claims would break it.
//
// Suffix scheme: "name" → "name-2" → "name-3" … (first collision becomes -2,
// matching git-worktree / file-manager conventions). A null/empty desired name
// has nothing to collide on, so it's returned unchanged. Pure + exported so
// tests can exercise it without a DB; claimTask calls it inside the txn.

function disambiguateWorktreeName(desired, taken) {
  if (desired === null || desired === undefined || desired === '') return desired;
  const takenSet = taken instanceof Set ? taken : new Set(taken || []);
  if (!takenSet.has(desired)) return desired;
  for (let suffix = 2; ; suffix++) {
    const candidate = `${desired}-${suffix}`;
    if (!takenSet.has(candidate)) return candidate;
  }
}

// setBuilderRank — the single chokepoint for rank changes (V3.R07 #232).
// Transactional: re-reads the target's current rank under FOR UPDATE, flips
// it, and writes an audit row to credit_log. The audit row's delta encodes
// direction (V3.R28 / #249 ceremony):
//   - Promotion (newIdx < oldIdx) → delta = +5 — small celebratory bonus so
//     drachmae mirrors authority. The trigger on credit_log will roll +5 into
//     builders.total_credits.
//   - Demotion (newIdx > oldIdx)  → delta = 0  — audit-only, no shaming
//     deduction. Demotions are dignified.
//   - Cross-ladder (one rank not in RANKS — should be impossible since the
//     API gates on RANKS, but the DB CHECK on builders.rank is the backstop)
//     → delta = 0, treated as audit-only.
// reason is always 'rank_change' so downstream queries (GET /me/pending-rank-
// change, audit replay) can join on it cleanly. The full old→new + actor go
// into the `description` column added by migration 031 — no parsing required.
// The legacy `reason` text format ("rank_change: <old>→<new> by builder#<actor>")
// is preserved verbatim too, so historical credit_log rows from before R28
// remain parseable by the same code path.
//
// Returns the updated builder row, or throws { code:'BUILDER_NOT_FOUND' } /
// { code:'RANK_UNCHANGED' }.
// _applyRankChangeTx — the in-transaction CORE of a rank change, shared by the
// Archon-driven setBuilderRank and the automatic xenos→thetes graduation in the
// confirm paths (#692 / ADR 0034). Runs inside the CALLER's transaction/client
// — it does NOT open or commit one. Locks the builder row, flips the rank,
// writes the credit_log audit row (+5 ceremony on promotion, 0 otherwise), and
// — on demotion — revokes live sessions so a stale token can't replay old
// authority. Returns the audit shape (incl. the builder's `status`, so the
// caller can fire the post-commit box reconcile on its OWN connection).

async function _applyRankChangeTx(client, { builderId, newRank, actorBuilderId, reasonNote = null, enforceSingleRungPromotion = false }) {
  const { rows } = await client.query(
    `SELECT id, rank, status FROM builders WHERE id = $1 FOR UPDATE`,
    [builderId]
  );
  const target = rows[0];
  if (!target) throw { code: 'BUILDER_NOT_FOUND' };
  const oldRank = target.rank;
  if (oldRank === newRank) throw { code: 'RANK_UNCHANGED', rank: oldRank };

  // #707 — manual promotions advance ONE live rung at a time. Checked here
  // (atomic, under the FOR UPDATE lock) but only when the caller opts in; the
  // automatic xenos→thetes graduation (always +1) does not.
  if (enforceSingleRungPromotion) {
    const rungErr = singleRungPromotionError(oldRank, newRank);
    if (rungErr) throw rungErr;
  }

  const { rows: updated } = await client.query(
    `UPDATE builders SET rank = $2 WHERE id = $1
     RETURNING id, github_id, github_login, display_name, avatar_url, total_credits, created_at, rank`,
    [builderId, newRank]
  );

  // V3.R28 / #249 — ceremony delta. Promotion (moving UP the ladder = lower
  // index in RANKS) earns +5; demotion is audit-only (0).
  const oldIdx = RANKS.indexOf(oldRank);
  const newIdx = RANKS.indexOf(newRank);
  const isPromotion = oldIdx !== -1 && newIdx !== -1 && newIdx < oldIdx;
  const isDemotion = oldIdx !== -1 && newIdx !== -1 && newIdx > oldIdx;
  const delta = isPromotion ? 5 : 0;
  // reason is the join key for downstream pickup; the human-readable text stays
  // in `description`. The "by builder#N" clause is load-bearing — the rank-change
  // greeting parser (getLatestRankChangeForBuilder) matches on it — so an
  // automatic promotion (#692) keeps it (actor = the builder themselves) and
  // APPENDS the "auto-graduation: …" note rather than replacing it.
  const description = reasonNote
    ? `rank_change: ${oldRank}→${newRank} by builder#${actorBuilderId} (${reasonNote})`
    : `rank_change: ${oldRank}→${newRank} by builder#${actorBuilderId}`;
  await client.query(
    `INSERT INTO credit_log (builder_id, task_id, delta, reason, description)
     VALUES ($1, NULL, $2, 'rank_change', $3)`,
    [builderId, delta, description]
  );

  // V3.R38 / #259 — DEMOTION hook for criterion C7 (rank-change-near-instant).
  // Revoke every active session in the same transaction so the demoted builder's
  // CLI tokens stop working on their next API call. Combined with requireBuilder
  // re-reading rank from the DB per request (ADR 0016), this is belt-and-braces.
  // Promotion never revokes — we don't log someone out for getting a raise.
  let demotionRevoked = 0;
  if (isDemotion) {
    const { rowCount } = await client.query(
      `UPDATE builder_sessions
          SET revoked_at = now()
        WHERE builder_id = $1 AND revoked_at IS NULL`,
      [builderId]
    );
    demotionRevoked = rowCount;
  }

  return {
    builder: updated[0],
    previous_rank: oldRank,
    status: target.status,
    sessions_revoked: demotionRevoked,
    direction: isPromotion ? 'promotion' : isDemotion ? 'demotion' : 'lateral',
    credit_delta: delta,
  };
}


async function maybeAutoGraduateToThetes(client, builderId) {
  if (builderId == null) return null;
  const { rows } = await client.query(`SELECT rank FROM builders WHERE id = $1`, [builderId]);
  const rank = rows[0]?.rank;
  if (rank !== 'xenos') return null;
  const { rows: c } = await client.query(
    `SELECT count(*)::int AS n FROM tasks
      WHERE shipped_by = $1 AND status = 'shipped'`,
    [builderId]
  );
  if (!qualifiesForThetesGraduation(rank, c[0].n)) return null;
  return _applyRankChangeTx(client, {
    builderId,
    newRank: 'thetes',
    actorBuilderId: builderId,
    reasonNote: `auto-graduation: ${c[0].n} shipped tasks (#692)`,
  });
}

// countShippedTasksForBuilder — #766. The number of successfully shipped tasks
// attributed to a builder (tasks.shipped_by, status='shipped'). Drives the
// onboarding checklist's "N of 3" ship counter (the 'ship_three' terminal
// stage) and is the same count maybeAutoGraduateToThetes gates on. Returns 0
// for a null/unknown builder.

async function countShippedTasksForBuilder(builderId) {
  if (builderId == null) return 0;
  const { rows } = await pool.query(
    `SELECT count(*)::int AS n FROM tasks WHERE shipped_by = $1 AND status = 'shipped'`,
    [builderId]
  );
  return rows[0]?.n ?? 0;
}

// getLatestRankChangeForBuilder — V3.R28 / #249.
// Returns the most recent credit_log row with reason='rank_change' for the
// given builder, parsed into a shape the SessionStart hook + /me/pending-
// rank-change route can consume directly. Returns null when the builder has
// never had a rank change. The parser tolerates both the post-R28 format
// (delta carries +5 / 0, description carries the legacy "a→b by #N" text)
// and the pre-R28 format (reason carries the full text, description NULL).

async function listVersions() {
  const { rows } = await pool.query(
    `SELECT id, name, track, status, scope_doc_path, started_at, shipped_at, done_when
       FROM versions
       ORDER BY started_at`
  );
  return rows;
}


async function getVersion(id) {
  const { rows } = await pool.query(
    `SELECT id, name, track, status, scope_doc_path, started_at, shipped_at, done_when
       FROM versions WHERE id = $1`,
    [id]
  );
  return rows[0] ?? null;
}


async function versionProgress() {
  // Joins the rolled-up progress view (any of completed/confirmed/shipped counts
  // as "done") with the per-state breakdown view from migration 012 so the
  // public dashboard can render a stacked three-segment progress bar.
  //
  // Also surfaces two version-level fields the Works-in-Progress surfaces need
  // (task 938): `done_when` (the senate-voice short description rendered as the
  // version's blurb on both the status mirror and the work board) and
  // `criteria_count` (how many done_when_criteria are seeded). The status mirror
  // uses criteria_count > 0 to tell a genuinely-active version from a freshly
  // stubbed "future placeholder" (e.g. a next-version row created by
  // version-close that has no criteria seeded yet) without needing a schema flag.
  const { rows } = await pool.query(
    `SELECT vp.version_id, vp.name, vp.status,
            vp.shipped_count, vp.total_count, vp.shipped_weight, vp.total_weight,
            v.done_when,
            COALESCE(dwc.criteria_count, 0) AS criteria_count,
            COALESCE(vlb.completed_count, 0) AS lifecycle_completed_count,
            COALESCE(vlb.confirmed_count, 0) AS lifecycle_confirmed_count,
            COALESCE(vlb.shipped_count,   0) AS lifecycle_shipped_count
       FROM version_progress vp
       LEFT JOIN version_lifecycle_breakdown vlb ON vlb.version_id = vp.version_id
       LEFT JOIN versions v ON v.id = vp.version_id
       LEFT JOIN (
         SELECT version_id, count(*) AS criteria_count
           FROM done_when_criteria
          GROUP BY version_id
       ) dwc ON dwc.version_id = vp.version_id
       ORDER BY vp.version_id`
  );
  return rows.map((r) => ({
    ...r,
    criteria_count: Number(r.criteria_count),
    lifecycle_completed_count: Number(r.lifecycle_completed_count),
    lifecycle_confirmed_count: Number(r.lifecycle_confirmed_count),
    lifecycle_shipped_count: Number(r.lifecycle_shipped_count),
    percent_complete:
      r.total_weight > 0 ? Math.round((Number(r.shipped_weight) / Number(r.total_weight)) * 100) : 0,
  }));
}

// Create a version + (optionally) its done-when criteria in one atomic write —
// the seed primitive `bongos init` uses so a fresh instance needs no hand-written
// seed-*.js script (task 1204 / R65). Atomic: the version and all its criteria
// commit together, so a bad criterion leaves nothing half-created. Criteria are
// idempotent on (version_id, criterion_id) so a re-run can't double-insert.

async function createVersion({ id, name, status = 'planning', scopeDocPath = null, doneWhen = null, criteria = [] }) {
  return withTx(async (client) => {
    const { rows } = await client.query(
      `INSERT INTO versions (id, name, status, scope_doc_path, done_when)
            VALUES ($1, $2, $3, $4, $5)
       RETURNING id, name, status, scope_doc_path, started_at, shipped_at, done_when`,
      [id, name, status, scopeDocPath, doneWhen]
    );
    const version = rows[0];
    const createdCriteria = [];
    let i = 0;
    for (const c of (criteria || [])) {
      const { rows: cr } = await client.query(
        `INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, sort_order)
              VALUES ($1, $2, $3, $4)
         ON CONFLICT (version_id, criterion_id) DO NOTHING
         RETURNING id, version_id, criterion_id, criterion_md, sort_order, satisfied`,
        [id, c.criterion_id, c.criterion_md, Number.isFinite(c.sort_order) ? c.sort_order : (i + 1) * 10]
      );
      if (cr[0]) createdCriteria.push(cr[0]);
      i++;
    }
    return { version, criteria: createdCriteria };
  });
}

// -------------------------------------------------------------------------
// Goals (ADR 0086 §2 / BV1.R56 — task 1510)
//
// The shared, module-scoped tier between versions and criteria. Membership
// (goal_members) is what later grants bounded task authoring within the goal's
// `scope_modules` wall (R57 adds routes/goals.js; R58 the /status rollup). These
// are the pure SQL helpers + their unit tests only — NO route references a goal
// yet, so OTB behaves identically.
//
// Each accepts the #538 deps.pool seam (honored ONLY under NODE_ENV==='test')
// so the suite can drive them with a SQL-aware fake — same posture as
// abandonTask / createOverrideRequest.
// -------------------------------------------------------------------------

// Shared column list so every goal read/return shapes a row identically.

const GOAL_COLS =
  'id, version_id, title, description, scope_modules, status, visibility, created_by, succeeded_by_goal_id, sort_order, created_at, updated_at';

// Shared column list for a goal_membership_requests row (task 1951 / ADR 0112) —
// the invite / join-request queue behind private goals. Every helper below shapes
// a row identically, the GOAL_COLS precedent.
const MEMBERSHIP_REQUEST_COLS =
  'id, goal_id, builder_id, kind, status, note, created_by, resolved_by, created_at, resolved_at, updated_at';


// The creator is the goal's OWNER (created_by — the fixed authority, task 1735)
// and lands in the member list as a 'lead' (rendered "manager" in the hall): the
// member-insert CTE rides in the same statement so goal + owner-membership land
// atomically. createdBy NULL (system-attributed, e.g. the migration-160 default
// goals) inserts no member — those goals have no owner; Archons act as one.

async function createGoal(
  { versionId, title, description = null, scopeModules = [], status = 'open', createdBy = null },
  deps = {}
) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `WITH next_order AS (
       SELECT COALESCE(MAX(sort_order) + 1, 0) AS n FROM goals WHERE version_id = $1
     ), g AS (
       INSERT INTO goals (version_id, title, description, scope_modules, status, created_by, sort_order)
            SELECT $1, $2, $3, $4, $5, $6, next_order.n FROM next_order
       RETURNING ${GOAL_COLS}
     ), first_lead AS (
       INSERT INTO goal_members (goal_id, builder_id, role)
       SELECT g.id, $6::bigint, 'lead' FROM g WHERE $6::bigint IS NOT NULL
     )
     SELECT * FROM g`,
    [versionId, title, description, scopeModules, status, createdBy]
  );
  return rows[0];
}


async function getGoal(id, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `SELECT ${GOAL_COLS} FROM goals WHERE id = $1`,
    [id]
  );
  return rows[0] ?? null;
}

// getGoalDependencies (task 1761) — the prerequisite goals THIS goal is blocked by:
// the goal->goal edges in the polymorphic `dependencies` table (migration 163),
// read as "from is blocked until to is done". Each carries its satisfied state — a
// goal dependency is satisfied when the target goal is 'achieved' (migration 163's
// done-ness for a goal). The hall (goals-page + roadmap) shows these and greys/locks
// an open goal with any unsatisfied dep. Scope is goal->goal only (a goal depending
// on a task/criterion is not a modeled pattern). deps.pool test seam.
async function getGoalDependencies(goalId, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `SELECT g.id, g.title, g.status, g.version_id,
            (g.status = 'achieved') AS satisfied
       FROM dependencies d
       JOIN goals g ON g.id = d.to_id
      WHERE d.from_kind = 'goal' AND d.from_id = $1 AND d.to_kind = 'goal'
      ORDER BY g.id`,
    [goalId]
  );
  return rows;
}

// listGoals — optional version_id / status filters (NULL = no filter), ordered
// by the owner's WITHIN-version priority (sort_order, task 1760), falling back
// to created_at/id so a fresh instance and prod agree on row order pre-reorder.

async function listGoals({ versionId = null, status = null } = {}, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `SELECT ${GOAL_COLS}
       FROM goals
      WHERE ($1::text IS NULL OR version_id = $1)
        AND ($2::text IS NULL OR status = $2)
      ORDER BY version_id, sort_order, created_at, id`,
    [versionId, status]
  );
  return rows;
}

// reorderGoals — Archon drag-to-reorder (task 1760). orderedIds is the new
// relative order for a SCOPED SUBSET of versionId's goals — the caller (hall
// UI) only ever renders a status-filtered slice (roadmap excludes archived;
// the Goals page defaults to open-only), so demanding the version's COMPLETE
// goal set here would fail-closed on every version that has ever archived a
// goal (the goal the client never rendered, and so could never round-trip).
// Every id must still belong to THIS version, appear once (fail-closed on a
// cross-version id or a duplicate — SET_MISMATCH), and be non-empty; any
// goal in the version NOT named in orderedIds (e.g. an archived one hidden
// from the view that dragged) keeps its RELATIVE order, appended after the
// reordered slice — reordering a subset never disturbs a goal the client
// didn't even see. Returns the reordered rows (the touched subset only).

async function reorderGoals({ versionId, orderedIds }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows: existing } = await activePool.query(
    `SELECT id FROM goals WHERE version_id = $1 ORDER BY sort_order, created_at, id`,
    [versionId]
  );
  const existingIds = existing.map((r) => String(r.id));
  const existingSet = new Set(existingIds);
  const wantedIds = orderedIds.map(String);
  if (wantedIds.length === 0 || new Set(wantedIds).size !== wantedIds.length || !wantedIds.every((id) => existingSet.has(id))) {
    const err = new Error('ordered_ids must be a duplicate-free list of this version\'s goal ids');
    err.code = 'SET_MISMATCH';
    throw err;
  }
  const wantedSet = new Set(wantedIds);
  const remainder = existingIds.filter((id) => !wantedSet.has(id));
  const finalOrder = [...orderedIds, ...remainder.map(Number)];
  const { rows } = await activePool.query(
    `UPDATE goals g
        SET sort_order = data.ord, updated_at = now()
       FROM (SELECT unnest($1::bigint[]) AS id, unnest($2::int[]) AS ord) AS data
      WHERE g.id = data.id
      RETURNING ${GOAL_COLS.split(', ').map((c) => `g.${c}`).join(', ')}`,
    [finalOrder, finalOrder.map((_, i) => i)]
  );
  const byId = new Map(rows.map((r) => [String(r.id), r]));
  return orderedIds.map((id) => byId.get(String(id))).filter(Boolean);
}

// setGoalStatus — the open -> achieved -> archived lifecycle move (R63/R64 wire
// the auto-achieve + archive/reopen on top). Bumps updated_at. Returns null if
// the goal id is unknown.

async function setGoalStatus({ goalId, status }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `UPDATE goals
        SET status = $2, updated_at = now()
      WHERE id = $1
      RETURNING ${GOAL_COLS}`,
    [goalId, status]
  );
  return rows[0] ?? null;
}

// achieveGoalIfComplete — the auto-achieve half of the criterion-confirm flow
// (ADR 0086 §6 / BV1.R63). Called after a criterion is confirmed (satisfied=true):
// if that criterion's goal is still `open` AND every criterion under the goal is
// now satisfied (with ≥1), flip the goal open→achieved. Conservative + idempotent —
// it never touches an achieved/archived goal (reopen/archive is the R64 lifecycle
// move), and an empty goal (no criteria) is never auto-achieved. Returns
// { achieved, goal }: `goal` is the (possibly updated) row, or null for an unknown
// id. Honours the #538 deps.pool test seam (NODE_ENV==='test' only), like its
// siblings, so the flip logic is unit-testable with a fake client.

async function achieveGoalIfComplete({ goalId }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const goal = await getGoal(goalId, deps);
  // Only an OPEN goal can auto-achieve. An already achieved/archived goal is left
  // exactly as-is — re-confirming a criterion must not churn its status.
  if (!goal || goal.status !== 'open') return { achieved: false, goal: goal ?? null };
  const { rows } = await activePool.query(
    `SELECT count(*)::int                              AS total,
            count(*) FILTER (WHERE NOT satisfied)::int AS unsatisfied
       FROM done_when_criteria
      WHERE goal_id = $1`,
    [goalId]
  );
  const total = rows[0]?.total ?? 0;
  const unsatisfied = rows[0]?.unsatisfied ?? 0;
  // Need ≥1 criterion and zero unsatisfied — confirming the LAST one is the
  // trigger. An empty goal stays open (nothing could complete it).
  if (total === 0 || unsatisfied > 0) return { achieved: false, goal };
  const updated = await setGoalStatus({ goalId, status: 'achieved' }, deps);
  return { achieved: true, goal: updated };
}

// addGoalMember — join (or change role on re-join). Upserts on the (goal_id,
// builder_id) PK so a member re-joining as lead is promoted, not a duplicate-key
// error. role defaults to 'member'.

async function addGoalMember({ goalId, builderId, role = 'member' }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `INSERT INTO goal_members (goal_id, builder_id, role)
          VALUES ($1, $2, $3)
     ON CONFLICT (goal_id, builder_id) DO UPDATE SET role = EXCLUDED.role
     RETURNING goal_id, builder_id, role, joined_at`,
    [goalId, builderId, role]
  );
  return rows[0];
}

// removeGoalMember — leave. Returns { removed } so the (later) route can 404 a
// non-member leave without a second lookup.

async function removeGoalMember({ goalId, builderId }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rowCount } = await activePool.query(
    `DELETE FROM goal_members WHERE goal_id = $1 AND builder_id = $2`,
    [goalId, builderId]
  );
  return { removed: rowCount > 0 };
}


async function listGoalMembers(goalId, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  // Builder identity rides along (task 1734: the hall Goals page renders member
  // names + lead badges) — additive columns, so every existing consumer that
  // reads only {goal_id, builder_id, role} is untouched.
  const { rows } = await activePool.query(
    `SELECT gm.goal_id, gm.builder_id, gm.role, gm.joined_at,
            b.github_login, b.display_name, b.avatar_url, b.rank
       FROM goal_members gm
       LEFT JOIN builders b ON b.id = gm.builder_id
      WHERE gm.goal_id = $1
      ORDER BY gm.joined_at, gm.builder_id`,
    [goalId]
  );
  return rows;
}

// listCriteriaForGoal — the done_when_criteria re-parented under a goal (R56
// backfilled every criterion under its version's default goal). Powers the
// "linked criteria" half of GET /goals/:id; projection matches done-when.js's
// listCriteria so the hall renders goal + version criteria identically.

async function listCriteriaForGoal(goalId, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `SELECT id, version_id, criterion_id, criterion_md, satisfied, sort_order, goal_id
       FROM done_when_criteria
      WHERE goal_id = $1
      ORDER BY sort_order, id`,
    [goalId]
  );
  return rows;
}

// isGoalMember — is this builder a member of this goal? The membership predicate
// behind the bounded-authority gates (BV1.R64 ask-to-widen; the R60 authoring
// gate reuses the same idea). Returns a plain boolean.

async function isGoalMember({ goalId, builderId }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `SELECT 1 FROM goal_members WHERE goal_id = $1 AND builder_id = $2 LIMIT 1`,
    [goalId, builderId]
  );
  return rows.length > 0;
}

// getGoalMember — one membership row incl. role, or null. The lead-authority
// read behind PATCH /goals/:id/members/:builderId (task 1735): the route needs
// the actor's and the target's role, not just the isGoalMember boolean.

async function getGoalMember({ goalId, builderId }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `SELECT goal_id, builder_id, role, joined_at
       FROM goal_members
      WHERE goal_id = $1 AND builder_id = $2`,
    [goalId, builderId]
  );
  return rows[0] ?? null;
}

// setGoalMemberRole — apply a role change with the owner guard IN the statement
// (task 1735): the goal OWNER (goals.created_by) is the fixed authority, so a
// demotion never applies to the owner's row even if two requests race past the
// route's pure gate (the attachParent "re-check atomically" posture). Returns
// the updated row, or null when nothing changed — no such member, or the guard
// blocked an owner demotion — which the route answers as a conflict.

async function setGoalMemberRole({ goalId, builderId, role }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `UPDATE goal_members gm
        SET role = $3
      WHERE gm.goal_id = $1 AND gm.builder_id = $2
        AND ($3 = 'lead'
             OR gm.builder_id IS DISTINCT FROM
                (SELECT g.created_by FROM goals g WHERE g.id = $1))
     RETURNING goal_id, builder_id, role, joined_at`,
    [goalId, builderId, role]
  );
  return rows[0] ?? null;
}

// transferGoalOwnership — reassign the goal's owner (task 1735): created_by
// moves to the new owner and the new owner's membership row is upserted to
// 'lead' (manager) in the SAME statement, so the goal can never point at an
// owner who isn't in its member list. The OLD owner keeps their lead row —
// "drops to manager" — exactly the handoff semantics the route promises. The
// route gates WHO may call this (owner | Archon, target Metic+); this helper
// just performs the move. Returns the updated goal row, or null for unknown id.

async function transferGoalOwnership({ goalId, newOwnerId }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `WITH g AS (
       UPDATE goals
          SET created_by = $2, updated_at = now()
        WHERE id = $1
       RETURNING ${GOAL_COLS}
     ), new_owner_member AS (
       INSERT INTO goal_members (goal_id, builder_id, role)
       SELECT g.id, $2, 'lead' FROM g
       ON CONFLICT (goal_id, builder_id) DO UPDATE SET role = 'lead'
     )
     SELECT * FROM g`,
    [goalId, newOwnerId]
  );
  return rows[0] ?? null;
}

// listActiveClaimsForTasks — which of these tasks hold an active claim right
// now (claims.released_at IS NULL — the claims-table convention; there is no
// status column). Feeds the conflict detector's claim-aware severity
// (goal-conflicts.js, task 1736). Holder identity rides along so the hall can
// name who to talk to.

async function listActiveClaimsForTasks(taskIds, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const ids = (taskIds || []).map(Number).filter(Number.isFinite);
  if (ids.length === 0) return [];
  const { rows } = await activePool.query(
    `SELECT c.id AS claim_id, c.task_id, c.builder_id, c.claimed_at,
            b.github_login
       FROM claims c
       LEFT JOIN builders b ON b.id = c.builder_id
      WHERE c.task_id = ANY($1::bigint[]) AND c.released_at IS NULL
      ORDER BY c.claimed_at, c.id`,
    [ids]
  );
  return rows;
}

// requestClaimRelease — the flag-for-release resolution action (task 1736): a
// goal owner/manager asks the holder of a task's ACTIVE claim to wrap up or
// release. A soft nudge, not an eviction — nothing about the claim's validity
// changes; the flag surfaces on the holder's own claim reads
// (getActiveClaimsForBuilder → /me). Idempotent: re-flagging refreshes
// requester/time/note. Returns the flagged claim row, or null when the task
// holds no active claim (the route answers 409).

async function requestClaimRelease({ taskId, requestedBy, note = null }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `UPDATE claims
        SET release_requested_by = $2,
            release_requested_at = now(),
            release_requested_note = $3
      WHERE task_id = $1 AND released_at IS NULL
     RETURNING id AS claim_id, task_id, builder_id,
               release_requested_by, release_requested_at, release_requested_note`,
    [taskId, requestedBy, note]
  );
  return rows[0] ?? null;
}

// rescopeTaskTouches — the rescope resolution action (task 1736): a goal
// owner/manager rewrites a task's DECLARED touches[] at PLANNING time, with the
// ADR 0049 advisory semantics (git merge stays the authoritative collision
// detector; this only reshapes the planning-time conflict view). This is NOT
// the mid-claim drift-expand removed in task 879 — the route refuses a task
// with an active claim, so touches are never rewritten under a working session.
//
// The ADR 0084 floor stays honest: the rank floor was auto-derived from touches
// at CREATE, so rewriting touches re-derives it and RATCHETS requires_rank UP
// in the same UPDATE if the new blast radius demands more (the
// updateTaskSecuritySensitive precedent — never lowered; an Archon can PATCH it
// down explicitly). The caller passes the task row's current facts
// (securitySensitive, currentRequiresRank) it already fetched for containment.
// Returns { id, touches, requires_rank }, or null for an unknown task.

async function rescopeTaskTouches({ taskId, touches, securitySensitive = false, currentRequiresRank = 'xenos' }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const cleaned = Array.from(new Set((touches || []).map((p) => String(p || '').trim()).filter(Boolean)));
  const floor = deriveRequiredRank(cleaned, securitySensitive === true);
  const effectiveRank = highestRank(currentRequiresRank ?? 'xenos', floor);
  const { rows } = await activePool.query(
    `UPDATE tasks SET touches = $2, requires_rank = $3, updated_at = now()
      WHERE id = $1
     RETURNING id, touches, requires_rank`,
    [taskId, cleaned, effectiveRank]
  );
  return rows[0] ?? null;
}

// addGoalScopeModules — the "ask to widen" mutation (ADR 0086 §4 / BV1.R64). Adds
// module key(s) to a goal's scope_modules, set-union + deduped (existing keys and
// repeats collapse), so widening is idempotent. The route — not this helper — is
// where the wall is enforced: scope is NEVER self-granted, so a protected module
// can only be added by an Archon, and only a member/Archon may widen at all. This
// helper just performs the append once that gate has passed. Returns the updated
// goal row, or null for an unknown id.

async function addGoalScopeModules({ goalId, modules }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `UPDATE goals
        SET scope_modules = COALESCE((
              SELECT array_agg(DISTINCT m ORDER BY m)
                FROM unnest(scope_modules || $2::text[]) AS m
            ), '{}'),
            updated_at = now()
      WHERE id = $1
      RETURNING ${GOAL_COLS}`,
    [goalId, modules]
  );
  return rows[0] ?? null;
}

// setGoalSuccessor — the rescope carry-forward link (ADR 0086 §6 / BV1.R64). Stamps
// an (achieved) goal's succeeded_by_goal_id to point at the new-version goal that
// continues it, so the version→version lineage is queryable. Bumps updated_at.
// Returns the updated row, or null if the goal id is unknown.

async function setGoalSuccessor({ goalId, successorId }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `UPDATE goals
        SET succeeded_by_goal_id = $2, updated_at = now()
      WHERE id = $1
      RETURNING ${GOAL_COLS}`,
    [goalId, successorId]
  );
  return rows[0] ?? null;
}

// -------------------------------------------------------------------------
// Private goals: visibility + the invite / join-request queue (task 1951 / ADR
// 0112). The query layer only — the routes (task 1952) hold the authorization
// wall (owner|manager|Archon for invites/approvals; the invitee for accepting).
// -------------------------------------------------------------------------

// setGoalVisibility — flip a goal public|private (ADR 0112). 'public' is the
// migration default = today's open-join; 'private' means non-members can't
// self-join (they are invited or request+approved). Bumps updated_at. Returns
// the updated goal row, or null for an unknown id. The route gates WHO may call
// this (authorizeGoalManagement: owner|manager|Archon); this helper just writes.
async function setGoalVisibility({ goalId, visibility }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `UPDATE goals
        SET visibility = $2, updated_at = now()
      WHERE id = $1
      RETURNING ${GOAL_COLS}`,
    [goalId, visibility]
  );
  return rows[0] ?? null;
}

// createMembershipRequest — open a pending invite (kind='invite', a manager asks
// builder_id in) or join-request (kind='request', the builder asks to join). The
// partial-unique index (one pending row per goal+builder) means a duplicate ask
// raises 23505; we surface it as a typed PENDING_EXISTS the route maps to 409 (the
// access_requests precedent). createdBy is who opened it. Returns the new row.
async function createMembershipRequest({ goalId, builderId, kind, createdBy = null, note = null }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  try {
    const { rows } = await activePool.query(
      `INSERT INTO goal_membership_requests (goal_id, builder_id, kind, created_by, note)
            VALUES ($1, $2, $3, $4, $5)
       RETURNING ${MEMBERSHIP_REQUEST_COLS}`,
      [goalId, builderId, kind, createdBy, note]
    );
    return rows[0];
  } catch (err) {
    if (err && err.code === '23505') {
      const e = new Error('a pending membership request already exists for this builder on this goal');
      e.code = 'PENDING_EXISTS';
      throw e;
    }
    throw err;
  }
}

// getMembershipRequest — one request row by id, or null. The route reads it to
// check kind + goal_id + status + builder_id before authorizing a resolve.
async function getMembershipRequest(id, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `SELECT ${MEMBERSHIP_REQUEST_COLS} FROM goal_membership_requests WHERE id = $1`,
    [id]
  );
  return rows[0] ?? null;
}

// resolveMembershipRequest — close a pending request. status is one of
// 'accepted' | 'rejected' | 'cancelled'. The WHERE status='pending' guard makes
// it atomic + idempotent: a lost race (already resolved / gone) returns null, so
// the route never double-adds a member off a re-submitted resolve. resolvedBy is
// who closed it. The membership add itself is the route's job (addGoalMember on
// accept/approve). Returns the updated row, or null when nothing was pending.
async function resolveMembershipRequest({ id, status, resolvedBy = null }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `UPDATE goal_membership_requests
        SET status = $2, resolved_by = $3, resolved_at = now(), updated_at = now()
      WHERE id = $1 AND status = 'pending'
     RETURNING ${MEMBERSHIP_REQUEST_COLS}`,
    [id, status, resolvedBy]
  );
  return rows[0] ?? null;
}

// acceptMembershipRequestAndAddMember — the ACCEPT/APPROVE half done ATOMICALLY
// (task 1952 review fix). Resolving a request to 'accepted' and adding the
// member used to be two separate queries: an error between them left an
// 'accepted' row with no membership — unrecoverable, since the row is no longer
// pending and can't be re-accepted. One CTE makes them a single statement: the
// member INSERT feeds off the SAME UPDATE (the createGoal / transferGoalOwnership
// atomic-CTE precedent), so either both land or neither does. The UPDATE's
// WHERE status='pending' keeps it idempotent — a lost race (already resolved /
// gone) resolves nothing, adds nobody, and returns null. On the (near-impossible,
// since the create routes reject an existing member) membership conflict the
// existing role is PRESERVED, so an approve never silently demotes a manager.
// Returns { request, member } or null.
async function acceptMembershipRequestAndAddMember({ id, resolvedBy = null }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `WITH resolved AS (
       UPDATE goal_membership_requests
          SET status = 'accepted', resolved_by = $2, resolved_at = now(), updated_at = now()
        WHERE id = $1 AND status = 'pending'
       RETURNING ${MEMBERSHIP_REQUEST_COLS}
     ), added AS (
       INSERT INTO goal_members (goal_id, builder_id, role)
       SELECT goal_id, builder_id, 'member' FROM resolved
       ON CONFLICT (goal_id, builder_id) DO UPDATE SET role = goal_members.role
       RETURNING goal_id, builder_id, role, joined_at
     )
     SELECT (SELECT to_jsonb(r) FROM resolved r) AS request,
            (SELECT to_jsonb(a) FROM added a)    AS member`,
    [id, resolvedBy]
  );
  const request = rows[0] && rows[0].request;
  if (!request) return null;   // nothing was pending — no resolve, no member added
  return { request, member: rows[0].member };
}

// listInboxFor — the home-page inbox (task 1954) for one builder, three buckets:
//   • invitations     — pending invites addressed to ME (accept/decline), with the
//                        goal + who invited me.
//   • joinRequests    — pending join-requests on goals I OWN or MANAGE
//                        (goals.created_by = me OR a goal_members 'lead' row for me),
//                        with the goal + the asker's identity + their note (approve/deny).
//   • myPendingRequests — my own outstanding join-requests (so I can see/withdraw them).
// Requests only ever exist on private goals someone made private, so an
// owner/manager always exists — a request never lands in nobody's inbox. Archons
// can still approve any request via the route; the inbox stays scoped to what a
// builder owns/manages so it doesn't drown an Archon in every goal's queue.
async function listInboxFor(builderId, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const [invitations, joinRequests, myPendingRequests] = await Promise.all([
    activePool.query(
      `SELECT r.id, r.goal_id, r.kind, r.status, r.note, r.created_at,
              g.title AS goal_title, g.version_id, g.visibility,
              ib.github_login AS invited_by_login, ib.display_name AS invited_by_name,
              ib.avatar_url AS invited_by_avatar
         FROM goal_membership_requests r
         JOIN goals g ON g.id = r.goal_id
         LEFT JOIN builders ib ON ib.id = r.created_by
        WHERE r.kind = 'invite' AND r.status = 'pending' AND r.builder_id = $1
        ORDER BY r.created_at, r.id`,
      [builderId]
    ),
    activePool.query(
      `SELECT r.id, r.goal_id, r.builder_id, r.kind, r.status, r.note, r.created_at,
              g.title AS goal_title, g.version_id, g.visibility,
              b.github_login, b.display_name, b.avatar_url, b.rank
         FROM goal_membership_requests r
         JOIN goals g ON g.id = r.goal_id
         LEFT JOIN builders b ON b.id = r.builder_id
        WHERE r.kind = 'request' AND r.status = 'pending'
          AND (g.created_by = $1
               OR EXISTS (SELECT 1 FROM goal_members gm
                           WHERE gm.goal_id = g.id AND gm.builder_id = $1 AND gm.role = 'lead'))
        ORDER BY r.created_at, r.id`,
      [builderId]
    ),
    activePool.query(
      `SELECT r.id, r.goal_id, r.status, r.note, r.created_at,
              g.title AS goal_title, g.version_id, g.visibility
         FROM goal_membership_requests r
         JOIN goals g ON g.id = r.goal_id
        WHERE r.kind = 'request' AND r.status = 'pending' AND r.builder_id = $1
        ORDER BY r.created_at, r.id`,
      [builderId]
    ),
  ]);
  return {
    invitations: invitations.rows,
    joinRequests: joinRequests.rows,
    myPendingRequests: myPendingRequests.rows,
  };
}

// listPendingRequestsForGoal — the goals-page manager view (task 1953): every
// pending row on a goal, BOTH kinds (invites the goal has outstanding + join-
// requests awaiting approval), with the counterpart builder's identity. Ordered
// kind-then-time so invites and requests group predictably.
async function listPendingRequestsForGoal(goalId, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `SELECT r.id, r.goal_id, r.builder_id, r.kind, r.status, r.note, r.created_at,
            b.github_login, b.display_name, b.avatar_url, b.rank
       FROM goal_membership_requests r
       LEFT JOIN builders b ON b.id = r.builder_id
      WHERE r.goal_id = $1 AND r.status = 'pending'
      ORDER BY r.kind, r.created_at, r.id`,
    [goalId]
  );
  return rows;
}

// -------------------------------------------------------------------------
// Tasks
// -------------------------------------------------------------------------


// task 1763: resolve a version's catch-all "<version> — general" goal (created by
// migration 160, created_by NULL). This is the fallback goal a goal-less task
// defaults into (see createTask) so the "every task belongs to a goal" invariant
// holds for every create-vector. Returns the goal id, or null when the version has
// no general goal (then the caller leaves goal_id NULL rather than failing a
// create). Honors the #538 deps.pool test seam (NODE_ENV==='test') so it is
// unit-testable DB-free. The title match mirrors migration 160's insert exactly
// (v.id || ' — general', a spaced em-dash) — keep the two in sync.
async function generalGoalIdForVersion(versionId, deps = {}) {
  if (versionId == null) return null;
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `SELECT id FROM goals WHERE version_id = $1 AND title = $1 || ' — general' LIMIT 1`,
    [versionId]
  );
  return rows[0] ? rows[0].id : null;
}

async function createTask({
  versionId,
  title,
  description = '',
  status = 'backlog',
  touches = [],
  estMinutes = null,
  estCostUsd = null,
  manualDegree = null,
  priority = null,
  automationTag = null,
  creditsReward = 0,
  source = null,
  sourceRef = null,
  valueSummary = null,
  kind = 'unclassified',
  discipline = 'unclassified',
  parallelSafe = null,
  newcomerFriendly = false,
  needsMigration = false,
  securitySensitive = false,
  requiresRank = null,
  moduleKey = null,
  // BV1.R60 / ADR 0086 §3: goal-authored tasks stamp the goal they were created
  // under (POST /goals/:id/tasks). Nullable — every other create-vector (POST
  // /tasks, capture, restock, discord-bugs, seeds) omits it and creates a
  // goal-less task exactly as before. The rank floor still auto-derives above
  // (requiresRank stays null for the goal vector → derived purely from touches +
  // sensitivity), so goal_id never influences the requires_rank clamp.
  goalId = null,
}) {
  // task 1498 / ADR 0085: every task carries a deliberate rank floor. Derive it
  // from touches + sensitivity, then let an explicit requiresRank override only
  // UPWARD (highestRank) — a requested rank below the derived floor is clamped
  // up to the floor (fail-closed; the floor mirrors the trust-boundary paths a
  // sub-Metic builder cannot push to anyway).
  const requiresRankEffective = highestRank(
    deriveRequiredRank(touches, securitySensitive),
    requiresRank ?? 'xenos'
  );
  // task 1677 / ADR 0096 (2026-06-28): creation is now the PRIMARY reward-assignment
  // point — every task is born with a fair drachmae value, not just at promote/claim.
  // When the caller supplies NO positive credits_reward (null/undefined/0), auto-assign
  // the capped (<=REWARD_SUGGESTION_CAP) suggestion from kind + est_minutes here, at the
  // lowest create layer, so EVERY create-vector (POST /tasks, idea-promotion, capture,
  // newcomer-restock, discord-bugs, seed scripts) inherits creation-time assignment.
  // An explicitly-provided POSITIVE value is respected (author-set, never overridden).
  // The promote/claim auto-assign (tasks 1670/1673) stays as a backstop for any legacy
  // or edge path that still births a 0-reward row. Cost-plus session reward (ADR 0054)
  // remains the ungameable primary pay driver; this per-task value is a capped floor.
  let creditsRewardEffective = creditsReward;
  if (rewardMissing(creditsRewardEffective)) {
    creditsRewardEffective = suggestCreditsReward({ est_minutes: estMinutes, kind });
  }
  // task 1763: every task belongs to a goal. The goal-authored vector (POST
  // /goals/:id/tasks) passes goalId; every OTHER vector (POST /tasks, capture,
  // newcomer-restock, discord-bugs, seeds) omits it — so default a goal-less task
  // into its version's catch-all "<version> — general" goal here, at the lowest
  // create layer, so the invariant holds for all of them without touching each
  // caller. If the version has no general goal the fallback is null and the task
  // is created goal-less exactly as before — a creator must never be broken.
  let goalIdEffective = goalId;
  if (goalIdEffective == null) {
    goalIdEffective = await generalGoalIdForVersion(versionId);
  }
  const { rows } = await pool.query(
    `INSERT INTO tasks (version_id, title, description, status, touches,
                        est_minutes, est_cost_usd, manual_degree, priority,
                        automation_tag, credits_reward, source, source_ref, value_summary,
                        kind, discipline, parallel_safe, newcomer_friendly, needs_migration,
                        security_sensitive, requires_rank, module_key, goal_id, promoted_at)
     VALUES ($1, $2, $3, $4, $5,
             $6, $7, $8, $9,
             $10, $11, $12, $13, $14,
             $15, $16, $17, $18, $19,
             $20, $21, $22, $23,
             CASE WHEN $4 IN ('ready','active') THEN now() ELSE NULL END)
     RETURNING *`,
    [
      versionId,
      title,
      description,
      status,
      touches,
      estMinutes,
      estCostUsd,
      manualDegree,
      priority,
      automationTag,
      creditsRewardEffective,
      source,
      sourceRef,
      valueSummary,
      kind,
      discipline,
      parallelSafe,
      newcomerFriendly === true,
      needsMigration === true,
      securitySensitive === true,
      requiresRankEffective,
      moduleKey ?? null,
      goalIdEffective ?? null,
    ]
  );
  // task 1677 / ADR 0096: audit each creation-time auto-assignment so the trail is
  // complete (the visible credits_reward on the row is the other half). Only logs
  // when we actually filled an unset reward — an explicit positive value is silent.
  if (rewardMissing(creditsReward) && rows[0]) {
    console.log(
      `[reward-gate] AUTO-ASSIGN task ${rows[0].id} credits_reward -> ${creditsRewardEffective} (cap ${REWARD_SUGGESTION_CAP}) [creation]`
    );
  }
  return rows[0];
}

// task 386 (idea #85): app-level idempotency for the POST /tasks create-vector.
// Returns the EARLIEST existing task carrying this (source, source_ref) pair, or
// null when either is absent. Keyed on (source, source_ref) — the exact pair
// cost_log already dedups on (see logCost: `ON CONFLICT (source, source_ref)`) —
// so a re-submitted create (a retried POST, a capture re-run) resolves to the
// original row instead of silently minting a duplicate.
//
// Deliberately NOT a DB unique constraint: the tasks table already carries
// historical (source, source_ref) duplicates (the very bug this closes — e.g.
// #248 dup of #252), so `CREATE UNIQUE INDEX` would fail to build on deploy. The
// Archon-only, low-frequency POST /tasks vector makes the SELECT-then-insert race
// window irrelevant. The other create-vectors (newcomer-restock, triage
// promotion, discord-bugs) call createTask directly and own their own dedup, so
// route-level idempotency leaves them untouched. #538 test seam mirrored.

async function findTaskBySourceRef({ source, sourceRef } = {}, deps = {}) {
  if (source == null || sourceRef == null || sourceRef === '') return null;
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { rows } = await activePool.query(
    `SELECT * FROM tasks
      WHERE source = $1 AND source_ref = $2
      ORDER BY id ASC
      LIMIT 1`,
    [source, sourceRef]
  );
  return rows[0] ?? null;
}

// newcomerInstanceStats (the evergreen-chore supply read) carved into
// modules/onboarding/db.js (BV1.R81 / ADR 0093 §1) — it backs the onboarding
// module's newcomer-restock and is part of that domain's data layer.

// updateTaskColumn (task 1086, C2) — the single-column task setters below were
// byte-identical except for the column name and (security_sensitive) a boolean
// coercion. One allowlisted helper backs them all. The ALLOWLIST gates the
// interpolated column name as defense-in-depth: callers pass a hard-coded literal,
// never user input, so this can never become SQL injection.

const TASK_SETTER_COLUMNS = new Set([
  'kind', 'discipline', 'newcomer_friendly', 'security_sensitive', 'parallel_safe', 'automation_tag',
]);

async function updateTaskColumn(id, column, value) {
  if (!TASK_SETTER_COLUMNS.has(column)) {
    throw new Error(`updateTaskColumn: column "${column}" is not an allowed task setter`);
  }
  const { rows } = await pool.query(
    `UPDATE tasks SET ${column} = $1, updated_at = now() WHERE id = $2 RETURNING *`,
    [value, id]
  );
  return rows[0] ?? null;
}


// task 1763: (re)assign a task's goal_id. Deliberately NOT a TASK_SETTER_COLUMNS
// flag — goal_id is a FK the PATCH /tasks/:id route validates (goal exists + same
// version as the task) before calling this, so it stays a dedicated setter rather
// than a bare allowlisted column. updated_at bumps like the flag setters.
// createCriterion — add a done-when criterion to a version at RUNTIME (the
// POST /versions/:id/done-when Archon route). ADR 0105 moved scope-truth seeds
// out of the normal migration path, so a brand-new criterion on a running
// instance can't be added by a plain migration; this is the live vector a
// planning session uses. sort_order defaults to max(existing)+1 (mirrors the
// criterion-proposal ratify path). Throws 23505 on a duplicate (version_id,
// criterion_id) — the route maps that to 409.
async function createCriterion({ versionId, criterionId, criterionMd, goalId = null, sortOrder = null }) {
  let order = sortOrder;
  if (order == null) {
    const { rows: maxRows } = await pool.query(
      `SELECT COALESCE(MAX(sort_order), 0) + 1 AS next FROM done_when_criteria WHERE version_id = $1`,
      [versionId]
    );
    order = maxRows[0].next;
  }
  const { rows } = await pool.query(
    `INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, goal_id, sort_order)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING id, version_id, criterion_id, criterion_md, goal_id, sort_order, satisfied`,
    [versionId, criterionId, criterionMd, goalId, order]
  );
  return rows[0];
}

async function updateTaskGoal(id, goalId) {
  const { rows } = await pool.query(
    `UPDATE tasks SET goal_id = $1, updated_at = now() WHERE id = $2 RETURNING *`,
    [goalId, id]
  );
  return rows[0] ?? null;
}


async function updateTaskKind(id, kind) { return updateTaskColumn(id, 'kind', kind); }


async function updateTaskDiscipline(id, discipline) { return updateTaskColumn(id, 'discipline', discipline); }

// #360 / ADR 0018 + V3.R15 #239: open (or close) a task to Xenos claims by
// marking it newcomer_friendly. Default false; an Archon sets it true to let
// the sandboxed entry rank claim+ship this task. (Column was renamed from
// xenos_claimable → newcomer_friendly in migration 039 — the property describes
// the *task*, not "who is allowed".) (The legacy updateTaskXenosClaimable alias
// was removed in the task-874 dead-code sweep — it had zero callers.)

async function updateTaskNewcomerFriendly(id, newcomerFriendly) { return updateTaskColumn(id, 'newcomer_friendly', newcomerFriendly); }

// task 990 / migration 084 — flag a task security-sensitive (or not). When set,
// its ship broadcast routes ONLY to the Archon-only #security-ship-feed channel
// (ship.js chooseBroadcastTargets), never the public #ship-news / #ship-feed.
// Explicit, never heuristic: a misfire leaks an unpatched exploit. Boolean only
// (the === true coercion below preserves the boolean-only contract).

async function updateTaskSecuritySensitive(id, securitySensitive) {
  // task 1498 / ADR 0085: flagging a task security_sensitive RAISES its rank
  // floor (a now-sensitive task must require Metic+). Recompute and ratchet
  // requires_rank UP in the same atomic UPDATE so the two columns can't diverge;
  // never lower it (an existing 'metic'/'archon' may be a protected-touch floor
  // or a deliberate override — flipping the flag off doesn't drop the gate; an
  // Archon can PATCH requires_rank down to the derived floor explicitly).
  const sec = securitySensitive === true;
  const { rows } = await pool.query(
    `UPDATE tasks
        SET security_sensitive = $1,
            requires_rank = CASE WHEN $1 AND requires_rank IN ('xenos', 'thetes')
                                 THEN 'metic' ELSE requires_rank END,
            updated_at = now()
      WHERE id = $2
      RETURNING *`,
    [sec, id]
  );
  return rows[0] ?? null;
}

// task 1498 / ADR 0085: set a task's rank floor explicitly (the Archon override).
// The DERIVED floor (touches + security_sensitive) is a HARD minimum — a request
// below it is clamped UP via highestRank, so an override can only RAISE the bar,
// never open a sensitive task to a lower rank. `requiresRank` is one live rank
// (xenos|thetes|metic|archon); the route validates the enum. Returns the updated
// row, or null when the task is missing.

async function updateTaskRequiresRank(id, requiresRank) {
  const task = await getTask(id);
  if (!task) return null;
  const floor = deriveRequiredRank(task.touches, task.security_sensitive);
  const effective = highestRank(floor, requiresRank ?? 'xenos');
  const { rows } = await pool.query(
    `UPDATE tasks SET requires_rank = $1, updated_at = now() WHERE id = $2 RETURNING *`,
    [effective, id]
  );
  return rows[0] ?? null;
}

// ---------------------------------------------------------------------------
// task 1670 / ADR 0096 — require a credits_reward (drachmae) before a task is
// workable. credits_reward defaults to 0 (migration 003); historically a task
// could be promoted to 'ready' and claimed+shipped while paying 0 drachmae. The
// gate below makes a present, positive reward a precondition for the two
// workable transitions (promote-to-ready + claim). It is AUTHOR-SET, never
// auto-derived (ADR 0023 anti-gaming): we may SUGGEST a value, never apply it.
//
// Pure helpers so the route + the claim path + the unit tests all share one
// source of truth (the deriveRequiredRank/highestRank precedent).
// ---------------------------------------------------------------------------

// A "fully unrewarded" task is one whose credits_reward is NULL or <= 0.
function rewardMissing(creditsReward) {
  return creditsReward === null || creditsReward === undefined || Number(creditsReward) <= 0;
}

// Suggest a starting drachmae value — derived from est_minutes scaled by a
// coarse per-kind weight (ADR 0023 kind multipliers). ~1 drachma/min of
// estimated work, floored at 5 so a tiny task still names a non-zero number,
// and CAPPED at REWARD_SUGGESTION_CAP.
//
// task 1673 / ADR 0096 amendment (2026-06-28): the gate shifted from BLOCK to
// AUTO-ASSIGN — this value is now PERSISTED onto the task at the promote/claim
// gate, not merely suggested. That reverses ADR 0023's "never auto-derive"
// stance for the *gate-time backstop only*, so the cap below is load-bearing
// anti-gaming: it bounds how much est-inflation can balloon an auto-assigned
// payout. The ungameable cost-plus session reward (ADR 0054) stays the PRIMARY
// pay driver; this per-task value is a modest, capped floor. Anyone wanting more
// than the cap must still set credits_reward by hand via PATCH /tasks/:id
// (author-set, review-gated — the ADR 0023 path is intact for explicit values).
const KIND_REWARD_WEIGHT = {
  feature: 1.0, bug: 1.25, infra: 1.0, refactor: 0.85, spike: 0.75,
  'learning-capture': 0.75, cleanup: 0.6, decision: 1.0, 'blocker-resolution': 1.25,
  unclassified: 1.0,
};
const REWARD_SUGGESTION_CAP = 60; // drachmae — anti-gaming ceiling on the auto-assigned value
function suggestCreditsReward({ est_minutes, kind } = {}) {
  const mins = Number(est_minutes);
  const base = Number.isFinite(mins) && mins > 0 ? mins : 30; // default ~30-min task
  const weight = KIND_REWARD_WEIGHT[kind] ?? 1.0;
  const raw = Math.max(5, Math.round(base * weight));
  return Math.min(REWARD_SUGGESTION_CAP, raw); // capped so est-inflation can't balloon pay
}

// task 1673 / ADR 0096 amendment (2026-06-28): AUTO-ASSIGN at the gate instead
// of BLOCKING. The shared decision helper for the promote route + the claim
// backstop. Given a task, decide whether the reward gate needs to ACT:
//   - returns { assign: N } when the task is unrewarded AND not grandfathered —
//     the caller must persist credits_reward = N (the capped suggestion) and
//     PROCEED (no refusal). Grandfathered/exempt rows that are still 0 also get
//     a real value here, so the ~27 reward_gate_exempt tasks earn a fair payout
//     when claimed.
//   - returns null when the task already has a positive reward (nothing to do).
// `grandfathered` is retained for signature back-compat; it no longer suppresses
// the assignment (we WANT to value the grandfathered zero-reward tasks), so the
// reward_gate_exempt column is now inert — see the ADR amendment.
function rewardGateAssignment(task) {
  if (!task) return null;
  if (!rewardMissing(task.credits_reward)) return null;
  return { assign: suggestCreditsReward(task) };
}

// Back-compat shim. The pre-1673 gate BLOCKED with this error object; callers and
// the unit tests referenced it. The gate now AUTO-ASSIGNS, so the wired callers
// no longer consult it — kept exported so any stale external reference resolves,
// returning null (no refusal) when a reward is present.
function rewardGateError(task, { grandfathered = false } = {}) {
  if (!task) return null;
  if (grandfathered || task.reward_gate_exempt === true) return null;
  if (!rewardMissing(task.credits_reward)) return null;
  const suggested = suggestCreditsReward(task);
  return { code: 'REWARD_REQUIRED', suggested };
}

// Persist an auto-assigned credits_reward. Standalone (own pool query) variant
// for the promote route. Logs an AUDIT line so every auto-assignment is traceable
// (the visible credits_reward change is the other half of the audit trail).
async function setCreditsReward(id, value) {
  const { rows } = await pool.query(
    `UPDATE tasks SET credits_reward = $1, updated_at = now() WHERE id = $2 RETURNING id, credits_reward`,
    [value, id]
  );
  console.log(`[reward-gate] AUTO-ASSIGN task ${id} credits_reward -> ${value} (cap ${REWARD_SUGGESTION_CAP}) [promote]`);
  return rows[0] ?? null;
}

// migration 028 — flag a task safe (or not) to run alongside others in a
// parallel autonomous run. Accepts true | false | null (null = un-judged).

async function updateTaskParallelSafe(id, parallelSafe) { return updateTaskColumn(id, 'parallel_safe', parallelSafe); }

// Recategorize a task's automation_tag mid-life so the autonomous overnight
// runner's --fit filter (tasks_session_fit view, migration 028) can pick it
// up — or drop it. Accepts 'overnight-safe' | 'live-only' | 'needs-input' |
// null. Surfaced because at task-creation triage we are often conservative
// and leave the tag unset, then later judge that a task is safe to delegate.

async function updateTaskAutomationTag(id, automationTag) { return updateTaskColumn(id, 'automation_tag', automationTag); }

// BV1.R53 (task 1422): assign (or clear) the module_key that declares which
// module this task's work belongs to. Drives module-disjointness at claim time
// and diff⊆module enforcement at ship time. Accepts any key in MODULE_SCOPE_MAP,
// or null to clear. Validation happens in the route; this just writes the column.

async function updateTaskModuleKey(id, moduleKey) { return updateTaskColumn(id, 'module_key', moduleKey); }

// touches[] cleanup [4/8] (task 879): updateTaskTouches() was removed with the
// drift scanner + the PATCH /tasks/:id touches branch + ship's drift-expand
// flow. touches[] is no longer mutated mid-claim — a wrong up-front prediction
// is repaired (when it matters at all) by git merge / the claim-time overlap
// guard, not by rewriting the array. The claim-time parallel-safety invariant
// it duplicated still lives in claimTask().


// task 1957: credits_awarded is the ACTUAL drachmae paid out for completing a
// task — the sum of the TASK-REWARD credit_log deltas booked against it: the
// confirm credit ('task.confirmed', = credits_reward × kind-multiplier), the
// idea-promotion bonus, and the net-negative (simplification) bonus, across all
// builders. The reason allowlist is deliberate: achievement unlocks
// ('achievement.*') also carry the shipped task's id but are GAMIFICATION, not a
// reward for the task, so they must NOT inflate the payout (session.token_reward
// and rank_change carry task_id=NULL and are excluded already). The CASE guard
// short-circuits to 0 for unsettled tasks so the hot board/claimable list never
// scans credit_log (credits don't land until 'confirmed' anyway) — the UI shows
// credits_reward (the creation-time ESTIMATE) with an "Est." label until then,
// and this real ledger figure once confirmed/shipped. Read-only; no schema change.
const CREDITS_AWARDED_SUBQUERY =
  `CASE WHEN t.status IN ('confirmed', 'shipped')
        THEN (SELECT COALESCE(SUM(cl.delta), 0)::int
                FROM credit_log cl
               WHERE cl.task_id = t.id
                 AND cl.reason IN ('task.confirmed', 'idea_promotion_bonus', 'ship.net_negative'))
        ELSE 0 END`;

async function getTask(id) {
  const { rows } = await pool.query(
    `SELECT t.*, ${CREDITS_AWARDED_SUBQUERY} AS credits_awarded,
            pms_calibrated_minutes(t.est_minutes, t.kind) AS est_minutes_calibrated
       FROM tasks t WHERE t.id = $1`,
    [id]
  );
  return rows[0] ?? null;
}


async function listTasks({ versionId, status, kind, discipline, goalId } = {}) {
  const params = [];
  const where = [];
  if (versionId) {
    params.push(versionId);
    where.push(`version_id = $${params.length}`);
  }
  if (status) {
    params.push(status);
    where.push(`status = $${params.length}`);
  }
  if (kind) {
    params.push(kind);
    where.push(`kind = $${params.length}`);
  }
  if (discipline) {
    params.push(discipline);
    where.push(`discipline = $${params.length}`);
  }
  if (goalId) {
    params.push(goalId);
    where.push(`goal_id = $${params.length}`);
  }
  const sql =
    `SELECT t.*, ${CREDITS_AWARDED_SUBQUERY} AS credits_awarded,
            pms_calibrated_minutes(t.est_minutes, t.kind) AS est_minutes_calibrated
       FROM tasks t` +
    (where.length ? ` WHERE ${where.join(' AND ')}` : '') +
    ` ORDER BY priority NULLS LAST, created_at`;
  const { rows } = await pool.query(sql, params);
  return rows;
}

// Tasks that are ready, unblocked, and have no touches[] overlap
// with currently active claims. Excludes tasks already claimed by this
// builder (so the same builder doesn't see their own active claim listed
// as "claimable").
// `fit` (optional) narrows the list to tasks that are safe to run in an
// autonomous/overnight session-runner (task #358):
//   'autonomous' — autonomous-fit per the canonical tasks_session_fit view
//                  ('autonomous' ∈ fits_session_modes, i.e. overnight-safe +
//                  manual_degree<=2 + unblocked). claimable_tasks already
//                  excludes blocked tasks, but we join the view so the
//                  definition of "autonomous" lives in exactly one place.
//   'parallel'   — autonomous-fit AND tasks.parallel_safe = true (the planning
//                  judgment that a task is safe to run alongside others).
//
// SR-12 / finding G2 (task 994) — PROTECTED-PATH EXCLUSION for autonomous fit.
// The overnight-builder runs as Archon and direct-pushes to main; every
// write-side gate keys on the AUTHOR's rank and only blocks authors BELOW Metic,
// so an archon-authored autonomous commit sails through all of them. A task's
// `description` originates (via idea-triage promotion) from idea_inbox.body_md,
// which any xenos / unlinked Discord user can seed — so attacker-seeded text can
// reach an archon-authority agent. To stop a seeded directive from reaching the
// permission/methodology/deploy CORE unreviewed, any --fit task whose declared
// touches[] overlap a permission-sensitive path (the ADR 0043 protected set) is
// EXCLUDED from the autonomous/parallel feed. Those tasks still appear in the
// normal interactive claimable list — a human must own them; an autonomous run
// never can. This is a HARD control (a JS post-filter on the fit query), not a
// soft prompt instruction. Backstops the SKILL.md fencing (layer 1).

async function listClaimableTasks({ versionId = null, builderId = null, discipline = null, fit = null } = {}) {
  const params = [];
  const where = [];
  if (versionId) {
    params.push(versionId);
    where.push(`v.version_id = $${params.length}`);
  }
  if (discipline) {
    params.push(discipline);
    where.push(`v.discipline = $${params.length}`);
  }
  if (builderId) {
    params.push(builderId);
    where.push(`NOT EXISTS (
      SELECT 1 FROM claims c2
       WHERE c2.task_id = v.id
         AND c2.builder_id = $${params.length}
         AND c2.released_at IS NULL
    )`);
    // V3.R15 #239: view-level sandbox gate. A sandboxed builder sees ONLY
    // newcomer_friendly tasks in the claimable feed; the live general-queue
    // ranks see everything. The view itself is builder-agnostic (views can't
    // read session context), so the filter is realized here at SELECT time.
    // Belt-and-braces with the row-level check in claimTask, which still throws
    // rank_too_low_for_task at claim time.
    // #510: FAIL CLOSED — allowlist the general-queue ranks {thetes, metic,
    // archon} (mirrors GENERAL_QUEUE_RANKS / xenosClaimAllowed in JS) rather than
    // the old `<> 'xenos'` test, which failed OPEN (any reserved/unknown/typo
    // rank — or a NULL from a missing lookup — was treated as privileged and
    // shown the whole queue). thetes is live (#692 / ADR 0034) so it stays in.
    where.push(`(
      (SELECT rank FROM builders WHERE id = $${params.length}) IN ('thetes', 'metic', 'archon')
      OR v.newcomer_friendly = true
    )`);
    // V3.R82 #301: view-level requires_rank floor. The CASE expressions map
    // both sides to the live tier; a builder is shown a task iff their tier >=
    // the task's required tier. The tiers MUST mirror REQUIRES_RANK_TIER in JS
    // (xenos=1, thetes=2, metic=3, archon=4 — thetes added #692 / mig 068);
    // any rank outside the four live ones collapses to 0 and is gated out —
    // same fail-closed behaviour as rankAllowsTask in JS. Same parameter index
    // as the xenos gate above ($${params.length}) because both refer to the
    // same builderId.
    where.push(`(
      CASE (SELECT rank FROM builders WHERE id = $${params.length})
        WHEN 'archon' THEN 4 WHEN 'metic' THEN 3 WHEN 'thetes' THEN 2 WHEN 'xenos' THEN 1 ELSE 0
      END
    ) >= (
      CASE COALESCE(v.requires_rank, 'xenos')
        WHEN 'archon' THEN 4 WHEN 'metic' THEN 3 WHEN 'thetes' THEN 2 WHEN 'xenos' THEN 1 ELSE 0
      END
    )`);
  }
  // Autonomy / parallel-eligibility filter. Joining tasks_session_fit (also a
  // SELECT t.* view) makes bare column names like priority/created_at ambiguous,
  // so the ORDER BY below qualifies them with v. unconditionally.
  let fitJoin = '';
  if (fit === 'autonomous' || fit === 'parallel') {
    fitJoin = ` JOIN tasks_session_fit sf ON sf.id = v.id`;
    where.push(`'autonomous' = ANY(sf.fits_session_modes)`);
    if (fit === 'parallel') {
      where.push(`v.parallel_safe = true`);
    }
  }
  // Order by calibrated estimate (falls back to raw when calibrator returns NULL
  // — e.g. unestimated tasks). Calibrated reflects realistic time-to-ship given
  // recent actuals; ordering on the raw estimate puts oversized tasks at the
  // bottom even when their actual time-to-ship is short. See migration 015.
  const sql =
    `SELECT v.* FROM claimable_tasks v` + fitJoin +
    (where.length ? ` WHERE ${where.join(' AND ')}` : '') +
    ` ORDER BY v.priority NULLS LAST,
              COALESCE(v.est_minutes_calibrated, v.est_minutes) NULLS LAST,
              v.created_at`;
  const { rows } = await pool.query(sql, params);
  // SR-12 / G2 (task 994): when the autonomous/parallel runner is asking, drop
  // any task whose declared touches[] reach the permission/methodology/deploy
  // core. The runner ships as Archon straight to main, so these must never be
  // claimed unsupervised — a human owns them. Applied in JS (not SQL) so it
  // reuses the single canonical protected-path matcher (matchProtected) shared
  // with the grader pre-pass, pre-push hook, and main-audit — no second source
  // of truth to drift.
  if (fit === 'autonomous' || fit === 'parallel') {
    return rows.filter((t) => !taskTouchesProtectedPath(t));
  }
  // Newcomer-chore display cap (task 1266, owner decision 2026-06-19). The
  // newcomer-floor keeps a deep supply pool (floor: 3 artist + 2 ideator) so
  // several newcomers arriving at once each have something to grab — but that
  // pool depth is a CROSS-BUILDER supply concept, not one person's to-do list.
  // Shown raw, a single artist+ideator sees five near-identical "Same as above"
  // seats. Cap the newcomer_friendly rows in the human-facing feed to 3 so the
  // menu maps to the Xenos->Thetes bar (ship 3 works). Reached only on the
  // human/default path — the autonomous/parallel runner returned above and is
  // untouched. The floor replenisher counts ready+backlog rows and is likewise
  // unaffected (it never reads this feed).
  return capNewcomerTasks(rows);
}

// Cap the number of newcomer_friendly rows in a claimable feed to `cap`
// (task 1266). Pure + exported for unit testing. Non-newcomer (real version)
// rows pass through untouched and unbounded. When newcomer rows exceed the cap
// they're selected round-robin across the disciplines PRESENT among them — so
// each of the builder's lanes is represented before a slot goes to a duplicate
// of an already-shown discipline. Input ordering (priority, est, created) is
// preserved: we compute a keep-set of ids and then filter the original array.

function capNewcomerTasks(rows, cap = 3) {
  const all = Array.isArray(rows) ? rows : [];
  const newcomer = all.filter((t) => t && t.newcomer_friendly === true);
  if (newcomer.length <= cap) return all;

  // Group newcomer rows by discipline, preserving (a) input order within each
  // group and (b) first-appearance order of the groups themselves — so the
  // highest-priority discipline's chore is picked first.
  const groups = new Map(); // discipline -> [rows], insertion-ordered
  for (const t of newcomer) {
    const disc = t.discipline || 'unclassified';
    if (!groups.has(disc)) groups.set(disc, []);
    groups.get(disc).push(t);
  }
  const lists = Array.from(groups.values());

  // Round-robin: take index 0 from each group, then index 1, etc., until we've
  // kept `cap` rows. Duplicate disciplines fill later passes once each lane has
  // been represented.
  const keep = new Set();
  let depth = 0;
  let progressed = true;
  while (keep.size < cap && progressed) {
    progressed = false;
    for (const list of lists) {
      if (depth < list.length) {
        keep.add(list[depth].id);
        progressed = true;
        if (keep.size >= cap) break;
      }
    }
    depth += 1;
  }

  // Filter the original (ordered) array: every non-newcomer row, plus the kept
  // newcomer rows. Preserves the original feed ordering.
  return all.filter((t) => t.newcomer_friendly !== true || keep.has(t.id));
}

// SR-12 / G2 (task 994): does this task's declared touches[] overlap any
// permission-sensitive (ADR 0043) path? Pure + exported for unit testing.
// Returns true if ANY declared touch matches a protected glob — such a task is
// off-limits to the autonomous runner regardless of who would author it,
// because the runner authors as Archon and the write-side gates can't catch a
// high-rank automated author acting on attacker-seeded task text.
//
// A task with NO declared touches[] is treated as SAFE for the feed (returns
// false): touches[] is advisory at ship time (ADR 0049), so an empty list is
// the common honest case (e.g. a small game/doc task), not a signal of danger
// — and the autonomous fit pool is already narrowed to overnight-safe +
// manual_degree<=2 + unblocked tasks. The exclusion fires only on a POSITIVE
// match against a declared protected path.

function taskTouchesProtectedPath(task) {
  const touches = Array.isArray(task && task.touches) ? task.touches : [];
  if (touches.length === 0) return false;
  return matchProtected(touches).length > 0;
}

// Cross-discipline recommendations for /builder-start (V3.R81 / #299).
//
// Given the full claimable list and the builder's preferred_disciplines,
// returns up to `limit` tasks whose discipline is OUTSIDE the builder's
// preferences — the "you might enjoy" section. Pure function (no DB round
// trip): the caller already holds the claimable rows, so we just partition
// and rank them.
//
// Ranking key (most relevant first):
//   1. priority DESC          — a P5 in another lane still beats a P1
//   2. credits-per-minute DESC — best bang-for-effort among equal priority
//   3. est_minutes ASC         — shorter wins the tiebreak (easier to try)
//   4. id ASC                  — stable final tiebreak
//
// 'unclassified' tasks are excluded: they're un-triaged, not a real lane to
// recommend exploring. If preferred_disciplines is empty (no preference), the
// builder already sees everything in the main list, so there is nothing
// "outside" to recommend — return [].

function rankCrossDisciplineRecommendations(claimable, preferredDisciplines, limit = 3) {
  const rows = Array.isArray(claimable) ? claimable : [];
  const prefs = Array.isArray(preferredDisciplines) ? preferredDisciplines : [];
  // No stated preference → no "outside", nothing to recommend.
  if (prefs.length === 0) return [];
  const prefSet = new Set(prefs);
  const cpm = (t) => {
    const credits = Number(t.credits_reward) || 0;
    const mins = Number(t.est_minutes_calibrated ?? t.est_minutes) || 0;
    return mins > 0 ? credits / mins : 0;
  };
  const outside = rows.filter(
    (t) => t.discipline && t.discipline !== 'unclassified' && !prefSet.has(t.discipline)
  );
  outside.sort((a, b) => {
    const pa = Number(a.priority) || 0;
    const pb = Number(b.priority) || 0;
    if (pb !== pa) return pb - pa; // higher priority first
    const ca = cpm(a);
    const cb = cpm(b);
    if (cb !== ca) return cb - ca; // higher credits/min first
    const ma = Number(a.est_minutes_calibrated ?? a.est_minutes) || Infinity;
    const mb = Number(b.est_minutes_calibrated ?? b.est_minutes) || Infinity;
    if (ma !== mb) return ma - mb; // shorter first
    return (Number(a.id) || 0) - (Number(b.id) || 0); // stable
  });
  return outside.slice(0, Math.max(0, limit));
}

// What's currently active across all builders. Used by /builder-start
// for the "in-flight" sidebar so a builder can see who else is on what.

async function listActiveClaims() {
  const { rows } = await pool.query(
    `SELECT c.id AS claim_id, c.task_id, c.builder_id, c.worktree_name, c.claimed_at,
            t.title, t.touches, t.version_id, t.priority,
            b.github_login, b.display_name
       FROM claims c
       JOIN tasks t ON t.id = c.task_id
       JOIN builders b ON b.id = c.builder_id
      WHERE c.released_at IS NULL
      ORDER BY c.claimed_at`
  );
  return rows;
}


async function updateTaskStatus(id, status) {
  await pool.query(`UPDATE tasks SET status = $2 WHERE id = $1`, [id, status]);
}

// -------------------------------------------------------------------------
// Task dependencies (migration 020, task 309 / V3.R01b)
// -------------------------------------------------------------------------
// Forward edge: rows where task_id = X give X's dependencies.
// Reverse edge: rows where depends_on_task_id = X give X's dependents.

// Shared projection for both dep edges. Forward (dependencies): the tasks X
// depends on. Reverse (dependents): the tasks that depend on X. Same SELECT;
// the two differ only in which side of the dependencies edge is joined vs filtered.

async function getTaskDepEdges(taskId, { reverse = false } = {}) {
  // task->task edges only (the historical dependency arrays). Goal/criterion edges
  // live in the same `dependencies` table but surface via the generic /dependencies
  // endpoint, not these task-summary arrays — so consumers see an unchanged shape
  // (task 1516). Forward: $1 is the from side; reverse: $1 is the to side.
  const joinCol = reverse ? 'd.from_id' : 'd.to_id';
  const whereCol = reverse ? 'd.to_id' : 'd.from_id';
  const { rows } = await pool.query(
    `SELECT t.id, t.title, t.status, t.version_id, t.kind, t.priority
       FROM dependencies d
       JOIN tasks t ON t.id = ${joinCol}
      WHERE d.from_kind = 'task' AND d.to_kind = 'task'
        AND ${whereCol} = $1
      ORDER BY t.title`,
    [taskId]
  );
  return rows;
}


async function getTaskDependencies(taskId) {
  return getTaskDepEdges(taskId, { reverse: false });
}


async function getTaskDependents(taskId) {
  return getTaskDepEdges(taskId, { reverse: true });
}

// Generic cycle check over the polymorphic graph. Adding edge (from -> to) creates
// a cycle iff `from` is already reachable FROM `to` along existing edges, so we seed
// the walk at `to` and look for `from`. Nodes are (kind, id) pairs tokenized as
// "kind:id"; returns the offending path of tokens, or null. Visited-set + depth cap
// keep it terminating (task 1516, generalizes the task-only CTE from migration 020).

async function findCycle(fromKind, fromId, toKind, toId, executor = pool) {
  if (fromKind === toKind && Number(fromId) === Number(toId)) {
    return [`${fromKind}:${fromId}`, `${toKind}:${toId}`];
  }
  const { rows } = await executor.query(
    `WITH RECURSIVE walk(kind, id, depth, path) AS (
       SELECT $1::text, $2::bigint, 1, ARRAY[$1 || ':' || $2::text]
       UNION ALL
       SELECT d.to_kind, d.to_id, w.depth + 1, w.path || (d.to_kind || ':' || d.to_id::text)
         FROM dependencies d
         JOIN walk w ON d.from_kind = w.kind AND d.from_id = w.id
        WHERE NOT ((d.to_kind || ':' || d.to_id::text) = ANY(w.path))
          AND w.depth < 100
     )
     SELECT path FROM walk WHERE kind = $3 AND id = $4::bigint LIMIT 1`,
    [toKind, toId, fromKind, fromId]
  );
  return rows[0]?.path ?? null;
}

// Task-only wrapper preserving the historical bigint[] path shape for the task
// dependency API. A pure task->task cycle maps cleanly to task ids; a cycle that
// traverses a goal/criterion node (possible once cross-kind edges exist) keeps those
// nodes as "kind:id" tokens rather than mislabeling them as task ids.

async function findDependencyCycle(taskId, depTaskId, executor = pool) {
  if (Number(taskId) === Number(depTaskId)) return [Number(taskId), Number(depTaskId)];
  const path = await findCycle('task', taskId, 'task', depTaskId, executor);
  if (!path) return null;
  return path.map((tok) => {
    const [kind, id] = String(tok).split(':');
    return kind === 'task' ? Number(id) : tok;
  });
}


async function addTaskDependency(taskId, depTaskId) {
  if (taskId === depTaskId) {
    throw { code: 'SELF_DEP' };
  }
  // Confirm both tasks exist
  const { rows: existing } = await pool.query(
    `SELECT id FROM tasks WHERE id = ANY($1::bigint[])`,
    [[taskId, depTaskId]]
  );
  if (existing.length !== 2) {
    throw { code: 'TASK_NOT_FOUND' };
  }
  const cyclePath = await findDependencyCycle(taskId, depTaskId);
  if (cyclePath) {
    throw { code: 'CYCLE', path: cyclePath };
  }
  await pool.query(
    `INSERT INTO dependencies (from_kind, from_id, to_kind, to_id)
     VALUES ('task', $1, 'task', $2)
     ON CONFLICT DO NOTHING`,
    [taskId, depTaskId]
  );
  return { task_id: taskId, depends_on_task_id: depTaskId };
}


async function removeTaskDependency(taskId, depTaskId) {
  const { rowCount } = await pool.query(
    `DELETE FROM dependencies
      WHERE from_kind = 'task' AND from_id = $1
        AND to_kind = 'task' AND to_id = $2`,
    [taskId, depTaskId]
  );
  return rowCount > 0;
}

// Replace the full dependency set for a task. Used by bulk seeders.
// Validates no cycles among the new set in one transaction. Order of the
// list doesn't matter.

async function setTaskDependencies(taskId, depTaskIds) {
  const unique = [...new Set(depTaskIds.map(Number))];
  if (unique.includes(Number(taskId))) {
    throw { code: 'SELF_DEP' };
  }
  return withTx(async (client) => {
    // Replace only this task's task->task edges; leave any task->goal/criterion
    // edges (created via the generic /dependencies endpoint) untouched.
    await client.query(
      `DELETE FROM dependencies WHERE from_kind = 'task' AND from_id = $1 AND to_kind = 'task'`,
      [taskId]
    );
    for (const dep of unique) {
      // Re-check cycle for each insert (using the same txn connection so the
      // previous inserts in this txn are visible). Reuses findDependencyCycle
      // with the txn client as executor — task 1087, C3.
      const cyclePath = await findDependencyCycle(taskId, dep, client);
      if (cyclePath) {
        throw { code: 'CYCLE', path: cyclePath };
      }
      await client.query(
        `INSERT INTO dependencies (from_kind, from_id, to_kind, to_id)
         VALUES ('task', $1, 'task', $2)`,
        [taskId, dep]
      );
    }
    return unique;
  });
}

// ---------------------------------------------------------------------------
// Generic polymorphic dependencies (migration 163 / ADR 0086 §5 / task 1516).
// The task->task helpers above are the historical task API over this same table;
// these add/remove/read edges of ANY kind ({task, goal, criterion}). A dependency
// is a REFERENCE, not a grant — it never widens module scope, so cross-goal /
// cross-version edges are allowed.
// ---------------------------------------------------------------------------

const DEP_KINDS = ['task', 'goal', 'criterion'];

const DEP_KIND_TABLE = { task: 'tasks', goal: 'goals', criterion: 'done_when_criteria' };


async function dependencyNodeExists(kind, id, executor = pool) {
  const table = DEP_KIND_TABLE[kind];
  if (!table) return false;
  const { rows } = await executor.query(`SELECT 1 FROM ${table} WHERE id = $1`, [id]);
  return rows.length > 0;
}

// Add a polymorphic edge "from is blocked until to is done". Throws BAD_KIND,
// SELF_DEP, NODE_NOT_FOUND, or CYCLE (with the offending kind:id path).

async function addDependency(fromKind, fromId, toKind, toId) {
  if (!DEP_KINDS.includes(fromKind) || !DEP_KINDS.includes(toKind)) throw { code: 'BAD_KIND' };
  if (fromKind === toKind && Number(fromId) === Number(toId)) throw { code: 'SELF_DEP' };
  if (!(await dependencyNodeExists(fromKind, fromId)) || !(await dependencyNodeExists(toKind, toId))) {
    throw { code: 'NODE_NOT_FOUND' };
  }
  const cyclePath = await findCycle(fromKind, fromId, toKind, toId);
  if (cyclePath) throw { code: 'CYCLE', path: cyclePath };
  await pool.query(
    `INSERT INTO dependencies (from_kind, from_id, to_kind, to_id)
     VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING`,
    [fromKind, fromId, toKind, toId]
  );
  return { from_kind: fromKind, from_id: Number(fromId), to_kind: toKind, to_id: Number(toId) };
}


async function removeDependency(fromKind, fromId, toKind, toId) {
  const { rowCount } = await pool.query(
    `DELETE FROM dependencies
      WHERE from_kind = $1 AND from_id = $2 AND to_kind = $3 AND to_id = $4`,
    [fromKind, fromId, toKind, toId]
  );
  return rowCount > 0;
}

// Edges for a node. reverse=false: what (kind,id) depends on; reverse=true: what
// depends on (kind,id).

async function getDependencies(kind, id, { reverse = false } = {}) {
  const selfKind = reverse ? 'to_kind' : 'from_kind';
  const selfId = reverse ? 'to_id' : 'from_id';
  const { rows } = await pool.query(
    `SELECT from_kind, from_id, to_kind, to_id, created_at
       FROM dependencies
      WHERE ${selfKind} = $1 AND ${selfId} = $2
      ORDER BY from_kind, from_id, to_kind, to_id`,
    [kind, id]
  );
  return rows;
}

// ---------------------------------------------------------------------------
// Task ↔ criterion links (task_criteria, migration 055 / ADR 0025; populated on
// task-create + manage endpoints by task 438). Mirrors the task_dependencies
// CRUD above. A criterion "ref" is either a numeric done_when_criteria.id, a
// positional "Cn" token (C1 = the version's first criterion by
// (sort_order, criterion_id) — the SAME ordering the #435 backfill +
// done-when.criterionProgress use), or a criterion_id slug. resolveCriterionIds
// maps refs to numeric ids SCOPED to a version, so "C8" is unambiguous and a
// numeric id from another version doesn't resolve.
// ---------------------------------------------------------------------------

// PURE: classify a single criterion ref. Returns { kind:'cnum', n } |
// { kind:'id', id } | { kind:'slug', slug }. Exported for unit tests (no DB).
// A leading C/c + digits is positional; bare digits are a numeric id; anything
// else is treated as a criterion_id slug.

function parseCriterionRef(raw) {
  const ref = String(raw == null ? '' : raw).trim();
  const cMatch = /^C(\d+)$/i.exec(ref);
  if (cMatch) return { kind: 'cnum', n: Number(cMatch[1]) };
  if (/^\d+$/.test(ref)) return { kind: 'id', id: Number(ref) };
  return { kind: 'slug', slug: ref };
}

// Resolve an array of refs to done_when_criteria.id values within a version.
// Returns { ids: [unique numeric ids, first-appearance order], unresolved: [refs] }.

async function resolveCriterionIds(versionId, refs) {
  const ids = [];
  const unresolved = [];
  if (!Array.isArray(refs) || refs.length === 0) return { ids, unresolved };
  const { rows } = await pool.query(
    `SELECT id, criterion_id,
            ROW_NUMBER() OVER (ORDER BY sort_order, criterion_id) AS cnum
       FROM done_when_criteria
      WHERE version_id = $1`,
    [versionId]
  );
  const byId = new Set(rows.map((r) => Number(r.id)));
  const byCnum = new Map(rows.map((r) => [Number(r.cnum), Number(r.id)]));
  const bySlug = new Map(rows.map((r) => [String(r.criterion_id), Number(r.id)]));
  const seen = new Set();
  for (const raw of refs) {
    const p = parseCriterionRef(raw);
    let id = null;
    if (p.kind === 'cnum') id = byCnum.get(p.n) ?? null;
    else if (p.kind === 'id') id = byId.has(p.id) ? p.id : null;
    else id = bySlug.get(p.slug) ?? null;
    if (id == null) { unresolved.push(String(raw).trim()); continue; }
    if (!seen.has(id)) { seen.add(id); ids.push(id); }
  }
  return { ids, unresolved };
}

// Read the criteria linked to a task, with the live "Cn" position + link source.

async function getTaskCriteria(taskId) {
  const { rows } = await pool.query(
    `WITH ranked AS (
       SELECT id, version_id, criterion_id, criterion_md,
              ROW_NUMBER() OVER (PARTITION BY version_id ORDER BY sort_order, criterion_id) AS cnum
         FROM done_when_criteria
     )
     SELECT r.id, r.criterion_id, r.criterion_md, r.cnum, tc.source, tc.created_at
       FROM task_criteria tc
       JOIN ranked r ON r.id = tc.criterion_id
      WHERE tc.task_id = $1
      ORDER BY r.cnum`,
    [taskId]
  );
  return rows;
}

// Link one task to one criterion. Validates both exist AND share a version (a
// task can only gate its OWN version's criteria). Idempotent (ON CONFLICT DO
// NOTHING). Throws { code } the route maps: TASK_NOT_FOUND | CRITERION_NOT_FOUND
// | CRITERION_VERSION_MISMATCH.

async function addTaskCriterion(taskId, criterionId, source = 'manual') {
  const { rows: tRows } = await pool.query(`SELECT version_id FROM tasks WHERE id = $1`, [taskId]);
  if (tRows.length === 0) throw { code: 'TASK_NOT_FOUND' };
  const { rows: cRows } = await pool.query(`SELECT version_id FROM done_when_criteria WHERE id = $1`, [criterionId]);
  if (cRows.length === 0) throw { code: 'CRITERION_NOT_FOUND' };
  if (cRows[0].version_id !== tRows[0].version_id) {
    throw { code: 'CRITERION_VERSION_MISMATCH', taskVersion: tRows[0].version_id, criterionVersion: cRows[0].version_id };
  }
  const safeSource = ['manual', 'planning', 'backfill'].includes(source) ? source : 'manual';
  await pool.query(
    `INSERT INTO task_criteria (task_id, criterion_id, source)
     VALUES ($1, $2, $3)
     ON CONFLICT DO NOTHING`,
    [taskId, criterionId, safeSource]
  );
  return { task_id: taskId, criterion_id: criterionId, source: safeSource };
}


async function removeTaskCriterion(taskId, criterionId) {
  const { rowCount } = await pool.query(
    `DELETE FROM task_criteria WHERE task_id = $1 AND criterion_id = $2`,
    [taskId, criterionId]
  );
  return rowCount > 0;
}

// Link many already-resolved criterion ids at create-time (default source
// 'planning'). Assumes resolveCriterionIds already version-checked them, so this
// is one idempotent batch insert. Returns the count inserted.

async function linkTaskCriteria(taskId, criterionIds, source = 'planning') {
  const ids = [...new Set((criterionIds || []).map(Number).filter(Number.isFinite))];
  if (ids.length === 0) return 0;
  const safeSource = ['manual', 'planning', 'backfill'].includes(source) ? source : 'planning';
  const { rowCount } = await pool.query(
    `INSERT INTO task_criteria (task_id, criterion_id, source)
     SELECT $1, c, $3 FROM unnest($2::bigint[]) AS c
     ON CONFLICT DO NOTHING`,
    [taskId, ids, safeSource]
  );
  return rowCount;
}

// The claim gate's resolution point (task 1516 / ADR 0086 §5). Returns every
// dependency of taskId that is NOT yet "done", resolving the task's OWN edges plus
// edges INHERITED from its goal (tasks.goal_id) and the criteria it fulfils
// (task_criteria). "Done": task shipped | criterion satisfied | goal achieved. Each
// unmet row is { kind, id, title, state }. An orphaned `to` (no FK; row deleted)
// yields no JOIN match and is silently absent — the promotion predicate treats such
// an edge as un-done, so it can never accidentally unblock a task. A task with only
// task->task edges resolves identically to the pre-1516 task-only gate.

async function unsatisfiedDeps(taskId, client = pool) {
  const { rows } = await client.query(
    `WITH gating AS (
       SELECT d.to_kind, d.to_id
         FROM dependencies d
         JOIN tasks t ON t.id = $1
        WHERE (d.from_kind = 'task'      AND d.from_id = t.id)
           OR (d.from_kind = 'goal'      AND d.from_id = t.goal_id)
           OR (d.from_kind = 'criterion' AND d.from_id IN (
                 SELECT tc.criterion_id FROM task_criteria tc WHERE tc.task_id = t.id))
     )
     SELECT 'task' AS kind, x.id, x.title, x.status::text AS state
       FROM gating g JOIN tasks x ON g.to_kind = 'task' AND x.id = g.to_id
      WHERE x.status <> 'shipped'
     UNION ALL
     SELECT 'criterion' AS kind, x.id, x.criterion_md AS title,
            (CASE WHEN x.satisfied THEN 'satisfied' ELSE 'unsatisfied' END) AS state
       FROM gating g JOIN done_when_criteria x ON g.to_kind = 'criterion' AND x.id = g.to_id
      WHERE x.satisfied = false
     UNION ALL
     SELECT 'goal' AS kind, x.id, x.title, x.status::text AS state
       FROM gating g JOIN goals x ON g.to_kind = 'goal' AND x.id = g.to_id
      WHERE x.status <> 'achieved'`,
    [taskId]
  );
  return rows;
}

// -------------------------------------------------------------------------
// Claims (atomic)
// -------------------------------------------------------------------------

// Tries to atomically claim a task. Returns the claim row on success.
// Throws { code: 'ALREADY_CLAIMED' } if another builder beat us to it.
// Throws { code: 'TASK_NOT_READY' } if the task isn't in 'ready'.
// Throws { code: 'TOUCHES_CONFLICT' } if a different active claim has
// overlapping touches[] (caught BEFORE the unique-violation, so we
// give a useful error rather than a generic constraint failure).

async function claimTask({ taskId, builderId, worktreeName, headSha, creatorSessionId, enforceOverlap = false }) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // V3.R88 (#307): a deactivated builder cannot claim new work. Their
    // history is preserved, but they're out of the active rotation until an
    // Archon reactivates them.
    const { rows: builderRows } = await client.query(
      `SELECT status, rank FROM builders WHERE id = $1`,
      [builderId]
    );
    if (builderRows[0] && builderRows[0].status === 'inactive') {
      throw { code: 'BUILDER_INACTIVE' };
    }
    const builderRank = builderRows[0] ? builderRows[0].rank : null;

    const { rows: taskRows } = await client.query(
      `SELECT id, status, touches, newcomer_friendly, requires_rank, needs_migration, module_key, credits_reward, reward_gate_exempt, est_minutes, kind FROM tasks WHERE id = $1 FOR UPDATE`,
      [taskId]
    );
    if (taskRows.length === 0) {
      throw { code: 'TASK_NOT_FOUND' };
    }
    const task = taskRows[0];
    if (task.status !== 'ready') {
      throw { code: 'TASK_NOT_READY', currentStatus: task.status };
    }

    // Three-rank model (task #360 / ADR 0018; V3.R15 #239): a Xenos is the
    // sandboxed entry rank and may claim ONLY tasks explicitly opened to them
    // (newcomer_friendly). Metic+ (the approved working rank) and Archon claim
    // any ready task. This is the server-enforced half of C2's "Xenos ships
    // only explicitly-tagged-open tasks" — markdown describes it, this check
    // enforces it. Error code is rank_too_low_for_task (V3.R15); XENOS_RESTRICTED
    // is kept as an alias on the error object for callers on the pre-rename
    // release.
    if (!xenosClaimAllowed(builderRank, task.newcomer_friendly)) {
      throw { code: 'rank_too_low_for_task', legacy_code: 'XENOS_RESTRICTED' };
    }

    // V3.R82 (#301): the inverse gate — a task can RAISE its minimum required
    // rank above the default. requires_rank='metic' blocks Xenos; 'archon'
    // blocks Xenos+Metic. The DB CHECK on tasks.requires_rank enforces the
    // enum, so we trust the value here. INSUFFICIENT_RANK carries the actual
    // and required ranks so the caller can render a clean error.
    if (!rankAllowsTask(builderRank, task.requires_rank)) {
      throw {
        code: 'INSUFFICIENT_RANK',
        required: task.requires_rank,
        actual: builderRank,
      };
    }

    // The claim gate (ADR 0015, generalized in task 1516 / ADR 0086 §5): a task
    // can't be claimed while any dependency is un-done — its OWN edges plus those
    // inherited from its goal/criteria, where "done" = task shipped | criterion
    // satisfied | goal achieved. The auto-promotion triggers keep backlog tasks
    // gated, but a manually-promoted task could end up 'ready' with pending deps —
    // this is the second line of defence. Wire code stays DEPS_NOT_SHIPPED.
    const unmetDeps = await unsatisfiedDeps(taskId, client);
    if (unmetDeps.length > 0) {
      throw {
        code: 'DEPS_NOT_SHIPPED',
        deps: unmetDeps.map((r) => ({ kind: r.kind, id: r.id, title: r.title, status: r.state })),
      };
    }

    // task 1670 / ADR 0096 + task 1673 amendment: the reward backstop now
    // AUTO-ASSIGNS instead of blocking. No task ships paying 0 drachmae — but a
    // claim is never REFUSED for it. If credits_reward is 0/NULL at claim time
    // (a backlog task that auto-promoted before 178, a manually-flipped 'ready'
    // row, a reward zeroed after promotion, or one of the ~27 grandfathered
    // reward_gate_exempt tasks), assign the capped suggestion HERE — inside this
    // same FOR UPDATE transaction, so the value is set and the claim commit
    // together atomically. AUDIT: a log line + the visible credits_reward change.
    const rewardAssign = rewardGateAssignment(task);
    if (rewardAssign) {
      await client.query(
        `UPDATE tasks SET credits_reward = $1, updated_at = now() WHERE id = $2`,
        [rewardAssign.assign, taskId]
      );
      task.credits_reward = rewardAssign.assign;
      console.log(`[reward-gate] AUTO-ASSIGN task ${taskId} credits_reward -> ${rewardAssign.assign} (cap ${REWARD_SUGGESTION_CAP}) [claim by builder ${builderId}]`);
    }

    let overlapWarning = null;
    // touches[] cleanup [5/8] (task 880): prefix-aware overlap vs every OTHER
    // active claim, computed in JS with the canonical matcher. The old SQL `&&`
    // only caught exact-element overlap, so ['src/bongos/'] and ['src/bongos/db.js']
    // slipped past it. Active claims are bounded by the number of concurrent
    // builders, so fetching their touches and comparing in JS is cheap.
    //
    // The result is ADVISORY by default (ADR 0017: a hard 409 turned correct,
    // mergeable work into deferred backlog — git merge is the real collision
    // detector). It becomes a HARD precondition only when enforceOverlap=true,
    // which the autonomous --parallel runner sets: there, two same-footprint
    // tasks fanned into concurrent unsupervised agents could semantically
    // clobber each other in ways git won't flag (parallel_safe covers non-file
    // hazards, not file adjacency).
    const { rows: activeClaimRows } = await client.query(
      `SELECT c.id, t.id AS task_id, t.title, t.touches, t.module_key FROM claims c
         JOIN tasks t ON t.id = c.task_id
        WHERE c.released_at IS NULL AND t.id <> $1`,
      [taskId]
    );
    // BV1.R53 (task 1422): module-disjointness is a HARD gate (not advisory) when
    // both tasks carry a module_key. Two tasks in the same module are always a
    // semantic conflict — their work inherently overlaps regardless of which files
    // they predict. Two tasks in DIFFERENT modules are always safe (file-path
    // overlap between modules is a fitness-function violation, not a runtime
    // concern). module_key disjointness supersedes the touches[] check for
    // module-keyed tasks and is never advisory.
    if (task.module_key) {
      const sameModuleConflicts = activeClaimRows.filter((r) => r.module_key === task.module_key);
      if (sameModuleConflicts.length > 0) {
        throw {
          code: 'MODULE_CONFLICT',
          module_key: task.module_key,
          conflictTaskTitles: sameModuleConflicts.map((r) => r.title),
        };
      }
    }
    // touches[] overlap check applies only when module_key is absent on either side.
    const overlapping = activeClaimRows.filter(
      (r) => !(task.module_key && r.module_key) && touchesOverlap(task.touches, r.touches)
    );
    if (overlapping.length > 0) {
      const titles = overlapping.map((r) => r.title);
      if (enforceOverlap) {
        throw { code: 'TOUCHES_CONFLICT', conflictTaskTitles: titles };
      }
      overlapWarning = titles;
    }

    // Pre-allocate a migration number if the task signals it'll add one.
    // Trigger: the tasks.needs_migration boolean (migration 081, touches[]
    // cleanup [1/8] / task 876). Replaced the old touches[]-contains-'migrations/'
    // string sentinel so allocation no longer rides on a drifting path array.
    let reservedMigrationNumber = null;
    if (task.needs_migration === true) {
      const { rows: bumpRows } = await client.query(
        `UPDATE migration_counter
            SET next_number = next_number + 1
          WHERE id = 1
          RETURNING next_number - 1 AS allocated`
      );
      reservedMigrationNumber = bumpRows[0].allocated;
    }

    // V3.R51 (#270): server-side worktree_name uniqueness across ACTIVE claims.
    // `released_at IS NULL` is exactly the active set (same predicate as the
    // touches-conflict check above and uniq_active_claim_per_task). A name freed
    // by a resolved claim won't appear here, so it's reused without a suffix —
    // which is what the overnight builder relies on. We hold FOR UPDATE on the
    // task row already; reading the active names inside the same txn is good
    // enough for the disambiguation to be stable for this insert.
    let finalWorktreeName = worktreeName ?? null;
    if (finalWorktreeName) {
      const { rows: activeNameRows } = await client.query(
        `SELECT worktree_name FROM claims
          WHERE released_at IS NULL AND worktree_name IS NOT NULL`
      );
      const taken = new Set(activeNameRows.map((r) => r.worktree_name));
      finalWorktreeName = disambiguateWorktreeName(finalWorktreeName, taken);
    }

    const insertClaim = await client.query(
      `INSERT INTO claims (task_id, builder_id, worktree_name, head_sha, reserved_migration_number, creator_session_id)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, task_id, builder_id, worktree_name, claimed_at, head_sha, reserved_migration_number`,
      [taskId, builderId, finalWorktreeName, headSha ?? null, reservedMigrationNumber, creatorSessionId ?? null]
    );

    await client.query(`UPDATE tasks SET status = 'active' WHERE id = $1`, [taskId]);

    // Gamification carved to modules/economy/ (BV1.R77 / ADR 0093 §1-2): resolve
    // the `reward` kernel port and fire the claim hook inside this same txn.
    const justUnlocked = await seams.resolveOptional('reward').evaluateAfterClaim(
      client, builderId, insertClaim.rows[0].id
    );

    // V3.R75 (#294): tick the onboarding state machine for first_claim. Done
    // inside the same transaction so the claim and onboarding write commit
    // together. Wrapped in try/catch so an onboarding-table issue can't
    // block a legitimate claim. The onboarding state machine carved into
    // modules/onboarding/ (BV1.R81 / ADR 0093 §1): resolve the `onboarding`
    // kernel port and pass this txn `client` — never a direct require of a
    // module. Default-on, so present in prod; the ?. degrades to a no-op (the
    // state tick is best-effort anyway) when the module is off.
    let graduationBuilder = null;
    try {
      const onboarding = seams.resolveOptional('onboarding');
      const result = onboarding && await onboarding.markStage(client, builderId, 'first_claim');
      if (result && result.justGraduated) {
        const { rows: br } = await client.query(
          `SELECT id, display_name, github_login FROM builders WHERE id = $1`,
          [builderId]
        );
        graduationBuilder = br[0] || null;
      }
    } catch (e) {
      console.log('[gds] claimTask onboarding markStage failed (non-blocking):', e && e.message);
    }

    await client.query('COMMIT');
    if (graduationBuilder) {
      try {
        seams.resolveOptional('onboarding')?.broadcastGraduation(graduationBuilder);
      } catch (e) {
        console.log('[gds] graduation broadcast post-claim failed:', e && e.message);
      }
    }
    return { ...insertClaim.rows[0], just_unlocked: justUnlocked, overlap_warning: overlapWarning };
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    if (err && err.code === '23505') {
      // unique_violation on uniq_active_claim_per_task — race lost
      throw { code: 'ALREADY_CLAIMED' };
    }
    throw err;
  } finally {
    client.release();
  }
}

// Atomically claim N tasks in a single transaction. All-or-nothing.
//
// Mirrors claimTask's semantics for each task in the batch but runs inside ONE
// BEGIN/COMMIT, so a partial failure (any one task being unready / already
// claimed / touches-conflicting) rolls back the whole batch. The caller is
// never left holding a half-acquired set.
//
// Additional check beyond the single-claim path: inter-batch touches conflict.
// Within the requested set, no two tasks may have overlapping touches[]. The
// optimizer should already filter these on the way in, but the server
// re-validates so a stale client can't sneak through.
//
// On failure, throws { code: 'BATCH_FAILED', failures: [{ task_id, reason }] }.
// Reasons mirror the single-claim error codes (TASK_NOT_FOUND, TASK_NOT_READY,
// TOUCHES_CONFLICT, ALREADY_CLAIMED) plus 'BATCH_TOUCHES_CONFLICT' for
// intra-batch overlap.

async function claimTasksBatch({ taskIds, builderId, worktreePrefix, creatorSessionId }) {
  if (!Array.isArray(taskIds) || taskIds.length === 0) {
    throw { code: 'BATCH_EMPTY' };
  }
  const uniqIds = Array.from(new Set(taskIds.map(Number)));
  if (uniqIds.length !== taskIds.length) {
    throw { code: 'BATCH_DUPLICATE_IDS' };
  }
  // Stable-sort the IDs before SELECT FOR UPDATE so two concurrent batches
  // sharing any rows can't deadlock by locking in opposite orders.
  uniqIds.sort((a, b) => a - b);

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // V3.R88 (#307): a deactivated builder can't batch-claim either.
    const { rows: builderRows } = await client.query(
      `SELECT status, rank FROM builders WHERE id = $1`,
      [builderId]
    );
    if (builderRows[0] && builderRows[0].status === 'inactive') {
      throw { code: 'BUILDER_INACTIVE' };
    }
    const builderRank = builderRows[0] ? builderRows[0].rank : null;

    // Lock every requested task row up front (sorted to avoid deadlocks).
    const { rows: taskRows } = await client.query(
      `SELECT id, status, touches, newcomer_friendly, requires_rank, needs_migration, module_key FROM tasks WHERE id = ANY($1::bigint[]) ORDER BY id FOR UPDATE`,
      [uniqIds]
    );

    const failures = [];
    // node-pg returns bigint/bigserial columns (tasks.id) as JS STRINGS, not
    // numbers (learning #94) — Number() them before comparing against uniqIds
    // (which are already numbers). Without this, foundIds.has(requestedId)
    // never matches ("1781" !== 1781) and EVERY requested id is wrongly
    // reported TASK_NOT_FOUND, even ones the SELECT above found fine.
    const foundIds = new Set(taskRows.map((r) => Number(r.id)));
    for (const requestedId of uniqIds) {
      if (!foundIds.has(requestedId)) {
        failures.push({ task_id: requestedId, reason: 'TASK_NOT_FOUND' });
      }
    }
    for (const t of taskRows) {
      if (t.status !== 'ready') {
        failures.push({ task_id: t.id, reason: 'TASK_NOT_READY', currentStatus: t.status });
      }
    }

    // Three-rank model (task #360 / ADR 0018; V3.R15 #239): a Xenos may
    // batch-claim only tasks explicitly opened to them (newcomer_friendly).
    // Mirrors the single claimTask gate so the batch path can't be used to
    // sidestep the sandbox. Failure reason carries both names — the new
    // canonical code and the legacy alias — so callers on either release work.
    if (builderRank === 'xenos') {
      for (const t of taskRows) {
        if (!xenosClaimAllowed(builderRank, t.newcomer_friendly)) {
          failures.push({ task_id: t.id, reason: 'rank_too_low_for_task', legacy_reason: 'XENOS_RESTRICTED' });
        }
      }
    }

    // V3.R82 (#301): the per-task requires_rank floor. Mirrors the single
    // claimTask gate so a Metic can't slip through batch-claim to grab an
    // Archon-only task. The xenos sandbox check above handles the xenos case
    // exhaustively for requires_rank='xenos' (the default); this gate refuses
    // requires_rank='metic'/'archon' when the builder is below.
    for (const t of taskRows) {
      if (!rankAllowsTask(builderRank, t.requires_rank)) {
        failures.push({
          task_id: t.id,
          reason: 'INSUFFICIENT_RANK',
          required: t.requires_rank,
          actual: builderRank,
        });
      }
    }

    // Per-task dependency check (ADR 0015, generalized task 1516). An EXTERNAL dep
    // (not in this batch) must already be done; a batch-internal dep isn't done yet
    // at claim time but doesn't block — the batch is worked serially. "Internal"
    // applies ONLY to task-kind deps: a goal/criterion dep can never be a task id in
    // the batch, so it is always external (must not be filtered out).
    const batchIdSet = new Set(uniqIds);
    for (const t of taskRows) {
      const unmet = await unsatisfiedDeps(t.id, client);
      const external = unmet.filter((d) => !(d.kind === 'task' && batchIdSet.has(Number(d.id))));
      if (external.length > 0) {
        failures.push({
          task_id: t.id,
          reason: 'DEPS_NOT_SHIPPED',
          deps: external.map((d) => ({ kind: d.kind, id: d.id, title: d.title, status: d.state })),
        });
      }
    }

    // BV1.R53 (task 1422): module-disjointness within the batch — two tasks in
    // the same module are a hard conflict (batch is the autonomous --parallel
    // path; module-disjointness is always enforced there).
    for (let i = 0; i < taskRows.length; i++) {
      for (let j = i + 1; j < taskRows.length; j++) {
        const a = taskRows[i];
        const b = taskRows[j];
        if (a.module_key && b.module_key && a.module_key === b.module_key) {
          failures.push({
            task_id: b.id,
            reason: 'MODULE_CONFLICT',
            module_key: a.module_key,
            conflictsWithTaskId: a.id,
          });
        }
      }
    }

    // touches[] cleanup [5/8] (task 880): inter-batch overlap via the canonical
    // prefix-aware matcher (was JS Set-equality, which missed dir-prefix
    // adjacency like ['src/bongos/'] vs ['src/bongos/db.js']). Batch claims are the
    // autonomous --parallel path, so the overlap gate stays HARD here.
    // Skip the touches check for pairs where both tasks have module_key set —
    // module-disjointness already covers them (either same-module = conflict above,
    // or different-module = always safe regardless of predicted file paths).
    for (let i = 0; i < taskRows.length; i++) {
      for (let j = i + 1; j < taskRows.length; j++) {
        const a = taskRows[i];
        const b = taskRows[j];
        if (a.module_key && b.module_key) continue; // module-disjointness handled above
        if (touchesOverlap(a.touches, b.touches)) {
          failures.push({
            task_id: b.id,
            reason: 'BATCH_TOUCHES_CONFLICT',
            conflictsWithTaskId: a.id,
          });
        }
      }
    }

    // Touches conflict against OTHER builders' active claims (prefix-aware).
    // Fetch every active claim's touches (can't SQL-prefilter with `&&` — that
    // would miss dir-prefix adjacency) and compare with the canonical matcher.
    const { rows: activeClaims } = await client.query(
      `SELECT c.id AS claim_id, c.task_id AS conflict_task_id, t.title, t.touches, t.module_key
         FROM claims c
         JOIN tasks t ON t.id = c.task_id
        WHERE c.released_at IS NULL
          AND t.id <> ALL($1::bigint[])`,
      [uniqIds]
    );
    for (const t of taskRows) {
      // BV1.R53: module-disjointness against other builders' active claims.
      if (t.module_key) {
        for (const cr of activeClaims) {
          if (cr.module_key === t.module_key) {
            failures.push({
              task_id: t.id,
              reason: 'MODULE_CONFLICT',
              module_key: t.module_key,
              conflictTaskTitle: cr.title,
              conflictClaimId: cr.claim_id,
            });
          }
        }
      }
      for (const cr of activeClaims) {
        if (t.module_key && cr.module_key) continue; // both have module_key → handled above
        if (touchesOverlap(t.touches, cr.touches)) {
          failures.push({
            task_id: t.id,
            reason: 'TOUCHES_CONFLICT',
            conflictTaskTitle: cr.title,
            conflictClaimId: cr.claim_id,
          });
        }
      }
    }

    if (failures.length > 0) {
      throw { code: 'BATCH_FAILED', failures };
    }

    // All checks passed. Insert N claim rows, allocating per-task migration
    // numbers if the touches[] signals it. The unique-violation safety net is
    // still here: if another batch beat us to a row between our SELECT FOR
    // UPDATE and INSERT (it can't, given the row lock, but defense in depth),
    // we surface that as ALREADY_CLAIMED for the specific task.
    //
    // task 1802 — uniq_active_claim_per_session (migration 180) is keyed on
    // creator_session_id alone, so it can't tell "N rows from one batch call"
    // from "N rows from N separate /claims calls": every row here used to carry
    // the SAME non-null creatorSessionId for a real (bound) CLI session, so the
    // 2nd INSERT always hit the partial unique index. Each batch-claimed task
    // also gets its OWN worktree name (worktreePrefix-taskId, right below) — a
    // batch is claiming N tasks for N future (possibly parallel) working
    // sessions, not one shared worktree — so there is no correctness reason to
    // bind every row to the session that placed the batch call. Bind only the
    // FIRST row (preserves today's exact behavior for the common size-1 batch,
    // and keeps this session's own "at most one BOUND active claim" invariant
    // intact); every later row in the batch is inserted session-unbound
    // (creator_session_id=NULL), same as a bind_session:false web claim —
    // adoptable by any of the builder's own CLI sessions when they pick it up.
    const inserted = [];
    for (let i = 0; i < taskRows.length; i++) {
      const t = taskRows[i];
      let reservedMigrationNumber = null;
      if (t.needs_migration === true) {
        const { rows: bumpRows } = await client.query(
          `UPDATE migration_counter
              SET next_number = next_number + 1
            WHERE id = 1
            RETURNING next_number - 1 AS allocated`
        );
        reservedMigrationNumber = bumpRows[0].allocated;
      }
      const worktreeName = worktreePrefix
        ? `${worktreePrefix}-${t.id}`
        : null;
      const rowCreatorSessionId = i === 0 ? (creatorSessionId ?? null) : null;
      try {
        const insertClaim = await client.query(
          `INSERT INTO claims (task_id, builder_id, worktree_name, head_sha, reserved_migration_number, creator_session_id)
           VALUES ($1, $2, $3, NULL, $4, $5)
           RETURNING id, task_id, builder_id, worktree_name, claimed_at, head_sha, reserved_migration_number`,
          [t.id, builderId, worktreeName, reservedMigrationNumber, rowCreatorSessionId]
        );
        inserted.push(insertClaim.rows[0]);
      } catch (err) {
        if (err && err.code === '23505') {
          throw { code: 'BATCH_FAILED', failures: [{ task_id: t.id, reason: 'ALREADY_CLAIMED' }] };
        }
        throw err;
      }
      await client.query(`UPDATE tasks SET status = 'active' WHERE id = $1`, [t.id]);
    }

    await client.query('COMMIT');
    return { claims: inserted };
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

// Bulk release (task 1758): release N of the caller's OWN claims in one call —
// the batch twin of the single-claim resolve(outcome='abandoned') path
// (release.js / the work board's doRelease both use that path; this is the
// same effect, N at a time). Unlike claimTasksBatch, this is NOT all-or-nothing:
// a release has no cross-claim invariant to protect (no touches/module/
// dependency check makes sense between two claims being given back), so each
// claim_id stands alone. One bad id (not found, not yours, already resolved,
// session-locked) fails ONLY that item — every other valid id in the batch
// still releases. Mirrors resolveClaim's per-claim effects (released_at +
// outcome, task → 'ready', sealSessionLog, actual_minutes recompute) and
// releaseClaimOnBehalf's row-locked batch-read shape.
async function releaseClaimsBatch({ claimIds, builderId, resolverSessionId, force }) {
  if (!Array.isArray(claimIds) || claimIds.length === 0) {
    throw { code: 'BATCH_EMPTY' };
  }
  // Stable-sort before locking so two concurrent batches sharing a row can't
  // deadlock by locking in opposite orders (claimTasksBatch precedent).
  const uniqIds = Array.from(new Set(claimIds.map(Number))).sort((a, b) => a - b);

  return withTx(async (client) => {
    const { rows: claimRows } = await client.query(
      `SELECT c.id, c.task_id, c.builder_id, c.released_at, c.claimed_at,
              c.worktree_name, c.creator_session_id, t.title
         FROM claims c JOIN tasks t ON t.id = c.task_id
        WHERE c.id = ANY($1::bigint[]) FOR UPDATE`,
      [uniqIds]
    );
    // node-pg returns claims.id (bigserial) as a STRING (learning #94) — Number()
    // it so lookups below (byId.get(claimId), claimId from uniqIds) actually hit.
    const byId = new Map(claimRows.map((r) => [Number(r.id), r]));

    const released = [];
    const failures = [];
    for (const claimId of uniqIds) {
      const claim = byId.get(claimId);
      if (!claim) { failures.push({ claim_id: claimId, reason: 'CLAIM_NOT_FOUND' }); continue; }
      if (claim.builder_id !== builderId) { failures.push({ claim_id: claimId, reason: 'NOT_YOUR_CLAIM' }); continue; }
      if (claim.released_at) { failures.push({ claim_id: claimId, reason: 'ALREADY_RESOLVED' }); continue; }
      if (!force && claim.creator_session_id && resolverSessionId &&
          claim.creator_session_id !== resolverSessionId) {
        failures.push({ claim_id: claimId, reason: 'CLAIM_SESSION_MISMATCH', claimWorktree: claim.worktree_name ?? null });
        continue;
      }

      await client.query(
        `UPDATE claims SET released_at = now(), outcome = 'abandoned' WHERE id = $1`,
        [claimId]
      );
      await client.query(
        `UPDATE tasks SET status = 'ready', updated_at = now() WHERE id = $1`,
        [claim.task_id]
      );
      await sealSessionLog(client, {
        builderId, taskId: claim.task_id, claimId, startedAt: claim.claimed_at,
        outcome: 'abandoned', notesMd: null,
      });
      await client.query(
        `UPDATE tasks
            SET actual_minutes = (
              SELECT COALESCE(SUM(EXTRACT(EPOCH FROM (ended_at - started_at)) / 60)::integer, 0)
              FROM session_logs WHERE task_id = $1
            )
          WHERE id = $1`,
        [claim.task_id]
      );
      released.push({ claim_id: claimId, task_id: claim.task_id, task_title: claim.title });
    }

    return { released, failures };
  });
}

// Read-only dry-run twin of claimTasksBatch's pre-flight checks (task 1758).
// Validates an arbitrary task_id set for parallel-safety + sequencing WITHOUT
// claiming anything — no row lock, no write — so the hall's multi-select
// toolbar can grey out invalid actions before a real claim. Mirrors
// claimTasksBatch's checks (rank, dependencies, module-disjointness, touches
// overlap — both within the set and against other builders' active claims)
// but collects EVERY failure per task instead of stopping at the first one.
// Keep the check set in sync with claimTasksBatch if either changes.
async function validateClaimBatch({ taskIds, builderId }) {
  if (!Array.isArray(taskIds) || taskIds.length === 0) {
    throw { code: 'BATCH_EMPTY' };
  }
  const uniqIds = Array.from(new Set(taskIds.map(Number)));

  const { rows: builderRows } = await pool.query(
    `SELECT status, rank FROM builders WHERE id = $1`,
    [builderId]
  );
  const builderInactive = builderRows[0] ? builderRows[0].status === 'inactive' : false;
  const builderRank = builderRows[0] ? builderRows[0].rank : null;

  const { rows: taskRows } = await pool.query(
    `SELECT id, status, touches, newcomer_friendly, requires_rank, module_key
       FROM tasks WHERE id = ANY($1::bigint[])`,
    [uniqIds]
  );
  // node-pg returns tasks.id (bigserial) as a STRING (learning #94) — Number()
  // it so lookups below (byId.get(id), id from uniqIds) actually hit.
  const byId = new Map(taskRows.map((r) => [Number(r.id), r]));

  // Other builders' active claims — for the cross-batch touches/module check,
  // same query shape as claimTasksBatch.
  const { rows: activeClaims } = await pool.query(
    `SELECT c.id AS claim_id, t.title, t.touches, t.module_key
       FROM claims c JOIN tasks t ON t.id = c.task_id
      WHERE c.released_at IS NULL AND t.id <> ALL($1::bigint[])`,
    [uniqIds]
  );

  const reasonsById = new Map(uniqIds.map((id) => [id, []]));
  const push = (id, reason) => reasonsById.get(id).push(reason);

  for (const id of uniqIds) {
    if (builderInactive) push(id, { reason: 'BUILDER_INACTIVE' });
    const t = byId.get(id);
    if (!t) { push(id, { reason: 'TASK_NOT_FOUND' }); continue; }
    if (t.status !== 'ready') push(id, { reason: 'TASK_NOT_READY', currentStatus: t.status });
    if (builderRank === 'xenos' && !xenosClaimAllowed(builderRank, t.newcomer_friendly)) {
      push(id, { reason: 'rank_too_low_for_task', legacy_reason: 'XENOS_RESTRICTED' });
    }
    if (!rankAllowsTask(builderRank, t.requires_rank)) {
      push(id, { reason: 'INSUFFICIENT_RANK', required: t.requires_rank, actual: builderRank });
    }
  }

  // Dependencies — external to the batch only (a batch-internal dep is fine;
  // the batch is worked serially, same rule as claimTasksBatch).
  const batchIdSet = new Set(uniqIds);
  for (const id of uniqIds) {
    if (!byId.get(id)) continue;
    const unmet = await unsatisfiedDeps(id);
    const external = unmet.filter((d) => !(d.kind === 'task' && batchIdSet.has(Number(d.id))));
    if (external.length > 0) {
      push(id, {
        reason: 'DEPS_NOT_SHIPPED',
        deps: external.map((d) => ({ kind: d.kind, id: d.id, title: d.title, status: d.state })),
      });
    }
  }

  // Cross-task conflicts within the set — module-disjointness, then touches
  // overlap. Symmetric: a conflicting pair marks BOTH task_ids invalid for
  // PARALLEL (either can still run alone / sequentially after the other).
  for (let i = 0; i < uniqIds.length; i++) {
    const a = byId.get(uniqIds[i]);
    if (!a) continue;
    for (let j = i + 1; j < uniqIds.length; j++) {
      const b = byId.get(uniqIds[j]);
      if (!b) continue;
      if (a.module_key && b.module_key && a.module_key === b.module_key) {
        push(a.id, { reason: 'MODULE_CONFLICT', module_key: a.module_key, conflictsWithTaskId: b.id });
        push(b.id, { reason: 'MODULE_CONFLICT', module_key: a.module_key, conflictsWithTaskId: a.id });
        continue;
      }
      if (a.module_key && b.module_key) continue;
      if (touchesOverlap(a.touches, b.touches)) {
        push(a.id, { reason: 'BATCH_TOUCHES_CONFLICT', conflictsWithTaskId: b.id });
        push(b.id, { reason: 'BATCH_TOUCHES_CONFLICT', conflictsWithTaskId: a.id });
      }
    }
  }

  // Conflicts against OTHER builders' active claims (prefix-aware touches +
  // module-disjointness) — the check the client can't do on its own, since it
  // has no visibility into claims it doesn't hold.
  for (const id of uniqIds) {
    const t = byId.get(id);
    if (!t) continue;
    for (const cr of activeClaims) {
      if (t.module_key && cr.module_key === t.module_key) {
        push(id, { reason: 'MODULE_CONFLICT', module_key: t.module_key, conflictTaskTitle: cr.title, conflictClaimId: cr.claim_id });
        continue;
      }
      if (t.module_key && cr.module_key) continue;
      if (touchesOverlap(t.touches, cr.touches)) {
        push(id, { reason: 'TOUCHES_CONFLICT', conflictTaskTitle: cr.title, conflictClaimId: cr.claim_id });
      }
    }
  }

  const results = uniqIds.map((id) => {
    const reasons = reasonsById.get(id);
    return { task_id: id, valid: reasons.length === 0, reasons };
  });

  return { results, parallel_safe: results.every((r) => r.valid) };
}

// Resolve a claim. Three-state task lifecycle:
//   active → completed         (builder declared done; awaiting grader)
//   active → completed → confirmed   (promoted by applyGrade when the subagent
//                                      grader passes; credits land at confirmed)
//   active → ready             (abandoned or partial — back to the queue)
//
// Caller passes `verification` = { passed: bool, scanner_clean, smoke_clean,
// diff_stats, notes_md }. `passed` here is the LOCAL verification (scanner +
// smoke). It is no longer the credits gate — that's the subagent grader, applied
// in a separate call to applyGrade(). resolveClaim always lands the task at
// `completed` when passed=true; the caller is expected to invoke the grader and
// POST the result to /tasks/:id/grade (which calls applyGrade).
//
// Returns: { taskId, taskTitle, taskStatus, creditsAwarded, advanceToMerge,
//            justUnlocked, grade }. With the v2 subagent grader, resolveClaim
// itself never awards credits or advances to confirmed — those happen later
// via applyGrade. advanceToMerge is therefore always false and grade is null
// at resolveClaim time. Both keys stay in the response shape so existing
// callers (ship.js) don't break.

async function resolveClaim({ claimId, builderId, outcome, notesMd, valueSummary, verification, resolverSessionId, force, committedFiles = null, sandboxReview = null }) {
  return withTx(async (client) => {
    const { rows: claimRows } = await client.query(
      `SELECT c.id, c.task_id, c.builder_id, c.released_at, c.claimed_at,
              c.worktree_name, c.creator_session_id,
              t.credits_reward, t.title
         FROM claims c JOIN tasks t ON t.id = c.task_id
        WHERE c.id = $1 FOR UPDATE`,
      [claimId]
    );
    if (claimRows.length === 0) throw { code: 'CLAIM_NOT_FOUND' };
    const claim = claimRows[0];
    if (claim.builder_id !== builderId) throw { code: 'NOT_YOUR_CLAIM' };
    if (claim.released_at) throw { code: 'ALREADY_RESOLVED' };
    // Session lock: only the session that created this claim can resolve it.
    // Skipped when force=true (emergency), when the claim pre-dates this
    // migration (creator_session_id IS NULL), or when the resolver has no
    // session context (legacy path). This closes the cross-session release hole.
    if (!force && claim.creator_session_id && resolverSessionId &&
        claim.creator_session_id !== resolverSessionId) {
      throw { code: 'CLAIM_SESSION_MISMATCH', claimWorktree: claim.worktree_name ?? null };
    }

    await client.query(
      `UPDATE claims SET released_at = now(), outcome = $2 WHERE id = $1`,
      [claimId, outcome]
    );

    // Map outcome → task status under the new lifecycle.
    // 'shipped' from the CLI now means "builder declared done" → completed.
    // The CLI keeps the legacy outcome name to avoid an enum migration on
    // claims.outcome; the task-level status is what's gaining the new states.
    let newTaskStatus;
    if (outcome === 'shipped') newTaskStatus = 'completed';
    else if (outcome === 'abandoned') newTaskStatus = 'ready';
    else if (outcome === 'partial') newTaskStatus = 'ready';
    else newTaskStatus = 'ready';

    await client.query(
      `UPDATE tasks
          SET status = $2,
              value_summary = COALESCE($3, value_summary),
              updated_at = now()
        WHERE id = $1`,
      [claim.task_id, newTaskStatus, valueSummary ?? null]
    );

    // touches[] cleanup [7/8] (task 882): backfill touches[] from the REAL
    // committed diff at ship. The planning-time touches[] is now optional (a
    // prediction nobody has to get right up front); on a successful ship we
    // replace it with what git actually reports, so the declared set becomes
    // reality. This is the write path that makes the touches[]-keyed profile
    // counters (art_ships / pms_ships, see achievements + db leaderboard) and
    // the historical record diff-accurate — closing the loop left open in #878.
    // Only on a 'shipped' resolve with a non-empty list (never wipe touches[]
    // with an empty diff on a DB-only / no-op ship).
    if (outcome === 'shipped' && Array.isArray(committedFiles) && committedFiles.length > 0) {
      const cleaned = Array.from(
        new Set(committedFiles.map((p) => String(p || '').trim()).filter(Boolean))
      );
      if (cleaned.length > 0) {
        await client.query(
          `UPDATE tasks SET touches = $2, updated_at = now() WHERE id = $1`,
          [claim.task_id, cleaned]
        );
      }
    }

    // Task #1048 (ADR 0046 follow-up): record the builder's sandbox self-approval
    // as a durable fact on the task. When a dev-box builder reviews a staged
    // game change on their sandbox and approves shipping it (TTY 'y', or an
    // explicit --approved re-run on the dominant non-TTY path), ship.js threads
    // { stamp, url, method } through this resolve call. We stamp `by` + `at`
    // SERVER-SIDE (never trust the client for identity or time) and persist the
    // blob to tasks.sandbox_review. Only on a 'shipped' resolve carrying a
    // payload — laptop ships, non-game diffs, quick-tunnel boxes, --skip-stage,
    // and un-approved re-runs send nothing, leaving the column NULL.
    if (outcome === 'shipped' && sandboxReview && typeof sandboxReview === 'object' && sandboxReview.stamp) {
      // Sanitize the client-supplied fields (defense in depth): the builder's
      // box controls stamp/url/method, so clamp lengths, whitelist `method`, and
      // accept only an https:// URL. This keeps a forged/oversized value — or a
      // future stored-XSS string like a `javascript:` URL rendered in the hall —
      // out of the persisted record. `by`/`at` stay SERVER-stamped (never
      // client-set), so identity and time can't be spoofed.
      const srStamp = String(sandboxReview.stamp).slice(0, 128);
      const srUrl = (typeof sandboxReview.url === 'string' && /^https:\/\//.test(sandboxReview.url))
        ? sandboxReview.url.slice(0, 256)
        : null;
      const srMethod = ['tty', 'flag'].includes(sandboxReview.method) ? sandboxReview.method : 'flag';
      await client.query(
        `UPDATE tasks
            SET sandbox_review = jsonb_build_object(
                  'by',     (SELECT github_login FROM builders WHERE id = $2),
                  'at',     now(),
                  'stamp',  $3::text,
                  'url',    $4::text,
                  'method', $5::text
                ),
                updated_at = now()
          WHERE id = $1`,
        [claim.task_id, builderId, srStamp, srUrl, srMethod]
      );
    }

    // Write the session_logs entry + recompute actual_minutes FIRST, so the
    // grader (below) can see a fresh actual_minutes value when scoring the
    // est/actual ratio criterion.
    await sealSessionLog(client, {
      builderId, taskId: claim.task_id, claimId, startedAt: claim.claimed_at,
      outcome, notesMd: notesMd ?? null,
    });
    await client.query(
      `UPDATE tasks
          SET actual_minutes = (
            SELECT COALESCE(
              SUM(EXTRACT(EPOCH FROM (ended_at - started_at)) / 60)::integer,
              0
            )
            FROM session_logs
            WHERE task_id = $1
          )
        WHERE id = $1`,
      [claim.task_id]
    );

    // V3.R18 (#209): the credits gate moved out of resolveClaim into a separate
    // subagent grader. resolveClaim's job is now just "did local verification
    // (scanner + smoke) pass — if yes, land at completed and stop." The caller
    // then runs the subagent grader and POSTs the result to /tasks/:id/grade,
    // which advances completed→confirmed and awards credits when the grader
    // passes (see applyGrade below).
    //
    // The response shape preserves `advanceToMerge` and `grade` so ship.js
    // doesn't need to change at the resolveClaim seam — both are always
    // false/null with the new flow.

    return {
      taskId: claim.task_id,
      taskTitle: claim.title,
      taskStatus: newTaskStatus,
      creditsAwarded: 0,
      advanceToMerge: false,
      justUnlocked: [],
      grade: null,
    };
  });
}

// Final transition: confirmed → shipped. Called by /merge-mode (or auto-merge
// in /builder-ship) once the branch is on main + deployed. No credit
// implication — credits already landed at confirmed. Sets shipped_at.
//
// V3.R14 (#238): also stamps builders.first_ship_at the first time this
// builder ever crosses the ship threshold. COALESCE makes the write
// idempotent — subsequent ships leave the first stamp untouched. Done in
// the same transaction so a roster query that joins both tables sees a
// consistent view.

async function shipTask({ taskId, builderId }, deps = {}) {
  // #538 test seam (mirrors confirmTask): a caller-supplied pool is honored ONLY
  // under NODE_ENV==='test', so a regression test can drive the txn with a
  // SQL-aware fakeClient. Production callers omit deps → module pool.
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const { shipRow, graduationBuilder, rankGraduation, actualShipperId, closedClaimCount } = await withTx(async (client) => {
    const { rows } = await client.query(
      `UPDATE tasks
          SET status = 'shipped',
              shipped_at = now(),
              shipped_by = COALESCE(shipped_by, $2),
              updated_at = now()
        WHERE id = $1 AND status = 'confirmed'
        RETURNING id, title, status, shipped_at, shipped_by, security_sensitive, value_summary`,
      [taskId, builderId]
    );
    if (rows.length === 0) {
      const e = new Error('task not in confirmed state');
      e.code = 'TASK_NOT_CONFIRMED';
      throw e;
    }
    // task 1643: close any claim still OPEN on this task, inside the same txn
    // that shipped it. The normal path already closed the claim in resolveClaim
    // (claimed→completed); this is the safety net for STRANDS — a task that
    // reached a terminal state without that resolve (strand recovery, direct-SQL
    // fixups, or the confirm paths, which flip status + award credits but never
    // touch the claim). Without it the claim dangles released_at=NULL forever and
    // every claim-aware view (builder dashboard, parallel-safety) keeps showing
    // the shipped task as actively claimed — the BV1.R04/R05 strand class (live
    // repro task 1300 / claim #1292). COALESCE preserves any existing outcome; an
    // open claim has outcome=NULL so it lands 'shipped'. The stale-claim sweeper
    // can't do this — its release resets the task to 'ready', un-shipping it.
    // Invariant established here: a shipped task has no open claims.
    const { rows: closedClaims } = await client.query(
      `UPDATE claims
          SET released_at = now(),
              outcome = COALESCE(outcome, 'shipped')
        WHERE task_id = $1 AND released_at IS NULL
        RETURNING id`,
      [taskId]
    );
    // shipped_by is what actually counts — COALESCE above means the row's
    // historical shipped_by wins over the late-arriving builderId, so use
    // the returned value to be sure we credit the right onboarding ship.
    const actualShipperId = rows[0].shipped_by ?? builderId;
    if (actualShipperId != null) {
      await client.query(
        `UPDATE builders
            SET first_ship_at = COALESCE(first_ship_at, now())
          WHERE id = $1`,
        [actualShipperId]
      );
    }
    // V3.R75 (#294) / #766: tick the onboarding state machine inside the same
    // transaction that bumped first_ship_at. The terminal stage is now
    // 'ship_three' — it clears only once the builder has THREE shipped tasks,
    // the same threshold that auto-promotes a Xenos to Thetes below, so the
    // checklist graduation coincides with the rank promotion. The 1st/2nd ships
    // are deliberately no-ops for the stage (the hall's "N of 3" counter comes
    // from the live shipped count, not from the stage). markStage is idempotent.
    // We wrap in try/catch so the ship can't fail because of an onboarding
    // plumbing error — best-effort, mirrors the safeMarkStage helper but inlined
    // to share the transaction.
    // The onboarding state machine carved into modules/onboarding/ (BV1.R81 /
    // ADR 0093 §1): resolve the `onboarding` kernel port and pass this txn
    // `client` — never a direct require of a module. ?. degrades to a no-op when
    // the module is off (best-effort anyway).
    let graduationBuilder = null;
    if (actualShipperId != null) {
      try {
        const onboarding = seams.resolveOptional('onboarding');
        const { rows: sc } = await client.query(
          `SELECT count(*)::int AS n FROM tasks WHERE shipped_by = $1 AND status = 'shipped'`,
          [actualShipperId]
        );
        const result = (onboarding && sc[0].n >= THETES_GRADUATION_THRESHOLD)
          ? await onboarding.markStage(client, actualShipperId, 'ship_three')
          : null;
        if (result && result.justGraduated) {
          // Read the builder row for the broadcast (display_name). Cheap —
          // same transaction. Broadcast itself fires AFTER COMMIT so a chat
          // failure can't roll back the ship.
          const { rows: br } = await client.query(
            `SELECT id, display_name, github_login FROM builders WHERE id = $1`,
            [actualShipperId]
          );
          graduationBuilder = br[0] || null;
        }
      } catch (e) {
        // Don't roll back the ship for an onboarding write failure.
        console.log('[gds] shipTask onboarding markStage failed (non-blocking):', e && e.message);
      }
    }

    // #692 / ADR 0034 (trigger #704): thetes RANK auto-graduation — distinct
    // from the onboarding-stage graduation above. Keyed on the attributed
    // shipper; if they're now a Xenos with 3 successfully SHIPPED tasks, promote
    // xenos→thetes atomically with this ship. Rank-guarded + idempotent.
    const rankGraduation = await maybeAutoGraduateToThetes(client, actualShipperId);

    return { shipRow: rows[0], graduationBuilder, rankGraduation, actualShipperId, closedClaimCount: closedClaims.length };
  }, { pool: activePool });
  if (closedClaimCount > 0) {
    // Post-commit observability: a normal ship closes 0 here (resolveClaim
    // already released the claim). A non-zero count means this ship healed a
    // strand — worth a log line so the class is visible if it recurs (task 1643).
    console.log(`[gds] shipTask: closed ${closedClaimCount} orphaned claim(s) on shipped task ${taskId} (strand safety net — task 1643)`);
  }
  if (graduationBuilder) {
    try {
      seams.resolveOptional('onboarding')?.broadcastGraduation(graduationBuilder);
    } catch (e) {
      console.log('[gds] graduation broadcast post-ship failed:', e && e.message);
    }
  }
  if (rankGraduation) {
    await seams.emitAsync('builder.box-reconcile-needed', {
      builderId: actualShipperId, rank: 'thetes', status: rankGraduation.status, actor: 'auto-graduation:#692',
    }).catch(() => {});
  }
  return { ...shipRow, graduatedTo: rankGraduation ? 'thetes' : null };
}

// task 1134 — feed for the server-owned publish reconciler (src/bongos/
// publish-reconciler.js). Returns one row per CONFIRMED task from its LATEST claim
// (by claimed_at): builder_id (the claim holder, passed to shipTask so the ship is
// attributed to whoever did the work — shipped_by / first_ship_at / thetes
// graduation — exactly as a self-poll would), worktree_name (→ branch
// `claude/<worktree_name>`), and head_sha.
//
// task 1313 — TWO changes that close the strand class:
//   1) head_sha is now selected, so the reconciler can prove a land directly from
//      the commit (isAncestorOfDefaultBranch) when the PR/branch is gone.
//   2) the `worktree_name IS NOT NULL` filter is GONE. A confirmed task whose
//      latest claim carries no worktree_name (a server-mediated publish that never
//      recorded one) used to be omitted entirely and strand forever; it now comes
//      through so the head_sha ancestry check can heal it. Rows with neither a
//      usable branch nor a sha-shaped head_sha are simply no-ops in the sweep.
// No schema change for head_sha: claims.worktree_name + head_sha + claimed_at all
// exist. task 1547 adds c.published_head_sha (the SERVER-pushed tip) so the sweep
// proves a per-task land from this task's OWN commit, not a (reusable) branch name.

async function listConfirmedTasksForReconcile({ limit = 100 } = {}) {
  // t.updated_at is set to now() when confirmTask flips status→'confirmed', so for a
  // STRANDED confirmed task (nothing else touches it) it is a faithful proxy for the
  // confirm time. The reconciler ages out silent strands on it (task 1546 / blocker 47:
  // 15 tasks sat unprovable for up to 66h because every sweep miss was a silent continue).
  const { rows } = await pool.query(
    `SELECT DISTINCT ON (t.id) t.id AS task_id, c.builder_id, c.worktree_name, c.head_sha,
            c.published_head_sha, t.updated_at AS confirmed_at
       FROM tasks t
       JOIN claims c ON c.task_id = t.id
      WHERE t.status = 'confirmed'
      ORDER BY t.id, c.claimed_at DESC
      LIMIT $1`,
    [limit]
  );
  return rows;
}

// task 1547 — record the tip the server actually pushed for this task's
// server-mediated publish (ADR 0055), on the LATEST claim for the task. Called by
// POST /tasks/:id/publish-branch after a successful pushBundle. This is the durable
// per-task land proof the reconcile gates on: claims.head_sha is the claim-time
// BASE, which for a task whose base is already on main (e.g. an R03 base) would
// false-positive an ancestry check; the published tip cannot. Idempotent — a
// re-publish of the same branch just re-stamps the same sha. Returns the updated
// claim id, or null if no claim exists (defensive — publish-branch is ownership-gated).

async function setClaimPublishedSha({ taskId, builderId, sha }) {
  if (!sha || !/^[0-9a-f]{7,64}$/.test(String(sha))) return null;
  const { rows } = await pool.query(
    `UPDATE claims
        SET published_head_sha = $3
      WHERE id = (
        SELECT id FROM claims
         WHERE task_id = $1 AND builder_id = $2
         ORDER BY claimed_at DESC, id DESC
         LIMIT 1
      )
      RETURNING id`,
    [taskId, builderId, sha]
  );
  return rows[0]?.id ?? null;
}

// task 1547 — the published tip for the LATEST claim on a task (any builder), used
// by the publish-status reconcile-on-read to verify the task's own commit landed
// before flipping confirmed->shipped. NULL when no server-mediated publish recorded
// one (legacy rows / a publish that never succeeded — e.g. the BV1.R04/R05 strand).

async function getClaimPublishedSha(taskId) {
  const { rows } = await pool.query(
    `SELECT published_head_sha
       FROM claims
      WHERE task_id = $1
      ORDER BY claimed_at DESC, id DESC
      LIMIT 1`,
    [taskId]
  );
  return rows[0]?.published_head_sha ?? null;
}

// V3.R14 (#238) — onboarding observability roster.
//
// One row per builder, joined with the live "what are they doing right
// now" signals the Archon needs to triage onboarding from /builders:
//
//   - identity:    id, github_login, display_name, rank, status
//   - credits:     total_credits (drachmae)
//   - karma:       karma (good-citizenship track)
//   - onboarding:  onboarded_at, first_ship_at,
//                  time_to_first_ship_minutes (NULL until they've shipped)
//   - claims:      active_claim_count, stale_claim
//
// "stale_claim" mirrors the stale-claim-release sweeper definition
// (.claude/scheduled-tasks/stale-claim-release/SKILL.md): a still-open
// claim where either the last session_pulses row is older than the
// stale threshold, or there's no pulse row at all AND claimed_at is
// older than the threshold. Default threshold is 24h to match this
// task's spec — the sweeper itself uses GDS_STALE_CLAIM_HOURS (default
// 6h) and is in charge of *acting*. The roster only *surfaces*.
//
// Returns: array of builder roster rows, ordered by:
//   1. inactive builders sink to the bottom (status='inactive' last)
//   2. still-onboarding (first_ship_at IS NULL) above shipped builders
//   3. then by created_at DESC inside each group (newest first)

async function getBuildersRoster({ staleHours = 24 } = {}) {
  const hours = Number(staleHours);
  if (!Number.isFinite(hours) || hours <= 0) {
    throw new Error('getBuildersRoster: staleHours must be a positive number');
  }
  const { rows } = await pool.query(
    `WITH stale_active AS (
       SELECT c.builder_id,
              COUNT(*) FILTER (
                WHERE ${staleClaimHourPredicate('$1')}
              ) AS stale_claim_count,
              COUNT(*) AS active_claim_count
         FROM claims c
         LEFT JOIN session_pulses sp ON sp.claim_id = c.id
        WHERE c.released_at IS NULL
        GROUP BY c.builder_id
     )
     SELECT
       b.id,
       b.github_login,
       b.display_name,
       b.avatar_url,
       b.rank,
       b.status,
       b.total_credits,
       b.karma,
       b.created_at,
       b.onboarded_at,
       b.first_ship_at,
       CASE
         WHEN b.first_ship_at IS NULL OR b.onboarded_at IS NULL THEN NULL
         ELSE GREATEST(
           0,
           EXTRACT(EPOCH FROM (b.first_ship_at - b.onboarded_at))::bigint / 60
         )
       END AS time_to_first_ship_minutes,
       COALESCE(sa.active_claim_count, 0) AS active_claim_count,
       (COALESCE(sa.stale_claim_count, 0) > 0) AS stale_claim
       FROM builders b
       LEFT JOIN stale_active sa ON sa.builder_id = b.id
      ORDER BY
        (b.status = 'inactive') ASC,
        (b.first_ship_at IS NOT NULL) ASC,
        b.created_at DESC`,
    [hours]
  );
  return rows;
}

// V3.R14 (#238) — stale claim detail for the roster expand view.
// Returns the active claim rows for a specific builder *with* stale
// signals, so the Archon can pick the right one to release. Used by
// the management panel's per-row "release stale claim" action.

async function getActiveClaimsForBuilderWithStale(builderId, { staleHours = 24 } = {}) {
  const builder = Number(builderId);
  const hours = Number(staleHours);
  if (!Number.isFinite(builder)) {
    throw new Error('getActiveClaimsForBuilderWithStale: builderId must be numeric');
  }
  if (!Number.isFinite(hours) || hours <= 0) {
    throw new Error('getActiveClaimsForBuilderWithStale: staleHours must be a positive number');
  }
  const { rows } = await pool.query(
    `SELECT c.id          AS claim_id,
            c.task_id     AS task_id,
            c.builder_id  AS builder_id,
            c.claimed_at  AS claimed_at,
            c.worktree_name AS worktree_name,
            t.title       AS task_title,
            sp.last_pulse_at AS last_pulse_at,
            (
              ${staleClaimHourPredicate('$2')}
            ) AS stale_claim
       FROM claims c
       JOIN tasks t ON t.id = c.task_id
       LEFT JOIN session_pulses sp ON sp.claim_id = c.id
      WHERE c.released_at IS NULL
        AND c.builder_id = $1
      ORDER BY c.claimed_at ASC`,
    [builder, hours]
  );
  return rows;
}

// V3.R14 (#238) — release a claim "on behalf of" the original builder.
// Archon-only at the route layer; this helper does no rank check itself,
// so callers MUST gate it.
//
// Mirrors the stale-claim-release sweeper's transaction shape:
//   1. lock the claim row, skip if it raced to released
//   2. set released_at + outcome='abandoned'
//   3. send the task back to status='ready'
//   4. write a session_logs entry tagged "[archon-release] ..." so the
//      audit trail makes it obvious this was a third-party intervention
//      and not the original builder abandoning their own work
//
// reason: free-text the Archon supplies (≤512 chars; the route validates).
// archonLogin: display string of the acting Archon, embedded in notes_md.

async function releaseClaimOnBehalf({ claimId, archonId, archonLogin, reason }) {
  const id = Number(claimId);
  if (!Number.isFinite(id)) {
    throw Object.assign(new Error('claimId must be numeric'), { code: 'BAD_CLAIM_ID' });
  }
  return withTx(async (client) => {
    const { rows: cur } = await client.query(
      `SELECT c.id, c.task_id, c.builder_id, c.claimed_at, c.released_at,
              t.title
         FROM claims c JOIN tasks t ON t.id = c.task_id
        WHERE c.id = $1
        FOR UPDATE`,
      [id]
    );
    if (cur.length === 0) {
      throw Object.assign(new Error('claim not found'), { code: 'CLAIM_NOT_FOUND' });
    }
    if (cur[0].released_at) {
      throw Object.assign(new Error('claim already released'), { code: 'ALREADY_RESOLVED' });
    }
    const { task_id: taskId, builder_id: ownerId, claimed_at: claimedAt, title } = cur[0];
    const tag = '[archon-release]';
    const actor = archonLogin
      ? `@${archonLogin} (builder #${archonId})`
      : `archon #${archonId}`;
    const reasonText = (typeof reason === 'string' && reason.trim().length > 0)
      ? reason.trim()
      : 'no reason given';
    const notesMd =
      `${tag} released by ${actor}: ${reasonText} ` +
      `Original claim by builder #${ownerId} for task #${taskId} "${title}".`;

    await client.query(
      `UPDATE claims SET released_at = now(), outcome = 'abandoned' WHERE id = $1`,
      [id]
    );
    await client.query(
      `UPDATE tasks
          SET status = 'ready',
              updated_at = now()
        WHERE id = $1`,
      [taskId]
    );
    // session_logs row carries the original builder_id (whose session this
    // was) PLUS the tagged notes_md identifying the acting Archon. The
    // sweeper writes the same way — "the session belongs to the builder,
    // the release was decided by someone else."
    await sealSessionLog(client, {
      builderId: ownerId, taskId, claimId: id, startedAt: claimedAt,
      outcome: 'abandoned', notesMd,
    });
    return {
      claim_id: id,
      task_id: taskId,
      original_builder_id: ownerId,
      task_title: title,
      notes_md: notesMd,
    };
  });
}

// Manual confirm: completed → confirmed without going through resolveClaim
// again. Awards credits if the task carries a reward and credits haven't
// already been awarded. For human override of failed auto-verification.

async function confirmTask({ taskId, builderId }, deps = {}) {
  // #538 test seam: a caller-supplied pool is honored ONLY under NODE_ENV==='test'
  // so a regression test can drive the txn with a SQL-aware fakeClient (same
  // pattern as decideOverrideRequest / override_attribution.mjs). Production
  // callers omit deps → module pool.
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  return withTx(async (client) => {
    // #661: credit the builder who actually DID the work — the task's claim
    // holder — never the confirming Archon. The /tasks/:id/confirm route is
    // archon-only and passes req.builder.id (the confirmer); before this fix
    // both the credit_log row AND tasks.shipped_by were attributed to that
    // Archon when they manual-confirmed someone else's completed task (live
    // repro 2026-06-04: Xenos's #660 credit landed on builder #1). The claim
    // holder is the builder on the most-recent claims row for the task — for a
    // 'completed' task that is the builder whose 'shipped' resolve drove it
    // there. Fall back to the confirmer only if the task has no claim at all (a
    // degenerate state, e.g. status set directly via SQL) so a legitimate
    // confirm is never refused. Mirrors the #538 fix on the override path.
    const creditedBuilderId = (await mostRecentClaimHolderId(client, taskId)) ?? builderId;

    const { rows } = await client.query(
      `UPDATE tasks
          SET status = 'confirmed',
              shipped_by = COALESCE(shipped_by, $2),
              updated_at = now()
        WHERE id = $1 AND status = 'completed'
        RETURNING id, title, credits_reward, kind`,
      [taskId, creditedBuilderId]
    );
    if (rows.length === 0) {
      throw Object.assign(new Error('task not in completed state'), { code: 'TASK_NOT_COMPLETED' });
    }
    const task = rows[0];

    // Credit allocation carved to modules/economy/ (BV1.R77 / ADR 0093 §1-2):
    // resolve the `reward` kernel port once; every credit/achievement write below
    // runs inside this same txn. resolveOptional → undefined on a vanilla instance
    // without economy, so every use is guarded (degrades to a best-effort no-op).
    const reward = seams.resolveOptional('reward');

    // Award credits if not already in credit_log for this task. V3.R27 (#247)
    // routes the insert through insertMultipliedConfirmCredit so the kind
    // multiplier and self-describing description apply to manual-confirms
    // identically to grader-confirms.
    const { rows: existing } = await client.query(
      `SELECT 1 FROM credit_log WHERE task_id = $1 AND reason = 'task.confirmed' LIMIT 1`,
      [taskId]
    );
    let creditsAwarded = 0;
    let ideaBonus = null;
    if (reward && existing.length === 0 && task.credits_reward > 0) {
      const credit = await reward.insertMultipliedConfirmCredit(
        client, creditedBuilderId, taskId, task.credits_reward, task.kind
      );
      creditsAwarded = credit.creditsAwarded;
      ideaBonus = await reward.maybeAwardIdeaPromotionBonus(
        client, taskId, creditedBuilderId, creditsAwarded
      );
    }

    // task 1679: confirmTask is the --skip-grade / grader_bypass ship path — the
    // DOMINANT one — and until now it awarded credits but NEVER evaluated
    // achievements (only applyGrade did), so builders shipping with grader_bypass
    // on only ever unlocked first-claim. Reconcile the full state-based set here
    // so every ship path unlocks achievements. The claim is already
    // outcome='shipped' (resolveClaim ran first) and credits (above + the session
    // reward) are reflected in builders.total_credits, so all predicates see
    // current state. Wrapped in a SAVEPOINT: achievements are best-effort
    // gamification and must never fail a confirm — a reconcile error rolls back
    // only the reconcile, leaving the confirm + credit intact.
    let justUnlocked = [];
    if (reward && reward.reconcileBuilderAchievements) {
      await client.query('SAVEPOINT ach_reconcile');
      try {
        justUnlocked = await reward.reconcileBuilderAchievements(client, creditedBuilderId, { taskId });
        await client.query('RELEASE SAVEPOINT ach_reconcile');
      } catch (_) {
        await client.query('ROLLBACK TO SAVEPOINT ach_reconcile');
        justUnlocked = [];
      }
    }

    // #704: thetes graduation is NOT evaluated here — it fires at SHIP time
    // (shipTask), keyed on 3 successfully SHIPPED tasks, not at confirm.

    return { taskId, taskTitle: task.title, taskStatus: 'confirmed', creditsAwarded, ideaBonus, creditedBuilderId, justUnlocked };
  }, { pool: activePool });
}

// abandonTask (task 987) — the terminal "retire this task" transition. The GDS
// lifecycle had promote (backlog→ready), the claim-resolve path (active→
// completed/ready), and confirm/ship (completed→confirmed→shipped), but NO
// first-class way to KILL a task that is no longer relevant. The only routes to
// status='abandoned' were offboarding a builder (offboardBuilder, which seals
// each open claim) and a raw SQL UPDATE — so stale/moot tasks sat in 'ready' as
// claimable noise (the box-teardown chores #819/#822/#827 and the dup tasks
// #907/#926 that other sessions had already shipped, all retired 2026-06-13).
// This is the missing transition.
//
// Guards:
//   - already 'abandoned' → idempotent no-op (alreadyAbandoned:true) so a retry
//                           or a double-click never errors.
//   - 'shipped'           → CANNOT_ABANDON_SHIPPED. Shipped work is immutable
//                           history; retiring it would corrupt the ledger and
//                           the version_progress rollups.
//   - an unreleased claim → TASK_HAS_ACTIVE_CLAIM. A live claim means a session
//                           still owns the work; release it first so the abandon
//                           can never race a ship in flight.
// Any other status (backlog/ready/blocked/completed/confirmed) abandons. The
// route is archon-gated, and the abandon + its reason are captured in audit_log
// by the writing middleware, so the append-only ledger records who retired what.
//
// NOTE on dependencies: abandoning a task that is listed in another task's
// dependencies[] does NOT auto-adjust those dependents — they will simply never
// auto-promote on this (now dead) dep. That is intentionally left to the Archon
// (PUT/DELETE /tasks/:id/dependencies) rather than guessed at here; the stale
// chores this was built for are dependency leaves.
//
// #538 test seam: a caller-supplied pool is honored ONLY under NODE_ENV==='test'
// so a regression test can drive the txn with a SQL-aware fakeClient, same as
// confirmTask / decideOverrideRequest. Production callers omit deps → module pool.

async function abandonTask({ taskId, reason }, deps = {}) {
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const client = await activePool.connect();
  try {
    await client.query('BEGIN');

    const { rows: taskRows } = await client.query(
      `SELECT id, title, status FROM tasks WHERE id = $1 FOR UPDATE`,
      [taskId]
    );
    if (taskRows.length === 0) {
      throw Object.assign(new Error('task not found'), { code: 'TASK_NOT_FOUND' });
    }
    const task = taskRows[0];

    if (task.status === 'abandoned') {
      await client.query('COMMIT');
      return { taskId, taskTitle: task.title, taskStatus: 'abandoned', previousStatus: 'abandoned', alreadyAbandoned: true };
    }
    if (task.status === 'shipped') {
      throw Object.assign(new Error('cannot abandon a shipped task'), { code: 'CANNOT_ABANDON_SHIPPED' });
    }

    const { rows: activeClaims } = await client.query(
      `SELECT id FROM claims WHERE task_id = $1 AND released_at IS NULL LIMIT 1`,
      [taskId]
    );
    if (activeClaims.length > 0) {
      throw Object.assign(new Error('task has an active claim; release it first'), { code: 'TASK_HAS_ACTIVE_CLAIM' });
    }

    const { rows: updated } = await client.query(
      `UPDATE tasks
          SET status = 'abandoned',
              value_summary = COALESCE(NULLIF($2, ''), value_summary),
              updated_at = now()
        WHERE id = $1
        RETURNING id, title, status`,
      [taskId, reason ? `Abandoned: ${reason}` : '']
    );

    await client.query('COMMIT');
    return {
      taskId,
      taskTitle: updated[0].title,
      taskStatus: 'abandoned',
      previousStatus: task.status,
      alreadyAbandoned: false,
    };
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

// task override requests — V3.R74 (#293). Rare path: a builder whose ship was
// rejected by the subagent grader (task stays at 'completed', no credits)
// believes the grader was wrong and asks an Archon to confirm anyway.


async function createOverrideRequest({ taskId, requesterId, rationale }) {
  const { rows: taskRows } = await pool.query(
    `SELECT id, status FROM tasks WHERE id = $1`,
    [taskId]
  );
  if (taskRows.length === 0) {
    throw Object.assign(new Error('task not found'), { code: 'TASK_NOT_FOUND' });
  }
  if (taskRows[0].status !== 'completed') {
    throw Object.assign(new Error('task not in completed state'), {
      code: 'TASK_NOT_COMPLETED',
      currentStatus: taskRows[0].status,
    });
  }
  try {
    const { rows } = await pool.query(
      `INSERT INTO task_override_requests (task_id, requested_by_builder_id, rationale)
       VALUES ($1, $2, $3)
       RETURNING id, task_id, requested_by_builder_id, rationale, status, created_at`,
      [taskId, requesterId, rationale]
    );
    return rows[0];
  } catch (err) {
    // uniq_task_override_requests_open_per_task — one open request per task.
    if (err && err.code === '23505') {
      throw Object.assign(new Error('open request already exists for this task'), {
        code: 'OPEN_REQUEST_EXISTS',
      });
    }
    throw err;
  }
}


async function listOverrideRequests({ status = 'open', limit = 50 } = {}) {
  const { rows } = await pool.query(
    `SELECT r.id, r.task_id, r.requested_by_builder_id, r.rationale, r.status,
            r.decided_by_builder_id, r.decided_at, r.decision_note, r.created_at,
            t.title AS task_title, t.status AS task_status, t.version_id, t.credits_reward,
            b.github_login AS requester_login, b.display_name AS requester_display_name
       FROM task_override_requests r
       JOIN tasks t ON t.id = r.task_id
       JOIN builders b ON b.id = r.requested_by_builder_id
      WHERE r.status = $1
      ORDER BY r.created_at DESC
      LIMIT $2`,
    [status, limit]
  );
  return rows;
}


async function decideOverrideRequest({ requestId, archonId, decision, note }, deps = {}) {
  if (decision !== 'approve' && decision !== 'deny') {
    throw Object.assign(new Error('bad decision'), { code: 'BAD_DECISION' });
  }
  // `deps.pool` is a TEST-ONLY injection seam (#538) — honored ONLY when
  // NODE_ENV==='test' (not merely "not production"), so an unset NODE_ENV in a
  // prod-like box can't accidentally activate it, and a future route that
  // naively forwarded a caller-supplied pool could never swap the DB connection
  // in prod (hacker review #538). It lets tests drive the txn with a fakeClient
  // (same pattern as credit_grant.mjs). Production callers omit it → module pool.
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  return withTx(async (client) => {
    // RETURNING requested_by_builder_id so the approve path doesn't re-read the
    // row it just locked (#538): the work was the ORIGINAL REQUESTER's, and both
    // the credit AND the ship attribution must go to them.
    const { rows } = await client.query(
      `UPDATE task_override_requests
          SET status = $1,
              decided_by_builder_id = $2,
              decided_at = now(),
              decision_note = $3
        WHERE id = $4 AND status = 'open'
        RETURNING id, task_id, status, requested_by_builder_id`,
      [decision === 'approve' ? 'approved' : 'denied', archonId, note ?? null, requestId]
    );
    if (rows.length === 0) {
      throw Object.assign(new Error('request not open'), { code: 'REQUEST_NOT_OPEN' });
    }
    const row = rows[0];

    let confirmResult = null;
    if (decision === 'approve') {
      // BOTH the credit AND the ship attribution (shipped_by, which drives the
      // builders' hall + peer-vote feed) go to the builder who actually DID the
      // work — the task's most-recent claim holder — never the approving Archon.
      //
      // (#538: previously shipped_by fell to the Archon via
      // COALESCE(shipped_by, archonId), misattributing the ship even though the
      // credit was routed correctly. That fix attributed everything to the
      // override REQUESTER. SR-16 / #996 tightens it once more: with the new
      // ownership gate on POST /tasks/:id/override-request the requester is
      // already the claim holder OR an Archon, so resolving the CLAIM HOLDER
      // here — the same attribution source applyGrade/confirmTask use via
      // getLastClaimHolder — keeps the credit on the worker even when an Archon
      // files the request on a builder's behalf. Falls back to the requester
      // only when the task has no claim on record at all, so a legitimate
      // degenerate edge — e.g. status set directly via SQL — is never refused.)
      const creditedBuilderId = (await mostRecentClaimHolderId(client, row.task_id)) ?? row.requested_by_builder_id;
      // requested_by_builder_id is NOT NULL in the schema, so this can only be
      // null in a degenerate state. Rather than silently fall back to archonId —
      // which would re-create the exact misattribution #538 fixed — refuse the
      // approval if there is neither a claim holder nor a requester to credit.
      // Rolls back so the override stays open for inspection.
      if (creditedBuilderId == null) {
        throw Object.assign(
          new Error(`override request ${requestId} has no claim holder or requester to credit`),
          { code: 'OVERRIDE_NO_REQUESTER' }
        );
      }

      // Flip the task completed→confirmed and attribute the ship to the
      // requester. Inlined here (rather than calling confirmTask) because
      // confirmTask opens its own client/transaction; we want one atomic step.
      const { rows: taskRows } = await client.query(
        `UPDATE tasks
            SET status = 'confirmed',
                shipped_by = COALESCE(shipped_by, $2),
                updated_at = now()
          WHERE id = $1 AND status = 'completed'
          RETURNING id, title, credits_reward, kind`,
        [row.task_id, creditedBuilderId]
      );
      if (taskRows.length === 0) {
        // Task was raced to another terminal state (e.g. someone manually
        // confirmed it between the request and the decision). The approval row
        // still stands as the audit signal; we just don't double-flip the task.
        // creditedBuilderId is included for a consistent return shape so callers
        // can always destructure it from confirmResult without a guard (#538).
        confirmResult = { taskFlipped: false, creditsAwarded: 0, ideaBonus: null, creditedBuilderId };
      } else {
        const task = taskRows[0];
        const { rows: existing } = await client.query(
          `SELECT 1 FROM credit_log WHERE task_id = $1 AND reason = 'task.confirmed' LIMIT 1`,
          [task.id]
        );
        let creditsAwarded = 0;
        let ideaBonus = null;
        if (existing.length === 0 && task.credits_reward > 0) {
          // V3.R27 (#247): apply kind multiplier on the override-confirm path
          // too, so a builder who had to argue for their ship is not punished
          // by getting the legacy 1.0× payout. Credit allocation carved to
          // modules/economy/ (BV1.R77 / ADR 0093 §1-2): resolve the `reward`
          // kernel port and write the credit inside this same txn.
          const reward = seams.resolveOptional('reward');
          const credit = await reward.insertMultipliedConfirmCredit(
            client, creditedBuilderId, task.id, task.credits_reward, task.kind
          );
          creditsAwarded = credit.creditsAwarded;
          ideaBonus = await reward.maybeAwardIdeaPromotionBonus(
            client, task.id, creditedBuilderId, creditsAwarded
          );
        }
        // #704: thetes graduation is evaluated at SHIP time (shipTask), not on
        // confirm/override — credits here, rank graduation when the task ships.
        confirmResult = { taskFlipped: true, creditsAwarded, ideaBonus, creditedBuilderId };
      }
    }

    return { request: row, confirmResult };
  }, { pool: activePool });
}

// Credit allocation carved into modules/economy/credits.js (BV1.R77 / ADR 0093
// §§1-2): KIND_MULTIPLIERS / IDEA_BONUS_FRACTION / REWARD_MARGIN_PCT,
// computeSessionTokenReward, applyKindMultiplier, insertMultipliedConfirmCredit,
// maybeAwardIdeaPromotionBonus, awardSessionTokenReward, and the net-negative
// (Subtractor) bonus all left this monolith. The lifecycle above (applyGrade /
// confirmTask / decideOverrideRequest / upsertSessionRecordWithReward) resolves
// them through the `reward` kernel port, passing its own tx client.

// applyGrade — V3.R18 (#209). Writes the subagent grader result to task_grades
// and, if the grade passed, promotes completed→confirmed + awards credits.
//
// Inputs (the route handler validates + scores the subagent JSON before
// calling this, so we accept a pre-built grade-result):
//   taskId       — number
//   builderId    — current authenticated builder (must own the task's most-
//                  recent claim; the route handler enforces this)
//   gradeResult  — { score, passed, threshold, grader_kind, grader_version,
//                    rubric_scores, signals, notes_md, issues }
//
// Returns: { taskId, taskTitle, taskStatus, creditsAwarded, justUnlocked,
//            grade: {score, passed, ...} }.
//
// Idempotent: the task_grades row is upsert-on-task_id (a re-grade overwrites);
// credit_log is guarded by an existence check on (task_id, 'task.confirmed').

async function applyGrade({ taskId, builderId, gradeResult, committedFiles = null, diffHash = null }, deps = {}) {
  // committedFiles (touches[] cleanup [3/8] / task 878): the real committed
  // changed-files for this ship, computed client-side by ship.js. Threaded to
  // evaluateAfterShip so the prefix-keyed shipper badges reflect the actual
  // diff rather than the predicted touches[]. Optional — null/absent falls back
  // to touches[] inside evaluateAfterShip.
  // #871 test seam (mirrors confirmTask's #538 seam): a caller-supplied pool is
  // honored ONLY under NODE_ENV==='test' so tests/grade_attribution.mjs can drive
  // the txn with a SQL-aware fakeClient. Production callers omit deps → module pool.
  const activePool = (deps.pool && process.env.NODE_ENV === 'test') ? deps.pool : pool;
  const result = await withTx(async (client) => {
    const { rows: taskRows } = await client.query(
      `SELECT id, title, status, credits_reward, kind FROM tasks WHERE id = $1 FOR UPDATE`,
      [taskId]
    );
    if (taskRows.length === 0) {
      throw Object.assign(new Error('task not found'), { code: 'TASK_NOT_FOUND' });
    }
    const task = taskRows[0];

    // The grade can only land while the task is at `completed` (just shipped
    // and awaiting grading) or `confirmed` (already promoted by a prior grade
    // pass — re-grading is allowed and writes a fresh row, but it does not
    // re-award credits or re-evaluate achievements). At `shipped`/`backlog`/
    // `active`/`ready`/`blocked`/`abandoned` the grade has no lifecycle target,
    // so we refuse.
    if (!['completed', 'confirmed'].includes(task.status)) {
      throw Object.assign(new Error(`task is at ${task.status}; grade only applies at completed/confirmed`), {
        code: 'TASK_NOT_GRADABLE',
        current_status: task.status,
      });
    }

    // SECURITY (#871 — mirrors the #661 confirmTask fix): credit + attribute the
    // builder who actually DID the work — the task's most-recent claim holder —
    // NEVER the caller of this endpoint. Before this fix applyGrade set
    // tasks.shipped_by and the credit_log row to `builderId` (req.builder.id from
    // the route), so a builder who POSTed a fabricated passing grade on ANOTHER
    // builder's `completed` task captured both the ship attribution AND the
    // drachmae. POST /tasks/:id/grade now also gates to the claim holder/Archon,
    // but we fix the attribution here too: defense-in-depth, and it is the
    // CORRECT behaviour for the Archon `--regrade` path where the caller is not
    // the worker. Fall back to the caller only if the task has no claim at all
    // (degenerate — e.g. status set directly via SQL) so a legit grade is never
    // refused.
    const creditedBuilderId = (await mostRecentClaimHolderId(client, taskId)) ?? builderId;

    // Upsert the grade row. The subagent's issues[] is embedded into the
    // signals jsonb so /me + the public dashboard can surface structured
    // failure detail without a schema change. (task_grades has no `issues`
    // column.)
    const signalsForRow = {
      ...(gradeResult.signals || {}),
      issues: gradeResult.issues || [],
    };
    await client.query(
      `INSERT INTO task_grades
         (task_id, score, passed, threshold, grader_kind, grader_version,
          rubric_scores, signals, notes_md, diff_hash)
       VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8::jsonb, $9, $10)
       ON CONFLICT (task_id) DO UPDATE SET
         score          = EXCLUDED.score,
         passed         = EXCLUDED.passed,
         threshold      = EXCLUDED.threshold,
         grader_kind    = EXCLUDED.grader_kind,
         grader_version = EXCLUDED.grader_version,
         rubric_scores  = EXCLUDED.rubric_scores,
         signals        = EXCLUDED.signals,
         notes_md       = EXCLUDED.notes_md,
         diff_hash      = EXCLUDED.diff_hash,
         graded_at      = now()`,
      [
        taskId,
        gradeResult.score,
        gradeResult.passed,
        gradeResult.threshold,
        gradeResult.grader_kind,
        gradeResult.grader_version,
        JSON.stringify(gradeResult.rubric_scores || {}),
        JSON.stringify(signalsForRow),
        gradeResult.notes_md ?? null,
        diffHash ?? null,
      ]
    );

    let finalStatus = task.status;
    let creditsAwarded = 0;
    let creditsRaw = 0;
    let creditsMultiplier = 1.0;
    let ideaBonus = null; // { ideaBonusAwarded, bonusBuilderId, ideaId } | null
    let netNegativeBonus = 0;
    let subtractorUnlocks = [];
    let justUnlocked = [];
    // Credit allocation + gamification carved to modules/economy/ (BV1.R77 / ADR
    // 0093 §1-2): resolve the `reward` kernel port ONCE; every credit/achievement
    // write below runs inside this same txn via the resolved provider. The
    // state-machine SQL (FOR UPDATE, task_grades upsert, UPDATE tasks status,
    // claim-holder lookup, logGradeAttempt) stays here in the lifecycle.
    const reward = seams.resolveOptional('reward');
    if (gradeResult.passed && task.status === 'completed') {
      await client.query(
        `UPDATE tasks
            SET status = 'confirmed',
                shipped_by = COALESCE(shipped_by, $2),
                updated_at = now()
          WHERE id = $1 AND status = 'completed'`,
        [taskId, creditedBuilderId]
      );
      finalStatus = 'confirmed';

      // V3.R93 (#354): reward simplification. A ship whose diff removed more
      // lines than it added earns a small flat bonus, written as its own
      // credit_log row (reason='ship.net_negative') with a self-describing
      // description. Idempotent on (task_id, reason) so a re-grade is a no-op.
      // diff_stats arrives via gradeResult.signals (ship.js decorates it).
      //
      // Awarded BEFORE the achievement evaluators so the Subtractor achievement
      // (which counts the builder's net-negative ships) sees the current ship's
      // bonus row in this same transaction.
      const nn = await reward.awardNetNegativeBonus(
        client, creditedBuilderId, taskId, gradeResult.signals?.diff_stats
      );
      netNegativeBonus = nn.bonus;
      subtractorUnlocks = nn.justUnlocked;

      // Credit award is idempotent on (task_id, 'task.confirmed'). A second
      // pass through applyGrade for the same task (re-grade scenario) is a
      // no-op for credit_log.
      const { rows: existing } = await client.query(
        `SELECT 1 FROM credit_log WHERE task_id = $1 AND reason = 'task.confirmed' LIMIT 1`,
        [taskId]
      );
      if (existing.length === 0 && task.credits_reward > 0) {
        const { rows: beforeRows } = await client.query(
          `SELECT total_credits FROM builders WHERE id = $1`,
          [creditedBuilderId]
        );
        const totalBefore = Number(beforeRows[0]?.total_credits ?? 0);

        // V3.R27 (#247): apply the per-kind multiplier. The credit_log
        // description records "<raw>c × <mult> = <effective>c (<kind>)" so
        // the audit trail is self-explaining; the trigger on credit_log rolls
        // the effective value into builders.total_credits exactly as before.
        const credit = await reward.insertMultipliedConfirmCredit(
          client, creditedBuilderId, taskId, task.credits_reward, task.kind
        );
        creditsAwarded = credit.creditsAwarded;
        creditsRaw = credit.raw;
        creditsMultiplier = credit.multiplier;

        // V3.R27 (#247): staged idea-promotion bonus. If this task came out
        // of idea_inbox and the capturer is a different builder than the
        // shipper, give the capturer 25% of the multiplier-adjusted reward.
        // Runs INSIDE the same txn so total_credits and bonus stay atomic.
        ideaBonus = await reward.maybeAwardIdeaPromotionBonus(
          client, taskId, creditedBuilderId, creditsAwarded
        );

        // #704: thetes graduation is evaluated at SHIP time (shipTask), not at
        // grader-confirm — credits land here, rank graduation when the task ships.

        const { rows: afterRows } = await client.query(
          `SELECT total_credits FROM builders WHERE id = $1`,
          [creditedBuilderId]
        );
        const totalAfter = Number(afterRows[0]?.total_credits ?? 0);

        const shipUnlocks = await reward.evaluateAfterShip(client, creditedBuilderId, taskId, committedFiles);
        const creditUnlocks = await reward.evaluateAfterCreditAward(
          client, creditedBuilderId, totalBefore, totalAfter
        );
        justUnlocked = [...subtractorUnlocks, ...shipUnlocks, ...creditUnlocks];
      } else {
        const shipUnlocks = await reward.evaluateAfterShip(client, creditedBuilderId, taskId, committedFiles);
        justUnlocked = [...subtractorUnlocks, ...shipUnlocks];
      }

      // task 1679: state-based safety net. The granular evaluators above are
      // boundary-/path-sensitive — breaking-the-100c-bar only fires when a
      // per-task confirm credit crosses 100 (the session cost-plus reward never
      // hits it), and streaks key off current_streak. reconcile re-checks every
      // achievement against current state and unlocks any straggler. It is
      // idempotent: anything the granular calls just unlocked is visible in this
      // txn, so reconcile's alreadyUnlocked guard skips it (no dup awards).
      // SAVEPOINT-wrapped so it can never fail the grade-confirm.
      if (reward && reward.reconcileBuilderAchievements) {
        await client.query('SAVEPOINT ach_reconcile');
        try {
          const reconciled = await reward.reconcileBuilderAchievements(client, creditedBuilderId, { taskId });
          await client.query('RELEASE SAVEPOINT ach_reconcile');
          if (reconciled.length) justUnlocked = [...justUnlocked, ...reconciled];
        } catch (_) {
          await client.query('ROLLBACK TO SAVEPOINT ach_reconcile');
        }
      }
    }
    // !passed → task_grades row written above; task stays at completed; no
    // credits, no achievements. Builder can manual-confirm via /confirm if the
    // grade was wrong.

    return {
      taskId,
      taskTitle: task.title,
      taskStatus: finalStatus,
      creditedBuilderId, // #871: the builder credited/attributed (claim holder, not caller)
      creditsAwarded,
      creditsRaw,
      creditsMultiplier,
      ideaBonus, // V3.R27 (#247): { ideaBonusAwarded, bonusBuilderId, ideaId } | null
      netNegativeBonus,
      advanceToMerge: finalStatus === 'confirmed',
      justUnlocked,
      grade: {
        score: gradeResult.score,
        passed: gradeResult.passed,
        threshold: gradeResult.threshold,
        rubric_scores: gradeResult.rubric_scores || {},
        notes_md: gradeResult.notes_md ?? null,
        issues: gradeResult.issues || [],
      },
    };
  }, { pool: activePool });

  // 6D.6 (ADR 0027): record this grade ATTEMPT in the append-only log so
  // re-grade thrash is countable (task_grades is upsert-unique). Post-commit +
  // best-effort: logGradeAttempt uses a pooled connection and swallows its own
  // errors, so it can never roll back or block the grade that just committed.
  await logGradeAttempt({ taskId, builderId, passed: gradeResult.passed, score: gradeResult.score });

  return result;
}


async function getActiveClaimsForBuilder(builderId) {
  // release_requested_* (task 1736): a goal owner/manager's flag-for-release
  // nudge rides on the holder's own claim read so /me (and the surfaces built
  // on it) can show "someone asked you to wrap this up".
  const { rows } = await pool.query(
    `SELECT c.id AS claim_id, c.task_id, c.worktree_name, c.claimed_at,
            c.head_sha, c.reserved_migration_number,
            c.release_requested_by, c.release_requested_at, c.release_requested_note,
            t.title, t.touches, t.priority, t.credits_reward, t.version_id, t.module_key
       FROM claims c JOIN tasks t ON t.id = c.task_id
      WHERE c.builder_id = $1 AND c.released_at IS NULL
      ORDER BY c.claimed_at`,
    [builderId]
  );
  return rows;
}

// task 1642 — every active claim bound to a given CLI session. "Active" is the
// claims-table convention (released_at IS NULL); there is NO `status` column on
// claims (a common misread — the task's status lives on `tasks`). Keyed on
// creator_session_id (the worktree's session), NOT builder_id: a builder may run
// many concurrent sessions, each with exactly one claim/one worktree, and that
// norm must keep working. This backs the session-scoped one-active-claim guard
// (shouldRefuseSessionClaim) that blocks commingled ships. NULL-session callers
// must never reach this — they are session-UNBOUND web claims (bind_session=false)
// that any CLI session may adopt; the route short-circuits before calling here.
async function getActiveClaimsForSession(creatorSessionId) {
  if (!creatorSessionId) return [];
  const { rows } = await pool.query(
    `SELECT c.id AS claim_id, c.task_id, c.creator_session_id, c.claimed_at,
            t.title
       FROM claims c JOIN tasks t ON t.id = c.task_id
      WHERE c.creator_session_id = $1 AND c.released_at IS NULL
      ORDER BY c.claimed_at`,
    [creatorSessionId]
  );
  return rows;
}

// The builder who most recently held a claim on this task — active OR resolved.
// Used by the `--regrade` ownership guard (#678): when a ship lands at
// `completed` but the subagent grader fails, the claim is already consumed, so
// the only record of "whose work this is" lives in the claims ledger. Returns
// the latest claim row by claim time (id is the tiebreak, monotonic), joined to
// the builder for github_login, plus the claim's head_sha (the grader's
// last-resort baseline), or null if the task was never claimed. Deliberately
// does NOT return the holder's rank — the regrade gate keys off the CALLER's
// rank (from /me), and rank is sensitive metadata not previously on this read
// surface (grader hacker finding, #678). Pure read, builder-agnostic.

async function getLastClaimHolder(taskId) {
  const { rows } = await pool.query(
    `SELECT c.builder_id, c.head_sha, c.released_at, c.outcome, c.claimed_at,
            b.github_login
       FROM claims c
       JOIN builders b ON b.id = c.builder_id
      WHERE c.task_id = $1
      ORDER BY c.claimed_at DESC, c.id DESC
      LIMIT 1`,
    [taskId]
  );
  return rows[0] ?? null;
}

// getTaskGrade — fetch the current grade row for a task (V4.R08 diff-hash
// reuse). Returns { diff_hash, passed, score, threshold, grader_kind,
// grader_version, rubric_scores, signals, notes_md } or null when no grade
// exists yet. Used by ship.js before the grade step to detect "same diff →
// skip the panel".
async function getTaskGrade(taskId) {
  const { rows } = await pool.query(
    `SELECT diff_hash, passed, score, threshold, grader_kind, grader_version,
            rubric_scores, signals, notes_md
       FROM task_grades
      WHERE task_id = $1
      LIMIT 1`,
    [taskId]
  );
  return rows[0] ?? null;
}

// -------------------------------------------------------------------------
// Cost log + summary carved into modules/economy/cost.js (BV1.R77 / ADR 0093
// §§1-2): logCost (the one cost_log writer), reconcileSessionCosts,
// costSummary, and costCalibrationSummary left this monolith. routes/cost.js
// + the reconciler + the public dashboard resolve them via the `reward` kernel
// port. (The DAY_SERIES_CTE constant they shared moved with them.)
// -------------------------------------------------------------------------

// -------------------------------------------------------------------------
// Recent shipped tasks (for status page feed)
// -------------------------------------------------------------------------

// GDS #191: optional `days` (positive integer) restricts to rows shipped within
// the trailing N days. `null` / `undefined` / `0` means no date filter (all time).
// Limit is still applied either way so the status page never pulls an unbounded
// payload. Default keeps the historical 30-row "recent" feel for callers that
// don't pass options.

async function recentShippedTasks(limit = 30, { days = null } = {}) {
  const params = [limit];
  let whereClause = `t.status = 'shipped'
        AND ${SMOKE_NOT_LIKE}`;
  if (days && Number.isFinite(days) && days > 0) {
    params.push(days);
    whereClause += `\n        AND t.shipped_at > now() - ($${params.length}::int * interval '1 day')`;
  }
  const { rows } = await pool.query(
    `SELECT t.id, t.title, t.value_summary, t.version_id, t.status, t.shipped_at, t.credits_reward,
            ${CREDITS_AWARDED_SUBQUERY} AS credits_awarded,
            t.est_minutes, t.actual_minutes,
            b.github_login, b.display_name
       FROM tasks t
       LEFT JOIN builders b ON b.id = t.shipped_by
      WHERE ${whereClause}
      ORDER BY t.shipped_at DESC NULLS LAST
      LIMIT $1`,
    params
  );
  return rows;
}

// Rolling median of actual/est ratio for a builder's last N shipped tasks.
// Returns null if there is insufficient data.

async function getEstVsActualRatio(builderId, limit = 10) {
  const { rows } = await pool.query(
    `SELECT actual_minutes::float / est_minutes AS ratio
       FROM tasks
      WHERE shipped_by = $1
        AND status = 'shipped'
        AND actual_minutes IS NOT NULL
        AND est_minutes IS NOT NULL
        AND est_minutes > 0
      ORDER BY shipped_at DESC NULLS LAST
      LIMIT $2`,
    [builderId, limit]
  );
  if (rows.length === 0) return null;
  const ratios = rows.map((r) => Number(r.ratio));
  const med = median(ratios);
  return { median: Math.round(med * 100) / 100, sample_size: ratios.length };
}

// Aggregated estimation drift for the public status page.
// Returns overall median ratio + per-version breakdown.

async function estimationDriftSummary() {
  const { rows } = await pool.query(
    `SELECT version_id,
            actual_minutes::float / est_minutes AS ratio
       FROM tasks
      WHERE status = 'shipped'
        AND actual_minutes IS NOT NULL
        AND est_minutes IS NOT NULL
        AND est_minutes > 0
        AND ${SMOKE_NOT_LIKE}
      ORDER BY shipped_at DESC NULLS LAST`
  );

  if (rows.length === 0) {
    return { overall_median: null, sample_size: 0, by_version: [] };
  }

  const allRatios = rows.map((r) => Number(r.ratio));
  const overallMedian = Math.round(median(allRatios) * 100) / 100;

  const byVersion = new Map();
  for (const r of rows) {
    if (!byVersion.has(r.version_id)) byVersion.set(r.version_id, []);
    byVersion.get(r.version_id).push(Number(r.ratio));
  }

  const versionBreakdown = Array.from(byVersion.entries()).map(([version_id, ratios]) => ({
    version_id,
    median_ratio: Math.round(median(ratios) * 100) / 100,
    task_count: ratios.length,
  }));

  return {
    overall_median: overallMedian,
    sample_size: allRatios.length,
    by_version: versionBreakdown,
  };
}


async function recentShippedTasksByBuilder(builderId, limit = 10) {
  const { rows } = await pool.query(
    `SELECT t.id, t.title, t.value_summary, t.version_id, t.status, t.shipped_at, t.credits_reward,
            ${CREDITS_AWARDED_SUBQUERY} AS credits_awarded
       FROM tasks t
      WHERE t.shipped_by = $1
        AND t.status = 'shipped'
        AND t.title NOT LIKE '\\_\\_smoke\\_\\_%' ESCAPE '\\'
      ORDER BY t.shipped_at DESC NULLS LAST
      LIMIT $2`,
    [builderId, limit]
  );
  return rows;
}

// -------------------------------------------------------------------------
// Achievement getters (listAchievements / getBuilderAchievements /
// getLeaderboardWithAchievements / getLockedAchievementsProgress /
// renderProgressText) carved into modules/economy/achievements.js (BV1.R77 /
// ADR 0093 §§1-2). me.js + public.js resolve them via the `reward` kernel port.
// -------------------------------------------------------------------------

// -------------------------------------------------------------------------
// Karma feed (V3.R28 / #248)
// -------------------------------------------------------------------------

// Last N karma_log entries for this builder, newest first. Powers the
// proposer's karma feed — the "Done when: visible in the proposer's karma
// feed" criterion for V3.R28. When R26 (#246) ships the profile-page karma
// trend UI, the page reads from this helper. Lightweight join to builders
// so the UI can render "granted by @<login>" without a second query.
//
// Append-only by construction (karma_log has no DELETE/UPDATE paths), so
// this is safe to call freely.

async function recentGradesForBuilder(builderId, limit = 5) {
  const { rows } = await pool.query(
    `SELECT g.task_id, g.score, g.passed, g.threshold, g.graded_at,
            g.grader_kind, g.grader_version, g.rubric_scores,
            COALESCE(g.signals->'issues', '[]'::jsonb) AS issues,
            COALESCE((g.signals->>'confidence')::numeric, NULL) AS confidence,
            t.title, t.kind, t.discipline
       FROM task_grades g
       JOIN tasks t ON t.id = g.task_id
      WHERE t.shipped_by = $1
      ORDER BY g.graded_at DESC
      LIMIT $2`,
    [builderId, limit]
  );
  return rows;
}

// Rolling 7d avg grade across ALL builders, plus pass-rate. Powers the
// public status tile + leaderboard hover.

async function rollingAvgGrade(days = 7) {
  const { rows } = await pool.query(
    `SELECT
       COUNT(*)::int                                            AS n,
       COALESCE(AVG(score), 0)::numeric(3,1)                    AS avg_score,
       ${gradePassCount('passed')} AS n_passed,
       COALESCE(MIN(score), 0)::numeric(3,1)                    AS min_score,
       COALESCE(MAX(score), 0)::numeric(3,1)                    AS max_score
       FROM task_grades
      WHERE graded_at >= now() - ($1 || ' days')::interval`,
    [String(days)]
  );
  return rows[0] || { n: 0, avg_score: 0, n_passed: 0, min_score: 0, max_score: 0 };
}

// Per-builder rolling avg, last `days` days. Powers the /builders profile.

async function gradeByBuilder(days = 30) {
  const { rows } = await pool.query(
    `SELECT
       t.shipped_by                                             AS builder_id,
       b.github_login,
       b.display_name,
       b.avatar_url,
       COUNT(*)::int                                            AS n,
       COALESCE(AVG(g.score), 0)::numeric(3,1)                  AS avg_score,
       ${gradePassCount('g.passed')} AS n_passed,
       ROUND(COALESCE(AVG(CASE WHEN g.passed THEN 1 ELSE 0 END), 0), 3) AS pass_rate,
       MAX(g.graded_at)                                         AS last_graded_at
       FROM task_grades g
       JOIN tasks t    ON t.id = g.task_id
       LEFT JOIN builders b ON b.id = t.shipped_by
      WHERE g.graded_at >= now() - ($1 || ' days')::interval
        AND t.shipped_by IS NOT NULL
      GROUP BY t.shipped_by, b.github_login, b.display_name, b.avatar_url
      ORDER BY n DESC, avg_score DESC`,
    [String(days)]
  );
  return rows;
}

// Public grade-trend timeline — array of { day, n, avg_score }. Powers a
// chart on status.amazonprimea.com.

async function gradeTrendByDay(days = 30) {
  const { rows } = await pool.query(
    `SELECT
       to_char(date_trunc('day', graded_at), 'YYYY-MM-DD') AS day,
       COUNT(*)::int AS n,
       AVG(score)::numeric(3,1) AS avg_score,
       ${gradePassCount('passed', { coalesce: false })} AS n_passed
       FROM task_grades
      WHERE graded_at >= now() - ($1 || ' days')::interval
      GROUP BY date_trunc('day', graded_at)
      ORDER BY day ASC`,
    [String(days)]
  );
  return rows;
}

// -------------------------------------------------------------------------
// Builder analytics — the "AI dev curve" (V3.R72 / #291, criterion C5).
//
// Per-builder historical time-series powering the /builders profile analytics
// panel and (aggregated, individuals stripped) the public /status ecosystem
// tile. Everything derives from existing columns — tasks.shipped_at /
// actual_minutes / est_minutes / kind, cost_log.builder_id (migration 046),
// claims.outcome, and task_grades — so no migration is needed. Smoke tasks
// (`__smoke__*`) are excluded everywhere, mirroring the other status feeds.
// One round trip per series, fanned out with Promise.all.
// (SMOKE_NOT_LIKE is now declared once at module top — task 1087, C3.)
// -------------------------------------------------------------------------


async function builderAnalytics(builderId, days = 90) {
  const d = String(days);
  const [shipRate, costTrend, durationTrend, gradeTrend, topKinds, headline, claimRollup] =
    await Promise.all([
      // Ships per day — the core "dev curve".
      pool.query(
        `SELECT to_char(date_trunc('day', shipped_at), 'YYYY-MM-DD') AS day,
                COUNT(*)::int AS n
           FROM tasks
          WHERE shipped_by = $1 AND status = 'shipped'
            AND shipped_at >= now() - ($2 || ' days')::interval
            AND ${SMOKE_NOT_LIKE}
          GROUP BY 1 ORDER BY 1 ASC`,
        [builderId, d]
      ),
      // Cost per day + tasks touched that day → cost-per-task in JS.
      pool.query(
        `SELECT to_char(date_trunc('day', recorded_at), 'YYYY-MM-DD') AS day,
                SUM(amount_usd)::numeric(12,2) AS total_usd,
                COUNT(DISTINCT task_id)::int AS n_tasks
           FROM cost_log
          WHERE builder_id = $1
            AND recorded_at >= now() - ($2 || ' days')::interval
          GROUP BY 1 ORDER BY 1 ASC`,
        [builderId, d]
      ),
      // Avg actual vs estimated minutes per day (the "getting faster" curve).
      pool.query(
        `SELECT to_char(date_trunc('day', shipped_at), 'YYYY-MM-DD') AS day,
                ROUND(AVG(actual_minutes))::int AS avg_actual,
                ROUND(AVG(est_minutes))::int AS avg_est
           FROM tasks
          WHERE shipped_by = $1 AND status = 'shipped'
            AND actual_minutes IS NOT NULL AND est_minutes IS NOT NULL
            AND shipped_at >= now() - ($2 || ' days')::interval
            AND ${SMOKE_NOT_LIKE}
          GROUP BY 1 ORDER BY 1 ASC`,
        [builderId, d]
      ),
      // Grade pass-rate per day (quality holding up as throughput rises?).
      pool.query(
        `SELECT to_char(date_trunc('day', g.graded_at), 'YYYY-MM-DD') AS day,
                COUNT(*)::int AS n,
                ${gradePassCount('g.passed', { coalesce: false })} AS n_passed,
                AVG(g.score)::numeric(3,1) AS avg_score
           FROM task_grades g
           JOIN tasks t ON t.id = g.task_id
          WHERE t.shipped_by = $1
            AND g.graded_at >= now() - ($2 || ' days')::interval
          GROUP BY 1 ORDER BY 1 ASC`,
        [builderId, d]
      ),
      // Top kinds shipped (all-time — a "what do I build" fingerprint).
      pool.query(
        `SELECT COALESCE(kind, 'unspecified') AS kind, COUNT(*)::int AS n
           FROM tasks
          WHERE shipped_by = $1 AND status = 'shipped'
            AND ${SMOKE_NOT_LIKE}
          GROUP BY 1 ORDER BY n DESC, kind ASC`,
        [builderId]
      ),
      // Window headline numbers.
      pool.query(
        `SELECT COUNT(*) FILTER (WHERE status = 'shipped')::int AS total_shipped,
                COALESCE(SUM(actual_minutes) FILTER (
                  WHERE status = 'shipped' AND actual_minutes IS NOT NULL), 0)::int AS total_minutes,
                COALESCE(ROUND(AVG(actual_minutes) FILTER (
                  WHERE status = 'shipped' AND actual_minutes IS NOT NULL)), 0)::int AS avg_duration_min
           FROM tasks
          WHERE shipped_by = $1
            AND ${SMOKE_NOT_LIKE}
            AND (shipped_at IS NULL OR shipped_at >= now() - ($2 || ' days')::interval)`,
        [builderId, d]
      ),
      // Confirmation rate — share of resolved claims that ended in a ship
      // (vs. abandoned / expired / partial). Distinct from the grade pass-rate.
      pool.query(
        `SELECT COUNT(*)::int AS resolved_claims,
                SUM(CASE WHEN outcome = 'shipped' THEN 1 ELSE 0 END)::int AS shipped_claims
           FROM claims
          WHERE builder_id = $1 AND outcome IS NOT NULL
            AND claimed_at >= now() - ($2 || ' days')::interval`,
        [builderId, d]
      ),
    ]);

  // task 1503: the "Cost / work ($)" chart plots per-day cost-per-work. The old
  // per_task = day's cost / COUNT(DISTINCT cost_log.task_id) flat-lined at 0 —
  // most cost rows carry a NULL task_id (session-token / infra / api spend), so
  // the DISTINCT count was 0 for those days and per_task fell to 0; on the rare
  // task-attributed day it spiked wildly. Cost (recorded_at) and works
  // (shipped_at) don't align by day, so a same-day ratio can't be meaningful.
  // Instead expose the CUMULATIVE cost-per-work as of each day — running total
  // spend / running works shipped — which is always defined once there's a ship
  // and converges to headline.cost_per_task.
  const shipsByDay = new Map(shipRate.rows.map((r) => [r.day, Number(r.n) || 0]));
  const costByDay = new Map(costTrend.rows.map((r) => [r.day, Number(r.total_usd) || 0]));
  const curveDays = Array.from(new Set([
    ...costTrend.rows.map((r) => r.day),
    ...shipRate.rows.map((r) => r.day),
  ])).sort();
  let cumCost = 0;
  let cumShips = 0;
  const perWorkByDay = new Map();
  for (const day of curveDays) {
    cumCost += costByDay.get(day) || 0;
    cumShips += shipsByDay.get(day) || 0;
    perWorkByDay.set(day, cumShips > 0 ? Math.round((cumCost / cumShips) * 100) / 100 : 0);
  }
  const cost_trend = costTrend.rows.map((r) => ({
    day: r.day,
    total_usd: Number(r.total_usd),
    n_tasks: r.n_tasks,
    // Cumulative cost-per-work as of this day (see note above). Converges to
    // headline.cost_per_task; never the old all-zero flat line.
    per_work: perWorkByDay.get(r.day) ?? 0,
  }));
  const totalCost = cost_trend.reduce((s, r) => s + r.total_usd, 0);

  const h = headline.rows[0] || { total_shipped: 0, total_minutes: 0, avg_duration_min: 0 };
  const c = claimRollup.rows[0] || { resolved_claims: 0, shipped_claims: 0 };
  const grades = gradeTrend.rows;
  const gradedN = grades.reduce((s, r) => s + r.n, 0);
  const gradedPassed = grades.reduce((s, r) => s + r.n_passed, 0);

  return {
    window_days: days,
    ship_rate: shipRate.rows, // [{ day, n }]
    cost_trend, // [{ day, total_usd, n_tasks, per_work }] — per_work is cumulative (task 1503)
    duration_trend: durationTrend.rows, // [{ day, avg_actual, avg_est }]
    grade_trend: grades, // [{ day, n, n_passed, avg_score }]
    top_kinds: topKinds.rows, // [{ kind, n }]
    headline: {
      total_shipped: h.total_shipped,
      total_cost_usd: Math.round(totalCost * 100) / 100,
      cost_per_task: h.total_shipped > 0 ? Math.round((totalCost / h.total_shipped) * 100) / 100 : 0,
      avg_duration_min: h.avg_duration_min,
      confirmation_rate: c.resolved_claims > 0 ? Math.round((c.shipped_claims / c.resolved_claims) * 100) / 100 : null,
      resolved_claims: c.resolved_claims,
      grade_pass_rate: gradedN > 0 ? Math.round((gradedPassed / gradedN) * 100) / 100 : null,
      graded_n: gradedN,
    },
  };
}

// Ecosystem-wide aggregate — the SAME shape of series as builderAnalytics but
// summed across every builder, with NO per-builder identity. This is the only
// analytics surface the public /status page is allowed to render (individuals
// stay behind the authenticated /analytics/builder/:id route). Grade + cost
// daily series already have public feeds (/public/grades, /public/cost-summary),
// so this adds just the ship-rate, duration, top-kinds, and headline aggregates.

async function ecosystemAnalytics(days = 90) {
  const d = String(days);
  const [shipRate, durationTrend, topKinds, headline] = await Promise.all([
    pool.query(
      `SELECT to_char(date_trunc('day', shipped_at), 'YYYY-MM-DD') AS day,
              COUNT(*)::int AS n
         FROM tasks
        WHERE status = 'shipped' AND shipped_by IS NOT NULL
          AND shipped_at >= now() - ($1 || ' days')::interval
          AND ${SMOKE_NOT_LIKE}
        GROUP BY 1 ORDER BY 1 ASC`,
      [d]
    ),
    pool.query(
      `SELECT to_char(date_trunc('day', shipped_at), 'YYYY-MM-DD') AS day,
              ROUND(AVG(actual_minutes))::int AS avg_actual,
              ROUND(AVG(est_minutes))::int AS avg_est
         FROM tasks
        WHERE status = 'shipped'
          AND actual_minutes IS NOT NULL AND est_minutes IS NOT NULL
          AND shipped_at >= now() - ($1 || ' days')::interval
          AND ${SMOKE_NOT_LIKE}
        GROUP BY 1 ORDER BY 1 ASC`,
      [d]
    ),
    pool.query(
      `SELECT COALESCE(kind, 'unspecified') AS kind, COUNT(*)::int AS n
         FROM tasks
        WHERE status = 'shipped' AND shipped_by IS NOT NULL
          AND shipped_at >= now() - ($1 || ' days')::interval
          AND ${SMOKE_NOT_LIKE}
        GROUP BY 1 ORDER BY n DESC, kind ASC`,
      [d]
    ),
    pool.query(
      `SELECT COUNT(*)::int AS total_shipped,
              COUNT(DISTINCT shipped_by)::int AS active_builders,
              COALESCE(ROUND(AVG(actual_minutes) FILTER (
                WHERE actual_minutes IS NOT NULL)), 0)::int AS avg_duration_min
         FROM tasks
        WHERE status = 'shipped' AND shipped_by IS NOT NULL
          AND shipped_at >= now() - ($1 || ' days')::interval
          AND ${SMOKE_NOT_LIKE}`,
      [d]
    ),
  ]);

  const h = headline.rows[0] || { total_shipped: 0, active_builders: 0, avg_duration_min: 0 };
  return {
    window_days: days,
    ship_rate: shipRate.rows,
    duration_trend: durationTrend.rows,
    top_kinds: topKinds.rows,
    headline: {
      total_shipped: h.total_shipped,
      active_builders: h.active_builders,
      avg_duration_min: h.avg_duration_min,
    },
  };
}

// -------------------------------------------------------------------------
// audit_log (V3.R35 / #256) — append-only stream of authenticated writes.
//
// The writing middleware (src/bongos/middleware/audit.js) calls insertAuditLog
// AFTER the response has been sent, wrapped in try/catch — so the request
// path never blocks on this insert and a DB failure here can never break a
// real user request. The reader is the archon-only GET /api/gds/audit-log
// endpoint backed by listAuditLog below (paginated, newest-first).
// -------------------------------------------------------------------------

// insertAuditLog — the append-only audit write — moved to ./db-kernel (BV1.R69 /
// ADR 0091 §2: audit is a kernel primitive). Imported + re-exported at the top
// of this file; the writing middleware + the listAuditLog reader below unchanged.

// listAuditLog — paginated, newest-first. Clamps limit to 1..500 and offset to
// >= 0 at the route layer; this helper trusts its inputs.
//
// Optional filters:
//   builderId — only entries for that builder
//   method    — one of POST/PATCH/PUT/DELETE
//   surface   — originating surface (e.g. 'discord_bot'); the literal string
//               'none' selects direct human writes (surface IS NULL). This is
//               what makes the documented forensic isolation of bot-origin
//               writes actually queryable through the API, not just via psql
//               (ADR 0033 §1 / F4 finding).

async function logGradeAttempt({ taskId, builderId, passed, score }, queryFn) {
  const q = queryFn || ((text, params) => pool.query(text, params));
  try {
    await q(
      `INSERT INTO grade_attempts (task_id, builder_id, passed, score) VALUES ($1, $2, $3, $4)`,
      [
        Number(taskId),
        builderId == null ? null : Number(builderId),
        passed === true,
        score == null ? null : Number(score),
      ]
    );
    return true;
  } catch (err) {
    console.error('[gds] logGradeAttempt (non-blocking):', err && err.message ? err.message : err);
    return false;
  }
}

// countGradeAttempts — how many times a task has been graded (re-grade thrash).

async function countGradeAttempts(taskId, queryFn) {
  const q = queryFn || ((text, params) => pool.query(text, params));
  const { rows } = await q(`SELECT COUNT(*)::int AS n FROM grade_attempts WHERE task_id = $1`, [Number(taskId)]);
  return rows[0] ? rows[0].n : 0;
}

// ---- security_docs: Archon-only sensitive security documents (task 991) -----
//
// The DATED security engagement reports (exploit detail) live in the DB, NOT in
// the git clone (threat-model §6.3 / ADR 0020). The route layer gates every read
// to requireRank('archon'); these helpers are pure parameterized SQL.

// Upsert a doc by slug — insert if new, update title/content (and bump
// updated_at) if the slug already exists. Returns the full row.

async function acquireMergeLease({ key = 'main', holder, ttlSeconds = 600 } = {}) {
  if (!holder) throw new Error('acquireMergeLease: holder is required');
  const { rows } = await pool.query(
    `INSERT INTO merge_lease (key, holder, acquired_at, expires_at)
          VALUES ($1, $2, now(), now() + make_interval(secs => $3))
     ON CONFLICT (key) DO UPDATE
          SET holder = EXCLUDED.holder, acquired_at = now(), expires_at = EXCLUDED.expires_at
        WHERE merge_lease.expires_at <= now() OR merge_lease.holder = EXCLUDED.holder
     RETURNING holder, expires_at`,
    [key, holder, ttlSeconds]
  );
  if (rows.length) return { acquired: true, holder, expires_at: rows[0].expires_at };
  const cur = await pool.query('SELECT holder, expires_at FROM merge_lease WHERE key = $1', [key]);
  return { acquired: false, holder: cur.rows[0]?.holder ?? null, expires_at: cur.rows[0]?.expires_at ?? null };
}

// Release the lease IFF still held by this holder (defensive against releasing a lease that was
// already reclaimed + re-acquired by someone else after a TTL expiry). Returns { released }.

async function releaseMergeLease({ key = 'main', holder } = {}) {
  if (!holder) throw new Error('releaseMergeLease: holder is required');
  const { rowCount } = await pool.query(
    'DELETE FROM merge_lease WHERE key = $1 AND holder = $2',
    [key, holder]
  );
  return { released: rowCount > 0 };
}

// Current lease holder + expiry (null if free). Read-only; safe on the request path.

async function mergeLeaseStatus({ key = 'main' } = {}) {
  const { rows } = await pool.query(
    `SELECT key, holder, acquired_at, expires_at, (expires_at <= now()) AS expired
       FROM merge_lease WHERE key = $1`,
    [key]
  );
  return rows[0] ?? null;
}

// Peer-vote → karma fold-in (V3.R25 / #245). The exact transaction that
// POST /tasks/peer-votes/tally runs, extracted so the route AND the
// server-internal weekly timer (the carved autonomy module's poller,
// modules/autonomy/pollers/routine-timers.js — it reaches this via the doorway
// `api.tallyPeerVotes`, BV1.R83 / ADR 0078 amendment) share ONE code path and
// can never diverge on tally semantics. Idempotent:
// only folds matured (>= lag days), not-yet-tallied votes, then stamps them
// tallied_at = now() — a re-run within the week finds nothing new. Writes
// karma_log with granted_by = NULL (a system fold-in has no requester); the
// route's Archon gate is an HTTP-auth concern, not a property of this SQL. The
// `FOR UPDATE OF pv` row lock is the real multi-instance guard: two processes
// (e.g. the timer + a manual run, or a second instance on the same DB) can't
// double-fold the same votes — the loser blocks, then sees tallied_at set.

const PEER_VOTE_KARMA_LAG_DAYS = 7;


async function tallyPeerVotes() {
  return withTx(async (client) => {
    const { rows: matured } = await client.query(
      `SELECT pv.id, t.shipped_by AS builder_id, pv.vote
         FROM peer_votes pv
         JOIN tasks t ON t.id = pv.target_task_id
        WHERE pv.tallied_at IS NULL
          AND pv.recorded_at <= now() - ($1::int * interval '1 day')
          AND t.shipped_by IS NOT NULL
        FOR UPDATE OF pv`,
      [PEER_VOTE_KARMA_LAG_DAYS]
    );
    const netByBuilder = new Map();
    const voteIds = [];
    for (const r of matured) {
      voteIds.push(r.id);
      netByBuilder.set(r.builder_id, (netByBuilder.get(r.builder_id) || 0) + r.vote);
    }
    const karmaRows = [];
    for (const [builderId, net] of netByBuilder) {
      if (net === 0) continue; // no net signal → no karma row, but still mark tallied
      await client.query(
        `INSERT INTO karma_log (builder_id, delta, reason, granted_by)
         VALUES ($1, $2, 'peer_vote_weekly', NULL)`,
        [builderId, net]
      );
      karmaRows.push({ builder_id: builderId, delta: net });
    }
    if (voteIds.length) {
      await client.query(
        `UPDATE peer_votes SET tallied_at = now() WHERE id = ANY($1::bigint[])`,
        [voteIds]
      );
    }
    return {
      ok: true,
      votes_tallied: voteIds.length,
      builders_credited: karmaRows.length,
      karma: karmaRows,
      lag_days: PEER_VOTE_KARMA_LAG_DAYS,
    };
  });
}


module.exports = {
  tallyPeerVotes,
  PEER_VOTE_KARMA_LAG_DAYS,
  RANKS,
  listVersions,
  getVersion,
  versionProgress,
  createVersion,
  createGoal,
  getGoal,
  getGoalDependencies,
  listGoals,
  reorderGoals,
  setGoalStatus,
  achieveGoalIfComplete,
  addGoalMember,
  removeGoalMember,
  listGoalMembers,
  isGoalMember,
  getGoalMember,
  setGoalMemberRole,
  transferGoalOwnership,
  listActiveClaimsForTasks,
  requestClaimRelease,
  rescopeTaskTouches,
  addGoalScopeModules,
  setGoalSuccessor,
  // Private goals: visibility + the invite/join-request queue (task 1951 / ADR 0112).
  setGoalVisibility,
  createMembershipRequest,
  getMembershipRequest,
  resolveMembershipRequest,
  acceptMembershipRequestAndAddMember,
  listInboxFor,
  listPendingRequestsForGoal,
  listCriteriaForGoal,
  createTask,
  generalGoalIdForVersion,
  findTaskBySourceRef,
  getTask,
  listTasks,
  updateTaskGoal,
  createCriterion,
  updateTaskKind,
  updateTaskDiscipline,
  updateTaskNewcomerFriendly,
  updateTaskRequiresRank,
  xenosClaimAllowed,
  rankAllowsTask,
  REQUIRES_RANK_TIER,
  // BV1.R69/R86 (ADR 0091 §2 + ADR 0093): the rank ladder moved to db-kernel and
  // is re-imported at the top of this file via the doorway (line 32). The lifecycle
  // carve dropped it from THIS module.exports, so `db.LIVE_RANK_LADDER` read undefined
  // in routes/tasks.js — its requires_rank validation did `new Set(undefined)` (an
  // empty set that rejects every value), then threw on `undefined.join(...)` while
  // building the 400 body. That throw is an unhandled rejection in the async handler
  // (outside the try/catch; Express 4 doesn't catch async rejections), so the request
  // hung forever → Cloudflare 524. Re-exporting it closes the hole. (task 1675)
  LIVE_RANK_LADDER,
  deriveRequiredRank,
  highestRank,
  rewardMissing,
  suggestCreditsReward,
  REWARD_SUGGESTION_CAP,
  rewardGateAssignment,
  rewardGateError,
  setCreditsReward,
  THETES_GRADUATION_THRESHOLD,
  qualifiesForThetesGraduation,
  countShippedTasksForBuilder,
  singleRungPromotionError,
  disambiguateWorktreeName,
  updateTaskParallelSafe,
  updateTaskSecuritySensitive,
  updateTaskAutomationTag,
  updateTaskModuleKey,
  listClaimableTasks,
  capNewcomerTasks,
  taskTouchesProtectedPath, // SR-12 / G2 (task 994): autonomous-fit protected-path exclusion (pure, testable)
  rankCrossDisciplineRecommendations,
  listActiveClaims,
  updateTaskStatus,
  getTaskDependencies,
  getTaskDependents,
  addTaskDependency,
  removeTaskDependency,
  setTaskDependencies,
  findDependencyCycle,
  findCycle,
  addDependency,
  removeDependency,
  getDependencies,
  unsatisfiedDeps,
  parseCriterionRef,
  resolveCriterionIds,
  getTaskCriteria,
  addTaskCriterion,
  removeTaskCriterion,
  linkTaskCriteria,
  claimTask,
  claimTasksBatch,
  releaseClaimsBatch,
  validateClaimBatch,
  resolveClaim,
  confirmTask,
  abandonTask,
  applyGrade,
  shipTask,
  listConfirmedTasksForReconcile, // task 1134 — server-owned publish reconciler feed
  setClaimPublishedSha, // task 1547 — record the SERVER-pushed tip for per-task land proof
  getClaimPublishedSha, // task 1547 — read the published tip for the reconcile gate
  getActiveClaimsForBuilder,
  getActiveClaimsForSession,
  getLastClaimHolder, // --regrade ownership guard (#678)
  getTaskGrade,       // V4.R08 — diff-hash reuse check before grading
  getBuildersRoster,
  getActiveClaimsForBuilderWithStale,
  releaseClaimOnBehalf,
  recentShippedTasks,
  recentShippedTasksByBuilder,
  getEstVsActualRatio,
  estimationDriftSummary,
  recentGradesForBuilder,
  rollingAvgGrade,
  gradeByBuilder,
  gradeTrendByDay,
  builderAnalytics,
  ecosystemAnalytics,
  createOverrideRequest,
  listOverrideRequests,
  decideOverrideRequest,
  logGradeAttempt,
  countGradeAttempts,
  acquireMergeLease,
  releaseMergeLease,
  mergeLeaseStatus,
};
