-- 022_v3_reconcile_dep_gated_status.sql
-- GDS-V3 / task 347 / V3.R02-followup — Reconcile dep-gated task status.
--
-- Migration 021 wired dependency edges onto existing GDS-V3 tasks
-- retroactively, but did not demote tasks that were ALREADY 'ready' and now
-- carry an unshipped dependency. Result: ~51 tasks displayed as 'ready' in
-- /builder-start yet returned 409 DEPS_NOT_SHIPPED on claim (the claim-time
-- guard in src/bongos/db.js caught them). The queue lied about what was
-- actually claimable.
--
-- Fix: demote every 'ready' task that has at least one unshipped dependency
-- back to 'backlog'. The auto-promotion trigger from migration 020 then
-- re-promotes each one to 'ready' the moment its last dependency ships.
--
-- Invariant restored: a task is 'ready' only if all of its dependencies are
-- 'shipped'. Spikes are unaffected (they already live in backlog by policy).
--
-- Idempotent: the demotion is conditioned on the presence of an unshipped
-- dependency, so re-running after deps ship is a no-op. Tasks already in
-- backlog are not in scope (WHERE status = 'ready').
BEGIN;

UPDATE tasks t
   SET status = 'backlog',
       updated_at = now()
 WHERE t.version_id = 'GDS-V3'
   AND t.status = 'ready'
   AND EXISTS (
     SELECT 1
       FROM task_dependencies d
       JOIN tasks dep ON dep.id = d.depends_on_task_id
      WHERE d.task_id = t.id
        AND dep.status <> 'shipped'
   );

-- Bump migration counter (021 left it at 22, which this file consumes) + register.
UPDATE migration_counter SET next_number = GREATEST(next_number, 23) WHERE id = 1;
INSERT INTO schema_migrations (version) VALUES ('022_v3_reconcile_dep_gated_status')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
