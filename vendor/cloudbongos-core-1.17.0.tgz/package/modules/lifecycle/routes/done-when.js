// done_when_criteria routes — three endpoints:
//   GET  /api/bongos/versions/:id/done-when            — public, 60s cache
//   POST /api/bongos/done-when/:criterionId/satisfy    — auth
//   POST /api/bongos/done-when/:criterionId/unsatisfy  — auth
//
// The status page renders the GET response under each version progress card
// (see modules/status-ui/public/status.js → renderDoneWhenList). The POST endpoints are
// for the operator (web UI / curl) to flip criteria as they're satisfied.
//
// See src/bongos/done-when.js for the DB helpers and the rationale comment.

const express = require('express');
// Intra-module + the published doorway — a module never requires a core internal.
const api = require('../../../src/module-api');
const auth = api;
const doneWhen = require('../done-when');
const db = require('../db');
const { validateOrRespond, parseId, asyncHandler, LIMITS } = api;

module.exports = function buildDoneWhenRouter() {
  const router = express.Router();

  // Public: status.amazonprimea.com fetches this every 60s alongside other
  // public/* surfaces. No auth, same Cache-Control posture as the other
  // status feeds.
  // rank: public — status.amazonprimea.com fetches every 60s anonymously.
  router.get('/versions/:id/done-when', asyncHandler('GET /versions/:id/done-when', async (req, res) => {
    const versionId = String(req.params.id || '').trim();
    if (!versionId) return res.fail('version_id_required', 400);
    // Version → Goals → Criteria (ADR 0086 §2 / BV1.R58): the response now also
    // carries `goals` (criteria grouped under their goal). `criteria` keeps its
    // flat shape so existing consumers are unaffected.
    const { criteria, goals } = await doneWhen.criteriaGroupedByGoal(versionId);
    res.set('Cache-Control', 'public, max-age=60');
    res.json({ version_id: versionId, criteria, goals });
  }, { errorCode: 'list_failed' }));

  // Auth (Archon): create a done-when criterion at RUNTIME. ADR 0105 moved
  // scope-truth seeds (versions/goals/criteria) out of the normal migration path,
  // so a brand-new criterion on a RUNNING instance can no longer be added by a
  // plain migration (migrations/instance/ applies only under the owner opt-in
  // GDS_APPLY_INSTANCE_SEEDS=1, a DR step). This is the vector a planning session
  // uses to add a criterion to a live version WITHOUT a droplet migrate. Archon-
  // only — done_when_criteria is scope-shaping (mirrors the criterion-proposal
  // ratify gate). Pinned in route-rank-check.MODULE_EXPECTED_RANKS.
  // rank: archon — scope-truth write (a new criterion on a version).
  router.post('/versions/:id/done-when', auth.requireBuilder, auth.requireRank('archon'), asyncHandler('POST /versions/:id/done-when', async (req, res) => {
    const versionId = String(req.params.id || '').trim();
    if (!versionId) return res.fail('version_id_required', 400);
    if (validateOrRespond(req, res, {
      criterion_id: { required: true, type: 'string', minLength: 1, maxLength: 64 },
      criterion_md: { required: true, type: 'string', minLength: 1, maxLength: LIMITS.DESCRIPTION },
      goal_id: { type: 'integer', min: 1 },
      sort_order: { type: 'integer', min: 0 },
    })) return;
    const version = await db.getVersion(versionId);
    if (!version) return res.fail('version_not_found', { status: 404, message: `No version '${versionId}'.` });
    // A goal_id, if given, must exist AND belong to this version.
    if (req.body.goal_id != null) {
      const goal = await db.getGoal(req.body.goal_id);
      if (!goal || String(goal.version_id) !== String(versionId)) {
        return res.fail('bad_goal_id', { status: 400, message: `goal_id ${req.body.goal_id} does not exist on version '${versionId}'.` });
      }
    }
    try {
      const criterion = await db.createCriterion({
        versionId,
        criterionId: req.body.criterion_id,
        criterionMd: req.body.criterion_md,
        goalId: req.body.goal_id ?? null,
        sortOrder: req.body.sort_order ?? null,
      });
      res.status(201).json({ ok: true, criterion });
    } catch (err) {
      if (err && err.code === '23505') {
        return res.fail('criterion_exists', { status: 409, message: `criterion_id '${req.body.criterion_id}' already exists on version '${versionId}'.` });
      }
      console.error('[gds] POST /versions/:id/done-when', err);
      return res.fail('create_failed', { status: 500, message: 'internal error' });
    }
  }, { errorCode: 'create_failed' }));

  // Auth (Metic+): the criterion review queue — every criterion auto-flagged
  // "met — pending review" (≥1 linked task, all shipped, not yet confirmed),
  // derived from task_criteria + ship status (ADR 0086 §6 / BV1.R63). Powers the
  // /goal-review skill. Optional ?version= scopes to one version. Gated Metic+ to
  // match the satisfy route below — this is the planner's closing queue, not a
  // public surface.
  // rank: metic+archon — the planner review queue (mirrors the satisfy gate).
  router.get('/done-when/pending-review', auth.requireBuilder, auth.requireRank('metic', 'archon'), asyncHandler('GET /done-when/pending-review', async (req, res) => {
    const versionId = String(req.query.version || '').trim() || null;
    const criteria = await doneWhen.listPendingReviewCriteria({ versionId });
    res.json({ criteria, count: criteria.length });
  }, { errorCode: 'pending_review_failed' }));

  // Auth (Metic+): confirm a criterion — flip it to satisfied. Accepts optional
  // satisfied_by_task_id so the UI can show which ship-task fulfilled it. When the
  // criterion belongs to a goal and was its LAST unsatisfied one, the goal auto-
  // flips open→achieved (ADR 0086 §6 / BV1.R63). Re-ranked Archon→Metic+ so the
  // planner — not only the Archon — closes the criterion/goal loop; the route is
  // pinned in route-rank-check.EXPECTED_RANKS so a further downgrade is caught.
  // rank: metic+archon — criterion confirmation + goal auto-achieve (the closing loop).
  router.post('/done-when/:criterionId/satisfy', auth.requireBuilder, auth.requireRank('metic', 'archon'), asyncHandler('POST /done-when/:criterionId/satisfy', async (req, res) => {
    if (validateOrRespond(req, res, {
      satisfied_by_task_id: { type: 'integer', min: 1 },
    })) return;
    const id = parseId(req, res, { param: 'criterionId', code: 'bad_criterion_id' });
    if (id === null) return;
    // Validate first so a missing id is a clean 404 rather than a
    // 200-with-null-body (acceptance criterion #5).
    const existing = await doneWhen.getCriterion(id);
    if (!existing) return res.fail('criterion_not_found', 404);
    const taskId = req.body?.satisfied_by_task_id ?? null;
    const updated = await doneWhen.markCriterion(id, taskId);
    // Auto-achieve: confirming a goal's last criterion flips it open→achieved.
    // A criterion with no goal (goal_id NULL) completes no goal.
    let goalResult = { achieved: false, goal: null };
    if (updated?.goal_id != null) {
      goalResult = await db.achieveGoalIfComplete({ goalId: updated.goal_id });
    }
    res.json({ criterion: updated, goal_achieved: goalResult.achieved, goal: goalResult.goal });
  }, { errorCode: 'satisfy_failed' }));

  // Auth: flip a criterion back to unsatisfied (rare; for corrections).
  // rank: archon — un-flip a criterion; same gate as satisfy.
  router.post('/done-when/:criterionId/unsatisfy', auth.requireBuilder, auth.requireRank('archon'), asyncHandler('POST /done-when/:criterionId/unsatisfy', async (req, res) => {
    const id = parseId(req, res, { param: 'criterionId', code: 'bad_criterion_id' });
    if (id === null) return;
    const existing = await doneWhen.getCriterion(id);
    if (!existing) return res.fail('criterion_not_found', 404);
    const updated = await doneWhen.unmarkCriterion(id);
    res.json({ criterion: updated });
  }, { errorCode: 'unsatisfy_failed' }));

  return router;
};
