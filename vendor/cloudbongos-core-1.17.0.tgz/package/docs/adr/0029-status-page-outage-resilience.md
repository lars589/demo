# 0029 — Status-page outage resilience: measure from outside, host off-box, prevent at the source

- **Status:** Accepted. **Slice 1 (external prober) built this session** under task **[#565](https://example.com/builders#/task/565)**: `.github/workflows/status-probe.yml` + `scripts/status-probe.mjs` + this ADR. **Follow-up B (page off-box) has since SHIPPED** — `status.example.com` is served off the droplet from GitHub Pages (repo `example-owner/example-status`), synced by `.github/workflows/sync-status-mirror.yml`. Incident-backfill (follow-up C) is **not yet built**.
- **Date:** 2026-06-03
- **Deciders:** Lars Kristensen (Archon), Claude
- **Track:** `internal` (the status dashboard / The Watch)
- **Context tasks:** **[#565](https://example.com/builders#/task/565)** (slice 1 — external prober + alert + this ADR) · **blocker [#6](https://example.com/builders#/blocker/6)** (DigitalOcean backup payment + billing alerts — root-cause prevention, Lars-only) · follow-up **B** (move `public-status/` off-box + CORS on `/api/gds/public/*` + repoint `status.` DNS) · follow-up **C** (backfill the 2026-06-03 incident into the honest uptime history).
- **Relates to:** [ADR 0003 — Cloudflare Origin Cert](<redacted>.md) (the CF↔origin leg) · the in-process poller [`src/bongos/uptime-poller.js`](../../src/bongos/uptime-poller.js) (now demoted from public source-of-truth) · [`docs/recipes/ops-gotchas.md`](../recipes/ops-gotchas.md) (the new "status page shared fate" gotcha).

## Context

On **2026-06-03, ~10:00–14:39 UTC (~4h 39m)**, DigitalOcean **powered off the production droplet after a payment-method charge failed**. The game *and* the status page went dark together, and Lars discovered it by eye — via a Cloudflare 522 — with no alert.

Three independent design flaws turned a billing hiccup into a silent, invisible outage:

1. **The status page shares fate with the product.** `status.example.com` is served by the **same Node process on the same droplet** as the game. Whatever kills the product kills the status page. A status page's entire job is to be up when the product is down.
2. **It measures itself from inside itself.** [`src/bongos/uptime-poller.js`](../../src/bongos/uptime-poller.js) runs *in that Node process* and probes `http://127.0.0.1`. When the droplet died, the poller died — so it wrote **zero rows** during the outage (not "down" rows — *none*). The Watch renders that gap as 100% green. **A monitor that lives inside the thing it monitors can never witness its own death.** It also can't see Cloudflare, DNS, or "is the box reachable from the world" — only "can the server talk to itself."
3. **Nothing alerted a human.** Detection depended on someone noticing.

The cardinal industry rule (GitHub → `githubstatus.com` on Atlassian's infra; status accounts on a separate platform as a backup channel) is: **a status page must not share fate with the system it reports on, and availability must be measured from outside it.**

## Decision

Keep The Watch's custom design (Lars's call), but fix all three flaws as three independent layers:

### 1. Measure from outside (built this session — slice 1, [#565](https://example.com/builders#/task/565))
An **external prober runs on GitHub-hosted runners** — off our DigitalOcean infrastructure — and probes the **public** URL exactly as a visitor would:
- [`scripts/status-probe.mjs`](../../scripts/status-probe.mjs) — dependency-free Node; probes `https://example.com/healthz` with in-run confirmation retries (UP if any of 3 attempts is a 200; DOWN only if all fail, which suppresses transient blips). Appends to `history.jsonl`, rewrites `status.json` (snapshot + 24h/7d/90d uptime), prunes to 90 days.
- [`.github/workflows/status-probe.yml`](../../.github/workflows/status-probe.yml) — `*/5` cron + `workflow_dispatch`; publishes the result to an **orphan `status-data` branch** (off-box, web-readable, survives a droplet outage); **fails the job when the site is confirmed down**, which emails the repo owner — the alert.

### 2. Host the page off-box (follow-up B — SHIPPED)
`status.example.com` is now served off the droplet from **GitHub Pages** (repo `example-owner/example-status`), synced by [`.github/workflows/sync-status-mirror.yml`](../../.github/workflows/sync-status-mirror.yml); the page no longer shares fate with the product. Original plan, for the record:
Move `public-status/` to free static hosting **separate from the droplet** (Cloudflare Pages or GitHub Pages). The page shell + the **uptime/incident section** are served off-box and read the `status-data` source, so they stay truthful during an outage. The rich GDS panels (treasury, grades, progress) keep loading client-side from `example.com/api/gds/public/*` and **degrade gracefully** to "origin unreachable" when the droplet is down (requires adding CORS to those public routes). Then repoint `status.example.com` DNS at the off-box host.

### 3. Prevent at the source + alert (blocker [#6](https://example.com/builders#/blocker/6))
The actual root cause was billing. Add a **backup payment method + billing/balance alerts** on DigitalOcean (Lars-only — DO account access). Preventing the outage beats reporting it. The slice-1 prober is the detection net if prevention ever fails.

## Why this mechanism (and the trade-offs)

- **Free and already-owned.** The repo is on GitHub (`example-owner/example`); GitHub Actions + a git branch cost $0 and run off our droplet. Prior art: the open-source **Upptime** project is exactly this pattern (Actions probe → commit to git → issues on downtime → Pages status site); we build a minimal, theme-preserving version instead of adopting its UI.
- **Trade-offs, accepted for a bootstrapped project:**
  - GitHub cron granularity is **5 min** and runs can be delayed under load → detection latency is minutes, not seconds.
  - Scheduled workflows fire **only from the default branch**, so the monitor is live only once [#565](https://example.com/builders#/task/565) merges to `main`; use the "Run workflow" button until then.
  - GitHub disables schedules after **60 days of repo inactivity** (not a concern at our daily-commit cadence).
  - The alert is a **failed-run email** to the repo owner; richer alerting (auto-opened issue, Google-Chat webhook reusing `scripts/chat/`, or Better Stack SMS/phone) is a documented upgrade path.

## Alternatives considered

- **Hosted status SaaS (Better Stack / UptimeRobot / Atlassian Statuspage).** The most common professional answer; $0 on free tiers; sub-minute checks + real SMS/phone alerting + their own hosted page. **Rejected as the primary** because Lars wants to keep the custom Greek "The Watch" design and full ownership. Retained as the **upgrade path** if we later want faster checks or phone alerts — it composes with this design (it can be the prober feeding our off-box page).
- **Keep self-measurement but render gaps as "unknown" (grey) instead of green.** Makes the page honest but still dies with the product and still can't alert. Insufficient on its own.
- **A second always-on box to host the status page.** Defeats the cost posture ($5k/yr budget) and just moves the shared-fate problem.

## Consequences

- [`src/bongos/uptime-poller.js`](../../src/bongos/uptime-poller.js) is **no longer the public source of truth** for availability. It stays useful as an *internal* component-liveness signal (can the process reach its own DB?), but The Watch's availability section will read the off-box `status-data` (follow-up B). Whether to retire the in-process poller entirely is decided in B.
- Honest uptime history starts accumulating off-box from the first prober run.
- The 2026-06-03 incident is backfilled into the record (follow-up C) so The Watch stops claiming 100%.
- The lesson — "a status page must not share fate with the product, and cannot measure itself" — is captured as **GDS learning `#35`** and a new "Status page + monitoring" section in [`docs/recipes/ops-gotchas.md`](../recipes/ops-gotchas.md) (incl. the 522 / total-outage diagnostic runbook).
- Because it's off-box, `status.example.com` doubles as the fallback when the hall (`example.com/builders`, CLAUDE.md's canonical doc-reading surface — [#758](https://example.com/builders#/task/758)) is unreachable — it won't render full docs, but it stays up to show whether the droplet itself is down.
