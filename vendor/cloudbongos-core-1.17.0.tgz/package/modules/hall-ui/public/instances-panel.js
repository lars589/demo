// instances-panel.js — the "Instances" hall widget (provisioning module, ADR 0111
// §1, task 1947 / BV1-prov-P6).
//
// Surfaces provisioning_instances STATE + cost estimate: an owner sees their own
// instance(s) + request status; an Archon additionally sees the fleet roster + the
// cost ledger total. One cohesive panel — the caller's own instances always, the
// fleet appended only when /me returns rank 'archon'.
//
// GATED on the provisioning module: registered with module:'provisioning', so
// contributeHallWidget (dom-utils.js) drops it entirely on an instance that hasn't
// enabled the module — the belt-and-suspenders to window.__MODULES__ (ADR 0062 §4).
//
// Reuses the dev-box hall pattern: a self-contained, self-fetching widget (the
// goals.js precedent), living in the hall's own served dir so it serves on both the
// apex and the builders subdomain. Reads the P1 routes only:
//   GET /provisioning/instances                 (own)
//   GET /provisioning/fleet                      (archon)
//   GET /provisioning/fleet/cost-ledger          (archon)
// READ/STATE only — no mutations. Creating a request is `bongos init` (P5) or the
// provisioning API; request/teardown buttons here are a deliberate follow-up.
(function () {
  'use strict';
  if (!window.OTB || typeof window.OTB.contributeHallWidget !== 'function') return;
  const { escapeHtml } = window.OTB;
  const API = '/api/bongos';
  // Generated typed client (task 1996 / R09), served as window.BongosClient by
  // /lib/bongos-client.js. baseUrl:'' passes the full same-origin paths this file
  // builds through unchanged; result-mode ({ status, ok, data }) preserves control flow 1:1.
  const api = window.BongosClient.createClient({ baseUrl: '', credentials: 'same-origin', throwOnError: false });

  async function getJSON(path, { softAuth = false } = {}) {
    const res = await api.request('GET', path);
    if (res.status === 401) {
      if (softAuth) { const e = new Error('auth-needed'); e.code = 'auth-needed'; throw e; }
      window.location.assign(`${API}/auth/web/start`);
      throw new Error('redirecting to auth');
    }
    if (!res.ok) throw new Error(`${path} → ${res.status}`);
    return res.data;
  }

  let host = null;

  // Lifecycle status → a badge class from the shared goal-badge family (achieved =
  // live/green, open = in-flight/neutral, archived = gone/muted). Mirrors the states
  // in provisioning_001_tables.sql / provisioning.INSTANCE_STATES.
  const STATUS_CLASS = {
    active: 'goal-badge--achieved',
    requested: 'goal-badge--open',
    provisioning: 'goal-badge--open',
    tearing_down: 'goal-badge--archived',
    torn_down: 'goal-badge--archived',
    error: 'goal-badge--archived',
  };
  function statusBadge(status) {
    const cls = STATUS_CLASS[status] || 'goal-badge--open';
    return `<span class="goal-badge ${cls}">${escapeHtml(status || 'unknown')}</span>`;
  }
  // Monthly cost — co-tenant is $0 (shares an existing box); a dedicated droplet
  // carries its tier's estimate. VISIBILITY only (ADR 0111 §6), never a bill.
  function usdMonthly(n) {
    const v = Number(n) || 0;
    return v > 0 ? `$${v.toFixed(2)}/mo` : '$0';
  }
  function openIntentNote(inst) {
    if (!inst.open_intent) return '';
    return ` <span class="ledger__note">(${escapeHtml(inst.open_intent.action)} ${escapeHtml(inst.open_intent.state)})</span>`;
  }

  function ownRow(inst) {
    return `<tr>
        <td>${escapeHtml(inst.slug || '—')}</td>
        <td>${statusBadge(inst.status)}${openIntentNote(inst)}</td>
        <td>${escapeHtml(inst.hosting_shape || '—')}</td>
        <td>${inst.domain ? escapeHtml(inst.domain) : '—'}</td>
        <td>${usdMonthly(inst.cost_estimate_usd)}</td>
      </tr>`;
  }

  function fleetRow(inst) {
    const owner = inst.owner || {};
    return `<tr>
        <td>${escapeHtml(inst.slug || '—')}</td>
        <td>${escapeHtml(owner.github_login || owner.display_name || '—')}</td>
        <td>${statusBadge(inst.status)}</td>
        <td>${escapeHtml(inst.hosting_shape || '—')}</td>
        <td>${inst.tier ? escapeHtml(inst.tier) : '—'}</td>
        <td>${usdMonthly(inst.cost_estimate_usd)}</td>
      </tr>`;
  }

  // Paint the caller's own instances into #instances-own-body.
  function renderOwn(instances) {
    const body = host.querySelector('#instances-own-body');
    if (!body) return;
    if (!instances.length) {
      body.innerHTML = '<p class="goal-empty">No instances yet. Create one with <code>bongos init</code> or the provisioning API — it’ll show here with its status and cost.</p>';
      return;
    }
    body.innerHTML =
      '<table class="ledger"><thead><tr><th>Instance</th><th>Status</th><th>Shape</th><th>Domain</th><th>Cost</th></tr></thead>' +
      `<tbody>${instances.map(ownRow).join('')}</tbody></table>`;
  }

  // Paint the fleet + cost-ledger total into #instances-fleet (Archon only). Reveals
  // the section (hidden by default in the skeleton) once data is in hand.
  function renderFleet(fleet, ledger) {
    const wrap = host.querySelector('#instances-fleet');
    const body = host.querySelector('#instances-fleet-body');
    if (!wrap || !body) return;
    wrap.hidden = false;
    if (!fleet.length) {
      body.innerHTML = '<p class="goal-empty">No provisioned instances across the fleet yet.</p>';
      return;
    }
    const total = ledger && typeof ledger.total_monthly_usd === 'number' ? ledger.total_monthly_usd : null;
    body.innerHTML =
      '<table class="ledger"><thead><tr><th>Instance</th><th>Owner</th><th>Status</th><th>Shape</th><th>Tier</th><th>Cost</th></tr></thead>' +
      `<tbody>${fleet.map(fleetRow).join('')}</tbody></table>` +
      (total !== null ? `<p class="ledger__note">Fleet estimate: <strong>${usdMonthly(total)}</strong> across ${fleet.length} instance${fleet.length === 1 ? '' : 's'} (co-tenant instances are $0).</p>` : '');
  }

  async function load() {
    if (!host) return;
    try {
      // Own instances (any authenticated builder).
      const mine = await getJSON(`${API}/provisioning/instances`);
      renderOwn(Array.isArray(mine.instances) ? mine.instances : []);
    } catch (err) {
      const body = host.querySelector('#instances-own-body');
      if (body) body.innerHTML = '<p class="goal-empty">Your instances couldn’t be loaded just now. Refresh to try again.</p>';
      console.error('[hall] instances load failed', err);
    }

    // Archon-only: the fleet roster + cost ledger. Read /me softly; a non-Archon (or
    // an auth hiccup) simply never reveals the fleet section.
    try {
      const me = await getJSON(`${API}/me`, { softAuth: true }).catch(() => null);
      const rank = me && me.builder ? me.builder.rank : null;
      if (rank !== 'archon') return;
      const [fleet, ledger] = await Promise.all([
        getJSON(`${API}/provisioning/fleet`).catch(() => ({ instances: [] })),
        getJSON(`${API}/provisioning/fleet/cost-ledger`).catch(() => null),
      ]);
      renderFleet(Array.isArray(fleet.instances) ? fleet.instances : [], ledger);
    } catch (err) {
      console.error('[hall] instances fleet load failed', err);
    }
  }

  const SKELETON =
    '<h2 id="instances-h" class="scroll__h">Instances</h2>' +
    '<p class="scroll__lede">Hosting you’ve provisioned through Cloud Bongos — each instance’s status and estimated monthly cost. Provision one with <code>bongos init</code> or the provisioning API.</p>' +
    '<div id="instances-own-body"><div class="profile__placeholder">Loading your instances…</div></div>' +
    '<div id="instances-fleet" hidden>' +
      '<h3 class="scroll__h" style="font-size:1rem;margin-top:1rem">Fleet</h3>' +
      '<p class="scroll__lede">Every owner’s instances and the fleet cost estimate (Archon view).</p>' +
      '<div id="instances-fleet-body"><div class="profile__placeholder">Loading the fleet…</div></div>' +
    '</div>';

  function mount(hostEl) {
    host = hostEl;
    host.innerHTML = SKELETON;
    load();
  }

  window.OTB.contributeHallWidget({
    id: 'instances-scroll', label: 'Instances', order: 34,
    module: 'provisioning', view: 'home', zone: 'home-main',
    labelledby: 'instances-h', mount,
  });
})();
