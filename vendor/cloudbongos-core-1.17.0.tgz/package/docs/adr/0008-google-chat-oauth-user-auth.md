# 0008 — Google Chat integration auth model: OAuth as the operator user

- **Status:** Superseded by [ADR 0032](0032-discord-mirror-of-gds.md) (outbound) and [ADR 0033](<redacted>.md) (bot/inbound) — Google Chat fully retired 2026-06-05, replaced by Discord
- **Date:** 2026-05-09
- **Deciders:** Lars

## Context

The Google Chat broadcast integration needs to (a) post milestone updates to the Example team space and (b) read replies/reactions to surface them as feature requests. Google offers two distinct auth paths for the Chat API:

1. **Service account / Chat App identity** — the integration speaks as a registered "bot" persona that's added to the space.
2. **User OAuth** — the integration speaks as a real user (in our case `lars@example.com`).

Both can read and post; the difference is whose name appears next to messages and reactions, and what setup is required.

## Decision

We will use **User OAuth (as `lars@example.com`)**.

- OAuth client is a **Desktop application** type, registered under a Google Cloud project (`off-the-boats`) owned by `lars@example.com`.
- The OAuth consent screen is configured as **Internal** (only `example.com` Workspace users can authorize), which skips Google's app-verification process.
- A long-lived **refresh token** lives at `~/.config/otb/google-chat-token.json` on the operator's Mac (mode 600). The refresh token is exchanged for short-lived access tokens at runtime.
- Posts and reactions appear under **Lars Kristensen** in the team chat. The team experience is "Lars is sharing build updates," not "a bot is talking."

## Alternatives considered

- **Service account with Chat App identity.** Cleanest separation (the bot is its own persona, posts under "Off the Boats Build Bot"). Requires registering the Chat App via Google Cloud's Chat API Configuration page, a "deployment ID," and Workspace admin permission to allow the service account into the space. More setup steps; the bot identity feels less personal for a small team chat where everyone knows Lars.
- **Incoming webhook only (outbound, no auth dance).** Dramatically simpler — paste a URL, POST to it, message appears. Good enough for outbound milestone posts but **cannot read messages, threads, or reactions**. Rejected because the inbound feedback loop is half the value.

## Consequences

- **The team sees Lars as the source of every milestone post.** Friendly for a small team but means we should never post anything Lars wouldn't want under his own name. The posting rules in [`docs/google-chat-broadcast.md`](../google-chat-broadcast.md) explicitly limit content to player-visible outcomes in plain language.
- **Reactions show as Lars's reactions.** When the integration acks a request with ✅, the team sees Lars reacting. Aligns with the "Lars relays team feedback to the build" mental model.
- **Refresh token is a high-value secret.** Anyone with this file can post to the team chat as Lars and read everything Lars has access to in Google Chat. Lives at `~/.config/otb/google-chat-token.json` mode 600, never committed (`.gitignore` enforces). If ever leaked, revoke from [myaccount.google.com/permissions](https://myaccount.google.com/permissions) and re-run `scripts/chat/auth-once.js`.
- **Refresh token does not expire** for Internal Workspace OAuth apps unless explicitly revoked. No periodic re-auth needed.
- **Tied to one operator.** If Lars leaves the project (or example.com), the integration breaks. Acceptable for V1 — Lars is a single point of failure on much more than this. If/when the team grows, we can graduate to a service account, write ADR 0009 documenting the migration, and re-issue the integration as a bot identity.
- **No Workspace admin involvement required.** Internal OAuth consent + Desktop OAuth client are both self-serve at the user level.
