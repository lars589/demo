-- PMS-V3 Planning Session #1 seed
-- Applied under claim 166 (task 227, V3.R00 — Planning Session #1).
-- Idempotent on re-run.
--
-- What this migration does:
--   1. Updates versions.PMS-V3.done_when to match the 9 criteria
--   2. Seeds 9 done_when_criteria rows for version_id='PMS-V3'
--   3. Renames the 9 existing PMS-V3 tasks with their V3.R## prefix
--      and sets their priorities per the ranking. Existing descriptions
--      are preserved.
--
-- Net-new tasks (81 of them) are created via scripts/pms/seed-v3-tasks.js
-- which runs after this migration is applied. We split because tasks have
-- rich descriptions and the API handles task_kind classification + foreign-
-- key writes more cleanly than a long SQL VALUES list.

BEGIN;

-- Short-circuit guard: migration 019 renames versions.id 'PMS-V3' to 'GDS-V3'.
-- If the rename has already happened (or this DB never had PMS-V3 at all),
-- every statement below is a no-op at best and a FK violation at worst.
-- Skip cleanly so a fresh restore + replay doesn't blow up the deploy.
--
-- We use a CTE-style WHERE-EXISTS guard on each statement (no DO block —
-- DO blocks can't short-circuit the rest of the file). The criteria INSERT
-- is wrapped with a SELECT-driven feed so it naturally produces zero rows
-- when PMS-V3 is absent.

-- ============================================================================
-- 1. Update versions.PMS-V3.done_when text
-- ============================================================================
UPDATE versions
SET done_when = 'When this is finished, multiple trusted builders will work the city in parallel — onboarded in under two hours, ranked into three tiers, shipping under their own credentials with their own karma alongside their drachmae, judged to the same quality bar, proposing scope into the next planning session, parallel-safe under load, gated by server-enforced permissions, cloneable in full with local-first memory that syncs on every ship, and able to earn drachmae by red-teaming a staging mirror of the city''s walls.'
WHERE id = 'PMS-V3';

-- ============================================================================
-- 2. Seed 9 done_when_criteria rows for PMS-V3
--    UPSERT semantics via ON CONFLICT (version_id, criterion_id).
--    Outer WHERE EXISTS makes this a no-op when 019 has already renamed
--    PMS-V3 → GDS-V3 (the FK check would otherwise fail).
-- ============================================================================
INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, sort_order)
SELECT * FROM (VALUES
  ('PMS-V3', 'onboarding-2h',
   '**Trusted-newcomer onboarding to first shipped task is ≤ 2 hours.** A Metic-tier builder added by Archon today is shipping a real PMS task on `main` within 2 hours, without 1:1 help. Build environment bootstraps from `git clone` + one setup script; docs live outside CLAUDE.md, written for first-time readers; at least one newcomer-friendly task is always open per active version; `/builder-setup` no longer assumes Archon''s machine.',
   1),
  ('PMS-V3', 'three-ranks-gate-everything',
   '**Three ranks exist, and they gate every privileged operation.** Xenos (default for any GitHub-authed person; read-only on public surfaces + ship only explicitly-tagged-open tasks), Metic (Archon-approved; full claim/ship, planning sessions in proposal mode, idea triage, blocker review, priority sessions), Archon (rank promotion, ratification, version close, infra). `builders.rank` enum + middleware on every privileged route + Archon-only promotion/demotion endpoint + rank visible on /builders hall.',
   2),
  ('PMS-V3', 'per-builder-credentials',
   '**Every builder ships under their own credentials, with their own cost and authorship.** Per-builder Gemini key registered during `/builder-setup`; per-builder cost ledger entries; authorship in session_logs/claims/commits is the actual builder, never Archon-as-proxy; soft-cap warning before a builder hits their hard cost ceiling; Anthropic account linking via Claude Code self-verification.',
   3),
  ('PMS-V3', 'quality-bar-holds',
   '**Work shipped by any builder meets the same quality bar Archon''s V2 work did.** Opus-subagent grader replaces the v1 process-audit grader and gates `completed → confirmed`; per-builder × per-kind calibration tightens the bar over time, never loosens; failed confirmations are visible to the builder with actionable feedback written to the learnings table; regressions caught by automation, not by Archon''s eye.',
   4),
  ('PMS-V3', 'propose-ratify',
   '**Trusted builders propose; Archon ratifies; the cadence is structural.** Metics shape what comes next by surfacing proposals, not by writing system state directly. Planning sessions, priority sessions, idea triage, and blocker review are Metic-runnable; proposed criteria/tasks land in `idea_inbox` tagged with the source builder; Archon ratifies during the next planning session, writing them into `done_when_criteria` and `tasks`; nightly skill-usage feedback loop surfaces friction; builder analytics surface "AI dev curve" per builder; PMS-V4''s done-when criteria are mostly authored by Metic proposals captured during V3.',
   5),
  ('PMS-V3', 'parallel-safe-under-load',
   '**N>1 builders work in parallel without colliding on claims, merges, or shared system state.** Claim concurrency is deterministic; merge serialization handles drift; scheduled tasks don''t multiplex per-builder state incorrectly; session-scoped hooks move off per-session onto scheduled timers where appropriate; parallel-safety bugs surfaced during V3 get fixed in V3.',
   6),
  ('PMS-V3', 'server-enforced-perms',
   '**Permissions are enforced server-side; no builder can grant themselves authority by editing local files.** `rank` lives in the database, checked on every privileged request against the DB (no caching, so demotion is effectively instant); skills, hooks, and `.claude/settings.json` cannot grant authority — they can only call into server endpoints that themselves enforce rank; CLAUDE.md and other markdown files describe permissions but are never the source of truth; an ADR documents the trust boundary; a periodic auditor confirms no privileged route is missing a rank check.',
   7),
  ('PMS-V3', 'cloneable-local-memory-server-sync',
   '**The repo, memory system, art pipeline, and methodology are cloneable by any Metic; memory is local-first, server-canonical on ship.** `git clone` is the onboarding path — no Archon-only handoffs beyond rank assignment. No secrets live in the repo (verified). Each builder''s local memory dir syncs to a server-side per-builder store every time a task ships; learnings remain server-canonical. Cloning the repo never exposes another builder''s local memory. Art pipeline runs end-to-end on a fresh checkout with the builder''s own Gemini key.',
   8),
  ('PMS-V3', 'security-baseline-plus-red-team',
   '**The server has production-grade security basics, and Metics earn drachmae by red-teaming it.** Input validation, auth-token hygiene, rate limits on write paths, audit logging on privileged routes, dependency-scan in CI — all green before any non-Archon ships. A staging environment mirrors prod. Any Metic can role-play as an attacker on staging; confirmed vulnerabilities are filed by the discoverer and earn drachmae proportional to severity, auto-confirmed by a subagent reproducing the exploit on staging. Reported vulnerabilities are fixed in V3 unless Archon explicitly defers with an ADR. Observability dashboard (Grafana provisioned-as-code) makes regressions visible.',
   9)
) AS v(version_id, criterion_id, criterion_md, sort_order)
WHERE EXISTS (SELECT 1 FROM versions WHERE id = 'PMS-V3')
ON CONFLICT (version_id, criterion_id) DO UPDATE
  SET criterion_md = EXCLUDED.criterion_md,
      sort_order = EXCLUDED.sort_order;

-- ============================================================================
-- 3. Update the 9 existing PMS-V3 task priorities + titles
--    Idempotent guard: only prepend V3.R## prefix when not already there.
--    These UPDATEs are intrinsically safe when PMS-V3 has been renamed:
--    the tasks they reference (by id) may still exist but their version_id
--    is now 'GDS-V3', and the WHERE-clause `id = N AND title NOT LIKE 'V3.R%'`
--    is already idempotent (title prefix was applied on the original run).
-- ============================================================================

-- V3.R04 — Builder rank system (Tier 1, P5)
UPDATE tasks SET priority = 5,
  title = 'V3.R04 — ' || title
WHERE id = 106 AND title NOT LIKE 'V3.R%';

-- V3.R10 — Per-builder Gemini API key (Tier 1, P5)
UPDATE tasks SET priority = 5,
  title = 'V3.R10 — ' || title
WHERE id = 91 AND title NOT LIKE 'V3.R%';

-- V3.R15 — Seamless builder onboarding umbrella (Tier 1, P5)
UPDATE tasks SET priority = 5,
  title = 'V3.R15 — ' || title
WHERE id = 222 AND title NOT LIKE 'V3.R%';

-- V3.R18 — Replace v1 grader with Opus subagent (Tier 2, P5)
UPDATE tasks SET priority = 5,
  title = 'V3.R18 — ' || title
WHERE id = 209 AND title NOT LIKE 'V3.R%';

-- V3.R19 — Subagent grader v1 (Tier 2, P5)
UPDATE tasks SET priority = 5,
  title = 'V3.R19 — ' || title
WHERE id = 201 AND title NOT LIKE 'V3.R%';

-- V3.R20 — Grader calibration + per-builder × per-kind (Tier 2, P5)
UPDATE tasks SET priority = 5,
  title = 'V3.R20 — ' || title
WHERE id = 202 AND title NOT LIKE 'V3.R%';

-- V3.R21 — Auto-flip confirmed→shipped on merge (Tier 2, P5)
UPDATE tasks SET priority = 5,
  title = 'V3.R21 — ' || title
WHERE id = 98 AND title NOT LIKE 'V3.R%';

-- V3.R46 — version-close.js refusal bug fix (Tier 4, P4)
UPDATE tasks SET priority = 4,
  title = 'V3.R46 — ' || title
WHERE id = 224 AND title NOT LIKE 'V3.R%';

-- V3.R47 — chat-inbox triage off per-session hook (Tier 4, P4)
UPDATE tasks SET priority = 4,
  title = 'V3.R47 — ' || title
WHERE id = 220 AND title NOT LIKE 'V3.R%';

COMMIT;
