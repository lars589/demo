# ADR 0119 — API pagination contract

**Date:** 2026-07-04
**Status:** Accepted (contract; R13 of goal 36).
**Context:** [task 2000](https://builders.example.com#/task/2000) (BONGOS-V1, goal 36, criterion `api-pagination`). The contract; the sweep that adopts it across every list endpoint + caps the currently-unbounded public lists is R14 ([task 2001](https://builders.example.com#/task/2001)).

## Problem

Three pagination styles coexist across the API: `limit`-only, `limit`+`offset`, and none. Some public lists (leaderboard, blockers, versions) return **everything** — an unbounded result set that grows with the project and is a cost/DoS amplification target on the unauthenticated `/public/*` surface. A caller cannot page any two endpoints the same way, and cannot assume a list is bounded.

## Decision

**One convention: `?limit=&offset=` (limit/offset), served through one shared helper.**

- **`limit`** — positive integer; default **50**, hard cap **200** (`PAGINATION.DEFAULT_LIMIT` / `MAX_LIMIT`). A value over the cap is clamped to the cap, so **no list can return an unbounded set**.
- **`offset`** — non-negative integer; default **0**.
- **Clamp, never reject.** A bad/absent/oversized value is coerced to a sane default (a list read stays forgiving — a typo'd `limit` returns the first page, not a 400). This is deliberately looser than write-body validation (R11), which rejects.
- **Shared helper** — `parsePagination(req, { defaultLimit, maxLimit })` in `src/gds/routes/_helpers.js` returns `{ limit, offset }`. Per-endpoint caps are expressible via `maxLimit` (e.g. a heavy aggregate can cap lower).
- **Response convention** — a paginated list returns `{ items: [...], page: { limit, offset, total? } }`; `pageMeta(limit, offset, total?)` builds the `page` block. `total` is optional (some lists can't cheaply count); when present a caller derives "more pages" via `offset + items.length < total`.

**Why limit/offset, not cursor.** Limit/offset is the style already in use (the `?limit=`/`?offset=` reads today), needs no opaque-token or stable-sort infrastructure, and is trivial for an external caller or a `curl` to construct. Cursor pagination is stronger under high write-churn (no skipped/duplicated rows across pages), but this API's lists are modest and mostly append/status-updated; the cursor machinery is not worth its cost here. If a specific hot, churning list ever needs it, cursor can be added for that endpoint without changing this default.

## Consequences

- Adopting the helper (R14) makes every list page identically and caps the unbounded public lists (leaderboard/blockers/versions) — closing the cost/DoS surface.
- **Opt-in + non-breaking today:** adding the helper + `pageMeta` changes no response until a route calls them. R14 does the adoption; the currently-unbounded lists gain a default page (a behaviour change scoped to R14, announced there).
- The OpenAPI spec (R08 enrichment) advertises `limit`/`offset` query params + the `page` response block as the standard, so the generated client + docs teach one paging model.

## Rejected

- **Cursor/keyset pagination as the default** — more robust under churn but needs opaque cursors + a stable sort key per endpoint; disproportionate for these list sizes. Left as a per-endpoint escape hatch.
- **Page-number pagination (`?page=&per_page=`)** — same expressiveness as offset but an extra mental step (page→offset) and awkward when the page size changes mid-scroll.
- **Leaving lists unbounded** — the status quo; the exact cost/DoS problem the criterion exists to close.
- **Rejecting a bad `limit` with a 400** — a list read should be forgiving; clamping is friendlier and keeps a typo from breaking a dashboard. (Write validation, R11, is the strict counterpart.)
