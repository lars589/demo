-- core_191_module_submissions.sql — the ADR 0107 §1 upstreaming review queue.
--
-- task 1770: `bongos module submit <key>` packages a module (manifest +
-- attribution + file contents) + its DCO-style sign-off and files it into a
-- rank-gated review queue. Real cross-repo submission (an instance filing into
-- the CORE repo's own review process) is not wired up yet — the extracted core
-- (github.com/lars589/cloud-bongos, private) has no reachable submission API
-- today, and R85 (the forcing-function second consumer) was abandoned in favor
-- of the already-proven two-repo model (see task 1689's value_summary). So this
-- table is the interim, buildable-now queue: it lives in THIS instance's own
-- Bongos DB (the same DB the module was built against), rank-gated identically
-- to the eventual core-side surface. Task 1771 (core-side review & accept flow)
-- reviews rows here; if/when a live cross-repo core endpoint exists, filing
-- becomes a network hop instead of a local INSERT with no schema change to the
-- caller. See docs/adr/0135-module-upstream-submission-interim-queue.md.
--
-- files jsonb = [{ path, contentBase64, bytes }, ...] — a full snapshot of the
-- module tree at submit time (ADR 0107 §1 "packages the module + ... into a
-- ... queue"), so a reviewer (task 1771) can inspect the submitted code without
-- needing network/filesystem access to the submitting instance's repo.
--
-- Idempotent: safe to re-run.

CREATE TABLE IF NOT EXISTS module_submissions (
  id                  bigserial PRIMARY KEY,
  module_key          text NOT NULL,
  submitted_by        bigint NOT NULL REFERENCES builders(id),
  manifest            jsonb NOT NULL,
  files               jsonb NOT NULL,
  sign_off            jsonb NOT NULL,
  precheck_passed_at  timestamptz NOT NULL,
  source_repo         text,
  status              text NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending', 'accepted', 'rejected')),
  reviewed_by         bigint REFERENCES builders(id),
  reviewed_at         timestamptz,
  review_notes        text,
  submitted_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_module_submissions_status ON module_submissions (status, submitted_at DESC);
CREATE INDEX IF NOT EXISTS idx_module_submissions_key ON module_submissions (module_key, submitted_at DESC);

INSERT INTO schema_migrations (version) VALUES ('core_191_module_submissions')
  ON CONFLICT (version) DO NOTHING;
