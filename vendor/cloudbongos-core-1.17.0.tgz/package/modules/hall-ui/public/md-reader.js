// md-reader.js — a small, dependency-free markdown reader for in-hall docs.
//
// Task 1472: the drachmae-and-karma onboarding doc needs a rendered in-hall
// page (the primer proves the pattern, but its parser is baked into primer.js
// and coupled to the primer's ack/diagram chrome). This factors the reusable
// core out into `window.OTBMdReader` so any hall doc-reader page can fetch a
// canonical `docs/onboarding/*.md` and render it client-side with no build
// step and no external markdown dependency.
//
// Covers the subset our onboarding docs actually use: h1–h3, paragraphs,
// unordered/ordered lists (single level), tables, fenced code, hr,
// blockquotes (which the primer's own parser does NOT handle — the drachmae
// doc uses them heavily), and inline `code` / **bold** / *italic* / [link].
// The repo-relative link rewriter is parameterized (base dir + GitHub bases +
// a diagrams route) so each page points relative paths at the right place.
//
// (The primer's copy predates this and can adopt OTBMdReader in a later pass —
// captured as an idea at ship; leaving primer.js untouched here keeps this
// change off the sign-in-gated onboarding page.)

(function () {
  'use strict';

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // Stable slug for heading anchors — lowercase, strip punctuation, dash-join.
  // Matches the primer's slugify so in-doc anchor links behave identically.
  function slugify(text) {
    return String(text)
      .toLowerCase()
      .replace(/[—–]/g, '-')
      .replace(/[^a-z0-9\s-]/g, '')
      .trim()
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-');
  }

  function normalizePath(p) {
    const parts = p.split('/');
    const out = [];
    for (const part of parts) {
      if (part === '' || part === '.') continue;
      if (part === '..') { out.pop(); continue; }
      out.push(part);
    }
    return out.join('/') + (p.endsWith('/') ? '/' : '');
  }

  // Build a link resolver bound to where THIS doc lives in the repo. Relative
  // repo paths (../adr/…, diagrams/…) are rewritten to something that resolves
  // in the browser instead of 404-ing under /builders/*:
  //   - http(s):// or #anchor or mailto:/tel:  → unchanged
  //   - the diagrams dir                        → the in-hall diagrams route
  //   - everything else                         → GitHub blob/tree (bases fetched
  //     from /api/gds/public/repo-info; null until then → pass through, 404s
  //     harmlessly rather than crashing).
  // opts: { baseDir, getBlobBase, getTreeBase, diagramsHref }
  function makeResolveLinkHref(opts) {
    const baseDir = (opts && opts.baseDir) || '';
    const getBlobBase = (opts && opts.getBlobBase) || (() => null);
    const getTreeBase = (opts && opts.getTreeBase) || (() => null);
    const diagramsHref = (opts && opts.diagramsHref) || '/builders/diagrams';
    return function resolveLinkHref(href) {
      if (!href) return href;
      if (/^https?:\/\//i.test(href)) return href;
      if (href.startsWith('#')) return href;
      if (href.startsWith('mailto:') || href.startsWith('tel:')) return href;
      // The onboarding diagrams live at /builders/diagrams/* in the hall.
      if (href === 'diagrams/' || href === 'diagrams') return diagramsHref;
      let resolved;
      if (href.startsWith('/')) {
        resolved = href.replace(/^\/+/, '');
      } else {
        resolved = normalizePath(baseDir + href);
      }
      // The diagrams PNGs referenced by relative path resolve in-hall too.
      const dm = resolved.match(/(?:^|\/)diagrams\/([\w.-]+\.png)$/);
      if (dm) return `${diagramsHref}/${dm[1]}`;
      const trailingSlash = resolved.endsWith('/');
      const lastSeg = resolved.replace(/\/+$/, '').split('/').pop() || '';
      const isDir = trailingSlash || !lastSeg.includes('.');
      const cleanResolved = resolved.replace(/^\/+/, '').replace(/\/+$/, '');
      const base = isDir ? getTreeBase() : getBlobBase();
      if (!base) return href;
      return `${base}/${cleanResolved}`;
    };
  }

  // Inline substitutions on already-escaped text. Code spans are protected
  // first via placeholders so bold/italic/link rules don't touch their guts.
  function renderInline(escapedText, resolveLinkHref) {
    const resolve = resolveLinkHref || ((h) => h);
    const codeSpans = [];
    let out = escapedText.replace(/`([^`]+)`/g, (_m, g1) => {
      codeSpans.push(g1);
      return ` CODE${codeSpans.length - 1} `;
    });
    out = out.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_m, text, url) => {
      const safeUrl = url.replace(/&amp;/g, '&').replace(/&#39;/g, "'");
      const resolved = resolve(safeUrl);
      let linkHost = '';
      try { linkHost = new URL(resolved, location.href).hostname; } catch (_) { /* relative */ }
      const instApex = location.hostname.split('.').slice(-2).join('.');
      const sameInstance = !!linkHost && (linkHost === location.hostname || linkHost === instApex || linkHost.endsWith('.' + instApex));
      const external = /^https?:\/\//.test(resolved) && !sameInstance;
      const attrs = external ? ' target="_blank" rel="noopener"' : '';
      return `<a href="${escapeHtml(resolved)}"${attrs}>${text}</a>`;
    });
    out = out.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    out = out.replace(/(^|[^*])\*([^*]+)\*(?!\*)/g, '$1<em>$2</em>');
    out = out.replace(/ CODE(\d+) /g, (_m, idx) => `<code>${escapeHtml(codeSpans[Number(idx)])}</code>`);
    return out;
  }

  function splitTableRow(line) {
    const cells = line.split('|').map((c) => c.trim());
    if (cells.length && cells[0] === '') cells.shift();
    if (cells.length && cells[cells.length - 1] === '') cells.pop();
    return cells;
  }

  // Block grammar (line-by-line). Returns { html, headings } where headings is
  // [{ level, text, id }] for building a TOC + scrollspy.
  function parseMarkdown(md, resolveLinkHref) {
    const lines = String(md).replace(/\r\n?/g, '\n').split('\n');
    const out = [];
    const headings = [];
    let i = 0;

    while (i < lines.length) {
      const raw = lines[i];

      // Fenced code block.
      if (raw.startsWith('```')) {
        i += 1;
        const codeLines = [];
        while (i < lines.length && !lines[i].startsWith('```')) { codeLines.push(lines[i]); i += 1; }
        i += 1; // consume closing ```
        out.push(`<pre><code>${escapeHtml(codeLines.join('\n'))}</code></pre>`);
        continue;
      }

      // Headings.
      let hm;
      if ((hm = raw.match(/^(#{1,3})\s+(.+?)\s*$/))) {
        const level = hm[1].length;
        const text = hm[2];
        const id = slugify(text);
        headings.push({ level, text, id });
        out.push(`<h${level} id="${escapeHtml(id)}">${renderInline(escapeHtml(text), resolveLinkHref)}</h${level}>`);
        i += 1;
        continue;
      }

      // Horizontal rule.
      if (/^---+\s*$/.test(raw)) { out.push('<hr>'); i += 1; continue; }

      // Blank line — paragraph separator.
      if (/^\s*$/.test(raw)) { i += 1; continue; }

      // Blockquote — consecutive '> ' lines collapse into one <blockquote>.
      // (The drachmae doc leans on these for its "why / note" asides.)
      if (/^>\s?/.test(raw)) {
        const quoteLines = [];
        while (i < lines.length && /^>\s?/.test(lines[i])) {
          quoteLines.push(lines[i].replace(/^>\s?/, ''));
          i += 1;
        }
        const inner = quoteLines.join(' ').trim();
        out.push(`<blockquote><p>${renderInline(escapeHtml(inner), resolveLinkHref)}</p></blockquote>`);
        continue;
      }

      // Table: header row '| … |' followed by a separator row.
      if (/^\|/.test(raw) && i + 1 < lines.length && /^\|[\s\-:|]+\|\s*$/.test(lines[i + 1])) {
        const headerCells = splitTableRow(raw);
        i += 2;
        const bodyRows = [];
        while (i < lines.length && /^\|/.test(lines[i])) { bodyRows.push(splitTableRow(lines[i])); i += 1; }
        let html = '<table><thead><tr>';
        for (const c of headerCells) html += `<th>${renderInline(escapeHtml(c), resolveLinkHref)}</th>`;
        html += '</tr></thead><tbody>';
        for (const row of bodyRows) {
          html += '<tr>';
          for (const c of row) html += `<td>${renderInline(escapeHtml(c), resolveLinkHref)}</td>`;
          html += '</tr>';
        }
        html += '</tbody></table>';
        out.push(html);
        continue;
      }

      // Lists (unordered '- ' or ordered '1. '); consecutive items collapse.
      if (/^(-|\d+\.)\s+/.test(raw)) {
        const ordered = /^\d+\.\s+/.test(raw);
        const items = [];
        while (i < lines.length && /^(-|\d+\.)\s+/.test(lines[i])) {
          const content = lines[i].replace(/^(-|\d+\.)\s+/, '');
          items.push(`<li>${renderInline(escapeHtml(content), resolveLinkHref)}</li>`);
          i += 1;
        }
        out.push(`<${ordered ? 'ol' : 'ul'}>${items.join('')}</${ordered ? 'ol' : 'ul'}>`);
        continue;
      }

      // Paragraph — collect consecutive non-special lines.
      const paraLines = [raw];
      i += 1;
      while (i < lines.length &&
             !/^\s*$/.test(lines[i]) &&
             !/^(#{1,3})\s/.test(lines[i]) &&
             !/^---+\s*$/.test(lines[i]) &&
             !/^```/.test(lines[i]) &&
             !/^>\s?/.test(lines[i]) &&
             !/^\|/.test(lines[i]) &&
             !/^(-|\d+\.)\s+/.test(lines[i])) {
        paraLines.push(lines[i]);
        i += 1;
      }
      out.push(`<p>${renderInline(escapeHtml(paraLines.join(' ')), resolveLinkHref)}</p>`);
    }

    return { html: out.join('\n'), headings };
  }

  window.OTBMdReader = { escapeHtml, slugify, normalizePath, makeResolveLinkHref, renderInline, splitTableRow, parseMarkdown };
})();
