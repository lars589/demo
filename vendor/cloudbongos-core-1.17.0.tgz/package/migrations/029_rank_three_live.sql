-- 029_rank_three_live.sql — the three-rank model goes live (Xenos / Metic / Archon).
--
-- Context: task #360, follow-up to the V3.R86 (#305) CLAUDE.md audit, which
-- surfaced that the ENFORCED model (archon + thetes default, xenos = exit tier)
-- conflicted with the PLANNED model in V3 criterion C2 + the skills (xenos
-- default sandbox -> metic working rank -> archon). Lars chose to wire the
-- three-rank model for real. See ADR 0018.
--
-- This migration does the two SCHEMA pieces; the route-grant + claim-gate
-- pieces are code (src/bongos/*), not schema. Adding 'metic' to the live set is a
-- code change (it was already a reserved value in the migration 023 CHECK enum)
-- — no enum change is needed here.
--
-- Blast radius is zero: at the time this ran only the founding Archon existed. No thetes/metic/xenos
-- builders are live, so flipping the default affects only builders created from
-- now on. Existing rows are untouched (ALTER ... SET DEFAULT is not retroactive).
--
-- Idempotent: safe to re-run.

-- 1. New GitHub-authed builders now default to the sandboxed entry rank.
--    (Was 'thetes' in migration 023.) Metic is the Archon-approved working rank
--    a builder is deliberately promoted to; thetes joins the reserved ladder.
ALTER TABLE builders ALTER COLUMN rank SET DEFAULT 'xenos';

-- 2. The "explicitly-tagged-open" mechanism for the Xenos sandbox. A Xenos can
--    only claim tasks flagged open to them; everything else needs Metic+.
--    Default false = closed; an Archon opens a task by setting it true via
--    PATCH /api/gds/tasks/:id.
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS xenos_claimable boolean NOT NULL DEFAULT false;

INSERT INTO schema_migrations (version) VALUES ('029_rank_three_live')
  ON CONFLICT (version) DO NOTHING;
