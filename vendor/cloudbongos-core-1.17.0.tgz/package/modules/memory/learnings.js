// GDS learnings — durable capture of paid-once knowledge.
//
// Companion module to src/bongos/db.js. Lives in its own file (per the F1 spec)
// so per-feature touches[] stay disjoint across V2 builders.
//
// Schema (migration 006_pms_v2.sql):
//   learnings(id, title, body_md, tags text[], related_files text[],
//             captured_by, source, source_ref, task_id?, created_at)
//   indexes: GIN(tags), GIN(related_files),
//            UNIQUE(source, source_ref) WHERE non-null
//
// Wired into routes by src/bongos/routes.js (POST + GET /api/gds/learnings).

// Carved into modules/memory/ (BV1.R72 / ADR 0091 §2): pool via the doorway.
const crypto = require('crypto');
const { pool } = require('../../src/module-api');
// ADR 0095 C4: <private>…</private>-fenced content is stripped at ingest so it
// never lands in the learnings store (nor the recall index that reads it).
const { stripPrivate } = require('./search-chunker');

// -------------------------------------------------------------------------
// Windowed content-hash dedup (ADR 0095 C5, task 1662)
// -------------------------------------------------------------------------
//
// The (source, source_ref) UNIQUE index already de-dups learnings that carry an
// explicit idempotency key. But most learnings are captured WITHOUT one (a
// builder runs `learning-capture.js` twice, or two near-simultaneous sessions
// capture the same insight) — those slip past the source_ref guard and land as
// near-duplicate rows. C5 adds a second, softer guard for exactly that case:
// hash the content (captured_by + title + body) and, if an identical hash was
// written WITHIN A SHORT WINDOW, reuse that existing row instead of inserting.
//
// This is the claude-mem pattern — SHA256(session+title+narrative), short
// window — adapted to our schema: there is no `session` column, so the writer
// (captured_by) plays that role, and the window is enforced by a time-bounded
// SELECT rather than a stored hash column (no migration; modules/memory only).
// It is deliberately mechanical and backward-compatible: a NULL captured_by
// still hashes (to the empty string), and a write outside the window inserts
// normally, so nothing that used to be stored stops being stored.
const DEDUP_WINDOW_MS = 30_000; // ~30s — matches claude-mem's short window.

// learningContentHash — the dedup key for a learning's *content*. Pure +
// exported for tests. Mirrors memory.js's sha256Hex shape (full hex digest);
// the window query, not a prefix, bounds the comparison. captured_by is folded
// in so two different builders capturing the same text are NOT collapsed (the
// session-scoping half of the claude-mem key). NUL-delimited so adjacent fields
// can't run together (title 'a' + body 'bc' must not collide with 'ab' + 'c').
function learningContentHash({ capturedBy = null, title = '', bodyMd = '' } = {}) {
  const key = `${capturedBy ?? ''}\0${title ?? ''}\0${bodyMd ?? ''}`;
  return crypto.createHash('sha256').update(key, 'utf8').digest('hex');
}

// -------------------------------------------------------------------------
// Writes
// -------------------------------------------------------------------------

// Insert a learning. Two layers of idempotency:
//   1. (source, source_ref) UNIQUE — an explicit key skips reinsert (returns
//      null, mirroring db.logCost semantics).
//   2. windowed content-hash (ADR 0095 C5) — even WITHOUT a source_ref, a write
//      whose (captured_by + title + body) matches one stored within the last
//      DEDUP_WINDOW_MS reuses that existing row instead of inserting a near-dup.
//      The existing row is returned (NOT null) so a caller that re-captures the
//      same insight still gets a usable id back.
async function createLearning({
  title,
  bodyMd,
  tags = [],
  relatedFiles = [],
  capturedBy = null,
  source = null,
  sourceRef = null,
  taskId = null,
}) {
  if (!title || typeof title !== 'string') {
    throw new Error('createLearning: title required');
  }
  if (!bodyMd || typeof bodyMd !== 'string') {
    throw new Error('createLearning: bodyMd required');
  }

  // ADR 0095 C4: strip <private>-fenced content from title + body before they are
  // hashed/deduped/stored, so no fenced text reaches the learnings table or the
  // recall index. Done after the required-string validation so the marker can't
  // be used to smuggle an empty learning past it (a learning whose entire body is
  // fenced strips to empty and is rejected like any other empty body).
  title = stripPrivate(title);
  bodyMd = stripPrivate(bodyMd);
  if (!bodyMd.trim()) {
    throw new Error('createLearning: bodyMd required (empty after <private> strip)');
  }

  // Windowed content-hash pre-check. We can't index a hash column (no migration
  // in scope), so we fetch the small set of recent rows from the SAME writer and
  // compare hashes in code. The window keeps that set tiny, and the existing
  // idx_learnings_created index makes the time-bounded scan cheap. A matching
  // recent row short-circuits the insert and is returned as-is.
  const contentHash = learningContentHash({ capturedBy, title, bodyMd });
  const { rows: recent } = await pool.query(
    `SELECT id, title, body_md, tags, related_files, captured_by,
            source, source_ref, task_id, created_at
       FROM learnings
      WHERE created_at >= now() - ($1::bigint * interval '1 millisecond')
        AND captured_by IS NOT DISTINCT FROM $2
      ORDER BY created_at DESC`,
    [DEDUP_WINDOW_MS, capturedBy]
  );
  for (const r of recent) {
    if (learningContentHash({ capturedBy: r.captured_by, title: r.title, bodyMd: r.body_md }) === contentHash) {
      return r; // near-duplicate within the window → reuse the existing row.
    }
  }

  const { rows } = await pool.query(
    `INSERT INTO learnings (title, body_md, tags, related_files, captured_by,
                            source, source_ref, task_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
     ON CONFLICT (source, source_ref)
       WHERE source IS NOT NULL AND source_ref IS NOT NULL
       DO NOTHING
     RETURNING id, title, body_md, tags, related_files, captured_by,
               source, source_ref, task_id, created_at`,
    [
      title,
      bodyMd,
      Array.isArray(tags) ? tags : [],
      Array.isArray(relatedFiles) ? relatedFiles : [],
      capturedBy,
      source,
      sourceRef,
      taskId,
    ]
  );
  return rows[0] ?? null;
}

// -------------------------------------------------------------------------
// Reads
// -------------------------------------------------------------------------

// All learnings, newest first.
async function listAllLearnings({ limit = 200 } = {}) {
  const { rows } = await pool.query(
    `SELECT id, title, body_md, tags, related_files, captured_by,
            source, source_ref, task_id, created_at
       FROM learnings
       ORDER BY created_at DESC
       LIMIT $1`,
    [limit]
  );
  return rows;
}

// Find learnings whose tags overlap any of the given tags.
// Uses GIN index on tags via the && (overlap) operator.
// Empty tag list returns [] (matching nothing is more useful than matching all).
async function findLearningsByTags(tags, { limit = 50 } = {}) {
  if (!Array.isArray(tags) || tags.length === 0) return [];
  const { rows } = await pool.query(
    `SELECT id, title, body_md, tags, related_files, captured_by,
            source, source_ref, task_id, created_at
       FROM learnings
      WHERE tags && $1::text[]
      ORDER BY created_at DESC
      LIMIT $2`,
    [tags, limit]
  );
  return rows;
}

// Surface 2-3 learnings relevant to a task's touches[].
//
// Strategy: derive tag-candidates from each touches entry (full path + each
// path segment + basename without extension), then query for tag overlap.
// A learning tagged 'pms' will match a touches path like 'src/bongos/learnings.js';
// a learning tagged 'caddy' will match touches path 'infra/Caddyfile' iff the
// learning was tagged 'infra' or 'caddyfile' (basename match).
//
// Consumers:
//   - scripts/gds/claim.js calls this indirectly via
//     GET /api/gds/learnings?touches=a,b,c so /builder-claim N can surface
//     up to 3 most-recent relevant learnings right after a successful claim.
//     Query overhead is bounded by the GIN(tags) + GIN(related_files) indexes
//     declared in migration 006_pms_v2.sql (<50ms target).
async function findLearningsForTouches(touchesArr, { limit = 3 } = {}) {
  if (!Array.isArray(touchesArr) || touchesArr.length === 0) return [];
  const tagCandidates = tagsFromTouches(touchesArr);
  if (tagCandidates.length === 0) return [];
  const { rows } = await pool.query(
    `SELECT id, title, body_md, tags, related_files, captured_by,
            source, source_ref, task_id, created_at
       FROM learnings
      WHERE tags && $1::text[]
         OR related_files && $2::text[]
      ORDER BY created_at DESC
      LIMIT $3`,
    [tagCandidates, touchesArr, limit]
  );
  return rows;
}

// touches[] cleanup [3/8] (task 878): re-key the claim-time "relevant learnings"
// lookup off the task's discipline + title instead of its predicted touches[].
// touches[] is becoming an optional advisory (#882) — at CLAIM time it is often
// empty, which made the old touches-keyed lookup silently return nothing right
// when it's wanted. discipline + title are always present on the task. We match
// a learning when its tags overlap the candidates (discipline + meaningful title
// words) OR its title contains one of those words — so a task about "migrations"
// surfaces the migration-counter learning regardless of any file prediction.
const TASK_TAG_STOPWORDS = new Set([
  'the', 'and', 'for', 'with', 'from', 'into', 'this', 'that', 'via', 'per',
  'task', 'cleanup', 'fix', 'add', 'make', 'must', 'when', 'then', 'over',
]);

function tagsFromTask({ discipline, title } = {}) {
  const out = new Set();
  if (discipline && typeof discipline === 'string') {
    const d = discipline.trim().toLowerCase();
    if (d && d !== 'unclassified') out.add(d);
  }
  if (title && typeof title === 'string') {
    for (const w of title.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean)) {
      if (w.length >= 4 && !TASK_TAG_STOPWORDS.has(w)) out.add(w);
    }
  }
  return Array.from(out);
}

async function findLearningsForTask({ discipline, title, limit = 3 } = {}) {
  const candidates = tagsFromTask({ discipline, title });
  if (candidates.length === 0) return [];
  const { rows } = await pool.query(
    `SELECT id, title, body_md, tags, related_files, captured_by,
            source, source_ref, task_id, created_at
       FROM learnings
      WHERE tags && $1::text[]
         OR EXISTS (SELECT 1 FROM unnest($1::text[]) kw WHERE title ILIKE '%' || kw || '%')
      ORDER BY created_at DESC
      LIMIT $2`,
    [candidates, limit]
  );
  return rows;
}

// Derive lowercase tag-candidates from touches paths.
//   'src/bongos/learnings.js' → ['src/bongos/learnings.js', 'src', 'pms', 'learnings.js', 'learnings']
function tagsFromTouches(touchesArr) {
  const out = new Set();
  for (const raw of touchesArr) {
    if (!raw || typeof raw !== 'string') continue;
    const p = raw.toLowerCase();
    out.add(p);
    for (const seg of p.split('/').filter(Boolean)) {
      out.add(seg);
      // basename minus extension
      const dot = seg.lastIndexOf('.');
      if (dot > 0) out.add(seg.slice(0, dot));
    }
  }
  return Array.from(out);
}

module.exports = {
  createLearning,
  listAllLearnings,
  findLearningsByTags,
  findLearningsForTouches,
  findLearningsForTask,
  // windowed content-hash dedup (ADR 0095 C5, task 1662)
  learningContentHash,
  DEDUP_WINDOW_MS,
  // exported for tests
  _tagsFromTouches: tagsFromTouches,
  _tagsFromTask: tagsFromTask,
};
