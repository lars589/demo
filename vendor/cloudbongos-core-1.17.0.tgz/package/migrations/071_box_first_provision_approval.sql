-- 071_box_first_provision_approval.sql — ADR 0035 Decision 2 (#717): a newcomer's
-- FIRST box must be approved by an Archon before any paid droplet is created.
--
-- Context
-- -------
-- #701 (migration 070) made POST /box/ensure enqueue a provision/wake intent that
-- the control-plane runner (box.js run-intents) auto-drains. That is correct for
-- wakes and for a builder who has already EARNED a box — but anyone with a GitHub
-- account can sign in and become a Xenos, and a Xenos is above the box provisioning
-- floor, so a bare signup could cause a paid droplet (~$24/mo) to be created with
-- NO human in the loop. On a ~$5,000/yr budget that is an open cost hole
-- (ADR 0035 §Problem-3).
--
-- This migration adds a 'pending_approval' state to box_intents. A provision intent
-- for a builder with no prior provisioned box is enqueued as 'pending_approval'
-- (NOT 'pending'), so the runner — which only ever claims state='pending' — skips
-- it until an Archon approves (POST /box/intents/:id/approve flips it to 'pending').
-- Wakes and any subsequent provision auto-drain unchanged. The web tier still only
-- RECORDS A REQUEST; it never holds DO_API_TOKEN (the migration 070 invariant) — so
-- approval authorizes spend without granting the web any power over infrastructure.
--
-- Idempotent: safe to re-run.

-- Widen the state CHECK to admit 'pending_approval'. Postgres has no ALTER ... ADD
-- VALUE for a CHECK constraint, so drop + re-add. The inline column constraint from
-- migration 070 is auto-named <table>_<column>_check.
ALTER TABLE box_intents DROP CONSTRAINT IF EXISTS box_intents_state_check;
ALTER TABLE box_intents ADD CONSTRAINT box_intents_state_check
  CHECK (state IN ('pending', 'pending_approval', 'running', 'done', 'error'));

-- Audit: who approved the held first-box provision, and when.
ALTER TABLE box_intents ADD COLUMN IF NOT EXISTS approved_by text;
ALTER TABLE box_intents ADD COLUMN IF NOT EXISTS approved_at timestamptz;

-- 'pending_approval' is an OPEN state: it must count toward the one-open-intent-per-
-- builder rule (else a builder could pile up approval requests). Recreate the partial
-- unique index to include it. The runner's hot-path index (idx_box_intents_pending)
-- stays on state='pending' only, so a held intent is NEVER claimed by the runner —
-- approval (flip to 'pending') is precisely what makes it visible to the drainer.
DROP INDEX IF EXISTS ux_box_intents_open;
CREATE UNIQUE INDEX IF NOT EXISTS ux_box_intents_open
  ON box_intents (builder_id)
  WHERE state IN ('pending', 'pending_approval', 'running');

INSERT INTO schema_migrations (version) VALUES ('071_box_first_provision_approval')
  ON CONFLICT (version) DO NOTHING;
