# ADR 0057 — Approve new members and first dev boxes from Discord (Archon 👍/👎)

**Date:** 2026-06-15
**Context:** GDS-V4, task [#1100](https://example.com/builders#/task/1100). Builds on [ADR 0033](<redacted>.md) (the in-process Discord bot as a service principal), [ADR 0037](<redacted>.md) (config-driven channel layout), [ADR 0016](<redacted>.md) (server-enforced permissions / trust boundary), [ADR 0035](<redacted>.md) §2 (the first-box Archon approval gate, [#717](https://example.com/builders#/task/717)), and [ADR 0050](<redacted>.md) (invite-gated admission).
**Status:** Accepted.
**Track:** `internal` (development system / onboarding + Discord surface).

> **⚠️ Superseded in part by [ADR 0059](<redacted>.md) (task [#1141](https://example.com/builders#/task/1141)).** The **box half** — the `📦-box-approvals` channel and the box-intent 👍/👎 approve/deny wiring — is **removed**: there is no longer a first-box approval gate, so an admitted builder's first box provisions hands-off. The **member half** (`🚪-member-approvals` + the admit/dismiss reaction wiring) is unchanged — member-join admission is still the gate. Read the box-channel parts below as historical.

## Problem

Two recurring Archon decisions could only be made on the example builders hall ("the Watch", `/builders/watch`):

1. **Admit a new builder.** A stranger submits their GitHub username → an `access_requests` row lands at `status='pending'` → an Archon flips it to `'invited'` (or `'dismissed'`) via `PATCH /api/gds/access-requests/:id` (ADR 0050).
2. **Approve a first dev box.** A newcomer's first paid droplet is held at `box_intents.state='pending_approval'` (ADR 0035 §2) until an Archon flips it to `'pending'` via `POST /api/gds/box/intents/:id/approve`, at which point the control-plane runner provisions it.

Both required opening the hall. The owner already lives in Discord (where ship news, ideas, and bugs already flow — ADR 0033). Neither request emitted any notification, so an Archon had to *remember to check* the Watch. The ask: do both approvals from Discord, with a 👍 reaction, in two **separate** channels.

## Decision

Add two Archon-only Discord channels and wire a reaction handler to the two existing approve actions. **No new authority** is created — Discord becomes a faster trigger for server actions that already exist and are already Archon-gated.

- **Channels** (`docs/discord/channels.json`, reconciled per ADR 0037): `🚪-member-approvals` and `📦-box-approvals`, both `view: archon`. Kept separate as requested.
- **Outbound (request → channel).** When an `access_request` is created (`POST /access-requests`) the GDS posts a one-line request to `#member-approvals`; when a `box_intent` enters `pending_approval` (`POST /box/ensure`) it posts to `#box-approvals`. Both go through the channel's **incoming webhook** (`scripts/discord/lib.postWebhook`) — the same outbound-only mechanism as ship-news — via `src/bongos/approval-broadcast.js`. Best-effort and fire-and-forget: a Discord hiccup never blocks or fails the request path, and the hall queue remains the source of truth.
- **Inbound (👍/👎 → action).** The in-process bot's reaction handler (`src/bongos/discord-bot.js` → `src/bongos/discord-approvals.js`) reacts to 👍/👎 in those two channels:
  - `#member-approvals` 👍 → `access_requests` `'invited'`; 👎 → `'dismissed'`.
  - `#box-approvals` 👍 → `boxes.approveIntent` (held → `pending`, runner provisions); 👎 → `boxes.denyIntent`.

### Marker contract

Each request line **leads** with a `<kind> #<id>` token (`member-request #<id>` / `box-intent #<id>`), mirroring how ship-feed lines lead with `#<taskId>` (ADR 0033 §3). The handler anchors to the start of the message, so a body that happens to contain another `#5` cannot hijack the mapping. The producer (`approval-broadcast`) and parser (`discord-approvals.parseApprovalMarker`) are unit-tested to round-trip.

### The deny path for boxes

`box_intents.state` has no `denied` value, and adding one would need a migration to widen the CHECK. A 👎 instead resolves the held intent to terminal `state='error'` with `last_error='denied:archon:<login>'` (free-text `box_events.event='intent_denied'` records it). The runner only ever claims `state='pending'`, so a denied intent is never provisioned; `'error'` reads distinctly from a real provisioning failure via the `denied:` prefix. A terminal state frees the `ux_box_intents_open` index, so a declined newcomer can re-request later — symmetric with how a `'dismissed'` access request can be re-submitted. **No migration.**

## Why this is safe — the trust boundary holds (ADR 0016 / 0033 §1)

The one invariant: *every bot-triggered write re-checks the linked builder's LIVE rank.* The bot asserts only **who** reacted (Discord user → linked builder via the F1 link table, which reads `builders.rank` fresh); the GDS decides **what** they may do. Both actions are `requireRank('archon')` on the web, so `discord-approvals` re-derives the reactor's live rank and acts **only** when it is `archon`. A Metic, a player, or an unlinked reactor is a silent no-op. The bot cannot escalate; the worst a compromised bot could do is mis-report which Archon reacted — bounded by the `audit_log` (every write recorded with `surface='discord_bot'`).

Defense in depth, all fail-closed:

- **Webhook-only request lines.** The handler acts only on messages with a non-null `webhookId`. A member cannot post as a webhook (needs Manage Webhooks + the secret URL), so a hand-typed `member-request #5` can't trigger an approval — enforced in code, not just by channel permissions (the same guard ADR 0033 §3 uses for upvotes).
- **Channel-pinned.** The handler is inert unless the channel ids are configured (`DISCORD_MEMBER_APPROVALS_CHANNEL_ID` / `DISCORD_BOX_APPROVALS_CHANNEL_ID`, or the creds file) — it never acts on reactions in arbitrary channels.
- **Idempotent.** Both actions guard on the current DB state (`status='pending'` / `state='pending_approval'`), so a duplicate or late reaction matches nothing and is a no-op (`already_resolved`), never a double-write.
- **Mention pings suppressed.** `postWebhook` already sends `allowed_mentions:{parse:[]}` ([#871](https://example.com/builders#/task/871)), so an attacker-influenceable display name / note in a request line can't `@everyone` the server.
- **Never throws into the gateway.** Every handler path is caught; the bot can't be crashed by a malformed reaction, and the web/game process is never at risk (ADR 0033 fail-safe).

## Operator setup (inert until configured)

The feature ships dormant — the same posture as every other Discord surface. To turn it on:

1. Create the `🚪-member-approvals` and `📦-box-approvals` channels (or let the channel reconciler create them from `channels.json`).
2. Create an incoming webhook in each; store the URLs as `member_approvals` / `box_approvals` in `~/.config/otb/discord-webhooks.json` (or env `DISCORD_MEMBER_APPROVALS_WEBHOOK` / `DISCORD_BOX_APPROVALS_WEBHOOK`).
3. Record the two channel ids as `member_approvals_channel_id` / `box_approvals_channel_id` in `~/.config/otb/discord-bot.json` (or the matching env vars).

Until both halves are set, requests simply aren't posted and reactions aren't acted on; the hall Watch is unaffected.

## Alternatives considered

- **A new HTTP endpoint the bot calls.** Rejected — the bot is in-process (ADR 0033 F3), so it calls the function directly: no localhost self-HTTP, no minted bot session token to store/leak, strictly less attack surface. Same rationale as `discord-reaction`.
- **Reading the reactor's Discord @Archon role to authorize.** Rejected — Discord roles are cosmetic badges synced one-way from `builders.rank` (ADR 0033 §4); trusting them back would invert the trust boundary. We re-derive rank from the GDS.
- **Bot posts confirmations via the gateway client.** We post the short `✅ … invited/approved.` confirmation through the channel webhook instead, keeping the bot's write surface to Discord minimal (it adds no authority either way).
- **A migration adding a `denied` box-intent state.** Rejected for now — terminal `error` + a `denied:` prefix is sufficient and avoids a schema change; revisit if the roster UI needs to distinguish denials visually.
