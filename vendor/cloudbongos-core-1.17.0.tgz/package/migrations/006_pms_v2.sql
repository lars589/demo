-- 006_pms_v2.sql — PMS-V2 schema additions
--
-- See limitations/pms-v2.md for the king scope file.
-- See docs/adr/0010-pms-architecture.md for the architecture rationale (carries forward).
--
-- This migration adds:
--   - new columns on existing tables (tasks.kind, tasks.parent_task_id,
--     tasks.actual_minutes, tasks.scoping_confidence, claims.head_sha,
--     builders.timezone)
--   - new tables (achievements, builder_achievements, learnings, idea_inbox,
--     done_when_criteria, session_pulses)
--   - new view (tasks_session_fit)
--   - rebuilt views (claimable_tasks, version_progress) with the new
--     columns + parent/child rollup semantics
--   - seeds (8 achievements, V1 + PMS-V2 done-when criteria)
--
-- Idempotent: safe to re-run. Each ALTER, CREATE, INSERT uses IF NOT EXISTS
-- or ON CONFLICT.

-- =========================================================================
-- 1. New columns on existing tables
-- =========================================================================

-- builders.timezone — IANA name. Set on first auth from CLI's local TZ.
ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS timezone text NOT NULL DEFAULT 'America/New_York';

-- tasks.kind — required category, with auto-classifier escape valve 'unclassified'
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS kind text NOT NULL DEFAULT 'unclassified';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'tasks_kind_check'
  ) THEN
    ALTER TABLE tasks ADD CONSTRAINT tasks_kind_check
      CHECK (kind IN (
        'feature','bug','infra','refactor','spike',
        'learning-capture','cleanup','decision','blocker-resolution',
        'unclassified'
      ));
  END IF;
END $$;

-- tasks.parent_task_id — shallow hierarchy (one level deep, enforced in app code)
ALTER TABLE tasks
  ADD COLUMN IF NOT EXISTS parent_task_id bigint REFERENCES tasks(id);

CREATE INDEX IF NOT EXISTS idx_tasks_parent ON tasks (parent_task_id);

-- tasks.actual_minutes — wall-clock from session_logs at ship; computed in C4
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS actual_minutes integer;

-- tasks.scoping_confidence — 1..5 self-reported "how well-scoped is this?"
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS scoping_confidence integer;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'tasks_scoping_confidence_check'
  ) THEN
    ALTER TABLE tasks ADD CONSTRAINT tasks_scoping_confidence_check
      CHECK (scoping_confidence IS NULL OR scoping_confidence BETWEEN 1 AND 5);
  END IF;
END $$;

-- claims.head_sha — git HEAD captured at claim time; used by C3 incidental-work scanner
ALTER TABLE claims ADD COLUMN IF NOT EXISTS head_sha text;

-- =========================================================================
-- 2. New tables
-- =========================================================================

-- achievements — fixed catalog of 8 in V2; new ones require migration + rule
CREATE TABLE IF NOT EXISTS achievements (
  id            text PRIMARY KEY,
  name          text NOT NULL,
  description   text NOT NULL,
  icon          text,
  credit_bonus  integer NOT NULL DEFAULT 0,
  sort_order    integer NOT NULL DEFAULT 100
);

-- builder_achievements — unlock ledger; PK enforces "unlock once per builder"
CREATE TABLE IF NOT EXISTS builder_achievements (
  builder_id           bigint NOT NULL REFERENCES builders(id),
  achievement_id       text   NOT NULL REFERENCES achievements(id),
  unlocked_at          timestamptz NOT NULL DEFAULT now(),
  unlocked_by_task_id  bigint REFERENCES tasks(id),
  PRIMARY KEY (builder_id, achievement_id)
);

CREATE INDEX IF NOT EXISTS idx_builder_achievements_builder
  ON builder_achievements (builder_id);

-- learnings — structured capture of paid-once knowledge
CREATE TABLE IF NOT EXISTS learnings (
  id              bigserial PRIMARY KEY,
  title           text NOT NULL,
  body_md         text NOT NULL,
  tags            text[] NOT NULL DEFAULT '{}',
  related_files   text[] NOT NULL DEFAULT '{}',
  captured_by     bigint REFERENCES builders(id),
  source          text,
  source_ref      text,
  task_id         bigint REFERENCES tasks(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_learnings_tags_gin
  ON learnings USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_learnings_related_files_gin
  ON learnings USING gin (related_files);
CREATE INDEX IF NOT EXISTS idx_learnings_created
  ON learnings (created_at);

-- Idempotency: same (source, source_ref) skips reinsert, mirroring cost_log
CREATE UNIQUE INDEX IF NOT EXISTS uniq_learnings_source_ref
  ON learnings (source, source_ref)
  WHERE source IS NOT NULL AND source_ref IS NOT NULL;

-- idea_inbox — structured replacement for free-form generative-ideas.md
CREATE TABLE IF NOT EXISTS idea_inbox (
  id                  bigserial PRIMARY KEY,
  title               text NOT NULL,
  body_md             text NOT NULL DEFAULT '',
  kind                text NOT NULL DEFAULT 'unclassified'
                      CHECK (kind IN (
                        'feature','bug','infra','refactor','spike',
                        'learning-capture','cleanup','decision','blocker-resolution',
                        'unclassified'
                      )),
  suggested_version   text REFERENCES versions(id),
  suggested_priority  integer
                      CHECK (suggested_priority IS NULL OR suggested_priority BETWEEN 1 AND 5),
  captured_at         timestamptz NOT NULL DEFAULT now(),
  captured_by         bigint REFERENCES builders(id),
  status              text NOT NULL DEFAULT 'open'
                      CHECK (status IN ('open','promoted','discarded','merged')),
  promoted_to_task_id bigint REFERENCES tasks(id),
  reviewed_at         timestamptz
);

CREATE INDEX IF NOT EXISTS idx_idea_inbox_status
  ON idea_inbox (status);
CREATE INDEX IF NOT EXISTS idx_idea_inbox_captured_at
  ON idea_inbox (captured_at);

-- done_when_criteria — per-version structured "is this version done?" gate
CREATE TABLE IF NOT EXISTS done_when_criteria (
  id                    bigserial PRIMARY KEY,
  version_id            text NOT NULL REFERENCES versions(id),
  criterion_id          text NOT NULL,
  criterion_md          text NOT NULL,
  satisfied             boolean NOT NULL DEFAULT false,
  satisfied_by_task_id  bigint REFERENCES tasks(id),
  checked_at            timestamptz,
  sort_order            integer NOT NULL DEFAULT 100,
  UNIQUE (version_id, criterion_id)
);

CREATE INDEX IF NOT EXISTS idx_done_when_version
  ON done_when_criteria (version_id);

-- session_pulses — heartbeat for stale-claim detection (C1)
CREATE TABLE IF NOT EXISTS session_pulses (
  claim_id        bigint PRIMARY KEY REFERENCES claims(id) ON DELETE CASCADE,
  builder_id      bigint NOT NULL REFERENCES builders(id),
  last_pulse_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_session_pulses_last_pulse
  ON session_pulses (last_pulse_at);

-- =========================================================================
-- 3. View rebuilds
-- =========================================================================

-- claimable_tasks: same semantics as 005, but now using SELECT t.* so the
-- new task columns (kind, parent_task_id, actual_minutes, scoping_confidence)
-- flow through to API consumers without a future view-rebuild.
DROP VIEW IF EXISTS claimable_tasks;
CREATE VIEW claimable_tasks AS
SELECT t.*
  FROM tasks t
 WHERE t.status = 'ready'
   AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
   AND NOT EXISTS (
     SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id
   )
   AND NOT EXISTS (
     SELECT 1 FROM claims c
       JOIN tasks t2 ON t2.id = c.task_id
      WHERE c.released_at IS NULL
        AND t2.touches && t.touches
   );

-- tasks_session_fit (P2): derives session-mode fit + credits-per-minute
-- from existing automation_tag + manual_degree + blocker presence.
CREATE OR REPLACE VIEW tasks_session_fit AS
SELECT t.*,
  CASE
    WHEN t.automation_tag = 'overnight-safe' AND COALESCE(t.manual_degree, 5) <= 2
         AND NOT EXISTS (SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id)
      THEN ARRAY['autonomous','check-in','active']
    WHEN t.automation_tag = 'live-only' OR COALESCE(t.manual_degree, 5) >= 4
      THEN ARRAY['active']
    ELSE ARRAY['check-in','active']
  END AS fits_session_modes,
  CASE WHEN t.credits_reward > 0 AND t.est_minutes IS NOT NULL AND t.est_minutes > 0
    THEN ROUND(t.credits_reward::numeric / t.est_minutes, 3)
    ELSE NULL
  END AS credits_per_minute
FROM tasks t;

-- version_progress: rebuilt to count only LEAF tasks (those with no children).
-- Today no tasks have children, so this is identical in behavior to 005's
-- view. Once C2 lands, parent tasks become aggregators of their children
-- and stop being counted directly.
DROP VIEW IF EXISTS version_progress;
CREATE VIEW version_progress AS
SELECT v.id AS version_id,
       v.name,
       v.track,
       v.status,
       count(*) FILTER (WHERE t.status = 'shipped') AS shipped_count,
       count(*) AS total_count,
       COALESCE(sum(
         CASE WHEN t.status = 'shipped' THEN 6 - COALESCE(t.priority, 5) ELSE 0 END
       ), 0)::bigint AS shipped_weight,
       COALESCE(sum(6 - COALESCE(t.priority, 5)), 0)::bigint AS total_weight
  FROM versions v
  LEFT JOIN tasks t
    ON t.version_id = v.id
   AND (t.title IS NULL OR t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\')
   AND NOT EXISTS (
     SELECT 1 FROM tasks child WHERE child.parent_task_id = t.id
   )
 GROUP BY v.id, v.name, v.track, v.status;

-- =========================================================================
-- 4. Seeds: achievements (8 fixed in V2)
-- =========================================================================
-- Bonuses: 1c/1c/2c/2c/5c/2c/2c/5c — total possible 20c per builder.
-- Adjustable later before bringing in another builder (per Lars).

INSERT INTO achievements (id, name, description, icon, credit_bonus, sort_order) VALUES
  ('first-ship',           'First Ship',
   'Ship your first task.',
   '📦', 1, 10),
  ('first-claim',          'First Claim',
   'Claim your first task.',
   '🪙', 1, 20),
  ('first-parallel-claim', 'First Parallel Claim',
   'Hold two simultaneous claims; ship both successfully.',
   '⚓', 2, 30),
  ('streak-3',             'Streak: 3 Nights',
   'Ship a task in 3 consecutive local-time nights (≥15min, kind != cleanup).',
   '🔥', 2, 40),
  ('streak-7',             'Streak: 7 Nights',
   'Ship a task in 7 consecutive local-time nights (≥15min, kind != cleanup).',
   '🌋', 5, 50),
  ('art-pipeline-shipper', 'Art Pipeline Shipper',
   'Ship a task whose touches[] include the art/ pipeline.',
   '🎨', 2, 60),
  ('pms-shipper',          'PMS Shipper',
   'Ship a task whose touches[] include src/pms/ or scripts/pms/.',
   '⚙️', 2, 70),
  ('breaking-the-100c-bar','Breaking the 100c Bar',
   'Cross 100 total credits.',
   '💯', 5, 80)
ON CONFLICT (id) DO UPDATE
  SET name         = EXCLUDED.name,
      description  = EXCLUDED.description,
      icon         = EXCLUDED.icon,
      credit_bonus = EXCLUDED.credit_bonus,
      sort_order   = EXCLUDED.sort_order;

-- =========================================================================
-- 4b. Pre-seed PMS-V2 + PMS-V3 versions rows (FK dependency for §5 and
--     for migration 011's done_when backfill).
-- =========================================================================
-- 003_pms.sql seeds only V1 + PMS-V1. The §5 seed below FK-references
-- PMS-V2, and migration 011 expects to UPDATE rows for PMS-V2 and PMS-V3.
-- On production this works only because the rows were inserted manually
-- during V2 planning. On a from-scratch DB restore §5 FK-fails before
-- the chain can complete. Pre-seeding here closes that hole (idea #13).
--
-- done_when is left empty here; migration 011 fills it from the king
-- scope docs. ON CONFLICT DO NOTHING preserves whatever shape these rows
-- already have on production.

-- Instance-seed guard (task 1704 / ADR 0105): OTB internal versions — must not
-- seed onto a vanilla / non-owning DB. See scripts/migrate.sh (app.seed_instance_data).
DO $seed$ BEGIN IF current_setting('app.seed_instance_data', true) IS DISTINCT FROM 'off' THEN
INSERT INTO versions (id, name, track, status, scope_doc_path, started_at, done_when)
VALUES
  ('PMS-V2', 'PMS V2 — methodology overhaul + auto-logging + achievements', 'internal', 'building',
   'limitations/pms-v2.md', '2026-05-10'::timestamptz, ''),
  ('PMS-V3', 'PMS V3 — planning', 'internal', 'planning',
   NULL, '2026-05-10'::timestamptz, '')
ON CONFLICT (id) DO NOTHING;
END IF; END $seed$;

-- =========================================================================
-- 5. Seeds: PMS-V2 done-when criteria (mirrors limitations/pms-v2.md)
-- =========================================================================

-- Instance-seed guard (task 1704 / ADR 0105): OTB PMS-V2 scope-truth. FK-references
-- the PMS-V2 version guarded above, so this must skip on a vanilla DB too.
DO $seed$ BEGIN IF current_setting('app.seed_instance_data', true) IS DISTINCT FROM 'off' THEN
INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, sort_order) VALUES
  ('PMS-V2', 'web-ui',
   '/builders themed read-only single-page web UI with copy-prompt-to-clipboard per task',
   10),
  ('PMS-V2', 'prompter-optimizer',
   'Full prompter optimizer: /builder-session with free-text + parallel-set + smart defaults; /builder-start enriched and drops cross-builder visibility',
   20),
  ('PMS-V2', 'achievements',
   'Achievement system (8 achievements, 20c bonus pool, top-10 paged badges, anti-gaming guards)',
   30),
  ('PMS-V2', 'never-miss',
   'Learnings + idea_inbox + task_kind: never miss a learning, every AI-generated task has a kind',
   40),
  ('PMS-V2', 'auto-logging',
   'Auto-logging: session pulse, stale-claim detection, incidental-work scanner, estimate-vs-actual reconciliation',
   50),
  ('PMS-V2', 'auto-versioning',
   'Auto-versioning: structured done-when criteria, gated close-flow (80% AND all criteria), auto-draft of next-version scope',
   60),
  ('PMS-V2', 'single-source-claim',
   'Single-source claim semantics carried through (LIMIT-1 fix from PMS-V1 holds)',
   70)
ON CONFLICT (version_id, criterion_id) DO UPDATE
  SET criterion_md = EXCLUDED.criterion_md,
      sort_order   = EXCLUDED.sort_order;
END IF; END $seed$;

-- =========================================================================
-- 6. Seeds: V1 done-when criteria (mirrors limitations/current-version.md)
-- =========================================================================
-- The V1 done-when (CLAUDE.md §9): "the experience supports the full
-- purchase loop: land in the world → walk to the vendor → buy a real
-- item → Hermeslines fulfills it." Decomposed into checkable criteria.

-- Instance-seed guard (task 1704 / ADR 0105): OTB V1 game scope-truth. FK-references
-- the V1 version guarded above, so this must skip on a vanilla DB too.
DO $seed$ BEGIN IF current_setting('app.seed_instance_data', true) IS DISTINCT FROM 'off' THEN
INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, sort_order) VALUES
  ('V1', 'world-land',
   'Visitor lands in the persistent world from amazonprimea.com',
   10),
  ('V1', 'walk-to-vendor',
   'Visitor can walk to Hyperion at the shipping container with WASD',
   20),
  ('V1', 'auth-magic-link',
   'Visitor authenticates via Stripe-tied magic link before purchase',
   30),
  ('V1', 'vendor-purchase',
   'Vendor dialog supports real-product purchase via Stripe',
   40),
  ('V1', 'hermeslines-fulfill',
   'Order intake reaches Hermeslines fulfillment system (whatever the format)',
   50),
  ('V1', 'order-confirmation',
   'Visitor receives order confirmation in-world',
   60)
ON CONFLICT (version_id, criterion_id) DO UPDATE
  SET criterion_md = EXCLUDED.criterion_md,
      sort_order   = EXCLUDED.sort_order;
END IF; END $seed$;

-- =========================================================================
-- 7. Migration record
-- =========================================================================

INSERT INTO schema_migrations (version) VALUES ('006_pms_v2')
  ON CONFLICT (version) DO NOTHING;
