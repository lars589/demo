-- 063_session_records_tool_errors_idx.sql — BFG session evaluator 6D.2 (ADR 0027).
--
-- searchSessions sorts AND filters on COALESCE((metrics->>'tool_error_count')::int, 0)
-- (the "interesting session" signal). Postgres only uses an expression index
-- when the indexed expression EXACTLY matches the query's — so the index must
-- include the same COALESCE wrapper db.js uses, or it's inert (#541 grade).
--
-- Harmless + fast at current scale (the table is tiny); this is forward cover.

CREATE INDEX IF NOT EXISTS idx_session_records_tool_errors
  ON session_records ((COALESCE((metrics->>'tool_error_count')::int, 0)));
