# 0004 — "Example" as the in-world civilization name (trademark risk knowingly accepted)

- **Status:** Accepted
- **Date:** 2026-05-08
- **Deciders:** Lars

## Context

The world needs a name for the new civilization that grows around the washed-ashore shipping container. The name should:

- Read as belonging in the ancient-Greek setting
- Carry the brand wink — Example undercuts Amazon-style logistics, and the container is the inciting object
- Be coined (not a real Greek place name we'd mispresent)

The candidate "Example" landed because it does triple duty: a tongue-in-cheek nod to **Amazon Prime**, a callback to the **Amazons** of Greek mythology (warrior tribe — fits the early-civilization setting), and a believable coined place-name.

The obvious problem: it contains the protected marks "Amazon" and "Amazon Prime." Amazon's legal team enforces trademark aggressively.

## Decision

We will use **Example** as the civilization name, knowingly accepting the trademark risk.

To minimize the cost of a forced rebrand, the name must be treated as a **single string in one config**. It must not be baked into:

- Class names, type names, function names, file names
- Database schemas (table/column/enum names)
- Asset filenames
- URL paths beyond the apex domain itself

The apex domain `example.com` is the painful piece on rebrand — accepted.

## Alternatives considered

- **A cleaner coined name (e.g. "Hermeia," "Korykos," "Boreas")** — eliminates trademark exposure but loses the brand wink that ties the world to Example's positioning against Amazon-scale logistics. Lars judged the brand wink worth the risk.
- **Use the name only in dialog/UI text, not as the formal civilization name** — half-measure that doesn't actually reduce legal exposure (the trademark issue is the use, not the formality).

## Consequences

- **Open legal risk.** Probability of Amazon legal making contact is non-zero, especially if the project gets visible.
- **Contingency plan, ready to execute on first contact:**
  1. Rebrand the civilization name (text-only — should be a single config string)
  2. Swap the apex domain (most painful step — DNS, certs, links, anything that has hardcoded `example.com`)
  3. World lore, container, vendor, and all game mechanics stay unchanged
- **Operating constraint for all future development:** every time the name is about to be embedded in code, file paths, schemas, or assets, **stop** and instead reference it indirectly through one config value.
- **Documented as an open risk in the project framing** so future sessions and team members understand the posture is "accepted, not unaware."
