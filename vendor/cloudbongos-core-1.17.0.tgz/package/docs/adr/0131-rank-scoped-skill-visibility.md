# 0131 — Rank-scoped skill visibility: feasibility spike + recommended approach

- **Status:** Spike outcome — **Proposed** (pending owner go-ahead to build). Documents a feasibility finding so future agents don't re-attempt the approach that doesn't work.
- **Date:** 2026-07-05
- **Deciders:** jaxri (Metic), Claude. Owner chose "design spike first" for task 1650.
- **Task:** [#1650](https://example.com/builders#/task/1650)

## Context

Task 1650 asks that a builder's Claude session list **only** the skills their live rank can use. Today every session lists every skill, so a lower-rank builder can invoke a gated skill (e.g. `/planning-session`, `/blocker-review`) and only gets stopped partway through — a confusing dead-end.

**This is UX decluttering, not a permission boundary.** Authority is already enforced two ways that stay exactly as-is: the server's `requireRank` (→ 403, [ADR 0016](<redacted>.md)) and each gated skill's own early rank self-check. Hiding a skill from the menu removes a dead-end; it grants and removes nothing. The task's assumed mechanism was **a `SessionStart` hook that filters the skill list by the rank we fetch at session start** (we already run such a hook, `.claude/hooks/session-start.js`).

## Finding (the spike result)

**Claude Code hooks cannot filter, hide, remove, or rewrite the skill listing the model sees.** This is unambiguous in the current docs:

- Skills are discovered by **directory scan** at session start (`.claude/skills/<name>/SKILL.md`); each skill's `name` + `description` is injected into context as a "skill listing" (the full body loads only on invoke).
- `SessionStart`'s only skill-relevant outputs are `additionalContext` (inject text) and `reloadSkills: true` (re-scan so **newly-written** skills appear — it can only **add**, never subtract). There is no field to hide or remove a skill.
- `PreToolUse` fires on the `Skill` tool at **invocation**, not on what's advertised. `UserPromptExpansion` can block a `/skill` **when the user types it**, but doesn't remove it from the menu.
- Hooks **cannot mutate settings at runtime** — settings are read from files at startup.

So the <redacted> design **does not exist**.

## Options that CAN achieve it

| # | Mechanism | Hide strength | Cost / caveats |
|---|---|---|---|
| **A** | Pre-launch step writes per-builder `skillOverrides: "off"` into `.claude/settings.local.json` **before** `claude` starts | **HARD** (menu + model + Remote Control/SDK) | Must be written by the **launcher** (the wrapper/box bootstrap that already fetches rank), NOT the SessionStart hook. Per-builder file; subject to the workspace-trust dialog; does **not** cover plugin-namespaced skills (`/engineering:*` etc.). |
| **B** | `Skill(name)` **deny** rules in settings | **HARD** on invocation (still shows in menu) | Belt-and-suspenders enforcement next to the server checks; same "written to a file, not by a live hook" constraint. |
| **D** | `SessionStart` `additionalContext` — inject "you are rank X; don't use skills P, Q, R" | **SOFT** (advisory) | Zero new infra — rank already comes from the existing hook. Menu unchanged; the model *can* still invoke a listed skill. |
| **E** | Per-skill self-check + bail (already in place) | menu unchanged, **effect gated** | This is what we do today; composes with server enforcement. |

## Recommendation

1. **Abandon the hook-filter premise** — it's not buildable. Record it here so we don't retry it.
2. **Don't invest in the heavy launcher change (A) yet.** Because this is UX-only — the server (ADR 0016) and each skill's self-check already enforce rank — a hard menu hide is a *nicety*, not a fix. Mechanism A rewires the launch path, generates a per-builder `settings.local.json`, and still misses plugin skills, for a purely cosmetic gain.
3. **If we want *some* declutter cheaply now,** ship mechanism **D**: extend the existing `session-start.js` hook to emit an `additionalContext` line naming the skills the builder's rank can't use ("these are visible but off-limits to your rank — don't reach for them"). It's a soft nudge, but it removes the dead-end surprise with zero new infra and no trust-dialog/plugin caveats.
4. **Revisit A** only if menu clutter becomes a real, reported pain — then move the `skillOverrides` write into whatever launches `claude` (a launcher wrapper or the box bootstrap), driven by the live rank.

Either way, the **server rank gate and the per-skill self-checks stay** — consistent with the trust-boundary rule that the DB enforces and markdown/settings only describe.

## References

- Claude Code docs: *Extend Claude with skills* (skill listing, `skillOverrides`, `Skill(...)` permissions), *Hooks* (`SessionStart` `additionalContext`/`reloadSkills`; no runtime settings mutation), *Configure permissions* (`Skill(name)` deny rules).
- Local: `.claude/hooks/session-start.js` (where rank is fetched today), `.claude/settings.json` (hooks/permissions wiring).
- [ADR 0016](<redacted>.md) — server-enforced permissions (the real gate this UX never replaces).
