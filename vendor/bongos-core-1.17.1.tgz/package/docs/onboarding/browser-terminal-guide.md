# Building from a Chromebook, iPad, or phone (the browser terminal)

*Plain-language how-to for builders on a device that can't run the Claude Code desktop app.*

Most builders run Claude Code in the **desktop app** (Mac or Windows). But you don't need it. If all you have is a **Chromebook, iPad, or phone** — anything with a web browser — you can still build, because your dev box serves its own **terminal in a browser tab**, and from there you switch to driving the box from the Claude app. This is the **Remote Control** path.

You never install anything and you never touch SSH. It's two things: open a link, then sign in.

> **On a Mac or Windows laptop?** You don't need this page — use the desktop app instead ([claude.com/download](https://claude.com/download)); it's the smoother path. This guide is only for browser-only devices.

## What you'll do, at a glance

1. Ask for your box and its terminal link (**`/builder-box`**).
2. Open the link and sign in.
3. Start Claude in the terminal and sign in once.
4. Switch to **Remote Control** so you can work from the Claude app.

That's it. Steps 1–3 are a one-time launchpad; after that you live in the Claude app.

## Step 1 — Get your box and the terminal link

In a Claude session, run **`/builder-box`**. It's your box's control panel — it will:

- **wake or create your box** hands-off if it isn't already running (you never wait on an operator), and
- give you your **terminal link** and a **one-time password** once the box is up.

If the box was asleep, give it about a minute to come up, then run `/builder-box` again to read the link. (Under the hood `/builder-box` uses the box's own web terminal, published to the hall — you don't need any of that detail; just run the command.)

## Step 2 — Open the link and sign in

1. Open the **terminal link** in any browser tab.
2. A small sign-in box appears. Enter:
   - **Username:** `otb`
   - **Password:** the one-time password `/builder-box` gave you.
3. You're now looking at a terminal running on your box, already in your project folder.

## Step 3 — Start Claude in the terminal

In that terminal, type:

```
claude
```

and press Enter. The first time, it walks you through a normal browser sign-in (and may ask you to trust the folder once — say yes). When it finishes, you're in a real, interactive Claude Code session on your box. This first sign-in is the whole reason the browser terminal exists: a real person at a real browser can complete the login that a headless setup never could.

## Step 4 — Switch to Remote Control (the daily surface)

The terminal is a **launchpad, not where you'll live.** Once Claude is running in the terminal, run this **inside that session**:

```
/remote-control
```

It prints a **pairing link**. Open that link and you can now drive your box straight from the **Claude web or mobile app** — a much nicer surface than the terminal tab. From here on, that's where you work; the terminal was just where you logged in.

> ⚠️ **Use the `/remote-control` slash command from inside a running Claude session — not a standalone `claude rc` command in the shell.** The standalone version mis-reads folder trust and fails; starting Remote Control from within an already-signed-in session is the path that works.

## Good to know

- **Closing the terminal tab ends the session and closes the box.** That's expected — it's how the session cleans up. Your work that's committed/shipped is safe; the box itself just shuts down.
- **The box sleeps when idle and wakes on demand.** Next time, start again at Step 1 — `/builder-box` wakes it and hands you a fresh link.
- **You also get a live game preview.** If your box is on the stable-hostname setup, your terminal link looks like `https://term-<you>.example.com`; your private game preview (the **sandbox**) is the same address with `term-` swapped for `sandbox-` — `https://sandbox-<you>.example.com`. Run **`/builder-stage`** to push your current edits there and review a change in a browser before you ship it. (See "Your own dev box" in the [primer](primer.md).)

## If something isn't working

- **No link yet?** The box may still be waking. Wait ~1 minute after `/builder-box` says it's starting, then run `/builder-box` again.
- **Password rejected?** Re-run `/builder-box` to get a fresh link + password — the box republishes them when it restarts.
- **Brand-new to the project on a browser-only device?** Getting the very first box onto a pure browser-only device can need a one-time assist (there's a known first-boot gap for a device with no terminal at all). If `/builder-box` can't hand you a link, ask an Archon to help seed your box once; after that the browser flow works on its own.

---

*Deeper detail (the systemd units, the Cloudflare tunnel, operator setup, and end-to-end verification) lives in the operator recipe [`docs/recipes/managed-settings-remote-control.md`](../recipes/managed-settings-remote-control.md) (Part 2) and [ADR 0038](../adr/<redacted>.md) / [ADR 0040](../adr/<redacted>.md). This page is the builder-facing summary of that flow.*
