// src/bongos/render-prefs.js — the per-builder "render widgets" knob (task 1279).
//
// Governs whether the deterministic session cards (start.js's /builder-start
// card + the ship-card lifecycle card: claimed → review → confirmed → shipped)
// render as a rich in-feed HTML widget (via the app's show_widget tool) or as
// the plain markdown / monospace fallback.
//
// Why it's a knob: the widget is nicer, but the agent must relay its full markup
// VERBATIM into show_widget — reading it once and re-emitting it once — so every
// byte of HTML is shuttled through the model twice, at every session-start,
// claim, and ship stage. Measured: the /builder-start widget is ~4.7K tokens vs
// ~0.5K for the markdown form (9×); the lifecycle card ~0.9K vs ~0.12K monospace
// (7×). This knob lets a builder turn that token cost off. When off, the CLIs
// emit ONLY the text form (no HTML is ever written or relayed) — so it's a real
// saving, not just a visual change.
//
// Unlike the wandering knob ([[wandering-prefs]]) this is pure cost/taste, NOT a
// trust gate — so there is NO rank cap: any builder may pick either value, and
// the default is ON (the experience tasks 1273/1275 deliberately shipped).
//
// Storage: one reserved key ('widgets') inside the `behavior_prefs` jsonb column
// on `builders` (migration 119 — the same blob the wandering knob uses). Value
// is a scalar boolean; a missing key falls back to DEFAULT_ENABLED, so the
// column stays sparse. applyPatch leaves sibling keys (e.g. 'wandering') alone.
//
// This module is the single source of truth: GET/PATCH /api/gds/me/render + the
// /me payload surface it, the /settings UI reads it, and the start/claim/ship
// CLIs read the resolved boolean to decide whether to emit HTML at all.

const RESERVED_KEY = 'widgets';
const DEFAULT_ENABLED = true;

// ---- pure helpers ----

// The raw override a builder has stored (the 'widgets' key off behavior_prefs),
// or null when unset/invalid. Kept separate from the effective value so the UI
// can show "you chose X" vs "the default (Y)".
function overrideEnabled(behaviorPrefs) {
  const raw = behaviorPrefs && behaviorPrefs[RESERVED_KEY];
  return typeof raw === 'boolean' ? raw : null;
}

// The resolved boolean — the value the CLIs act on. Override if set, else the
// default. This is the one function the start/claim/ship scripts care about.
function widgetsEnabled(behaviorPrefs) {
  const o = overrideEnabled(behaviorPrefs);
  return o === null ? DEFAULT_ENABLED : o;
}

// Everything the /me payload + the /settings UI need in one object.
function describeForApi(behaviorPrefs) {
  return {
    widgets_enabled: widgetsEnabled(behaviorPrefs),
    default_enabled: DEFAULT_ENABLED,
    override: overrideEnabled(behaviorPrefs),
  };
}

// Validate a PATCH body: { widgets: <bool> | null }. `null` clears the override
// (fall back to the default). Unknown keys → 422. Non-boolean values → 422.
// Returns { ok, patch } or { ok:false, errors }. An empty body is a valid no-op.
function validatePatch(body) {
  if (body == null || typeof body !== 'object' || Array.isArray(body)) {
    return { ok: false, errors: [{ error: 'body_must_be_object' }] };
  }
  const errors = [];
  const patch = {};
  for (const [key, value] of Object.entries(body)) {
    if (key !== RESERVED_KEY) {
      errors.push({ key, error: 'unknown_key', allowed: [RESERVED_KEY] });
      continue;
    }
    if (value === null || typeof value === 'boolean') {
      patch[RESERVED_KEY] = value; // null = clear → default
      continue;
    }
    errors.push({ key, error: 'invalid_value', value, allowed: 'boolean or null' });
  }
  if (errors.length > 0) return { ok: false, errors };
  return { ok: true, patch };
}

// Apply a validated patch to a builder's existing behavior_prefs. Pure. null
// deletes the key (fall back to default); a boolean overwrites. Other keys in
// the blob (e.g. the wandering knob) are left untouched.
function applyPatch(existing, patch) {
  const next = { ...(existing || {}) };
  for (const [key, value] of Object.entries(patch)) {
    if (value === null) delete next[key];
    else next[key] = value;
  }
  return next;
}

module.exports = {
  RESERVED_KEY,
  DEFAULT_ENABLED,
  overrideEnabled,
  widgetsEnabled,
  describeForApi,
  validatePatch,
  applyPatch,
};
