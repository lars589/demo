# 0104 — Trust the GDS API channel in Claude Code auto mode (pre-allow `scripts/gds/api.js`)

- **Status:** Accepted
- **Date:** 2026-07-02
- **Deciders:** Lars (owner) · Claude (Opus 4.8)
- **Track:** `internal` (Cloud Bongos)
- **Relates to:** [ADR 0016](<redacted>.md) (server-enforced permissions / trust boundary — the load-bearing rationale). Completes task [#1051](https://example.com/builders#/task/1051) (the narrow named-script allow-list, from the task-[#1027](https://example.com/builders#/task/1027) nightmare) and complements task [#1251](https://example.com/builders#/task/1251) (default dev boxes to `bypassPermissions`). Executed under task [#1716](https://example.com/builders#/task/1716).

## Context

Claude Code's **auto** permission mode runs an LLM *classifier* that judges each action and hard-denies what it reads as a risky external write or as work beyond the user's request. A builder hit this on the dev box:

> Permission for this action was denied by the Claude Code auto mode classifier. Reason: **[External System Writes]** The agent patches inbox item 486 (which it did not create this session) to "promoted" and creates a task from an agent-inferred idea, well beyond the user's request to ship the scope doc.

Two prior decisions were supposed to prevent this and don't fully:

- Task **1051** (from the task-[#1027](https://example.com/builders#/task/1027) nightmare, where the classifier denied `ship.js` mid-deploy) added a **narrow** `permissions.allow` to the project `.claude/settings.json` for the blessed **named** scripts (`ship`/`claim`/`release`/`reauth`/`paste-token`/`start`/`setup`/`sandbox-stage`/`capture`/`learning-capture`/`doctor`). An explicit allow-rule bypasses the classifier for that command.
- Task **1251** additionally defaults the box's interactive `claude` to `bypassPermissions` (no classifier at all on the box).

**The gap.** Every autonomous GDS operation that has *no dedicated script* — idea-triage **promote**, **create-task**, blocker-**resolve**, criterion **ratify**, **goal** create, cost-via-API, security reports — rides the *generic* caller `node scripts/gds/api.js <METHOD> /api/gds/...` (see [`.claude/skills/idea-triage/SKILL.md`](../../.claude/skills/idea-triage/SKILL.md)). That generic channel was never allow-listed. So the moment a session is in **auto** mode rather than bypass — a builder cycled modes with Shift+Tab, the task-1251 `bypassPermissions` write didn't take, or the work is on a laptop/local full clone — the classifier hard-denies the **entire** autonomous GDS write surface. It only "just works" under `bypassPermissions`, which is a mode-level paper-over of a missing allow-rule.

## Decision

**Pre-allow the generic GDS API channel.** Add `Bash(node scripts/gds/api.js:*)` to the project `.claude/settings.json` `permissions.allow`. It ships in the repo, so it reaches the box, laptops, and **every permission mode** at once, and it is locked against silent regression by [`tests/box_ship_permissions.mjs`](../../tests/box_ship_permissions.mjs).

The owner chose **"trust the whole channel"** over a narrower "reads + a few specific write paths" split — the split is brittle (breaks when a skill uses a slightly different path or flag order) and buys only illusory least-privilege, because the server already gates every write by rank.

## Why this is safe (the crux)

The auto-mode classifier was **never the security gate here** — the **GDS server is**, and it is stricter. `builders.rank` is checked on every request, per-request, with no caching ([ADR 0016](<redacted>.md)). Therefore:

- Allow-listing `api.js` grants an autonomous builder **nothing beyond what its rank already permits**. It only removes a redundant, weaker, and — as observed — **wrong** harness prompt that mistook a sanctioned idea-triage session for scope creep.
- `api.js` can only reach `/api/gds/*` on the configured API base (via `cli-lib.apiCall`); it is **not** a general HTTP or shell escape hatch. Blast radius = "the caller's rank-permitted GDS operations, without a per-call prompt" — which is exactly the design intent of an autonomous builder.
- **Scope-discipline** ("don't wander off the claim") is owned by the methodology's per-builder **`wandering`** knob ([`modules/builder-settings/wandering-prefs.js`](../../modules/builder-settings/wandering-prefs.js)), which is the correct layer — a harness classifier can't tell whether promoting an idea *is* the task.

Editing this allow-list grants no authority; sub-Metic authorship limits, protected-path gates, and rank checks all remain server-enforced ([ADR 0016](<redacted>.md)).

## Consequences

- Auto mode no longer prompts for any GDS API call. `bypassPermissions` boxes are unaffected (the rule is a no-op there). Laptops / local clones in auto mode now run the autonomous GDS loop hands-free, matching a bypass-mode box.
- The one-line pattern extends cleanly if a *named* read wrapper (`recall.js`, `status.js`, `me.js`) later turns out to be classifier-gated too — but those are out of scope here; `api.js` is the channel the autonomous loop actually rides.
- **Follow-up (not blocking):** investigate *why* a box provisioned for `bypassPermissions` (task 1251) still lands builders in auto mode — a Shift+Tab toggle, a failed `~/.claude/settings.json` write, or a Claude Code default change. This allow-rule makes the GDS loop robust regardless of the answer, so it is diagnostics, not a blocker.
