#!/usr/bin/env bash
# healthcheck.sh — image-level toolchain integrity check for the Amazonprimea
# Dev Box (ADR 0031 §3).
#
# This is the IMAGE half of "doctor.js as the health check": it answers "was the
# box built correctly?" using only what the image itself provides — no GDS
# session, no repo checkout, no network. The BUILDER half ("is *this builder*
# authed, hooked, and clean?") is scripts/gds/doctor.js, run at attach time.
#
# Two modes:
#   --build   run as the final Dockerfile RUN step (fail the build on a bad box).
#   (default) the runtime HEALTHCHECK / a recreated-box probe (#598).
#
# Both check the same stable, image-level toolchain. Repo-level facts (sharp in
# node_modules, the art libs in the venv) are installed at first-run by
# post-create.sh and verified there — they are intentionally NOT gated here so
# the container never flaps "unhealthy" during provisioning.
#
# NOTE on ordering: Node, the GitHub CLI, and Claude Code are installed by
# devcontainer *features*, which run AFTER the Dockerfile is built. So the
# --build assertion can't see Node — it checks only what the Dockerfile itself
# provides (the Python venv + firewall tooling). The Node check runs at runtime,
# where features are present.

set -uo pipefail

MODE="${1:-runtime}"
fails=0

ok()   { echo "  ok   $*"; }
bad()  { echo "  FAIL $*"; fails=$((fails + 1)); }

# Node >= 22 — runtime only (feature-installed after the Dockerfile build).
if [ "$MODE" != "--build" ]; then
  if command -v node >/dev/null 2>&1; then
    nver="$(node --version 2>/dev/null)"
    nmaj="$(echo "$nver" | sed 's/^v//' | cut -d. -f1)"
    if [[ "$nmaj" =~ ^[0-9]+$ ]] && [ "$nmaj" -ge 22 ]; then
      ok "node $nver (>= 22)"
    else
      bad "node $nver found, need >= 22"
    fi
  else
    bad "node not on PATH"
  fi
else
  echo "  --   node check deferred to runtime (feature-installed after the Dockerfile)"
fi

# Python >= 3.12 (the venv interpreter — must be first on PATH)
if command -v python3 >/dev/null 2>&1; then
  pyver="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null || echo "?")"
  pymaj="${pyver%%.*}"; pymin="${pyver#*.}"
  if [[ "$pymaj" =~ ^[0-9]+$ ]] && [[ "$pymin" =~ ^[0-9]+$ ]] \
     && { [ "$pymaj" -gt 3 ] || { [ "$pymaj" -eq 3 ] && [ "$pymin" -ge 12 ]; }; }; then
    ok "python ${pyver} (>= 3.12) [$(command -v python3)]"
  else
    bad "python ${pyver} found, need >= 3.12"
  fi
  # The venv must be the active interpreter so the art pipeline's deps resolve.
  if [ -n "${OTB_VENV:-}" ] && [ "$(command -v python3)" = "${OTB_VENV}/bin/python3" ]; then
    ok "art-pipeline venv active (${OTB_VENV})"
  else
    bad "expected venv python at ${OTB_VENV:-<unset>}/bin/python3, got $(command -v python3)"
  fi
else
  bad "python3 not on PATH"
fi

# Firewall tooling present (the default-deny boundary depends on it).
for tool in iptables ipset dig jq; do
  if command -v "$tool" >/dev/null 2>&1; then
    ok "$tool present"
  else
    bad "$tool missing (firewall/init would fail)"
  fi
done

if [ "$fails" -eq 0 ]; then
  [ "$MODE" = "--build" ] && echo "toolchain integrity: OK (build)"
  exit 0
fi
echo "toolchain integrity: ${fails} problem(s)"
exit 1
