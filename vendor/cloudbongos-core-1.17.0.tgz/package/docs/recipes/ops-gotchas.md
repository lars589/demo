---
track: internal
scope: shared-infra (production droplet, Caddy, Postgres, deploy chain) — touches both tracks but the *recipes themselves* are builder-facing
---

# Ops gotchas — read before deploying or touching infra

Things we've already paid for once. Don't pay again.

Organized by topic, not chronology. New entries go in the matching section; create a new section for a new topic.

---

## PostgreSQL

### `pg` defaults to TCP localhost, not the Unix socket

- **Symptom:** `new Pool()` with no `host` fails with `SASL: SCRAM-SERVER-FIRST-MESSAGE: client password must be a string`. The Node process appears to start, but every database call silently fails (or noisily fails depending on where it happens).
- **Root cause:** The `pg` library defaults to TCP `localhost`. With Postgres configured for **peer authentication** (matching the OS user to the DB user), TCP doesn't qualify — TCP requires a password, peer auth only works over the Unix socket. So `pg` tries TCP, Postgres demands a password, no password is provided, SASL bombs.
- **Fix:** Pass the socket directory explicitly:
  ```js
  new Pool({ host: '/var/run/postgresql' })
  ```
  (Or set `PGHOST=/var/run/postgresql` in the environment.) That directory is the Debian/Ubuntu default Postgres socket location; on other distros it may differ.
- **Why it bites:** The `pg` library's defaults assume a standard TCP+password setup, which is the most common configuration but not the cheapest one for a single-machine deploy. Peer auth is more secure and frictionless once you know the socket path. The error message points at SASL, not at the host setting, which buries the real cause.
- **Where this lives in the codebase:** [`src/db.js`](../../src/db.js) has the explicit socket host.

---

## Colyseus

### Server/client version skew between 0.16 and 0.17

- **Symptom:** `npm install colyseus` picks the latest 0.17.x server, but `colyseus.js` (the browser client) is still 0.16.x. Install fails with an `eresolve` peer-dependency error on `@colyseus/schema` because 0.17 wants schema v4 and 0.16 wants schema v3.
- **Root cause:** Colyseus releases server-side first; the browser client lags by several months. The two must be on the same major.minor.
- **Fix:** Pin all four to the same major.minor in `package.json`:
  ```json
  "colyseus": "^0.16",
  "@colyseus/ws-transport": "^0.16",
  "@colyseus/schema": "^3",
  "colyseus.js": "^0.16"
  ```
- **Why it bites:** `npm install <pkg>` pulls the latest version unless told otherwise, and there's no warning that the matching client doesn't exist yet. `colyseus.js` 0.17 will eventually ship — when it does, the pins can be lifted in lockstep.

### Colyseus 0.16 ignores `static maxClients`

- **Symptom:** Setting `maxClients` as a static class field on a Room subclass (the documented pattern in some online examples) has no effect. The room accepts unlimited clients.
- **Fix:** Set `this.maxClients = N` inside `onCreate()`. It is an instance property, not a static one, in 0.16.
- **Why it bites:** The docs and examples drift between Colyseus versions. The older static-field pattern is still findable on the web.

---

## Caddy + Cloudflare

### Let's Encrypt auto-renewal silently breaks under Cloudflare proxy (resolved)

- **Symptom:** Caddy obtained the initial cert fine, then failed to renew at the 90-day mark — site went down.
- **Root cause:** With Cloudflare proxy ON (orange cloud), CF intercepts port 80 at the edge and Caddy never sees the HTTP-01 challenge from Let's Encrypt. Renewal silently fails.
- **Fix (already in place):** Replaced Let's Encrypt with a Cloudflare Origin Certificate (15-year cert at `/etc/caddy/origin.crt` + `.key`, explicit `tls` directive in Caddyfile). Eliminates the auto-renewal dependency for the CF↔origin leg. See [ADR 0003](../adr/<redacted>.md).
- **Why it bites:** The failure mode is silent for ~89 days, then catastrophic. Easy to think the site is "set and forget" when it is actually approaching a cliff.

### Deploying configs to `/etc/caddy/` requires staging through `~/`

- **Symptom:** `scp` directly to `/etc/caddy/Caddyfile` fails with permission denied because `lars` doesn't own `/etc/caddy/`.
- **Fix:** `scp` to `~/staging/Caddyfile` first, then `sudo mv ~/staging/Caddyfile /etc/caddy/Caddyfile && sudo systemctl reload caddy`. Same pattern for the systemd unit at `/etc/systemd/system/example.service`.
- **Why it bites:** The deploy script handles this for normal app code, but config files in `/etc/` need the staging step. Easy to forget when you haven't touched infra in a while.

### Cloudflare hides real client IPs from the origin

- **Symptom:** Caddy logs show Cloudflare IPs (162.158.x.x, 172.69.x.x, etc.) instead of real visitor IPs.
- **Fix when needed:** Wire `trusted_proxies cloudflare` into the Caddyfile so Caddy honors `X-Forwarded-For` / `CF-Connecting-IP`. CF maintains the IP-range list — the directive auto-pulls it.
- **Why it bites:** Not yet biting (we're not rate-limiting or doing abuse detection). It will bite the moment we try to identify a single misbehaving client. Documented here so when that day comes the fix is one line.

---

## SSH + droplet

### Don't `apt-get upgrade` in a plain SSH session

- **Symptom:** Mid-upgrade, sshd restarts (because openssh-server was in the upgrade set). The SSH session drops, leaving the upgrade half-run and the operator locked out until they can reach the DigitalOcean web console.
- **Recovery (already once):** Power-cycle from DO web console, log back in, verify the upgrade completed. It usually has — apt is good at finishing what it started — but this is luck not design.
- **Fix going forward:** Skip routine `apt-get upgrade` entirely. Let `unattended-upgrades` handle security patches in the background — it's already enabled. If a manual upgrade is genuinely needed, wrap it in `tmux` or `screen` so it survives the session drop.
- **Why it bites:** sshd is the lifeline. Anything that touches it from inside an SSH session is dangerous.

### SSH is key-only, root login disabled

- **Reminder, not a gotcha:** `PermitRootLogin no`, `PasswordAuthentication no` in `/etc/ssh/sshd_config`. Only `lars` can log in, and only with the registered ed25519 key. If the key is ever lost, recovery is via DigitalOcean's web console (or by attaching the volume to a recovery droplet).

### SSH silently times out — fail2ban banned your IP

- **Symptom:** `ssh lars@REDACTED_IP` hangs and times out. `ping REDACTED_IP` works. `curl https://example.com/healthz` returns 200. Only port 22 from your specific public IP is dead. Looks identical to a firewall outage.
- **Root cause:** fail2ban (running on the droplet, watches `/var/log/auth.log`) saw N auth failures from your IP inside the rolling window and inserted an iptables `DROP` rule. Default policy in this distro: 5 failures in 10 minutes triggers a 10-minute ban. The drop is silent — no RST, no Mac-side log, no obvious error — which is why diagnosis is slow the first time.
- **Immediate fix:** DigitalOcean web console (it bypasses port 22 because it doesn't go through SSH at all). Log into the droplet via the console, then:
  ```bash
  sudo fail2ban-client status sshd            # confirm the IP is in the Banned list
  sudo fail2ban-client unban <your-public-IP>
  ```
  Then verify from the Mac: `ssh -o ConnectTimeout=5 lars@REDACTED_IP "uptime"` should respond in <1s.
- **Permanent fix:** add your IP to `/etc/fail2ban/jail.local`'s `ignoreip` list and reload fail2ban. `jail.local` overrides the package's `jail.conf` so apt upgrades won't trample the whitelist. Example file:
  ```ini
  [DEFAULT]
  ignoreip = 127.0.0.1/8 ::1 <your-public-IP>
  bantime = 10m
  findtime = 10m
  maxretry = 5

  [sshd]
  enabled = true
  ```
  Then `sudo systemctl reload fail2ban`. Confirm with `sudo fail2ban-client status sshd | grep -i ignor` — the IP should appear in the Ignored list.
- **Why it bites:** the failure mode is silent. There's no log on the Mac side, no log from the operating shell, and the symptom is indistinguishable from "port 22 is closed" or "the droplet is down." You only realize it's fail2ban after the DO console reveals the iptables DROP. First-time diagnosis is ~20 minutes; once you know the signature it's 30 seconds.
- **For new builders:** most builders (Metic and below) don't need direct droplet SSH — they work through the public API. The whitelist is primarily an Archon-comfort item. Don't reflexively add every new builder's IP; only add IPs for people who actually deploy.

---

## GitHub OAuth (web flow)

### Authorized callback URL must include the full /api/gds path

- **Symptom:** Visitor clicks "Sign in with GitHub" on /builders, GitHub renders its red "Be careful!" warning page or returns `?error=redirect_uri_mismatch`, and the visitor never lands back on the hall.
- **Root cause:** The GitHub OAuth app's **Authorization callback URL** field must match exactly what the server tells GitHub. Our server sends `${publicOrigin}/api/gds/auth/web/callback` — easy to misconfigure as just `https://example.com/` or `/auth/callback` when registering a fresh OAuth app.
- **Fix:** In github.com → Settings → Developer settings → OAuth Apps → (the Off the Boats app) → **Authorization callback URL**, set:
  ```
  https://example.com/api/gds/auth/web/callback
  ```
  No trailing slash, full path. If staging gets provisioned ([#260](https://example.com/builders#/task/260)) it will need a second OAuth app or the same app with multiple callback URLs (GitHub now supports up to 10).
- **Where this lives in the codebase:** [`src/bongos/routes/auth.js`](../../src/bongos/routes/auth.js) — `/auth/web/start` computes `redirectUri` from `publicOrigin(req)` and the `/auth/web/callback` route reads back to it. As of [#371](https://example.com/builders#/task/371) the error branches render a styled HTML page (with a retry link) instead of `text/plain`, so the visitor at least sees something coherent.
- **Why it bites:** GitHub's warning page is intentionally scary and doesn't tell you *which* URL it expected; the only diagnostic is the `error=redirect_uri_mismatch` query param on the redirect back, which our server now surfaces in the styled error page.

---

## Mac / local dev

### TextEdit defaults to RTF and silently corrupts plain-text files

- **Symptom:** Saved a Cloudflare Origin Cert to `~/Desktop/origin.crt` from TextEdit. The file ended up wrapped in RTF formatting codes (and TextEdit added `.rtf` to the filename).
- **Fix:** `textutil -convert txt -output X.crt X.crt.rtf` strips the RTF wrapper and writes plain PEM.
- **Going forward:** When editing certs, keys, configs, or any plain-text file on this Mac, either Format → Make Plain Text in TextEdit first, or use VS Code (plain text by default), or use `nano`/`vim` from the terminal.
- **Why it bites:** TextEdit's default makes sense for word-processing but is hostile to anything that needs to be byte-exact.

### `.env.local` is auto-provisioned into new worktrees (don't `cp` it by hand)

- **Behavior (V3.R59 [#278](https://example.com/builders#/task/278)):** `.env.local` is gitignored, so `git worktree add` does not carry it over. The `SessionStart` hook [`.claude/hooks/session-start.js`](../../.claude/hooks/session-start.js) copies it from the main checkout into the worktree on first session — no manual `cp` from a sibling needed.
- **If the main checkout has no `.env.local`:** the hook tells you to run `/builder-setup`.
- **The Google AI Studio key is separate:** it resolves from `~/.config/otb/env`, which already survives worktree churn — see [`art/pipeline/gen_api.py`](../../art/pipeline/gen_api.py).
- **All hooks run via `node`, not `bash` ([#671](https://example.com/builders#/task/671)):** `SessionStart`, `UserPromptSubmit`, and `Stop` run identically on Windows/macOS/Linux. `session-start.js` chains the env-copy + onboarding + rank-change greeting + memory pull that the old `sync-env-local.sh` shell chain ran.

---

## GDS build pipeline

### Two deterministic routines run as in-process server timers, not external cron

- **What:** `peer-vote-tally` (weekly) runs inside the always-on Node process via the autonomy module's poller `modules/autonomy/pollers/routine-timers.js` (ADR 0078 amendment, task 1382; carved into `modules/autonomy/` at BV1.R83) — no `claude -p`, no external cron, no token. The loader's `startModulePollers` starts it (on the game/droplet boot only); it reaches `tallyPeerVotes` through the doorway. It's a no-op anywhere the DB is unreachable (builder machines), so it only does work on the prod droplet.
- **Disable / move it out-of-process:** set `ROUTINE_TIMERS_DISABLED=1` in `/etc/example/web-source.env` and restart. Also set it on any **second** always-on instance that shares the `example` DB so the tally can't double-fold (the `FOR UPDATE OF pv` row lock is the hard guard if you forget).
- **Run it manually now:** `node scripts/gds/run-routine.js peer-vote-tally` (the dispatcher front door still works). The cadence is boot-anchored ("~90s after boot, then weekly"), not a wall-clock Monday job — frequent deploys re-anchor it, which is harmless (the tally is idempotent).

### A ship was graded FAIL but the work is genuinely good (grader false-negative)

- **Symptom:** `/builder-ship` runs the subagent grader and it hard-FAILs with blockers that are *factually wrong* — e.g. "No PNG committed" / "no evidence the review ran" / "empty diff — no files changed" — even though the work is committed on the branch and passed its own review. The task is stuck at `completed` with 0 credits, and the builder is below Archon so every fix route (`PATCH touches`, `POST /confirm`, override-decide) is gated.
- **Root cause (one known class, fixed):** the grader read a `null` baseline because the task had empty `touches[]`, so it diffed against nothing and "saw" zero files. Fixed in [#536](https://example.com/builders#/task/536) — the grader baseline is now derived from `git merge-base` independent of `touches[]`. If you hit a *different* false-negative class, treat the below as the general escape hatch.
- **The process (canonical — works at any rank):**
  1. The **stuck builder** (any rank, incl. Xenos) files an override request — this is the one builder-rank-available escape hatch:
     `POST /api/gds/tasks/:id/override-request` with `{ "rationale": "<≥20 chars: why the grade is wrong>" }`.
     This is *not* routing around the trust boundary — Xenos are allowed to file; only the decision is privileged.
  2. An **Archon** reviews the open queue (`GET /api/gds/override-requests?status=open`) and decides:
     `POST /api/gds/override-requests/:id/decide` with `{ "decision": "approve", "note": "..." }`.
  3. On approve, the task flips `completed → confirmed` and **both the credit AND the ship attribution (`shipped_by`) land with the original requester**, never the approving Archon ([#538](https://example.com/builders#/task/538)). The whole exchange is permanently audited in `task_override_requests` (requester, decider, rationale, decision note, timestamps).
- **Do NOT** use `POST /tasks/:id/confirm` to unstick *another* builder's task — it credits + attributes to the *caller* (the Archon), not the original builder. `/confirm` is for the shipping builder's own `--skip-grade` path. The override-request → approve flow is the correct tool when the work was someone else's.
- **Why it bites:** the grader defaults to fail (by design — it's adversarial), so a false-negative looks identical to a real rejection. The fix is a documented, audited human-in-the-loop appeal, not a grader bypass — and the appeal pays the right person.

---

## Status page + monitoring

### Cloudflare 522 with the whole site dark — the droplet itself is down (often billing)

- **Symptom:** `example.com` shows Cloudflare **522 (connection timed out)** and the status page is dark too. From your machine, `ping` + `ssh` (port 22) + `curl https://…` (443) **all time out** — not "connection refused" — yet `dig example.com` still returns Cloudflare IPs and status.digitalocean.com is green.
- **Root cause:** the droplet is powered off / hung / firewalled — **not** an app crash. A *timeout* (black-hole) on every port means packets are dropped, the signature of the box being down or network-blocked; *refused* would mean the box is up but the service isn't listening. On 2026-06-03 the cause was a **failed DigitalOcean payment** — DO powers off droplets when a charge fails.
- **Fix:** every lever is in the **DigitalOcean web panel** (SSH is dead and we keep no `doctl`/API token locally): check for a billing banner, check the droplet's power state, then Power → Turn on / Power Cycle. The recovery console bypasses SSH entirely. Confirm with `ssh … uptime` (a fresh boot) once it answers; systemd auto-starts caddy/node/postgres. Prevent recurrence with a **backup payment method + balance alerts** on DO.
- **Why it bites:** a billing power-off looks identical to a crash or a firewall block, and the status page can't tell you which — it's served by the same droplet (see next entry).

### Your status page must not share fate with the product (and cannot measure itself)

- **Symptom:** the site is down for hours, but The Watch still shows 100% / "standing".
- **Root cause:** `status.example.com` is served by the same Node process on the same droplet as the game, and the in-process poller (`src/bongos/uptime-poller.js`) probes `127.0.0.1`. When the droplet dies, the page dies with it and the poller writes **zero rows** — the gap renders as green. A monitor that lives inside the monitored thing cannot witness its own death.
- **Fix:** measure availability from **outside** (the external GitHub-Actions prober — `.github/workflows/status-probe.yml`, task [#565](https://example.com/builders#/task/565)) and host the status page **off-box** (follow-up [#566](https://example.com/builders#/task/566)). See [ADR 0029](../adr/<redacted>.md) + GDS learning `#35`.
- **Why it bites:** a status page that lies is worse than none — it actively reassures you while the product is on fire.

### The live status page is NOT served by the droplet — editing the status surface + deploying does nothing

> **Path note (BV1.R84):** the status surface moved from `public-status/` to `modules/status-ui/public/` (carved to the `status-ui` web-surface module). Everything below applies at the new path; `scripts/status-mirror-sync.js` was re-pointed. **Open follow-up:** `.github/workflows/sync-status-mirror.yml` still triggers on `public-status/**` and must be re-pointed at `modules/status-ui/public/**` by an owner/Archon (the GitHub App can't push `.github/workflows/*`, learning 107) — until then the auto-sync won't fire and you must run the script by hand.

- **Symptom:** you change `modules/status-ui/public/`, deploy to the droplet, the origin serves the new page (verified via `curl` on the box), but `status.example.com` keeps showing the old version. Purging Cloudflare doesn't help.
- **Root cause:** the off-box move (ADR 0029) repointed `status.example.com` DNS at **GitHub Pages from the separate repo `example-owner/example-status`** (served by Fastly — headers say `server: GitHub.com`, `via: varnish`, **no `cf-*` headers** → Cloudflare isn't even in the path). The droplet still serves `modules/status-ui/public/` as a same-origin fallback, but the public DNS goes to Pages. There was no sync, so droplet edits never reached the live page.
- **Fix:** publish to the mirror with `node scripts/status-mirror-sync.js --repo-dir <mirror-checkout> --push` — or (once the workflow trigger is re-pointed, see the path note above) let `.github/workflows/sync-status-mirror.yml` do it on push (needs the `STATUS_MIRROR_TOKEN` repo secret). `status.js`/`style.css`/`cursors/` are byte-identical copies (the one off-box difference, the API base, is injected via `window.STATUS_API_BASE` in the mirror's `index.html`); the sync injects the off-box banner + API-base script into `index.html` at fixed anchors and **throws if an anchor is missing** rather than mis-publishing. GitHub Pages purges its own Fastly cache on deploy, so the live page updates ~1 min after the Pages build goes green (`gh api repos/example-owner/example-status/pages/builds/latest`). ([#737](https://example.com/builders#/task/737))
- **Why it bites:** the origin looks correct at every layer you can `curl` from the box, so you chase a phantom cache on the wrong CDN. The tell is the response headers — `server: GitHub.com` + Fastly, not `cloudflare`.

---

## Dev box

### `bypassPermissions` "still not available" even though the box was provisioned for it (task 2022)

- **Symptom:** you reconnect to the browser terminal (or SSH) on a dev box and `claude` still stops for permission prompts, even though tasks [#1251](https://example.com/builders#/task/1251) and [#1314](https://example.com/builders#/task/1314) default every box to `bypassPermissions`.
- **Root cause:** `otb-box-launch.sh` (behind `box-terminal.service`) only ever runs `claude` once — the first time it creates the tmux `otb` session. Every later connect just reattaches to that **same running process**. The `defaultMode=bypassPermissions` setting is written into `~/.claude/settings.json` by `box-source-fetch.sh`'s cron, on its own `*/10` schedule (and, on an already-provisioned box, only after that box's baked copy of the script has self-updated to even contain the fix). If the `otb` tmux session got created before that write landed — an older box, or a fresh box whose very first connect raced the first cron tick — `claude` started once in normal `auto` mode and is stuck there for the life of the box; reconnecting never re-launches it, so the fix never takes effect even once the setting is correct on disk. (Flagged as an open follow-up in [ADR 0104](../adr/<redacted>.md).)
- **Fix:** `otb-box-launch.sh` now asserts `defaultMode=bypassPermissions` itself, synchronously, right before it creates a **new** `otb` tmux session — so a fresh session never depends on cron timing. This prevents the race going forward but does **not** repair a box whose `otb` session is already running in the wrong mode: for that, from an SSH/browser-terminal shell run `tmux kill-session -t otb` then reconnect (the launcher creates a fresh session and picks up the corrected setting immediately). Killing the session only drops the terminal pane — it does not touch `/workspace` or in-flight git state.
- **Why it bites:** every layer *looks* fixed — `~/.claude/settings.json` has the right value, `IS_SANDBOX=1` is set — because you're inspecting the box's filesystem, not the already-running process that never re-read it.

## When to add a new entry here

Anytime you spend more than ~10 minutes diagnosing something that turned out to have a non-obvious cause, add a section. Include symptom, root cause, fix, and why-it-bites. The cost of a 5-minute write-up is much less than the cost of the next session re-discovering the same thing.
