'use strict';

// Discord reaction → Archon approval (task 1100).
//
// An Archon's 👍/👎 on a request line in #member-approvals fires the SAME server
// action the amazonprimea hall fires:
//   #member-approvals  👍 → access_requests → 'invited'   (PATCH /access-requests/:id)
//                      👎 → access_requests → 'dismissed'
//
// TRUST BOUNDARY (ADR 0016 / 0033 §1) — the one invariant: every bot-triggered
// write re-checks the LINKED builder's LIVE rank. The bot asserts only WHO
// reacted (Discord user → linked builder via the F1 table, which reads rank
// FRESH from `builders`); the GDS decides WHAT they may do. Both these actions
// are Archon-only on the web (auth.requireRank('archon')), so here we re-derive
// the reactor's live rank and act ONLY when it is 'archon'. Anything else (an
// unlinked reactor, a Metic, a player) is a no-op. The bot cannot escalate; the
// worst a compromised bot could do is mis-report which Archon reacted, bounded
// by the audit_log (surface='discord_bot').
//
// WHY A FUNCTION, NOT AN HTTP ENDPOINT: the bot is in-process (ADR 0033 F3), so
// it calls this directly — no localhost self-HTTP, no minted bot session token.
//
// FAIL-CLOSED + NEVER THROWS: the caller is a gateway event handler that must
// not crash the bot; every path returns { outcome } and all failure is caught.

const { pool } = require('../../src/module-api');
const db = require('./db');
const { auditDiscordBot } = require('./discord-audit');
const auth = require('./auth');

// Only the top rank may approve admissions (identical to the
// web routes' auth.requireRank('archon')).
const APPROVING_RANK = 'archon';

// PURE — map a discord.js emoji name to an approval decision, or null for any
// other reaction (which the handler then ignores).
function emojiToDecision(emojiName) {
  if (emojiName === '👍') return 'approve';
  if (emojiName === '👎') return 'decline';
  return null;
}

// PURE — extract { kind, id } from an approval request line. The producer
// (approval-broadcast.js) LEADS each line with a `member-request #<id>` token; we
// anchor to the start so a body that mentions another "#7" can't hijack the
// mapping. kind is always 'member'. Returns null when the line carries no leading
// approval marker (e.g. a confirmation reply we post).
function parseApprovalMarker(content) {
  if (typeof content !== 'string') return null;
  const m = /^\s*(member-request)\s+#(\d{1,15})\b/.exec(content);
  if (!m) return null;
  const id = Number(m[2]);
  if (!Number.isInteger(id) || id <= 0) return null;
  return { kind: 'member', id };
}

// DB — resolve a pending access request to 'invited' | 'dismissed', stamping the
// approving Archon. GUARDED on status='pending' (idempotent: a second reaction,
// or one on an already-resolved request, matches nothing → null), exactly like
// the PATCH /access-requests/:id route. Returns the updated row or null.
async function resolveAccessRequest({ id, status, builderId }) {
  const { rows } = await pool.query(
    `UPDATE access_requests
        SET status = $1, resolved_by_builder_id = $2, resolved_at = now()
      WHERE id = $3 AND status = 'pending'
      RETURNING id, github_login, status`,
    [status, builderId, id]
  );
  return rows[0] || null;
}

// The real dependency set — injected so recordApprovalReaction is unit-testable
// against fakes with NO database.
const realDeps = {
  getBuilderByDiscordUserId: db.getBuilderByDiscordUserId,
  resolveAccessRequest,
  insertAuditLog: db.insertAuditLog,
};

// Orchestrate one approval reaction. NEVER throws. `kind` is fixed by WHICH
// channel the reaction landed in (the bot knows the channel id) and is always
// 'member'; `decision` ('approve'|'decline') comes from the emoji; `recordId`
// from the parsed marker. Returns { outcome, ... } where outcome ∈
//   'approved' | 'declined'        — action fired
//   'already_resolved'             — record was gone/resolved (idempotent no-op)
//   'ignored' (+reason)            — not an Archon / bad input
//   'error' (+error)
async function recordApprovalReaction({ discordUserId, kind, decision, recordId }, deps = realDeps) {
  if (!auth.isValidDiscordUserId(discordUserId)) {
    return { outcome: 'ignored', reason: 'bad_discord_user_id' };
  }
  if (kind !== 'member') {
    return { outcome: 'ignored', reason: 'bad_kind' };
  }
  if (decision !== 'approve' && decision !== 'decline') {
    return { outcome: 'ignored', reason: 'bad_decision' };
  }
  if (!Number.isInteger(recordId) || recordId <= 0) {
    return { outcome: 'ignored', reason: 'bad_record_id' };
  }

  try {
    // Re-derive the reactor's LIVE rank — the whole trust boundary (ADR 0016).
    const builder = await deps.getBuilderByDiscordUserId(discordUserId);
    if (!builder) return { outcome: 'ignored', reason: 'unlinked_reactor' };
    if (builder.rank !== APPROVING_RANK) return { outcome: 'ignored', reason: 'not_archon' };

    const status = decision === 'approve' ? 'invited' : 'dismissed';
    const resolved = await deps.resolveAccessRequest({ id: recordId, status, builderId: builder.id });

    // A guarded UPDATE matched nothing → the record was already resolved or gone.
    // Idempotent no-op (a duplicate/late reaction), not an error.
    if (!resolved) {
      return { outcome: 'already_resolved', kind, recordId, builderId: builder.id };
    }

    const outcome = decision === 'approve' ? 'approved' : 'declined';

    // Audit every bot-triggered write (ADR 0033 §1). Best-effort — an audit
    // failure must not undo the approval.
    await auditDiscordBot(deps, {
      builderId: builder.id,
      route: `discord:approval:${kind}`,
      requestBodyRedacted: { discord_user_id: discordUserId, kind, record_id: recordId, decision, outcome },
      responseStatus: 200,
      logLabel: 'approval audit-log write failed',
    });

    return { outcome, kind, recordId, builderId: builder.id, resolved };
  } catch (err) {
    console.error('[discord-bot] recordApprovalReaction failed:', err.message);
    return { outcome: 'error', error: err.message };
  }
}

module.exports = {
  // pure (unit-tested)
  emojiToDecision,
  parseApprovalMarker,
  APPROVING_RANK,
  // orchestration + DB
  recordApprovalReaction,
  resolveAccessRequest,
  realDeps,
};
