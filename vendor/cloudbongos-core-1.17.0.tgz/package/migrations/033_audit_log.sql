-- 033_audit_log.sql — append-only audit stream for privileged writes (V3.R35 / #256).
--
-- Today most state changes are recoverable from individual tables (credit_log,
-- task updates, claims, etc.) but there is no single "who did what when"
-- stream. With multiple builders authenticating against the same server we
-- need an append-only ledger so:
--   - the R67 Archon security view can show "all writes by builder X" in one
--     query without scanning a dozen feature tables;
--   - post-incident forensics has a single chronological record;
--   - a future periodic auditor (R45) can replay write history.
--
-- Captured: every AUTHENTICATED WRITE (POST/PATCH/PUT/DELETE) request the
-- /api/gds router serves. Reads (GETs) are NOT logged — volume + signal/noise.
--
-- Redaction: the writing middleware (src/bongos/middleware/audit.js) walks the
-- parsed body and replaces any value whose KEY name contains 'token',
-- 'password', 'key', or 'secret' (case-insensitive) with the literal string
-- '<redacted>'. Recurses into nested objects + arrays. The redacted body is
-- what lands here.
--
-- Retention: indefinite for V3. A retention sweep is explicitly a V4 concern.
-- (We don't index for deletion; the v3 plan is "we'll deal with it when the
-- table actually gets big.")
--
-- Idempotent: CREATE TABLE IF NOT EXISTS + ON CONFLICT DO NOTHING migration row.

CREATE TABLE IF NOT EXISTS audit_log (
  id                       bigserial PRIMARY KEY,
  -- Who made the request. NULL would mean "unauthenticated", but the middleware
  -- only fires for authenticated writes, so this column is NOT NULL in practice.
  -- We still FK to builders so a stray entry can never reference a ghost.
  builder_id               bigint NOT NULL REFERENCES builders(id),
  -- The matched route path (e.g. '/tasks/:id', not '/tasks/256') so we can
  -- group by endpoint. Falls back to req.path if the matched route isn't
  -- available (some sub-router edge cases).
  route                    text NOT NULL,
  method                   text NOT NULL CHECK (method IN ('POST','PATCH','PUT','DELETE')),
  -- Parsed JSON request body, with sensitive keys redacted. Stored as jsonb so
  -- we can later run ad-hoc queries against specific fields. Defaults to '{}'.
  request_body_redacted    jsonb NOT NULL DEFAULT '{}'::jsonb,
  -- The HTTP status the response went out with. We log AFTER 'finish' so this
  -- is the real status the client saw.
  response_status          integer NOT NULL,
  -- Client IP. Honors the express 'trust proxy' setting (set in server.js) so
  -- we record the real client through the Cloudflare → Caddy → Node chain.
  ip                       text,
  -- User-Agent header, free text.
  user_agent               text,
  recorded_at              timestamptz NOT NULL DEFAULT now()
);

-- Forensics queries are almost always "what did builder X do" or "everything
-- in the last N hours sorted newest-first". Index both.
CREATE INDEX IF NOT EXISTS idx_audit_log_builder ON audit_log (builder_id, recorded_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_log_recorded_at ON audit_log (recorded_at DESC);
-- "Who's hitting this route" is the third common shape.
CREATE INDEX IF NOT EXISTS idx_audit_log_route ON audit_log (route, recorded_at DESC);

-- Bump the migration counter past 033 so the next claim that includes
-- 'migrations/' allocates 034.
UPDATE migration_counter SET next_number = GREATEST(next_number, 34) WHERE id = 1;

INSERT INTO schema_migrations (version) VALUES ('033_audit_log')
  ON CONFLICT (version) DO NOTHING;
