// GDS task hierarchy — shallow (one-level) parent/child tree.
//
// V2 introduces tasks.parent_task_id so a piece of work can decompose into
// a parent task plus N child tasks (e.g., "F1: schema migration" with
// children "table-x", "view-y", "seed-z"). The depth is intentionally
// capped at one level — a parent cannot itself have a parent, and a task
// that already has children cannot become a child. This module enforces
// those invariants in app code; the DB enforces atomic ship-rollup via
// the trigger added in migration 007_pms_v2_hierarchy_trigger.sql.
//
// See limitations/pms-v2.md (Activity 1 C2).

const { pool } = require('../../src/module-api');

// -------------------------------------------------------------------------
// attachParent(taskId, parentTaskId)
//
// Sets tasks.parent_task_id = parentTaskId on the target task, after
// validating:
//   - both tasks exist
//   - target !== parent (no self-reference)
//   - target.version_id === parent.version_id (no cross-version trees)
//   - parent.parent_task_id IS NULL                      (depth cap, side 1)
//   - target has no children of its own                  (depth cap, side 2)
//
// Pass parentTaskId=null to detach (always allowed if the task exists).
// Throws { code: 'TASK_NOT_FOUND' | 'PARENT_NOT_FOUND' | 'SELF_PARENT'
//        | 'VERSION_MISMATCH' | 'PARENT_HAS_PARENT' | 'TARGET_HAS_CHILDREN' }.
// -------------------------------------------------------------------------
async function attachParent(taskId, parentTaskId) {
  const targetId = Number(taskId);
  if (!Number.isInteger(targetId) || targetId <= 0) {
    throw { code: 'TASK_NOT_FOUND' };
  }

  // Detach path — no parent validation needed.
  if (parentTaskId === null || parentTaskId === undefined) {
    const { rowCount, rows } = await pool.query(
      `UPDATE tasks SET parent_task_id = NULL WHERE id = $1 RETURNING *`,
      [targetId]
    );
    if (rowCount === 0) throw { code: 'TASK_NOT_FOUND' };
    return rows[0];
  }

  const parentId = Number(parentTaskId);
  if (!Number.isInteger(parentId) || parentId <= 0) {
    throw { code: 'PARENT_NOT_FOUND' };
  }
  if (parentId === targetId) {
    throw { code: 'SELF_PARENT' };
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const { rows: targetRows } = await client.query(
      `SELECT id, version_id, parent_task_id FROM tasks WHERE id = $1 FOR UPDATE`,
      [targetId]
    );
    if (targetRows.length === 0) throw { code: 'TASK_NOT_FOUND' };
    const target = targetRows[0];

    const { rows: parentRows } = await client.query(
      `SELECT id, version_id, parent_task_id FROM tasks WHERE id = $1 FOR UPDATE`,
      [parentId]
    );
    if (parentRows.length === 0) throw { code: 'PARENT_NOT_FOUND' };
    const parent = parentRows[0];

    if (parent.version_id !== target.version_id) {
      throw { code: 'VERSION_MISMATCH', target_version: target.version_id, parent_version: parent.version_id };
    }
    if (parent.parent_task_id !== null) {
      throw { code: 'PARENT_HAS_PARENT', parent_id: parentId, grandparent_id: Number(parent.parent_task_id) };
    }

    const { rows: childRows } = await client.query(
      `SELECT id FROM tasks WHERE parent_task_id = $1 LIMIT 1`,
      [targetId]
    );
    if (childRows.length > 0) {
      throw { code: 'TARGET_HAS_CHILDREN', target_id: targetId };
    }

    const { rows: updated } = await client.query(
      `UPDATE tasks SET parent_task_id = $2 WHERE id = $1 RETURNING *`,
      [targetId, parentId]
    );

    await client.query('COMMIT');
    return updated[0];
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

module.exports = {
  attachParent,
};
