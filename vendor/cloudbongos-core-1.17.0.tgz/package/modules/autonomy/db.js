'use strict';

// modules/autonomy/db.js — the autonomy_runs db slice (BV1.R83 / ADR 0093 §1).
//
// The Multi-Agent System's autonomy gate (System 3, task 1351) records every
// precheck decision to the `autonomy_runs` table — both as an audit trail and as
// the source of the "stored last_head" the no-signal check compares origin/main
// against. These two queries were carved out of the ~5k-LOC src/bongos/db.js
// monolith alongside the rest of the autonomy/MAS domain (the gate CLI, the
// conductor/architect CLIs, the routine timer + precheck route).
//
// THE BOUNDARY (the one rule): this slice reaches the kernel ONLY through the
// published doorway `../../src/module-api.js` — the shared `pool`. It must never
// `require()` a core internal directly, and never another module.
//
// The autonomy_runs TABLE (migration 126) was created before the module system
// and stays in core migrations/ (the shared-schema additive rule the sessions /
// onboarding carves established — a NEW autonomy migration belongs in
// modules/autonomy/migrations/ namespaced autonomy_*). The module owns the
// QUERIES; the schema stays put.

const { pool } = require('../../src/module-api');

// Record one autonomy-precheck decision (audit + the "stored last_head" source).
async function recordAutonomyRun({ routine, decision, reason = null, headSha = null, claimableCount = null, enabled = false }) {
  const { rows } = await pool.query(
    `INSERT INTO autonomy_runs (routine, decision, reason, head_sha, claimable_count, enabled)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING id, created_at`,
    [routine, decision, reason, headSha, claimableCount, enabled === true]
  );
  return rows[0] || null;
}

// The head_sha of this routine's most recent `go` — the baseline the next
// precheck compares origin/main against ("did anything land since we last ran?").
async function lastAutonomyHead(routine) {
  const { rows } = await pool.query(
    `SELECT head_sha FROM autonomy_runs
      WHERE routine = $1 AND decision = 'go' AND head_sha IS NOT NULL
      ORDER BY created_at DESC LIMIT 1`,
    [routine]
  );
  return rows[0]?.head_sha || null;
}

module.exports = {
  recordAutonomyRun,
  lastAutonomyHead,
};
