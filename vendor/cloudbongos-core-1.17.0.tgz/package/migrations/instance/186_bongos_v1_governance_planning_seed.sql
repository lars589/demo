-- 186_bongos_v1_governance_planning_seed.sql  (migrations/instance/ — OTB scope-truth)
-- Planning session (2026-07-03): the BONGOS-V1 "Governance — configurable roles &
-- permissions" goal + its six done-when criteria.
--
-- WHY THIS LIVES IN migrations/instance/ (ADR 0105 / selfhost-boot gate):
-- versions/goals/done_when_criteria are OTB scope-truth, NOT platform-universal
-- schema. In migrations/ root they would seed a vanilla third-party self-host with
-- OTB's governance criteria (the selfhost-boot VANILLA assertion: a fresh DB seeds
-- ZERO scope-truth). Here, migrate.sh applies the file only when the OWNING instance
-- opts in (GDS_APPLY_INSTANCE_SEEDS=1); a vanilla self-host skips the whole dir.
--
-- DR-SAFE: the goal was first created via the API (a runtime row), so a from-scratch
-- owning-instance replay would have no goal to parent the criteria under. This
-- migration recreates the goal idempotently (title-guard) so replay stays whole and
-- so it is a no-op on prod (where goal 30 already exists). Mirrors migration 183.
--
-- The 25 tasks (BV1.R90-R114) + dependency graph are seeded by
-- scripts/gds/seed-governance-tasks.js after this deploys (so the slugs resolve).

BEGIN;

DO $do$
DECLARE gid bigint;
BEGIN
  SELECT id INTO gid FROM goals
    WHERE version_id = 'BONGOS-V1'
      AND title = 'Governance — configurable roles & permissions'
    LIMIT 1;

  IF gid IS NULL THEN
    INSERT INTO goals (version_id, title, description, scope_modules, created_by, status)
    VALUES (
      'BONGOS-V1',
      'Governance — configurable roles & permissions',
      $desc$A core, Discord-style roles-and-permissions system where PERMISSIONS are the atomic primitive and ranks become seeded roles. Adds first-class principals (machine identities), session-scopes (box tokens), ownership-scoped permissions, and a governance-owned protected-surface registry (policy owns / substrate enforces). Capability lives in core (modules/governance/, default:true); per-project settings split config/governance.json (over neutral) + governance_* DB tables. Ships an Archon-only Governance hall tab (assign + toggle; system permissions locked). Preserves the ADR 0016 trust boundary end-to-end. Protected-scope (kernel/lifecycle) -> Archon-mediated.$desc$,
      '{kernel,lifecycle,hall-ui}',
      1,
      'open'
    )
    RETURNING id INTO gid;
  END IF;

  INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, goal_id, sort_order) VALUES
  ('BONGOS-V1', 'gov-perms-atom',
   $md$**Permissions become the atom; ranks become seeded roles — with zero day-one behavior change.** Authority stops being a fixed rank threshold and becomes a resolved set of granular permissions. Done when: a code-defined permission catalog exists (each permission flagged `system` or not, since permissions map to real routes and cannot be UI-invented); a per-request, uncached resolver returns a builder's effective permission set as the union of their roles (preserving ADR 0016); four seeded roles (`xenos`/`thetes`/`metic`/`archon`) reproduce today's thresholds exactly; a `requirePermission()` gate exists alongside `requireRank`; and a parity test proves every builder resolves to exactly today's powers (behavior-identical at ship).$md$,
   gid, 20),
  ('BONGOS-V1', 'gov-gates-permissioned',
   $md$**Every DB-resolvable authority gate reads permissions, not rank.** Rank stops being special everywhere the server decides access. Done when: the ~60 HTTP route gates migrate `requireRank(...)` -> `requirePermission(...)`; claim eligibility (`xenosClaimAllowed`/`rankAllowsTask`/per-task floor), the page-level gates, and the wandering-prefs clamp are re-expressed as permissions; the ~6 duplicated numeric rank-tier maps collapse into the single resolver; and the `route-rank-check` fitness function is updated to assert permission gates so nothing silently regresses.$md$,
   gid, 21),
  ('BONGOS-V1', 'gov-full-model',
   $md$**The complete authority model is represented — not just role -> permission.** The 2026-07-03 authority sweep proved Cloud Bongos authority runs on ~7 mechanisms, not one. Done when: first-class **principals** (machine identities like the BFG memory-writer and the Discord bot, keyed on `system_role`, never UI-grantable) are modeled; **session-scopes** (box-scoped tokens, deny-by-default) are a first-class capability distinct from a builder's roles; **ownership-scoped** permissions ("act on *own* X" — own box/memory/credentials/claim) are expressible; and the **protected-surface registry** (today's `PROTECTED_GLOBS` / `EXPECTED_RANKS`) becomes governance-owned *data* while the out-of-band substrate (git hooks, CI, GitHub branch protection, SSH) stays the *enforcer* — policy owns, substrate enforces.$md$,
   gid, 22),
  ('BONGOS-V1', 'gov-core-project-split',
   $md$**Capability lives in core; settings live per project.** The governance engine is portable to any Cloud Bongos instance; each project keeps its own governance data. Done when: `modules/governance/` is a `default:true` core module with its own `governance_*` additive migrations and a resolver exposed through a kernel port; role *templates/defaults* ship as `config/governance.json` resolved over a `config/governance.neutral.json` (the branding pattern); live role/permission/assignment *data* lives in the DB; and a fresh vanilla instance boots with sane neutral defaults and no OTB identity.$md$,
   gid, 23),
  ('BONGOS-V1', 'gov-archon-tab',
   $md$**The Archon Governance tab — assign + toggle.** The owner can configure governance from the builders' hall, Discord-style. Done when: an Archon-only Governance tab lets you view/edit the ~12 operational permissions per role, create custom roles, and assign roles to builders; `system` permissions render **locked** (visible but not grantable); and the tab is gated in depth at the page layer (`serve-internal`), the API layer (`governance.manage`), and pinned in `route-rank-check`.$md$,
   gid, 24),
  ('BONGOS-V1', 'gov-boundary-proof',
   $md$**The trust boundary provably holds — with a live proof and the docs corrected.** This criterion de-risks the whole goal: no amount of governance configuration can weaken production safety. Done when: an abuse-matrix test proves no configurable role/permission can grant a low-trust builder deploy or protected-path access; a live demonstration creates a custom role granting an operational permission (it works) while a `system` permission stays enforced by substrate; an ADR records the "permissions-as-atom + principals + session-scopes + protected-surface registry, policy-owns/substrate-enforces" decision; and the stale ADR 0043 / canonical-permissions.md branch-protection claims are fixed (GitHub branch protection is now live).$md$,
   gid, 25)
  ON CONFLICT (version_id, criterion_id) DO UPDATE
    SET criterion_md = EXCLUDED.criterion_md,
        goal_id      = EXCLUDED.goal_id,
        sort_order   = EXCLUDED.sort_order;
END
$do$;

COMMIT;
