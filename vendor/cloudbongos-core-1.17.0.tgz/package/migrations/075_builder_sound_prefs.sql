-- 075_builder_sound_prefs.sql — per-builder per-sound on/off preferences
-- (V3.R91 / #786). Follow-up to the #781 sound system.
--
-- One jsonb column on `builders` (sound_prefs), default '{}'. Each entry maps a
-- sound name (chime | alert | ship | triumph | fanfare) to a boolean: false =
-- the builder has muted that sound. A MISSING key falls back to the system
-- default (ON), so the column stays sparse — a builder who never opens the
-- setting has '{}' and hears everything, exactly as before this shipped.
--
-- This deliberately mirrors migration 037 (skill_model_prefs): per-builder
-- personalized config, sparse + irregular, read by primary key, with the
-- allowlist + defaults living in code (src/bongos/sound-prefs.js) rather than a
-- Postgres CHECK — so adding a sixth sound is a one-line code change, not a
-- coordinated schema migration.
--
-- The toggle is stored server-side but the sound plays from a LOCAL hook
-- (.claude/sounds/play.js); a SessionStart step (scripts/gds/fetch-sound-prefs.js)
-- mirrors this column into ~/.config/otb/sound-prefs.json so the offline hook
-- can honor it without a per-turn network call. play.js fails OPEN (plays) when
-- the local file is absent, so a fresh machine still gets sounds.
--
-- Idempotent: safe to re-run.

ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS sound_prefs jsonb NOT NULL DEFAULT '{}'::jsonb;

INSERT INTO schema_migrations (version) VALUES ('075_builder_sound_prefs')
  ON CONFLICT (version) DO NOTHING;
