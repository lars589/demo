-- #569 — Builders-hall live updates: Postgres NOTIFY triggers.
--
-- The builders hall (public-builders/) fetched every panel ONCE at page load
-- and then froze until a manual refresh — so an onboarding step that ticks
-- server-side (e.g. after /builder-ship) never showed until the page reloaded.
-- See docs/adr/0030-builders-hall-live-updates.md for the full design.
--
-- This migration is the "something changed" signal source. A single
-- statement-level AFTER trigger on each table that backs a live panel emits a
-- pg_notify on the 'gds_live' channel carrying a minimal {table, op} payload.
-- The GDS process holds one persistent LISTEN connection (src/bongos/live-channel.js)
-- and relays each notification to the Colyseus BuildersHallRoom
-- (src/rooms/BuildersHallRoom.js), which broadcasts a nudge over the existing
-- game WebSocket so the hall re-pulls the affected panels.
--
-- Why statement-level (FOR EACH STATEMENT), not row-level:
--   * The payload carries NO row data — only the table name + op — so we don't
--     need OLD/NEW. A bulk UPDATE therefore needs exactly one nudge, not one
--     per row. Statement-level coalesces it for free and keeps write overhead
--     on these tables negligible.
--   * The browser de-bounces nudges and re-fetches whole panels regardless, so
--     per-row granularity would buy nothing.
--
-- Why pg_notify (not row data over the wire): it catches EVERY write path —
-- API routes, background routines, AND direct psql writes (the methodology's
-- "direct DB writes are work too" reality) — because the trigger lives in the
-- database, below the application. That direct-write coverage is the whole
-- point: the original staleness often came from changes the app never saw.

-- Generic notifier. Used by every trigger below. TG_OP / TG_TABLE_NAME are
-- available in statement-level triggers; OLD/NEW are not, and we don't use them.
CREATE OR REPLACE FUNCTION gds_notify_live() RETURNS trigger AS $$
BEGIN
  PERFORM pg_notify(
    'gds_live',
    json_build_object('table', TG_TABLE_NAME, 'op', TG_OP)::text
  );
  RETURN NULL;  -- AFTER STATEMENT triggers ignore the return value
END;
$$ LANGUAGE plpgsql;

-- One trigger per table backing a live hall panel:
--   tasks                    — claimable list, recent ships, the "ship" step
--   claims                   — claimable list churn, the "claim" step
--   builders                 — standing (credits/karma cached counters), rank, disciplines
--   builder_onboarding_state — the onboarding checklist itself (the reported bug)
--   credit_log / karma_log   — drachmae + karma feeds (and the leaderboard)
--
-- DROP-then-CREATE keeps the migration idempotent (CREATE TRIGGER has no
-- IF NOT EXISTS form before PG 17; the droplet runs PG 16).
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'tasks', 'claims', 'builders',
    'builder_onboarding_state', 'credit_log', 'karma_log'
  ] LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_%s_notify_live ON %I', t, t);
    EXECUTE format(
      'CREATE TRIGGER trg_%s_notify_live
         AFTER INSERT OR UPDATE OR DELETE ON %I
         FOR EACH STATEMENT EXECUTE FUNCTION gds_notify_live()',
      t, t
    );
  END LOOP;
END $$;

INSERT INTO schema_migrations (version) VALUES ('066_live_notify_triggers')
  ON CONFLICT DO NOTHING;
