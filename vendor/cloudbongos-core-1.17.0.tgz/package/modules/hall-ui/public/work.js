// public-builders/work.js — the Work Board (/builders/work, served at
// builders.amazonprimea.com/work).
//
// Signed-in builders only. The page is the builder-facing SOURCE OF TRUTH for
// "works in progress"; it gathers two views the hall + status dashboard used to
// scatter:
//
//   1. WORKS IN PROGRESS — the live in-flight list, every open claim across all
//      builders (active_claims from GET /api/bongos/tasks/claimable). Version-level
//      progress + goals moved to the Roadmap page (task 1757).
//   2. WORKS WAITING TO BE CLAIMED — the claimable queue, filterable, with the
//      copy-prompt action (same shape as the hall's Claim section).
//
// Read-only across the wire EXCEPT the per-task copy-prompt button, which is
// purely client-side (writes to the clipboard, no server call).
//
// Auth: the page itself is gated server-side (server.js requireBuilderPage), so
// an unauthenticated visitor never reaches this script — but on a 401 from any
// fetch (expired session) we still bounce into the web sign-in flow. The
// claimable feed is additionally primer-gated server-side; a signed-in builder
// who hasn't acknowledged the primer gets a friendly gate notice instead of the
// queue.

(() => {
  'use strict';

  const API = '/api/bongos';
  // Generated typed client (task 1996 / R09), served as window.BongosClient by
  // /lib/bongos-client.js. baseUrl:'' passes the full same-origin paths this file
  // builds through unchanged; result-mode ({ status, ok, data }) preserves control flow 1:1.
  const api = window.BongosClient.createClient({ baseUrl: '', credentials: 'same-origin', throwOnError: false });
  const AUTH_NEEDED = 'auth-needed';

  // escapeHtml / $ / fmtNum / fmtDate / toast now come from the shared
  // window.OTB toolkit (dom-utils.js, loaded first). Thin wrappers keep this
  // file's exact variants (date-only fmtDate; a 2200ms clearing toast).
  // fmtAgo / toAuth / getJSON / postJSON stay local below.
  const { escapeHtml, $, fmtNum } = window.OTB;
  const fmtDate = (iso) => window.OTB.fmtDate(iso);
  const toast = (msg) => window.OTB.toast(msg, { duration: 2200, clear: true });
  const curLabel = (caps) => { const l = (window.__BRANDING__ && window.__BRANDING__.currency && window.__BRANDING__.currency.label) || 'credits'; return caps ? l.charAt(0).toUpperCase() + l.slice(1) : l; };

  // Coarse relative time ("just now", "3h", "2d") for how long a claim's been
  // borne. Kept compact so the in-flight table stays narrow.
  function fmtAgo(iso) {
    if (!iso) return '—';
    const then = new Date(iso).getTime();
    if (Number.isNaN(then)) return '—';
    const secs = Math.max(0, Math.floor((Date.now() - then) / 1000));
    if (secs < 60) return 'just now';
    const mins = Math.floor(secs / 60);
    if (mins < 60) return `${mins}m`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h`;
    const days = Math.floor(hrs / 24);
    return `${days}d`;
  }

  function toAuth() {
    window.location.assign(`${API}/auth/web/start`);
  }

  // getJSON with the hall's auth posture: softAuth surfaces a typed error so the
  // caller can decide (here, /me uses it to render nothing fatal); everything
  // else redirects into sign-in on a 401. A 403 is surfaced (not redirected) so
  // the primer gate can be handled gracefully.
  async function getJSON(path, opts = {}) {
    const res = await api.request('GET', path);
    if (res.status === 401) {
      if (opts.softAuth) {
        const err = new Error(AUTH_NEEDED);
        err.code = AUTH_NEEDED;
        throw err;
      }
      toAuth();
      throw new Error('redirecting to auth');
    }
    if (!res.ok) {
      const err = new Error(`${path} → ${res.status}`);
      err.status = res.status;
      throw err;
    }
    return res.data;
  }

  // Mutating call (claim / release). Cookie-authed, same posture as the settings
  // page. Resolves to the parsed body on 2xx; on a non-2xx it throws an Error
  // carrying { status, data } so callers can map the server's typed error code
  // (ALREADY_CLAIMED, TOUCHES_CONFLICT, …) to a friendly message. A 401 still
  // bounces to sign-in — a mutation with a dead session is unrecoverable here.
  async function postJSON(path, body) {
    const res = await api.request('POST', path, { body: body || {} });
    if (res.status === 401) { toAuth(); throw new Error('redirecting to auth'); }
    let data = null;
    try { data = res.data; } catch (_) { /* empty/non-JSON body */ }
    if (!res.ok) {
      const err = new Error(`${path} → ${res.status}`);
      err.status = res.status;
      err.data = data || {};
      throw err;
    }
    return data;
  }

  // ---- paginated lists: per-page dropdown + Prev/Next (task 1931/1955) -------
  // All four Work-page lists (In Progress, Ready, Completed, Backlog) paginate
  // the same way, through one shared helper. Each list owns a `pager` (page +
  // per-page, persisted to its own localStorage key) and a DOM id `prefix`;
  // renderPagerBar paints `#<prefix>-{pager,range,page,prev,next,per-page}`.
  // Page/per-page live in module scope so a background poll / action refresh
  // re-renders on the SAME page — only an explicit filter/per-page change resets.
  const PER_PAGE_OPTIONS = [10, 25, 50, 100];
  const MIN_PER_PAGE = PER_PAGE_OPTIONS[0]; // ≤ this fits one page — hide the bar
  const DEFAULT_PER_PAGE = 25;
  function loadPerPage(key, fallback) {
    try {
      const v = Number(window.localStorage.getItem(key));
      return PER_PAGE_OPTIONS.includes(v) ? v : fallback;
    } catch (_) { return fallback; }
  }
  function makePager(prefix, key) {
    return { prefix, key, page: 1, perPage: loadPerPage(key, DEFAULT_PER_PAGE) };
  }
  const pagers = {
    wip: makePager('wip', 'otb.work.wipPerPage'),
    ready: makePager('ready', 'otb.work.readyPerPage'),
    done: makePager('done', 'otb.work.donePerPage'),
    backlog: makePager('backlog', 'otb.work.backlogPerPage'),
  };

  // A section-header count pill: reveal it and set its number once data lands.
  function setCountPill(sel, n) {
    const el = $(sel);
    if (!el) return;
    el.hidden = false;
    el.textContent = String(n);
  }

  // Slice `list` to the pager's current page (clamped — the filtered list may
  // have shrunk under a poll), paint the bar, and return the slice to render.
  // The bar hides when the whole list fits one minimum page.
  function paginate(list, p) {
    const total = list.length;
    const totalPages = Math.max(1, Math.ceil(total / p.perPage));
    if (p.page > totalPages) p.page = totalPages;
    if (p.page < 1) p.page = 1;
    const start = (p.page - 1) * p.perPage;
    const slice = list.slice(start, start + p.perPage);
    renderPagerBar(p, total, totalPages, start, slice.length);
    return slice;
  }

  function renderPagerBar(p, total, totalPages, start, shownCount) {
    const pager = $(`#${p.prefix}-pager`);
    if (!pager) return;
    if (total <= MIN_PER_PAGE) { pager.hidden = true; return; }
    pager.hidden = false;
    const range = $(`#${p.prefix}-range`);
    if (range) range.textContent = total
      ? `Showing ${start + 1}–${start + shownCount} of ${total}`
      : 'Showing 0 of 0';
    const ind = $(`#${p.prefix}-page`);
    if (ind) ind.textContent = `Page ${p.page} of ${totalPages}`;
    const prev = $(`#${p.prefix}-prev`);
    if (prev) prev.disabled = p.page <= 1;
    const next = $(`#${p.prefix}-next`);
    if (next) next.disabled = p.page >= totalPages;
    const sel = $(`#${p.prefix}-per-page`);
    if (sel && sel.value !== String(p.perPage)) sel.value = String(p.perPage);
  }

  // Wire a pager's controls once (per-page dropdown + Prev/Next). `rerender`
  // re-renders that list; a per-page change resets to page 1 and persists.
  function wirePager(p, rerender) {
    $(`#${p.prefix}-per-page`)?.addEventListener('change', (e) => {
      const v = Number(e.target.value);
      if (!PER_PAGE_OPTIONS.includes(v)) return;
      p.perPage = v; p.page = 1;
      try { window.localStorage.setItem(p.key, String(v)); } catch (_) { /* private mode → in-memory only */ }
      rerender();
    });
    $(`#${p.prefix}-prev`)?.addEventListener('click', () => { if (p.page > 1) { p.page -= 1; rerender(); } });
    $(`#${p.prefix}-next`)?.addEventListener('click', () => { p.page += 1; rerender(); });
  }

  // ---- 1a. live in-flight list (active claims) -----------------------------

  function renderInFlight(active) {
    if (Array.isArray(active)) liveState.active = active;
    const tbody = $('#wip-table tbody');
    if (!tbody) return;
    // task 1899: sort the viewer's own claims first (mine-first), preserving
    // server order within each group (JS sort is stable). The count pill always
    // reflects the TOTAL active-claim count, even on the empty path below.
    const all = liveState.active;
    const isMine = (c) => viewer.id != null && Number(c.builder_id) === Number(viewer.id);
    const rows = all.slice().sort((a, b) => (isMine(b) ? 1 : 0) - (isMine(a) ? 1 : 0));
    setCountPill('#wip-count', all.length);
    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="6" class="ledger__empty">No tasks are in progress right now.</td></tr>`;
      pagers.wip.page = 1;
      const wp = $('#wip-pager');
      if (wp) wp.hidden = true;
      return;
    }
    const shown = paginate(rows, pagers.wip);
    tbody.innerHTML = shown.map((c) => {
      const who = escapeHtml(c.display_name || c.github_login || 'a builder');
      const handle = c.github_login && c.display_name && c.display_name !== c.github_login
        ? ` <small>@${escapeHtml(c.github_login)}</small>`
        : '';
      const ver = c.version_id ? `<span class="task__tag">${escapeHtml(c.version_id)}</span>` : '';
      const mine = viewer.id != null && Number(c.builder_id) === Number(viewer.id);
      const ageTitle = c.claimed_at ? ` title="claimed ${escapeHtml(fmtDate(c.claimed_at))}"` : '';
      // task 1759: bulk-release checkbox — offered ONLY on the viewer's own rows,
      // same scoping rule as the single Release button below.
      const claimIdStr = escapeHtml(String(c.claim_id));
      const selectCb = mine
        ? `<input type="checkbox" class="wip__select" data-claim-id="${claimIdStr}" data-task-id="${escapeHtml(String(c.task_id))}" aria-label="Select task ${escapeHtml(String(c.task_id))} for bulk release"${selection.release.has(claimIdStr) ? ' checked' : ''}>`
        : '';
      // Release is offered ONLY on the viewer's own claims (the server scopes it
      // too via NOT_YOUR_CLAIM, but we don't dangle a button others can't use).
      const action = mine
        ? `<button class="wip__release" type="button" data-claim-id="${claimIdStr}" data-task-id="${escapeHtml(String(c.task_id))}">Release</button>`
        : '<span class="wip__mine-none" aria-hidden="true">—</span>';
      return `
        <tr${mine ? ' class="wip__row--mine"' : ''}>
          <td class="wip__select-cell">${selectCb}</td>
          <td>#${escapeHtml(String(c.task_id))}</td>
          <td>${escapeHtml(c.title || '(untitled)')} ${ver}${mine ? ' <span class="task__tag task__tag--mine">yours</span>' : ''}</td>
          <td class="wip-builder">${who}${handle}</td>
          <td${ageTitle}>${escapeHtml(fmtAgo(c.claimed_at))}</td>
          <td class="wip__action">${action}</td>
        </tr>
      `;
    }).join('');
  }

  // ---- 2. claimable queue (filter + sort + copy prompt) --------------------

  const taskState = { all: [], versions: [], backlog: [] };
  // Live view context. viewerId lets renderInFlight decide which active claims
  // are the viewer's own (→ a Release action). active holds the last in-flight
  // payload so a poll can re-render claim ages without another round-trip.
  const viewer = { id: null };
  const liveState = { active: [] };
  // Guards against double-firing an action while its request is in flight.
  const pending = new Set();

  // task 1759: multi-select + the bottom bulk toolbar. `claim` holds
  // String(task_id) from the claimable queue; `release` maps
  // String(claim_id) -> task_id for the viewer's OWN in-flight claims (release
  // is only ever offered on those rows to begin with — see renderInFlight).
  const selection = { claim: new Set(), release: new Map() };
  // Last server dry-run (POST /claims/batch/validate) result, keyed by the
  // sorted selected-id set so an unrelated re-render doesn't refire it.
  const validateCache = { key: '', parallelSafe: null, byId: new Map() };
  let validateDebounce = null;
  // Per-task dependency edges for the "can these be sequenced?" cycle check —
  // fetched lazily via GET /tasks/:id (task-detail.js's call) since the
  // claimable feed doesn't carry dependencies[] per row. Stable for a ready
  // task within one page session, so caching by id is safe.
  const depsCache = new Map(); // task_id -> [dependency task_id, ...]
  const sequentialCache = { key: '', order: null };
  let sequentialDebounce = null;

  function creditsPerMinute(t) {
    const c = Number(t.credits_reward);
    const m = Number(t.est_minutes);
    if (!c || !m || m <= 0) return -Infinity;
    return c / m;
  }

  function priorityRank(p) {
    if (!p) return 99;
    const m = /^P(\d+)/i.exec(String(p));
    return m ? Number(m[1]) : 99;
  }

  // task 1756: two tasks can't run in parallel if their touches[] overlap — exact
  // path match or a directory-prefix either way (mirrors the server's touchesOverlap
  // / the goals-page conflict estimate). Empty touches never conflict.
  function touchesConflict(aList, bList) {
    const norm = (p) => String(p).replace(/\/+$/, '');
    for (const a of (Array.isArray(aList) ? aList : [])) {
      const na = norm(a);
      for (const b of (Array.isArray(bList) ? bList : [])) {
        const nb = norm(b);
        if (na === nb || na.startsWith(nb + '/') || nb.startsWith(na + '/')) return true;
      }
    }
    return false;
  }

  // task 1752 (+ 1498 / ADR 0084): the minimum rank to claim a task, as a tag shown
  // on EVERY task row. 'xenos' is the open default → a muted "Any rank" tag (open to
  // all, not a warning); 'archon' shows bare; other ranks show 'Rank+'. Kept here for
  // now; the shared task-detail view (task 1753) will lift this into the common
  // toolkit so every task surface renders rank identically.
  function rankTagHtml(requiresRank) {
    const rr = (requiresRank || 'xenos').toLowerCase();
    if (rr === 'xenos') {
      return '<span class="task__tag task__tag--rank-open" title="No rank floor — any builder can claim this task">Any rank</span>';
    }
    const label = rr === 'archon' ? 'Archon' : rr.charAt(0).toUpperCase() + rr.slice(1) + '+';
    return `<span class="task__tag task__tag--rank" title="Minimum rank required to claim this task">${escapeHtml(label)}</span>`;
  }

  // task 1829: free-text search over the claimable/backlog lists. Matches the
  // query (case-insensitive substring) against the task id (with or without a
  // leading '#'), the title, and the goal title (taskState.goalTitles — the
  // same map that labels the Goal filter, task 1755). Empty query matches all,
  // so clearing the box restores the full (still dropdown-filtered) list.
  function searchQuery() {
    const el = $('#f-search');
    return el ? el.value.trim().toLowerCase() : '';
  }
  function matchesSearch(t, q) {
    if (!q) return true;
    const needle = q.replace(/^#/, '');
    if (!needle) return true;
    if (String(t.id).includes(needle)) return true;
    if ((t.title || '').toLowerCase().includes(needle)) return true;
    const goalTitle = (taskState.goalTitles || {})[String(t.goal_id)] || '';
    if (goalTitle.toLowerCase().includes(needle)) return true;
    return false;
  }

  function renderClaimable() {
    const root = $('#task-list');
    if (!root) return;
    const vFilter = $('#f-version').value;
    const gFilter = $('#f-goal') ? $('#f-goal').value : '';
    const kFilter = $('#f-kind').value;
    const dFilter = $('#f-discipline').value;
    const nFilter = $('#f-newcomer') ? $('#f-newcomer').value : '';
    const sortBy = $('#f-sort').value;
    const sQuery = searchQuery();

    let list = taskState.all.filter((t) => {
      if (!matchesSearch(t, sQuery)) return false;
      if (vFilter && t.version_id !== vFilter) return false;
      // task 1755: goal filter. '__none__' isolates tasks with no goal.
      if (gFilter === '__none__' && t.goal_id != null) return false;
      if (gFilter && gFilter !== '__none__' && String(t.goal_id) !== gFilter) return false;
      if (kFilter && t.kind !== kFilter) return false;
      if (dFilter && (t.discipline || 'unclassified') !== dFilter) return false;
      if (nFilter === 'yes' && !t.newcomer_friendly) return false;
      return true;
    });

    // task 1756: run-mode filter — a task is "parallel-safe" when its touches[]
    // don't overlap any OTHER task in the currently-visible set; "conflict" is the
    // complement (would collide, so run them sequentially). Computed over the
    // already-filtered list so it answers "of what I'm looking at, what can run
    // together." O(n²) over touches — fine at board scale.
    const fitFilter = $('#f-fit') ? $('#f-fit').value : '';
    if (fitFilter === 'parallel' || fitFilter === 'conflict') {
      const base = list;
      list = base.filter((t) => {
        const conflicts = base.some((o) => o !== t && touchesConflict(t.touches, o.touches));
        return fitFilter === 'parallel' ? !conflicts : conflicts;
      });
    }

    if (sortBy === 'cpm') {
      list = list.slice().sort((a, b) => creditsPerMinute(b) - creditsPerMinute(a));
    } else if (sortBy === 'credits') {
      list = list.slice().sort((a, b) => Number(b.credits_reward || 0) - Number(a.credits_reward || 0));
    } else if (sortBy === 'minutes') {
      list = list.slice().sort((a, b) => (Number(a.est_minutes) || Infinity) - (Number(b.est_minutes) || Infinity));
    } else if (sortBy === 'priority') {
      list = list.slice().sort((a, b) => priorityRank(a.priority) - priorityRank(b.priority));
    } else if (sortBy === 'id') {
      // task 1830: sort by task number, ascending (lowest/oldest first).
      list = list.slice().sort((a, b) => Number(a.id) - Number(b.id));
    }

    const count = $('#claim-count');
    if (count) count.textContent = `${list.length} ${list.length === 1 ? 'task' : 'tasks'} waiting`;
    // task 1899: header count pill reflects the filtered-list length.
    setCountPill('#ready-count', list.length);

    if (!list.length) {
      root.innerHTML = `<div class="profile__placeholder">No tasks match these filters. Try widening them.</div>`;
      pagers.ready.page = 1;
      const pager = $('#ready-pager');
      if (pager) pager.hidden = true;
      return;
    }

    // task 1931/1955: paginate via the shared helper. renderClaimable never
    // RESETS the page (only an explicit filter/sort/per-page change does), so a
    // background poll keeps the viewer on their current page.
    const shown = paginate(list, pagers.ready);
    root.innerHTML = shown.map((t) => {
      const cpm = creditsPerMinute(t);
      const cpmText = Number.isFinite(cpm) ? `${cpm.toFixed(2)} d/min` : '— d/min';
      const minutesText = t.est_minutes ? `${t.est_minutes}m` : '—';
      const discipline = t.discipline || 'unclassified';
      const disciplineTag = discipline !== 'unclassified'
        ? `<span class="task__tag">${escapeHtml(discipline)}</span>`
        : '';
      const newcomerTag = t.newcomer_friendly
        ? '<span class="task__tag task__tag--newcomer">newcomer</span>'
        : '';
      const rankTag = rankTagHtml(t.requires_rank);
      const touches = Array.isArray(t.touches) ? t.touches : [];
      const touchesLine = touches.length
        ? `<div class="task__touches" title="Files this task is responsible for">✎ ${touches.map(escapeHtml).join(', ')}</div>`
        : '';
      const selected = selection.claim.has(String(t.id));
      return `
        <div class="task${selected ? ' task--selected' : ''}" data-task-id="${t.id}">
          <div class="task__id">
            <input type="checkbox" class="task__select" data-task-id="${t.id}" aria-label="Select task ${t.id} for bulk actions"${selected ? ' checked' : ''}>
            <span>#${t.id}</span>
            <button class="task__open" type="button" data-task-id="${t.id}" title="Open task details" aria-label="Open details for task ${t.id}">⤢</button>
          </div>
          <div class="task__body">
            <p class="task__title">${escapeHtml(t.title)}</p>
            <div class="task__meta">
              <span class="task__tag">${escapeHtml(t.version_id || '?')}</span>
              <span class="task__tag">${escapeHtml(t.kind || 'unclassified')}</span>
              ${disciplineTag}
              ${newcomerTag}
              ${rankTag}
              ${t.priority ? `<span class="task__tag">${escapeHtml(t.priority)}</span>` : ''}
              <span>${minutesText}</span>
              <span>${cpmText}</span>
            </div>
            ${touchesLine}
          </div>
          <div class="task__credits">
            <span class="task__credits-num">${fmtNum(window.OTBBranding?.taskCreditValue?.(t) ?? t.credits_reward)}</span>
            <span class="task__credits-label">${window.OTBBranding?.taskCreditLabel?.(t) ?? ((window.OTBBranding?.currencyLabel?.() ?? 'credits') + ' Est.')}</span>
          </div>
          <div class="task__actions">
            <button class="task__claim" type="button" data-task-id="${t.id}" aria-label="Claim task ${t.id}">Claim</button>
            <button class="task__copy" type="button" data-task-id="${t.id}" title="Copy the task prompt to your clipboard" aria-label="Copy prompt for task ${t.id}"><span class="task__copy-icon" aria-hidden="true">📋</span><span class="task__copy-label">Copy prompt</span></button>
          </div>
        </div>
      `;
    }).join('');
  }

  function populateVersionFilter(versions) {
    const sel = $('#f-version');
    if (!sel) return;
    for (const v of versions) {
      const opt = document.createElement('option');
      opt.value = v.id;
      opt.textContent = v.id;
      if (v.name && v.name !== v.id) opt.title = v.name;
      sel.appendChild(opt);
    }
  }

  // task 1755: the Goal filter — options are the goals present on the claimable
  // feed, labeled by title (falls back to 'Goal #id' before titles load).
  // '__none__' isolates ungoaled tasks. Populated once after the feed loads.
  function populateGoalFilter() {
    const sel = $('#f-goal');
    if (!sel) return;
    const cur = sel.value;
    const titles = taskState.goalTitles || {};
    const ids = [...new Set(taskState.all.map((t) => t.goal_id).filter((x) => x != null).map(String))];
    ids.sort((a, b) => String(titles[a] || `Goal #${a}`).localeCompare(String(titles[b] || `Goal #${b}`)));
    sel.length = 1; // keep the leading "— all goals —" option
    for (const id of ids) {
      const opt = document.createElement('option');
      opt.value = id;
      opt.textContent = titles[id] || `Goal #${id}`;
      sel.appendChild(opt);
    }
    if (taskState.all.some((t) => t.goal_id == null)) {
      const opt = document.createElement('option');
      opt.value = '__none__';
      opt.textContent = 'No goal';
      sel.appendChild(opt);
    }
    if (cur) sel.value = cur;
  }

  // Editors and the Claude desktop/CLI app autolink any bare "#NNN" in a session
  // transcript to the dev box's GitHub remote (…/issues/NNN), which 404s because
  // our records number tasks separately from GitHub. So the scroll we hand the
  // builder must never carry a bare "#NNN": write "task NNN" + the clickable hall
  // URL, and strip "#NNN" out of the (free-text) task description too.
  function deHashRefs(text) {
    return String(text == null ? '' : text).replace(/#(\d{1,5})\b/g, 'task $1');
  }

  function buildPromptForTask(t) {
    const desc = deHashRefs((t.description || '').trim());
    const hallBase = location.hostname.startsWith('builders.') ? location.origin : `${location.origin}/builders`;
    const hallUrl = `${hallBase}#/task/${t.id}`;
    return [
      `I am working on GDS task ${t.id} (${t.title}) — ${hallUrl}`,
      `Read the task description, follow its acceptance criteria, stay strictly within touches[], and ship via /builder-ship when done.`,
      ``,
      `Task description:`,
      desc || '(no description)',
    ].join('\n');
  }

  async function copyPromptForTask(taskId, btn) {
    const t = taskState.all.find((x) => String(x.id) === String(taskId));
    if (!t) return;
    const prompt = buildPromptForTask(t);
    const icon = btn.querySelector('.task__copy-icon');
    const label = btn.querySelector('.task__copy-label');
    try {
      await navigator.clipboard.writeText(prompt);
      btn.dataset.copied = '1';
      if (icon) icon.textContent = '✓';
      if (label) label.textContent = 'Copied';
      setTimeout(() => {
        btn.dataset.copied = '0';
        if (icon) icon.textContent = '📋';
        if (label) label.textContent = 'Copy prompt';
      }, 1600);
      toast(`Prompt for #${taskId} copied to your clipboard.`);
    } catch (err) {
      try {
        const ta = document.createElement('textarea');
        ta.value = prompt;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
        toast(`Prompt for #${taskId} copied.`);
      } catch (_) {
        toast('Could not copy to the clipboard. Try again.');
      }
    }
  }

  // ---- claim / release actions ---------------------------------------------

  // Map the server's typed error code to a builder-readable line. The codes are
  // exactly those POST /claims and POST /claims/:id/resolve can return.
  function friendlyActionError(status, data) {
    const code = data && data.error;
    switch (code) {
      case 'ALREADY_CLAIMED':
        return 'Someone else claimed that task first. The board will refresh.';
      case 'TASK_NOT_READY':
        return 'That task is no longer ready to be claimed.';
      case 'TOUCHES_CONFLICT': {
        const titles = Array.isArray(data.conflicts) ? data.conflicts.map((c) => c.title).filter(Boolean) : [];
        return titles.length
          ? `That task overlaps an active claim: ${titles.join('; ')}. Wait for it to ship.`
          : 'That task overlaps another active claim. Wait for it to ship.';
      }
      case 'DEPS_NOT_SHIPPED':
        return 'That task waits on unshipped dependencies. Pick another for now.';
      case 'rank_too_low_for_task':
      case 'XENOS_RESTRICTED':
      case 'INSUFFICIENT_RANK':
        return 'Your rank is not yet high enough for that task.';
      case 'newcomer_must_ship_first':
        return data.what_to_do || 'Ship your current claim before opening another.';
      case 'NOT_YOUR_CLAIM':
        return 'That claim is not yours to release.';
      case 'ALREADY_RESOLVED':
        return 'That claim was already resolved. The board will refresh.';
      case 'BUILDER_INACTIVE':
        return 'Your account is inactive. Contact an Archon.';
      default:
        return `The board could not complete that (${status}). Try again.`;
    }
  }

  // Maps a single batch-item failure reason (POST /claims/batch,
  // /claims/batch/validate) to a builder-readable fragment. Distinct from
  // friendlyActionError above because a batch item's shape differs (reason,
  // not error; extra fields like conflictsWithTaskId/module_key).
  function friendlyBatchReason(item) {
    switch (item && item.reason) {
      case 'TASK_NOT_FOUND': return 'no longer exists';
      case 'TASK_NOT_READY': return `no longer ready${item.currentStatus ? ` (${item.currentStatus})` : ''}`;
      case 'ALREADY_CLAIMED': return 'already claimed';
      case 'TOUCHES_CONFLICT': return `overlaps ${item.conflictTaskTitle || 'an active claim'}`;
      case 'BATCH_TOUCHES_CONFLICT': return `overlaps task #${item.conflictsWithTaskId} in this selection`;
      case 'MODULE_CONFLICT': return item.conflictsWithTaskId
        ? `shares module "${item.module_key}" with task #${item.conflictsWithTaskId} in this selection`
        : `shares module "${item.module_key}" with an active claim`;
      case 'DEPS_NOT_SHIPPED': return 'waits on unshipped dependencies';
      case 'rank_too_low_for_task':
      case 'XENOS_RESTRICTED':
      case 'INSUFFICIENT_RANK': return 'rank too low';
      case 'BUILDER_INACTIVE': return 'account inactive';
      default: return (item && item.reason) || 'not claimable';
    }
  }

  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); return true; }
    catch (_) {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        const ok = document.execCommand('copy');
        ta.remove();
        return ok;
      } catch (_e) {
        return false;
      }
    }
  }

  // ---- bulk selection (task 1759) -------------------------------------------

  function selectionTotal() { return selection.claim.size + selection.release.size; }

  // task 1869: the single place that flips a card's selection — used by both
  // the checkbox itself (forceChecked = its post-click .checked) and a click
  // anywhere else on the card body (forceChecked omitted = toggle). Keeping
  // one path means the checkbox's visual state, the card's highlight class,
  // and the selection Set can never drift out of sync with each other.
  function toggleTaskSelection(card, forceChecked) {
    const cb = card.querySelector('.task__select');
    if (!cb) return;
    const next = forceChecked != null ? forceChecked : !cb.checked;
    cb.checked = next;
    const id = String(cb.dataset.taskId);
    if (next) selection.claim.add(id); else selection.claim.delete(id);
    card.classList.toggle('task--selected', next);
    renderBulkToolbar();
  }

  // Drops any selected id that's fallen out from under the selection (claimed
  // by someone else, shipped, released elsewhere, …) so a stale checkbox never
  // outlives the row it pointed at. Called after every live refresh.
  function pruneSelection() {
    const claimableIds = new Set(taskState.all.map((t) => String(t.id)));
    for (const id of Array.from(selection.claim)) {
      if (!claimableIds.has(id)) selection.claim.delete(id);
    }
    const mineClaimIds = new Set(
      liveState.active
        .filter((c) => viewer.id != null && Number(c.builder_id) === Number(viewer.id))
        .map((c) => String(c.claim_id))
    );
    for (const claimId of Array.from(selection.release.keys())) {
      if (!mineClaimIds.has(claimId)) selection.release.delete(claimId);
    }
  }

  function selectedClaimIds() { return [...selection.claim].map(Number); }
  function selectionKey(ids) { return ids.slice().sort((a, b) => a - b).join(','); }

  async function scheduleValidate(key, ids) {
    if (validateDebounce) clearTimeout(validateDebounce);
    validateDebounce = setTimeout(async () => {
      try {
        const result = await postJSON(`${API}/claims/batch/validate`, { task_ids: ids });
        validateCache.key = key;
        validateCache.parallelSafe = !!result.parallel_safe;
        validateCache.byId = new Map((result.results || []).map((r) => [String(r.task_id), r]));
      } catch (_) {
        // Best-effort — leave Parallel disabled-with-a-generic-title on failure
        // rather than risk copying a prompt for tasks we couldn't verify.
        validateCache.key = key;
        validateCache.parallelSafe = false;
        validateCache.byId = new Map();
      }
      renderBulkToolbar();
    }, 350);
  }

  async function fetchDeps(taskId) {
    if (depsCache.has(taskId)) return depsCache.get(taskId);
    let deps = [];
    try {
      const d = await getJSON(`${API}/tasks/${encodeURIComponent(taskId)}`, { softAuth: true });
      if (d && d.task && Array.isArray(d.task.dependencies)) {
        deps = d.task.dependencies.map((x) => Number(x.id)).filter((x) => Number.isFinite(x));
      }
    } catch (_) { /* treat as no known dependencies */ }
    depsCache.set(taskId, deps);
    return deps;
  }

  // Kahn's algorithm restricted to edges BETWEEN the selected ids (an
  // out-of-selection dependency doesn't block sequencing the selection
  // itself). Returns the topological order, or null if the restricted graph
  // has a cycle (can't be sequenced).
  function topoOrder(ids, edgesByTask) {
    const remaining = new Set(ids);
    const order = [];
    let progressed = true;
    while (remaining.size && progressed) {
      progressed = false;
      for (const id of Array.from(remaining)) {
        const deps = (edgesByTask.get(id) || []).filter((d) => remaining.has(d));
        if (deps.length === 0) {
          order.push(id);
          remaining.delete(id);
          progressed = true;
        }
      }
    }
    return remaining.size ? null : order;
  }

  function scheduleSequentialCheck(key, ids) {
    if (sequentialDebounce) clearTimeout(sequentialDebounce);
    sequentialDebounce = setTimeout(async () => {
      const edgesByTask = new Map();
      await Promise.all(ids.map(async (id) => { edgesByTask.set(id, await fetchDeps(id)); }));
      sequentialCache.key = key;
      sequentialCache.order = topoOrder(ids, edgesByTask);
      renderBulkToolbar();
    }, 350);
  }

  function renderBulkToolbar() {
    const bar = $('#bulk-toolbar');
    if (!bar) return;
    if (selectionTotal() === 0) { bar.hidden = true; return; }
    bar.hidden = false;

    const countEl = $('#bulk-count');
    if (countEl) {
      const parts = [];
      if (selection.claim.size) parts.push(`${selection.claim.size} to claim`);
      if (selection.release.size) parts.push(`${selection.release.size} to release`);
      countEl.textContent = parts.join(' · ');
    }

    const claimBtn = $('#bulk-claim-btn');
    if (claimBtn) {
      claimBtn.disabled = selection.claim.size === 0;
      claimBtn.textContent = selection.claim.size > 1 ? `Bulk claim (${selection.claim.size})` : 'Bulk claim';
    }
    const releaseBtn = $('#bulk-release-btn');
    if (releaseBtn) {
      releaseBtn.disabled = selection.release.size === 0;
      releaseBtn.textContent = selection.release.size > 1 ? `Bulk release (${selection.release.size})` : 'Bulk release';
    }

    const parallelBtn = $('#bulk-parallel-btn');
    if (parallelBtn) {
      if (selection.claim.size < 2) {
        parallelBtn.disabled = true;
        parallelBtn.title = 'Select at least 2 waiting tasks to copy a parallel-session prompt.';
      } else {
        const ids = selectedClaimIds();
        const key = selectionKey(ids);
        if (validateCache.key === key && validateCache.parallelSafe != null) {
          parallelBtn.disabled = !validateCache.parallelSafe;
          if (!validateCache.parallelSafe) {
            const bad = [...validateCache.byId.values()].filter((r) => !r.valid);
            const detail = bad.map((r) => `#${r.task_id}: ${(r.reasons || []).map(friendlyBatchReason).join(', ')}`).join(' · ');
            parallelBtn.title = detail || 'Selected tasks conflict and cannot run in parallel.';
          } else {
            parallelBtn.title = '';
          }
        } else {
          parallelBtn.disabled = true;
          parallelBtn.title = 'Checking for conflicts…';
          scheduleValidate(key, ids);
        }
      }
    }

    const sequentialBtn = $('#bulk-sequential-btn');
    if (sequentialBtn) {
      if (selection.claim.size < 2) {
        sequentialBtn.disabled = true;
        sequentialBtn.title = 'Select at least 2 waiting tasks to copy a sequential prompt.';
      } else {
        const ids = selectedClaimIds();
        const key = selectionKey(ids);
        if (sequentialCache.key === key) {
          sequentialBtn.disabled = sequentialCache.order == null;
          sequentialBtn.title = sequentialCache.order == null
            ? 'These tasks depend on each other in a cycle and cannot be ordered.'
            : '';
        } else {
          sequentialBtn.disabled = true;
          sequentialBtn.title = 'Checking dependency order…';
          scheduleSequentialCheck(key, ids);
        }
      }
    }
  }

  function clearSelection() {
    selection.claim.clear();
    selection.release.clear();
    renderClaimable();
    renderInFlight();
    renderBulkToolbar();
  }

  function buildBulkParallelPrompt(tasks) {
    const hallBase = location.hostname.startsWith('builders.') ? location.origin : `${location.origin}/builders`;
    const lines = [
      `I want to work on ${tasks.length} GDS tasks IN PARALLEL — open ${tasks.length} separate Claude Code sessions, each in its own worktree, one per task below, so they can run at the same time without touching each other's files.`,
      '',
    ];
    tasks.forEach((t, i) => {
      lines.push(`Session ${i + 1} — task ${t.id} (${t.title}) — ${hallBase}#/task/${t.id}`);
      lines.push(`Claim it with /builder-claim ${t.id}, follow its acceptance criteria, stay within touches[], ship via /builder-ship when done.`);
      lines.push('');
    });
    return lines.join('\n').trim();
  }

  function buildBulkSequentialPrompt(tasks) {
    const hallBase = location.hostname.startsWith('builders.') ? location.origin : `${location.origin}/builders`;
    const lines = [
      `I want to work on ${tasks.length} GDS tasks IN ORDER, one after another in this same session — claim, build, and ship each before moving to the next.`,
      '',
    ];
    tasks.forEach((t, i) => {
      lines.push(`${i + 1}. Task ${t.id} (${t.title}) — ${hallBase}#/task/${t.id}`);
    });
    lines.push('');
    lines.push('For each: /builder-claim <id>, follow its acceptance criteria, stay within touches[], /builder-ship <id> before starting the next.');
    return lines.join('\n');
  }

  async function doBulkClaim() {
    const ids = selectedClaimIds();
    if (!ids.length) return;
    const btn = $('#bulk-claim-btn');
    if (btn) { btn.disabled = true; btn.textContent = 'Claiming…'; }
    try {
      if (ids.length === 1) {
        await postJSON(`${API}/claims`, { task_id: ids[0], bind_session: false });
        toast(`You claimed #${ids[0]}. Open a terminal to start work.`);
      } else {
        await postJSON(`${API}/claims/batch`, { task_ids: ids, bind_session: false });
        toast(`Claimed ${ids.length} tasks. Open a terminal to start work.`);
      }
      selection.claim.clear();
      await refreshLive();
    } catch (err) {
      if (err && err.message === 'redirecting to auth') return;
      if (err.status === 409 && err.data && err.data.error === 'batch_failed') {
        const failures = Array.isArray(err.data.failures) ? err.data.failures : [];
        const lines = failures.map((f) => `#${f.task_id} (${friendlyBatchReason(f)})`);
        toast(lines.length
          ? `The batch could not be claimed — ${lines.join('; ')}.`
          : 'The batch could not be claimed. It was left untouched (all-or-nothing).');
        await refreshLive().catch(() => {});
      } else {
        toast(friendlyActionError(err.status, err.data));
        if (err.status === 409) await refreshLive().catch(() => {});
      }
    } finally {
      renderBulkToolbar();
    }
  }

  async function doBulkRelease() {
    const entries = [...selection.release.entries()]; // [claimId, taskId]
    if (!entries.length) return;
    const label = entries.length === 1 ? `#${entries[0][1]}` : `${entries.length} tasks`;
    const pronoun = entries.length === 1 ? 'It returns' : 'They return';
    if (!window.confirm(`Release ${label}? ${pronoun} to the queue and no ${curLabel()} are earned.`)) return;
    const btn = $('#bulk-release-btn');
    if (btn) { btn.disabled = true; btn.textContent = 'Releasing…'; }
    try {
      if (entries.length === 1) {
        await postJSON(`${API}/claims/${encodeURIComponent(entries[0][0])}/resolve`, { outcome: 'abandoned' });
        toast(`Released #${entries[0][1]}. It returns to the queue.`);
      } else {
        const result = await postJSON(`${API}/claims/batch/release`, { claim_ids: entries.map(([cid]) => Number(cid)) });
        const released = Array.isArray(result.released) ? result.released.length : 0;
        const failed = Array.isArray(result.failures) ? result.failures.length : 0;
        toast(failed
          ? `Released ${released} of ${entries.length} — ${failed} could not be released.`
          : `Released ${released} tasks. They return to the queue.`);
      }
      selection.release.clear();
      await refreshLive();
    } catch (err) {
      if (err && err.message === 'redirecting to auth') return;
      toast(friendlyActionError(err.status, err.data));
    } finally {
      renderBulkToolbar();
    }
  }

  async function doClaim(taskId, btn) {
    const key = `claim:${taskId}`;
    if (pending.has(key)) return;
    pending.add(key);
    if (btn) { btn.disabled = true; btn.textContent = 'Claiming…'; }
    try {
      // bind_session:false — a web claim has no working session, so leave it
      // unbound (see claims.js resolveCreatorSessionId) and the builder can ship
      // it later from any of their own terminals.
      await postJSON(`${API}/claims`, { task_id: Number(taskId), bind_session: false });
      toast(`You claimed #${taskId}. Open a terminal to start work.`);
      await refreshLive();
    } catch (err) {
      if (err && err.message === 'redirecting to auth') return;
      toast(friendlyActionError(err.status, err.data));
      // A conflict/already-claimed means our view is stale — pull fresh truth.
      if (err.status === 409) await refreshLive().catch(() => {});
      if (btn) { btn.disabled = false; btn.textContent = 'Claim'; }
    } finally {
      pending.delete(key);
    }
  }

  async function doRelease(claimId, taskId, btn) {
    const key = `release:${claimId}`;
    if (pending.has(key)) return;
    if (!window.confirm(`Release your claim on #${taskId}? It returns to the queue and no ${curLabel()} are earned.`)) return;
    pending.add(key);
    if (btn) { btn.disabled = true; btn.textContent = 'Releasing…'; }
    try {
      // No DELETE /claims/:id exists — release is resolve(outcome=abandoned),
      // the same path /builder-release uses. Scoped to the caller's own claim
      // server-side (NOT_YOUR_CLAIM).
      await postJSON(`${API}/claims/${encodeURIComponent(claimId)}/resolve`, { outcome: 'abandoned' });
      toast(`Released #${taskId}. It returns to the queue.`);
      await refreshLive();
    } catch (err) {
      if (err && err.message === 'redirecting to auth') return;
      toast(friendlyActionError(err.status, err.data));
      if (err.status === 409) await refreshLive().catch(() => {});
      if (btn) { btn.disabled = false; btn.textContent = 'Release'; }
    } finally {
      pending.delete(key);
    }
  }

  // ---- recent history (completed / shipped) --------------------------------

  // task 1899: module-level store so the Completed pager can re-render without a
  // param (mirrors renderInFlight's liveState.active pattern).
  let historyRows = [];

  // ---- task 1469: project-wide "works completed" momentum summary ----------
  //
  // A compact card above the Completed list summarizing the WHOLE project's
  // shipped output (NOT the viewer's own — that lives on the profile page): total
  // works shipped (all-time, summed from /public/progress lifecycle_shipped_count),
  // total <currency> awarded (/public/cost-summary total_value_credits), and the
  // most recent ship (the head of the recent-shipped feed already loaded for the
  // history list). All three are public reads; no per-builder data.
  let worksSummary = { progress: null, cost: null };

  function summaryTile(label, num, sub, subTitle) {
    const subHtml = sub
      ? `<span class="stat-tile__sub" ${subTitle ? `title="${escapeHtml(subTitle)}" ` : ''}style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(sub)}</span>`
      : '';
    return `<div class="stat-tile"><span class="stat-tile__label">${escapeHtml(label)}</span>` +
      `<span class="stat-tile__num">${escapeHtml(String(num))}</span>${subHtml}</div>`;
  }

  function renderWorksSummary() {
    const root = $('#works-summary');
    if (!root) return;
    const versions = worksSummary.progress && Array.isArray(worksSummary.progress.progress)
      ? worksSummary.progress.progress : null;
    // Wait for the shipped-count feed; the card stays hidden until then (and on a
    // project that has shipped nothing).
    if (!versions) { root.hidden = true; return; }
    const shipped = versions.reduce((n, v) => n + (Number(v.lifecycle_shipped_count) || 0), 0);
    if (!shipped) { root.hidden = true; return; }
    const awarded = worksSummary.cost ? Number(worksSummary.cost.total_value_credits) || 0 : null;
    const latest = Array.isArray(historyRows) && historyRows.length ? historyRows[0] : null;

    const tiles = [summaryTile('Works shipped', fmtNum(shipped))];
    if (awarded != null) tiles.push(summaryTile(`${curLabel(true)} awarded`, fmtNum(awarded)));
    if (latest) {
      tiles.push(summaryTile('Latest ship', latest.shipped_at ? fmtAgo(latest.shipped_at) : '—',
        latest.title || `#${latest.id}`, latest.title || ''));
    }
    root.innerHTML = tiles.join('');
    root.hidden = false;
  }

  function renderHistory(tasks) {
    if (Array.isArray(tasks)) historyRows = tasks;
    const root = $('#history-list');
    if (!root) return;
    // task 1754: reveal the Completed group only when there are shipped tasks.
    const scroll = $('#history-scroll');
    if (scroll) scroll.hidden = !historyRows.length;
    const rows = historyRows;
    setCountPill('#done-count', rows.length);
    if (!rows.length) {
      root.innerHTML = `<div class="profile__placeholder">Nothing shipped yet.</div>`;
      pagers.done.page = 1;
      const dp = $('#done-pager');
      if (dp) dp.hidden = true;
      return;
    }
    const shown = paginate(rows, pagers.done);
    root.innerHTML = shown.map((t) => {
      const ver = t.version_id ? `<span class="task__tag">${escapeHtml(t.version_id)}</span>` : '';
      const when = t.shipped_at ? fmtAgo(t.shipped_at) : '';
      return `
        <div class="history__row">
          <span class="history__id">#${escapeHtml(String(t.id))}</span>
          <span class="history__title">${escapeHtml(t.title || '(untitled)')} ${ver}</span>
          <span class="history__when" title="${escapeHtml(fmtDate(t.shipped_at))}">${escapeHtml(when)}</span>
        </div>
      `;
    }).join('');
    // task 1469: now that historyRows is populated, (re)render the momentum card so
    // its "Latest ship" tile reflects the newest shipped task.
    renderWorksSummary();
  }

  // ---- backlog (not-yet-ready tasks) ---------------------------------------

  // task 1754: the collapsed "Backlog" group — status=backlog tasks, read-only
  // (they can't be claimed until their blockers ship). Reuses rankTagHtml (1752)
  // and opens the shared task-detail overlay (1753) on click.
  // task 1955: module-level store so the Backlog pager re-renders without a param.
  let backlogRows = [];

  function renderBacklog(tasks) {
    if (Array.isArray(tasks)) backlogRows = tasks;
    const scroll = $('#backlog-scroll');
    const root = $('#backlog-list');
    if (!root) return;
    // Hide the whole section only when there's genuinely no backlog; when a
    // search is active but filters everything out, keep the section visible so
    // the "0 tasks" count explains the empty list (task 1829).
    if (!backlogRows.length) { if (scroll) scroll.hidden = true; return; }
    const q = searchQuery();
    const list = q ? backlogRows.filter((t) => matchesSearch(t, q)) : backlogRows;
    if (scroll) scroll.hidden = false;
    const countEl = $('#backlog-count');
    if (countEl) countEl.textContent = `${list.length} ${list.length === 1 ? 'task' : 'tasks'}`;
    const shown = paginate(list, pagers.backlog);
    root.innerHTML = shown.map((t) => {
      const ver = t.version_id ? `<span class="task__tag">${escapeHtml(t.version_id)}</span>` : '';
      return `
        <div class="history__row" data-task-id="${escapeHtml(String(t.id))}" title="Open task #${escapeHtml(String(t.id))}">
          <span class="history__id">#${escapeHtml(String(t.id))}</span>
          <span class="history__title">${escapeHtml(t.title || '(untitled)')} ${ver} ${rankTagHtml(t.requires_rank)}</span>
          <span class="history__when">${escapeHtml(t.kind || '')}</span>
        </div>`;
    }).join('');
  }

  // ---- live refresh + polling ----------------------------------------------

  // Pull the claimable feed + active claims and re-render both. Shared by the
  // post-action refresh and the poll timer. Swallows the gate/transport errors
  // the same way loadAll does so a transient failure doesn't blank the board.
  async function refreshLive() {
    try {
      const claimResp = await getJSON(`${API}/tasks/claimable`);
      renderInFlight(claimResp.active_claims || []);
      taskState.all = claimResp.claimable || [];
      renderClaimable();
      pruneSelection();
      renderBulkToolbar();
    } catch (err) {
      if (err && err.status === 403) { showClaimGate(); renderInFlight([]); }
      // Other failures: keep the last good render rather than blanking.
    }
  }

  function startPolling() {
    // Re-render the in-flight ages every tick even without new data, and pull
    // fresh truth from the server. Paused while the tab is hidden to avoid
    // pointless background traffic.
    const POLL_MS = 20000;
    setInterval(() => {
      if (document.hidden) { return; }
      refreshLive();
    }, POLL_MS);
    // Cheap local re-render of claim ages between polls.
    setInterval(() => {
      if (!document.hidden && liveState.active.length) renderInFlight();
    }, 60000);
    // Snap to fresh data the moment the tab regains focus.
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) refreshLive();
    });
  }

  // ---- gate notice (signed in, primer not yet read) ------------------------

  function showClaimGate() {
    const gate = $('#gate-scroll');
    const claim = $('#claim-scroll');
    if (gate) gate.hidden = false;
    if (claim) claim.hidden = true;
  }

  // ---- bootstrap -----------------------------------------------------------

  async function loadAll() {
    // /me confirms the viewer + personalises the header. softAuth so a stale
    // session renders the page chrome rather than a hard bounce — though the
    // server gate means an unauth visitor never gets here in the first place.
    let me = null;
    try {
      me = await getJSON(`${API}/me`, { softAuth: true });
    } catch (err) {
      if (err && err.code === AUTH_NEEDED) { toAuth(); return; }
      throw err;
    }
    viewer.id = me?.builder?.id ?? null;
    const sub = $('#work-sub');
    if (sub) {
      const name = me?.builder?.display_name || me?.builder?.github_login || 'builder';
      sub.textContent = `Welcome, ${name}. Claim and release tasks and follow work in progress — no terminal needed.`;
    }

    // Recent history — public read surface, never gated. Independent of the
    // claimable feed so it paints even if that's gated/late.
    getJSON(`${API}/public/recent-shipped`)
      .then((r) => renderHistory(r.tasks || []))
      .catch(() => {
        const root = $('#history-list');
        if (root) root.innerHTML = `<div class="profile__placeholder">Recent history could not be loaded right now.</div>`;
      });

    // task 1469: the project-wide "works completed" momentum summary above the
    // Completed list. Public reads, independent of the claimable feed so it paints
    // regardless; the card stays hidden if either read fails.
    Promise.all([
      getJSON(`${API}/public/progress`).catch(() => null),
      getJSON(`${API}/public/cost-summary`).catch(() => null),
    ]).then(([progress, cost]) => {
      worksSummary = { progress, cost };
      renderWorksSummary();
    });

    // task 1754: the Backlog group — not-yet-ready tasks. Best-effort + independent
    // of the claimable feed; leaves the section hidden on failure.
    getJSON(`${API}/tasks?status=backlog`)
      .then((r) => { taskState.backlog = r.tasks || []; renderBacklog(taskState.backlog); })
      .catch(() => { /* backlog stays hidden */ });

    // task 1755: goal id → title map for the Goal filter (best-effort).
    taskState.goalTitles = {};
    try {
      const gr = await getJSON(`${API}/goals`);
      (gr.goals || []).forEach((g) => { taskState.goalTitles[g.id] = g.title; });
    } catch (_) { /* filter labels fall back to 'Goal #id' */ }

    // Claimable + active claims in one call. A 403 means the primer gate — show
    // the friendly notice and hide the claim queue, but keep the in-flight list
    // empty-but-honest (the gate also blocks active_claims, so say so).
    try {
      const [claimResp, versionsResp] = await Promise.all([
        getJSON(`${API}/tasks/claimable`),
        getJSON(`${API}/versions`).catch(() => ({ versions: [] })),
      ]);
      taskState.versions = versionsResp.versions || [];
      populateVersionFilter(taskState.versions);
      renderInFlight(claimResp.active_claims || []);
      taskState.all = claimResp.claimable || [];
      renderClaimable();
      populateGoalFilter(); // task 1755
      pruneSelection();
      renderBulkToolbar();
    } catch (err) {
      if (err && err.status === 403) {
        showClaimGate();
        renderInFlight([]);
        return;
      }
      const root = $('#task-list');
      if (root) root.innerHTML = `<div class="profile__placeholder">The task list could not be loaded right now.</div>`;
      renderInFlight([]);
    }
  }

  function wireEvents() {
    // task 1931: any filter/sort change re-paginates the Ready list from page 1.
    const onReadyFilterChange = () => { pagers.ready.page = 1; renderClaimable(); };
    $('#f-version')?.addEventListener('change', onReadyFilterChange);
    $('#f-goal')?.addEventListener('change', onReadyFilterChange);
    $('#f-kind')?.addEventListener('change', onReadyFilterChange);
    $('#f-discipline')?.addEventListener('change', onReadyFilterChange);
    $('#f-newcomer')?.addEventListener('change', onReadyFilterChange);
    $('#f-fit')?.addEventListener('change', onReadyFilterChange);
    $('#f-sort')?.addEventListener('change', onReadyFilterChange);
    // task 1829: free-text search — 'input' fires on every keystroke and on the
    // type=search clear (✕). Re-render BOTH the claimable and backlog lists,
    // resetting each to page 1 so matches aren't hidden behind pagination.
    $('#f-search')?.addEventListener('input', () => {
      pagers.ready.page = 1;
      pagers.backlog.page = 1;
      renderClaimable();
      renderBacklog();
    });

    // task 1931/1955: pagination controls for all four Work-page lists.
    wirePager(pagers.ready, renderClaimable);
    wirePager(pagers.wip, renderInFlight);
    wirePager(pagers.done, renderHistory);
    wirePager(pagers.backlog, renderBacklog);

    $('#task-list')?.addEventListener('click', (e) => {
      // task 1759: the multi-select checkbox. Toggle the Set + the card's
      // highlight class directly (cheaper than a full renderClaimable) and
      // stop here — it must never fall through to the card-select handler below.
      const selectCb = e.target.closest('.task__select');
      if (selectCb) {
        const card = selectCb.closest('.task');
        if (card) toggleTaskSelection(card, selectCb.checked);
        return;
      }
      const claimBtn = e.target.closest('.task__claim');
      if (claimBtn) { doClaim(claimBtn.dataset.taskId, claimBtn); return; }
      const copyBtn = e.target.closest('.task__copy');
      if (copyBtn) { copyPromptForTask(copyBtn.dataset.taskId, copyBtn); return; }
      // task 1869: the explicit open-detail hitbox — now the ONLY way to open
      // the shared task-detail overlay from a claimable card (the card body
      // itself toggles selection below, since multi-select is the primary card
      // interaction now that 1759 shipped).
      const openBtn = e.target.closest('.task__open');
      if (openBtn && openBtn.dataset.taskId && window.OTBTaskDetail) {
        window.OTBTaskDetail.open(openBtn.dataset.taskId);
        return;
      }
      // task 1869: clicking the card anywhere else toggles its selection
      // checkbox (matches the affordance a checkbox already implies).
      const card = e.target.closest('.task');
      if (card && card.dataset.taskId) toggleTaskSelection(card);
    });

    // task 1754: a Backlog row opens the shared task-detail overlay (read-only).
    $('#backlog-list')?.addEventListener('click', (e) => {
      const row = e.target.closest('.history__row');
      if (row && row.dataset.taskId && window.OTBTaskDetail) window.OTBTaskDetail.open(row.dataset.taskId);
    });

    // Release lives in the in-flight table (the viewer's own claims only).
    $('#wip-table')?.addEventListener('click', (e) => {
      // task 1759: the bulk-release checkbox — mirrors the task-list one above.
      const selectCb = e.target.closest('.wip__select');
      if (selectCb) {
        const claimId = String(selectCb.dataset.claimId);
        if (selectCb.checked) selection.release.set(claimId, selectCb.dataset.taskId);
        else selection.release.delete(claimId);
        renderBulkToolbar();
        return;
      }
      const rel = e.target.closest('.wip__release');
      if (!rel) return;
      doRelease(rel.dataset.claimId, rel.dataset.taskId, rel);
    });

    // task 1759: the bottom bulk-action toolbar.
    $('#bulk-claim-btn')?.addEventListener('click', doBulkClaim);
    $('#bulk-release-btn')?.addEventListener('click', doBulkRelease);
    $('#bulk-clear-btn')?.addEventListener('click', clearSelection);
    $('#bulk-parallel-btn')?.addEventListener('click', async () => {
      const ids = selectedClaimIds();
      const tasks = ids.map((id) => taskState.all.find((t) => Number(t.id) === id)).filter(Boolean);
      if (tasks.length < 2) return;
      const ok = await copyText(buildBulkParallelPrompt(tasks));
      toast(ok ? `Parallel-session prompt for ${tasks.length} tasks copied.` : 'Could not copy to the clipboard.');
    });
    $('#bulk-sequential-btn')?.addEventListener('click', async () => {
      const ids = selectedClaimIds();
      const key = selectionKey(ids);
      if (sequentialCache.key !== key || sequentialCache.order == null) return;
      const tasks = sequentialCache.order.map((id) => taskState.all.find((t) => Number(t.id) === id)).filter(Boolean);
      if (tasks.length < 2) return;
      const ok = await copyText(buildBulkSequentialPrompt(tasks));
      toast(ok ? `Sequential prompt for ${tasks.length} tasks copied.` : 'Could not copy to the clipboard.');
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    wireEvents();
    loadAll()
      .then(() => startPolling())
      .catch((err) => {
        console.error('[work] load failed:', err);
        toast('The work board failed to load. Reload to try again.');
      });
  });
})();
