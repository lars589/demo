# ADR 0047 — Discord `#bugs` intake → GDS tasks, straight-through, with a layered anti-abuse guard

- **Status:** Accepted
- **Date:** 2026-06-12
- **Task:** [#931](https://example.com/builders#/task/931)
- **Extends:** [ADR 0033](<redacted>.md) (Discord bot service principal, the `#ideas` → `idea_inbox` inbound path), [ADR 0016](<redacted>.md) (trust boundary), [ADR 0034](<redacted>.md) (the rank ladder this leans on)

## Context

Builders wanted somewhere to drop a small fix they've spotted without context-switching into a full claim. The `#ideas` channel already exists (ADR 0033 §F6), but ideas land in `idea_inbox` and wait for human triage (`/idea-triage`) before becoming work. Lars's directive (2026-06-12): **bugs skip triage and become GDS tasks (`kind='bug'`) directly** — claimable work, straight through.

That directive carries an embedded red-team question the task made a hard requirement: *if bug-filing creates tasks with no triage gate, how do we stop someone injecting nonsense / spam / malicious bugs into the queue?* The straight-through path and the abuse guard are the **same** task — neither ships without the other.

## Decision

A `#bugs` Discord channel (added to `docs/discord/channels.json`) whose messages the bot turns into GDS tasks (`kind='bug'`) via a new in-process module `src/bongos/discord-bugs.js`, structurally parallel to `discord-inbound.js` but routing to `db.createTask` instead of `inbox.captureIdea`. The intake is guarded **in depth**, all server-side, all fail-closed:

1. **Linked-builder-only.** An *unlinked* Discord author cannot create a task — their message is ignored (logged, not filed). Unlike `#ideas` (which captures unattributed ideas), making *claimable work* requires being an accountable, known builder who has completed the GitHub→Discord OAuth link. This is the single biggest anti-abuse lever: no anonymous injection.
2. **Rank-aware landing.** A linked **Metic+** builder's bug lands `status='ready'` — instantly claimable, the true straight-through path their trust earns. A linked **Xenos/Thetes** builder's bug lands `status='backlog'`, where a Metic+ promotes it (`POST /tasks/:id/promote`, the one-click confirm-to-ready already used by `/idea-triage`). The landing is decided server-side from the reporter's **live** rank, never from anything in the message. This mirrors the trust ladder used everywhere else in the GDS.
3. **Per-builder rate-limit.** At most N bug-tasks per builder per rolling hour (default 5, `DISCORD_BUGS_RATE_PER_HOUR`), counted from `audit_log` (`db.countRecentDiscordBugFilings`). Over-limit filings are ignored **and audited** (`response_status=429`, `surface='discord_bot'`) so a spammer surfaces in forensics. The count fails *open* (the linked-builder + audit trail still hold a spammer accountable) so a transient DB hiccup never loses a real report.
4. **Body screen.** Empty / too-short (< 8 chars) / text-free (no letters) messages are rejected before any DB write; title + body are capped to the GDS limits.

Every filing is audited with `surface='discord_bot'` (`route='discord:bugs'`), so the existing `GET /audit?surface=discord_bot` forensic surface covers this path with no new endpoint.

### Why rank-aware landing rather than always-ready or always-backlog

- *Always-ready* honors "straight-through" most literally but puts a newcomer's (or a freshly-compromised account's) unreviewed text straight into the claimable queue.
- *Always-backlog + confirm* is safest but isn't really "straight-through" — it's just lighter triage, which defeats the point for the trusted builders this feature is for.
- *Rank-aware* gives trusted builders (Metic+) the genuine straight-through path while gating exactly the population the red-team question worries about (newcomers / low-trust), at zero extra ceremony for the people who earned trust. It reuses machinery that already exists (rank, `promote`), so it adds a decision function, not a subsystem.

## Consequences

- **Config / go-live:** inert until `DISCORD_BUGS_CHANNEL_ID` (env, or `bugs_channel_id` in `~/.config/otb/discord-bot.json`) is set **and** the bot is enabled (`DISCORD_BOT_ENABLED=true`) with the Message Content intent — exactly like `#ideas`. The channel itself is created/edited by the ADR 0037 channel reconciler from `channels.json`.
- **Version:** filed bugs default to `DISCORD_BUGS_VERSION_ID` (default `GDS-V3`, the open internal version, since most builder-filed bugs are about the dev system). An Archon can re-home a game bug to a product version. Reward defaults to `DISCORD_BUGS_CREDITS` (10).
- **Trust boundary intact (ADR 0016):** the bot asserts only *who* posted; the landing state is derived from the live GDS rank, never trusted from the message. The bot grants nothing.
- **Deferred:** a dedicated abuse-flag widget on the `/watch` red-team view. The audit trail (`surface='discord_bot'`, the 429 rejections) already makes abuse queryable; a bespoke view is a follow-up if volume warrants it.
