# Recipe — running the autonomous overnight builder ("session polling")

> Added under GDS-V3 task [#358](https://example.com/builders#/task/358). The routine itself is `.claude/scheduled-tasks/overnight-builder/SKILL.md`; this page is the operator's runbook. Archon-only.

## What it does

Starts one session that works the GDS queue **by priority, on its own**. It claims the highest-priority safe task, works it in a fresh sub-agent, ships it, then re-polls the claimable list — the promote-on-ship DB trigger (migration 020) self-feeds the queue, so as soon as one task ships the next unblocked one is waiting. It loops until nothing claimable remains, the time budget runs out, or the cost cap is hit.

It only ever touches tasks the GDS marks safe to run unattended (`automation_tag = 'overnight-safe'`, `manual_degree <= 2`, unblocked). Nothing broken reaches `main`: the quality grader gates credits and the auto-merge re-runs smoke tests and bails (parking the task) on any conflict or failure.

## Start it (serial — the proven path)

1. **Keep the Mac awake.** Deploys run from your machine, so it must stay on. In a terminal:
   ```bash
   caffeinate -i &
   ```
   `caffeinate` is a built-in macOS command that stops the Mac from sleeping; `-i` prevents idle sleep until you kill it (`kill %1` or just close the terminal in the morning). Nothing to install.
2. **Open a Claude Code session** in the repo and launch the routine, e.g.:
   > "Run the overnight-builder routine. Serial, 6-hour budget, stop at $40."
3. It checks you're **Archon** (refuses otherwise), then loops. Walk away.

## Go parallel (advanced — opt in only with credit headroom)

Parallel runs several tasks at once in **separate isolated worktrees**. It gets more done but spends Claude credits several times faster and has more ways to get stuck unattended. Only use it when you know you have the credit headroom for the night.

> "Run overnight-builder, **parallel 3**, 6-hour budget, stop at $80."

The runner only fills parallel slots with tasks explicitly flagged **`parallel_safe = true`** (and, as always, with non-overlapping file footprints). Flag a task parallel-safe at creation (`parallel_safe: true` in `POST /api/gds/tasks`) or after the fact:

```bash
TOKEN=$(node -e "console.log(require(require('os').homedir()+'/.config/otb/pms-session.json').token)")
curl -sS -X PATCH -H "Authorization: Bearer ${TOKEN}" -H "Content-Type: application/json" \
  -d '{"parallel_safe": true}' https://example.com/api/gds/tasks/<id>
```

In parallel mode each worker stops at `confirmed` (credits land) and the runner lands the merges **one at a time** — concurrent merges to `main` are never allowed.

## Reading the morning report

The end-of-run report buckets everything; the only things needing you are:

- **Parked — needs merge** (`confirmed`): a ship passed quality review but hasn't landed yet. The server reconciler sweeps these to `shipped` on its own within ~5 min — re-check the report before acting. Only if one is *still* parked after that does it need **`/merge-mode`** by hand (a conflict the server couldn't auto-resolve).
- **Parked — needs grade review** (`completed`): the quality grader failed or flaked (it flakes ~1 in 3). Eyeball the change; if it's good, manually confirm it (`POST /api/gds/tasks/:id/confirm`, archon-only).
- **Released with feedback**: the runner couldn't finish these and put them back in the queue with a note (a captured learning) explaining why — so the next builder, you or it, doesn't start from zero. Nothing to do unless you want to unblock them.

Everything under **Shipped** is already merged and deployed.

## Gotchas

- **It's archon-only** by policy (only `archon` and `thetes` ranks are live; claim/ship are open to any builder at the API, so the rank check lives in the routine). When middle ranks go live, widen the gate there.
- **No more `--expand-touches` / drift scanner (task 879).** ship.js no longer scans for files outside the declared touches[] or offers to expand it — a wrong up-front prediction isn't ship-blocking; `git merge` at land time is the authoritative collision detector. (Older notes referenced `--expand-touches auto`; that flag is gone.)
- **`.env.local` doesn't propagate to fresh worktrees** — if a parallel worker's task hits the Google API (art pipeline), copy it in first. See `docs/recipes/pixel-art-pipeline.md`.
- **Start serial first.** Prove a clean single-task loop before trusting a parallel night.
