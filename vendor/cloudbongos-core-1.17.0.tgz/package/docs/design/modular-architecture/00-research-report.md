# Component-Based Development & Code Packaging for AI-Agent-Driven Development

**A research report for Cloud Bongos** · 2026-06-21 · feeds the modular-architecture work (builds on ADR 0080, 0062).

## 0. How to read this (provenance)

Produced by a deep-research harness (fan-out web search → fetch 27 sources → adversarial verification) plus a grounding pass over our repo and ADRs. The harness was **cut off by the org's monthly Claude spend limit** before its synthesis step, so claims carry one of three marks:

- **✅ Verified** — passed 3-vote (or 2-1) adversarial verification against a primary source.
- **📄 Sourced** — from a primary source the harness fetched, but its verification vote was lost to the budget cutoff. Cite with normal care.
- **🔧 Synthesis** — analysis / recommendation / mapping to our codebase.

## 1. Executive summary

The instinct behind this work is the industry direction — Cloud Bongos is catching up to (and in places ahead of) how mature systems and AI-first teams organize code. Three framing findings:

1. **The "package" is becoming the unit of everything** — not the file. Monorepo tooling, plugin systems, and AI-agent tooling all converge on a **manifest-defined package** as the unit of (a) dependency arrows, (b) boundary enforcement, (c) ownership, (d) **AI context scoping**, and (e) "what a change affects." ADR 0080's `modules/<key>/module.json` is exactly this unit.
2. **The biggest lever on AI code quality is scoping the agent to a package, not the repo** — and the clean way to drive that is to connect a task to the module(s) it may affect. The industry already tags work this way (Jira/Linear components, conventional-commit scopes, `nx affected`, CODEOWNERS).
3. **Re-skinning is a solved pattern**: design tokens → CSS variables injected at runtime + a logic-core/swappable-skin split + feature-section toggles. We already have the seeds (`branding.json` → CSS-var injection; `modules.json` → `window.__MODULES__`).

You do **not** need Nx/Turborepo/Bazel for a single-process no-bundler app — in-repo module directories + a manifest + the existing `fitness.js` is the right lightweight choice.

## 2. Thread 1 — Modular packaging & monorepo organization

Spectrum (cheapest → heaviest): logical modules-in-a-folder → in-repo module dirs + a manifest discovered at runtime → workspaces → orchestrated monorepo (Nx/Turborepo) → Bazel.

- 📄 **Turborepo defines a package as "any directory containing a `package.json`"** — the manifest is the minimal required unit that makes a package discoverable ([Turborepo docs](https://turborepo.dev/docs/crafting-your-repository/structuring-a-repository), ✅ 2-1). Canonical layout splits `apps/` from `packages/` (✅ 3-0).
- ✅ **Dependency arrows are derived mechanically from manifests + lockfile**, not hand-declared.

**Smallest viable package unit:** a directory + a manifest the tooling acts on. **A manifest is worth it the moment you need machine-discoverability, declared dependency arrows, or a contract a loader/fitness-function enforces.** ADR 0080's `module.json` passes this test.

🔧 Cloud Bongos is a single-package, single-process Node monolith and **should stay one** — the in-repo `modules/<key>/` + manifest + loader gives ~80% of "real packages" at ~20% of the cost.

## 3. Thread 2 — Module boundary enforcement (fitness functions)

The "boundary rots back together" problem is universal; the cure is **architecture fitness functions** run in CI.

- ✅ **Nx `@nx/enforce-module-boundaries`** enforces which projects may import which, at lint/CI time ([Nx docs](https://nx.dev/docs/technologies/eslint/eslint-plugin/guides/enforce-module-boundaries)). Constraints = project tags + `depConstraints` (`<redacted>`); one-way arrows via `notDependOnLibsWithTags` (all ✅ 3-0).
- ✅ **`eslint-plugin-boundaries`** is a pure ESLint plugin — **no bundler** — defining elements by path pattern + type, with a default-disallow baseline and asymmetric allow rules ([repo](https://github.com/javierbrea/eslint-plugin-boundaries), ✅ 3-0).
- 📄 Also: dependency-cruiser (JS/TS), import-linter (Python), ArchUnit / ts-arch.

🔧 Cloud Bongos already does this with `scripts/gds/fitness.js` (ADR 0062 §9 / 0061) — ahead of most teams. ADR 0080's proposed Checks 7–10 are textbook fitness functions. The semver'd published-core-API (`module-api.js`) is the standard way to make the one-way arrow usable.

## 4. Thread 3 — Plugin & extensibility architectures

| Pattern | Where it shows up | ADR 0080 analogue |
|---|---|---|
| Manifest + contribution points | VS Code `contributes` 📄; Backstage extension points 📄 | `module.json` `contributes` |
| Host composes the plugin | Fastify `register` ✅; Backstage host-owns-composition 📄 | loader mounts module routers behind auth |
| Encapsulation by default, opt-out | Fastify scope + `fastify-plugin` ✅ | loader hands a scoped, pre-gated router |
| Ports & adapters (hexagonal) | hexagonal arch 📄 | ADR 0079 tools-as-adapters; core/host |
| Compatibility ranges | Fastify version range ✅; VS Code `engines` 📄 | `coreVersion` + `bongos upgrade` |

- ✅ **Fastify enforces encapsulation by default** (`register` creates a new scope); a plugin opts out via `fastify-plugin`, which also declares the supported Fastify version range; the host+plugin graph is a DAG ([Fastify docs](https://fastify.dev/docs/latest/Reference/Plugins/), all ✅ 3-0).
- 📄 **VS Code**: declarative contribution points; extension-host process isolation for stability; host guarantees a responsive UI.
- 📄 **Backstage**: extension points owned by the host plugin; an ordering invariant means the host composes final behavior after all modules init.

**Feature flags vs feature modules** (🔧): flags toggle behavior within one codebase; feature modules are units of code that can be present/absent. `src/modules.js` is today a flag-style closed registry; ADR 0080 upgrades it to true feature modules.

### 4b. In-process plugin security

- 📄 **Backstage does NOT sandbox in-process plugins** — they share host privilege ([threat model](https://backstage.io/docs/overview/threat-model/)). VS Code isolates for *stability*, not security. 📄 **WordPress** privilege-escalation via plugins is a top vuln class ([Patchstack](https://patchstack.com/academy/wordpress/vulnerabilities/privilege-escalation/)) precisely because there's no composition-enforced authz floor.
- 🔧 The pattern for first-party plugins: trust for process safety, **enforce the boundary that matters (authz) by composition** — the host owns the mount and wraps every entry behind auth the plugin can't remove. ADR 0080 §3 is exactly this, and is *stronger* than Backstage (the route-rank fitness gate spans `modules/**/routes/`, so even a forgotten gate is a red build). Deferring true sandboxing is the standard call.

## 5. Thread 4 — Theming, white-labeling & re-skinning

- 📄 **Design tokens** (W3C DTCG format, `$value`/`$type`, first stable 2025.10) are the portable presentation layer ([W3C](https://www.w3.org/community/design-tokens/2025/10/28/design-tokens-specification-reaches-first-stable-version/); [format](https://www.designtokens.org/tr/drafts/format/)); **Style Dictionary** transforms them to CSS vars.
- 📄 **Headless/unstyled libraries** (Radix, Headless UI, React Aria, shadcn) = logic core + swappable skin. Generalizes: separate behavior/data from presentation so a re-skin is a token swap, not a logic edit.
- 📄 **Multi-brand / white-label SaaS**: one codebase, brand = config (token set + enabled features), runtime theme injection via CSS custom properties ([multi-brand SaaS](https://medium.com/@kodekx-solutions/<redacted>)).

🔧 Cloud Bongos has the seeds: `branding.json` theme tokens → CSS-var injection at boot (`themeMarkup`), `modules.json` → `window.__MODULES__` section toggles. Gaps: finish the ~90-site brand-string consolidation; unify the duplicated hall/status stylesheets onto one shared token set; keep all logic in the core API so a skin is a thin renderer. ADR 0079 (design-as-code, tools-as-adapters) is the right governance layer.

## 6. Thread 5 — Scoping AI agents to a package (the centerpiece)

- 📄 Bounded, relevant context → higher-quality output, fewer errors, lower token cost ([getbasis.ai](https://www.getbasis.ai/blogs/how-we-made-our-monorepo-ergonomic-for-agents), [tianpan.co](https://co.tianpan.co/blog/<redacted>), [Claude Code best practices](https://code.claude.com/docs/en/best-practices)).
- 📄 **Package-scoped nested context files** (AGENTS.md / nested CLAUDE.md / .cursor/rules) — [Datadog](https://dev.to/datadog-frontend-dev/<redacted>). Cloud Bongos already does this (nested CLAUDE.md, presence-enforced) — ahead.
- 📄 **Dependency-graph-scoped context** (`nx affected` / `turbo --filter`; [Nx AI agent skills](https://nx.dev/blog/nx-ai-agent-skills) exposes the project graph to agents).
- 📄 **Ticket↔component mapping is established**: Jira/Linear "Components", conventional-commit scopes, CODEOWNERS, `nx affected --files`.

🔧 **The synthesis:** `touches[]` is a file-path list (the lowest-altitude form). The industry moves the unit of affinity *up* from files to components/packages. Once modules are first-class, a task should declare **module affinity**; the agent loads only that module + the core API (small context, higher quality), parallel-safety becomes module-disjointness (cleaner than path overlap), and drift detection becomes semantic ("you said dev-box, you touched game"). *(Refined later: see [02](02-module-map.md)/[04](04-module-lifecycle.md) — in a fully modular world the file-path `touches[]` retires entirely in favor of the module label.)*

## 7. Thread 6 — How companies manage AI-assisted dev at scale

- 📄 Anthropic's multi-agent research system: orchestrator-worker, lead decomposes, subagents in parallel each with own context window ([Anthropic](https://www.anthropic.com/engineering/multi-agent-research-system)).
- 📄 [How Anthropic teams use Claude Code](https://claude.com/blog/how-anthropic-teams-use-claude-code); [Claude Code best practices](https://code.claude.com/docs/en/best-practices); [GitHub Copilot coding agent](https://docs.github.com/copilot/concepts/agents/coding-agent/about-coding-agent) (scoped to an issue, isolated env, PR review gate); [Nx AI agent skills](https://nx.dev/blog/nx-ai-agent-skills) (pair affected-graph with AI); [Macroscope](https://macroscope.com/content/ai-code-review-monorepos-complete-guide) (scope AI review to the affected graph).

🔧 Cloud Bongos already implements most of the at-scale playbook (MAS orchestrator-worker, nested context, adversarial grader, per-claim worktrees, claim model). The missing piece is the **<redacted>** step — which module-affinity adds.

## 8. Recommendations (incremental, lightweight-first)

1. Ship ADR 0080 (module manifest + loader + fitness boundary). `[convention + loader]`
2. **Task→module affinity** as the successor to `touches[]` (the centerpiece). `[convention + loader]`
3. Use module-affinity to scope agent context. `[convention + loader]`
4. Finish theming consolidation; unify the UIs' token set; logic stays in the core API. `[convention + loader]`
5. Per-module nested CLAUDE.md, presence-enforced. `[convention + loader]`
6. *(optional)* `eslint-plugin-boundaries` if import-graph checks outgrow `fitness.js`. `[convention + loader]`
7. *(not now)* Workspaces / Nx / Turborepo / Bazel — adds a build step for benefits you don't need as a single-process no-bundler app. `[heavyweight]`

## 9. Bibliography

**Verified primary (✅):** [Nx enforce-module-boundaries](https://nx.dev/docs/technologies/eslint/eslint-plugin/guides/enforce-module-boundaries) · [eslint-plugin-boundaries](https://github.com/javierbrea/eslint-plugin-boundaries) · [Turborepo structuring](https://turborepo.dev/docs/crafting-your-repository/structuring-a-repository) · [Fastify plugins](https://fastify.dev/docs/latest/Reference/Plugins/)

**Primary (📄, verification lost to budget cutoff):** [VS Code extensibility](https://vscode-docs.readthedocs.io/en/stable/extensions/our-approach/) · [Backstage extension points](https://backstage.io/docs/backend-system/architecture/extension-points/) · [Backstage threat model](https://backstage.io/docs/overview/threat-model/) · [W3C Design Tokens 2025.10](https://www.w3.org/community/design-tokens/2025/10/28/design-tokens-specification-reaches-first-stable-version/) · [DTCG format](https://www.designtokens.org/tr/drafts/format/) · [Anthropic multi-agent](https://www.anthropic.com/engineering/multi-agent-research-system) · [How Anthropic teams use Claude Code](https://claude.com/blog/how-anthropic-teams-use-claude-code) · [Claude Code best practices](https://code.claude.com/docs/en/best-practices) · [GitHub Copilot coding agent](https://docs.github.com/copilot/concepts/agents/coding-agent/about-coding-agent) · [Nx AI agent skills](https://nx.dev/blog/nx-ai-agent-skills)

**Secondary / blog:** [Datadog AGENTS.md](https://dev.to/datadog-frontend-dev/<redacted>) · [getbasis.ai](https://www.getbasis.ai/blogs/how-we-made-our-monorepo-ergonomic-for-agents) · [tianpan.co](https://co.tianpan.co/blog/<redacted>) · [monorepo.tools/ai](https://monorepo.tools/ai) · [Macroscope](https://macroscope.com/content/ai-code-review-monorepos-complete-guide) · [dependency-cruiser](https://dev.to/jacobandrewsky/<redacted>) · [hexagonal architecture](https://en.wikipedia.org/wiki/<redacted>(software)) · [Patchstack WordPress priv-esc](https://patchstack.com/academy/wordpress/vulnerabilities/privilege-escalation/) · [multi-brand SaaS](https://medium.com/@kodekx-solutions/<redacted>) · [white-label React](https://corecotechnologies.com/development/white-label-react-app/)

*Harness stats: 6 angles · 27 sources · 131 claims extracted · 25 verified (12 confirmed, 13 abstained at the budget cutoff).*
