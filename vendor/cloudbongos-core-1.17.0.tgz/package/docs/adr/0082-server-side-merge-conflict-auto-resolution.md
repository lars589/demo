# ADR 0082 — Server-side auto-resolution of generated-file & append-index merge conflicts

- **Status:** Accepted
- **Date:** 2026-06-21
- **Track:** internal
- **Builds on:** [ADR 0055](<redacted>.md) (server-mediated publish — the box holds no push credential; the server pushes), [ADR 0063](<redacted>.md) / [ADR 0066](<redacted>.md) / [ADR 0062](<redacted>.md) §8 (the generated artifacts + the `otb-regen` merge driver, task 1243), [ADR 0016](<redacted>.md) (trust boundary — this does NOT touch it)
- **Task:** [#1385](https://example.com/builders#/task/1385) (idea [#349](https://example.com/builders#/idea/349))

## Context

The active merge driver (task 1162, `github-push.mergeIfGreen`) lands a green PR the moment it is mergeable AND `CLEAN`, but bails on **any** conflict (`reason:'merge_conflict'`) and the publish-reconciler just moves on. Two conflict classes recur constantly in a multi-builder repo and are *not* genuine disagreements — they are mechanical collisions:

1. **Generated artifacts** — `docs/repo-map.md`, `docs/file-map.md`, `docs/session-log-index.md`, and the nested `CLAUDE.md` symbol blocks. Two parallel branches each regenerate them, so they conflict on nearly every merge. Task 1243 already solved this *locally* with the `otb-regen` git merge driver (`scripts/gds/git-merge-regen.js`), which regenerates them from the merged tree.
2. **The `docs/adr/README.md` append-index** — a hand-maintained table whose only recurring conflict is two branches each appending a new ADR row. There is no generator to rebuild it from, so `otb-regen` can't help it at all.

The gap: task 1243's machinery only runs in a **local** `git merge` (a builder's box, `/merge-mode`, ship's pre-stage). But the default ship path is **server-mediated** (ADR 0055) and lands via GitHub's own merge — and **GitHub's merge cannot run a custom merge driver** (`otb-regen`). So a confirmed PR that later conflicts only on these files sits open forever until a human with a credentialed checkout runs a local merge. This is the exact stall behind PR #300 and PR #167 (both on `docs/adr/README.md`).

The owner framed the goal as "kill the merge bottleneck" — and **explicitly rejected** the tempting alternative of lowering deploy/merge access down to the `thetes` rank. That would reopen the Builder 25 hole ([ADR 0043](<redacted>.md)): a lightly-trusted agent landing changes on a live prod payment system. The right fix changes *who does the mechanical work*, not *who is trusted to land code*.

## Decision

Two pieces, both reusing the task-1243 machinery rather than reinventing it:

**1. `.gitattributes` coverage.**
- `docs/adr/README.md merge=union` — the built-in `union` driver keeps both sides' appended rows, the correct resolution for an append list. `union` is core git (no per-clone registration) and is honored by every *local* merge.
- `docs/session-log-index.md merge=otb-regen` + adding it to `REGENERABLE` in `git-merge-regen.js` (a whole-file `renderIndex(collectEntries())`, like `docs/repo-map.md`) — so the generated session index self-heals everywhere the rest do.

**2. `src/bongos/conflict-resolve.js` — a server-side resolver** wired into the publish-reconciler. When a confirmed task's PR reports `merge_conflict`, it:
1. Clones the server's checkout into a throwaway temp dir (never the deploy worktree — mirrors `github-push.pushBundle`).
2. Registers the `otb-regen` driver in that clone (`install-git-hooks.registerMergeDriver`); `union` needs none.
3. Fetches fresh `origin/main` + the feature branch over the server's credentialed URL and checks out the branch.
4. Runs `git merge origin/main`. The driver resolves the generated files; `union` resolves the ADR index; **any genuine hand-written conflict leaves the merge non-zero**, and we `git merge --abort` and leave the PR untouched for a human.
5. On a fully-clean merge (asserted: no unmerged paths, no surviving `<<<<<<<`/`>>>>>>>` markers), pushes the resolved branch.

The PR's required checks (unit / trufflehog / audit / gate-review) re-run on the new head, and the next `mergeIfGreen` sweep lands it.

## Why this is safe — and never worse than today

- **It bypasses no gate.** It pushes a *commit*; it does not merge to `main`. Every required check re-runs before anything lands. It cannot bypass the grader, gate-review, or rank checks — and **zero change to the trust boundary** (the rejected `thetes` alternative).
- **It resolves only what the driver/union resolve.** A real hand-conflict aborts to a human; the resolver invents nothing (`git-merge-regen` already exits non-zero if any marker survives a regeneration).
- **Isolated + best-effort + kill-switchable.** It works in a temp clone (can't race `~/deploy.sh`), is wrapped best-effort in the reconciler (a failure is logged, never thrown), and is killable via `CONFLICT_RESOLVE_DISABLED=1`. If anything goes wrong the strand is simply left exactly as it is today.
- **No `--force`, ever.** A non-fast-forward push (someone moved the branch) fails safely; the next sweep retries against the new tip.

## Consequences

- Generated/index-only conflicts on the server path now self-heal within a reconciler sweep (~5 min) with no human and no credentialed checkout — the PR #300/[#167](https://example.com/builders#/task/167) class is closed going forward.
- The resolution push changes the PR head, so an SHA-pinned `gate-owner-approved` (ADR 0058) on a *gate-surface* PR would need re-approval. In practice these conflicts are on docs/index files (rarely gate-surface), so this is uncommon; when it happens, the behavior is the same one-click re-approval as any post-push change.
- `docs/adr/README.md` itself now carries `merge=union`, so this ADR's own index row — and every future one — stops conflicting.
- The generated-artifact set is defined once (`REGENERABLE` in `git-merge-regen.js`, mirrored by `.gitattributes` and the `fitness.js` freshness gate); adding a future generated file means adding it in those places together.

## Alternatives considered

- **Lower deploy/merge access to `thetes`** (the owner's first instinct) — rejected: reopens the Builder 25 hole for zero benefit here (the stranded session was already Archon; rank was never the blocker).
- **Rely on GitHub honoring `union`/custom drivers server-side** — GitHub does not run custom merge drivers, and `union` honoring is unreliable across GitHub's merge surface; doing the merge locally on the server makes the outcome deterministic regardless.
- **A `gen-adr-index.js` generator** so `otb-regen` could rebuild `docs/adr/README.md` — rejected for now: the index's `Track`/`Topic` columns are human-authored and not derivable from the ADR files, so `union` is the correct, cheap resolution for an append list.
