const express = require('express');
// Carved into modules/memory/ (BV1.R72 / ADR 0091 §2): auth + the shared request
// validators (validateOrRespond/LIMITS) via the doorway; the learnings lib is an
// intra-module require.
const api = require('../../../src/module-api');
const auth = api;
const learnings = require('../learnings');
const { validateOrRespond, LIMITS } = api;

module.exports = function buildLearningsRouter() {
  const router = express.Router();

  // rank: any-builder — read learnings (own + others').
  router.get('/learnings', auth.requireBuilder, async (req, res) => {
    const tagsRaw = req.query.tags;
    const touchesRaw = req.query.touches;
    // touches[] cleanup [3/8] (task 878): the preferred claim-time lookup keys
    // off the task's discipline + title (always present) rather than its
    // predicted touches[]. ?touches= is kept for back-compat.
    const disciplineRaw = req.query.discipline;
    const titleRaw = req.query.title;
    try {
      let rows;
      if (tagsRaw) {
        const tags = String(tagsRaw)
          .split(',')
          .map((s) => s.trim().toLowerCase())
          .filter(Boolean);
        rows = await learnings.findLearningsByTags(tags);
      } else if (disciplineRaw || titleRaw) {
        rows = await learnings.findLearningsForTask({
          discipline: disciplineRaw ? String(disciplineRaw) : null,
          title: titleRaw ? String(titleRaw) : null,
        });
      } else if (touchesRaw) {
        const touches = String(touchesRaw).split(',').map((s) => s.trim()).filter(Boolean);
        rows = await learnings.findLearningsForTouches(touches);
      } else {
        rows = await learnings.listAllLearnings();
      }
      res.json({ learnings: rows });
    } catch (err) {
      console.error('[gds] GET /learnings', err);
      res.fail('list_failed', { status: 500, message: 'internal error' });
    }
  });

  // rank: any-builder — capture a learning (own contribution).
  router.post('/learnings', auth.requireBuilder, async (req, res) => {
    if (validateOrRespond(req, res, {
      title: { required: true, type: 'string', maxLength: LIMITS.TITLE, minLength: 1 },
      body_md: { required: true, type: 'string', maxLength: LIMITS.DESCRIPTION, minLength: 1 },
      tags: { type: 'array', maxItems: 64, itemsType: 'string' },
      related_files: { type: 'array', maxItems: 256, itemsType: 'string' },
      source: { type: 'string', maxLength: LIMITS.SOURCE },
      source_ref: { type: 'string', maxLength: LIMITS.SOURCE_REF },
      task_id: { type: 'integer', min: 1 },
    })) return;
    const body = req.body || {};
    if (!body.title || !body.body_md) {
      return res.fail('title_and_body_md_required', 400);
    }
    try {
      const tags = Array.isArray(body.tags)
        ? body.tags.map((t) => String(t).toLowerCase())
        : [];
      const relatedFiles = Array.isArray(body.related_files) ? body.related_files : [];
      const out = await learnings.createLearning({
        title: body.title,
        bodyMd: body.body_md,
        tags,
        relatedFiles,
        capturedBy: req.builder.id,
        source: body.source ?? null,
        sourceRef: body.source_ref ?? null,
        taskId: body.task_id ?? null,
      });
      if (!out) {
        // ON CONFLICT skipped: same (source, source_ref) already captured.
        return res.status(200).json({ skipped: true, reason: 'duplicate_source_ref' });
      }
      res.status(201).json({ learning: out });
    } catch (err) {
      console.error('[gds] POST /learnings', err);
      res.fail('create_failed', { status: 500, message: 'internal error' });
    }
  });

  return router;
};
