# 0003 — Cloudflare proxy ON + Origin Certificate (replaces Let's Encrypt)

- **Status:** Accepted
- **Date:** 2026-05-08
- **Deciders:** Lars

## Context

Initial deploy used Caddy's built-in Let's Encrypt integration: Caddy handled HTTP-01 challenges directly with the public internet, obtained a 90-day cert, and auto-renewed.

After hello-world shipped, we turned on Cloudflare's reverse proxy (orange cloud) for caching, basic DDoS shielding, and edge TLS termination. With CF in front, port 80 is intercepted at the edge and Caddy can no longer complete HTTP-01 challenges — auto-renewal would silently fail and the site would go down at the 90-day mark.

We needed a TLS strategy that survives having Cloudflare in front of the origin.

## Decision

We will use a **Cloudflare Origin Certificate** for the CF↔origin leg of TLS, configured as an explicit `tls` directive in Caddyfile. Cloudflare's Universal SSL handles the browser-facing leg.

- **Cert:** Issued by `CloudFlare Origin SSL Certificate Authority`, hostnames `example.com, *.example.com`, valid through **2041-05-04 (15 years)**
- **Stored at:** `/etc/caddy/origin.crt` (mode 644) and `/etc/caddy/origin.key` (mode 640, owned by `root:caddy`)
- **Caddyfile** uses explicit `tls /etc/caddy/origin.crt /etc/caddy/origin.key` — no Let's Encrypt automation
- **Cloudflare SSL/TLS mode** set to **Full (strict)**

## Alternatives considered

- **Keep Let's Encrypt + DNS-01 challenge.** Workable but requires giving Caddy Cloudflare API access and managing the credentials. More moving parts, same result, shorter cert lifetime (90 days, auto-renewed).
- **Turn off Cloudflare proxy.** Loses caching and DDoS shielding. Net negative.
- **Cloudflare Flexible SSL (CF-only TLS, plain HTTP to origin).** Bad. Origin traffic is unencrypted and easily MITM'd at any hop after CF. Rejected on principle.

## Consequences

- **Renewal is a non-issue for ~15 years.** No auto-renewal cron, no certbot daemon, no monitoring on cert expiry until 2040ish.
- **Cloudflare is now load-bearing** — if Cloudflare goes down or terminates the origin cert, the site breaks. Acceptable trade-off for a free-tier service.
- **Real client IPs are now hidden behind Cloudflare** — Caddy sees CF IPs in `req.RemoteAddr`. Logged as a follow-up in the architecture notes: when we need real IPs (rate limiting, abuse detection), wire `trusted_proxies cloudflare` into the Caddyfile to honor `X-Forwarded-For` / `CF-Connecting-IP`.
- **Regenerating the cert** if ever needed: Cloudflare dashboard → SSL/TLS → Origin Server.
