# ADR 0025 — Offsite backup vendor: DigitalOcean Spaces

**Date:** 2026-05-30
**Context:** Task [#415](https://example.com/builders#/task/415) (V3.R62-offsite), claim `#338`, GDS-V3 criterion C8 ("memory is local-first, server-canonical on ship" — which depends on the GDS DB surviving whole-droplet loss). Companion to the local nightly backup filed by [#412](https://example.com/builders#/task/412) (V3.R62-precondition, [`docs/recipes/gds-db-backup.md`](../recipes/gds-db-backup.md)) and the secrets policy in [ADR 0022](0022-secrets-policy.md). Sits under [ADR 0024 §5](<redacted>.md) (backup cadence).
**Status:** Accepted.

## Problem

The local nightly `pg_dump` ([#412](https://example.com/builders#/task/412)) writes gzipped dumps to `/var/backups/gds/` — on the **same physical disk** (`/dev/vda1`) as the live database. That protects against the likely failures (bad migration, accidental `DROP`, schema corruption, an LLM writing a row it shouldn't) but **not** whole-droplet loss: provider failure, accidental droplet termination, or disk destruction takes the dumps with the database.

C8 makes builder memory server-canonical on ship — so the GDS DB is now the single home for every builder's synced memory, not just work-tracking state. Losing it loses that too. We need a copy that lives somewhere the droplet's disk dying cannot reach.

We must pick an off-droplet storage target. The budget posture (CLAUDE.md §4) is "cheapest viable; document the trade-off in an ADR when the more expensive option is chosen." We chose the more expensive option, so this ADR records why.

## Options considered

| Option | Cost | Notes |
|---|---|---|
| **Backblaze B2** | ~$0/mo at our volume (10 GB free; dumps are sub-1 MB) | Cheapest. Separate vendor, separate account, separate billing, separate credential lifecycle. S3-compatible API. |
| **DigitalOcean Spaces** ✅ | $5/mo flat (250 GB + 1 TB transfer included) | Same vendor as the droplet — one console, one bill, one support relationship, one place to reason about region/latency. S3-compatible API. |
| AWS S3 | ~$0 at our size but per-request + egress pricing | Third vendor, IAM complexity, surprise-bill risk. Rejected. |

## Decision

**Use DigitalOcean Spaces, in the NYC3 region** (same region as the droplet).

Rationale for accepting the $5/mo over B2's ~$0:

1. **One vendor.** The droplet, DNS-adjacent infra, and now backups all live in one DigitalOcean account. A non-software-engineer operator (the prompter — CLAUDE.md §2) manages one console and one bill, not two. The operational simplicity is worth $60/year on a $5,000 project budget.
2. **Same region as the droplet (NYC3).** Lowest-latency upload path; no cross-provider egress to reason about.
3. **Flat, predictable price.** $5/mo with generous included transfer — no per-request or surprise-egress billing to monitor. Predictability matters more than absolute floor at this scale.
4. **The scaffolding already pointed here.** The retired task-[#7](https://example.com/builders#/task/7) backup (see below) was already written against the `SPACES_*` env shape, so DO Spaces is the lowest-friction path to a *working* offsite copy.

B2 remains the obvious fallback if the $5/mo ever needs trimming — the uploader is plain S3 (`boto3` + `endpoint_url`), so re-pointing it at B2 is a credentials + endpoint change, nothing structural.

## What this replaces — the retired [#7](https://example.com/builders#/task/7) backup

A previous task ([#7](https://example.com/builders#/task/7), V1 era) shipped `scripts/backup.sh` + `/etc/cron.d/otb-backup`: a daily `pg_dump → DO Spaces` cron. By the time [#412](https://example.com/builders#/task/412)/[#415](https://example.com/builders#/task/415) were planned it had been **forgotten** — which is why [#415](https://example.com/builders#/task/415) was filed "vendor TBD." On inspection (2026-05-30) it was **deployed but dead**: `~/.config/otb/spaces.env` held all-empty credentials, no Space was ever created, and `/var/log/otb-backup.log` did not exist (it had never successfully run).

Rather than leave two competing, half-broken backup systems, [#415](https://example.com/builders#/task/415) **retires** the [#7](https://example.com/builders#/task/7) setup and replaces it with one clean story:

- **Local daily** — `gds-db-backup.timer` ([#412](https://example.com/builders#/task/412)), `pg_dump` → `/var/backups/gds/`, 30-day retention.
- **Offsite weekly** — `gds-db-offsite.timer` ([#415](https://example.com/builders#/task/415)), copies the *latest existing* local dump → DO Spaces, 4-week retention. It does **not** take its own `pg_dump`; it archives what [#412](https://example.com/builders#/task/412) already produced.

Removed by [#415](https://example.com/builders#/task/415): `scripts/backup.sh`, `infra/backup/otb-backup.cron`, the droplet's `/etc/cron.d/otb-backup`, and the empty `~/.config/otb/spaces.env` stub.

## Mechanics

- **Credentials** live at `/etc/example/spaces.env` (chmod 600, owned by `lars`), never in the repo — per [ADR 0022](0022-secrets-policy.md). Vars: `SPACES_KEY`, `SPACES_SECRET`, `SPACES_BUCKET`, `SPACES_REGION`, `SPACES_ENDPOINT`. systemd injects them via `EnvironmentFile`; manual runs source the same file.
- **Cadence:** Sunday 05:00 UTC, one hour after the 04:00 UTC local dump, so the offsite copy is always same-day-fresh.
- **Retention:** 4 weekly copies in the Space (`GDS_OFFSITE_KEEP=4`), pruned oldest-first under the `gds-offsite/` key prefix. ~1 month of offsite snapshots. Sub-1 MB each, so storage is a rounding error against the 250 GB tier.
- **Restore drill:** quarterly download-and-restore from the Space, documented in [`docs/recipes/gds-db-backup.md`](../recipes/gds-db-backup.md).

## Consequences

- **+$5/mo** recurring (~$60/yr) against the project budget. Acceptable and documented.
- Whole-droplet loss now costs at most ~1 week of writes (last weekly offsite copy), down from "everything." Combined with the daily local dump, the day-to-day exposure is still ≤24h.
- One credential to rotate (the Spaces key) per [ADR 0022](0022-secrets-policy.md) rotation procedure.
- A second vendor relationship is avoided; if cost pressure appears later, re-pointing the uploader at Backblaze B2 is a config change, not a rewrite.
