-- 067_builder_boxes.sql — #598 (ADR 0031 §2 / §5): per-builder cloud dev box lifecycle.
--
-- Context
-- -------
-- ADR 0031 decided the worker (the part of Claude Code that opens files and
-- runs commands) lives on an org-controlled, containerized DigitalOcean box —
-- ONE per builder (§2). #596 shipped the box-as-code (.devcontainer/). This
-- migration is the STATE LEDGER for the box LIFECYCLE that #598 builds on top:
-- provision → run → auto-suspend when idle → reclaim when dormant.
--
-- Why a DB table and not just DO's own droplet list: the GDS is the project's
-- complete ledger (CLAUDE.md hard rule). The lifecycle sweeps (idle-suspend,
-- dormant-reclaim) need a builder→box mapping, an activity heartbeat, and a
-- per-builder compute-cost tally that DO's API does not give us. DO holds the
-- live droplet; this table holds the lifecycle truth we reason over.
--
-- §9.3 resolution (recorded in ADR 0031): auto-suspend is SNAPSHOT-AND-PARK,
-- not a Coder control-plane. DO has no native suspend and a *powered-off*
-- droplet still bills, so "park" snapshots then DESTROYS the droplet (keeping
-- only the cheap snapshot, ~$0.30/mo) and "wake" recreates from the snapshot.
-- That is why `droplet_id`/`ip` are NULLable (gone while parked) but
-- `snapshot_id` persists across a park.
--
-- Idempotent: safe to re-run.

-- ---------------------------------------------------------------------------
-- builder_boxes — one row per builder, the lifecycle state of their box.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS builder_boxes (
  id               bigserial PRIMARY KEY,
  -- One box per builder (ADR 0031 §2: a shared box collides on files/ports/DB).
  builder_id       bigint NOT NULL UNIQUE REFERENCES builders(id) ON DELETE CASCADE,

  -- Lifecycle state machine (mirrored in src/bongos/boxes.js BOX_STATES):
  --   none        — no box yet (default; a row may exist pre-provision)
  --   provisioning— create-droplet in flight
  --   active       — droplet running, billing compute
  --   parking      — snapshot+destroy in flight
  --   parked       — droplet destroyed, only the snapshot remains (cheap)
  --   waking       — recreate-from-snapshot in flight
  --   destroyed    — fully de-provisioned (droplet + snapshot gone). The
  --                  dormant-reclaim sweep moves a long-parked box straight here.
  --   error        — a lifecycle op failed; needs operator attention
  state            text NOT NULL DEFAULT 'none'
    CHECK (state IN ('none','provisioning','active','parking','parked',
                     'waking','destroyed','error')),

  -- Source-access scope recorded at provision time. CONSUMED by #600 (rank-gated
  -- source access): 'starter' = a Xenos's scoped surface (art/docs/good-first),
  -- 'full' = a Metic+'s full private-repo credential. #598 records it; #600
  -- enforces what the box's GitHub credential can actually reach.
  scope            text NOT NULL DEFAULT 'starter'
    CHECK (scope IN ('starter','full')),
  -- The live rank the builder held when the box was provisioned (audit + #600).
  provisioned_rank text,

  -- DigitalOcean handles. droplet_id/ip are NULL while parked (droplet gone);
  -- snapshot_id is the durable residual that a wake restores from.
  droplet_id       text,
  droplet_name     text,
  snapshot_id      text,
  region           text NOT NULL DEFAULT 'nyc3',
  size_slug        text NOT NULL DEFAULT 's-2vcpu-4gb',
  ip               text,
  -- Stable per-builder DNS (e.g. box-<login>.dev.amazonprimea.com). The droplet
  -- IP churns on every wake; the hostname is what #599's Desktop managed-settings
  -- pin to. #598 records it + exposes a DNS hook; #599 owns the cutover.
  hostname         text,

  -- Activity + lifecycle timestamps.
  last_activity_at timestamptz, -- bumped by POST /box/heartbeat; drives idle sweep
  provisioned_at   timestamptz, -- first ever provision
  active_since     timestamptz, -- when the CURRENT live droplet started billing
  parked_at        timestamptz, -- when it last entered 'parked' (drives dormant sweep)
  destroyed_at     timestamptz,

  -- Running tally of compute cost charged to this box (USD). Accrued at park /
  -- deprovision as (active hours × size hourly rate); also mirrored to cost_log
  -- (category 'compute', builder-attributed) so the status dashboard sees it.
  compute_cost_usd numeric(10,4) NOT NULL DEFAULT 0,

  error_note       text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

-- Both sweeps select by state (listBoxes: WHERE state = $1) and then refine by
-- recency in memory (selectIdleBoxes / selectDormantBoxes), so a single index on
-- `state` serves every read path. Partial indexes on last_activity_at/parked_at
-- were deliberately NOT added: they would add write overhead on the hot heartbeat
-- UPDATE (which touches last_activity_at every ~5 min per active box) without
-- accelerating any query. If filtering ever moves into SQL at scale, add the
-- matching index in that same migration.
CREATE INDEX IF NOT EXISTS idx_builder_boxes_state ON builder_boxes (state);

-- ---------------------------------------------------------------------------
-- box_events — append-only lifecycle ledger. Direct infra mutations (CLI/sweep)
-- are project state changes too, so they get an audit row (CLAUDE.md hard rule).
-- The HTTP audit_log only captures API mutations; lifecycle ops run on the
-- control-plane CLI, so they record here.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS box_events (
  id          bigserial PRIMARY KEY,
  box_id      bigint NOT NULL REFERENCES builder_boxes(id) ON DELETE CASCADE,
  builder_id  bigint REFERENCES builders(id) ON DELETE SET NULL,
  -- provision | park | wake | deprovision | heartbeat | cost | error
  event       text NOT NULL,
  detail      text,
  cost_usd    numeric(10,4),
  -- Who/what triggered it: 'cli:<login>' | 'sweep:idle' | 'sweep:dormant' | 'api'
  actor       text,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_box_events_box ON box_events (box_id, created_at DESC);

INSERT INTO schema_migrations (version) VALUES ('067_builder_boxes')
  ON CONFLICT (version) DO NOTHING;
