# 0101 — Goal hierarchy Phase 5: relevance judge, sub-Metic membership in protected-scope goals, and the goal-reward model

- **Status:** Accepted (design + security review recorded; the build is a task cluster, filed backlog under BONGOS-V1). Two sub-decisions are explicitly **owner-gated at build time** — see Parts 2 and 3.
- **Date:** 2026-07-01
- **Deciders:** Lars (Archon), Claude

**Builds on:** [ADR 0086](<redacted>.md) (the goal hierarchy — this is its deferred Phase 5), [ADR 0043](<redacted>.md) (the protected-path hard floor this amends), [ADR 0016](<redacted>.md) (server-enforced permissions), [ADR 0084](<redacted>.md) (auto-derived rank floor), [ADR 0024](<redacted>.md) (the grader subagent harness the judge reuses), [ADR 0058](<redacted>.md) (gate-review + owner approval), [ADR 0054](<redacted>.md) (per-task cost-plus reward), [ADR 0023](<redacted>.md) (credit multipliers), [ADR 0027](<redacted>.md) (BFG contribution signals).

**Track:** `internal` (GDS / methodology — a Cloud Bongos platform capability).

---

## Context

[ADR 0086](<redacted>.md) shipped the goal-scoped work hierarchy — Phases 1–4 (BV1.R54–R64): the module-scope map, the configurable hierarchy preset, the `goals` tier, the bounded task-authoring gate (`POST /goals/:id/tasks`), the polymorphic dependency edge, and the criterion-auto-flag → `/goal-review` → goal-auto-achieve lifecycle. Those phases are **live and defended**: a member's authoring is bounded by the deterministic scope-subset wall, the protected-path block (the single [ADR 0043](<redacted>.md) roster), and the auto-derived rank floor ([ADR 0084](<redacted>.md)), with the ship-time gates authoritative on the real diff (BV1.R61 pins + abuse matrix).

ADR 0086 **explicitly deferred three non-decisions** to "its own security-reviewed ADR," because each is a matter of *judgment* or a *widening of the trust boundary* rather than the deterministic wall that shipped first. This is that ADR. It records the design and the security review; the build is a future cluster (filed below). It changes **no enforcement code**.

The three deferred items:

1. **An AI relevance / anti-hack judge** at goal-task create/claim time — advisory-first, never hard-blocking a newcomer.
2. **Sub-Metic membership inside protected-scope goals** — which amends the [ADR 0043](<redacted>.md) hard floor and requires the ship-time gates to become goal-aware.
3. **The goal-reward model** — does *achieving a goal* earn anything beyond the per-task cost-plus already paid, and how does any reward split among a goal's members.

---

## Decision

We adopt a three-part design. Each part is an independent, revertible build task. The security-sensitive boundary-widening (Part 2) ships **last**, behind the advisory judge (Part 1) and an explicit owner Gate sign-off + red-team pass.

### Part 1 — The relevance / anti-hack judge (advisory-first)

**What.** At goal-task **create** (`POST /goals/:id/tasks`) and, optionally, at **claim**, an AI judge assesses: *is this task genuinely in service of the goal, or is it scope-gaming / a hack attempt that slipped the deterministic gate?* (e.g. a task whose declared `touches[]` sit inside scope but whose title/description reveal an intent to weaken the very wall that admitted it).

**How.** Reuse the existing grader subagent harness ([ADR 0024](<redacted>.md) — the adversarial worker panel + `cascade-dispatch`), NOT a new harness. Cheapest model first (the cascade ceiling), escalate only on ambiguity; budget-aware (the $5k constraint).

**Advisory-first — the load-bearing rule.** The judge **flags for a Metic to review**; it **never hard-blocks a newcomer at create time**. The deterministic scope-subset + protected-path + auto-rank-floor gates remain the **only hard walls**. The judge is a soft, human-escalated signal that surfaces in a review queue mirroring the `/goal-review` / `/idea-triage` cadence. High-confidence or repeat gaming may *raise friction* (e.g. require a Metic co-sign before the authored task becomes claimable) but never a silent, opaque AI "no."

**Why advisory, not blocking.** An LLM judge is fallible; hard-blocking on it would (a) re-introduce the delegation bottleneck ADR 0086 exists to remove, and (b) create a gaming/DoS surface (adversarial prompts crafted to trip or exhaust the judge). Keeping it advisory means a wrong judge call costs a review, never a builder's ability to work.

### Part 2 — Sub-Metic membership in protected-scope goals (amends ADR 0043)

**Today (the conservative default that stays until this ships).** A protected-scope goal requires a **Metic+** holder ([ADR 0086](<redacted>.md) Deferred); a sub-Metic cannot author/claim/ship work touching the protected core even inside a goal — the [ADR 0043](<redacted>.md) hard floor blocks it at the pre-push hook, the grader `permissionPathPrePass`, the `gate-review` ESCALATE floor, and the post-push `main-audit`.

**The amendment.** An **Archon** may admit a sub-Metic to a protected-scope goal under a **tightly-scoped, Archon-granted membership**, letting them author + claim + ship work touching a **narrow, explicitly-enumerated** protected surface — but **only with the ship-time gates made goal-aware**.

**Security review (the crux).** The amendment is a genuine **widening of the trust boundary**, so it is purely *additive* permission, fail-closed, gated on an explicit grant:

- **Goal-aware ship-time gates.** A sub-Metic diff touching a protected path is allowed **only if** all hold, checked server-side against the **real committed diff** (not the advisory create-time `touches[]`): (a) the author is a **member** of a protected-scope goal, (b) the membership was **Archon-granted** and audit-logged, and (c) every protected path the diff touches is **within that goal's enumerated protected scope**. Any protected-path hit **outside** a live matching grant → the ADR-0043 floor bites unchanged.
- **Never self-granted.** Protected scope is Archon-set at goal creation ([ADR 0086](<redacted>.md) §4); membership admission to a protected-scope goal is the Archon-only `POST /goals/:id/members`. The sub-Metic can *ask*, never grant.
- **Blast-radius containment.** The member can touch only the goal's enumerated protected paths; the grader, `gate-review`, and `main-audit` still run on the real diff; the Archon can revoke membership; the Part-1 relevance judge watches for gaming; the `main-audit` flags any sub-Metic protected-path commit **not** covered by a live goal grant.
- **Ships last, gated.** This is the highest-risk change. Its build task carries an explicit **owner Gate approval** ([ADR 0058](<redacted>.md)) and a **red-team pass** before merge.

### Part 3 — The goal-reward model

**Question.** Does *achieving* a goal earn anything beyond the per-task cost-plus already paid ([ADR 0054](<redacted>.md)), and how does any reward split among members?

**Leaning (recorded; the money is owner-gated).**

- **Karma by default, not drachmae.** Drachmae are real money (1 = $1) against a tight $5k budget, and a goal is a *coordination construct*, not a unit of billable work — the per-task cost-plus already pays for the actual shipping. A goal-achievement **karma** bonus recognizes the collaboration with **no new monetary spend**.
- **Contribution-weighted, not membership-flat.** The bonus tracks **who actually shipped tasks under the goal** (reuse the shipped-task/credit attribution + the BFG contribution signals, [ADR 0027](<redacted>.md)), never mere membership — a flat per-member reward would incentivize goal-squatting. A `lead` may take a small coordination share.
- **On achievement, not creation.** The reward attaches when a goal is **achieved** (all criteria satisfied + confirmed via `/goal-review`), never on creation or joining — which, with contribution-weighting and the Metic confirmation, closes the free-rider and squatting surfaces.

**Owner-gated.** Whether *any* monetary (drachmae) component attaches, and the exact karma amount/curve, is **Lars's call at build time** — money is owner authority. This ADR records the budget-safe default (karma-only, contribution-weighted); the build task (P5.3) surfaces the money decision explicitly rather than presuming it.

### The child task list (filed backlog under BONGOS-V1, `source_ref` = this ADR)

- **P5.1 — Relevance/anti-hack judge (advisory-first).** Reuse the grader harness at goal-task create/claim; flag → Metic review queue; never hard-blocks; budget-aware cascade. *(Metic.)*
- **P5.2 — Goal-aware ship-time gates + the ADR-0043 amendment.** Sub-Metic membership in protected-scope goals under an Archon grant; make the pre-push hook / grader pre-pass / `gate-review` / `main-audit` goal-aware on the real diff; fail-closed; red-team + owner Gate sign-off. *(Archon; sequence after P5.1 so the advisory signal exists.)*
- **P5.3 — Goal-reward model.** Karma-default, contribution-weighted split on goal achievement; anti-gaming; the monetary decision surfaced to the owner. *(Metic; after the goal-achievement flow, BV1.R63.)*

---

## Alternatives considered

- **A hard-blocking relevance judge — rejected.** A fallible LLM as a hard gate re-introduces the bottleneck ADR 0086 removed and creates a gaming/DoS surface; the deterministic gates are the hard wall, the judge is a soft signal.
- **Keep protected-scope Metic+-only forever — rejected as the long-term posture** (it caps the maneuverability grant's reach), but it **is** the safe default that stays in force until P5.2 ships with its security review.
- **Flat per-member goal reward — rejected.** It incentivizes goal-squatting; contribution-weighting is fairer and anti-gaming.
- **A drachmae goal bonus by default — rejected as the default** (real money, tight budget); left as an explicit owner-gated option, not presumed.
- **Fold Phase 5 into Phase 4 rather than its own ADR — rejected** (ADR 0086 already decided this): the boundary-widening warrants a standalone security review, which is this document.

---

## Consequences

**Positive.** Completes the goal hierarchy's *judgment* and *reward* story: a soft relevance signal catches gaming the deterministic wall can't see; a newcomer can eventually touch a narrow protected surface under an explicit, revocable, audited Archon grant; and collaboration is recognized without mandatory monetary spend.

**Negative / cost.** Part 2 is a real widening of the trust boundary — the reason it ships last, fail-closed, red-teamed, and owner-approved. The judge adds LLM cost (mitigated: advisory, cheapest-model-first, budget-aware). The reward model adds accounting on goal achievement.

**Neutral.** The monetary-reward specifics and the exact karma curve stay owner-gated; the build is a future cluster (P5.1–P5.3), each part independently shippable and revertible; until they land, behavior is the conservative Phase-1–4 default (no goal bonus; protected-scope goals require a Metic+ holder; no AI judge in the loop).
