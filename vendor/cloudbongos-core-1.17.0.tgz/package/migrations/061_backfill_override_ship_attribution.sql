-- 061_backfill_override_ship_attribution.sql — fix #538 misattribution (2026-06-02).
--
-- Before #538, decideOverrideRequest set tasks.shipped_by = COALESCE(shipped_by,
-- archonId) when an Archon APPROVED a grader-false-negative override, so the SHIP
-- was attributed to the approving Archon (driving the builders' hall + peer-vote
-- feed) instead of the builder who actually did the work — even though the CREDIT
-- was routed to the requester correctly. The code is fixed; this backfills the
-- rows the old code already mis-stamped.
--
-- Re-point shipped_by to the original requester for every task that an APPROVED
-- override left attributed to its approving Archon. Idempotent: once
-- shipped_by = requester (which is DISTINCT FROM the decider) the WHERE no longer
-- matches, so re-running is a no-op.
--
-- Known instance at write time: task #477 (fisher NPC, LarsCode #3), already
-- corrected by hand on prod under the #538 claim. This migration makes that
-- correction reproducible in every environment (staging, restored backups) and
-- auditable in the diff — addressing the grader's blocker that the backfill was
-- otherwise invisible outside a side-channel psql command.

UPDATE tasks t
   SET shipped_by = r.requested_by_builder_id,
       updated_at = now()
  FROM task_override_requests r
 WHERE r.task_id = t.id
   AND r.status = 'approved'
   AND r.requested_by_builder_id IS NOT NULL
   AND t.shipped_by = r.decided_by_builder_id
   AND t.shipped_by IS DISTINCT FROM r.requested_by_builder_id;
