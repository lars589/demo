-- 187_goal_sort_order.sql — per-version goal priority (task 1760).
--
-- goals is a CORE-owned table (created before the module system, ADR 0083
-- §Decision #5 — a module migration may only touch its OWN <key>_-namespaced
-- objects, so this schema change lives in core migrations/, not
-- modules/lifecycle/migrations/, even though the query layer is lifecycle's).
--
-- sort_order is the OWNER'S priority ordering WITHIN a version — distinct
-- from goal.status (lifecycle) and goal.created_at (creation history).
-- Backfill assigns each existing goal its current (version_id, created_at, id)
-- rank so the visible order does not jump the moment this migration lands; a
-- fresh instance with zero goals is a no-op.

BEGIN;

ALTER TABLE goals
  ADD COLUMN IF NOT EXISTS sort_order integer NOT NULL DEFAULT 0;

WITH ranked AS (
  SELECT id, row_number() OVER (PARTITION BY version_id ORDER BY created_at, id) - 1 AS rn
  FROM goals
)
UPDATE goals g
   SET sort_order = ranked.rn
  FROM ranked
 WHERE g.id = ranked.id
   AND g.sort_order = 0
   AND ranked.rn <> 0;

COMMIT;
