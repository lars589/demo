// modules/lifecycle/goal-conflicts.js — the PURE goal task-conflict detector
// (task 1736). Server-side replacement for the hall Goals page's client-side
// exact-string overlap approximation: glob-aware touches[] intersection via the
// ONE canonical prefix-aware matcher (path-match.js, task 880 — reached through
// the published doorway), active-claim severity, and cross-goal overlaps
// against other open goals sharing scope_modules.
//
// Pure on purpose (the goal-scope-check precedent): the route fetches tasks /
// claims / sibling goals and calls computeGoalConflicts; every branch is pinned
// by a DB-free unit test (tests/goal_conflicts.mjs).
//
// Conflict = two OPEN tasks (not completed/confirmed/shipped/abandoned) whose
// DECLARED touches[] overlap. Declared touches are ADVISORY (ADR 0049 — git
// merge is the authoritative collision detector at land time); this detector is
// the PLANNING-time view a goal owner/manager resolves conflicts from, so pairs
// carry the overlap paths + a claim-aware severity, not a verdict.

const api = require('../../src/module-api');
const { matchOne } = api.pathMatch;

// Terminal statuses — a task here can no longer collide (its diff has landed,
// is landing, or never will). Mirrors the hall page's DONE_STATUSES + abandoned.
const RESOLVED_STATUSES = new Set(['completed', 'confirmed', 'shipped', 'abandoned']);

// A task participates in conflict detection only if it is open AND declares a
// blast radius. No touches → nothing to intersect (the client-side
// approximation skips these too; R60 goal-authored tasks always declare).
function isOpenWithTouches(t) {
  return t && !RESOLVED_STATUSES.has(t.status)
    && Array.isArray(t.touches) && t.touches.length > 0;
}

// Normalize one touches[] entry for the prefix matcher: tolerate the glob tail
// convention ('src/bongos/*', 'modules/hall-ui/**') by trimming it to the
// directory prefix matchOne already understands. Deeper glob syntax is not in
// the touches vocabulary (path-match.js is the canonical matcher, and it is
// prefix-based); an entry that trims to nothing is skipped.
function normalizeEntry(e) {
  return String(e || '').trim().replace(/\/?\*+$/, '');
}

// The overlapping entries between two touches[] sets — the pairwise application
// of matchOne in both directions, keeping the MORE SPECIFIC side of each hit
// (matches what the hall renders: 'src/bongos/db.js', not the 'src/bongos/' that
// covers it). Returns a deduped, sorted list.
function overlappingPaths(a, b) {
  const hits = new Set();
  for (const rawA of a || []) {
    const na = normalizeEntry(rawA);
    if (!na) continue;
    for (const rawB of b || []) {
      const nb = normalizeEntry(rawB);
      if (!nb) continue;
      if (matchOne(nb, [na])) hits.add(nb);        // na covers nb → nb is more specific (or equal)
      else if (matchOne(na, [nb])) hits.add(na);   // nb covers na → na is more specific
    }
  }
  return [...hits].sort();
}

// Claim-aware severity: two colliding tasks BOTH actively claimed are colliding
// right now ('high'); one claimed means new work would land under someone's
// feet ('medium'); neither claimed is a planning-time heads-up ('low').
function severityFor(aClaimed, bClaimed) {
  if (aClaimed && bClaimed) return 'high';
  if (aClaimed || bClaimed) return 'medium';
  return 'low';
}

const SEVERITY_ORDER = { high: 0, medium: 1, low: 2 };

// computeGoalConflicts — the detector.
//   goalTasks:          this goal's tasks (any status; filtered here)
//   activeClaimTaskIds: Set of task ids (any type; compared as strings) holding
//                       an active claim (claims.released_at IS NULL)
//   crossGoal:          [{ goal: {id,title}, tasks: [...] }] — other OPEN goals
//                       sharing scope_modules, whose open tasks are checked
//                       against THIS goal's open tasks (never against each other
//                       — those pairs belong to that goal's own conflict view)
// Returns pairs sorted most-severe first:
//   { task_a, task_b, title_a, title_b, overlapping_paths, severity,
//     has_active_claims, cross_goal, goal_b?, goal_b_title? }
function computeGoalConflicts({ goalTasks = [], activeClaimTaskIds = new Set(), crossGoal = [] } = {}) {
  const open = goalTasks.filter(isOpenWithTouches);
  const claimed = (t) => activeClaimTaskIds.has(String(t.id));
  const pair = (a, b, paths, extra) => ({
    task_a: Number(a.id),
    task_b: Number(b.id),
    title_a: a.title || '',
    title_b: b.title || '',
    overlapping_paths: paths,
    severity: severityFor(claimed(a), claimed(b)),
    has_active_claims: claimed(a) || claimed(b),
    cross_goal: false,
    ...extra,
  });

  const out = [];
  for (let i = 0; i < open.length; i++) {
    for (let j = i + 1; j < open.length; j++) {
      const paths = overlappingPaths(open[i].touches, open[j].touches);
      if (paths.length) out.push(pair(open[i], open[j], paths));
    }
  }
  for (const { goal, tasks } of crossGoal) {
    const others = (tasks || []).filter(isOpenWithTouches);
    for (const a of open) {
      for (const b of others) {
        const paths = overlappingPaths(a.touches, b.touches);
        if (paths.length) {
          out.push(pair(a, b, paths, {
            cross_goal: true,
            goal_b: Number(goal.id),
            goal_b_title: goal.title || '',
          }));
        }
      }
    }
  }
  out.sort((x, y) =>
    SEVERITY_ORDER[x.severity] - SEVERITY_ORDER[y.severity]
    || x.task_a - y.task_a || x.task_b - y.task_b);
  return out;
}

module.exports = {
  RESOLVED_STATUSES,
  isOpenWithTouches,
  normalizeEntry,
  overlappingPaths,
  severityFor,
  computeGoalConflicts,
};
