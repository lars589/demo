# ADR 0059 — Single approval: remove the dev-box (first-box) Archon approval gate

- **Status:** Accepted
- **Date:** 2026-06-16
- **Track:** internal
- **Supersedes:** [ADR 0035](<redacted>.md) §2 (the first-box Archon approval gate, [#717](https://example.com/builders#/task/717) / migration 071) and the **box half** of [ADR 0057](<redacted>.md) (the `#box-approvals` channel + the box-intent approve/deny wiring)
- **Builds on:** [ADR 0050](<redacted>.md) (invite-gated admission), [ADR 0031](<redacted>.md) (cloud dev boxes + the box provisioning rank floor), [ADR 0016](<redacted>.md) (server-enforced permissions)
- **Task:** 1141

## Context

A builder hit **two** human gates between "I heard about this" and "I'm shipping from a dev box":

1. **Member-join admission** ([ADR 0050](<redacted>.md)). A stranger submits their GitHub username → an `access_requests` row lands `pending` → an Archon invites or dismisses it (the hall Watch, or the `#member-approvals` Discord 👍/👎 from [ADR 0057](<redacted>.md)). This is the **admission** gate: it decides who is allowed into the hall at all.
2. **First-box Archon approval** ([ADR 0035](<redacted>.md) §2, [#717](https://example.com/builders#/task/717), migration 071). An already-admitted builder's *first* dev box was held at `box_intents.state='pending_approval'` until an Archon approved it (`POST /api/gds/box/intents/:id/approve`, or the `#box-approvals` Discord 👍/👎). Only then did the control-plane runner provision the paid (~$24/mo) droplet.

The first-box gate existed when admission was **open** — back then anyone with a GitHub account could become a Xenos with zero human in the loop, so a second human gate on the first paid box was the only thing standing between a signup and a charge ([ADR 0035](<redacted>.md) §Problem-3). Since [ADR 0050](<redacted>.md) closed that hole — admission is now invite-gated by default — the two gates are **redundant**: an Archon already had to admit this person before they could request a box at all. The second approval is a now-pointless second click that an Archon must remember to action (or it strands silently — the same failure mode the 2026-06-15 gate-surface retro called out for stranded approvals).

## Decision

Collapse the two human gates to **one — member-join admission.** Once a member is admitted ([ADR 0050](<redacted>.md)), their first dev box provisions **hands-off** through the existing box-intent runner: `POST /api/gds/box/ensure` enqueues the intent at `state='pending'` straight away (the same state a wake or a subsequent re-provision already uses), and the control-plane runner drains it unchanged. There is no `pending_approval` hold and no first-box approve step.

This **supersedes** [ADR 0035](<redacted>.md) §2 (Decision §2, "A newcomer's FIRST box requires Archon approval") and the **box half** of [ADR 0057](<redacted>.md) (the `#box-approvals` channel and its box-intent approve/deny reaction wiring). The rest of [ADR 0035](<redacted>.md) (§1 Metic+ local clone, §3 the single hosted guide) and the **member half** of [ADR 0057](<redacted>.md) (the `#member-approvals` channel) stand unchanged.

## Consequences

- **The member invite becomes the SOLE human gate before a paid (~$24/mo) box is created.** An admitted Xenos can provision their first box hands-off — the spend is bounded by the fact that a human already chose to admit them, not by a second per-box click.
- **The box provisioning RANK FLOOR still bounds eligibility.** `BOX_PROVISION_MIN_RANK` ([`src/bongos/boxes.js`](../../src/bongos/boxes.js)) is unchanged: the floor is still the rank-side control on who may have a box at all, and the per-builder "one box at a time" invariant (`box_intents` partial unique index, one `builder_boxes` row) is untouched. Removing the *first-box* gate does not widen *who* qualifies; it only removes the second human click for someone already admitted and already above the floor.
- **Migration 102 reverts the schema** introduced by migration 071 — the `pending_approval` box-intent state (and any approval-tracking column) is removed; in-flight first-box intents are migrated to `pending` so the runner drains them.
- **The box-panel "awaiting approval" UI state is removed** — `/builder-box` and the hall box panel no longer surface "your box is awaiting approval," because no box waits.
- **The `#box-approvals` Discord channel + its box-intent approve/deny wiring are removed** (the box half of [ADR 0057](<redacted>.md)). `#member-approvals` and the admission approve/dismiss wiring stay — admission is still the gate.
- **The trust-boundary invariant from [ADR 0031](<redacted>.md) §6 is unchanged.** The web tier still only *records a provision intent*; it never holds `DO_API_TOKEN` and never provisions directly. This ADR removes a human approval step, not the control-plane separation.

## Alternatives considered

- **Keep both gates.** Rejected — with admission now invite-gated ([ADR 0050](<redacted>.md)), the first-box gate is a redundant second click on a person an Archon already vetted, and it strands silently when un-actioned. The cost concern it was built for ([ADR 0035](<redacted>.md) §Problem-3) is already covered by admission + the rank floor.
- **Drop admission and keep first-box approval instead.** Rejected — admission is the stronger control (it gates *all* access, including reading and idea-filing, not just the box), and [ADR 0050](<redacted>.md) deliberately made it the default. Keeping the weaker, narrower gate while dropping the broader one inverts the design.
