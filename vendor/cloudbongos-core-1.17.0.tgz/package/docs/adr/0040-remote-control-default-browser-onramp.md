# ADR 0040 — Remote Control is the default browser-only on-ramp (reversing 0038's "RC is dead" verdict)

- **Status:** Accepted. **Reverses the "Remote Control is unfixable" conclusion of [ADR 0038](<redacted>.md)** (tasks [#745](https://example.com/builders#/task/745) / [#760](https://example.com/builders#/task/760)). Implemented in the onboarding/Settings work under [#807](https://example.com/builders#/task/807); recorded here under [#838](https://example.com/builders#/task/838); remaining legs (cloud-init trust pre-seed + the connect-guide / recipe-Part-2 rewrites that lead browser-only builders into the Claude app via `/remote-control`) landed under [#824](https://example.com/builders#/task/824).
- **Date:** 2026-06-07 (trust pre-seed leg: 2026-06-29, [#824](https://example.com/builders#/task/824))
- **Track:** `internal` (dev-system / builder onboarding)
- **Builds on:** [ADR 0038](<redacted>.md) (ttyd web terminal + Cloudflare Tunnel), [ADR 0031](<redacted>.md), [ADR 0035](<redacted>.md), [ADR 0039](<redacted>.md), [ADR 0016](<redacted>.md)

## Context

ADR 0038 concluded that Claude Code **Remote Control** (drive a session from the claude.ai web app or the mobile app) was *unfixable* for browser-only builders, and replaced it with a raw `ttyd` web terminal. The three blockers it documented were:

1. Trusted-Devices enrollment is interactive-`/login`-only — no headless path.
2. `claude rc` only renders its pairing link to a real TTY — a systemd service has none.
3. Remote Control requires full-scope browser OAuth — every baked-token path is excluded by design.

**All three were artifacts of running RC *headless, as a background service, with no human present.*** ADR 0038's own fix — the ttyd web terminal — dissolves every one of them: it puts a **real human at a real browser-backed PTY**. In that terminal, `/login`, workspace-trust, and Trusted-Devices enrollment all succeed (0038 verified exactly this for plain interactive `claude`).

So Remote Control was never the thing that was broken — the *headless context* was. Given a human PTY, RC works. **Verified live on the prod box (LarsCode) on 2026-06-07:** in the ttyd terminal, `claude` → accept workspace-trust → `/remote-control` prints a pairing link that drives the session from the Claude web/mobile app.

## Decision

**Remote Control is the recommended default experience for browser-only builders, and the onboarding leads with it.** This shipped in [#807](https://example.com/builders#/task/807): the "Claude Online" onboarding path walks the builder through

1. open the box's ttyd terminal (URL + password from the builders' hall),
2. run `claude` and complete the one-time sign-in,
3. run **`/remote-control`** to get a link, and
4. open that link to drive the session from the Claude web/mobile UI.

The ttyd terminal (ADR 0038) is retained but its role narrows to a **one-time launchpad**: the builder logs in and starts Remote Control there, then lives in the Claude app, not the raw terminal.

### Two specifics that are load-bearing

- **Use the in-session `/remote-control` slash command, not the standalone `claude rc` shell command.** The standalone command mis-checks workspace trust ([anthropics/claude-code#35817](https://github.com/anthropics/claude-code/issues/35817)): it reports `Workspace not trusted` even when the directory is trusted inside an interactive session, and a plain shell can't accept the trust dialog. Starting RC from *inside* an already-running, already-trusted `claude` session is the working path.
- **Closing the online terminal window ends the remote session and closes the dev box.** The onboarding states this so builders aren't surprised; it is a property of the session lifecycle, not a bug.

### What we explicitly do NOT do

- **No headless RC, no `claude-rc.service`.** ADR 0038 was right that RC can't run as a backgrounded service. RC is always started by a human in the ttyd terminal. The `claude-rc.service` / `box-report-pairing.sh` units deleted in [#760](https://example.com/builders#/task/760) stay deleted. (A stale comment in `infra/builder-box-cloud-init.yaml` still referenced the deleted unit; cleaned up under [#838](https://example.com/builders#/task/838).)
- **No token funneled to the box for RC.** RC authenticates through the builder's own interactive browser `/login` in the ttyd terminal — the same full-scope OAuth ADR 0038 relies on. The trust boundary ([ADR 0016](<redacted>.md)) is unchanged: no Anthropic credential is baked onto the box.
- **Workspace trust IS now pre-seeded — but as a NON-load-bearing convenience ([#824](https://example.com/builders#/task/824), updating the original deferral).** The cloud-init writes `/root/.claude.json` with `<redacted>` for `/root` + `/workspace` so the first `claude` launch usually skips the trust dialog before the builder reaches `/remote-control`. It is **deliberately best-effort**: the seed runs only when `/root/.claude.json` is absent (it never clobbers a config `claude` later writes), and upstream pre-seeding is known to be flaky ([#9113](https://github.com/anthropics/claude-code/issues/9113)). So nothing depends on it working — if it doesn't take, the builder accepts trust once during sign-in exactly as before. This is a one-keypress smoother, NOT a security control: trust is a UI convenience, and the real trust boundary is unchanged (no Anthropic credential is baked; auth is the builder's own interactive `/login`). The deferred question of whether RC can be spun up without the separate-window terminal dance at all remains open (idea_inbox).

## Consequences

- Browser-only builders (Chromebook, iPad, phone, locked-down laptop) get the full Claude web/mobile UI to drive their dev box — the experience ADR 0038 had to give up.
- The ttyd terminal becomes plumbing the builder touches once, not their daily surface.
- Two upstream behaviours we route around rather than depend on: the standalone-`claude rc` trust check (#35817 — avoided by using the slash command) and trust pre-seeding flakiness (#9113 — we now pre-seed for convenience but treat it as best-effort, so a failed seed costs the builder one trust keypress, nothing more). If Anthropic ships a headless RC mode or fixes the standalone trust check, we can simplify, but we do not rely on it.
- Verification crosses real hardware (box + a human at a browser). ADR 0038's `managed-settings-remote-control.md` recipe carries the end-to-end check; re-run it on any change to the terminal/RC flow.
