# ADR 0071 — Dev-box teardown confirms the droplet is gone before marking 'destroyed'; a bidirectional drift reconcile is the backstop

**Date:** 2026-06-20
**Context:** GDS / dev boxes, task [#1289](https://example.com/builders#/task/1289). Builds on [ADR 0031](<redacted>.md) (cloud dev environments) and [ADR 0053](0053-scoped-dev-box-session.md) (scoped dev-box session). Touches `scripts/gds/box.js`, `src/bongos/boxes.js`, `src/bongos/do-api.js`, `infra/box-drift-reconcile.{service,timer}`.
**Status:** Accepted.
**Track:** `internal` (development system / builder dev boxes).

## Problem — the "zombie" box

A dev box could reach GDS `box_state='destroyed'` while its DigitalOcean droplet kept **running and SSH-reachable**. Confirmed 2026-06-20 on `box-example-owner.dev.example.com` (builder LarsCode, xenos, id 3): `GET /api/gds/box/source-access` returned `403 {"reason":"NO_ACTIVE_BOX","box_state":"destroyed"}`, the box had no git `origin` remote, and it was frozen at an old commit — it could never pull new code again, which silently broke a newcomer feature (the box never fetched `scripts/gds/fetch-art-key.js`).

The impact is three-fold: **cost** (a "destroyed" droplet keeps billing), **security** (a box the control plane considers gone is still SSH-reachable and holds a live session token + repo clone), and **UX** (every task on a zombie box silently fails because the code can't update — a baffling "it's just not working").

### Root cause

`deprovisionOne()` deleted the droplet with a swallowed error and then set `destroyed` unconditionally:

```js
if (box.droplet_id) await doApi.deleteDroplet(box.droplet_id).catch((e) => console.log(`  ⚠ droplet delete: ${e.message}`));
// ...
await boxes.setBoxState(pool, box.builder_id, 'destroyed', { droplet_id: null, ... });
```

A transient DO failure (API blip, rate limit, token issue) was logged and ignored; the row flipped to `destroyed` and **nulled `droplet_id`** — losing the only reference to a droplet that was still alive. Worse, `canTransition('deprovision','destroyed')` is `false`, so the existing tooling could never re-attempt the teardown: the zombie was unreachable by id, forever.

## Decision

### 1. Confirm-before-destroyed (the primary fix)

The droplet delete is the **gate** for the `destroyed` transition. In `deprovisionOne()`:

- Delete the droplet via an **idempotent, retried** helper (`deleteWithRetry`): a `404` means "already gone" = success; transient failures retry a few times.
- If the delete genuinely fails after the retry budget, the box is parked at **`state='error'` with `droplet_id` PRESERVED** (not nulled) and an `error_note`, an `error` event is recorded, and the function **throws**. The row never reaches `destroyed` while a droplet is still alive.
- Snapshot / Cloudflare-tunnel / DNS teardown stay best-effort (a leftover snapshot is cost-only; the droplet — the thing that bills and is SSH-reachable — is gone by then), but the snapshot delete is now idempotent too.

This makes the DB row **truthful by construction**: `destroyed` now means "DO confirmed the droplet is gone."

### 2. A bidirectional drift reconcile (the backstop)

`box.js reconcile-drift` lists the real fleet droplets (`DoApi.listDroplets({ tag })` — a live read even in dry-run, since listing is non-mutating) and compares them to the GDS box rows via a pure `boxes.planDropletDrift()`:

- **Zombie** — a droplet no live box row claims (row is `destroyed`/`error`/`none`, or its `droplet_id` was nulled) → force-delete the droplet + tear down its tunnel/DNS.
- **Ghost** — a box row in a droplet-holding state whose `droplet_id` is gone from DO → mark `destroyed` (clearing the dead `droplet_id` + SSH host keys per idea 310) so the DB stops claiming a running box.

An **in-flight guard** protects provisions: a droplet created within `minAgeMinutes` (default 30) is never treated as a zombie — its box may still be `provisioning` (the row's `droplet_id` isn't written until the droplet settles `active`). Skipped-young droplets are reported, never deleted.

Dry-run is the default; `--apply` executes. A new hourly timer (`infra/box-drift-reconcile.{service,timer}`) runs it `--apply` so drift self-heals hands-off — hourly because a zombie bills continuously, so the daily dormant sweep is far too slow to catch one.

## Alternatives considered

- **Poll `getDroplet` until 404 after the DELETE.** Stronger confirmation, but adds latency + API calls; the DELETE returning 204/404 is sufficient acceptance, and `reconcile-drift` is the backstop for anything that still slips through. Rejected as over-engineering.
- **Box-side self-termination on `NO_ACTIVE_BOX`.** A box *cannot* delete its own droplet (no DO token; the builder firewall doesn't allow-list the DO API), and `poweroff` does **not** stop DigitalOcean billing. So self-termination can't actually reclaim the droplet — only the control-plane reconcile can. The box-side loop is harmless churn; we left `box-source-fetch.sh` unchanged rather than touch a fleet-auto-installed, permission-path-sensitive script ([ADR 0043](<redacted>.md)) for no real gain.
- **Reconcile snapshots too.** Out of scope: a leaked snapshot is ~$0.30/mo, not SSH-reachable, and not the reported bug. The reconcile is droplet-focused, matching the task.

## Consequences

- A failed teardown is now **visible** (`state='error'`, queryable) instead of a silent zombie, and self-heals on the next reconcile tick or `box.js deprovision`.
- One new operator step: `systemctl enable --now box-drift-reconcile.timer` on the prod droplet (mirrors the idle/dormant sweep units). `reconcile-drift` requires `DO_API_TOKEN` (always present in `/etc/example/box.env`).
- Pure decision (`planDropletDrift`) + idempotent delete (`deleteWithRetry`) are unit-tested hermetically in `tests/boxes.mjs` (no DO, DB, or clock).
