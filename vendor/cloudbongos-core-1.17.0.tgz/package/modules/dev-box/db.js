// modules/dev-box/db.js — the dev-box module's data layer (BV1.R68 / ADR 0091 §2,3).
//
// The dev-box DOMAIN query this module OWNS, reached through the published
// doorway's `pool` — a module never requires a core internal like
// ../../src/bongos/db (the ADR 0083 one-way rule). This is the per-domain db-slice
// pattern (ADR 0091 §2): the proven modules/discord/db.js + modules/game/db.js
// precedent applied to a core-domain leak. `setBuilderBoxBlocked` was the last
// dev-box query still living in the 6k-LOC core db.js monolith AND re-exported
// through the doorway (module-api.js); it is lifted verbatim to here and the
// doorway re-export + core copy are deleted. The boundary: this file requires
// ONLY src/module-api.js.
//
// box_blocked is cleanly dev-box-owned: the WRITE (here) and every READ
// (routes/box.js) live in this module — core never reads it. The columns
// physically sit on the core `builders` row (a box-feature migration added
// them), so this UPDATE touches a shared table; that is data locality, not
// logical ownership, and matches how box state has always been written. A
// future tidy could move them to a `dev_box_*` table — out of this carve's
// scope (no data migration).
'use strict';

const { pool } = require('../../src/module-api');

async function setBuilderBoxBlocked(builderId, { blocked, reason = null, actorBuilderId = null } = {}) {
  const on = !!blocked;
  const { rows } = await pool.query(
    `UPDATE builders
        SET box_blocked        = $2,
            box_blocked_reason = CASE WHEN $2 THEN $3 ELSE NULL END,
            box_blocked_at     = CASE WHEN $2 THEN now() ELSE NULL END,
            box_blocked_by     = CASE WHEN $2 THEN $4 ELSE NULL END
      WHERE id = $1
      RETURNING id, github_login, box_blocked, box_blocked_reason, box_blocked_at, box_blocked_by`,
    [builderId, on, reason, actorBuilderId]
  );
  return rows[0] ?? null;
}

module.exports = { setBuilderBoxBlocked };
