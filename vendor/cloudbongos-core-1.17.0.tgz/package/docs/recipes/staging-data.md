# Staging data — what's real, what's faked

> **Seeded by** [`scripts/gds/seed-staging.sh`](../../scripts/gds/seed-staging.sh) (V3.R41 / [#262](https://example.com/builders#/task/262)).
> Staging DB: `example_staging` on the droplet. Staging is the controlled mirror used for red-team ([#272](https://example.com/builders#/task/272) parallel-load, future C9 work) — **never** a place to trust as a record of truth.

## How seeding works

`seed-staging.sh` runs **on the droplet** (both databases are local, peer auth as `lars`). It takes a **full `pg_dump` of production (schema + data)**, drops and recreates the staging `public` schema, restores the dump, then anonymizes.

Why a full dump (not data-only): prod has a circular / self-referential FK (`tasks.parent_task_id`). A full dump adds all FK constraints **after** loading the rows, so that restores cleanly — and staging inherits prod's **exact schema**, so **no separate `migrate.sh` step is needed**. (A fresh `migrate.sh` from an empty DB would also fail: migration 021 is a *data* migration that assumes prod state.)

```bash
# On the droplet:
bash scripts/gds/seed-staging.sh

# Or from a laptop in one shot:
ssh lars@<droplet> 'bash -s' < scripts/gds/seed-staging.sh
```

Re-runnable any time; each run replaces staging's data wholesale.

## What's REAL (copied verbatim from prod)

The structure and content of the work-tracking graph, so staging behaves like the real system:

- **tasks, claims, versions, dependencies, done_when_criteria, task_criteria** — real titles, descriptions, statuses, ranks, links.
- **cost_log, credit_log, learnings, idea_inbox, grades, achievements** — real rows.
- **builder_memory** — real per-builder memory content (builder-authored project notes; internal, not personal data).

These are *project* data (what the team built), not end-user data. Staging lives on the same access-controlled droplet as prod.

## What's FAKED / removed (the anonymization step)

- **Builder identity is anonymized.** Every `builders` row gets `github_login = builder-<id>`, `display_name = Builder <id>`, `github_id = 900000<id>`, `avatar_url = NULL`. No real GitHub handle survives on staging.
- **All sessions are purged.** After the restore, the script nulls every column that references `builder_sessions` and then `DELETE`s every session row, so the seeded DB ends with **zero** sessions and **no real bearer token**. Mint a staging-only token directly (insert a row into `example_staging.builder_sessions`) when a test needs to authenticate — note the auth regex only accepts `[A-Za-z0-9]+`, so the token must be alphanumeric (no hyphens).

### Honest note on the restore window (not a zero-trust guarantee)

Because it's a *full* dump, real session rows **are** loaded during the restore and only deleted a moment later in the anonymize step — so for the brief restore→purge window (~1s) real bearer tokens transiently exist in the staging DB, and the temporary dump file under `/tmp` (mode `0600`, shredded on normal exit) holds real `github_login` values until cleanup. This is acceptable because staging is the **same trust domain** as prod (one access-controlled droplet, peer auth) — but it is **not** a "real tokens never touch staging" guarantee. If you need that guarantee (e.g. seeding onto a less-trusted host), revoke prod sessions first or seed during a maintenance window. The end state after a successful run is always zero sessions.

## Reseeding cadence

Re-run on demand (before a red-team / load-test session) or on a weekly cron. To install the weekly cron on the droplet:

```bash
# 03:30 every Monday — refresh staging from prod.
( crontab -l 2>/dev/null; echo "30 3 * * 1 bash /home/lars/example-staging/scripts/gds/seed-staging.sh >> /home/lars/seed-staging.log 2>&1" ) | crontab -
```

(On-demand is the common case; the cron is optional convenience. The staging checkout must be on current `main` so it has the latest schema — `git pull` it before a manual seed if prod's schema has moved. Until the cron is installed, treat staging data as a point-in-time snapshot from the last manual seed.)
