# ADR 0068 — Shared Gemini art key delivered from the GDS to newcomers

- **Status:** Accepted
- **Date:** 2026-06-20
- **Track:** internal
- **Builds on:** [ADR 0016](<redacted>.md) (rank enforced server-side, no caching — the gate here is `builders.rank`), [ADR 0054](<redacted>.md) (cost-plus economics — this is the org choosing to absorb newcomer art spend), and the existing per-builder BYOK key path in `art/pipeline/gen_api.py` (V3.R11 [#91](https://example.com/builders#/task/91))
- **Task:** [#1281](https://example.com/builders#/task/1281)

## Context

A newcomer's (rank `xenos`) three first chores include an **art** task — "generate one in-world asset" via `/otb-tile-generate` (`scripts/gds/newcomer-floor.templates.json`). That pipeline needs a Google AI Studio (Gemini) key. Until now the only ways a builder had one were (a) pasting their own during `/builder-setup` (`gemini_api_key` in their local session file) or (b) an operator hand-placing one in `~/.config/otb/env` on the machine. A brand-new builder has neither, so their very first art task fails with a "set `GOOGLE_AI_STUDIO_KEY`" error — a hostile first impression for a task we explicitly want them to complete.

The owner's intent: **we pay up front** for a newcomer's first art tasks. Once they prove themselves (graduate `xenos → thetes` after three shipped tasks) they bring their own key. This ADR records the Phase-1 *infrastructure* decision; the newcomer-facing *experience* (copy explaining we pay, the on-promotion walkthrough to add a personal key, a rank-aware setup prompt) is a deliberate Phase 2.

## Decision

The GDS becomes the source of a **shared** Gemini key, delivered to entitled builders and consumed by riding the art pipeline's existing key-resolution cascade.

1. **Storage = server secret, not the DB.** The shared key is an operator-provisioned env var `SHARED_ART_GEMINI_KEY` in `/etc/example/web-source.env` (env-first, then `~/.config/otb/gemini-shared.json#api_key` for local dev) — the exact pattern `auth.js` already uses for the GitHub/Discord secrets (`src/bongos/art-key.js`). It is **never** written to the database or its backups, so a DB dump is never a key-disclosure event.

2. **Entitlement = `xenos` only, server-enforced.** `GET /api/gds/me/art-key` (`src/bongos/routes/me.js`) reads the builder's live rank and returns `{ entitled, configured, reason, shared_key }`. The secret is attached **only** when `entitled && configured`. The boundary is a single named constant `SHARED_ART_KEY_MAX_TIER = REQUIRES_RANK_TIER.xenos`, so widening it later (e.g. "any builder without their own key") is a one-line change. Thetes+ get a `200` with `entitled:false` — **not** a 403 — so the client can tell "withdraw the key" apart from an auth failure.

3. **Delivery = a distinct, self-healing session slot.** A SessionStart sync (`scripts/gds/fetch-art-key.js`, a port of `fetch-sound-prefs.js`) calls the endpoint each session and writes/removes a **new** `shared_gemini_api_key` field in `~/.config/otb/gds-session.json` — separate from the builder's own `gemini_api_key`, so "ours" and "theirs" never blur. Re-deriving it every session means promotion to Thetes automatically withdraws the key on the next session start; `setup.js` also fetches it once at onboarding so the first task works immediately.

4. **Resolution = own key always wins.** `gen_api.py` gains one tier, slotted **below** the builder's own key and **above** the manual dotenv fallbacks: `env → own (gds) → own (pms) → shared (gds) → ~/.config/otb/env → .env.local`. A builder who sets their own key is never affected; the shared key is only ever a floor.

5. **Attribution.** `gen_api.api_key_source()` returns `own|shared|env|dotenv`, and `cost_ledger.log_call` stamps it as `key_source` on each row, so shared-key spend (the org's dime) is distinguishable from own-key spend on the cost dashboard.

## Consequences

- **Trust widening, bounded deliberately.** We hand a paid key to a low-trust newcomer (it lands in their mode-600 session file, the same tier as their GitHub token). A `xenos` could extract it and run up spend outside the pipeline. We accept this for newcomers and bound the blast radius by: (a) recommending a **dedicated** key with a Google-side **billing/quota cap** ([blocker for the owner](../../blockers/blockers.md)); (b) the server-side rank gate; (c) trivial rotation (change one env var, redeploy). The key is never logged and the endpoint is `no-store`.
- **Ships safely before the key exists.** With `SHARED_ART_GEMINI_KEY` unset the endpoint returns `configured:false` and nothing changes for anyone — newcomers see today's behavior. Provisioning is decoupled from the code landing.
- **No schema change.** Entitlement is computed from the existing `builders.rank`; no migration, no encryption layer, nothing in `migrations/`.

## Alternatives considered

- **Encrypted key in the DB + an Archon paste-in-browser UI.** More owner-friendly (no SSH) but adds an encryption layer, a migration, and a web surface, and puts the secret in the DB/backups. Rejected by the owner in favor of the server-secret-file path (simplest, most secure, matches every other secret on the project).
- **Reuse the existing `~/.config/otb/env` shared slot for delivery.** Zero pipeline change, but it's a plain shared dotenv that an operator may have set by hand — the sync could clobber a deliberate choice, and it can't cleanly distinguish "GDS-delivered" from "manual." Rejected for the dedicated, self-healing `shared_gemini_api_key` session field.
