-- 004_pms_cost_idempotency.sql
-- Make cost_log idempotent: same (source, source_ref) pair can only be inserted once.
-- This unblocks safe re-runs of backfill scripts (e.g. art ledger, future automated cost feeds).
--
-- The index is partial — only enforced when BOTH source and source_ref are non-null —
-- so manual cost entries (which often omit one or both) remain unrestricted.

CREATE UNIQUE INDEX IF NOT EXISTS uniq_cost_log_source_ref
  ON cost_log (source, source_ref)
  WHERE source IS NOT NULL AND source_ref IS NOT NULL;

INSERT INTO schema_migrations (version) VALUES ('004_pms_cost_idempotency')
  ON CONFLICT (version) DO NOTHING;
