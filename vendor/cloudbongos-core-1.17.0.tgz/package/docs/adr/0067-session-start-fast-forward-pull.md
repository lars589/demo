# ADR 0067 — Fast-forward the checkout to origin/main at session start (when safe)

- **Status:** Accepted
- **Date:** 2026-06-19
- **Track:** internal
- **Builds on:** the warn-only freshness step ([#1258]) it replaces; the dev-box source-materialization cron (`infra/box-source-fetch.sh`, [ADR 0031](<redacted>.md)); the existing memory pull-on-session-start (`.claude/hooks/pull-memory.js`, [#275]) whose best-effort/fail-open discipline this mirrors for the code checkout.
- **Task:** [#1277](https://example.com/builders#/task/1277) — owner request ("make sure we pull on every session start").

## Context

A builder's working checkout can run **stale** relative to `origin/main`, and several startup-loaded surfaces — `CLAUDE.md`, the file-based memory, and the SessionStart hooks themselves — are read **once** per session. A session that starts behind `main` therefore runs old methodology and old code with no self-heal during the session.

Two existing mechanisms only partly cover this:

1. **The dev-box cron** (`box-source-fetch.sh`, every ~10 min) does `git pull --ff-only` on the box's `/workspace` checkout. But it only freshens `/workspace` (not per-task worktrees), only fast-forwards, and lags by up to its interval — so a *new* session opened between ticks can still be behind.
2. **The warn-only freshness step** ([#1258]) did a bounded, non-mutating `git fetch origin main` and, if behind, *warned* but never pulled. Its stated reasons for not pulling: dirty trees can't fast-forward, and the Mac's iCloud-synced checkout has an mmap risk on big working-tree git ops.

The owner asked for the obvious fix — pull on session start — but the naive alternative (shorten the cron toward "every few seconds") is wrong on the merits: `cron` can't go sub-minute, every tick is an authenticated `GET /box/source-access` round-trip against the single prod droplet, and a frequent pull risks rewriting files **under an active session**. The right lever is **event-driven**: freshen once, at the moment work begins, not by polling faster.

## Decision

Upgrade the SessionStart freshness step (`freshenOrWarn()` in `.claude/hooks/session-start.js`, renamed from `printFreshnessWarning()`) from *fetch-and-warn* to *fast-forward-when-safe, else warn*. After the same bounded `git fetch origin main`, it computes `behind = HEAD..origin/main` and, if behind, runs `git merge --ff-only origin/main` **only** when **all** of these hold:

- **on branch `main`** — never pull `origin/main` into a feature branch / worktree (that is a rebase, not this hook's job; it cleanly no-ops the common laptop case);
- **zero local commits ahead** (`origin/main..HEAD == 0`) — strictly behind, so the merge is a real fast-forward, never a merge commit;
- **no modified/staged tracked files** (untracked/ignored are fine, so a box with stray logs still qualifies) — a fast-forward then cannot shadow uncommitted work;
- **a full clone, not a partial/blobless one** — on a `--filter=blob:none` box, checkout lazily fetches blobs over the network, which the bounded merge could interrupt; those are left to the cron.

Everything stays **bounded + fail-open**: a slow/offline network or any git error never blocks or delays session start — it falls through to the existing warning. The kill-switches (`OTB_FRESHNESS_CHECK_OFF`, `OTB_SUBAGENT` subagent skip) are preserved. On a successful pull the hook prints a one-line confirmation that also notes the caveat below.

This **reverses** the "nothing pulls at session start, by design" rule the [#1258] comment documented. That rule is preserved exactly for every case *outside* the safe gate (feature-branch worktrees, dirty trees, diverged history, partial clones), which still get the warning.

## Consequences

- **A fresh session on a clean `main` full clone starts current** — the box `/workspace` and a laptop's main checkout fast-forward at startup instead of waiting up to a cron interval (or forever, for a between-ticks session). This is the owner's asked-for behavior.
- **Never worse than before.** Where the safe gate doesn't hold, behavior is byte-identical to the warn-only step. Where it does, a fast-forward on a clean `main` is local + fast, so the bounded merge effectively never trips; if it ever did, the box cron remains the backstop.
- **The iCloud-mmap risk is sidestepped, not ignored.** The merge only runs on a clean `main`; Mac sessions are overwhelmingly feature-branch worktrees, which take the (unchanged) warn path. A main-checkout pull on the Mac is bounded and fail-open.
- **Worktrees and loaded-once surfaces are out of scope.** Per-task worktrees aren't auto-advanced (you don't pull `main` into a feature branch), and even after a successful code pull, the `CLAUDE.md` / hooks / memory already loaded for *this* session reflect the pre-pull state until the next session — the success line says so. The real reset for those surfaces remains a fresh session.
- **Starter (partial-clone) boxes** keep relying on the cron for freshness; they are deliberately excluded to avoid interrupting lazy blob fetches. If that matters later, the gate can be relaxed once a partial-clone-safe pull path exists.
- **No new dependency, no new network load.** One extra local `git merge` on the qualifying path; the prod API is untouched (this is the cheap event-driven alternative to a faster cron).

[#1258]: https://example.com/builders#/task/1258
[#275]: https://example.com/builders#/task/275
