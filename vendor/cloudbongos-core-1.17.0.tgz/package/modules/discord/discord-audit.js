// src/bongos/discord-audit.js
//
// Shared wrapper for the bot's audit-log writes (task 1091, C7 — dedup audit
// 2026-06-14 §2A discord). Every bot-triggered write is audited (ADR 0033 §1)
// with method='POST' and surface='discord_bot', best-effort: an audit failure
// must NEVER undo or throw out of the action it records, so it is caught and
// logged non-fatally. The five call sites (approvals, bugs ×2, inbound,
// reaction) differ only in builderId / route / requestBodyRedacted /
// responseStatus and the log label — everything else is fixed here.
//
// `deps` carries the injected insertAuditLog (deps.insertAuditLog) so the
// existing unit tests' mocked deps continue to observe the identical call.

async function auditDiscordBot(deps, { builderId, route, requestBodyRedacted, responseStatus, logLabel }) {
  try {
    await deps.insertAuditLog({
      builderId,
      route,
      method: 'POST',
      requestBodyRedacted,
      responseStatus,
      surface: 'discord_bot',
    });
  } catch (auditErr) {
    console.error(`[discord-bot] ${logLabel} (non-fatal):`, auditErr.message);
  }
}

module.exports = { auditDiscordBot };
