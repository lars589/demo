# ADR 0115 — Scheduled-routines portability (self-host + multi-builder)

**Date:** 2026-07-04
**Status:** Accepted (contract; spike deliverable).
**Context:** [task 2014](https://builders.example.com#/task/2014) (BONGOS-V1, from the 2026-07-04 CLAUDE.md review, bullet 241). The ~17 autonomous cron routines under [`.claude/scheduled-tasks/`](../../.claude/scheduled-tasks/) (`overnight-builder`, `idea-triage-nightly`, `overnight-code-review`, `bfg`, `security-review-weekly`, box lifecycle, audits, newcomer restock, …) were written for *this* instance. A self-hosted, multi-builder instance needs a defined model for which run instance-wide vs per-builder, how a fresh instance inherits/configures them, and what a builder gets by default. Companion to [ADR 0062](<redacted>.md) (core↔host split) and [ADR 0024](<redacted>.md) (the MAS the routines belong to).

## Problem

The routines are instance-agnostic in intent but were authored against OTB: their prose cites `example.com` API bases and `~/.config/otb` paths, and there was **no declared model** for how they scale to multiple builders or scaffold onto a fresh instance. Two questions were open: (1) in a multi-builder world, does a routine run once for the instance or once per builder? (2) how does a fresh instance inherit + configure the set, and what does an individual builder get by default?

## Decision

**Every scheduled routine is INSTANCE-WIDE — one scheduled run per instance, never one cron per builder.** A routine's *per-builder effect* (the BFG scores each builder; `newcomer-floor` restocks per discipline; `overnight-builder` may claim on any builder's behalf) comes from **iterating the builder set inside the routine body**, not from N per-builder schedules. This keeps scheduling O(1) in builders and the trust surface single (one control-plane scheduler, one autonomy gate), not O(builders).

The contract is made concrete + configurable by a **manifest**, [`config/scheduled-routines.json`](../../config/scheduled-routines.json), declaring per routine:

- `scope` — always `instance-wide` in v1 (the model above); `builderAware: true` marks the ones whose *body* iterates builders.
- `enabled` — the default-on/off for a fresh instance. **Read-only hygiene/ops routines default ON** (box lifecycle, audits, drift checks, newcomer restock, peer-vote tally, dep/security audits). **Autonomous build routines default OFF** (`overnight-builder`, `overnight-code-review`, `idea-triage-nightly`) — they carry `requiresAutonomy: true` and are a no-op until the instance arms `<PREFIX>_AUTONOMY_ENABLED` (matching today's default-unset OTB behavior). The BFG's cross-builder WRITE (Part C) stays independently gated by `BFG_WRITE_ENABLED` + a provisioned principal token.
- `cadence` — a scheduler hint (hourly/daily/nightly/weekly/on-merge); the actual cron lives in the operator's scheduler config.
- `requiresAutonomy` — whether the routine is inert until the autonomy flag is armed.

**Inheritance.** The routines ship in the core template (`.claude/scheduled-tasks/`); a fresh instance inherits the whole set + this manifest. The operator opts in/out and sets cadence **in the manifest**, without editing a routine. A vanilla instance therefore boots with the safe subset (read-only ops on, autonomous build off).

**What a builder gets by default.** Builders do **not** schedule their own routines in v1 — these are instance/ops-level. A builder's *involvement* is governed by their per-builder settings (autonomy opt-in, `wandering`, model allocation), not by this manifest. Per-builder scheduling is explicitly out of scope for v1 (a future extension could let a builder opt a builder-aware routine in/out for themselves).

## Consequences

- **`config/scheduled-routines.json` is the portability surface** — the single place an operator configures the routine fleet; the scheduler + a future `bongos init` read it to decide what to arm.
- **Portability debt flagged, not fully paid here (spike scope):** several routine `SKILL.md` files hardcode `example.com` / `~/.config/otb` in prose. The contract requires routines to resolve instance identity from config (`branding().domains`, the instance config dir) rather than hardcode it; genericizing all ~17 prose files is a **follow-up** (a mechanical sweep), captured as its own task — not part of this decision.
- **No behavior change today.** OTB keeps running every routine exactly as before; the manifest simply records the model it already follows (instance-wide) and the safe defaults. The `requiresAutonomy` routines remain OFF (OTB has not armed autonomy).
- **CLAUDE.md §12** references this contract + the manifest instead of just naming "~17 routines."
