# A Concrete Modular Architecture — and the safest way to get there

Built on the research ([00](00-research-report.md)). Plain language, decision-oriented.

## 1. The reframe: one decision treated as four

"How modular is the code" is a **separate question** from "how many packages" and "how many processes." They feel like one decision; they are four independent axes. Becoming modular means moving **only the first**.

| Axis | Today | Move? | Why |
|---|---|---|---|
| **Modularity** (how code is organized inside) | one fused blob | **→ go fully modular** | this is the goal |
| **Packaging** (npm package boundaries) | one `package.json` | **stay** | many packages buy dep-trees + caching, *not* modularity; cost a build/link step |
| **Runtime** (deployment) | one Node process | **stay** | a process-per-module is a scaling/sandbox choice; ADR 0080 defers sandboxing |
| **Build** (bundler) | none (raw files) | **stay** | pure cost for a $5k project; `start` is just `node server.js` |

> **The one-sentence version:** modularity is delivered by **boundaries + a loader + a contract** — not by multiplying packages or processes. VS Code, Backstage, and Fastify are deeply modular and run as a single process. Each "stay" has a clean future fork (marketplace → packages; untrusted modules → processes; a UI needing a build → that module owns its build), all of which ADR 0080 already defers — so you change nothing you'd later regret.

## 2. The confusing parts, in plain terms (shipping containers)

"Manifest" is literally a shipping term — the cargo list a ship carries.

| Jargon | Plain meaning | Shipping picture |
|---|---|---|
| Module / package | a self-contained folder with everything one feature needs | a labeled shipping container |
| Manifest (`module.json`) | a label file saying what's inside + what it needs | the cargo manifest on the door |
| The kernel | the always-on platform every module relies on (login, ranks, tasks) | the port — cranes, docks, customs |
| Loader | the part of the kernel that finds containers, checks labels, plugs the enabled ones in | the crane |
| Boundary / one-way arrow | a module may use the kernel; the kernel never reaches into a module; modules never reach into each other | containers connect only to the dock — never weld two together |
| Fitness function | an automatic build check that **fails the merge** if a boundary rule is broken | customs at the gate, auto-rejecting a wrongly-loaded truck |

Organizing once is easy; *staying* organized is the hard part — the fitness function is what makes the structure self-enforcing instead of relying on discipline.

## 3. The target architecture

The whole product becomes **core + modules**. A module is a **vertical slice** (its routes, DB tables, screens, agent-context) that reaches the rest of the system through **one published doorway**.

```mermaid
graph TD
    subgraph Modules["Modules (each a vertical slice: routes · db · ui · skills · manifest)"]
        G[game]
        D[dev-box]
        DC[discord]
        Y["your module<br/>(no fork!)"]
    end
    API["core/module-api.js<br/>THE published, versioned doorway<br/>(the only thing a module may import)"]
    subgraph Core["CORE — always on, carries ZERO module-specific code"]
        L[loader]
        A[auth + rank ladder]
        T[tasks · claims · grading · memory]
        DB[(core db pool + core tables)]
    end
    G --> API
    D --> API
    DC --> API
    Y --> API
    API --> Core
    Core -.->|"FORBIDDEN: core never imports a module<br/>(fitness check blocks it)"| Modules
```

**The five rules:** (1) one doorway, one direction — modules import `module-api.js` only; core never imports a module; modules never import each other. (2) The host owns the mount. (3) A module owns a vertical slice. (4) Shared state is namespaced (`<key>_*` tables, additive migrations). (5) A task is scoped to a module.

### 3a. How a module plugs in without picking the lock

The module ships a *recipe* for its routes; the **loader** wraps them behind auth the module can't remove:

```mermaid
graph LR
    M["module ships:<br/>route factory<br/>+ 'needs Metic'<br/>(never calls app.use)"] --> Loader
    subgraph Loader["the loader builds around it"]
        direction TB
        A1["① audit log"] --> A2["② requireBuilder"]
        A2 --> A3["③ requireRank(Metic) — live from DB"]
        A3 --> A4["④ the module's handler runs here"]
    end
```

The module's code only ever runs *inside* gates the core wraps around it; it can't register anything before the auth/rank checks because it never touches the front door. A separate fitness check fails the build if a module route forgets its rank gate. This is **stronger** than how Backstage/VS Code treat first-party plugins (they isolate for stability; Backstage doesn't sandbox at all). Full process-isolation is the deferred future fork.

## 4. What this does to `touches[]` — it retires

In a real modular world, two tasks on **different modules can't collide** — so the file-path `touches[]` array has nothing left to detect.

- Cross-module work → **parallel-safe by construction** (no check needed).
- Same-module or shared-core → the one zone that needs a check.
- So the safety question shrinks from "do these file lists overlap?" to "same module? touches core?" — answered by the task's **module label**, not a file array.

"Not passed the code" is about what the agent *sees*; the hard guarantee it can't write elsewhere comes from a **ship-time check that the diff stayed inside the declared module**. Seeing-only + verify-on-ship = real isolation. `touches[]` survives only as a transitional crutch while the code isn't in modules yet.

## 5. Why NOT a ground-up rewrite

```mermaid
graph LR
    subgraph RW["Ground-up rewrite"]
        R1["long dark window — nothing ships —<br/>re-deriving the SAME core (auth, tasks, grading, ~111 migrations)"] --> R2["risky big-bang cutover ⚠"]
    end
    subgraph ST["Strangler migration (recommended)"]
        S1[loader] --> S2[dev-box→module] --> S3["discord · art"] --> S4[game] --> S5["carve core + task→module"] --> S6[theming]
    end
```

- A rewrite **re-derives the parts you'd keep anyway** (auth, rank ladder, tasks/claims/credits, grader, ship pipeline, ~111 migrations) — no modularity win in retyping it; the win is *where code lives + enforced boundaries*, which a reorg delivers.
- The risk profile is upside-down for a bootstrapped, ship-small, AI-first project: a rewrite is a long no-ship window ending in a big-bang cutover.
- **Rule of thumb: rewrite when the foundation is wrong; reorganize when the foundation is sound but the filing is wrong.** Your foundation (trust boundary, GDS pipeline, grader) is sound; the filing (fused game/core, a 236 KB `db.js`, flat routes, hardcoded brand strings) is wrong. That's a reorg.

## 6. The migration path

Each phase ships independently, guarded by the fitness functions; easiest/most-isolated first, riskiest (game) last.

| # | Phase | What happens in the code |
|---|---|---|
| 0 | Draw the doorway | define `core/module-api.js` + teach `fitness.js` the one-way rule (mostly exists) |
| 1 | Build the loader | discover `modules/*/module.json`, validate, compose routes behind auth, apply module migrations, start/stop pollers |
| 2 | Move dev-box first | most self-contained + half flag-gated; the template every other move copies; prove OTB behaves identically |
| 3 | Move discord, then art-pipeline | same recipe |
| 4 | Move game (the hard one) | Colyseus rooms + world tables + `public/`; "realtime capability" seam |
| 5 | Carve the core + rewire the task model | split `db.js` per-module; add `task.module`; **retire `touches[]`**; extend fitness to verify diff-in-module |
| 6 | Finish theming | pull ~90 hardcoded brand strings into `branding.json`; unify the stylesheets; per-module UI sections |

The proof at every step (as in ADR 0062's core/host split): after moving a module, OTB behaves **byte-for-byte the same**.

## 7. What changes, what stays

**Changes (reorganize):** code moves into `modules/<key>/` slices · a real loader replaces hand-wired `if (isModuleEnabled())` lines · `module.json` becomes load-bearing · the 236 KB `db.js` is carved per-module · a task gains a module label; `touches[]` retires · brand strings + stylesheets consolidate.

**Stays (unchanged):** one `package.json` · one Node process (`node server.js`) · no bundler · Postgres, raw ESM client + CJS server · the trust boundary + rank ladder (extended to module routes) · the GDS ship/grade/deploy pipeline.
