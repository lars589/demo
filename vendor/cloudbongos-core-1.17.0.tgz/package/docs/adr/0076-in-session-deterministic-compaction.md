# ADR 0076 — In-session deterministic compaction (retrieval-first context)

**Status:** Accepted (2026-06-20) · tasks [#1347](https://example.com/builders#/task/1347) [#1348](https://example.com/builders#/task/1348) [#1349](https://example.com/builders#/task/1349) [#1350](https://example.com/builders#/task/1350) · hardened [#1364](https://example.com/builders#/task/1364) · System 2 of the Cloud Bongos LLM-reduction redesign (spike [#1326](https://example.com/builders#/task/1326)) · builds on [ADR 0075](<redacted>.md) (the ledger that measures it) and [ADR 0060](0060-gds-retrieval-layer.md) (the recall layer it recovers through)

## Context

The efficiency audit's central finding ([ADR 0075](<redacted>.md)): **~82% of token spend is a few dozen Opus "marathon" sessions**, and their cost is overwhelmingly `cache_read` — a context prefix that grows monotonically and is **re-billed on every assistant turn for hours**. Marathon cost is therefore the *integral of a growing prefix over hundreds of turns*, and the prefix is dominated by stale tool output: file reads later edited, the same file read repeatedly, large `Grep`/`Glob`/`ls`/`Bash` dumps acted on once and never referenced again. **This is the only pool large enough to matter — no cache, model-router, or cron-gate can touch it. Only bounding the live context can.**

Spike [#1347](https://example.com/builders#/task/1347) measured the realized headroom on 7 real OTB Opus transcripts: **~24% of tool-output tokens are provably stale** by three conservative deterministic rules (superseded reads 7.3%, stale dumps 7.9%, duplicate reads 0.2%; per-session range 4–73%). That is the *floor* — the classifier deliberately counts only what it can prove — so System 2's 20–40% estimate is validated as plausible-to-conservative.

## Decision

A **deterministic eviction pass batched at the PreCompact boundary** drops stale tool output so the re-billed prefix stops growing; recovery is **retrieval-first** through the existing `/recall` layer.

### Why the PreCompact boundary, not per-turn

Rewriting the prefix mid-session invalidates the prompt cache: the next turn re-pays a full **cache-write** ($6.25/Mtok opus) instead of a cache-read ($0.50/Mtok). Doing that every turn costs far more than it saves. But compaction **already** resets the cache and pays one cache-write — so an eviction batched *there* is free of marginal cache cost, and every later turn reads the smaller, longer-lived working set. So: **evict only at PreCompact, never per-turn.**

### Always-live vs retrieve-on-demand

The classifier (`.claude/hooks/eviction-policy.js`, pure + hermetically tested) only ever targets `tool_result` blocks, and only these three classes:

| Reason | Rule | Why safe to drop |
|---|---|---|
| `superseded` | a **whole-file** `Read` whose file was later `Edit`/`Write`-n | a definitive newer source of truth exists (the edit); the old read is stale |
| `duplicate` | an older `Read` whose line range is later **covered** by another `Read` of the same file | the later read fully contains it; it is the current truth |
| `stale_dump` | a `Grep`/`Glob`/`LS`/**reproducible** `Bash` result ≥ dumpMin tokens, older than the recency floor, **not cited** by a later turn | bulk output acted on once; re-derivable by re-running the tool |

**Never-evict (always-live):** user turns, assistant text + reasoning, the claim **context-pack**, **worktree-path guidance**, harness `system-reminder`s, the **last N turns** (the live working set), the **newest read of any file**, and any **non-reproducible/side-effectful `Bash` output** (a generated secret, a timestamp, a migration result — re-running yields a different value, so it is irrecoverable). A **backward-reference liveness scan** is the final safety: a dump whose distinct line is quoted *or* whose distinctive identifiers/paths are reused by a *later* assistant turn (a paraphrase) is kept (it is still being cited). When in doubt, keep — the system must never break a session to save tokens.

### Retrieval-first recovery (the evict-stub → /recall loop)

Each evicted block is replaced by a **one-line stub** naming what is gone and a **one-step recovery**: a file `re-Read`, or — for a dump — a concrete `` /recall "<pattern>" `` query (which routes through `src/bongos/search.js` `searchChunks` / RRF, the same rank-scoped layer [ADR 0060](0060-gds-retrieval-layer.md) and the session-start `recall-hints.js` precedent use) **or** a re-run of the same tool. The PreCompact hook emits a **one-time** directive stating the recovery rule once — *recover on demand, do NOT pre-fetch* — which is what prevents a retrieval loop (the agent re-fetching everything it just evicted and undoing the compaction). `search_chunks` already dedups by `content_hash`, so re-ingested/duplicate content costs nothing extra.

### Wire, don't arm

The PreCompact hook (`.claude/hooks/pre-compact.js`, task 1349) is gated behind the per-builder **`OTB_INSESSION_COMPACT`** flag, **OFF by default** — an instant no-op for every builder until explicitly enabled. On a harness build without a PreCompact event the hook degrades to a Stop-hook *advisory* (stderr only, never blocks, never per-turn-rewrites). The directive is emitted as `hookSpecificOutput.additionalContext`; an older harness that ignores it simply compacts as usual.

## Consequences

- The single largest lever in the redesign (20–40% of total spend) is built and inert, ready for the owner to arm per-builder.
- Savings are **measurable**: once armed, each compaction can record its counterfactual into `cost_baseline` (ADR 0075) — the priced size of what was evicted vs. what re-reading it would have cost — so the system proves itself in dollars rather than asserting.
- Recovery never silently loses data: every evicted block is on disk (re-Read), in `/recall` (file content), or re-derivable (re-run the tool); the stub says which.
- **Risk owned:** the directive is *guidance* to the compaction step, which is itself an LLM — eviction is advisory, not a hard transcript edit. The conservative classifier + never-evict list bound the blast radius; arming should start on one builder and watch `by_tier.cache_read_pct` (ADR 0075) before rollout.

### Hardening before arming (task [#1364](https://example.com/builders#/task/1364))

Three soundness gaps in the original classifier were closed before the flag is armed — each tightens a rule toward *keep* (the safety direction), so none can newly evict something that was previously kept:

1. **Non-reproducible/side-effectful `Bash` is never a `stale_dump`.** The recovery stub said "re-run `Bash`", but re-running `openssl rand`, a `date`, a one-time generated value, or an `apply migration` yields a *different* value or has already mutated state — the affordance was actively wrong. A volatile-command detector (randomness, timestamps, mutations, file-writing redirects) excludes these from eviction; pure read commands (`cat`/`grep`/`ls`/`find`/…) stay evictable.
2. **`duplicate`/`superseded` respect `Read` `offset`/`limit`.** They keyed on `file_path` alone, so a later read of a *different slice* marked the earlier slice `duplicate`, and a 1-line `Edit` marked an *entire* prior read `superseded` — dropping content never actually superseded. Now a read is `duplicate` only when a later read's line range **covers** it, and `superseded` fires only on a **whole-file** read (a partial read can't be located against a line-range-less `Edit`).
3. **Liveness catches paraphrase.** The backward-reference scan matched only verbatim ≥40-char line quotes; an agent that re-stated a still-needed dump in its own words lost it. A distinctive-identifier/path overlap heuristic now keeps a dump when a later turn reuses several of its salient tokens.

## Reproduce / verify

- Pure tests (DB-free): `tests/eviction_policy.mjs` (classifier, 22 cases incl. the task 1364 hardening), `tests/pre_compact.mjs` (gate + directive).
- Dry-run against a real transcript: `OTB_INSESSION_COMPACT=1` piped a `{hook_event_name:'PreCompact', transcript_path}` payload to `pre-compact.js` → emits the directive; unset → no-op.
- Spike methodology + numbers: task [#1347](https://example.com/builders#/task/1347).
