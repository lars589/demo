-- 172_v2_world_planning_seed.sql
-- Land Builder #25's world-building planning package (idea_inbox 416-427),
-- reviewed + adjusted with Lars, folded into the existing product version V2.
-- Backed by task 1569 (source_ref V2-world-planning-1).
--
-- Decisions baked in here:
--   * World-building folds into V2 — NO new version row.
--   * The warp stays in V2 (criterion connected-warps + its tasks).
--   * The in-house map editor (criterion map-editor + 6 tasks) defers to V3.
--   * Engineering/server lanes are split from design/art lanes (carried by the
--     per-task module_key + requires_rank set in the companion seed script).
--
-- This migration handles DB scope-truth only:
--   1. 4 goals (3 on V2, 1 on V3)
--   2. 7 done_when_criteria (6 on V2, 1 on V3), parented to their goals
--   3. V2 + V3 versions.done_when text
--   4. +5 karma x7 to builder #25 (the proposer), mirroring ratify
--   5. idea_inbox bookkeeping (416-424 resolved; 427 left open as the durable
--      world-expansion reference)
--
-- The 16 V2 + 6 V3 + 2 GDS-V4 tasks (with deps + criterion links) are created
-- by scripts/gds/seed-v2-world-tasks.js, run against the API after this deploys.
--
-- Idempotent: goals guarded by NOT EXISTS (version_id,title); criteria via
-- ON CONFLICT (version_id,criterion_id); karma via NOT EXISTS on a per-idea
-- reason marker; idea updates are naturally idempotent.

BEGIN;

-- Vanilla-safe guard (task 1264 / hardware-verify R63): everything below seeds
-- OTB *product* scope-truth (V2/V3 game-world planning). A vanilla Cloud Bongos
-- instance has no V2/V3 version rows — no migration seeds them (they were created
-- via the API on the OTB instance) — so each INSERT below would violate the
-- versions foreign key on a fresh DB. Wrap the seed in a DO block that no-ops
-- unless the product versions exist. (On the OTB instance this migration is
-- already recorded in schema_migrations and never re-runs; the guard only bites
-- on a fresh self-host DB — see docker-compose.yml / self-host.)
DO $seed$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM versions WHERE id IN ('V2','V3')) THEN
    RAISE NOTICE '172: V2/V3 product versions absent — vanilla instance, skipping OTB world-planning seed.';
    RETURN;
  END IF;

-- ---------------------------------------------------------------------------
-- 1. Goals (module-scoped workspaces, ADR 0086). created_by = 1 (Archon land).
-- ---------------------------------------------------------------------------
INSERT INTO goals (version_id, title, description, scope_modules, status, created_by)
SELECT 'V2', 'World engine (multi-map runtime)',
       'File-based maps, depth rendering, and per-map warp rooms. Engineering — touches protected game code (Metic+).',
       ARRAY['game']::text[], 'open', 1
WHERE NOT EXISTS (SELECT 1 FROM goals WHERE version_id='V2' AND title='World engine (multi-map runtime)');

INSERT INTO goals (version_id, title, description, scope_modules, status, created_by)
SELECT 'V2', 'Olympia art set',
       'Terrain, temple kit, and decor for Olympia on the locked 64-color palette. Design — art pipeline, open to any builder.',
       ARRAY['art-pipeline']::text[], 'open', 1
WHERE NOT EXISTS (SELECT 1 FROM goals WHERE version_id='V2' AND title='Olympia art set');

INSERT INTO goals (version_id, title, description, scope_modules, status, created_by)
SELECT 'V2', 'Olympia vertical slice',
       'Compose the walkable Olympia map from engine + art, second connected map, and score vs the reference.',
       ARRAY['game']::text[], 'open', 1
WHERE NOT EXISTS (SELECT 1 FROM goals WHERE version_id='V2' AND title='Olympia vertical slice');

INSERT INTO goals (version_id, title, description, scope_modules, status, created_by)
SELECT 'V3', 'Map authoring & editor',
       'In-house map editor that round-trips maps into the game. Deferred out of V2; depends on the V2 engine shipping first.',
       ARRAY['game']::text[], 'open', 1
WHERE NOT EXISTS (SELECT 1 FROM goals WHERE version_id='V3' AND title='Map authoring & editor');

-- ---------------------------------------------------------------------------
-- 2. done_when_criteria, parented to the goals above. criterion_md text is
--    lifted verbatim from the ratified proposals (ideas 416-422).
-- ---------------------------------------------------------------------------
INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, sort_order, goal_id)
VALUES
 ('V2', 'world-data',
  E'**The world loads from per-map data files, not hardcoded arrays — one source feeds both client render and server collision.**\n\n*Why:* retires the hand-mirrored map twins (`public/game/world/map.js` ↔ `src/world/map.js`, today''s top drift risk) and makes hand-designed maps possible.\n\n- A documented JSON map format at `public/assets/maps/<id>.json` with layers: ground (dense, drives autotile), decoration, objects, overlay; plus structures, warps, spawns.\n- A single shared parse + collision module (`mapFormat.js`) used by client and server; no duplicated map data.\n- Collision is *derived* from layers + structure solid-cells (generalizes today''s blocking-terrain / blocking-object rule).\n- ADR 0012 invariant intact: objects never pollute the ground autotile picker.\n- Today''s 26×20 room round-trips through the new format with identical render + walkability.',
  100, (SELECT id FROM goals WHERE version_id='V2' AND title='World engine (multi-map runtime)')),

 ('V2', 'walk-olympia',
  E'**A player can walk the Olympia Sanctuary in-game at the fidelity of the reference art.**\n\n*Why:* the vertical slice that proves the whole art + rendering direction before any expansion.\n\n- Temple of Zeus, Temple of Hera, the Altis grove, the plaza, and the stadium frontage are present and recognizable from the reference sheets.\n- The camera follows the player and scrolls a map larger than the viewport (canvas no longer equals map size).\n- Movement stays client-predicted / server-authoritative.\n- The scene is staged on the sandbox and walkable end-to-end.',
  200, (SELECT id FROM goals WHERE version_id='V2' AND title='Olympia vertical slice')),

 ('V2', 'depth-sort',
  E'**Tall structures render with correct depth — the player passes behind their tops and in front of their bases.**\n\n*Why:* 3/4-tilt temples, columns, and statues look wrong under today''s flat depth-0/1 layering.\n\n- 2.5D y-sort: player-plane objects and all character sprites share `depth = base*1000 + footY`.\n- An always-above overlay band carries structure tops (column capitals, roof crowns).\n- Reconciled with the existing autotile + interior-tile transform render path.\n- No z-fighting within a single structure''s footprint.',
  300, (SELECT id FROM goals WHERE version_id='V2' AND title='World engine (multi-map runtime)')),

 ('V2', 'connected-warps',
  E'**At least two connected maps with working warps — the player crosses between areas server-authoritatively.**\n\n*Why:* the classic Pokémon world model (overworld → enterable complex) the reference implies.\n\n- `mapId` in player state; one Colyseus room instance per map; per-map seating + queue.\n- Warp points move the player between maps at named spawns.\n- The 100-cap becomes per-map (overworld overflow can''t block Olympia).\n- Warping into a full destination map degrades gracefully (queue handoff).',
  400, (SELECT id FROM goals WHERE version_id='V2' AND title='World engine (multi-map runtime)')),

 ('V2', 'olympia-art-set',
  E'**The Olympia art set exists and passes the rubric on the locked 64-color palette.**\n\n*Why:* the slice cannot render without the terrain, building, and decor assets.\n\n- Terrain: marble plaza / flagstone, stone & cliff, river / water, forest + palm, grass variants — as autotile families where they tile.\n- Temple building kit: walls, columns / colonnade, orange-tile roof slopes, steps — authored as Pattern-B continuous illustrations sliced to the structure registry.\n- Decor: Zeus / Hera statues, altar-with-fire, amphorae, fountains.\n- All members land in the packed atlas + manifest; `tests/autotile_xverify.mjs` stays green.',
  500, (SELECT id FROM goals WHERE version_id='V2' AND title='Olympia art set')),

 ('V2', 'scored-vs-reference',
  E'**The Olympia slice is scored against the reference images, and the reference becomes the durable target.**\n\n*Why:* closes the loop — proves the criterion set actually produced the intended look.\n\n- The four reference sheets are ingested into `art/references/` as the durable target.\n- `otb-design-review` scores the new tiles ≥ the rubric threshold.\n- A before/after writeup lands in `docs/reviews/` with side-by-side screenshots vs the reference.',
  700, (SELECT id FROM goals WHERE version_id='V2' AND title='Olympia vertical slice')),

 ('V3', 'map-editor',
  E'**A lightweight in-house map editor lets a builder author maps that round-trip into the game.**\n\n*Why:* hand-editing JSON for scenes the size of Olympia doesn''t scale.\n\n- Paint ground with *live autotile preview* (imports the game''s `terrain.js`/`autotile.js` picker — no new autotile code).\n- Place objects + multi-tile structures; set warps, spawns, collision.\n- Save a valid map file (validated by the same `mapFormat` validator), persisted via the deploy-safe path (branch/PR per the save-model spike).\n- A map authored in the editor loads and plays in the game unchanged.',
  50, (SELECT id FROM goals WHERE version_id='V3' AND title='Map authoring & editor'))
ON CONFLICT (version_id, criterion_id) DO UPDATE
  SET criterion_md = EXCLUDED.criterion_md,
      sort_order   = EXCLUDED.sort_order,
      goal_id      = EXCLUDED.goal_id;

-- ---------------------------------------------------------------------------
-- 3. Version done_when text (broaden V2 to cover the walkable world; note the
--    editor carry on V3).
-- ---------------------------------------------------------------------------
UPDATE versions
   SET done_when = 'Other players are visible in a real, walkable world: a player walks the Olympia Sanctuary in-game at reference-art fidelity, with file-based multi-layer maps feeding both client render and server collision, correct depth-sorting on tall structures, at least two connected maps with server-authoritative warps, and the Olympia art set passing the rubric on the locked palette.'
 WHERE id = 'V2';

UPDATE versions
   SET done_when = COALESCE(done_when, '') ||
       E'\n\nAlso (folded in from the world-building plan): a lightweight in-house map editor lets a builder author maps that round-trip into the game (depends on the V2 world engine shipping first).'
 WHERE id = 'V3'
   AND done_when NOT LIKE '%in-house map editor%';

-- ---------------------------------------------------------------------------
-- 4. Karma to the proposer (#25), mirroring the ratify path (+5 each, x7).
--    Guarded per-idea so a re-run can't double-credit.
-- ---------------------------------------------------------------------------
INSERT INTO karma_log (builder_id, delta, reason, granted_by)
SELECT 25, 5, m.reason, 1
FROM (VALUES
  ('proposal_ratified:idea-416'),
  ('proposal_ratified:idea-417'),
  ('proposal_ratified:idea-418'),
  ('proposal_ratified:idea-419'),
  ('proposal_ratified:idea-420'),
  ('proposal_ratified:idea-421'),
  ('proposal_ratified:idea-422')
) AS m(reason)
WHERE NOT EXISTS (
  SELECT 1 FROM karma_log k WHERE k.builder_id = 25 AND k.reason = m.reason
);

-- ---------------------------------------------------------------------------
-- 5. idea_inbox bookkeeping.
--    416-422 (criterion proposals) + 424 (the umbrella) -> promoted.
--    423 (superseded umbrella v1) -> discarded.
--    427 (reference manifest, future world-scale) -> LEFT OPEN on purpose as
--        the durable expansion reference; 425/426 are promoted by the seed.
-- ---------------------------------------------------------------------------
UPDATE idea_inbox
   SET status = 'promoted', reviewed_at = now()
 WHERE id IN (416,417,418,419,420,421,422,424)
   AND status = 'open';

UPDATE idea_inbox
   SET status = 'discarded', reviewed_at = now()
 WHERE id = 423
   AND status = 'open';

END
$seed$;

COMMIT;
