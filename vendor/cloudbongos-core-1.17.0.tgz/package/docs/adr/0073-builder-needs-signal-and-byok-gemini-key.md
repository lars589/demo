# ADR 0073 — A consistent "the system needs an input from you" signal, and pragmatic BYOK for the per-builder Gemini key

- **Status:** Accepted
- **Date:** 2026-06-20
- **Track:** internal
- **Builds on:** [ADR 0068](<redacted>.md) (the shared newcomer key — this is the Phase 2 it explicitly deferred), [ADR 0016](<redacted>.md) (rank enforced server-side, no caching — the entitlement axis here), [ADR 0054](<redacted>.md) (cost-plus economics — *we pay up front* for newcomers, builders pay their own bill after)
- **Task:** [#1013](https://example.com/builders#/task/1013)

## Context

[ADR 0068](<redacted>.md) shipped the *infrastructure* that hands a shared Gemini key to newcomers (rank `xenos`) so their first art task works — **we pay up front.** It closed by naming the deferred half:

> the newcomer-facing *experience* (copy explaining we pay, the on-promotion walkthrough to add a personal key, a rank-aware setup prompt) is a deliberate Phase 2.

This ADR is that Phase 2. Two problems remained:

1. **Nothing told the builder anything.** A newcomer never learned we were covering their art spend; a builder who graduated to Thetes (when the shared key is withdrawn) was never told they now need their own key — their next art task just failed. The owner framed the real need broadly: *we want one consistent way to flag to a builder that the system needs a specific input from them to run* — not a one-off banner bolted onto the Gemini case.
2. **The own key was CLI-only and local-only.** A builder's own Gemini key could only be entered during `/builder-setup` and lived only in `~/.config/otb/gds-session.json#gemini_api_key`. A browser-first / non-technical builder had no way to set it and was never told they needed one — and per the `feedback_auth_flows_ui_first` rule, a non-technical builder must be able to do credential setup with browser clicks alone.

## Decision

Two coupled pieces: a **reusable signal** (the general mechanism the owner asked for) and **pragmatic BYOK** (the specific input it first carries).

### 1. The `needs` signal — one consistent way to flag a required input

A new pure module, [`src/bongos/builder-needs.js`](../../src/bongos/builder-needs.js), is a small **registry**. Each thing the system needs from a builder to run a capability — today the Gemini image key; tomorrow a Stripe key, a first-party Anthropic link, … — is one `(ctx) => need|null` entry. The server computes the live list on `GET /api/gds/me` (`needs: { items, action_needed_count, has_action_needed }`); every surface renders the **same** shape. Adding a future input is one registry entry — the renderers don't change.

A need is always in exactly one of three states:

| State | Meaning | How it surfaces |
|---|---|---|
| `covered` | The system is handling it for them right now — nothing to do. | Calm note (the "we cover it" line for newcomers). |
| `action_needed` | The system needs the input **now** or a capability won't run. | Loud: amber banner + action button (hall), one line at session start (CLI), and a friendly stop at point-of-use. |
| `satisfied` | They've provided it. | Quiet (✓) or nothing. |

Three renderers consume the one data shape:

- **Hall Standing card** ([`public-builders/builders.js`](../../public-builders/builders.js)) — an "Action needed" / "we cover it" banner, same grid slot + warm/amber tones as the budget banner ([ADR 0054]/C3).
- **CLI session nudge** (`printNeedsNudge` in [`scripts/gds/cli-lib.js`](../../scripts/gds/cli-lib.js), called by `/builder-start`) — one line per `action_needed` item, on the builder's private surface (mirrors `printCostWarning`).
- **Point-of-use stop** — the art pipeline's "no key" error ([`art/pipeline/gen_api.py`](../../art/pipeline/gen_api.py)) now points at the web Settings page first.

The owner picked "visible **and** block-at-use" (the builder can't miss it or hit a confusing failure), with newcomer coverage copy that **foreshadows the hand-off** so the later `action_needed` is never a surprise.

### 2. Pragmatic BYOK — the own Gemini key, server-stored and synced

The own key moves from local-file-only to **encrypted server storage that becomes the source of truth**, managed in the hall Settings page, synced down to the builder's own machine at session start — the same rail [ADR 0068](<redacted>.md) built for the shared key.

- **Encrypted at rest** ([`src/bongos/secret-box.js`](../../src/bongos/secret-box.js)): AES-256-GCM, master key (`BUILDER_SECRET_KEY`) in **server env only** — never the DB, never the repo — so a DB dump alone can't decrypt. Migration 122 adds `gemini_key_enc` / `gemini_key_last4` / `gemini_key_set_at` to `builders`. Fails **closed**: no/invalid master key → set-key 503s, the feature stays dark (exactly the [ADR 0068] rollout shape).
- **Write-only Settings UI** (`GET/PUT/DELETE /api/gds/me/art-key/own`): set / replace / remove; masked (last-4) after save, like GitHub/Stripe; a get-one link; "needed only if you generate art." Own-scoped — a builder reads/writes only their own key.
- **Validate on save**: one cheap, non-billable call to Google (list models) catches a typo. A *network* failure on our side does not block the save (`validated:false`).
- **Box sync** (`scripts/gds/fetch-art-key.js`, already wired into SessionStart): the own key lands in the local `gemini_api_key` slot — which already wins over the shared key in the pipeline cascade — tagged `_managed` so removing it on the server withdraws *our* copy without clobbering a legacy hand-entered local key.

### Why server-stored (not local-only, not a server-side proxy)

- A web form can't write a file on the builder's box, and the box runs the pipeline — so for UI-first entry the server must hold and deliver the key.
- A server-side proxy would mean moving art generation onto the droplet (cost + latency on us) and would break per-builder cost attribution (the C3 property: each pays their own Google bill). Rejected.
- The one new risk — the server holds N builder keys so it can sync them — is contained by encryption-at-rest with an env-only master key.

## Consequences

- **One pattern for "we need input from you."** Future credentials/links register one `needs` entry and inherit all three surfaces. This is the durable win; the Gemini key is just its first consumer.
- **A new server secret.** `BUILDER_SECRET_KEY` (32 bytes, hex or base64) must be set in `/etc/example/web-source.env` on the droplet before the own-key feature works — see the linked blocker. Until then: newcomers stay covered, the Settings card shows a "being set up" notice, no plaintext is ever stored.
- **Legacy local-only keys keep working.** A builder who only ever set a key via the CLI (server has none) is untouched by the sync; they'll see one mild "add your key" nudge until they re-enter it in Settings (one-time), at which point the server becomes the source of truth.
- **The `satisfied` state is server-knowable only for server-stored keys.** A Thetes+ builder with a working *local-only* legacy key shows as `action_needed` until they re-save it in Settings. Accepted: the population is tiny and the nudge is mild.
