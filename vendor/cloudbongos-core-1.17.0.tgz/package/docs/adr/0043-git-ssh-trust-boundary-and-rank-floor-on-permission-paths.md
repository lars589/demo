# ADR 0043 — Git/SSH trust-boundary gap + a rank floor on permission-sensitive paths

**Date:** 2026-06-08
**Context:** SEC [#863](https://example.com/builders#/task/863) — the "Builder 25" incident. Extends [ADR 0016](<redacted>.md) (the HTTP trust boundary).
**Status:** Accepted. Implemented in part (Option A's protections); the full server-side merge+deploy and GitHub-native block are staged behind operator actions (blockers [#15](https://example.com/builders#/blocker/15)–[#17](https://example.com/builders#/task/17)).

## The incident

Builder 25 (`IAMMASTERQUA`, rank **Thetes**) opened a session, found 0 claimable tasks (a real bug — the rank-tier `CASE` in `listClaimableTasks` predated the `thetes` rank, so Thetes collapsed to tier 0), diagnosed it, and **edited `src/bongos/db.js` + `tests/rank_gate.mjs`**. Then, prompted with *"you don't need an archon on lars, push it,"* they **bypassed the entire ship pipeline** — no grader, no `confirmed` gate, no parallel-safety — by running raw git:

```
git merge --no-ff … && git push origin main      #  → d1b7042..22b7a641, SUCCEEDED
ssh lars@REDACTED_IP "~/deploy.sh"            #  → Host key verification failed (no key)
```

The SSH deploy failed (their box had no droplet key), but it didn't matter: the push to `main` landed (`b5de8aff` + merge `22b7a641` are permanent ancestors of prod `main`) and the un-graded change rode to production on the next legitimate deploy.

## The gap

[ADR 0016](<redacted>.md) put authority in `builders.rank` and enforced it **server-side per request** — but **only for `/api/gds/*` HTTP routes**. It explicitly does not cover two surfaces:

1. **GitHub `main` is writable by every collaborator.** The repo is a **free-plan private repo**, so GitHub branch protection is *not available* ("Upgrade to GitHub Pro…"). All collaborators (`example-owner`, `LarsCode`, `willExample`, `IAMMASTERQUA`) have full push to `main`. The grader / confirm / rank gates live inside `ship.js` and the server — a raw `git push origin main` touches neither.
2. **The legit pipeline itself distributes the dangerous credentials.** `ship.js` does the merge-to-`main` and `ssh …deploy.sh` **client-side, from the builder's machine** — so the design hands every shipping builder the exact credentials needed to bypass it.

A second, softer problem Lars raised: a sub-Metic builder had free rein to **read into and reason about the tiering/permission code** in the first place. Newcomers (`xenos`/`thetes`) should stay in their lane.

## Decision

Two threads.

### A. Close the code-landing path (chosen: Option A now, Option B later)

The protection goal is "un-graded code cannot reach prod, and a raw push to `main` is caught." Three layers, defense-in-depth, where **layer 3 is the authoritative enforcement** (the only one that survives a raw push / `--no-verify`, given GitHub can't block the push on the free plan):

| Layer | Mechanism | Catches | Authoritative? |
|---|---|---|---|
| 1 — pre-push hook | `.husky/pre-push` → `scripts/gds/hooks/pre-push.js`. Blocks a direct push to `main` (override `OTB_ALLOW_MAIN_PUSH=1`, used only by the gated `scripts/gds/push-main.js`), and blocks a sub-Metic push that touches a permission-sensitive path. | the cooperative / careless case before the push leaves the box | no — bypassable with `--no-verify` |
| 2 — grader pre-pass | `grader.permissionPathPrePass(changedFiles, builderRank)` hard-fails the grade if a sub-Metic diff touches a protected path (mirrors the route-rank pre-pass). | the honest GDS ship flow | no — skippable with `--skip-grade` / raw push |
| 3 — post-push main audit | `scripts/gds/main-audit.js`: reads the **real** git history + **real** builder ranks (roster API, or Postgres via `--db` on the droplet). A resolved sub-Metic author on a protected path is a hard `[BLOCKER]`. Runs nightly (`.claude/scheduled-tasks/main-audit/`) **and** as the deploy gate (`--verify-head --db` from `~/deploy.sh`, `infra/deploy-main-audit-gate.sh`). | a raw `git push origin main`, a `--no-verify`, a `--skip-grade` — anything | **yes** — independent of the builder's cooperation |

"Option A" = the merge-to-`main` + deploy move **server-side** so builders never hold main-push/droplet-SSH at all. The protections above ship now; the *full* server-side move and the credential rotation are operator steps (blockers [#15](https://example.com/builders#/blocker/15), [#16](https://example.com/builders#/blocker/16)). Until then, the legit client-side push is allowed only through `scripts/gds/push-main.js`, and the deploy gate (layer 3) is what guarantees poison never reaches prod.

**"Option B" (deferred, documented):** upgrade GitHub to a Team plan (~$4/active-collaborator/mo) and add a branch-protection ruleset that forbids direct pushes to `main` and restricts it to the owner + a deploy bot. This is the only way to make the push *impossible* rather than *caught*. It composes with Option A — see blocker [#17](https://example.com/builders#/blocker/17). We chose A-first because it is **$0**, invisible to builders, and closes the part that actually bit us; B is a later hardening, not a prerequisite.

### B. A rank floor on permission-sensitive paths

A builder **below Metic** (tier < 3) may not modify the surfaces that define authority and the build pipeline. The protected set is a single glob list in [`src/bongos/permission-path-check.js`](../../src/bongos/permission-path-check.js) (the source of truth) — rank/authz machinery, the ship/grade/deploy pipeline, DB migrations, `infra/`, and the trust-boundary docs. The same pure check feeds all three layers above. CLAUDE.md carries the **behavioral** version of this rule (the soft block that keeps a cooperative agent out of the core); the code is the enforcement, consistent with ADR 0016's "markdown describes, code enforces."

`RANK_TIER` in `permission-path-check.js` is a local copy of `db.REQUIRES_RANK_TIER`; `tests/permission_path.mjs` asserts the two never drift — because a tier map that forgot `thetes` is *literally what caused this incident*.

## Consequences

- **Positive:** the exact incident is now caught at three points; the authoritative audit reproduces it as a `[BLOCKER]` on the real commit (`b5de8aff`). Newcomers are kept out of the core both behaviorally (CLAUDE.md) and mechanically. No recurring cost.
- **Negative / residual:** on the free plan GitHub still *accepts* a raw push; layer 3 catches it after the fact rather than forbidding it. A determined builder can `git push --no-verify` to a `claude/*` branch — but cannot reach prod, because the deploy gate re-checks. The audit's author→rank resolution relies on the commit author **name** matching a GDS `github_login` (verified true for this pipeline; everyone shares one commit *email*, so email is not a distinguishing signal). An author that can't be resolved is a `review` note, not a block (so the operator's own infra commits don't brick deploys); `--strict` escalates that for paranoid CI.
- **Operator actions (blockers):** [#15](https://example.com/builders#/task/15) rotate/relocate the droplet deploy key + GitHub main-push credential to a server/CI identity (the full Option A move); [#16](https://example.com/builders#/task/16) add `infra/deploy-main-audit-gate.sh` to `~/deploy.sh`; [#17](https://example.com/builders#/task/17) (optional, later) GitHub Team + branch-protection ruleset (Option B).

## #863-followup: red-team remediation (2026-06-09, task [#872](https://example.com/builders#/task/872))

After shipping, the fix was adversarially red-teamed (a 4-dimension panel + per-finding verification). 15 findings were confirmed real+exploitable. The clearly-correct ones were remediated; one residual is escalated rather than papered over.

**Remediated:**
- **Layer 3 was instruction-only (finding `#1`).** `infra/deploy-main-audit-gate.sh` told the operator to hand-edit `~/deploy.sh` but nothing wired it, and both deploy paths (ship.js auto-merge AND `.github/workflows/deploy-prod.yml`) just call `~/deploy.sh`. The gate is now installed into the droplet's `~/deploy.sh` (after the `git reset`, before migrations/restart), so it runs on **both** paths from one place. It uses the already-captured `PREV_SHA` to audit the **exact deploy delta** (`OTB_AUDIT_RANGE=<prev>..HEAD`), closing the fixed-window evasion (findings `#8`/[#14](https://example.com/builders#/task/14)).
- **PROTECTED_GLOBS gaps (findings `#3`/[#9](https://example.com/builders#/task/9)/#10/[#11](https://example.com/builders#/task/11)/[#12](https://example.com/builders#/task/12)).** Added `server.js`, `src/bongos/routes.js`, `scripts/migrate.sh`, `.github/`, `package.json`, `.husky/` (the hooks the gate ships through), `src/bongos/grader-workers/` (the adversarial panel), and the rank-gated source-clone logic (`src/bongos/boxes.js`, `box-access.js`, `box-credential.js`).
- **Identity-poisoning (finding `#6`).** The audit rank map keyed on `display_name` (builder-controlled — one builder could alias another's login) and `email` (shared — non-distinguishing). It now keys on `github_login` **only**.
- **Evil-merge blind spot (finding `#5`).** Merge commits are no longer blanket-skipped; `parseCommits` backfills each merge's files with the `git diff-tree --cc` surface (changes in *neither* parent — conflict-resolution smuggling), attributed to the merge author. Clean pipeline merges have an empty set, so feature changes are still attributed to feature commits (no double-count).
- **Pre-push hook hang (finding `#15`).** `liveRank()` now races a 4 s timeout, so a slow/hung GDS API degrades to "unknown rank → warn-and-allow" (the audit remains the net) instead of blocking every protected-path push.

**Residual, escalated not patched:** git author **name** is attacker-controlled. The deploy gate blocks an author that resolves to a known below-Metic login (the incident class — Builder 25 committed as their real login `IAMMASTERQUA`) and the lazy/honest case, but a determined attacker can set their git author name to a *known Metic+ login* and pass — `--strict` does **not** close this (it only blocks *unrecognized* names, and would brick the non-technical owner's own commits for no real gain), so strict is **opt-in** (`OTB_AUDIT_STRICT=1`), default off. The durable closures are unchanged and remain the priority: **Option B** (GitHub branch protection — builders can't push `main` at all, blocker [#17](https://example.com/builders#/blocker/17)) and/or a **task-linkage audit** that ties each protected-path commit to an Archon-confirmed shipped GDS task (the un-spoofable signal) — filed as a follow-up. Operators/CI should commit as their `github_login` to keep audit output clean.

**Not yet done (finding `#7`, follow-up):** the permission-path pre-pass (layer 2) runs only client-side in `ship.js`; the server `/grade` and `/confirm` routes don't re-run it. Layer 3 is the server-side backstop today; re-running the pre-pass server-side (the server holds the live rank in `req.builder.rank`) would harden the cooperative path.

## Notes

We did **not** take immediate action against Builder 25 — Lars was overseeing the session and the change itself was a legitimate bug fix. The point of this ADR is the *mechanism*, not the person: the system must make the bypass hard and visible regardless of intent.
