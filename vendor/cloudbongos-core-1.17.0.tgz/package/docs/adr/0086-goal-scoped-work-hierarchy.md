# 0086 — Goal-scoped work hierarchy: assign goals, not tasks

- **Status:** Accepted (design recorded; build is task-pending via a planning session)
- **Date:** 2026-06-23
- **Deciders:** Lars (Archon), Claude

**Builds on:** [ADR 0016](<redacted>.md) (server-enforced rank boundary), [ADR 0025](<redacted>.md) (structured criterion↔task link), [ADR 0043](<redacted>.md) (protected paths + rank floor), [ADR 0049](<redacted>.md) (`touches[]` advisory), [ADR 0062](<redacted>.md) (instance/host decoupling — the config-preset pattern), [ADR 0083](<redacted>.md) (modular architecture — "a task is scoped to a module"), [ADR 0084](<redacted>.md) (auto-derived per-task rank floor), [ADR 0015](<redacted>.md) (task dependencies + auto-promotion), [ADR 0054](<redacted>.md) (cost-plus reward).

**Track:** `internal` (GDS / methodology — a Cloud Bongos platform capability).

---

## Context

Today only the Archon can create or edit tasks — `POST /tasks` and `PATCH /tasks/:id` are both `requireRank('archon')` ([`src/bongos/routes/tasks.js`](../../src/bongos/routes/tasks.js)). Lower-ranking builders (`xenos`, `thetes`) can only **file ideas** into `idea_inbox`; they have no ability to shape their own work toward an objective.

> **Update (2026-06-26, [ADR 0090](<redacted>.md)):** `POST /tasks` / `PATCH /tasks/:id` are now `requireRank('metic','archon')` — a *Metic* may author tasks directly. This ADR's goal-scoped, module-fenced authoring path (`POST /goals/:id/tasks`) is now the mechanism for **sub-Metic** ranks (`xenos`/`thetes`) specifically; everything below about the scope-subset wall and protected-path block is unchanged and still governs that path. Every task must be hand-authored by the owner first — a delegation bottleneck that wastes capable builders' judgment, and the opposite of the AI-first norm where agents do the building.

Lars's directive (2026-06-23): **stop assigning individual *tasks*; assign *goals*.** A builder working toward a goal should be able to **author and organize their own tasks** beneath it — but only within a **module scope** they cannot exceed, and never in a way that lets someone "pick a goal and then create tasks that hack stuff."

This slots directly into the modular architecture: [ADR 0083](<redacted>.md) Rule 5 already states *"a task is scoped to a module."* Goals are the mechanism that turns that rule into a **live, enforced permission** rather than a convention.

The structure decided over a design session is a six-tier hierarchy — most of which **already exists** in the GDS. Only **Goal** is a genuinely new tier:

| Tier | What it is | In the system today |
|---|---|---|
| **Project** | the instance itself (Example) | implicit (one project per install) — becomes a config preset |
| **Version** | a scope phase that sets goals | ✅ `versions` |
| **Goal** | a shared, module-scoped workspace | 🆕 **the one new tier** |
| **Criteria** | the tests for "goal met" | ✅ `done_when_criteria` — re-parented version → goal |
| **Task** | work fulfilling a criterion | ✅ `tasks` (link to criteria via `task_criteria`) |
| **Sub-task** | a task broken down | ✅ `tasks.parent_task_id` (one level) |

---

## Decision

**We will introduce a `goal` tier and reorganize work tracking into a six-level hierarchy — Project → Version → Goal → Criteria → Task → Sub-task — whose *structure* is a per-instance config preset (owner-set at onboarding) and whose *enforcement* is core. A goal is a shared, joinable, module-scoped workspace: joining it grants bounded authority to author tasks within the goal's modules, with scope set by a trusted rank and never self-granted.**

### 1. The hierarchy is a configurable preset (onboarding)

The tier set is host-configured, not hardcoded — the [ADR 0062](<redacted>.md) core/host pattern applied to the work model.

- A new **`config/hierarchy.json`** (joins `branding.json` / `modules.json` as host config; loaded by a `hierarchy-config.js` mirroring `src/modules.js`) declares the tiers — names, order, and which tier carries **scope**, **membership**, and **criteria**. Example ships the six-tier preset above; the project owner fills/edits it **during onboarding**.
- **v1 scope of "editable":** the standard tier set with owner-set labels, enable/disable, and which tier owns scope/criteria/membership. Fully *arbitrary* custom tier graphs are a later extension — explicitly not built now.

### 2. The Goal tier (shared, module-scoped) + criteria re-parenting

- **New `goals` table** — sits between `versions` and `done_when_criteria`. New (not `parent_task_id`: one-level, task lifecycle; not `done_when_criteria`: that *is* the criteria tier). Carries: `version_id`, `title`/`description`, **`scope_modules text[]`** (the wall), `status` (`open|achieved|archived`), `created_by`, `succeeded_by_goal_id` (rescope carry-forward).
- **Goals are shared, not owned** — a new **`goal_members`** table (many builders ↔ one goal; `lead`/`member` roles). **Membership**, not a single assignee, is what grants bounded task authoring.
- **Criteria re-parent under goals** — `done_when_criteria` gains a `goal_id` (backfill existing version criteria under a per-version default goal). A version is "done" when all its goals are achieved; the `/status` rollup becomes **Version → Goals → Criteria → Tasks** (extends [ADR 0025](<redacted>.md)).
- **Tasks** gain `goal_id`; sub-tasks remain `parent_task_id`; a task fulfils a criterion via the existing `task_criteria` link.

### 3. Bounded task authoring (membership grants it; the create-time gate)

- **`POST /goals`** — `requireRank('metic','archon')`; **Archon-only when `scope_modules` includes a `protected` module.**
- **`POST /goals/:id/join` / `leave`** — open join for normal goals; **joining a sensitive-scope goal needs Archon approval** (reuse the access-request pattern, [`access-requests.js`](../../src/bongos/routes/access-requests.js)).
- **`POST /goals/:id/tasks`** — `requireBuilder` + an in-handler gate (the maneuverability grant), ordered + fail-closed: goal `open` and **caller is a member** (or Archon); version guards reused from `POST /tasks`; **scope subset** — every `touches[]` element covered by the goal's `scope_modules` globs (`touchesOverlap`, [`path-match.js`](../../src/bongos/path-match.js)); **protected-path block** — `checkPermissionPaths` ([`permission-path-check.js`](../../src/bongos/permission-path-check.js)) so a sub-Metic member cannot author a task touching the protected core; then `db.createTask` stamping `goal_id`. `POST /tasks` / `PATCH /tasks/:id` stay byte-identical (Archon-only) for ungoverned creation.
- **Rank floor is auto-derived, not a bespoke cap.** Per [ADR 0084](<redacted>.md), a created task's `requires_rank` is auto-derived from its touches + sensitivity (`deriveRequiredRank` → `metic` for protected/sensitive, else `xenos`) and can only be raised. So a goal member need not (and cannot) self-set a rank that escapes their own gate — and a sensitive task auto-floors to `metic`, which a sub-Metic author could not claim. No new cap mechanism; this composes with the one that already exists.

### 4. The scope wall (set by the planner, never self-granted; "ask to widen")

- **New `src/bongos/module-scope-map.js`** — each module key → its path globs + a `protected` flag, for the full ~16-module roster from the [modular-architecture design](../design/modular-architecture/02-module-map.md). `protected: true` where globs intersect `PROTECTED_GLOBS` ([ADR 0043](<redacted>.md)) — the lifecycle/ship-pipeline, migrations, security, authz core. It **auto-tightens** as [ADR 0083](<redacted>.md) moves code into `modules/<key>/`, converging on that ADR's task→module affinity (where `touches[]` retires in favour of the module label + a ship-time diff⊆module check). The carve precedes the feature (Lars: "carve more modules first").
- A goal's `scope_modules` is set by the assigner at planning time — the **one moment scope is defined**, which is precisely why it is **never self-granted**. Widening goes through a request a trusted rank approves (Archon for a protected module).

### 5. Dependencies

- **One polymorphic "blocked-until-done" edge** — a new `dependencies(from_kind, from_id, to_kind, to_id)` over `{task, goal, criterion}`; the existing `tasks.dependencies[]` (task→task) migrates in. "Done" = task/sub-task `shipped`, criterion `satisfied`, goal `achieved`.
- **One enforcement point** — it resolves down to the existing **claim gate** ([ADR 0015](<redacted>.md)): claiming a task checks its own deps plus deps inherited from its goal/criterion; achieving/shipping a node auto-promotes its dependents.
- **Cross-goal and cross-version is allowed** (Lars, 2026-06-23). A dependency is a **reference, not a grant** — it never widens module scope, so cross-module deps are safe; cross-goal deps become the visible coordination contract between two shared workspaces. Containment (the tree) is never a dependency; the graph is acyclic.

### 6. Achievement (auto-flag → planner review → auto-achieve) + lifecycle

- **Auto-flag.** When every task linked to a criterion has shipped, the server **auto-flags that criterion "met — pending review"** — deterministic, from the `task_criteria` links + ship status, no manual propose step (a `pending_review` flag; the existing `satisfied` bool is set on confirm).
- **Planner reviews, obviously and triage-style.** Flagged criteria surface as a clear review queue, walked one-at-a-time via a new **`/goal-review` skill** that mirrors `/idea-triage` (confirm / reject / note). The **planner (Metic+)** confirms — resolving "who confirms" so the Archon is not in every goal's closing loop. (This re-ranks the existing criterion-satisfy route from Archon-only to Metic+.) Confirming a goal's last criterion **auto-flips the goal `open → achieved`**.
- **Lifecycle / rescope.** `open → achieved → archived` (archived is re-openable). The same `/goal-review` cadence dispositions achieved goals (archive vs carry forward). At version rescope (next `/planning-session`), achieved goals are carried forward (`succeeded_by_goal_id`) or replaced — "previous or new" at each tier.
- **`/planning-session` becomes the scope phase, levelled up:** it defines a version's **goals**, each with its **criteria** and **module scope** (and optional seed tasks/join policy), uploaded atomically as today; sensitive-scope goals get Archon sign-off there.

### 7. How the boundary holds (reuse + defense-in-depth)

The create-time gate sees only *declared* touches (advisory — git merge is the real collision detector, [ADR 0049](<redacted>.md)), so it is the first filter, **not** the enforcement boundary. The existing **ship-time gates remain authoritative on the real diff**: the grader's `permissionPathPrePass`/`routeRankPrePass` + `serverSideGuards` ([`grader.js`](../../src/bongos/grader.js)), the `gate-review` ESCALATE floor, and the post-push `main-audit`. A mis-declared task still cannot *merge* if its real diff hits protected paths. Two CI fitness checks ([`fitness.js`](../../scripts/gds/fitness.js)) guard drift: goal routes are pinned in `route-rank-check.EXPECTED_RANKS`, and the scope code must *import* `PROTECTED_GLOBS`, never re-declare it.

### Deferred (explicit non-decisions)

- **Rewards** — whether *achieving a goal* earns anything beyond the per-task cost-plus already paid ([ADR 0054](<redacted>.md)), and how any reward splits among a goal's members. The leaning is karma by default (budget-safe, since drachmae are real money) with contribution-weighted splits, but this is **not yet decided** and rides a follow-on.
- **A sub-Metic builder joining a protected-scope goal** — letting a newcomer work *inside* the dangerous core under a tightly-scoped, Archon-granted goal amends the [ADR 0043](<redacted>.md) hard floor (and needs the ship-time gates to become goal-aware). Deliberately **last**, behind its own security-reviewed ADR. Until then, protected-scope goals require a Metic+ holder.
- **An AI relevance / anti-hack judge** at create/claim time (reusing the grader subagent harness; advisory-first, flag-for-Metic, never hard-blocking a newcomer) — a later phase; the deterministic scope + protected-path gates ship first.

---

## The build plan (phases → planning-session tasks)

Each phase ships independently; implementing tasks are created via `/planning-session` under the live internal version (a criterion cluster alongside the [ADR 0083](<redacted>.md) BV1 module work).

| Phase | Delivers | Depends on |
|---|---|---|
| 1 · Carve + config | `module-scope-map.js` (roster + `protected` flags); `config/hierarchy.json` + `hierarchy-config.js` (preset, onboarding-edited) | — |
| 2 · Goal entity | migration (`goals`, `goal_members`, `done_when_criteria.goal_id` + backfill, `tasks.goal_id`); `db.js` helpers; `/status` rollup through goals; join/leave + goal view + `?goal_id=` filter | 1 |
| 3 · Bounded authoring | `goal-scope-check.js` (pure); `routes/goals.js` create gate; sub-tasks; fitness checks; abuse-matrix tests | 1, 2 |
| 4 · Deps + achievement | polymorphic `dependencies` + claim-gate resolution; criterion auto-flag → `/goal-review` (confirm/reject) → goal auto-achieve; archive/reopen + rescope carry-forward; "ask to widen"; ideas-promote-to-any-tier | 2, 3 |
| 5 · (own ADR) | AI relevance judge; sub-Metic membership in protected-scope goals | 3, 4 |

---

## Alternatives considered

- **Reuse `parent_task_id` for goals (a goal = a parent task) — rejected.** One-level cap ([`hierarchy.js`](../../src/bongos/hierarchy.js)), wrong lifecycle (a goal is a standing grant, not shippable work that earns credit on ship), and a task has no place for scope or membership.
- **Reuse `done_when_criteria` as goals — rejected.** That table *is* the criteria tier; overloading it with membership + a creation grant conflates "definition of done" with "who may do work." A goal *links to* criteria; it is not one.
- **Single-owner goals — rejected** (Lars). Goals are shared workspaces; a single assignee would force mega-claims and block collaboration. Membership grants the authority; contribution (not membership alone) is what any future reward weights on.
- **A bespoke per-task rank cap at goal-create — rejected in favour of [ADR 0084](<redacted>.md).** The auto-derived floor already prevents a member minting a task that escapes their gate; a second mechanism would be a second list that drifts (the SEC [#863](https://example.com/builders#/task/863) failure mode).
- **Restrict dependencies to within a single goal — rejected** (Lars). Real dependencies cross goals; self-containment forces mega-goals or fakery. A dependency is only a reference, so cross-goal is safe and surfaces coordination.
- **Hard-code the hierarchy / build a full tier-editor UI now — both rejected.** A config preset edited at onboarding (the [ADR 0062](<redacted>.md) pattern) is the right middle: configurable per instance without a heavy runtime editor.
- **Open task creation to all ranks generally (no goal) — rejected.** That removes the scope wall entirely; the whole safety model is that authority is *bounded by an assigned goal's modules*, not granted by rank alone.

---

## Consequences

**Positive.** Lower-rank builders gain real maneuverability (author + organize their own work) without weakening the trust boundary — authority is bounded by an assigned, module-scoped goal and enforced server-side. It fills [ADR 0083](<redacted>.md) Rule 5 and reuses almost everything (versions, criteria, tasks, sub-tasks, the protected-path matcher, the auto-derived rank floor, the dependency/auto-promotion engine, the access-request pattern, the idea-triage cadence shape). The "carve more modules first" map is also an ADR-0083 deliverable. Each phase ships independently and is individually revertible.

**Negative / cost.** Schema changes to two core tables (`done_when_criteria` re-parenting under goals; `tasks.goal_id`) plus new `goals`/`goal_members`/`dependencies` tables and a criteria backfill — touches the lifecycle/`migrations` core, so those PRs ride the gate hard-floor and need owner sign-off (the boundary working as designed). The `/status` rollup, `/planning-session`, and the criterion-satisfy route all change. It is a deliberate **widening of the trust boundary** (sub-Metic builders can now create tasks), justified by the layered scope + protected-path + auto-rank-floor + ship-gate defenses; that widening is exactly why this is its own ADR.

**Neutral.** The reward model and sub-Metic-in-protected-scope membership are deferred to follow-ons; until they land, behavior is conservative (no goal bonus; protected-scope goals need a Metic+ holder). The configurable hierarchy ships as a preset; arbitrary tier graphs remain a future fork, not foreclosed.
