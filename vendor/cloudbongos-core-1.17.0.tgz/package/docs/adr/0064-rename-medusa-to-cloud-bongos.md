# ADR 0064 — Rename the platform: Medusa → Cloud Bongos

- **Status:** Accepted
- **Date:** 2026-06-19
- **Track:** internal
- **Amends:** [ADR 0062](<redacted>.md) (the instance-model build platform, formerly named "Medusa"). The 0062 architecture — portable core / host instance / gated feature-modules, the branding contract, feature-module selection — is **unchanged**; only the platform's name changes.
- **Task:** 1242 (this rename). Sibling: task 1216 / V4.R74 (the Cloud Bongos visual brand pack — the look this name wears).

## Context

The build platform decoupled out of the GDS in [ADR 0062](<redacted>.md) was named **Medusa** (a working name from the 2026-06-17 planning session). While designing the vanilla "customer 0" brand pack (task 1216 / V4.R74), the owner settled on a different identity and renamed the platform to **Cloud Bongos** — a light, joyful, "playing in the clouds" developer tool where *building software is laying down a beat*.

The visual direction is recorded with the brand pack (task 1216), not here: a Lion-King sunrise backdrop, Apple-style liquid-glass "cloud" cards, a bongo-pair mark with an equalizer/beat motif, and the type pairing **baloo 2** (lowercase wordmark) · **Quicksand** (interface) · **Fira Code** (numbers & code). *This* ADR records only the name and the rename's scope.

## Decision

1. **The platform is named Cloud Bongos** (was "Medusa"). This is the whole platform: the product name, the AGPL open-source project (C9 / R68–R73), the future `cloudbongos` CLI (`init`/`upgrade`, R65/R72), the canonical config identity, and all forward-facing docs.
2. **Scope = whole-platform rename, history preserved** (owner choice, 2026-06-19). Forward-facing surfaces are renamed; the historical record keeps "Medusa" as what was decided when, each reachable via this ADR.
3. **Canonical identity** lives in `config/branding.neutral.json` (customer 0): `identity.productName` / `identity.worldName` = `"Cloud Bongos"`, `envPrefix` = `"CLOUDBONGOS"`. The branding contract resolver and schema (ADR 0062 §3, `src/branding.js`) are unchanged — only the values move; `tests/branding.mjs` updated to match.
4. **The Greek rank ladder (Xenos · Thetes · Metic · Archon) is unchanged.** It is core methodology, not brand flavor (locked in the 0062 planning); the rename does not touch it.
5. **Capitalization:** the wordmark renders lowercase ("cloud bongos"); prose and identifiers use "Cloud Bongos".

## What this touches

**Renamed now (forward-facing):**
- `config/branding.neutral.json` (identity + envPrefix) and `tests/branding.mjs`; `src/branding.js` default env prefix.
- `CLAUDE.md` methodology-core framing (platform-name references; the §13 session-log index is left as history).
- `docs/branding-contract.md`, `docs/branding-fill-prompt.md`, `docs/project-context.md`, `docs/project-context.template.md`.
- Comments in `scripts/gds/fitness.js` and `scripts/gds/gen-repo-map.js`.
- This ADR + the [ADR index](README.md) row; a pointer note on ADR 0062.
- **Live DB strings** (follow-up, task 1244 / migration `<redacted>.sql`): the GDS-V4 **C8 + C9** done-when criteria and the **R67** proof-task title/description — rewritten forward because the API serves them to users (/status, the hall, /recall). Display text only; the `medusa-*` `criterion_id` keys and the `schema_migrations` version strings are untouched.

**Left as history (NOT rewritten):**
- ADR 0062 body (carries a pointer note to here), [ADR 0063](<redacted>.md).
- `docs/session-logs/<redacted>.md` and other logs.
- Applied migrations `110_medusa_planning_seed.sql`, `<redacted>.sql` (immutable once applied).
- `scripts/gds/seed-medusa-tasks.js` (the historical seed tooling; its filename and the **other 23** V4.R50–R74 task titles/descriptions that say "Medusa" — the R67 proof task + the C8/C9 criteria were rewritten live via migration 114 / task 1244; the rest stay as history per the owner's choice).
- `docs/repo-map.md` (generated — regenerates on deploy).

## Consequences

- `envPrefix: "CLOUDBONGOS"` only changes a *fresh* instance's branding env-**override** variable names (e.g. `CLOUDBONGOS_PUBLIC_ORIGIN`). Customer 1 (Example / OTB) keeps `OTB_*`; no live instance used a `MEDUSA_*` **branding-override** prefix, so there is nothing to shim there. *(Separately, the R52 migration-mode flag `MEDUSA_GDS_ONLY` in `scripts/migrate.sh` — a different namespace, not the branding prefix — does still carry the old name; it is unset by every live instance, so it is harmless today, and is slated for a neutral rename under V4.R71. Tracked in task 1244.)*
- Follow-on work inherits the new name: the visual brand pack (task 1216 / V4.R74); the config-namespace + env/CLI rename with back-compat shims (V4.R71) now targets the Cloud Bongos namespace; the AGPL repo + governance docs (C9, R68–R73) use "Cloud Bongos."
- A transitional split is expected and intentional: forward docs say "Cloud Bongos," the 0062-era record says "Medusa," and this ADR bridges them. Future agents should treat "Medusa" in historical records as the former name of Cloud Bongos.

## Rejected alternatives

- **Rewrite history too** (also rename ADRs, logs, migrations, the 24 task descriptions): rejected by the owner — it destroys the record of what was decided when, for little forward value.
- **Brand-pack-only** (keep the platform internally named "Medusa," show "Cloud Bongos" only as the default instance's brand): rejected — the owner wants the platform itself renamed.
