# &lt;Product Name&gt; — Project Identity (host instance context)

> **Neutral template — the skeleton a new Cloud Bongos instance fills in.** This is the project-context *template* Cloud Bongos ships ([ADR 0062](adr/<redacted>.md) §7, task [#1205](https://example.com/builders#/task/1205)); `cloudbongos init` ([#1204](https://example.com/builders#/task/1204)) copies it to `docs/project-context.md` and an owner's own LLM fills the placeholders. It is the prose counterpart to the neutral branding starter [`config/branding.neutral.json`](../config/branding.neutral.json). **Instance 1's filled version is [`docs/project-context.md`](project-context.md).** Do not edit this template per-instance — edit your copy.
>
> **Relationship to the rest of the project:**
> - [`CLAUDE.md`](../CLAUDE.md) is the **portable methodology core** Cloud Bongos ships — working rules, session protocol, claim→ship lifecycle, the [ADR 0061](adr/<redacted>.md) content charter, the nested-`CLAUDE.md` pattern. Instance-agnostic; you do not author it.
> - **This file is the *prose* identity** — lore, vision, the why. The **machine-readable** identity (exact strings code reads: product/world/company names, domains, cookie/OAuth origins, currency label, palette, repo binding) lives in the branding contract [`config/branding.json`](../config/branding.json) ([`docs/branding-contract.md`](branding-contract.md)). **Where a name must be exact for code, the branding contract wins** — never re-hardcode a contract-owned string here.

<!--
OWNER-LLM FILL PROMPT
=====================
You are filling in a new Cloud Bongos instance's project-context file. Read config/branding.json (the machine-readable
identity already chosen for this instance) and CLAUDE.md (the portable methodology core). Then replace every
<angle-bracket placeholder> below with this project's real identity, in the project's own voice:
  • What the product is, in one paragraph (the elevator pitch a new contributor reads first).
  • The company / who is behind it, and how that shapes the product's feel.
  • The goal & vision — what "unlike anything done before" means here; what success looks like.
  • The world / domain design — the setting, naming, tone; any trademark or naming constraints.
  • The visual style — the look, the references, the non-negotiables, and where the asset pipeline lives.
Keep it durable framing, not live state (live state belongs in the build platform's DB). Delete sections that
do not apply to this project. Delete this comment block when done.
-->

&lt;One paragraph: what this product is, who it's for, and the single idea that makes it distinct. The full
"two tracks / how work is sorted" framing lives in [`CLAUDE.md`](../CLAUDE.md) §1.&gt;

---

## Company Context — &lt;Company Name&gt;

- **What they are:** &lt;what the company/organization does&gt;
- **Customer base / audience:** &lt;who it serves&gt;
- **Brand positioning:** &lt;the feeling the brand carries, and how it must show up in the product&gt;
- **Website:** &lt;url&gt;

---

## Goal & Vision

&lt;What this experience is trying to be — the ambition. Bullet the core promises to the user, and what makes
the experience permanent / distinctive / worth building.&gt;

---

## World / Domain Design

- **Setting / domain:** &lt;where the experience lives, conceptually&gt;
- **Core named entities:** &lt;the world/product name and what it means; keep names in `config/branding.json`, not hardcoded&gt;
- **Inciting idea:** &lt;the hook — why a user enters and what they discover&gt;
- **Tone:** &lt;the feeling; what it is NOT&gt;

> ⚠️ **Naming / trademark posture:** &lt;any protected marks or naming risks, and the contingency.&gt; **Operating rule:** any
> rebrand-sensitive name must live as a single string in [`config/branding.json`](../config/branding.json) — never baked into
> class names, file names, DB schema, or asset filenames — so a forced rebrand is a one-line change ([ADR 0062](adr/<redacted>.md) §3).

---

## Visual Style

- &lt;The look and the touchstone references.&gt;
- &lt;Resolution / tile size / format constraints, if any.&gt;
- &lt;The palette / mood; what it is NOT (call out the easy-to-get-wrong defaults).&gt;

### Asset pipeline

&lt;If the instance enables an asset-generation module, describe where it lives and its non-negotiables (locked palette,
rubric, cost ceiling). Otherwise delete this subsection.&gt;
