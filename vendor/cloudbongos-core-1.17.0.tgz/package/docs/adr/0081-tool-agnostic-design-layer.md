# ADR 0081 — Tool-agnostic design layer: repo-canonical, Claude Design + Figma as adapters

**Status:** Accepted (2026-06-21) · this ADR [#1375](https://example.com/builders#/task/1375) · implementation cluster [#1376](https://example.com/builders#/task/1376) [#1377](https://example.com/builders#/task/1377) [#1378](https://example.com/builders#/task/1378) [#1379](https://example.com/builders#/task/1379) [#1380](https://example.com/builders#/task/1380) · applies the core↔host pattern of [ADR 0062](<redacted>.md) to design; grader/ship changes ride the gate-review hard floor of [ADR 0043](<redacted>.md)

## Context

Developers collaborate through Git because code is text: it diffs line-by-line and 3-way-merges automatically. Design has no equivalent — a Figma `.fig` is a proprietary vector scene-graph and a PNG is a binary blob; neither line-diffs or auto-merges. Designers never adopted the merge model: they co-edit live (Figma's multiplayer), snapshot versions, and publish component libraries. So "how does a designer's work reach GitHub?" has never had a clean answer here.

Three forces made this worth deciding now:

1. **UI is becoming real work.** Today the GDS has three disciplines — `engineer | artist | ideator` — and "design/figma/UI" tasks fall into `artist`, the pixel-art lane. UI (HUD, menus, the builders' hall, status dashboard, landing pages) is a different problem from world tiles and deserves its own lane.
2. **The grader is secretly two systems.** The GDS ship pipeline (`confirm → grade → merge → deploy → credits`) does **not** branch by discipline — every task rides the same rails. But the *grade* step is the code panel [`grader.js`](../../src/bongos/grader.js) (reads a git diff; scores code quality), while pixel art is really gated by a *separate* Gemini vision pipeline ([`art/pipeline/review.py`](../../art/pipeline/review.py)) that runs **upstream** in `/paint`, not at ship. Art passes the ship-time grader as a near-rubber-stamp because a text-only panel can't see pixels. Two grader codebases is a maintenance trap.
3. **Claude Design changed the calculus.** [Claude Design](https://www.anthropic.com/news/claude-design-anthropic-labs) (Anthropic Labs, beta, 2026) **writes code and renders it** — it has no vector canvas. Its output is HTML/CSS/JS, and its June 2026 update added tight Claude Code sync (`/design-sync` imports a repo's design system in; a finished design hands off to Claude Code "where the designer left off"). So for Claude Design, *design is code* — it merges like any other code.

Owner (Lars) requirements, reached in the 2026-06-21 design conversation:

- **No vendor lock-in.** A competitor may ship a rival design tool; the system must not depend on Claude Design specifically.
- **Human escape hatch.** A talented designer must be able to make manual changes directly in Figma.
- **One grader, one regen flow for every task type.** Type-dependent criteria are fine; two grader *systems* are not.

## Decision

**The repo is the single source of truth; every design tool is a swappable adapter against a neutral contract.** This is the [ADR 0062](<redacted>.md) core↔host decoupling applied to design: the system depends on the *contract*, not on any tool.

1. **Neutral design contract = the repo.** The canonical representation is design tokens (extending [`config/branding.json`](../../config/branding.json)) + component code + exported assets, plus a per-surface "design source pointer" (which tool authored it, where its editable source lives). Tools read from and write to this contract; nothing else is canonical. ([#1377](https://example.com/builders#/task/1377))

2. **Tools are adapters, not integrations.** Claude Design and Figma are the first two adapters; a future tool is just a third. Each adapter does two things: import the repo design system *into* the tool, and emit a tool change back as a *committed diff*.
   - **Claude Design adapter** ([#1378](https://example.com/builders#/task/1378)): `/design-sync` exports our design system in; the Claude Code handoff lands generated UI code under a claimed GDS task. No translation layer — the output is already code.
   - **Figma adapter** ([#1379](https://example.com/builders#/task/1379)): a human edit → generate component code/tokens (Code Connect / Figma MCP) → commit; and the repo syncs *back* to Figma (the code→Figma bridge) so the designer never edits a stale file. This is the human escape hatch.

3. **`ui` becomes its own discipline** ([#1376](https://example.com/builders#/task/1376)), split out of `artist`. `ui` = design-as-code (graded by diff + rendered screenshot); `artist`/graphics = pixel art (graded by vision). Each routes to its own work-mode (a new `/design`, mirroring `/paint`).

4. **Code-canonical round-trip.** Structured UI (components, layout, tokens — the design-system vocabulary) round-trips as code. Freeform visual work that doesn't translate cleanly is exported as a committed *asset* (the graphics path), not round-tripped. A surface a human truly wants to own canvas-first can be flagged "Figma-canonical" as an explicit exception; code-canonical is the default.

5. **One grader, one regen flow — parameterized by type, not forked** ([#1380](https://example.com/builders#/task/1380)). Collapse the code panel and the Gemini pipeline into a single engine: a rubric registry keyed by task type (code-quality / visual / UI+a11y), evidence chosen by type (git diff for code+UI; render→screenshot for visual), one **multimodal** Claude grade call that subsumes the separate vision pass, and one shared regen loop — `spec → generate → grade → fail? regenerate → pass? commit` — identical across types. Because Claude Design emits code, UI rides the *same* git-diff grader as engineer code; only pixel art needs the vision modality, which the multimodal grader already covers.

## Consequences

- **No lock-in.** Tools plug into the repo contract; adding or dropping one (Claude Design, Figma, a future rival) doesn't touch the core. That is the explicit insurance the owner asked for.
- **Designers keep Figma.** Manual Figma edits are first-class for structured/design-system changes and round-trip into the repo via a normal GDS task + the same grader. The honest limit: the Figma→code round-trip is lossy for arbitrary canvas art — that work becomes a committed asset, not round-tripped code.
- **One grader to maintain, not two.** The standalone Gemini review path is retired into the unified engine. Code doesn't auto-regen today (a failed grade = human fixes + re-ships); unifying gives every type the same generate→grade→regenerate loop.
- **Graphics is unchanged.** World pixel art stays on the Claude Code + Gemini pipeline; Figma stays its viewer ([`otb-figma-sync`](../../.claude/skills/otb-figma-sync/SKILL.md)). This ADR adds the `ui` lane beside it, it does not disturb the art pipeline.
- **Gate-review floor applies.** [#1380](https://example.com/builders#/task/1380) touches [`grader.js`](../../src/bongos/grader.js) + [`ship.js`](../../scripts/gds/ship.js) — the gate-review **hard floor** ([ADR 0043](<redacted>.md)). It needs owner Gate approval even for Archon, and the multimodal call path wants a security review.

## Rejected alternatives

- **Fork the GDS / keep two grader sets** (an earlier draft of this design). Rejected by the owner: separate grader systems per discipline is a maintenance trap. One engine + type-parameterized rubric/evidence achieves the same ends with one codebase.
- **Claude Design only.** Cleanest GitHub path (code-native), but bets the system on one beta — the lock-in the owner explicitly wants to avoid.
- **Figma only.** Mature and multiplayer, but its source is a vector file, so every change needs a code-generation translation step with an imperfect round-trip. Kept as an adapter, not as the single tool.
- **Figma-canonical (or per-tool source of truth) by default.** Two masters and lossy reconciliation. Code-canonical with Figma round-tripping *in* keeps one master; per-surface Figma-canonical remains available as an explicit exception.

## Implementation

The cluster is seeded and dependency-wired in the GDS (this ADR is [#1375](https://example.com/builders#/task/1375)):

- [#1376](https://example.com/builders#/task/1376) — `ui` discipline + work-mode (→ [#1375](https://example.com/builders#/task/1375))
- [#1377](https://example.com/builders#/task/1377) — neutral design contract + adapter interface (→ [#1375](https://example.com/builders#/task/1375))
- [#1378](https://example.com/builders#/task/1378) — Claude Design adapter (→ [#1377](https://example.com/builders#/task/1377))
- [#1379](https://example.com/builders#/task/1379) — Figma round-trip adapter (→ [#1377](https://example.com/builders#/task/1377))
- [#1380](https://example.com/builders#/task/1380) — unify the grader (→ [#1376](https://example.com/builders#/task/1376), [#1377](https://example.com/builders#/task/1377))

Acceptance, when built: a UI surface authored in Claude Design *and* one hand-edited in Figma both reach prod through one GDS task and the one grader; the standalone Gemini review path is gone; editing Figma always opens a design synced from current `main`.
