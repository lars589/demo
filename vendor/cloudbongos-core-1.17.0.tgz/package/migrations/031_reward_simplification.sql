-- 031_reward_simplification.sql — flip the simplification incentive (V3.R93 / #354).
--
-- Layer 2 (REWARD) of the code-simplification plan. Three coordinated changes,
-- all schema/seed (the streak un-exclusion + the net-negative credit path are
-- code changes in src/bongos/streak.js + src/bongos/db.js, not SQL):
--
--   1. credit_log gains a nullable `description` column so the net-negative
--      ship bonus (db.js awardNetNegativeBonus) can record the raw
--      removed/added line counts and the reason inline, instead of cramming
--      everything into the short `reason` enum-ish string. Existing inserts use
--      explicit column lists and never touch `description`, so this is additive
--      and safe; old rows read back NULL.
--
--   2. A new "Subtractor" achievement is seeded into the fixed catalog. It is
--      awarded via the EXISTING builder_achievements mechanism (see
--      src/bongos/achievements.js evaluateAfterShip) when a builder has earned the
--      net-negative ship bonus on >= 3 ships — i.e. they have, across multiple
--      ships, deleted more than they added. icon 🪓, credit_bonus 2 (same tier
--      as the other "ship a class of work" achievements).
--
--   3. The streak-3 / streak-7 achievement descriptions are corrected: they
--      previously read "(>=15min, kind != cleanup)", but as of this task
--      cleanup/refactor ships DO count toward streaks (streak.js exclusion
--      removed). Keep the catalog text honest.
--
-- Idempotent: ADD COLUMN IF NOT EXISTS; achievement seed is upsert-on-id.

-- 1. credit_log.description ------------------------------------------------
ALTER TABLE credit_log ADD COLUMN IF NOT EXISTS description text;

-- 2. + 3. Achievement catalog ----------------------------------------------
-- New "Subtractor"; corrected streak descriptions. Upsert so re-running this
-- migration (or a later catalog edit) converges. credit_bonus / sort_order on
-- Subtractor mirror the other touches[]-class achievements (art/gds shippers).
INSERT INTO achievements (id, name, description, icon, credit_bonus, sort_order) VALUES
  ('subtractor', 'Subtractor',
   'Earn the net-negative ship bonus on 3 ships — across your work you have deleted more than you have added.',
   '🪓', 2, 65),
  ('streak-3', 'Streak: 3 Nights',
   'Ship a task in 3 consecutive local-time nights (>=15min; cleanup/refactor now counts).',
   '🔥', 2, 40),
  ('streak-7', 'Streak: 7 Nights',
   'Ship a task in 7 consecutive local-time nights (>=15min; cleanup/refactor now counts).',
   '🌋', 5, 50)
ON CONFLICT (id) DO UPDATE
  SET name         = EXCLUDED.name,
      description  = EXCLUDED.description,
      icon         = EXCLUDED.icon,
      credit_bonus = EXCLUDED.credit_bonus,
      sort_order   = EXCLUDED.sort_order;

-- Bump the migration counter past 031 so the next claim that includes
-- 'migrations/' allocates 032.
UPDATE migration_counter SET next_number = GREATEST(next_number, 32) WHERE id = 1;

INSERT INTO schema_migrations (version) VALUES ('031_reward_simplification')
  ON CONFLICT (version) DO NOTHING;
