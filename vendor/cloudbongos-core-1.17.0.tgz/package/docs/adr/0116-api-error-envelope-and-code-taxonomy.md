# ADR 0116 — API error envelope + code taxonomy

**Date:** 2026-07-04
**Status:** Accepted (contract; R01 of goal 36).
**Context:** [task 1988](https://builders.example.com#/task/1988) (BONGOS-V1, goal 36 "Robust, versioned, easy-to-call public API", criterion `api-error-envelope`). This is the **contract** the rest of the criterion implements: the central middleware + `res.fail()` helper ([task 1989](https://builders.example.com#/task/1989), R02), the build check that holds the line ([task 1990](https://builders.example.com#/task/1990), R03), and the sweep of existing handlers onto it ([task 1991](https://builders.example.com#/task/1991), R04). Sibling contracts in the same goal: versioning (R05), the source-of-truth spike (R07), validation (C4), pagination (C5).

## Problem

An audit of the live API surface (`src/bongos/` + `modules/*/routes/`) found **352 distinct `error:'…'` string literals**, returned across HTTP statuses 400/401/403/404/409/413/422/429/500/502/503 in three or four different response *shapes* (`res.status(n).json({error})`, bare `res.json({error})`, `res.status(500).json({error, message})`, `res.sendStatus(n)`). A caller — the CLI, the Dev Box app, a web page, or an external self-hoster — cannot write **one** error-handling path against that: there is no guaranteed key to read, no stable status, and no way to tell a retriable failure from a permanent one. The codes are not the problem (a specific slug like `task_not_found` is useful); the *absence of a documented, uniform envelope and a classification* is.

## Decision

**One envelope, everywhere:**

```json
{ "error": { "code": "task_not_found", "message": "…", "details": … } }
```

- **`code`** — a stable machine-readable slug the caller may switch on. **The specific slug is preserved** — a caller keying on `task_not_found` keeps working. The taxonomy collapses codes by *category*; it does not discard them.
- **`message`** — human-readable, safe to surface. Internals are never echoed unless a handler opts in.
- **`details`** — optional structured payload (e.g. the validator's `[{field,reason}]`).

**A registry, not 352 loose strings** — `src/bongos/api-errors.js` (kernel, core). It defines **~12 canonical categories**, each with a default HTTP status and a `retriable` flag:

| category | status | retriable | meaning |
|---|---|---|---|
| `bad_request` | 400 | no | malformed/invalid input |
| `validation_failed` | 400 | no | spec/schema validation failed; `details` lists field errors |
| `unauthenticated` | 401 | no | no valid session/credential |
| `forbidden` | 403 | no | rank/ownership insufficient |
| `not_found` | 404 | no | resource missing |
| `conflict` | 409 | no | clashes with current state (exists, cycle, active claim, stale tip) |
| `payload_too_large` | 413 | no | body/element over the limit |
| `unprocessable` | 422 | no | well-formed but semantically unacceptable |
| `rate_limited` | 429 | **yes** | too many requests / quota |
| `internal` | 500 | **yes** | unexpected error or a server-side op that failed |
| `bad_gateway` | 502 | **yes** | upstream returned garbage |
| `unavailable` | 503 | **yes** | dependency/feature not configured or down |

Every one of the 352 codes classifies onto a category via **`classify(code)`** — an explicit `OVERRIDES` table for the exceptions the naming can't disambiguate (auth codes, preconditions read as conflicts, `*_too_large`), plus a **suffix/prefix heuristic** for the long tail that encodes the conventions the audit surfaced: `*_failed`/`*_error` → `internal`; `*_not_found` → `not_found`; `bad_*`/`invalid_*`/`*_required`/`*_mismatch` → `bad_request`; `already_*`/`*_taken`/`*_exists`/`*_conflict` → `conflict`; `*_unconfigured` → `unavailable`. `classify` is **pure + total**: an unrecognised (or future) code falls back to `internal` (500) — the safe default — never throwing.

The module also ships the **`ApiError`** carrier (`throw new ApiError(code, {status?, message?, details?})` — status/category derived from the registry) and the pure **`envelope()`** formatter. `statusForCode(code, override)` lets a call site keep its current status where it differs from the category default (e.g. a route already returning 422) — so the R04 sweep changes *shape*, not *status*, and is safe.

## Why this shape

- **`{error:{…}}` (nested), not `{error:'code', message:'…'}` (flat).** A nested object gives one place to grow (`details`, later `retriable`/`docs_url`) without colliding with a payload field, and lets a caller test `resp.error` as the single failure discriminator. The flat shape is what today's mess already is.
- **Preserve codes, collapse by category.** Discarding 352 codes down to 12 would break every caller that reads a specific code and lose real signal. Classification is additive: the code stays; the category + status become *derivable* and uniform.
- **Heuristic + overrides, not a 352-row frozen table.** The naming conventions are real and regular; encoding them as rules keeps the registry small and auto-classifies future codes, while the override table pins the ~90 genuine exceptions. The classifier is authoritative — R02/R04 call it, they don't re-decide.
- **Contract-only now, zero behaviour change.** Nothing imports `api-errors.js` yet, so this ADR + module + test ships without touching a single response. R02 wires the middleware; R04 sweeps the handlers behind the R03 build check.

## Consequences

- A caller can finally write one path: read `resp.error.code`, branch on `resp.error` presence, retry on the `retriable` categories (429/5xx).
- The OpenAPI spec (R07/`gen-api-docs.js`) can advertise the envelope as the single error schema and the category set as an enum.
- The sweep (R04) is mechanical: replace each `res.status(n).json({error:'x'})` with `res.fail('x')` (or `throw new ApiError('x')`), status preserved via the registry. The R03 build check fails any new hand-rolled flat error, so the line holds as the sweep progresses.

## Rejected

- **A flat `{error, message}`.** Already the de-facto shape; no room to grow, and `error` doubling as both discriminator and code is what callers can't rely on.
- **Renumbering to numeric error codes (e.g. `BONGOS-1234`).** Opaque to humans, needs a lookup table, and throws away the self-describing slugs.
- **Collapsing to ~12 codes only.** Loses per-operation signal and breaks specific-code callers.
- **A per-module registry.** The whole point is *one* shape across core + every module; a shared kernel registry is the only thing that guarantees it.
