# ADR 0021 — Per-builder skill model preferences + skill-efficiency audit

**Date:** 2026-05-28
**Context:** Task [#304](https://example.com/builders#/task/304) (V3.R85), GDS-V3 cost-discipline cross-cutting. Promotes idea_inbox [#21](https://example.com/builders#/idea/21); pulls forward a minimal slice of PMS-V4 idea [#30](https://example.com/builders#/idea/30).
**Status:** Accepted (mechanism only; per-skill refactor + execution-time hook deferred to follow-up tasks).

## Problem

Today every slash-command skill runs on whichever model the user launched. Two things are wrong with that:

1. **Mechanism vs judgment is conflated.** A skill like `/builder-claim` is structurally a shell around `scripts/gds/claim.js` — there is no LLM judgment in claiming a task. Yet it runs on whatever model the user's session is on (typically Opus 4.7), which burns budget on parsing + formatting that a `node` invocation does for free. Conversely, `/planning-session` IS the judgment — it sets a whole version's scope-truth — and demoting it for cost saving would be exactly the wrong move.
2. **There's no per-builder lever.** CLAUDE.md §2 documents a project-wide policy ("default to Opus, Haiku for plumbing") that doesn't survive contact with multi-builder reality. A builder who wants Sonnet for everything except priority-session has no way to express that without editing skill files.

The cross-cutting ask in [#304](https://example.com/builders#/task/304) is to make the trade-off explicit per skill AND tunable per builder.

## Decision

We will ship the **mechanism**: a per-builder storage + UI + API surface for picking a model per skill, plus an audit-classified set of system defaults. The **per-skill refactor** (extracting mechanism into pure scripts) and the **execution-time hook** (skills actually reading the preference at invocation) are filed as follow-up tasks and tracked separately.

The split is deliberate. The storage + UI + audit is load-bearing infrastructure — once it exists, the per-skill refactors can land independently (different skill, different week, different builder). The reverse order doesn't work: refactoring a skill without somewhere to encode the preference produces an orphaned commit.

### What ships now

1. **Migration 037 — `builders.skill_model_prefs jsonb`** (single column, default `'{}'`). A jsonb map from skill name → model token. Per-builder, sparse — missing keys fall back to the system default.
2. **`src/bongos/skill-prefs.js`** — pure module. Exports `ALLOWED_MODELS`, `KNOWN_SKILLS`, `SKILL_DEFAULTS`, `getDefault()`, `getForBuilder()`, `listEffective()`, `validatePatch()`, `applyPatch()`. The single source of truth that the API, the UI, and any future skill hook read from.
3. **`GET /api/gds/me/skill-prefs`** — returns `{ prefs, effective, defaults, known_skills, allowed_models }`. The UI consumes `effective` (which already merges override > default) plus `allowed_models` (drives the dropdown options).
4. **`PATCH /api/gds/me/skill-prefs`** — body is `{ <skill>: <model> | null }`. `null` clears the override; missing skills are untouched (partial updates are first-class). Unknown skill names or unknown models → 422 with a structured errors array.
5. **`/builders` profile UI** — new section "The Voice Behind Each Skill" rendering one row per skill with the system default + a dropdown for the builder's override.
6. **This ADR** — captures the audit + the design + the deferred items.

### What's deferred (follow-up tasks)

- **Per-skill refactor.** Each skill listed below as `default: 'script'` should actually be a script wrapper — today most of them already are (the `builder-*` slash commands shell out to `scripts/gds/*.js`), but the SKILL.md files still invite the LLM to parse the JSON output. Refactor per-skill is one-task-per-skill.
- **Execution-time hook.** Skills currently don't read `skill_model_prefs` when they run. The intended hook: each SKILL.md gets a top-line `Subagent model:` line resolved against `getForBuilder()` at invocation time, and any `Agent` tool call inside the skill passes the resolved model explicitly. That requires touching each SKILL.md plus a small helper script.
- **Cost measurement before/after.** Today we have `cost_log` rows by `category` but not by `(category, skill)`. Adding a skill-attribution column + a measurement window post-rollout is its own task.

These three are filed as new tasks at idea_inbox (kind=cleanup or refactor) so the deferred work is visible.

### Audit — what each skill is structurally

The audit pass walked every `.claude/skills/*/SKILL.md`, classified each step as **mechanism** (deterministic; no model judgment needed) or **judgment** (the model is the load-bearing thing), and picked a system default:

| Skill | Default | Why |
|---|---|---|
| `builder-start` | script | wraps `start.js` — format-output only |
| `builder-claim` | script | wraps `claim.js` — atomic DB write |
| `builder-release` | script | wraps `release.js` |
| `builder-exit` | script | wraps `onboarding-ship.js` (offboarding flow) |
| `builder-cost` | script | wraps `cost.js` — direct row insert |
| `otb-figma-sync` | script | direct Figma API push |
| `builder-ship` | sonnet | mostly mechanism, but drafts handoff notes + value summary (light judgment) |
| `idea-triage` | opus | walks the inbox and proposes promote/discard/merge verdicts — heavy judgment |
| `blocker-review` | opus | similar — walks blockers, drafts resolutions |
| `merge-mode` | opus | resolves merge conflicts, decides which branches go first |
| `planning-session` | opus | sets a version's scope — the highest-judgment skill in the project |
| `priority-session` | opus | reweights the inbox via plain-speech survey |
| `otb-builder-setup` | sonnet | long-form env walk-through; once-per-builder |
| `otb-tile-generate` | sonnet | orchestrates Gemini image gen + review; light judgment |
| `otb-design-review` | sonnet | orchestrates Gemini vision; light judgment |
| `otb-feedback-capture` | sonnet | converts speech to style-guide rule; medium judgment |

Six skills sit at `script` — the cleanest cost wins, and the simplest to hook (just don't invoke the LLM at all). Five sit at `opus` — the project-default and the right call. Five sit at `sonnet` — middle tier, where the budget lever is most useful.

### Why jsonb on `builders` and not a separate table

- The natural read shape is "what does THIS builder prefer for skill X" — keyed on builder primary key. A separate table forces a join.
- Sparse + irregular (most builders won't override most skills). jsonb's natural shape.
- Adding a new skill = one line in `KNOWN_SKILLS` + one line in `SKILL_DEFAULTS`. No backfill, no migration. A table would force coordinated schema + code change every time.
- Analytics queries ("how many builders override planning-session?") are rare enough to do via jsonb operators when needed.

If V4 retires per-skill defaults in favor of per-skill-*kind* defaults (the broader idea [#30](https://example.com/builders#/idea/30) reshape), the jsonb stays — only the helper changes.

### Why these four model tokens

`opus`, `sonnet`, `haiku`, `script`. The first three match the project-wide subagent routing vocabulary (CLAUDE.md §2). `script` is the deliberate "no LLM" sentinel — important because a skill marked `script` doesn't just save tokens, it commits to running deterministically. Without it, the only way to express "this skill has no judgment moment" would be to remove it from the matrix, which loses the audit signal.

## Alternatives considered

- **Per-skill defaults only, no per-builder override.** Simpler. Rejected — the ask in [#304](https://example.com/builders#/task/304) is explicitly "builder-toggleable." A project-wide policy + the ability to deviate is what aligns multi-builder reality with cost discipline.
- **Separate `builder_skill_prefs` table.** More flexible for analytics, easier to migrate one preference type without touching jsonb shape. Rejected for V3 — see above. Can supersede this later if analytics frequency justifies it.
- **Resolve overrides only at skill-execution time, no GET endpoint.** Possible, but then the /builders UI has no source of truth — it'd have to mirror `SKILL_DEFAULTS` in JS, which is exactly the kind of drift the helper module exists to prevent.
- **Validate model tokens via Postgres CHECK constraint on the jsonb.** Rejected — jsonb CHECK is awkward to express, and the API-level validation catches the same class of errors with a structured error message. The DB layer is defensive (uses jsonb's type system to reject non-string values), not authoritative.
- **Ship the full refactor + hookup atomically.** Tempting (one PR, complete done-when). Rejected because (a) [#304](https://example.com/builders#/task/304) is genuinely a multi-task project (1 mechanism PR + ~6 per-skill refactor PRs + 1 hook PR + 1 measurement PR), (b) the mechanism is independently useful (the audit alone tells builders what the system thinks each skill is for), and (c) shipping the mechanism gives every subsequent skill task a stable consumer.

## Consequences

- A builder can deviate from CLAUDE.md §2's default-Opus posture per skill, via the /builders UI. Power-users tune; new builders inherit sensible defaults.
- The audit (the table above) is now in code, not just CLAUDE.md prose — visible at `src/bongos/skill-prefs.js` and rendered in the UI. Stays honest as new skills land (the `KNOWN_SKILLS` sanity check at module load catches drift).
- Today, the storage exists but nothing reads `effective` at skill-execution time. The per-builder choice has no effect until the hookup task lands. The UI surfaces this honestly — the dropdown says "Set X → Sonnet" but the runtime still uses whatever model the user launched. Acceptable as the bootstrapping step.
- The `script` default for six skills is a *commitment* — those skills should not invoke the LLM for judgment. The next time one of them is edited, the editor sees `default: 'script'` in this ADR and adjusts the SKILL.md to delegate to the wrapper script.
- Adding a new skill in V4: one line in `KNOWN_SKILLS`, one line in `SKILL_DEFAULTS`, ship. No migration.

## Cross-references

- [Migration 037](../../migrations/<redacted>.sql) — the schema change.
- [`src/bongos/skill-prefs.js`](../../src/bongos/skill-prefs.js) — the helper module and source of truth for defaults.
- [`tests/skill_prefs.mjs`](../../tests/skill_prefs.mjs) — unit coverage for the pure helpers.
- [ADR 0017](<redacted>.md) — same spirit: keep judgment work intentional, mechanism work cheap.
- CLAUDE.md §2 — the project-wide subagent routing policy this ADR sits beside (not replaces — the policy is the default the matrix opens with).
