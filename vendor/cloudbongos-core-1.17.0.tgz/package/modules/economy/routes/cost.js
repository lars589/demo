const express = require('express');
// Carved into modules/economy/ (BV1.R77 / ADR 0093 §1-2): auth gates + request
// validators reach through the published doorway; the cost_log writer is an
// intra-module require — a module never requires a core internal.
const api = require('../../../src/module-api');
const cost = require('../cost');
const { validateOrRespond, LIMITS } = api;

const COST_CATEGORIES = ['api', 'compute', 'infra', 'domain', 'art', 'other'];

module.exports = function buildCostRouter() {
  const router = express.Router();

  // rank: any-builder — log cost on own claim (idempotent via source/source_ref).
  router.post('/cost', api.requireBuilder, async (req, res) => {
    if (validateOrRespond(req, res, {
      task_id: { type: 'integer', min: 1 },
      amount_usd: { required: true, type: 'number', min: 0, max: 1000000 },
      // Don't enum-restrict category — the existing skills set categories that
      // may legitimately drift; just cap the length. (CLAUDE.md mentions
      // api|compute|infra|domain|art|other as the canonical set.)
      category: { required: true, type: 'string', maxLength: 64, minLength: 1 },
      description: { type: 'string', maxLength: LIMITS.NOTES },
      source: { type: 'string', maxLength: LIMITS.SOURCE },
      source_ref: { type: 'string', maxLength: LIMITS.SOURCE_REF },
      recorded_at: { type: 'string', maxLength: 64 },
      // System 1 / task 1344: optional per-tier USD split (cost_log columns
      // added by migration 123). session-cost.js sends these so spend can be
      // attributed by tier (cache_read is the marathon sink). Omitted → NULL.
      fresh_input_usd: { type: 'number', min: 0, max: 1000000 },
      cache_read_usd: { type: 'number', min: 0, max: 1000000 },
      cache_write_usd: { type: 'number', min: 0, max: 1000000 },
      output_usd: { type: 'number', min: 0, max: 1000000 },
      // V3.R11 (#91): builder_id is optional. When absent we default to the
      // authed builder (the right answer 99% of the time). When provided it
      // must match the authed builder — we don't let one builder attribute
      // spend to another. Archons could in theory be allowed to override
      // (e.g. for backfill), but the only existing backfill path is
      // scripts/gds/backfill-cost.js, which runs as Lars (archon) and reads
      // the historical ledger that had no builder_id anyway. Keep the rule
      // tight; relax later if/when a real cross-builder use case appears.
      builder_id: { type: 'integer', min: 1 },
      // task #385 / migration 181: which skill invocation incurred this cost.
      skill_name: { type: 'string', maxLength: 64 },
    })) return;
    const { task_id: taskId, amount_usd: amountUsd, category, description, source, source_ref: sourceRef, recorded_at: recordedAt, builder_id: bodyBuilderId,
      fresh_input_usd: freshInputUsd, cache_read_usd: cacheReadUsd, cache_write_usd: cacheWriteUsd, output_usd: outputUsd,
      skill_name: skillName } = req.body || {};
    const authedBuilderId = Number(req.builder?.id);
    let builderId = authedBuilderId || null;
    if (bodyBuilderId != null) {
      const requested = Number(bodyBuilderId);
      if (!Number.isFinite(requested) || requested <= 0) {
        return res.fail('bad_builder_id', 400);
      }
      if (requested !== authedBuilderId) {
        return res.fail('builder_id_mismatch', { status: 403, message: 'builder_id must match the authenticated builder' });
      }
      builderId = requested;
    }
    let recordedAtDate = null;
    if (recordedAt) {
      const parsed = new Date(recordedAt);
      if (Number.isNaN(parsed.getTime())) {
        return res.fail('bad_recorded_at', 400);
      }
      recordedAtDate = parsed;
    }
    try {
      const out = await cost.logCost({
        taskId: taskId ?? null,
        amountUsd,
        category,
        description: description ?? null,
        source: source ?? 'manual',
        sourceRef: sourceRef ?? null,
        recordedAt: recordedAtDate,
        builderId,
        freshInputUsd: freshInputUsd ?? null,
        cacheReadUsd: cacheReadUsd ?? null,
        cacheWriteUsd: cacheWriteUsd ?? null,
        outputUsd: outputUsd ?? null,
        skillName: skillName ?? null,
      });
      if (!out) {
        // ON CONFLICT skipped: same (source, source_ref) already logged. Idempotent.
        return res.status(200).json({ skipped: true, reason: 'duplicate_source_ref' });
      }
      res.status(201).json({ id: out.id, recorded_at: out.recorded_at });
    } catch (err) {
      console.error('[gds] POST /cost', err);
      res.fail('cost_failed', { status: 500, message: 'internal error' });
    }
  });

  return router;
};
