-- 007_pms_v2_hierarchy_trigger.sql — auto-ship parents when all children ship
--
-- Companion to F1 (006_pms_v2.sql) and C2 (src/pms/hierarchy.js).
--
-- When the last unshipped child of a parent flips to status='shipped',
-- the parent itself flips to 'shipped' atomically. parent.shipped_at is
-- set to MAX(child.shipped_at). parent.shipped_by is left NULL — there
-- is no single builder responsible for a parent that ships via rollup.
-- (Individual children retain their own shipped_by; credits accrue per
-- child as today.)
--
-- Idempotent: CREATE OR REPLACE FUNCTION + DROP TRIGGER IF EXISTS.

CREATE OR REPLACE FUNCTION fn_auto_ship_parent_on_children_shipped()
RETURNS TRIGGER AS $$
DECLARE
  unshipped_count integer;
BEGIN
  -- Defensive guards (the WHEN clause already enforces these, but keep
  -- the function safe to call from any future trigger surface).
  IF NEW.parent_task_id IS NULL THEN
    RETURN NEW;
  END IF;
  IF NEW.status IS DISTINCT FROM 'shipped' THEN
    RETURN NEW;
  END IF;

  -- Count siblings of NEW (children of NEW.parent_task_id) that aren't
  -- yet shipped. NEW is already committed at AFTER-UPDATE time, so the
  -- count reflects post-update reality. Zero ⇒ promote the parent.
  SELECT count(*) INTO unshipped_count
    FROM tasks
   WHERE parent_task_id = NEW.parent_task_id
     AND status <> 'shipped';

  IF unshipped_count = 0 THEN
    UPDATE tasks
       SET status = 'shipped',
           shipped_at = COALESCE(
             (SELECT max(shipped_at) FROM tasks WHERE parent_task_id = NEW.parent_task_id),
             now()
           )
     WHERE id = NEW.parent_task_id
       AND status <> 'shipped';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_auto_ship_parent ON tasks;
CREATE TRIGGER trg_auto_ship_parent
  AFTER UPDATE OF status ON tasks
  FOR EACH ROW
  WHEN (NEW.status = 'shipped' AND NEW.parent_task_id IS NOT NULL)
  EXECUTE FUNCTION fn_auto_ship_parent_on_children_shipped();

INSERT INTO schema_migrations (version) VALUES ('007_pms_v2_hierarchy_trigger')
  ON CONFLICT (version) DO NOTHING;
