# ADR 0082 — Productized key-storage provisioning (server-generated master key, zero SSH)

**Status:** Accepted (2026-06-21) · task [#1398](https://example.com/builders#/task/1398) · resolves blocker 41 · extends the per-builder secret-box (task 1013; `src/bongos/secret-box.js`) · sibling of the UI-first intake work (task [#1391](https://example.com/builders#/task/1391))

> Note: `secret-box.js`'s header cites "ADR 0071" for the original design, but 0071 on disk is a different (dev-box) decision — that reference is stale. This ADR is the authoritative record for the master-key *provisioning* path; the encryption scheme itself shipped under task 1013.

## Context

The per-builder Gemini key feature (task 1013) encrypts each builder's key at rest with an AES-256-GCM **master key** that, by design, lives ONLY in server env (`BUILDER_SECRET_KEY`) or a local `~/.config/otb/builder-secret.key` (0600) operator file — never in the DB, repo, or chat. The feature shipped its endpoints + settings UI, but the master key was **never provisioned in prod**, so `secretBox.isConfigured()` is false → `GET /me/art-key/own` returns `storage_configured:false` → the settings card is a dead-end ("Key storage is being set up by an Archon — check back shortly") with no input. The result: **no builder can store a key at all**, blocking the art pipeline for everyone past the shared-newcomer tier (surfaced live when an Archon hit it on task 587).

The only documented fix was a manual one: SSH to the droplet and hand-add `BUILDER_SECRET_KEY` to the systemd EnvironmentFile. The owner declined that — provisioning should be a **product action**, not a terminal ritual.

## Decision

An **Archon initializes key storage from the UI** — the server generates and persists the master key; no human touches a secret.

- **`secretBox.provisionMasterKey({ file?, env? })`** generates 32 crypto-random bytes (`crypto.randomBytes`) and writes them (64-hex) to the operator file (`~/.config/otb/builder-secret.key`) as **0600** — the path the loader already honors as its file-fallback source, so it survives restarts. It is **idempotent and never overwrites**: if a valid key already resolves (env or file) it's a no-op (`created:false`); if a file is present but *doesn't* decode, it writes with the `wx` (exclusive-create) flag and **refuses on EEXIST** rather than clobber — overwriting the master key would make every already-stored builder key permanently undecryptable. `opts` exist only for the hermetic unit test.
- **`POST /api/gds/me/art-key/storage-init`** (in `routes/me.js`), gated `requireRank('archon')` — a server-wide admin action that happens to live under `/me/art-key/*` for client locality. It calls `provisionMasterKey()` and returns `{ ok, created, storage_configured }`; a refusal (present-but-invalid file) is a `409` that tells the operator to look, never a silent overwrite.
- **The settings card** (`public-builders/settings.js`), in the `storage_configured:false` state, now shows an Archon a **"Set up key storage"** button (the server enforces the rank regardless — the client check only decides what to render; divine tiers above archon also pass). Non-Archons keep the wait-for-an-Archon message. On success the card drops straight into the key-entry state.

## Consequences

- Turning on key storage is now one click by any Archon — **zero SSH, zero hand-edited prod secrets**. Re-clicking after it's up is a safe no-op.
- **Durability trade-off (accepted):** the master key lives in a 0600 file beside the encrypted blobs on the prod droplet. A `DB dump alone still cannot decrypt` (the key isn't in the DB). If the *droplet's disk* is lost without the file, stored keys become undecryptable — but this is BYOK: builders simply re-add their own keys. Crypto-RNG-to-file also beats a human-chosen secret (no weak/reused values, never pasted anywhere). Backing up the file with the other droplet secrets is recommended but not required for correctness.
- **Idempotency is load-bearing.** The never-overwrite guard is the one property that must never regress — a unit test asserts a second call leaves the key bytes unchanged and that a present-but-invalid file is refused, not clobbered.
- Security surface: this touches secret-box + an auth-gated route, so it runs the hacker/security review and gate-review will flag it. The provisioning endpoint exposes no secret material in any response (only `{ ok, created, storage_configured }`).

## Reproduce / verify

- Pure tests (DB-free): `tests/secret_box.mjs` — `provisionMasterKey` creates a 0600 64-hex file, is idempotent (no overwrite / no brick), short-circuits on a valid env key, and refuses a present-but-invalid file.
- Route gate: `tests/route_rank_check.mjs` confirms the new privileged route classifies to its rank.
- End-to-end: on a server with no master key, an Archon clicks "Set up key storage" → `storage_configured` flips true → a key can be added via Settings and syncs to the box (`fetch-art-key.js`).
