# Recipe — stand up staging.cloudbongos.com (password-locked landing-page preview)

> Brings up **staging.cloudbongos.com** — a password-locked preview of the Cloud Bongos
> landing **gate** (`brand/cloud-bongos/gate`, the cel-glass + `> cloud bongos` terminal
> prototype from tasks [#1532](https://example.com/builders#/task/1532) +
> [#1534](https://example.com/builders#/task/1534)). This is the future
> cloudbongos.com landing page, parked behind a shared password so it can be shared for
> review before it goes public. Task [#1540](https://example.com/builders#/task/1540).

## Architecture (what we're building)

The **cheapest possible** host: no app process, no new port, no new certificate. Caddy
**static-serves** the brand-art folder that already ships in the checkout, behind HTTP
basic auth (the password lock).

| Thing | Value |
|---|---|
| URL | `https://staging.cloudbongos.com` (redirects to `/gate/`, where the gate is served) |
| Served by | Caddy `file_server`, web root `/home/lars/example/brand/cloud-bongos` |
| Lock | HTTP basic auth — username `bongos` + a shared password |
| TLS | the existing `*.cloudbongos.com` origin + Cloudflare edge certs (already cover it) |
| Cost | **$0/mo** — same droplet, no process, no port |

Why static (not a reverse-proxy block like the others): the gate is plain HTML/CSS/JS +
PNGs. There is nothing to run. Caddy serves the files directly.

## Why the web root is the brand folder, not `gate/`

The gate page lives at `gate/index.html` but references its art **relative to `/gate/`** —
sprites **beside it** (`sprites/…`, `dispmaps/…`) and the world **one level up**
(`../world/…`). So the folder that must be the web root is `brand/cloud-bongos/` (the
parent), and the page must actually be served **at `/gate/`** for those relative paths to
resolve. The Caddy block therefore **redirects the apex `/` → `/gate/`** (`redir / /gate/`)
rather than serving the gate's HTML at the apex.

> History (task 1545): the block first tried to serve the gate AT the apex via
> `rewrite / /gate/index.html` plus per-folder rewrites (`/dispmaps/*` → `/gate/dispmaps/*`).
> That was fragile — when the gate gained `sprites/` (task 1541) those 404'd at the apex
> (the browser asked `/sprites/*`, not `/gate/sprites/*`). The redirect serves the gate at
> its native path so **all** relative folders resolve, with nothing to keep in sync.

## Phase ① — DNS (Cloudflare dashboard, ~30 s)

cloudbongos.com is on Cloudflare. Add **one** record:

1. Cloudflare → pick the **cloudbongos.com** zone → **DNS** → **Add record**.
2. Type **A**, Name **`staging`**, IPv4 **`REDACTED_IP`**, Proxy status **Proxied** (orange cloud ON), TTL Auto.
3. Save.

No new certificate is needed — the cloudbongos origin cert is already
`cloudbongos.com, *.cloudbongos.com`, and Cloudflare's edge cert covers
`staging.cloudbongos.com` too.

## Phase ② — the password (droplet, one-time)

The `staging.cloudbongos.com` block ships in `infra/Caddyfile` with a **dummy** bcrypt hash,
so no real secret is in git. Generate the real hash and keep it handy for Phase ③:

```bash
caddy hash-password --plaintext 'YOUR_PASSWORD'
#  → prints  $2a$14$………   (copy the whole thing)
```

Username is `bongos`; the password is whatever you hashed. The real hash lives **only** in
the live `/etc/caddy/Caddyfile` — never committed.

## Phase ③ — apply the Caddy block + reload

The `staging.cloudbongos.com` block is already in `infra/Caddyfile`. The live
`/etc/caddy/Caddyfile` has drifted slightly from the repo copy (comment wording + block
order), so **do not blindly `cp` the whole file** — append just the new block, swap the
dummy hash for the real one, then reload:

```bash
cd /home/lars/example
# 1. append only the staging.cloudbongos.com block (idempotent: skip if present)
grep -q 'staging.cloudbongos.com {' /etc/caddy/Caddyfile || \
  awk '/^# ── Cloud Bongos — STAGING/{p=1} p' infra/Caddyfile >> /etc/caddy/Caddyfile

# 2. replace the dummy hash: open the file, find the staging.cloudbongos.com
#    block's `basic_auth { bongos … }` line, and paste the real $2a$… hash from
#    Phase ② in place of the dummy one.
sudo nano /etc/caddy/Caddyfile          # or any editor

# 3. let the caddy user READ the static files. Caddy runs as user `caddy`, which
#    cannot traverse the 750 home dir — without this, authenticated requests get
#    403. Everything under /home/lars/example is already world-readable, so
#    ONLY the home dir itself needs to be traversable (one-time, persists):
sudo setfacl -m u:caddy:x /home/lars 2>/dev/null \
  || sudo chmod o+x /home/lars          # fallback if the `acl` package is absent
#    o+x allows traverse, not listing. For strict least-privilege instead of the
#    broad o+x, `sudo apt-get install -y acl` first so the setfacl path is taken.

# 4. validate (as root — it must read the 640 root:caddy origin key), then reload
sudo caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile
sudo systemctl reload caddy             # fails closed on a bad config
```

> A bad config makes `reload` error out and **keep serving the old config** — the live
> sites never go down. Leaving the dummy hash in place is also safe: it just means no one
> can log in (fail-closed) until you paste the real one.

## Phase ④ — verify

```bash
# from anywhere:
curl -sS -o /dev/null -w '%{http_code}\n' https://staging.cloudbongos.com/          # 401 (locked) ✓
curl -sS -u bongos:YOUR_PASSWORD https://staging.cloudbongos.com/ | grep -o 'cloud bongos'   # matches ✓
curl -sS -o /dev/null -w '%{http_code}\n' -u bongos:YOUR_PASSWORD \
     https://staging.cloudbongos.com/world/assets/plates/scene-establishing.png      # 200 (art loads) ✓
```

Then open `https://staging.cloudbongos.com` in **Chrome or Edge** (the live-glass
refraction needs Chromium `backdrop-filter` + SVG displacement; Safari falls back to a
plain frost, which still looks fine). The browser shows a username/password box — enter
`bongos` + the password — and the gate appears.

## Rotating / removing the password

- **Change the password:** regenerate the hash (Phase ②), edit the `bongos …` line in the
  `staging.cloudbongos.com` block of `/etc/caddy/Caddyfile`, `sudo systemctl reload caddy`.
- **Take the site down:** delete the `staging.cloudbongos.com` block from
  `/etc/caddy/Caddyfile`, `sudo systemctl reload caddy`, and remove the Cloudflare
  `staging` A record.

## Later — promote to the real public landing page

When the gate is approved as the public landing page, that is a **separate task**: fold the
gate into `public-landing/index.html` (served at the cloudbongos.com apex by
`platform-server.js`), bring the world art it needs under a served path, and drop the basic
auth. Until then, this staging block is the review surface and `public-landing/index.html`
stays the minimal buddha placeholder.

## Files this recipe uses

- `infra/Caddyfile` — the `staging.cloudbongos.com` block (ships with a dummy hash; the
  live file carries the real one).
- `brand/cloud-bongos/gate/` — the gate prototype (`index.html` + `dispmaps/`).
- `brand/cloud-bongos/world/assets/` — the art the gate refracts.
