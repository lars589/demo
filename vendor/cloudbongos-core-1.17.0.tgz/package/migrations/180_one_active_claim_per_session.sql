-- 180_one_active_claim_per_session.sql
-- task 1642 — DB-level defence-in-depth behind the app-layer guard
-- (modules/lifecycle/routes/claims.js shouldRefuseSessionClaim).
--
-- THE PROBLEM. Working 2+ tasks from one worktree means every commit lands on
-- the single branch that worktree owns; /builder-ship publishes the whole
-- branch, so shipping one task drags the other's commits with it (commingled
-- ships). The cure: a CLI session (≈ one worktree, identified by
-- creator_session_id) may hold at most ONE active claim at a time.
--
-- "Active" is the claims-table convention released_at IS NULL — there is NO
-- `status` column on `claims` (the task spec's `status='active'` named a column
-- that doesn't exist on this table; the row's lifecycle lives on `tasks`). The
-- partial unique index below therefore keys on released_at IS NULL.
--
-- creator_session_id IS NOT NULL is essential: a web claim (bind_session=false)
-- stores a NULL session and is adoptable by any of the builder's CLI sessions —
-- those must never collide with each other (many NULLs are fine) nor with a
-- bound CLI claim. The app guard skips NULL sessions for the same reason.
--
-- SAFETY — a unique index FAILS to create (and would block deploy) if existing
-- rows already violate it. Before the CREATE we mop up any pre-existing
-- duplicate session-bound active claims, keeping the EARLIEST per session and
-- closing the rest (released_at=now(), outcome='abandoned'). This is the same
-- "close the dangling claim" shape as migration 174. It is idempotent: a second
-- run finds no duplicates and closes nothing. The app-layer guard in
-- modules/lifecycle/routes/claims.js is the AUTHORITATIVE enforcement going
-- forward; this index is belt-and-braces and must NOT break deploy.

-- Step 1 — heal any current violation so the unique index can be created.
-- Per session, keep the earliest active bound claim (lowest claimed_at, id as
-- tiebreak) and close every later one. A NULL creator_session_id is untouched
-- (PARTITION BY would group all NULLs, so we exclude them from the scan).
WITH ranked AS (
  SELECT c.id,
         ROW_NUMBER() OVER (
           PARTITION BY c.creator_session_id
           ORDER BY c.claimed_at, c.id
         ) AS rn
    FROM claims c
   WHERE c.released_at IS NULL
     AND c.creator_session_id IS NOT NULL
)
UPDATE claims c
   SET released_at = now(),
       outcome     = COALESCE(c.outcome, 'abandoned')
  FROM ranked r
 WHERE c.id = r.id
   AND r.rn > 1;

-- Step 2 — the teeth: at most one active claim per (non-null) session.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_active_claim_per_session
  ON claims (creator_session_id)
  WHERE released_at IS NULL AND creator_session_id IS NOT NULL;
