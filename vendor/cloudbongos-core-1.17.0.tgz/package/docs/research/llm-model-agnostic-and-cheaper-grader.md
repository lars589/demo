# LLM Model-Agnostic Platform + Cheaper Grader — Tools Audit & Architecture Path

**A research/architecture spike for Cloud Bongos / Off the Boats**
Prepared 2026-06-28 · task [#1069](https://example.com/builders#/task/1069) · GDS-V4 · track `internal`

---

## 0. How to read this document (provenance)

This is a **doc-only research spike** — no code, migration, or config changed under it. It is grounded in a direct read of the live repo on 2026-06-28 (every coupling cited below was located with `grep` and a file read; line references are approximate and decorative — the file + function names are the load-bearing part). It does **two** things the task asked for:

- **Phase 1 — Tools/coupling audit.** A concrete inventory of *where* the platform is hard-wired to Anthropic/Claude today, file by file, so a build cluster knows exactly what to touch.
- **Phase 2 — Architecture path.** A recommended sequence to (a) a `ModelProvider` abstraction layer and (b) a cheaper grader, with trade-offs.

**Relationship to [ADR 0089](../adr/<redacted>.md).** The *direction* for both goals was already decided with the owner on 2026-06-26 and recorded in ADR 0089 (Accepted; build task-pending): a central work-type-parameterized grading engine, a cross-family ensemble (Claude + hosted open-weight judges), a `ModelProvider` adapter, and a hosted pay-per-call API for the open leg. **This spike does not re-decide any of that** — it supplies the missing input ADR 0089's "Implementation (task-pending)" section presumes: the *grounded coupling map* of the current codebase. Where this doc and ADR 0089 touch the same ground, ADR 0089 is the decision and this doc is the implementation reconnaissance feeding it.

> **Confidence marks:** ✅ verified against the live file this session · 🔧 my synthesis / recommendation · ⚠️ caveat or open question for the owner/build cluster.

---

## 1. Executive summary

**Today the platform is Anthropic-specific in exactly two ways, and they are cleanly separable.** 🔧

1. **The spawn shape** — every LLM call the *platform* makes (grader workers, architect audit, scheduled routines, onboarding analysis, the dispatch ladder) shells out to the **`claude` CLI binary** with `claude -p --model <id> --output-format json`. There is no SDK, no HTTP client, no provider seam — the coupling is "we spawn a specific CLI and parse its JSON envelope."
2. **The model vocabulary** — model identity is a **three-token family string** (`opus` / `sonnet` / `haiku`) threaded through `selectGraderModel`, `llm-pricing`, `cascade-dispatch`, and `skill-prefs`. Cross-family adversariality is *within Anthropic only* (Opus author → Sonnet grader).

The good news for the build: **there is one chokepoint.** Almost every platform LLM call funnels through `grader.runSubagent({prompt, opts})` (and its cached sibling `runSubagentCached`). Architect-audit and the routine runner reuse it; the only spawns that *don't* go through it are a couple of CLI scripts that call `spawn('claude', …)` directly. So a `ModelProvider` port introduced **at `runSubagent`** captures the overwhelming majority of the surface in one place. ✅

**The cheaper grader is the same lever pulled differently.** Grading is purely *additive* spend (we pay Claude to write the code, then pay Claude again — Opus/Sonnet — to grade it). The grader prompt is mostly a **fixed rubric sent every call**, which makes it the ideal candidate for (a) a cheaper open-weight judge via the same `openai-compatible` adapter and (b) prompt-cache amortization (already partly handled by the content-addressed LLM cache, [ADR 0077](../adr/<redacted>.md)). 🔧

**Recommended sequence (detail in §6):** introduce the `ModelProvider` port at `runSubagent` with the existing Claude path as the only registered provider (zero behavior change) → add an `openai-compatible` adapter (DeepInfra/OpenRouter, BYOK, owner spend approval) → generalize `selectGraderModel` into a provider+model registry → run one open judge **advisory-only** (logs, does not gate) → promote to voting once the error-correlation audit ([ADR 0089](../adr/<redacted>.md) §5) shows agreement. This is exactly ADR 0089's staging; this doc just pins each stage to the real files.

---

## 2. Phase 1 — The coupling audit (where Anthropic/Claude is wired in)

### 2.1 The single chokepoint: `runSubagent` (the CLI spawn)

The load-bearing coupling lives in **`modules/grading/grader.js` → `runSubagent({prompt, opts})`** (≈ line 902). ✅ It:

- spawns a binary resolved as `opts.claudeBin ?? process.env.OTB_CLAUDE_BIN ?? process.env.CLAUDE_BIN ?? 'claude'`;
- with args `['-p', '--print', '--model', model, '--output-format', 'json', '--tools', 'Read', '--disable-slash-commands', '--permission-mode', 'bypassPermissions']`;
- writes the prompt to the child's **stdin**, reads JSON from **stdout**;
- pulls the dollar cost out of the **Claude-specific `total_cost_usd` envelope field** (`extractCostUsd`, ≈ line 1012) and the result out of `env.result` (`extractAssistantResult`, ≈ line 1022).

Every assumption here is <redacted>: the binary name, the flag set (`--tools`, `--disable-slash-commands`, `--permission-mode`), the JSON envelope, and the cost field. **This is the function a `ModelProvider` port must wrap.** 🔧

There is already a thin escape hatch (`OTB_CLAUDE_BIN`/`CLAUDE_BIN`) and a cached wrapper `runSubagentCached` (≈ line 997) that routes through `api.llmCache`. The cache wrapper is provider-agnostic in shape (it keys on `{prompt, model, …}`) and will memoize an open-model call unchanged — confirmed by ADR 0077/0089. ✅

### 2.2 The model vocabulary: the `opus`/`sonnet`/`haiku` family triple

Model identity is a **substring-on-the-id** convention repeated in four places. None of them know about a *provider*; all assume the id contains one of three Anthropic family tokens:

| File | Function | Coupling | Mark |
|---|---|---|---|
| `modules/grading/grader.js` | `selectGraderModel({builderModel})` (≈ line 219) | Maps builder family → grader family, **Claude-only**: opus→`claude-sonnet-4-6`, sonnet/haiku→`claude-opus-4-7`. **Throws** on an id without opus/sonnet/haiku (intentional #117 guard — but it makes the function reject *any* non-Claude id outright). | ✅ |
| `modules/grading/grader.js` | constants `ASSUMED_BUILDER_MODEL='claude-opus-4-7'`, `DEFAULT_GRADER_MODEL='claude-sonnet-4-6'` (≈ lines 99–100, sourced from `grader-rubric.json`) | Hard-coded Claude default ids. | ✅ |
| `src/bongos/llm-pricing.js` | `familyFor(model)` + `PRICES` table (≈ lines 40–55) | USD/1M-token table keyed by the three Anthropic families; cache multipliers follow **Anthropic's** published 1.25×/2.0×/0.1× model. Unknown model → priced at opus rate + flagged. | ✅ |
| `src/bongos/cascade-dispatch.js` | `LADDER=['haiku','sonnet','opus']`, `rungIndex`, `startRungForKind` (≈ lines 28–50) | The (dormant, `OTB_AUTONOMY_ENABLED`-gated) cost-tier escalation ladder is three Anthropic rungs. | ✅ |
| `modules/builder-settings/skill-prefs.js` | `ALLOWED_MODELS = ['opus','sonnet','haiku','script']` (≈ line 29) | Per-builder model-ceiling vocabulary (migration 037) is the same three families + `script`. | ✅ |

**Implication:** "model-agnostic" requires generalizing this triple into a `{provider, model}` pair (or a model id the provider registry resolves), and `selectGraderModel`'s Claude-only branch + throw is the function ADR 0089 §3 calls out to replace with a provider registry. ✅

### 2.3 Other direct `claude` spawns (the scripts that bypass `runSubagent`)

Not everything goes through `runSubagent`. A `grep` for direct `claude` spawns / `CLAUDE_BIN` turned up these additional sites — each is a *second* spawn shape to bring under the port (or to leave as-is if it stays Claude-only): ✅

- **`scripts/gds/architect-audit.js`** — *reuses* `grader.runSubagentCached` (so it inherits the port for free) but hard-codes `ARCHITECT_MODEL = 'claude-opus-4-7'` (≈ line 55). One constant to parameterize.
- **`scripts/gds/run-routine.js`** — the scheduled-routine runner; `judgment`/`hybrid` modes "spawn `claude -p`" over a skill body (≈ lines 11–14, 140). Its own spawn helper.
- **`modules/autonomy/pollers/routine-timers.js`** — drives routine spawns (autonomy module).
- **`scripts/gds/onboarding-analyze.js`**, **`scripts/gds/newcomer-floor.js`**, **`scripts/gds/doctor.js`** — each references the `claude` binary directly (onboarding analysis, newcomer-floor classification, env doctor checks).
- **`scripts/gds/session-cost.js`** — does **not** spawn; it *parses* Claude Code's transcript layout: `~/.claude/projects/<encoded-cwd>/*.jsonl`, per-turn `message.usage` token blocks, and excludes grader-worker subprocess transcripts (≈ lines 32–86, `priceTranscript` ≈ line 140). This is a coupling to the **Claude Code interactive harness's on-disk format**, not to the model — see §2.4.

### 2.4 The interactive session is coupled to the harness, not just the model

The main builder session runs inside the **Claude Code CLI harness** itself, which is a deeper coupling than the model id:

- **`session-cost.js`** reads the harness's JSONL transcript format and prices it with `llm-pricing` (the interactive session has no `total_cost_usd` envelope, only token counts — that's the whole reason `llm-pricing.js` exists, per its header). ✅
- The **subagent model-routing policy** lives in `CLAUDE.md §2` as prose ("main session = Opus 4.8 (1M); subagents set `model` explicitly; Haiku for plumbing, Opus for everything else"). It is a *human/agent instruction*, not code — so "model-agnostic" at the interactive tier is partly a **docs/policy** change, not only a code change. ⚠️
- `scripts/gds/cli-lib.js`, `setup.js`, `me.js`, `auth.js`, `db.js`, `db-kernel.js` matched the grep but on inspection reference Claude only in **comments / `~/.config/otb/` paths / the `claude`-CLI auth story**, not in a model call. Low-priority for a provider port; relevant only if the platform ever wants the *interactive* tier on a non-Claude harness (out of scope for ADR 0089, which targets the **grader/platform** calls, not the human's editor). ✅🔧

### 2.5 What is NOT coupled (already abstracted, leave alone)

- **The content-addressed LLM cache** ([ADR 0077](../adr/<redacted>.md), `api.llmCache`) — provider-agnostic by shape; memoizes any `{prompt, model}` call. No change needed; it's a free win for the open leg. ✅
- **The worker contract** (`buildPrompt`/`extractJson`/`computeVerdict` in `modules/grading/grader-workers/`) — model-independent; it builds a prompt and parses JSON. A different model that returns the same JSON schema slots in with no worker change. ✅
- **The deterministic pre-passes** (route-rank, permission-path — `routeRankCheck`/`permissionPathCheck`) — zero-LLM, no model coupling, and per ADR 0089 §6 they **must stay** the authoritative security gate regardless of which model grades quality. ✅
- **The art/vision pipeline** (`modules/art-pipeline/`, Gemini) — a *separate* provider coupling (Google, not Anthropic). ADR 0089 §7 folds it into the same work-type seam later; out of scope for *this* spike's Anthropic-focused audit but flagged so the build cluster knows the second provider exists. ⚠️

---

## 3. The coupling map at a glance

```
                        ┌────────────────────────────────────────────┐
   PLATFORM LLM CALLS   │  selectGraderModel()  ── Claude-only if/else │  ← §2.2 vocabulary
                        │  (opus/sonnet/haiku family triple)           │
                        └───────────────────┬──────────────────────────┘
                                            │ model id (claude-*)
   ┌─────────────────────────┐             ▼
   │ grader workers (panel)  │──┐   ┌───────────────────────┐
   │ architect-audit.js      │──┼──▶│ grader.runSubagent()  │ ← §2.1 THE CHOKEPOINT
   │ (via runSubagentCached) │  │   │  spawn('claude', …)   │   (CLI binary + JSON envelope
   └─────────────────────────┘  │   │  parse total_cost_usd │    + total_cost_usd cost field)
                                 │   └───────────────────────┘
   ┌─────────────────────────┐  │
   │ run-routine.js          │──┘ (own spawn — §2.3, bring under port)
   │ onboarding-analyze.js   │
   │ newcomer-floor / doctor │
   └─────────────────────────┘

   ┌─────────────────────────┐   reads ~/.claude/projects/*.jsonl  ← §2.4 harness coupling
   │ session-cost.js         │──▶ prices via llm-pricing.familyFor() ← §2.2 vocabulary
   └─────────────────────────┘   (interactive tier; no envelope)

   ZERO-LLM, NO COUPLING (leave): route-rank · permission-path · llm-cache · worker contract
```

---

## 4. Phase 2 — Architecture path: the `ModelProvider` abstraction

### 4.1 The seam: a `ModelProvider` port wrapping `runSubagent`

🔧 Introduce a small port whose single method is "given a prompt + model spec, return `{ text, costUsd, raw }`". The current `runSubagent` becomes the **`anthropic-cli` provider** — the only one registered at first, so behavior is identical.

```
ModelProvider (port)
  .complete({ prompt, model, tools, timeoutMs, cwd, cache }) -> { text, costUsd, raw, runMs }

  providers:
    anthropic-cli      (today's runSubagent: spawn `claude -p`, parse total_cost_usd)   [default]
    openai-compatible  (HTTP POST to a base-URL chat/completions endpoint; one adapter
                        covers DeepInfra / OpenRouter / Together / Fireworks / Groq /
                        vLLM / Ollama by base-URL + key)                                 [later]
```

This matches ADR 0089 §3's `ModelProvider` decision exactly. The cost field abstracts the Anthropic-specific `total_cost_usd`: the `anthropic-cli` provider reads the envelope; the `openai-compatible` provider derives cost from `usage` tokens × a price table (reusing/extending `llm-pricing.js`, which is already a pure tokens→USD function — see §4.3). ✅🔧

**Why wrap at `runSubagent` and not higher (e.g. `gradeSubagent`):** `runSubagent` is the lowest common point every platform call already reaches (workers, architect-audit). Wrapping there is the minimal-diff seam — `gradeSubagent`, the worker runner, and architect-audit need no change beyond passing a `{provider, model}` instead of a bare model string. 🔧

### 4.2 Generalizing the model vocabulary

🔧 Replace the bare `opus`/`sonnet`/`haiku` substring convention with a `{ provider, model }` descriptor (or a registry that resolves an id → provider). Concretely:

- **`selectGraderModel`** → a **panel-composition resolver**: given the author's model, return the *list* of `{provider, model}` judges (today: one Claude judge of a different family; later: Claude + one open-weight judge). Its current `throw` on a non-Claude id (#117 guard) becomes a registry lookup miss instead of a hard throw. ✅🔧
- **`skill-prefs.ALLOWED_MODELS`** and **`cascade-dispatch.LADDER`** → extend the vocabulary to admit provider-qualified models. ⚠️ This touches `modules/builder-settings/` (migration 037 jsonb) — a **separate task** from the grader work; flag it as a dependency, do not bundle.
- Keep the three-family **price** semantics in `llm-pricing.js` for Claude, and **add open-model price rows** behind `familyFor` (or a provider-keyed table). ✅

### 4.3 Cost accounting for a non-Claude provider

✅ `llm-pricing.js` is already a clean, pure `priceUsage(model, usage)` → USD function (it exists precisely because the interactive session has token counts but no envelope). The `openai-compatible` adapter returns `usage` (input/output tokens), so the cost path is: **adapter `usage` → `llm-pricing.priceUsage` → cost_log**, mirroring how `session-cost.js` already prices the interactive tier. The only additions are open-model price rows + (optionally) a provider key so a Llama/Qwen/DeepSeek id doesn't fall through `familyFor`'s unknown→opus-rate path and over-price itself. ⚠️ The cache-multiplier model (1.25×/2.0×/0.1×) is Anthropic-specific; open providers have their own (often near-free) cached-input pricing — add a per-provider multiplier set rather than reusing Anthropic's.

### 4.4 Trust boundary (non-negotiable, from ADR 0089 §6)

An open-model verdict that gates a ship is a **content-injection surface** ([ADR 0080](../adr/<redacted>.md)). The abstraction must preserve:

- **Deterministic pre-passes stay authoritative + zero-LLM.** No LLM verdict (Claude or open) can upgrade a route-rank / permission-path fail to pass. The provider port grades *quality* only. ✅
- **Server-side guards (`serverSideGuards`) stay downgrade-only.** The existing envelope (re-run deterministic checks server-side, implausible-pass plausibility bound) is provider-independent and must wrap an open judge's verdict identically. ✅
- **Full audit logging.** Each judge's `{provider, model, raw response}` lands in `signals` so a bad/poisoned verdict is traceable. 🔧

---

## 5. Phase 2 — The cheaper grader (the second goal, same lever)

The grader is the **single best place to spend a cheaper model**, for three reasons grounded in the current code: 🔧

1. **It's additive spend on a fixed prompt.** The worker prompts are a large *fixed rubric* (`grader-rubric.json` + the default-fail `PROMPT_HEADER`) prepended to a per-task diff. A fixed prefix is the ideal cached-input shape — and the LLM cache already memoizes identical `{prompt, model}` grades (§2.5). An open provider's near-free cached input compounds this.
2. **Verification ≠ authorship.** ADR 0089's research finding: a small cross-*lineage* panel correlates *better* with human/owner judgment than one big same-family judge, and is >7× cheaper (PoLL/Verga 2024). The cheaper model isn't a quality compromise — for *judging*, independence is the quality.
3. **The worker contract is already model-independent.** A judge that returns the same `{functional_fidelity, code_quality, economy, confidence, issues}` JSON slots in with zero worker-code change (§2.5).

**Cost shape (from ADR 0089's analysis, not re-verified here):** ⚠️ a few-thousand-grades/month workload on a hosted open API (DeepInfra/OpenRouter) is ~$1–5/mo, with prompt-caching pushing input cost toward zero; self-hosting a GPU (~$200+/mo idle) never breaks even at this volume and is rejected. Treat the specific per-token numbers as provisional vendor figures to confirm at adoption.

**Concrete cheaper-grader moves, in dependency order:** 🔧

1. Land the `openai-compatible` provider (§4.1) — prerequisite.
2. Add **one** open-weight code judge (e.g. a DeepSeek/Qwen-class model) **advisory-only**: it grades and logs to `signals.workers[]`, its verdict does **not** gate. (Pick the checkpoint by live eval against `grade_attempts`, not vendor benchmarks.)
3. Run the **error-correlation audit** (ADR 0089 §5) — replay labeled past grades, compute per-judge Cohen's κ vs owner confirm/reject + pairwise error-correlation.
4. **Only then** promote the open judge to a voting member and (optionally) move one *lens* (e.g. the lighter Hacker/Efficiency workers) off Claude to the open judge to actually *reduce* the Claude bill — keeping Claude as the quality floor.

---

## 6. Recommended sequence (what to build, in order)

🔧 This mirrors ADR 0089's "Implementation (task-pending)" staging, pinned to the files this audit found. Each step is a candidate GDS task; each is behind a flag and ships without destabilizing the live gate.

| # | Step | Primary files | Behavior change | Owner cost ask |
|---|---|---|---|---|
| 1 | **`ModelProvider` port at `runSubagent`** | `modules/grading/grader.js` (`runSubagent`, `runSubagentCached`, `extractCostUsd`) | None — Claude is the only registered provider | none |
| 2 | **`openai-compatible` adapter** (base-URL + key; cost via `usage`) | new adapter + `src/bongos/llm-pricing.js` (open-model rows) | None until called | **BYOK open-model key; spend go-ahead** |
| 3 | **Generalize `selectGraderModel` → panel-composition resolver** ({provider, model} list) | `modules/grading/grader.js`; `grader-rubric.json` (panel config) | None — still resolves to one Claude judge by default | none |
| 4 | **Open judge, advisory-only** (grades + logs, does not gate) | `modules/grading/grader-workers/`, `grader.js` aggregation | Open verdict logged in `signals`; gate unchanged | the first live open-model spend |
| 5 | **Error-correlation audit routine** | new `.claude/scheduled-tasks/` routine + read `grade_attempts` | none (offline) | negligible |
| 6 | **Promote open judge to voting; move a lens off Claude** | `grader.js` aggregation (normalize + median + hard-veto) | Gate composition changes (flagged) | net-neutral/negative |
| 7 | **(Adjacent) generalize `skill-prefs`/`cascade-dispatch` vocabulary** | `modules/builder-settings/skill-prefs.js`, `src/bongos/cascade-dispatch.js` | per-builder model picks admit providers | none |

**Sequencing rationale:** steps 1–3 are pure-refactor / zero-behavior-change groundwork that can land safely under the live gate; the first real spend (and the first owner approval) is step 2's key + step 4's first call. The cheaper-grader payoff (step 6) is deliberately *last*, gated on the audit (step 5) proving the open judge agrees with the owner — never trade quality for cost on faith. Step 7 is adjacent vocabulary work that should be its **own** task (it touches `modules/builder-settings/` + a jsonb column) and is *not* a blocker for the grader path.

---

## 7. Open questions for the owner / build cluster

- ⚠️ **Provider + checkpoint.** ADR 0089 names DeepInfra/OpenRouter as transport and DeepSeek/Qwen-class as the open code judge, but says to pick the exact checkpoint by *live evaluation*, not vendor numbers. The error-correlation audit (step 5) is the decision instrument — build it before committing to a specific model.
- ⚠️ **Interactive-tier scope.** This spike (and ADR 0089) target the **platform/grader** calls. Making the *human's interactive session* model-agnostic (a different harness than Claude Code) is a much larger, separate question — `session-cost.js`'s transcript-format coupling (§2.4) and the `CLAUDE.md §2` routing policy would both move. Recommend explicitly **deferring** it; GDS-V4's per-builder model preferences ([idea #30](https://example.com/builders#/idea/30)) is the place that conversation belongs.
- ⚠️ **The Gemini/vision provider** is a second, parallel coupling (Google, in `modules/art-pipeline/`). ADR 0089 §7 folds it into the same work-type seam; if the build cluster wants one provider abstraction to cover *both* Anthropic and Google, the port in §4.1 should be designed with the vision path in mind from step 1 (a `complete` that can carry image evidence), not retrofitted.
- ⚠️ **`selectGraderModel`'s #117 throw.** It deliberately throws on an unrecognized model id to avoid silently grading on a wrong cross-family assumption. The provider-registry refactor must preserve that loud-failure intent (a misconfigured provider/model should fail loudly, not default silently) — don't regress the #117 guard into a silent fallback.

---

## 8. Follow-up code tasks (recommendations — not created by this spike)

Per the task's instruction, this doc lists recommended follow-ups rather than creating them. Each maps to a row in §6:

1. **`ModelProvider` port + `anthropic-cli` provider** (refactor `runSubagent`; no behavior change). [§6 step 1]
2. **`openai-compatible` provider adapter** + open-model price rows in `llm-pricing.js` (BYOK key; owner spend approval). [§6 steps 2–3]
3. **Open code judge, advisory-only** — log to `signals`, do not gate. [§6 step 4]
4. **Error-correlation audit routine** — κ + pairwise correlation over `grade_attempts`. [§6 step 5]
5. **Promote open judge to voting** + heterogeneous aggregation (z-score/rank normalize → median + hard-veto). [§6 step 6]
6. **Generalize per-builder model vocabulary** (`skill-prefs`, `cascade-dispatch`) to admit providers — separate, non-blocking. [§6 step 7]

---

## 9. Sources

- The live repo, read 2026-06-28: `modules/grading/grader.js`, `modules/grading/grader-workers/index.js`, `modules/grading/CLAUDE.md`, `src/bongos/llm-pricing.js`, `src/bongos/cascade-dispatch.js`, `modules/builder-settings/skill-prefs.js`, `scripts/gds/ci-grade.js`, `scripts/gds/architect-audit.js`, `scripts/gds/session-cost.js`, `scripts/gds/run-routine.js`.
- [ADR 0089 — Modular, multi-model adversarial grader](../adr/<redacted>.md) (the accepted direction this spike grounds; includes the external literature + market sweep — self-preference, PoLL, *Nine Judges*, open-weight model licenses, hosting math).
- [ADR 0028 — Honest LLM spend accounting](../adr/<redacted>.md), [ADR 0077 — Content-addressed LLM cache](../adr/<redacted>.md), [ADR 0080 — LLM cache API transport & trust model](../adr/<redacted>.md), [ADR 0062 — Instance-model decoupling](../adr/<redacted>.md), [ADR 0021 — Per-builder skill model preferences](../adr/<redacted>.md).
