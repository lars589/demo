// public-builders/task.js — the task-detail PAGE (/task/:id, task 751).
//
// Replaces the #/task/N overlay (task-detail.js's old ~166-LOC taskBody) with a
// real, shareable, indexable page: /builders/task/:id on the apex,
// builders.<apex>/task/:id on the subdomain (the rewrite shim in
// serve-internal.js normalizes both to the same served HTML). The server gates
// the page itself (SIGNEDIN_BUILDERS_PAGE_RE + the two-segment TASK_DETAIL_PAGE_RE),
// so an unauthenticated visitor never reaches this script.
//
// READ + NAVIGATION ONLY (task 751 scope) — no claim/release/ship action lives
// here. The "Copy prompt" button is purely client-side (clipboard write, no
// server call), same posture as the Work Board's copy action. Claim/release
// from the browser is the dependent follow-up task.

(() => {
  'use strict';

  const API = '/api/gds';
  // Generated typed client (task 1996 / R09), served as window.BongosClient by
  // /lib/bongos-client.js. baseUrl:'' passes the full same-origin paths this file
  // builds through unchanged; result-mode ({ status, ok, data }) preserves control flow 1:1.
  const api = window.BongosClient.createClient({ baseUrl: '', credentials: 'same-origin', throwOnError: false });
  const AUTH_NEEDED = 'auth-needed';
  const { escapeHtml, $, fmtDate } = window.OTB;
  const toast = (msg) => window.OTB.toast(msg, { duration: 2600 });
  const curLabel = () => (window.__BRANDING__ && window.__BRANDING__.currency && window.__BRANDING__.currency.label) || 'credits';

  function toAuth() {
    window.location.assign(`${API}/auth/web/start`);
  }

  async function getJSON(path, opts = {}) {
    const res = await api.request('GET', path);
    if (res.status === 401) {
      if (opts.softAuth) {
        const err = new Error(AUTH_NEEDED);
        err.code = AUTH_NEEDED;
        throw err;
      }
      toAuth();
      throw new Error('redirecting to auth');
    }
    if (!res.ok) {
      const err = new Error(`${path} → ${res.status}`);
      err.status = res.status;
      throw err;
    }
    return res.data;
  }

  // task 759: mutating call (ship / confirm). Cookie-authed, same posture as the
  // Work Board's postJSON — resolves to the parsed 2xx body, throws an Error
  // carrying { status, data } on a non-2xx so the caller can map the server's
  // typed lifecycle-error code to a friendly line. A 401 bounces to sign-in.
  async function postJSON(path, body) {
    const res = await api.request('POST', path, { body: body || {} });
    if (res.status === 401) { toAuth(); throw new Error('redirecting to auth'); }
    let data = null;
    try { data = res.data; } catch (_) { /* empty / non-JSON body */ }
    if (!res.ok) {
      const err = new Error(`${path} → ${res.status}`);
      err.status = res.status;
      err.data = data || {};
      throw err;
    }
    return data;
  }

  // Map the server's typed lifecycle-error to a builder-readable line. Codes are
  // exactly those POST /tasks/:id/ship + /confirm can return. The server is the
  // authority (ADR 0016); the UI only surfaces the refusal.
  function friendlyActionError(status, data) {
    switch (data && data.error) {
      case 'task_not_confirmed':
        return 'That task can only be shipped once it is confirmed (its grade has landed).';
      case 'task_not_completed':
        return 'That task is not marked complete yet.';
      case 'verify_attestation_required':
        return (data && data.message) || 'Confirm a verification task only after the verify actually passed.';
      case 'rank_too_low_for_task':
      case 'INSUFFICIENT_RANK':
        return 'Your rank is not high enough for that action.';
      case 'not_your_task':
        return 'Only the task’s claim holder or an Archon can take that action.';
      default:
        return status === 403
          ? 'You are not allowed to take that action.'
          : `Could not complete that (${status || '?'}). Try again.`;
    }
  }

  // task 759: run a lifecycle action (ship / confirm), then reload so the page
  // re-renders at the new status. On failure, surface the server's refusal and
  // re-enable the button. `load` is hoisted below.
  async function runLifecycle(btn, url, body, okMsg) {
    const orig = btn.textContent;
    btn.disabled = true;
    btn.textContent = '…';
    try {
      await postJSON(url, body);
      toast(okMsg);
      await load();
    } catch (err) {
      if (err && err.message === 'redirecting to auth') return;
      toast(friendlyActionError(err && err.status, err && err.data));
      btn.disabled = false;
      btn.textContent = orig;
    }
  }

  // Same base-URL logic as work.js's buildPromptForTask / task-detail.js's
  // redirect — the hall is mounted at "/" on builders.<apex> and at "/builders"
  // on the apex host.
  function hallBase() {
    return location.hostname.startsWith('builders.') ? '' : '/builders';
  }

  function taskIdFromPath() {
    const m = /\/task\/(\d+)/.exec(location.pathname);
    return m ? m[1] : null;
  }

  function rankText(rr) {
    const r = (rr || 'xenos').toLowerCase();
    if (r === 'xenos') return 'any rank';
    if (r === 'archon') return 'Archon';
    return r.charAt(0).toUpperCase() + r.slice(1) + '+';
  }

  function fmtRel(iso) {
    if (!iso) return '';
    const sec = (Date.now() - new Date(iso).getTime()) / 1000;
    if (sec < 3600) return `${Math.max(1, Math.floor(sec / 60))}m ago`;
    if (sec < 86400) return `${Math.floor(sec / 3600)}h ago`;
    return `${Math.floor(sec / 86400)}d ago`;
  }

  function depList(kindWord, items) {
    const rows = items.map((d) => {
      const status = d.status ? `<span class="td-dep-status">${escapeHtml(d.status)}</span>` : '';
      return `<li><a class="td-dep" href="${hallBase()}/task/${escapeHtml(String(d.id))}">#${escapeHtml(String(d.id))} — ${escapeHtml(d.title || 'task')}</a>${status}</li>`;
    }).join('');
    return `<div class="td-deps"><p class="td-section-h">${escapeHtml(kindWord)}</p><ul class="td-dep-list">${rows}</ul></div>`;
  }

  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); return true; }
    catch (_) {
      try {
        const ta = document.createElement('textarea');
        ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select();
        const ok = document.execCommand('copy'); ta.remove();
        return ok;
      } catch (_e) { return false; }
    }
  }

  function buildPrompt(t) {
    const url = `${location.origin}${hallBase()}/task/${t.id}`;
    const desc = String(t.description || '').replace(/(^|\s)#(\d+)\b/g, '$1$2');
    return `I am working on GDS task ${t.id} (${t.title || ''}) — ${url}\n\n` +
      `Claim it with \`/builder-claim ${t.id}\`, build it, then \`/builder-ship ${t.id}\`.\n\n` +
      `Task description:\n${desc}`;
  }

  function renderTask(t, lastClaim, viewer) {
    document.title = `#${t.id} — ${t.title || 'Task'} — ${document.title.split(' — ').pop()}`;
    const sub = $('#task-sub');
    if (sub) sub.textContent = `Task #${t.id}`;

    const parts = [];
    parts.push(`<p class="deeplink-card__kind">TASK <span class="task-status-pill task-status-pill--${escapeHtml(t.status || '')}">${escapeHtml(t.status || 'unknown')}</span></p>`);
    parts.push(`<h1 class="deeplink-card__title" id="task-h">#${t.id}${t.title ? ' — ' + escapeHtml(t.title) : ''}</h1>`);

    const meta = [];
    if (t.version_id) meta.push(escapeHtml(t.version_id));
    if (t.kind) meta.push(escapeHtml(t.kind));
    if (t.discipline && t.discipline !== 'unclassified') meta.push(escapeHtml(t.discipline));
    if (t.priority != null) meta.push('P' + escapeHtml(String(t.priority)));
    meta.push('min: ' + escapeHtml(rankText(t.requires_rank)));
    const creditVal = window.OTBBranding?.taskCreditValue?.(t) ?? t.credits_reward;
    if (creditVal != null) meta.push(`${creditVal} ${window.OTBBranding?.taskCreditLabel?.(t) ?? curLabel()}`);
    if (t.est_minutes) meta.push(`${t.est_minutes}m`);
    parts.push(`<p class="deeplink-card__meta">${meta.join(' · ')}</p>`);

    if (t.goal_id) {
      parts.push(`<p class="td-goal">Goal: <a href="/goals#/goal/${encodeURIComponent(t.goal_id)}">Goal #${escapeHtml(String(t.goal_id))}</a></p>`);
    }

    // Claim history (task 751 — best-effort: the API surfaces the most recent
    // claim holder, not the full ledger of every past claim).
    if (lastClaim) {
      const who = escapeHtml(lastClaim.github_login || 'a builder');
      const when = lastClaim.claimed_at ? fmtDate(lastClaim.claimed_at, { time: true }) : '';
      const state = lastClaim.released_at
        ? (lastClaim.outcome ? `released (${escapeHtml(lastClaim.outcome)})` : 'released')
        : 'holding this claim';
      parts.push(`<p class="task-detail__claim">Last claimed by <strong>${who}</strong> ${when ? 'on ' + escapeHtml(when) : ''} — ${state}.</p>`);
    }

    if (t.value_summary) {
      parts.push(`<p class="td-goal"><strong>Value:</strong> ${escapeHtml(t.value_summary)}</p>`);
    }

    if (t.description) {
      parts.push(`<div class="td-desc">${escapeHtml(t.description)}</div>`);
    }

    const touches = Array.isArray(t.touches) ? t.touches : [];
    if (touches.length) parts.push(`<p class="td-touches">✎ ${touches.map(escapeHtml).join(', ')}</p>`);

    const deps = Array.isArray(t.dependencies) ? t.dependencies : [];
    const dependents = Array.isArray(t.dependents) ? t.dependents : [];
    if (deps.length) parts.push(depList('Blocked by', deps));
    if (dependents.length) parts.push(depList('Blocks', dependents));

    if (t.shipped_at) {
      const by = t.shipped_by ? ` by builder #${escapeHtml(String(t.shipped_by))}` : '';
      parts.push(`<p class="deeplink-card__note">Shipped ${escapeHtml(fmtRel(t.shipped_at))}${by}.</p>`);
    }

    // task 759: lifecycle action from the browser (no /builder-* CLI). The server
    // enforces every rank + ownership gate (ADR 0016); we only surface the control
    // the caller is actually allowed to use, and map any refusal to a friendly
    // toast. `confirmed → shipped` is the any-builder-supervisor / own-claim ship;
    // `completed → confirmed` is the Archon-only grader-bypass confirm (others see
    // a read-only note — the grader/Archon still has to act).
    const rank = (viewer && viewer.rank) ? String(viewer.rank).toLowerCase() : '';
    const isSupervisor = rank === 'metic' || rank === 'archon';
    const ownsLastClaim = !!(viewer && lastClaim && lastClaim.github_login &&
      lastClaim.github_login === viewer.github_login);
    let lifecycle = '';
    if (t.status === 'confirmed' && (isSupervisor || ownsLastClaim)) {
      lifecycle = `<button class="td-btn td-btn--primary" type="button" id="ship-btn">Ship it</button>`;
    } else if (t.status === 'completed') {
      lifecycle = rank === 'archon'
        ? `<button class="td-btn td-btn--primary" type="button" id="confirm-btn">Confirm</button>`
        : `<p class="td-action-note">Awaiting the grader / a confirmation before it can ship.</p>`;
    }

    // Copy prompt (the "ship link") — the same claim/build/ship prompt the Work
    // Board hands an agent. Purely client-side (clipboard write, no server call).
    parts.push(`
      <div class="td-actions">
        ${lifecycle}
        <button class="td-btn" type="button" id="copy-prompt-btn">Copy prompt</button>
        <a class="td-btn" href="${hallBase()}/work">Open the Work Board</a>
      </div>
    `);

    const body = $('#task-body');
    if (body) body.innerHTML = parts.join('');

    const copyBtn = $('#copy-prompt-btn');
    if (copyBtn) {
      copyBtn.addEventListener('click', async () => {
        const ok = await copyText(buildPrompt(t));
        copyBtn.textContent = ok ? 'Copied ✓' : 'Copy failed';
        toast(ok ? `Prompt for #${t.id} copied to your clipboard.` : 'Could not copy to the clipboard.');
        setTimeout(() => { copyBtn.textContent = 'Copy prompt'; }, 1600);
      });
    }

    const shipBtn = $('#ship-btn');
    if (shipBtn) {
      shipBtn.addEventListener('click', () => {
        runLifecycle(shipBtn, `${API}/tasks/${encodeURIComponent(t.id)}/ship`, null, `#${t.id} shipped.`);
      });
    }
    const confirmBtn = $('#confirm-btn');
    if (confirmBtn) {
      confirmBtn.addEventListener('click', () => {
        // A verify-kind task's confirm attests the verification actually passed
        // (the server requires { verified: true }); make the Archon affirm it.
        if (t.kind === 'verify' && !window.confirm(`Confirm that verification for #${t.id} actually passed?`)) return;
        const body = t.kind === 'verify' ? { verified: true } : {};
        runLifecycle(confirmBtn, `${API}/tasks/${encodeURIComponent(t.id)}/confirm`, body, `#${t.id} confirmed.`);
      });
    }
  }

  function renderNotFound(id) {
    const body = $('#task-body');
    if (body) body.innerHTML = `
      <p class="deeplink-card__title" id="task-h">#${escapeHtml(String(id))} — no such task</p>
      <p class="deeplink-card__note">Tasks are numbered separately from GitHub pull requests, so this may be a PR rather than a GDS task.</p>
    `;
    const sub = $('#task-sub');
    if (sub) sub.textContent = 'Not found';
  }

  function renderError(id) {
    const body = $('#task-body');
    if (body) body.innerHTML = `
      <p class="deeplink-card__title" id="task-h">Could not load #${escapeHtml(String(id))}</p>
      <p class="deeplink-card__note">Try reloading in a moment.</p>
    `;
  }

  async function load() {
    const id = taskIdFromPath();
    if (!id) { renderNotFound(''); return; }
    try {
      const d = await getJSON(`${API}/tasks/${encodeURIComponent(id)}?include=last_claim`, { softAuth: true });
      if (!d || !d.task) { renderNotFound(id); return; }
      // Best-effort viewer probe so we know which lifecycle control (if any) the
      // caller is allowed to see. A failure just means no action buttons render —
      // the page still reads (task 759).
      let viewer = null;
      try {
        const me = await getJSON(`${API}/me`, { softAuth: true });
        viewer = (me && me.builder) ? me.builder : null;
      } catch (_) { /* cosmetic — the server enforces regardless */ }
      renderTask(d.task, d.last_claim || null, viewer);
    } catch (err) {
      if (err && err.code === AUTH_NEEDED) { toAuth(); return; }
      if (err && err.status === 404) { renderNotFound(id); return; }
      if (err && err.message === 'redirecting to auth') return;
      console.error('[task] load failed:', err);
      renderError(id);
    }
  }

  document.addEventListener('DOMContentLoaded', load);
})();
