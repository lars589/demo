# ADR 0095 — Borrowed memory, retrieval & collision concepts from claude-mem and graphify

**Status:** Proposed (owner-directed 2026-06-27; pending claim + companion ADR)
**Track:** internal
**Builds on:** [ADR 0060](0060-gds-retrieval-layer.md) (recall / retrieval layer), [ADR 0063](<redacted>.md) (generated repo-map symbol skeleton), [ADR 0094](<redacted>.md) (repo atlas), [ADR 0049](<redacted>.md) (touches[] advisory), [ADR 0082](<redacted>.md) (server-side conflict resolver), [ADR 0091](<redacted>.md) (memory module carve), [ADR 0026](<redacted>.md) / [ADR 0027](<redacted>.md) (BFG memory).
**Pairs with:** a companion owner-authored ADR on **grep vs. a semantic/embedding retrieval layer**. This ADR deliberately does **not** decide that question — every item below is independent of which retrieval mechanism we run.
**Sources evaluated:** [graphify](https://github.com/safishamsi/graphify) (MIT, Python) and [claude-mem](https://github.com/thedotmack/claude-mem) (Apache-2.0, JavaScript), in the 2026-06-27 research session.

## Context

We evaluated two mature, widely-starred Claude-Code tools that overlap our internal stack:

- **graphify** — turns a codebase + docs into a queryable knowledge graph (tree-sitter AST + LLM-inferred edges + Leiden clustering), shipped as a `/graphify` skill + MCP server.
- **claude-mem** — automatic persistent session memory (lifecycle hooks capture every tool use → AI-compressed summaries → reinjected next session), backed by SQLite + a Chroma vector DB.

Both overlap things we already run — recall ([ADR 0060](0060-gds-retrieval-layer.md)), the generated repo-map ([ADR 0063](<redacted>.md)) and the repo atlas ([ADR 0094](<redacted>.md)), the carved memory module ([ADR 0091](<redacted>.md)), the `learnings` table, and `touches[]`/merge-collision handling ([ADR 0049](<redacted>.md), [ADR 0082](<redacted>.md)).

**Neither fits wholesale**, for reasons specific to us:
- graphify is **Python** — a foreign runtime bolted beside a Node/Postgres codebase; it could only ever sit *next to* the GDS, never inside it.
- claude-mem's architecture is **local-first, single-developer** (a per-machine daemon + local SQLite + a Chroma vector service pulling in a Python/`uv` dependency). We are **centralized and multi-builder** (memory syncs to one Postgres on the droplet, rank-scoped, with the BFG doing cross-builder work). The shape is wrong.
- graphify's graph has **no rank-scoping**; committing a full-repo graph would expose permission-core structure to low-rank builders, against [ADR 0016](<redacted>.md).
- Both run an **open-core commercial play** (graphify → Penpax; claude-mem → a server/team beta), and claude-mem additionally endorses an associated **memecoin** — governance signals that argue against *depending* on either, though not against reading them.
- Claude Code itself deliberately favours **live agentic search over a prebuilt index** (freshness, simplicity) — the philosophy we already follow with lexical recall + a generated map.

But several *concepts* in these tools are stack-agnostic, cheap, and land on real gaps. This ADR records **which concepts we adopt and why**, and **what we decline**. The unifying principle: **borrow concepts, not tools** — reimplement in our own Node/Postgres stack, import no third-party code, add no new service, and stay inside the budget and the trust boundary.

## Decision

Adopt the following eight concepts. Each is reimplemented in-stack; none requires a new dependency or service (the one exception — a parser for the AST work — is called out in G2).

### From graphify (the "Tier-2" borrows)

- **G1 — Symbol-level collision detection.** Move `touches[]` overlap from *path-prefix* to *symbol/dependency* awareness (`src/bongos/path-match.js` `touchesOverlap`/`matchOne`, consumed by `claims.js`). **Why:** path-prefix over-flags — two tasks editing different functions in one big file (e.g. `db.js`) are falsely serialized, costing parallelism — and under-detects, missing cross-file collisions where one task changes a symbol another file depends on. [ADR 0049](<redacted>.md) already cut the *cost of being wrong* (touches is advisory, backfilled from the real diff); this attacks the *accuracy of the forecast*, the remaining lever. `git merge` stays the ground-truth backstop.
- **G2 — AST-based repo-map upgrade.** Replace the regex symbol extractor with a real parser via the `extractFile()` seam [ADR 0063](<redacted>.md) explicitly left for this (`scripts/gds/gen-repo-map.js`). **Why:** the regex extractor is server-JS-only, conflates two symbols that share a name, and builds no call graph. A parser (tree-sitter, **WASM build** — which sidesteps the `node-gyp` native-compile cost that [ADR 0063](<redacted>.md) rejected) gives polyglot coverage (the Python `art/` pipeline, client `public/game/` JS, SQL), real symbol resolution, and a dependency graph. That graph is the **substrate G1 needs**, and it feeds [ADR 0094](<redacted>.md)'s atlas **truer edges** than today's `fitness.js` regex-on-`require` facts. This is the one item with a (vendored, no-native-build) dependency cost; accepted for the payoff.
- **G3 — Surface the "why," forward-facing.** Extract design rationale (`# WHY:`/`# HACK:`/docstrings + ADR rationale) and attach it to the code it explains, surfaced *at the moment of work* rather than left in an archive. **Why:** we already *pay* to capture "why" (the ADR culture, the `# WHY:` convention) — but capture ≠ surfacing, and our builders are memoryless AI agents with a strong instinct to "tidy" load-bearing code, re-breaking solved problems (the fences in our own learnings/memory log). Cheap first cut: feed `# WHY:` + ADR rationale into the recall index; later, auto-inject the governing ADR when an agent opens a file it covers.

### From claude-mem (concepts 1–5)

- **C1 — Progressive-disclosure retrieval with token-cost visibility.** Layer recall into *cheap index → batch detail*: return a compact index first (IDs + titles, ~tens of tokens each), then fetch full bodies only for the few the agent selects (`modules/memory/routes/search.js`, `scripts/gds/recall.js`, the recall skill). **Why:** recall returns a flat list of snippets today; layering it yields ~10× fewer tokens per query (claude-mem's documented figure), which compounds across every session and serves the $5K / token-frugal posture directly. **Independent of grep-vs-semantic** — it's a presentation/cost pattern over whatever retrieval leg(s) the companion ADR chooses.
- **C2 — Hook graceful-degradation policy.** Codify one rule across the hook fleet (`.claude/hooks/*`, memory-sync in `ship.js`, the Conductor): an **infrastructure** failure (ECONNREFUSED / timeout / 5xx) → **exit 0, never block** the builder; a **code bug** (4xx / TypeError) → **exit 2, block** so it's fixed. **Why:** we run many hooks; a droplet hiccup must never freeze a session mid-work. (The unreachable-API condition encountered while authoring this very ADR is the canonical example.)
- **C3 — Memory-usefulness feedback loop.** Record whether a recalled chunk / learning was actually used, and let that signal drive ranking and decay (`modules/memory`, `learnings`). **Why:** nothing today tracks whether recalled knowledge helped; a usefulness signal lets high-value memory rise and dead weight fade, keeping the corpus high-signal as it grows. Pairs naturally with graphify's `save-result` (useful / dead_end / corrected).
- **C4 — `<private>` content-exclusion marker.** A tag an agent can wrap around sensitive content so it never enters the memory store (`modules/memory` ingest; complements the BFG transcript scrub). **Why:** a simple, explicit opt-out that reinforces the trust boundary ([ADR 0016](<redacted>.md)) — secrets, permission-core internals, sub-Metic-sensitive material fenced out at the source.
- **C5 — Windowed content-hash dedup.** On write, hash `(session + title + body)` and, if the same hash reappears within a short window, reuse the existing row instead of inserting (`modules/memory`, `learnings.js`). **Why:** stops near-duplicate memory/learning entries; complements the existing `source_ref` soft-idempotency.

## What we decline (and why)

- **Adopting either tool wholesale** — stack/architecture/trust mismatch (see Context).
- **Lifting graphify's Python code** — foreign runtime; borrow patterns, not source.
- **claude-mem's local-daemon + SQLite + Chroma architecture** — wrong shape for a centralized, multi-builder, Postgres server.
- **The Chroma / `uv` vector dependency** — exactly the dependency weight we deferred embeddings to avoid. *If* we ever add semantic retrieval, it is `pgvector` inside the existing Postgres — but **that decision belongs to the companion grep-vs-semantic ADR**, not here.
- **Automatic capture of every session** (claude-mem's default) — continuous token cost + noise risk; our deliberate capture is cheaper and higher-signal. Folded in only as auto-*suggestion*: the BFG may *propose* memory/learning entries for confirmation, never auto-commit.
- **Headline star counts as evidence** — treated as marketing signal; these choices weigh maturity, license, and fit, not stars.

## Consequences

- **Positive.** Sharper parallelism + fewer surprise merge conflicts (G1); a polyglot, symbol-accurate map that also strengthens the atlas (G2); load-bearing rationale that stops agents re-breaking fences (G3); cheaper recall per query (C1); hooks that never freeze a session (C2); a self-cleaning, higher-signal memory corpus (C3–C5). All in-stack, no new service.
- **Cost.** Eight follow-on tasks of varied size; G2 is the heaviest (a vendored WASM parser + reworking `gen-repo-map.js`). All modest against the budget. Each ships under its own claim and gate.
- **Neutral / boundary.** Nothing here changes the retrieval *mechanism* (grep vs. semantic) — that is the companion ADR's call, and C1/G3 are written to compose with whatever it decides. Single-process / single-package / no-new-daemon preserved.

## Alternatives considered

- **Adopt graphify and/or claude-mem wholesale** — rejected: stack mismatch, dependency weight, no rank-scoping (graphify), local-first single-dev architecture (claude-mem), and open-core/memecoin governance risk. Reading them is valuable; depending on them is not.
- **Do nothing (status quo)** — rejected: the gaps (false-serializing collisions, JS-only map, archived-not-surfaced "why," flat full-cost recall) are real and recurring; these borrows are cheap relative to the pain.
- **Bundle the semantic-retrieval decision into this ADR** — rejected: the owner is authoring it separately; keeping the retrieval-mechanism choice in one place avoids splitting it across two records, and every item here is deliberately mechanism-agnostic.
- **One ADR per concept** — rejected: these eight share one rationale (borrow-concepts-not-tools, from one evaluation); a single record keeps that reasoning together. Each still gets its own implementing task.
