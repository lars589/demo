# ADR 0039 — Setup-first onboarding UX: two-config selector + action-only Path checklist

**Date:** 2026-06-06
**Context:** GDS-V3, task [#777](https://example.com/builders#/task/777). Feeds done-when criterion **C1** (`a newcomer onboards in ≤ 2h`). Builds on [ADR 0035](<redacted>.md) (three onboarding paths), [ADR 0038](<redacted>.md) (the box-hosted ttyd browser terminal, now hardware-verified under [#771](https://example.com/builders#/task/771)), [ADR 0033](<redacted>.md) (the Discord OAuth account-link + auto-join), and [ADR 0034](<redacted>.md)/[#692](https://example.com/builders#/task/692) (the 3-ship xenos→thetes promotion).
**Status:** Accepted. Implemented this session under [#777](https://example.com/builders#/task/777).
**Track:** `internal` (dev-system / builder onboarding).

## Problem

The builders'-hall onboarding (the "Welcome to the Hall" panel + the "Path into the City" checklist) had two faults for a **zero-technical** newcomer who **won't read paragraphs**:

1. **Setup and milestones were tangled.** The welcome panel mixed *how to get a working environment* (install Claude Code, clone the repo, run `/builder-setup`) with *what to do next*, in dense prose. It also still told newcomers to clone a repo locally — but post-[ADR 0035](<redacted>.md) a Xenos is **box-only** and never clones anything to their own machine.
2. **The first checklist step was redundant.** "Bear the city's seal" (GitHub sign-in) is already done — a builder signed in with GitHub to even see the page.

## Decision

**Show ONLY setup first, as a two-config selector; then a short, action-only orientation checklist.**

### 1. Setup screen — pick how you connect to your dev box

Both configs reach the SAME hosted dev box (Xenos are box-only, [ADR 0035](<redacted>.md)); the choice is only the *client*:

- **Claude Desktop app (recommended)** — install the desktop app, open it on an empty folder, then paste a single instruction telling Claude to **read the hosted connect guide** (`GET /api/gds/box/connect`) and follow it. That guide (already served, public, no secrets) runs the OS-appropriate `box-connect` bootstrap (device-flow GitHub sign-in + SSH key + Desktop connection file). Then connect via *Code → Environment → "Example Dev Box"*.
- **Claude Online (browser only)** — no install; the hall **delivers the box terminal automatically**: one "Set up my dev box" button calls `POST /box/ensure` (auto-provision/wake; [#701](https://example.com/builders#/task/701)) and polls `GET /box/terminal`, then shows the ttyd URL + password ([ADR 0038](<redacted>.md)) right in the panel. Open it and type `claude`. No SSH, no `#support` relay.

**Why the hosted guide (not "type a `/builder-*` command"):** a brand-new builder has no repo and therefore none of the project's `/builder-*` skills locally. Pointing Claude at the public guide URL is self-contained — Claude fetches it and runs the bootstrap with nothing pre-installed. The bootstrap self-authenticates via device flow, so it does **not** require `/builder-setup` first.

Steps are short, scannable, and plain-spoken (the Mediterranean theme stays in the headings). The repo-clone walkthrough — and the `/public/repo-info` fetch that fed it — is removed from the newcomer panel. Getting the box itself is requested in Discord `#support` (an Archon provisions it — the [ADR 0035](<redacted>.md) §2 first-box cost gate).

### 2. "The Path into the City" — orientation, action-only, all auto-detected

Four displayed steps: **Join the Discord server** → **Choose thy craft** → **Run `/builder-setup`** → **Ship three works — and rise to Thetes**. The redundant GitHub-sign-in step is dropped from display, as are `first_start`/`first_claim` (implied by shipping). **Every step auto-detects — no manual ticking** ("the city watches"):

- **join_discord** clears when the builder links Discord. The button runs the **existing** OAuth flow (`GET /api/gds/auth/discord/start`, [ADR 0033](<redacted>.md)) — same control as `/builders/settings` — which auto-joins the guild + assigns the rank role; `discord.linked` then reads true. No new Discord backend.
- **cli_setup** clears once the builder has authenticated the GDS CLI — i.e. run `/builder-setup` (or the box-connect bootstrap); both mint a `source='cli'` session. Detected via `db.hasCliSession` (an `EXISTS` over `builder_sessions`); no manual mark.
- **pick_disciplines** / **ship_three** are the existing engine-backed steps (craft picker; 3-ship counter).

### 3. Display layer split from the graduation engine

The displayed list is a **read-only view** computed by `shapeForApi(state, { shipCount, discordLinked, cliAuthed })` — it does NOT change the onboarding state machine. The engine `STAGES` array (`auth_complete`…`ship_three`) is untouched, so graduation — and therefore the 3-ship xenos→thetes promotion ([#692](https://example.com/builders#/task/692)) and the graduation broadcast — stays driven **solely by ship-count**, independent of the displayed steps. `join_discord`/`cli_setup` are derived from live signals already available server-side (`discord.linked`, a `source='cli'` session) — **no new column, no migration, no write endpoint**.

## Consequences

- A newcomer sees setup first, picks a config, follows 3–4 plain steps to a working `claude` session, then a 4-step orientation path that ticks itself as they go.
- No new tables/columns/endpoints: both new steps are pure derivations in `GET /api/gds/me` (and the `PATCH /me/disciplines` echo). `db.hasCliSession(builderId)` is the only new helper.
- **The only thing that gates the rank-up is shipping three works.** The orientation steps are informational; a builder is never blocked by them.
- Connect is bootstrapped from the **hosted `GET /api/gds/box/connect` guide** so a builder with no local repo/skills can still onboard (Claude fetches + runs it).
- **Config B self-serves the terminal in the hall** (`POST /box/ensure` → poll `GET /box/terminal` → show URL + password) — the `#support` relay is gone. A newcomer's first box still waits for a quick Archon approval (ADR 0035 §2 cost gate), surfaced as a "waiting for approval" state. The remaining hardware dependency ([#774](https://example.com/builders#/task/774)) is the box's terminal reporter publishing its URL on a bare first boot; once it does, the hall shows it automatically.
- The "Join the Discord" button is suppressed when Discord OAuth isn't configured server-side (`discord.configured` false).
