# ADR 0130 — provision.js remote-exec over SSH: the control plane orchestrates co-tenant workloads on the co-hosting box

**Status:** Accepted — code implemented 2026-07-05 (task [#2065](https://example.com/builders#/task/2065)); **activation (SSH trust + token rotation) is a sequenced owner-op**, see §Activation. Follows [ADR 0126](<redacted>.md).

> **Superseded in part by [ADR 0132](<redacted>.md)** (task 2071). The remote-exec *mechanism* here stands, but activation found the co-hosting box runs **five** token-consuming runners (not one), each reading its queue from a **localhost-only** Postgres. So the migration also needs an SSH DB tunnel + control-plane variants of all five runners, and the runner unit named below (`provision-intent-runner-cloudbongos.*`) is replaced by `cohost-provision-intent-runner.*`. **Follow ADR 0132's §Activation, not the §Config + runner move step here.**

## Context

[ADR 0126](<redacted>.md) moved cloudbongos.com onto its own dedicated droplet that is also the **sole token-holding control plane** (`/etc/cloudbongos/box.env` holds the account-wide DigitalOcean + Cloudflare tokens). But it left the **co-hosting box** (`REDACTED_IP`) still holding its own DO token + a narrow Cloudflare token, used by two control-plane duties that still run *there*:

- `box.js` — dev-box lifecycle (create/destroy droplets, DNS).
- `provision.js` + `provision-intent-runner` — instance provisioning for co-tenant instances (`emersonian-circles.`, `staging.`) that **run on the co-hosting box**.

Reaching the owner's goal — **zero cloud tokens on the co-hosting box** — means moving both duties onto the control plane. The obstacle ADR 0126 named: **`provision.js` does its box-mutating steps LOCALLY** (`createdb`, `migrate`, write `/etc/<slug>/…`, `systemctl`, Caddy, healthz). If it runs on the control plane, those steps would hit the *control-plane* box — but the co-tenant instances live on the *co-hosting* box. So the runner needs a way to execute those steps **on the co-hosting box, remotely.**

## Decision

Add a **remote-exec-over-SSH path** to `provision.js` (`scripts/gds/provision.js`), gated behind `PROVISION_REMOTE_HOST` and **OFF by default** (unset ⇒ every step runs locally, byte-identical to today).

### The executor split

`provision.js` already runs every runbook step through two injected factories (`makeExec` / `makeWriteFile`). The change threads a **target** through them:

- **`exec` / `writeFile` — box-target.** When `PROVISION_REMOTE_HOST` is set, box-mutating steps run on that host over `ssh` (else local). `makeExec` composes `cd <remoteCwd> && <env> <cmd>` and feeds it to `ssh <host> bash -s` via **stdin** — so nothing needs shell-quoting on the way over (the classic remote-exec footgun). `makeWriteFile` base64-encodes the body and decodes it into place with `sudo tee` on the box (no raw secret on a command line).
- **`controlExec` / `controlWriteFile` — always local (the control plane).** Two steps must NOT cross to the co-hosting box because they need the cloud token / the packaging toolchain that live only on the control plane:
  - the **Cloudflare DNS hook** (`BOX_DNS_HOOK`) — the whole point is that the co-hosting box has no token;
  - the **standalone repo scaffold** (`git clone` / `package-core` / `bongos init` / `git push`).

`sudo` (from `PROVISION_SUDO`, [ADR 0128](<redacted>.md)) composes cleanly: for a remote step the `sudo` runs on the co-hosting box (as its passwordless-sudo user). Co-tenant A records point at `PROVISION_PUBLIC_IP` = the **co-hosting box's** IP (where the co-tenant actually runs), which is the "point `PROVISION_PUBLIC_IP` appropriately" clause of the task.

### `box.js` needs no code change

`box.js` is entirely **API-driven** (DigitalOcean + Cloudflare clients + the DNS hook) — it does no local box-mutating ops. So the dev-box lifecycle "moves to the control plane" simply by *running there* (it reads the tokens from `/etc/cloudbongos/box.env`) + relocating the `box-intent-runner` timer — a box-side op, no code.

### Why remote-exec (SSH) over the alternatives

- **vs. running the runner as-is on the co-hosting box** — that is the status quo, and it *requires* the tokens to stay there. Rejected: it's exactly what we're removing.
- **vs. a small agent/API on the co-hosting box the control plane calls** — more moving parts, a new listening surface + its own auth. SSH is already the trust primitive for these boxes (the 2063 migration itself was SSH-driven); reuse it.
- **vs. making every co-tenant a dedicated droplet** (no remote-exec needed) — real money per instance + a migration of the existing co-tenants; out of scope.

## The trust boundary this creates (the owner's call)

This gives the **control-plane box SSH command authority over the co-hosting box** (a key from the control plane in the co-hosting box's `authorized_keys`). The arrow points **control-plane → co-hosting**, never the reverse — the token-holding box commands the token-free box, not vice-versa, so a compromise of the co-hosting box still cannot reach the tokens. This is the deliberate posture; the SSH trust is installed as an explicit operator step (below), not by any auto-deploy.

## Activation (sequenced owner-op — do NOT reorder)

The code is inert until activated. Because both a remove-tokens step and a runner-move are involved, order matters (tracked in the blocker attached to task 2065):

1. **SSH trust** — put the control-plane box's key in the co-hosting box's `authorized_keys` (control-plane → co-hosting). Verify `ssh lars@REDACTED_IP true` from the control plane.
2. **Config + runner move** — install `infra/provision-intent-runner-cloudbongos.{service,timer}` on the control plane (carries `PROVISION_REMOTE_HOST` / `PROVISION_REMOTE_CHECKOUT` / `PROVISION_PUBLIC_IP`), `enable --now` the control-plane timer, and **disable the generic `provision-intent-runner.timer` on the co-hosting box in the same window** (never both — they'd double-drain). Run `box.js` (dev-box duties) from the control plane too.
3. **Verify** — provision/reconcile a co-tenant end-to-end from the control plane (its steps land on the co-hosting box; DNS lands from the control plane).
4. **Remove + rotate the tokens** — only once (1)–(3) are proven: delete `DO_API_TOKEN` + `CLOUDFLARE_API_TOKEN` from `/etc/example/box.env` and **rotate** them (DigitalOcean + Cloudflare consoles) so the old values are dead even if they leaked. **Irreversible / console-only — the owner does this.**
5. **Drop the rollback DB** — after a bake period, drop the retained `cloudbongos` DB on the co-hosting box (ADR 0126 rollback net).

## Consequences

- The co-hosting box can reach zero cloud tokens once activated; the control plane orchestrates the co-tenants it hosts over SSH.
- Default-OFF means this lands safely on `main` and changes nothing until the owner runs the activation — the co-hosting runner keeps working meanwhile.
- New trust edge (control-plane → co-hosting SSH), accepted as above.
- ~~Not addressed here (future): a co-tenant that should run *on the control plane* while `PROVISION_REMOTE_HOST` is set — today the flag is global (all co-tenant provisions go to the remote host). Fine for the current fleet (co-tenants live on the co-hosting box); revisit if a control-plane-local co-tenant is ever wanted.~~ **Resolved (task [#2074](https://example.com/builders#/task/2074)).** A **standalone** instance (`hosting_shape='standalone'`, its own repo dir — ADR 0108) IS the control-plane-local case: `scaffoldStandaloneRepo` already builds its repo dir on the control plane, so the follow-up box steps (code sync, migrate, `/etc`, systemd, Caddy, healthz) must run **there too**, not cross to the co-hosting box that never had that dir. `provision.js` now picks the executor **per hosting shape**, not by the global flag: standalone → the control-plane executors (`controlExec`/`controlWriteFile`); co-tenant + dedicated unchanged. A standalone's DNS A record targets `PROVISION_CONTROL_PLANE_IP` (this box), not `PROVISION_PUBLIC_IP` (the co-hosting box); a greenfield `demo.cloudbongos.com` was the driving case (goal 35 criterion 165). The per-instance override is shape-derived, so no new global flag was needed.
- **TLS companion to the above (task [#2077](https://example.com/builders#/task/2077)).** Because a standalone now runs control-plane-local under the control plane's `*.cloudbongos.com` **wildcard Cloudflare Origin cert**, Caddy already has a matching cert and never fires on-demand ACME — so the co-tenant posture (DNS `proxied=false` + on-demand Let's Encrypt, which needs the challenge to reach the origin) would serve that origin cert to *direct* clients: publicly **untrusted**, and it exposes the control-plane IP. So `provision.js` sets the standalone A record **`proxied=true`** (via a new `BOX_PROXIED` flag on `infra/box-dns-cloudflare.sh`, default off): the Cloudflare edge fronts it with a public cert (origin cert valid behind Full-strict) and the origin IP stays hidden. Co-tenant + dedicated stay `proxied=false` (their on-demand ACME is load-bearing). Same shape-derived split as the executor/IP decision above. Known follow-up: a standalone on a **custom** domain (no wildcard origin cert) would still want `proxied=false` + on-demand ACME — no such instance exists today (idea 528).
