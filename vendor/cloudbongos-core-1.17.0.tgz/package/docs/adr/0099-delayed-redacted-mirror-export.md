# ADR 0099 — The time-delayed, redacted public-mirror export pipeline (R72)

- **Status:** Accepted — **retirement trigger fired 2026-07-03, deferred to the public-flip.** ADR 0103 §4 / R88 ([#1727](https://example.com/builders#/task/1727)) physically extracted the core into [github.com/example-owner/cloud-bongos](https://github.com/example-owner/cloud-bongos), the designated canonical public artifact. That repo is **private for now**, so this generated mirror **remains the public surface** and is **not retired**; retire (or repoint) it when `cloud-bongos` is flipped public.
- **Date:** 2026-06-30
- **Track:** internal
- **Task:** [#1211](https://example.com/builders#/task/1211) (V4.R72) — the delayed export pipeline + source-level redaction. The XL long-pole of GDS-V4 criterion **C9** (Cloud Bongos is open, free, and protected from capture).
- **Builds on:** [ADR 0098](<redacted>.md) (the publishable-subtree manifest this pipeline *consumes*), [ADR 0065](<redacted>.md) §4 (the publish boundary + the "redact instance literals" mandate), [ADR 0022](0022-secrets-policy.md) (the secret scrubber this reuses), [ADR 0029](<redacted>.md) / [#741](https://example.com/builders#/task/741) (the scoped-deploy-key mirror-push precedent).
- **Gates:** [#1212](https://example.com/builders#/task/1212) (R73 — the lineage + no-leak proof) reuses this pipeline's `findLeaks` + `.mirror-provenance.json`.

## Context

ADR 0098 made the publish boundary executable (`scripts/gds/publish-manifest.js`, `isPublishable()`) but drew it at the **subtree** level and explicitly deferred to R72 the *file-level* work: publish a **~6-month-lagged snapshot** and **redact instance literals from inside published files**. The delay alone is not a security control — a droplet IP or domain committed seven months ago is exactly as sensitive today (§0098-6). Redaction is mandatory; the delay only shrinks the value of anything that ever slips.

The redaction surface is real, not theoretical: at build time **23** published files named the droplet IPv4, **1** named its IPv6, **~230** named the instance domain, **~50** named the owner login. Subtree exclusion cannot catch literals *inside* files the platform legitimately publishes (e.g. `docs/architecture.md`).

## Decision

`scripts/public-mirror-export.js` (orchestration) + `scripts/gds/mirror-redact.js` (redaction library) + `.github/workflows/sync-public-mirror.yml` (schedule/transport). Seven decisions carry the weight:

### 1. Snapshot, not history replay
Each run picks the **newest commit whose committer date is ≥ 180 days old** (`pickSnapshotCommit`) and exports that single tree. The mirror accumulates one lagged snapshot commit per run — always ~6 months behind. Rejected replaying/redacting full history: far more code + risk (rewrite every commit) for no gain the "done-when" asks for. Matches the status-mirror precedent (sync current state as commits).

### 2. The manifest is the only allow-list
The exporter enumerates the snapshot tree (`git ls-tree -r`) and partitions it through `isPublishable()` (ADR 0098) — **no second list**. A file dropping out of the publishable set (or out of the lagged tree) disappears from the mirror on the next run.

### 3. Two-layer redaction; the scrubber is reused, not re-typed
Instance-literal redaction (`redactText`: domain+subdomains → `example.com`, repo/db/world/company token → `example`, owner login+aliases → `example-owner`, public IPv4 **and** IPv6 → `REDACTED_IP`; localhost/RFC-1918/RFC-5737/link-local/ULA kept) **then** the ADR-0022 secret scrubber as a backstop. To reuse the proven scrubber without importing the heavyweight `ship.js`, its pure functions were extracted to `modules/security/secret-scrub.js` (`ship.js` re-exports them; `tests/scrubber_corpus.mjs` unchanged). One copy of the secret shapes, two consumers — the "imported, never re-typed" doctrine.

### 4. Self-leak invariant
`mirror-redact.js` is itself published (under `scripts/`), so it contains **no instance literal**. Every literal is derived at runtime from `config/branding.json` (excluded from the mirror) plus caller-supplied extras. A vanilla clone redacts *its own* instance's literals with the same code. `tests/mirror_redact.mjs` reads branding at test time and asserts the redactor source contains none of this instance's literals.

### 5. The no-leak gate is STRICTER than, and decoupled from, redaction
`findLeaks` scans for each raw sensitive literal as a **case-insensitive substring** + the IPv4/IPv6 floors — it does **not** reuse the redaction regexes. This was learned the hard way: a first cut shared a word-bounded owner rule (`\bexample-owner\b`) for both redact and detect; it silently missed `example-owner` inside a regex-literal string (`(\bexample-owner\b)` in `audit-authorship.sh`) *and the detector was blind to the miss because it used the same pattern.* Redaction may be smart (avoid over-mangling); the gate must be dumb and strict (any raw literal anywhere = fail). Owner redaction is therefore **unbounded substring** (a login is unique enough), which also covers `/Users/<login>` home paths.

### 6. Fail-closed, atomic
All files are redacted **in memory**; `findLeaks` + `findSecretLeak` run over every redacted blob; **only if the entire set is clean** does the exporter touch the mirror filesystem (clear → write → commit → push). Any residual → publish nothing, exit non-zero, name the file+label (never the secret value), mirror untouched. Binary files are kept verbatim but still leak-scanned — a secret in a binary fails closed rather than corrupting it. An empty publishable set aborts (never wipes the mirror).

### 7. Topology/owner extras live only in excluded files
The exact droplet IP (`DROPLET_IP`) and owner aliases beyond the GitHub login (`OWNER_ALIASES`, e.g. the real-name/home-dir username) are sourced from env set in the **workflow yaml — which `.github/` excludes from the mirror** — so they never appear in a published file. The generic public-IP floors already catch the droplet IP without knowing it; the exact value is belt-and-suspenders so the gate can assert *that* value is gone.

Transport reuses the ADR-0029/[#741](https://example.com/builders#/task/741) pattern: check out `cloudbongos/bongos` via a write-scoped deploy key (`PUBLIC_MIRROR_DEPLOY_KEY`), run the exporter with `--push`. Scheduled weekly + `workflow_dispatch`. `.mirror-provenance.json` (source SHA + committed-at + lag) is the lineage anchor R73 asserts against.

## Consequences

- **Dormant-until-mature = a safety property.** This repo's history is < 180 days old, so the pipeline is a **no-op** ("nothing to publish yet") until ~2026-11. That keeps the mirror empty until R73's independent no-leak proof lands and the owner flips the mirror public (ADR 0098 §7) — three layers of safety: the gate must pass to push at all; the repo stays private meanwhile; R73 must pass before the public flip.
- **R73 is cheap to build.** It reuses `findLeaks` (assert no leak on the pushed tree) and `.mirror-provenance.json` (assert `source_commit` is an ancestor of private `main`; diff the mirror's `migrations/` numbering + enum values against that commit in the private repo).
- **Owner setup is required before the first real publish** — the `PUBLIC_MIRROR_DEPLOY_KEY` secret (and optional `DROPLET_IP`). Tracked as a blocker; not urgent (dormant until history matures).
- **Redaction over-redacts conservatively** (recall-first for topology): a coined instance token or a public IP that appears in generic prose is redacted. Acceptable — the mirror is meant to read as the neutral platform.

## Alternatives considered (rejected)

- **Delay-only, no redaction.** Fails the "does NOT scrub secrets" reality; a 7-month-old droplet IP still pins prod. Rejected.
- **Share one regex set for redact + detect.** The blind-spot bug above: the gate can't catch what its own bounded rule missed. Rejected — the detector is a separate, stricter substring scan.
- **TruffleHog as the only secret check.** Strong but network-dependent and verify-only (no transform); can't run in the exporter's own deterministic self-check or the unit tests. Kept the reusable in-process scrubber as the authoritative gate; TruffleHog may layer on later.
- **Write then scan the mirror on disk.** A failed run would leave a dirty (unpushed) tree and risk a partial state. In-memory-then-write makes abort atomic. Rejected.
