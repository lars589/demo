// Shared robust JSON extraction for the grader (#79 / #380, completed in #493).
//
// A leaf module (requires nothing) so BOTH grader.js (the v2/validateAndScore
// path) AND every worker module (the v4 panel path) can delegate to ONE
// implementation without the worker→grader.js circular dependency that
// runWorker's injected-fn pattern exists to avoid.
//
// The naive "fenced block, else first-'{' to last-'}'" that every worker copied
// turned any output with trailing prose or stray braces into a spurious
// parse_error — the exact flake #465 then had to retry. This tries, in order:
//   1. parse the whole trimmed string,
//   2. a ```json fenced block,
//   3. a string/escape-aware BALANCED-BRACE scan returning the first
//      grade-shaped {...} object (preferring real SCORE keys so an incidental
//      {"verdict":"…"} in prose can't win).
// Falls back to null only when nothing parses.

// Score keys that mark a parsed object as the real grade (vs an incidental
// prose object). Module-level so extractJson doesn't re-allocate per call.
const GRADE_SHAPE_KEYS = ['functional_fidelity', 'code_quality', 'security_score', 'efficiency_score'];

function extractJson(raw) {
  if (typeof raw !== 'string') return null;

  const tryParse = (s) => { try { return JSON.parse(s); } catch { return null; } };
  const isObj = (o) => o && typeof o === 'object' && !Array.isArray(o);

  // 1. Whole string (clean JSON-only response — the happy path).
  const whole = tryParse(raw.trim());
  if (isObj(whole)) return whole;

  // 2. A fenced ```json block, if present.
  const fenced = /```(?:json)?\s*\n?([\s\S]*?)```/.exec(raw);
  if (fenced) {
    const f = tryParse(fenced[1].trim());
    if (isObj(f)) return f;
  }

  // 3. Balanced-brace scan: from each top-level '{', walk to its matching '}'
  // while skipping string literals (and escapes), and parse each complete span.
  // The outer loop skips over '{' that sit inside a string literal so we don't
  // launch doomed scans from mid-string (addresses the #493 nit).
  const candidates = [];
  let outerInStr = false, outerEsc = false;
  for (let i = 0; i < raw.length; i++) {
    const c = raw[i];
    if (outerInStr) {
      if (outerEsc) outerEsc = false;
      else if (c === '\\') outerEsc = true;
      else if (c === '"') outerInStr = false;
      continue;
    }
    if (c === '"') { outerInStr = true; continue; }
    if (c !== '{') continue;
    let depth = 0, inStr = false, esc = false;
    for (let j = i; j < raw.length; j++) {
      const ch = raw[j];
      if (inStr) {
        if (esc) esc = false;
        else if (ch === '\\') esc = true;
        else if (ch === '"') inStr = false;
      } else if (ch === '"') inStr = true;
      else if (ch === '{') depth++;
      else if (ch === '}') {
        depth--;
        if (depth === 0) {
          const obj = tryParse(raw.slice(i, j + 1));
          if (isObj(obj)) candidates.push(obj);
          break;
        }
      }
    }
  }
  if (candidates.length === 0) return null;
  // Prefer a candidate carrying a real SCORE key; else the first balanced object.
  const graded = candidates.find((o) => GRADE_SHAPE_KEYS.some((k) => k in o));
  return graded || candidates[0];
}

module.exports = { extractJson, GRADE_SHAPE_KEYS };
