# Builder Flows — what's blocked, what isn't

How a person works once the code is in modules. **Nothing you do is blocked — only where a task's code lands is bounded.**

## The one idea: two kinds of "access"

- **Platform capabilities** — claim, start, ship, file an idea, recall, see your box. These are **kernel endpoints over HTTP, gated only by your rank.** The module structure never touches them. Available everywhere, always.
- **Code-write scope** — which files a *single claimed task* may change. The **only** thing the structure bounds; it lives at the **worktree** level (not you, not your box); escaped by seeding a new task (itself a kernel capability).

**The wall is around each task's worktree — not around you, and not around your dev box.**

## 1. What the dev box has access to

The dev box is your machine — a persistent environment, **not** module-scoped. Scoping happens one level down, per claim.

| Layer | Scope | Governed by |
|---|---|---|
| Dev box (your environment) | full repo, all modules readable, whole CLI, the API, the preview | nothing — it's yours |
| Kernel capabilities (claim/ship/capture/…) | everything the platform can do | **your rank** (server-enforced) — never a module |
| A claim's worktree | write = its one module; read = that module + the kernel doorway | the task's **module label** + the ship-time diff check |

## 2. Flow: open a dev box → ship a task

```mermaid
graph LR
    A["Open dev box<br/>(box)"] --> B["/builder-start<br/>lists ALL modules<br/>(kernel)"]
    B --> C["/builder-claim N<br/>a game task<br/>(kernel)"]
    C --> D["worktree spun:<br/>modules/game + RO kernel<br/>(module-scoped)"]
    D --> E["agent edits game only<br/>(module-scoped)"]
    E --> F["/builder-ship<br/>smoke · diff⊆module · grade · merge · deploy<br/>(kernel)"]
    F --> G["live ✓<br/>worktree reaped"]
```

Five of seven steps are kernel/box capabilities; only the worktree + the edits are module-scoped. The only *new* thing is a silent check inside `/builder-ship` (diff ⊆ declared module) that in-scope work never notices.

## 3. Flow: claim a task in a different module

You're never "in" a module — each *claim* is. A second claim just makes a second scoped worktree; because the two tasks are in different modules they're **parallel-safe by construction** (no overlap check needed).

## 4. Flow: see an idea — and seed a cross-module task

Browsing ideas, filing an idea, and **seeding a task for another module** are all kernel operations — they need no access to the other module's code, so they work from anywhere. An agent in a game worktree can't *write* dev-box code, but it can always *file the task* for it (one command), then continue or hand off; a dependency link orders them if needed.

## 5. "Could this block me?" — every worry

| Worry | Why it isn't a block |
|---|---|
| Claim a task in a module I'm not "in"? | You're never "in" a module. Claiming is kernel; each claim makes its own scoped worktree. |
| Does my box only have one module's code? | No — the box has the full repo. Only each per-claim worktree is scoped. |
| Agent needs another module mid-task — stuck? | No — it seeds a task for it (kernel op, needs no access to that code); a dep orders them. |
| Filing an idea about module X needs X access? | No — capture/inbox is kernel; file from anywhere. |
| Is shipping gated by my module? | No — ship is kernel; the only module check is "diff ⊆ module," which passes for normal work. |
| Need to change the kernel/doorway? | Seed a kernel/core task (rank-gated as today); ship it first; the module task depends on it. |

## 6. Long autonomous sessions stay mobile

A Claude Code session is **not** welded to one worktree. The session is a **conductor**; each claimed task runs in its own module-scoped worktree:

```mermaid
graph TD
    S["long autonomous SESSION = <redacted> repo · full mobility · no module binding"]
    S --> A["task A (game) → worktree A → its own PR → ship"]
    S --> B["task B (dev-box) → worktree B → its own PR → ship"]
    S --> C["task C (memory) → worktree C → its own PR → ship"]
```

- **Parallel** (`--parallel N`): the conductor fans out worker subagents, each `isolation: "worktree"`, each on a different module → they can't collide (different modules).
- **Sequential**: the conductor `EnterWorktree`s a fresh worktree per task, ships, `ExitWorktree`s, moves on.

The session has full mobility across modules; only each *task's worker* is module-isolated. This is the orchestrator-worker pattern (ADR 0024), and the GDS already assigns a per-claim worktree.

## 7. Limiting what the box holds — the jailbreak blast radius

The split lets the box hold **far less**: only the claimed module (read/write) + the kernel's **safe contract** (signatures, read-only) + client plumbing + a scoped token. The kernel **implementation** (auth, rank, ship, grade) never leaves the server.

```mermaid
graph LR
    subgraph Box["DEV BOX · one claim (= jailbreak blast radius)"]
        M["modules/&lt;key&gt;/ — read/write"]
        KC["kernel CONTRACT — signatures + docs only (RO)"]
        CLI["CLI plumbing (cli-lib)"]
        TOK["scoped, claim-scoped token (not full-repo)"]
    end
    subgraph Server["SERVER · the trusted side"]
        KI["KERNEL IMPL — auth · rank · ship · grade<br/>(never on the box)"]
        OM[every other module's source]
        FR[full repo + history]
        EN["ENFORCES the rank ladder, live per request (ADR 0016)"]
    end
    Box -->|"privileged ops = HTTP call<br/>(box can't push main)"| Server
```

**The trap to avoid:** reducing what's *on disk* is not reducing *access* — a box holding a full-repo credential re-fetches. The real lever is **scoping the box's credential + fetch to the claimed module** (and module access can be **rank-gated** too, since the server mediates every fetch). The primary boundary always remains the **server-enforced rank ladder**; on-disk minimization is defense-in-depth on top.

| Approach | Efficiency | Real confidentiality boundary? |
|---|---|---|
| Sparse-checkout only | ✓ smaller tree | ✗ — `.git` still has everything |
| Partial clone + sparse | ✓✓ | ~ — box can lazily re-fetch with its token |
| **Server-mediated, claim-scoped fetch** | ✓✓ | **✓ — box never holds a full-repo remote or kernel source** |
| Per-module repos | ✓✓ | ✓✓ strongest — but contradicts single-repo (ADR 0080 rejected package-modules for v1) |

## 8. Two boundaries that compose (no new friction)

Modules sit **beside** the rank trust boundary, not replacing it: **rank** = *what* you may do (server-enforced, live); **module** = *where* this task's code lands (ship-time diff check + worktree scope). Neither adds a step to the builder's day — you still run `/builder-start`, `/builder-claim`, `/builder-ship` exactly as now. The structure is invisible in the happy path; the wall only shows itself when a task tries to wander, and then the answer isn't "blocked," it's "that's a second task."
