-- Bongos App — V1 planning seed (2026-06-20)
-- Owner-directed (archon). Idempotent on re-run.
--
-- Creates a NEW version line: BONGOS-V1 — the inaugural version of the "bongos"
-- platform line. Strategic intent (owner): bongos is the successor to the GDS;
-- the GDS deprecates after GDS-V4 and its infra/build-out migrates into bongos.
-- What V1 SHIPS is the Cloud Bongos desktop "Feedback Capture" tool: a Zoom-style
-- floating toolbar that captures narrated voice + ~1/sec snapshots and freehand
-- markup over ANY on-screen target, synthesizes them into one cheap, model-agnostic
-- prompt, and hands it to Claude Desktop + Claude Code. The existing Dev Box
-- desktop app (ADR 0045) is absorbed as a module of the bongos app (reusing its
-- Apple cert + distribution pipeline). Visual element-select is deferred to V2.
--
-- What this migration does:
--   1. INSERT the BONGOS-V1 versions row (track=internal, status=planning).
--   2. Seed 4 done_when_criteria (C1..C4) at sort_order 1..4.
-- Net-new tasks (R01..R17) are created AFTER this is applied via
-- scripts/gds/seed-bongos-app-tasks.js, so the positional C1..C4 refs resolve.
-- (Same split as migration 110 + seed-medusa-tasks.js.)

BEGIN;

-- ============================================================================
-- 1. Create the BONGOS-V1 version row.
-- ============================================================================
INSERT INTO versions (id, name, track, status, scope_doc_path, done_when, started_at)
VALUES (
  'BONGOS-V1',
  'Bongos App — V1',
  'internal',
  'planning',
  'limitations/bongos-v1.md',
  'Bongos App V1 ships the Cloud Bongos desktop feedback tool: a Zoom-style floating toolbar that captures narrated voice + ~1/sec snapshots and freehand markup over any on-screen target, synthesizes them into one cheap, model-agnostic prompt, and hands it to Claude Desktop and Claude Code. The Dev Box desktop app is absorbed as a module of the bongos app. This is the inaugural version of the bongos line, the successor the GDS migrates into after GDS-V4. Visual element-select is deferred to V2.',
  now()
)
ON CONFLICT (id) DO NOTHING;

-- ============================================================================
-- 2. Seed the 4 done_when_criteria (C1..C4). UPSERT on (version_id, criterion_id).
--    sort_order 1..4 -> positional refs C1..C4 for the seed script.
-- ============================================================================
INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, sort_order)
SELECT * FROM (VALUES
  ('BONGOS-V1', 'signed-installable',
   '**Signed, installable, and permission-guided on Mac + Windows.** A code-signed, notarized macOS build and a signed Windows build install from a branded download and launch as a floating menu-bar/tray app, reusing the existing Dev Box app distribution + Apple Developer ID; the Dev Box switch is absorbed as a module of the bongos app rather than shipping as a separate install. Done when: the bongos app is one Electron app that contains the prior Dev Box functionality as a module; a signed+notarized Mac build and a signed Windows build install from the branded /downloads redirect and auto-update; a first-run permission wizard detects + deep-links Screen Recording and Microphone grants with live grant-state; and an unsigned dev-build path exists for local iteration.',
   1),
  ('BONGOS-V1', 'captures-anywhere',
   '**Captures narrated feedback over any on-screen target.** The floating toolbar overlays any window (the Zoom annotation model) and records the microphone plus time-aligned ~1/sec snapshots of the chosen target, with freehand/box/arrow/text markup and a freeze-frame, on macOS and Windows. Done when: a transparent, always-on-top, click-through overlay draws over arbitrary other apps (surviving macOS fullscreen/Spaces and Windows multi-monitor DPI); a global hotkey summons/dismisses the bar; Record captures mic + the chosen window/screen at ~1/sec with snapshot-on-change + perceptual dedup + a frame cap; and Markup draws and freezes over any pixels.',
   2),
  ('BONGOS-V1', 'cheap-complete-synthesis',
   '**Synthesizes one cheap, complete, model-agnostic prompt.** The capture is fused into a single LLM-ready bundle at a disciplined token envelope — frames dominate cost, so audio is transcribed on-device to text and frames are deduped + salience-escalated rather than sent 1/sec at full resolution. Done when: on-device transcription (whisper.cpp) yields word-timestamped text; transcript and frames are time-aligned and only transcript/markup-flagged frames escalate to full resolution; a deterministic prompt.md is assembled with inlined absolute image paths; and a typical multi-minute session lands at the disciplined envelope (~5-11k tokens), not the ~70k+ naive cost.',
   3),
  ('BONGOS-V1', 'lands-in-claude',
   '**Lands in Claude — Desktop and Code — reliably and model-agnostically.** The synthesized bundle reaches both Claude surfaces without a fragile step, under a documented contract that works for any agent. Done when: a file-bundle handoff (prompt.md + image files) plus clipboard text works for Claude Desktop; a /feedback path injects the prompt and loads the image paths in Claude Code; an optional local stdio MCP server exposes the latest bundle for a hands-free pull; and an ADR + README document the architecture and the model-agnostic prompt/handoff contract.',
   4)
) AS v(version_id, criterion_id, criterion_md, sort_order)
WHERE EXISTS (SELECT 1 FROM versions WHERE id = 'BONGOS-V1')
ON CONFLICT (version_id, criterion_id) DO UPDATE
  SET criterion_md = EXCLUDED.criterion_md,
      sort_order   = EXCLUDED.sort_order;

-- ============================================================================
-- 3. Self-register so migrate.sh skips this file on the next deploy (it is
--    hot-applied via psql under this planning seed).
-- ============================================================================
INSERT INTO schema_migrations (version) VALUES ('120_bongos_v1_planning_seed')
ON CONFLICT DO NOTHING;

COMMIT;
