# Self-hosting Cloud Bongos (Docker)

Bring up a vanilla Cloud Bongos instance — the build platform + builders' hall + status dashboard, with no game — on any machine with Docker. Shipped by V4.R63 ([task #1202](https://example.com/builders#/task/1202), [ADR 0062](../adr/<redacted>.md)).

> **Relation to configurable-root ([ADR 0108](../adr/<redacted>.md)):** this is the **single-checkout** self-host shape — the whole repo (core + config) is baked into one image, so `resolveCoreRoot()` and `resolveInstanceRoot()` ([`src/instance-config.js`](../../src/instance-config.js)) both resolve to `/app` inside the container. ADR 0108 does not deprecate this path — it stays the cheap, supported shape for a quick reskin (this is how `cloudbongos.com` runs). The *installed-as-a-dependency* shape (a consumer repo running `npm install @bongos/core`) is the separate, heavier path ADR 0108 targets for a project that wants its own repo and its own upgrade cadence — see [`docs/recipes/packaging-the-core.md`](packaging-the-core.md).

## One command

```bash
docker compose up
```

That builds the image, starts Postgres, applies the build-system migrations (game-module migrations are skipped — this is a GDS-only instance), and serves the builders' hall at **http://localhost:3000**.

- The instance is **vanilla** by default: the neutral Cloud Bongos brand, every feature module (game, art pipeline, Discord, dev boxes) **off**. `.dockerignore` keeps the host's `config/branding.json` and `config/modules.json` out of the image, so it resolves to `config/branding.neutral.json` + `config/modules.neutral.json`.
- **No OTB scope-truth is seeded.** OTB/product data (game versions, goals, done-when criteria) lives in opt-in seed migrations under `migrations/instance/` (plus a few guarded blocks in the mixed files 003/006). `scripts/migrate.sh` skips them unless `GDS_APPLY_INSTANCE_SEEDS=1`, so a fresh DB comes up with only the schema and platform-universal defaults (ranks, achievements) — no crash, no foreign-key failures, no leftover versions. Platform system principals (`bfg-system`, `discord-bot-system`) are generic and remain. See task 1704 / [ADR 0105](../adr/<redacted>.md).
- **No prod topology** is referenced: the database is a local container, the credentials are local demo values, and the app reaches Postgres over TCP via `PG*` env (see `docker-compose.yml`).

To stop and wipe: `docker compose down -v` (the `-v` drops the `cloudbongos-db` volume).

## Branding / configuring your instance

The image is intentionally vanilla. To make it yours, supply your own config at runtime by mounting it over the build:

```yaml
# docker-compose.override.yml
services:
  app:
    volumes:
      - ./config/branding.json:/app/config/branding.json:ro
      - ./config/modules.json:/app/config/modules.json:ro
```

Author `config/branding.json` from the neutral starter — see [the branding contract](../branding-contract.md) and [`docs/branding-fill-prompt.md`](../branding-fill-prompt.md). Choose which features to enable in `config/modules.json` — see [the module contract](../modules-contract.md). Both resolve **over** the neutral starters, so you only specify what differs.

**Or scaffold it with `bongos init`** ([task #1204](https://example.com/builders#/task/1204)): a short interview (or `bongos init --from spec.json` for a hands-free / CI run) that writes both config files, **seeds your first version + its done-when goal**, and **files the human-only kickoff steps** (register a GitHub OAuth app, first owner sign-in, repo binding, admission) as real tracked tasks — so a fresh instance has a claimable queue on day one instead of an empty hall. It never invents your branding (it points you at the fill prompt for that). Preview the whole plan with `bongos init --dry-run`.

**Production hosting, optional (the `provisioning` module — [ADR 0111](../adr/<redacted>.md) §3).** If you enable the `provisioning` module and answer the interview's hosting questions (shape — co-tenant `$0` or a dedicated droplet — bring-your-own domain, credential ref, tier), init turns those answers into a real **provisioning request** (a queued `provision` intent the control-plane runner drains) instead of only filing a manual "production topology" task. The two irreducibly-human legs — the GitHub OAuth app and the first owner sign-in — stay guided/manual. If the module isn't enabled on the target instance, init falls back to the manual production-topology task, so nothing is silently skipped.

## Configuration surface

| Env var | Meaning | Compose default |
|---|---|---|
| `PGHOST` / `PGPORT` / `PGUSER` / `PGPASSWORD` / `PGDATABASE` | Postgres connection (read by both the app pool and the migration runner) | the local `db` service |
| `HOST` / `PORT` | bind address inside the container | `0.0.0.0` / `3000` |
| `MEDUSA_GDS_ONLY` | `1` = hard force-skip the OTB **instance-seed** migrations (`migrations/instance/`) — belt-and-suspenders over the default. A vanilla instance never wants OTB's versions/goals/criteria (task 1704 / [ADR 0105](../adr/<redacted>.md)). | `1` |
| `GDS_APPLY_INSTANCE_SEEDS` | `1` = opt IN to applying the bundled OTB instance-seed migrations. Default (unset) = **skip** — so a self-host never inherits OTB scope-truth. Only the owning instance sets this, and only when rebuilding its DB from scratch (DR). | unset |
| `CLOUDBONGOS_PUBLIC_ORIGIN` | public origin for OAuth callbacks etc. | `http://localhost:3000` |

(The env prefix is the instance's `envPrefix` from its branding pack — `CLOUDBONGOS` for vanilla.)

## What the image contains

- `node src/platform-server.js` — the GDS-only entrypoint (no Colyseus, no game rooms, no game assets).
- `postgresql-client` (for `scripts/migrate.sh`) + `tini` as PID 1.
- Runs as the unprivileged `node` user; a `HEALTHCHECK` polls `/healthz`.

## Production notes

For a real deployment, put a TLS-terminating reverse proxy (Caddy/Cloudflare/nginx) in front, point `CLOUDBONGOS_PUBLIC_ORIGIN` (and the builders/status origins) at your domain, and use managed or backed-up Postgres rather than the bundled container volume. The bundled `db` service is for a self-contained local instance, not a production database.
