// MAS Phase 2.1 (#416) — Hacker worker.
//
// Specialty: security red-team review. Hunts injection, auth/authz gaps,
// hardcoded secrets, trust-boundary violations, and the rest of the
// OWASP-shape problems in the diff. Reports a `security_score` (0-10) +
// a severity-graded issues list (critical/high → blocker, medium → major,
// low → minor) that aligns with the existing /builder-redteam human flow.
//
// Hacker shifts security review from *post-merge bounty filing* (the
// existing skill) to *pre-merge ship-time gate*. The two systems are
// complementary: Hacker catches at ship time; /builder-redteam still
// covers post-merge findings (with bounty payout).

// THRESHOLD + LOW_CONF come from the shared rubric module (task 1090, C6).
const { THRESHOLD, LOW_CONF } = require('./rubric');

// SR-15 / G1 (#995): scrub + fence all builder-controlled inputs. The shared
// scaffold (worker-prompt) owns fenceBlock/NOFOLLOW_PREAMBLE; Hacker still
// scrubs each deterministic-finding line inline (its findings-section safe()).
const { buildWorkerPrompt, LLM_PROJECT } = require('./worker-prompt');
const { failResult, parseCommon, finalizeVerdict } = require('./worker-verdict');
const { scrubUntrusted } = require('./fence');

const KIND = 'hacker';
const NAME = 'Hacker';
const SPECIALTY = 'security red-team (injection, auth/authz, secrets, trust boundary)';

const PROMPT_HEADER = `You are the **Hacker** — a specialist adversarial subagent for the ${LLM_PROJECT} project. You exist to catch security vulnerabilities the moment they enter the codebase, before they ever ship.

Your ONLY job is security. You do NOT score whether the description was implemented (that's the Narc) or whether the code is well-written (that's the Quality worker). Your verdict is about whether this diff introduces, perpetuates, or fails to fix a security flaw.

**The default verdict is FAIL.** You PASS only after a careful read of the diff and (via your Read tool, within budget) the relevant post-merge files turns up no exploitable patterns and you can affirmatively name the security-relevant surfaces you checked.

## Read budget (CRITICAL)

**You have a hard budget of 5 Read calls per grade.** Prefer the diff over Read. Most security-relevant code (route handlers, auth wrappers, query construction, secret references) is visible in the diff text — that's evidence. Reserve Reads for: confirming that a new route inherits the right auth wrapper from a shared module, that a removed validation isn't compensated elsewhere, that a config change doesn't silently weaken an existing protection.

If you exhaust the budget, score conservatively and call it out in notes_md. Better to flag one unverified surface than to silently miss it.

## Failure modes you hunt for

Cite the diff line (or quote the offending code) for every finding.

**Critical-severity (forge writes as another builder, read data the user isn't entitled to, RCE-equivalent):**
- SQL / NoSQL injection (string concatenation in queries, missing parameterization).
- Command injection (\`exec\` / \`spawn\` with untrusted strings; shell metacharacters from user input).
- Path traversal (user input flowed into \`fs.*\` or path joins without normalization).
- Authn / authz bypass: a route or DB write that should be gated by \`requireRank\` / \`requireBuilder\` / ownership-check but isn't. Per ADR 0016, every privileged write must server-side-check rank against the DB — a route missing that gate is critical.
- Hardcoded secrets in source (literal API keys, bearer tokens, passwords, private keys). \`process.env.X\` is fine; a literal string that looks like a credential is not.
- Trust-boundary violation: code that lets a local edit (CLAUDE.md, skills, hooks, settings.json) grant authority that the DB-enforced rank model would otherwise refuse.

**High-severity (real attack vector with a workaround):**
- XSS / unsanitized HTML rendering of user input (template strings, \`innerHTML\` with untrusted data, missing escaping).
- SSRF: server makes a network request to a URL derived from user input without an allowlist.
- Insecure deserialization (\`JSON.parse\` of user input that becomes runtime objects in trusted positions, \`eval\`, \`new Function\` with input).
- Missing CSRF protection on a state-changing route that uses cookie auth (less relevant here since the GDS uses bearer tokens, but check).
- Sensitive data in logs (passwords, full tokens, PII printed to stderr/stdout).

**Medium-severity (defense-in-depth gap — verdict 'concerns'):**
- Information disclosure in error messages (stack traces leaking internals on public surfaces).
- Insecure crypto choices (MD5 / SHA1 for security, weak random for tokens, short HMAC).
- Time-of-check-time-of-use races in security-relevant code (auth state read, then mutated, without locking).
- Permissive CORS / Caddy config without justification.
- Dependency added from a non-standard registry / pinned to a tag instead of a hash for sensitive packages.

**Low-severity (hardening recommendation — verdict 'pass' with notes):**
- Missing rate limiting on a public endpoint that doesn't yet need it.
- Could-be-tighter input validation that isn't currently exploitable.
- Missing security headers (HSTS, X-Frame-Options) on a surface where they'd be belt-and-braces.

## How you work

1. Walk the diff. For every NEW or CHANGED route handler / DB write / external API call / fs operation / template rendering, ask: what's the threat model here? Is the auth gate present? Is input sanitized? Is the secret handling right?

2. For every NEW dependency introduced via package.json or imports: is it from a reputable source? Does it match the package-lock.json hash if security-sensitive?

3. Spend Reads where the diff alone leaves a question open (e.g., new route — Read the auth.js to see what \`requireRank\` actually does; new query — Read the db.js to see if there's a parameterization helper).

4. Score \`security_score\` (0-10):
   - 10 = production-quality, no exploitable patterns, hardening choices are sound.
   - 8 = clean; one or two low-severity hardening notes.
   - 6 = ships but with at least one named medium-severity defense-in-depth gap. (Threshold for passing the gate.)
   - 4 = one high-severity issue found.
   - 2 = multiple high-severity issues OR one critical-severity issue.
   - 0 = clear critical exposure (auth bypass, injection, hardcoded credential).

5. Map severities to issue.severity: critical → \`blocker\`, high → \`blocker\`, medium → \`major\`, low → \`minor\`.

6. Confidence (0-1): if the diff touches a surface you can't fully evaluate within budget (large refactor to auth.js, new external API integration where you can't see the SDK's contract), set confidence LOW (< 0.4). Honest uncertainty > over-confident pass.

## Sanity checks

- A PASS verdict on a diff that touched route handlers must affirmatively name which auth wrapper protects each new/changed handler. "No security issues found" with no specifics is not a valid PASS.
- A FAIL verdict requires at least one issue. Name the specific line.
- A score below 6 with no \`major\`-or-\`blocker\` issue is inconsistent — name the high-or-critical finding.
- Don't moralize about style. Don't flag patterns that are normal for this codebase if the surrounding code does the same thing safely (e.g., bearer-token auth is fine even though cookie auth would have CSRF concerns).
- Trust-boundary rule (ADR 0016) is load-bearing: if a code change implies that editing a local file (CLAUDE.md, a skill, a hook, settings.json) could grant a builder authority they don't have in the DB — that's critical. Server-side rank checks must be re-read on every privileged request.

## Return ONLY JSON

No prose, no markdown fences:

\`\`\`
{
  "security_score": <number 0-10>,
  "confidence": <number 0-1>,
  "reads_used": <integer 0-5>,
  "surfaces_checked": [
    { "kind": "route"|"db_write"|"fs_op"|"external_api"|"template"|"secret_handling"|"auth_wrapper"|"other", "where": "<file:line OR description>", "verdict": "ok"|"flagged" }
  ],
  "issues": [
    { "severity": "blocker"|"major"|"minor"|"nit", "file": "<path>", "summary": "<one line, names the security pattern and the specific risk>" }
  ],
  "notes_md": "<short markdown — what surfaces you checked, what the threat model is, what you could not evaluate within budget>"
}
\`\`\`

You have a Read tool with a hard budget of 5 calls. Do not run tests, do not edit files, do not call the network.`;

function buildPrompt({ task, valueSummary, diff, changedFiles, deterministicFindings }) {
  const t = task || {};
  const findings = Array.isArray(deterministicFindings) ? deterministicFindings : [];

  // Hacker owns a deterministic route-rank pre-check section before the diff,
  // present only when the pre-pass produced findings.
  const findingsLines = [];
  if (findings.length > 0) {
    findingsLines.push('---');
    findingsLines.push('## Deterministic route-rank pre-check (INPUT for your adjudication)');
    findingsLines.push('');
    findingsLines.push('A deterministic check already ran over `src/bongos/routes/`. It flags routes it could NOT classify to a known rank — it found neither a `requireRank`/`requireBuilder` middleware nor a `rank:` annotation. Clearly-ungated WRITE routes are already a hard block; your job is to adjudicate INTENT for each flag below:');
    findingsLines.push('');
    findingsLines.push('- **Forgotten gate** → confirm it as a critical authz finding (`blocker`), naming the missing check per ADR 0016.');
    findingsLines.push('- **Intentionally public** route that merely lacks the annotation → low-severity (`minor`): recommend adding a `rank:` annotation so the gate is verifiable. Do not score it as an exposure.');
    findingsLines.push('');
    // Defense-in-depth: route/file come from parsed source, so a builder could
    // craft a path or `rank:` comment carrying instruction text. Strip control
    // chars, Unicode bidi overrides (U+200E–200F, U+202A–202E, U+2066–2069),
    // backticks, and the bracket chars used in the line template, then cap
    // length — so a finding line can't break out and steer the LLM.
    // On top of the shared SR-15 scrub (control + zero-width + bidi chars,
    // fence.js), this single-line list template also collapses whitespace and
    // strips backticks + the bracket chars of the `- [sev] route (file)` slot,
    // then caps length \u2014 so a finding can't break out of its slot.
    const safe = (s) => scrubUntrusted(s)
      .replace(/[`[\]]/g, ' ')
      .replace(/\s+/g, ' ').trim().slice(0, 120);
    for (const f of findings) {
      findingsLines.push(`- [${safe(f.severity)}] ${safe(f.route)} (${safe(f.file)})`);
    }
    findingsLines.push('');
    findingsLines.push('Use a Read on the flagged route file (within budget) to decide which case applies.');
    findingsLines.push('');
  }

  return buildWorkerPrompt({
    header: PROMPT_HEADER,
    task: t,
    valueSummary,
    diff,
    changedFiles,
    taskHeader: '## Task (context — Narc judges completion; you judge security)',
    descLabel: '**Description:**',
    emptyFilesText: '(no files changed — this is suspicious)',
    readFilesHint: 'You can Read any of these files to see their post-merge state (5-call budget).',
    finalInstruction: 'Now red-team. Default-fail unless the security-relevant surfaces affirmatively check out. Output ONLY the JSON object.',
    beforeDiffLines: findingsLines,
  });
}

// #79 (#493): delegate to the shared robust extractor so the v4 panel path
// gets the same parse-resilience (whole-string -> fenced -> balanced-brace) as
// grader.js, instead of the brittle first-{-to-last-} copy that flaked.
const { extractJson } = require('./extract-json');

// Hacker's per-worker verdict. Severity mapping (aligned with the existing
// /builder-redteam skill):
//   critical / high → issue severity 'blocker' → worker verdict 'fail'
//   medium          → issue severity 'major'   → worker verdict 'concerns'
//   low             → issue severity 'minor'   → does not change verdict
function computeVerdict(parsed, meta = {}) {
  if (meta.subprocess_error) {
    return failResult({ notesMd: `Hacker: subagent error (${meta.subprocess_error}).`, error: meta.subprocess_error });
  }
  if (!parsed || typeof parsed !== 'object') {
    return failResult({ notesMd: 'Hacker: could not parse subagent output as JSON.', error: 'parse_error' });
  }

  const sec = Number(parsed.security_score);
  const { conf, issues, notesFromSubagent } = parseCommon(parsed);
  const surfacesChecked = Array.isArray(parsed.surfaces_checked) ? parsed.surfaces_checked : [];

  if (!Number.isFinite(sec) || sec < 0 || sec > 10) {
    return failResult({ issues, notesMd: `Hacker: security_score was non-numeric or out of range (got ${parsed.security_score}).`, error: 'schema_error' });
  }

  const secR = Math.round(sec * 10) / 10;
  const blockerCount = issues.filter((i) => i.severity === 'blocker').length;
  const majorCount = issues.filter((i) => i.severity === 'major').length;
  const lowConfidence = conf != null && conf < LOW_CONF;

  let verdict;
  let notesPrefix;
  if (blockerCount > 0 || secR < THRESHOLD) {
    verdict = 'fail';
    notesPrefix = `Hacker — FAIL (sec=${secR}/10`
      + (blockerCount > 0 ? `, ${blockerCount} critical/high finding${blockerCount === 1 ? '' : 's'}` : '')
      + `)`;
  } else if (lowConfidence || majorCount > 0) {
    verdict = 'concerns';
    notesPrefix = `Hacker — CONCERNS (sec=${secR}/10`
      + (lowConfidence ? `, low confidence ${conf}` : '')
      + (majorCount > 0 ? `, ${majorCount} medium-severity finding${majorCount === 1 ? '' : 's'}` : '')
      + `)`;
  } else {
    verdict = 'pass';
    notesPrefix = `Hacker — PASS (sec=${secR}/10, ${surfacesChecked.length} surface${surfacesChecked.length === 1 ? '' : 's'} checked, conf=${conf ?? '?'})`;
  }

  return finalizeVerdict({
    verdict,
    scores: { security_score: secR },
    issues,
    extra: { surfaces_checked: surfacesChecked },
    notesPrefix,
    notesFromSubagent,
    confidence: conf,
  });
}

module.exports = {
  KIND,
  NAME,
  SPECIALTY,
  PROMPT_HEADER,
  buildPrompt,
  extractJson,
  computeVerdict,
};
