// public-builders/ranks.js — the ranks page (/builders/ranks).
//
// Read-only. Fetches /api/bongos/me to learn the viewer's rank, then renders the
// rank ladder with the "reveal only as far as the next rank" rule: the current
// rank and the one directly above it show their full unlocks; higher ranks
// keep their unlock details hidden until the builder is one rank below them
// (named, but details withheld). On a 401 it redirects into the web sign-in
// flow, exactly like the hall index — the page personalises to the viewer, so
// it needs a session.
//
// The rank model is the four live ranks of ADR 0018 + ADR 0034:
// xenos < thetes < metic < archon. RANK_UNLOCKS is mirrored from builders.js /
// docs/canonical-permissions.md.

(() => {
  'use strict';

  const API = '/api/bongos';
  // Generated typed client (task 1996 / R09), served as window.BongosClient by
  // /lib/bongos-client.js. baseUrl:'' passes the full `${API}/...` URLs below
  // through unchanged; result-mode ({ status, ok, data }) preserves control flow 1:1.
  const api = window.BongosClient.createClient({ baseUrl: '', credentials: 'same-origin', throwOnError: false });

  // escapeHtml / $ / rankLabel / toast now come from the shared window.OTB
  // toolkit (dom-utils.js, loaded first). Thin wrappers keep this file's exact
  // variants ('—' rankLabel empty; a 2600ms clearing toast). badge() +
  // RANK_UNLOCKS + RANK_LADDER stay local below.
  const { escapeHtml, $ } = window.OTB;
  const rankLabel = (rank) => window.OTB.rankLabel(rank);
  const toast = (msg) => window.OTB.toast(msg, { duration: 2600, clear: true });
  const curLabel = (caps) => { const l = (window.__BRANDING__ && window.__BRANDING__.currency && window.__BRANDING__.currency.label) || 'credits'; return caps ? l.charAt(0).toUpperCase() + l.slice(1) : l; };

  // Lowest → highest. Index is the rung number.
  const RANK_LADDER = ['xenos', 'thetes', 'metic', 'archon'];

  // Plain title + one-line character for each rank.
  const RANK_TITLE = {
    xenos: 'The newcomer',
    thetes: 'The proven builder',
    metic: 'The trusted builder',
    archon: 'The steward',
  };
  const RANK_BLURB = {
    xenos: 'A newcomer with a deliberately small surface: onboarding, safe starter tasks, and your own standing.',
    thetes: 'A builder who has shipped their first work — the day-to-day surfaces are open.',
    metic: 'A trusted builder: triage, reviews, planning sessions, and security reporting are open.',
    archon: 'The steward of the whole system — approvals, the roster, budgets, and the Archon pages.',
  };

  // What each rank unlocks. Mirror of builders.js RANK_UNLOCKS — sourced from
  // docs/canonical-permissions.md. Keep the two in sync.
  const RANK_UNLOCKS = {
    xenos: [
      'Read every public page.',
      'Claim and ship tasks an Archon has flagged newcomer-friendly.',
      `Earn ${curLabel()} for shipped work and karma for ratified ideas.`,
    ],
    thetes: [
      'Claim and ship any task in the general queue — no longer only newcomer-friendly work.',
      `Keep earning ${curLabel()} and karma for every clean ship.`,
      'No triage, blockers, planning, or task-shaping yet — those levers open at Metic.',
    ],
    metic: [
      'Claim and ship any task in the ready queue.',
      'Triage the idea inbox; resolve blockers; run planning sessions.',
      'Propose new version criteria for Archon ratification.',
    ],
    archon: [
      'Create, promote, and edit tasks; reshape the dependency graph.',
      'Grant or revoke ranks; close versions; confirm ships past the grader.',
      'Adjudicate vulnerability reports and override requests.',
    ],
  };

  // How a builder rises FROM their current rank. Keyed by current rank; the
  // value describes the climb to the next rung. Archon is the top — no climb.
  // NB: these strings INTENTIONALLY contain markup (<strong>) and are injected
  // via innerHTML below without escaping. That is safe only because they are
  // author-controlled constants. Never source RISE_FROM from server/user data
  // without switching the render site to escapeHtml — it would become XSS.
  const RISE_FROM = {
    xenos:
      `Claim and ship the newcomer-friendly tasks an Archon has opened to newcomers. Each clean ship earns ${curLabel()}; each ratified idea earns karma. On your <strong>third</strong> clean ship you are promoted automatically to <strong>Thetes</strong> — out of the newcomer sandbox, with the whole queue open to you. No fee, no application; the third ship does it.`,
    thetes:
      'You have the run of the queue. Promotion to <strong>Metic</strong> — triage, blockers, planning, the shaping of work — is granted by a standing Archon alone, to a builder whose judgment has earned the project’s trust. Keep shipping; rank is granted, never bought.',
    metic:
      'The <strong>Archon</strong> rank is granted rarely, by a standing Archon alone, to a Metic who has shaped the project’s direction and earned its deepest trust. There is no checklist — only the weight of what you have built.',
    archon:
      'You hold the highest rank. There is no rank above it — only the care of everything below.',
  };

  function badge(rank) {
    const variant = RANK_LADDER.includes(rank) ? `rank-badge--${rank}` : 'rank-badge--unknown';
    return `<span class="rank-badge ${variant}">${escapeHtml(rankLabel(rank))}</span>`;
  }

  function unlockList(rank) {
    const items = (RANK_UNLOCKS[rank] || []).map((u) => `<li>${escapeHtml(u)}</li>`).join('');
    return `<ul class="rank-card__list">${items}</ul>`;
  }

  // Render one revealed rank. `state` is 'attained' | 'current' | 'next'.
  function revealedCard(rank, state) {
    const statusText = {
      attained: 'Attained',
      current: 'You are here',
      next: 'Next rank',
    }[state];
    return `
      <li class="rank-card rank-card--${state}">
        <div class="rank-card__head">
          ${badge(rank)}
          <span class="rank-card__status rank-card__status--${state}">${statusText}</span>
        </div>
        <p class="rank-card__title">${escapeHtml(RANK_TITLE[rank] || rankLabel(rank))}</p>
        <p class="rank-card__blurb">${escapeHtml(RANK_BLURB[rank] || '')}</p>
        <p class="rank-card__unlocks-label">What it unlocks</p>
        ${unlockList(rank)}
      </li>`;
  }

  // Render one hidden rank — named, but its details withheld until the builder
  // is one rank below it. (Per Lars: show the name, keep the unlocks a mystery.)
  function sealedCard(rank) {
    return `
      <li class="rank-card rank-card--sealed">
        <div class="rank-card__head">
          ${badge(rank)}
          <span class="rank-card__status rank-card__status--sealed">Hidden</span>
        </div>
        <p class="rank-card__title">${escapeHtml(RANK_TITLE[rank] || rankLabel(rank))}</p>
        <p class="rank-card__blurb rank-card__blurb--sealed">A higher rank. Its details are hidden until you reach the rank directly below it.</p>
      </li>`;
  }

  function render(builder) {
    const rank = (builder && RANK_LADDER.includes(builder.rank)) ? builder.rank : 'xenos';
    const curIdx = RANK_LADDER.indexOf(rank);
    const nextIdx = curIdx < RANK_LADDER.length - 1 ? curIdx + 1 : -1;
    // Reveal everything up to and including the next rung; seal what's above.
    const revealUpTo = Math.max(curIdx, nextIdx);

    // ---- header sub-line ----
    const sub = $('#ranks-sub');
    if (sub) {
      const name = escapeHtml(builder.display_name || builder.github_login || 'builder');
      sub.innerHTML = `${name}, your rank is ${badge(rank)} — ${escapeHtml(RANK_TITLE[rank] || '')}.`;
    }

    // ---- "where you stand" summary ----
    const standing = $('#standing-body');
    if (standing) {
      const nextLine = nextIdx >= 0
        ? `The rank above yours is ${badge(RANK_LADDER[nextIdx])}. See below what it grants.`
        : 'You hold the highest rank.';
      standing.innerHTML = `
        <div class="ranks-standing__badge">${badge(rank)}</div>
        <div class="ranks-standing__text">
          <p class="ranks-standing__title">${escapeHtml(RANK_TITLE[rank] || rankLabel(rank))}</p>
          <p class="ranks-standing__blurb">${escapeHtml(RANK_BLURB[rank] || '')}</p>
          <p class="ranks-standing__next">${nextLine}</p>
        </div>`;
    }

    // ---- the ladder ----
    const ladder = $('#ladder-body');
    if (ladder) {
      ladder.innerHTML = RANK_LADDER.map((r, i) => {
        if (i > revealUpTo) return sealedCard(r);
        if (i === curIdx) return revealedCard(r, 'current');
        if (i === nextIdx) return revealedCard(r, 'next');
        return revealedCard(r, 'attained');
      }).join('');
    }

    // ---- how you advance ----
    const rise = $('#rise-body');
    if (rise) {
      rise.innerHTML = `<p class="ranks-rise__body">${RISE_FROM[rank] || RISE_FROM.xenos}</p>`;
    }
  }

  async function load() {
    let payload;
    try {
      const res = await api.request('GET', `${API}/me`);
      if (res.status === 401) {
        window.location.assign(`${API}/auth/web/start`);
        return;
      }
      if (!res.ok) throw new Error(`me → ${res.status}`);
      payload = res.data;
    } catch (err) {
      console.error('[ranks] failed to load standing', err);
      const sub = $('#ranks-sub');
      if (sub) sub.textContent = 'Could not load your rank. Return to the hall and try again.';
      toast('Could not load the ranks.');
      return;
    }
    // /me may return the builder under `.builder` or at the top level.
    const builder = (payload && payload.builder) ? payload.builder : payload;
    render(builder || {});
  }

  load();
})();
