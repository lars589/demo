# ADR 0062 — Medusa: decoupling the GDS into an instance-model build platform

- **Status:** Accepted
- **Date:** 2026-06-18
- **Track:** internal
- **Builds on:** [ADR 0010](0010-pms-architecture.md) (the GDS architecture being extracted), [ADR 0016](<redacted>.md) (the trust boundary — *core*, survives the split untouched), [ADR 0061](<redacted>.md) (the context-layer charter + nested docs — this ADR makes that the *portable methodology core*), [ADR 0004](0004-example-name-and-trademark-acceptance.md) (the civ-name "single config string" rule — generalized here into the branding contract), [ADR 0024](<redacted>.md) (the grader/architect/onboarding prompts that carry brand and must be parameterized)
- **Task:** [#1189](https://example.com/builders#/task/1189) (V4.R50) — the spike that **locks the boundary before the R51–R74 structural epics build**. Satisfies the design half of criteria **C8** (decouple the GDS into an instance model — "the GDS builds itself") and frames **C9** (AGPL open-source track).
- **Amended by:** [ADR 0108](<redacted>.md) — resolves §10's build-sequence assumption that instance content sits at the repo root into the configurable-root composition mechanism (a consumer installs the core as a dependency and injects an instance-root).

> **⚠ Renamed (2026-06-19):** the platform this ADR calls **Medusa** was renamed **Cloud Bongos** by owner directive. This record is kept verbatim as history; the rename decision (and what it touches vs. leaves as history) is [ADR 0064](<redacted>.md). Forward-facing config + docs now read "Cloud Bongos."

## Context

The goal (GDS-V4 Medusa cluster, planning tasks [#1188](https://example.com/builders#/task/1188)/[#1215](https://example.com/builders#/task/1215)): extract the GDS — the build/methodology platform — into **Medusa**, a configurable, self-hostable, AGPL, AI-first build platform. A host project supplies a **branding pack** and selects **feature-modules** (game, art-pipeline, discord, dev-box) that are *off by default*. **Customer 0** = Medusa on a plain vanilla brand, no modules — it builds itself (the C8 proof, [#1206](https://example.com/builders#/task/1206)). **Customer 1** = Example (OTB).

Today it is one fused codebase. A file-grounded coupling analysis (2026-06-18) found four seams:

1. **Process/HTTP** — one Express app + one Colyseus server. The GDS (`/api/gds`, hall, status) mounts host-agnostic *first*; the **game is the fall-through default**, not a module. Good news: `src/rooms/register.js` + `src/preview-server.js` already factor the game-room set out — the cleanest existing seam and the template for the cut.
2. **DB** — *one shared `pg` Pool*: `src/bongos/db.js` does `require('../db')` and reuses the game's pool. Game tables (`world_events`, `players`, migrations 001/002) and ~78 GDS tables share one pool and one flat migration sequence. `track` is a 2-value `CHECK (track IN ('product','internal'))` column on `versions`, woven into analytics + hall UI — an OTB-specific taxonomy.
3. **Brand/identity** — leaked, not single-config. "Example" is hardcoded across ~50 hits / 28 files; `example.com` across ~90 (cookie domain `.example.com`, OAuth origin, `*.dev.` SSH allowlist); "drachmae" in 23 files; "Off the Boats"/"Example" baked into **grader/architect/onboarding LLM prompts**. Only `devbox-app/src/brand.js` honors the single-config ideal.
4. **Methodology/skills** — already clean: `.claude/skills/builder-*` + idea/blocker/planning/status/recall are portable; the four `otb-*` art skills + `stop-sound.js` are host; `art/` is self-contained (no `src/` imports); Discord is already `DISCORD_BOT_ENABLED`-gated.

Why a spike-ADR first: 24 structural tasks (R51–R74) depend on this. They need **one** locked boundary, branding-contract schema, and module mechanism to build against, or they will diverge.

## Decision

### 1. The boundary (the cut-line)

**The engine is host-agnostic and mounts modules; a host is a branding pack + a set of enabled modules.** Invert today's "game is the default fall-through" → the game is a module the OTB instance enables.

| Component | Portable core (Medusa) | Host instance (OTB) | Feature-module (gated) |
|---|---|---|---|
| `src/bongos/*` (routes, auth, grader, BFG, onboarding, recall) | ✅ core (prompts templatized) | — | — |
| `src/bongos/db.js` Pool | ✅ owns its own Pool | — | — |
| `src/db.js`, `players`/`world_events`, migrations 001/002 | — | ✅ | `game` |
| `src/rooms/`, `register.js`, `preview-server.js`, `public/` | — | ✅ | `game` (already factored) |
| `public-builders/` hall + `public-status/` | ✅ *engine* | copy/theme/lore | branding pack supplies strings |
| `art/` + `otb-*` skills + tile scripts | — | ✅ | `art-pipeline` (self-contained) |
| `discord-*.js`, `scripts/discord/`, `channels.json` | ✅ *engine* | channel layout + persona | `discord` (already flag-gated) |
| `box*.js`, `cf-tunnel.js`, `devbox-app/`, box skills | ✅ *engine* | `*.dev.` domains | `dev-box` |
| `.claude/skills/builder-*`, idea/blocker/planning, hooks | ✅ core | `stop-sound.js`, `otb-*` | — |
| `versions.track` + by_track analytics/UI | — | the 2-value taxonomy | configurable track set |
| domains/origins/cookie-domain | reads from config | hardcoded ×90 today | — |

### 2. The instance model

- **Engine entrypoint** (R51, [#1190](https://example.com/builders#/task/1190)): boots Express + `buildGdsRouter()` + hall + status, host-agnostic, **no Colyseus, no game/tile mounts** — sibling to `src/preview-server.js`. Today's `server.js` becomes the *OTB instance boot* (engine + game module).
- **A host instance** = branding pack (§3) + feature-module flags (§4) + owner/repo/OAuth binding (R62, [#1201](https://example.com/builders#/task/1201)) + its own DB (R52).
- Customer 0 = vanilla brand, no modules (the dogfood); customer 1 = OTB (game + art + discord + dev-box, drachmae, Greek pack).

### 3. The branding contract (`config/branding.*` — R53 keystone, [#1192](https://example.com/builders#/task/1192))

One per-instance config; **resolution precedence: env var → instance config → neutral starter** (fail to the plain default, never to OTB). A documented schema + neutral starter + an owner-LLM "fill-it-in" prompt. Fields the codebase proves are needed (each hardcoded today):

- **Identity:** `productName`, `worldName` (the in-world / civilization name), `company` (+ site).
- **Domains:** `publicOrigin`, `buildersOrigin`, `statusOrigin`, `cookieDomain`, box subdomain pattern (`*.dev.`/`sandbox-`/`term-`). *(Load-bearing security strings — a swap must not widen cookie/SSH scope.)*
- **Currency label** (R56, [#1195](https://example.com/builders#/task/1195)): "drachmae" → configurable; the cost-plus reward **math is unchanged**.
- **Tracks:** replace the 2-value `product|internal` CHECK with a configurable set (R52, [#1191](https://example.com/builders#/task/1191)).
- **Theme/palette + copy pack:** hall lore/primer/404 copy, Discord persona, and — critically — the **grader/architect/onboarding prompt brand header** must read the project name from config, or a non-OTB instance grades against the wrong project identity.

Customer 1 (OTB) pack = R57 ([#1196](https://example.com/builders#/task/1196)); vanilla = R74 ([#1216](https://example.com/builders#/task/1216)); the diagram generator reads it (R58, [#1197](https://example.com/builders#/task/1197)).

### 4. Feature-module selection (R54, [#1193](https://example.com/builders#/task/1193))

A **module registry**: each module declares what it contributes — route mounts, hall/status UI sections, skills, disciplines/achievements, DB migrations/tables, Colyseus rooms, pollers, hooks. An instance's config enables a set; resolution gates at mount time (`routes.js`/the entrypoint reads the enabled set). Modules: `game` + `art-pipeline` (R59, [#1198](https://example.com/builders#/task/1198)), `discord` + `dev-box` (R60, [#1199](https://example.com/builders#/task/1199)). The hall's only realtime feature (a Colyseus room) gets a non-Colyseus fallback over the pg-NOTIFY relay so a game-less instance keeps live updates (R55, [#1194](https://example.com/builders#/task/1194)).

### 5. DB carve-out (R52, [#1191](https://example.com/builders#/task/1191))

A GDS-owned Pool reading `DATABASE_URL`/`PG*` (not hard-defaulting to the `example` DB) — sever `src/bongos/db.js`'s `require('../db')`. A GDS-only migration sequence; game migrations 001/002 belong to the `game` module and are simply not applied on a non-game instance. Drop the hardcoded track taxonomy. **The trust boundary ([ADR 0016](<redacted>.md)) and per-request rank enforcement are core and unchanged.**

### 6. Config namespace (R61, [#1200](https://example.com/builders#/task/1200))

Consolidate `OTB_*`/`PMS_*` env prefixes + the `~/.config/otb/` path to a neutral product namespace driven by instance config, with back-compat shims (existing local sessions/boxes keep working). Owner bootstrap from instance config replaces migration 023's hardcoded `github_login='example-owner'` Archon literal (R62, [#1201](https://example.com/builders#/task/1201)).

### 7. Portable methodology core ↔ host context split (folds in [ADR 0061](<redacted>.md) + R66 [#1205](https://example.com/builders#/task/1205))

- **CLAUDE.md becomes the portable methodology core** Medusa ships: the working rules, session protocol, claim→ship lifecycle, the ADR 0061 **content charter**, and the **nested-`CLAUDE.md`** pattern. Instance-agnostic.
- **The host authors its own project-context file.** The OTB identity (company, vision, world, visual style — today's CLAUDE.md §§3/5/6/7) moves OUT of the shipped core into an instance-owned context doc + the branding pack. This is the concrete meaning of "move the project identity": **it is the core/host split, not tidying.**
- `medusa init` (R65, [#1204](https://example.com/builders#/task/1204)) scaffolds a new instance's context file from a neutral template + the owner-LLM fill prompt. The AI-first norm ("AI always writes the code") is documented in the core.

### 8. Session logs in the portable core (new task, folds in the redesign)

The §13 hand-maintained in-file index is an OTB-era artifact: it bloats the always-loaded file, drifts, and recurrently breaks (dangling-link bug recurs as idea 57, BFG F2, [#580](https://example.com/builders#/task/580)). Medusa's core ships a **generate-don't-narrate** model instead:

- The **DB session corpus is canonical** (already true — the BFG corpus + ADR 0051 full-transcript capture, [#1004](https://example.com/builders#/task/1004)).
- The context file carries at most an **auto-generated, bounded "recent sessions" snippet**, regenerated at deploy (the `gen-diagrams.js` pattern, branding-aware per R58); **full history renders in the hall + a generated index.** No instance hand-maintains a session-log index.

**Implemented — task [#1226](https://example.com/builders#/task/1226), 2026-06-19.** `scripts/gds/gen-session-index.js` generates `docs/session-log-index.md` (full history) + a bounded 10-entry snippet injected between markers into CLAUDE.md §13; it runs + commits at **ship** (`ship.js` `regenerateSessionIndex` — the realized form of "the gen-diagrams pattern") and is gated by `gen-session-index --check` in `fitness.js` (Check 5). §12 + the handoff-template drop the hand-maintained-index / manual-compaction chores; CLAUDE.md fell 342→300 lines and `ROOT_HARD_MAX` ratcheted 360→310. Two honest deltas from the wording above: **(a)** the index is generated from the canonical session **prose files** (`docs/session-logs/*.md`), not the DB — "DB corpus is canonical" presumes ADR 0051 transcript capture ([#1004](https://example.com/builders#/task/1004)), still Proposed/unshipped; generating from the files needs no unshipped dependency and makes a link **structurally undanglable** (retires idea 57 / [#580](https://example.com/builders#/task/580)). **(b)** A dedicated **hall** rendering of full narrative history is deferred until [#1004](https://example.com/builders#/task/1004) lands (the existing Archon session-ledger renders the `session_records` digests today); the generated index is the browseable full-history surface meanwhile.

### 9. A → B → C, folded into Medusa

The 2026-06-18 context-cliff research recommended three paths; each becomes a Medusa **core** capability:

- **A — context-layer decomposition** (ADR 0061, [#1222](https://example.com/builders#/task/1222)): the charter + nested per-module docs. This *is* the portable methodology core (§7). Done; carried into R66.
- **B — generated code/altitude map:** a tree-sitter symbol skeleton, regenerated in CI, feeding the *factual* half of the nested docs so they don't drift — keeping **every** instance's codebase navigable, complementing the recall layer ([ADR 0060](0060-gds-retrieval-layer.md)). (New core task.)
- **C — fitness functions in CI:** the **enforcement layer for this whole ADR.** A dependency-cruiser/ArchUnit-style gate that (i) prevents host/feature-module code from leaking into the portable core and vice versa — **mechanically enforcing the §1 cut-line and §4 module boundaries so the decoupling cannot silently rot back together** — and (ii) enforces the ADR 0061 CLAUDE.md budget + nested-doc presence, and (iii) asserts no module bypasses the §5 rank checks. Without C the boundary is a hope; with C it is a gate. (New core task — the single highest-leverage guarantee that Medusa *stays* decoupled.)

### 10. Build sequence

R50 (this ADR) → **R51 entrypoint + R52 DB pool** (independent foundations) → **R53 branding contract (keystone — most epics cross-ref it)** → **R54 module system** → parallelizable de-brand epics (R55–R62, R66 CLAUDE.md split, the new session-log + Path-B tasks) → **Path-C fitness functions** (wired as a dep of "decoupling done") → R63 docker / R64 upgrade / R65 init → **R67 C8 proof** (a second, non-game branded instance ships a task). C9 (R68–R73: AGPL ADR/LICENSE, governance, public mirror, delayed export, lineage proof) proceeds on its own track.

## Consequences

- A clear, file-grounded target the 24 epics build against — one boundary, one contract, one module mechanism.
- The trust boundary + rank enforcement stay core and unchanged; a feature-module must never be able to bypass server-side rank checks (a Path-C assertion).
- **Hardest knots (called out so the epics plan for them):** (1) shared Pool + flat migrations; (2) the brand-saturated, *not* data-driven hall UI (~50 brand hits, drachmae in 23 files) — the largest mechanical job; (3) inverting game-as-default into a mounted module; (4) domains woven into auth/security — config swaps must not widen cookie/SSH scope; (5) brand inside LLM prompts (grader/architect/onboarding).
- **Risk: scope.** Mitigation: R53 keystone first; modules incremental; Path-C enforces no regression; customer-0 dogfood ([#1206](https://example.com/builders#/task/1206)) is the falsifiable proof the cut actually worked.
