# Module Map & Slicing

Measured from the tree at `cc8a5e0` (~95k LOC). LOC are approximate — classified by file purpose, some files straddle domains.

## 1. Where the lines of code live

| Area | ≈ LOC | Home |
|---|---:|---|
| **KERNEL** — auth · rank · db-pool · loader · audit · trust primitives | ~3,500 | kernel |
| Hall UI (`modules/hall-ui/public`, was `public-builders`) | ~13,100 | module (hall-UI) — carved BV1.R85 |
| Ship / publish pipeline | ~5,500 | → lifecycle |
| Shared data layer (`db.js`) | ~5,300 | carved per-domain |
| Work lifecycle (tasks·claims·versions) | ~3,800 | → lifecycle |
| Grading (grader + worker panel) | ~3,100 | module (grading) |
| Status UI (`public-status`) | ~3,000 | module (status-UI) |
| Memory · recall · search · learnings | ~2,200 | module (memory) |
| Onboarding · admission · newcomer | ~1,900 | module (onboarding) |
| Builder profile · prefs | ~1,600 | module (builder-settings) |
| Economy (credits·cost·streak·achievements) | ~1,000 | module (economy) |
| Security · red-team | ~1,000 | module (security) |
| Inbox · ideas · blockers | ~900 | module (ideas) |
| Builder CLI (`/builder-*`) | ~12,000 | follows each domain (a command travels with its module as a `skill`) |
| Seed / generator / ops scripts | ~7,000 | seeds = disposable · generators = kernel/build or per-module |
| Art pipeline | ~13,000 | feature module |
| Dev-box (+2,900 Electron, separate) | ~5,400 | feature module |
| Game | ~3,900 | feature module |
| Discord | ~2,300 | feature module |

**The reframe:** the four feature modules are only ~26% of the code. The other ~70% is "core" — which is *not one thing*: ~8–10 cohesive domains on a small (~3.5k) trust kernel. The real decision is **how finely to cut the core.**

## 2. Validated against the import graph (not intuition)

Built the `require()` graph across all 111 files in `src/bongos`:

| What the graph shows | Reading |
|---|---|
| **In-degree cliff** — auth (35), db (28), pool (24), _helpers (23), then single digits | ✅ kernel is real + small |
| **Tight, outward-silent clusters** — discord→all `discord-*`; box→box-access/credential; grader→grader-workers | ✅ discord, dev-box, grading, memory, economy, security-feature slice cleanly |
| **`tasks → grader`, `tasks → github-push`, `tasks → ship-broadcast`** | ❌ work reaches into ship + grading → **one coupled cluster** (see §3) |
| **`permission-path-check` / `route-rank-check`** imported by grader, tasks, instance | cross-cutting → **kernel**, not a "security module" |
| **`me → boxes, streak, prefs, onboarding`**; **`public → grader, security`** | ⚠️ two cross-domain read-aggregators → thin **facades** |

```mermaid
graph LR
    subgraph guess["My first cut (by purpose)"]
        W[work]
        S[ship]
        Gr[grading]
    end
    subgraph real["What require() shows: ONE module"]
        T["tasks (work)"] --> GG[grade]
        T --> SH[ship]
        T --> CV["+ claims · versions · credits"]
    end
    guess ==>|scan| real
```

> **Important correction:** the import graph turned my three by-purpose modules (work / ship / grading) into **one coupled cluster** — because the seam mechanism (see [04](04-module-lifecycle.md)) later *un*-fuses grading & economy back out via the kernel, the **lifecycle module** ends up = the build *state machine*; grading & economy are modules it *orchestrates*.

## 3. How finely to cut the core — three configs

| Config | Boundaries | Pros | Cons |
|---|---|---|---|
| **A · Coarse** (~5 units) | kernel + one core block + game/art/discord/dev-box (= ADR 0080 as-written) | smallest, lowest-risk migration | 70% of code stays a blob — AI-scoping barely improves |
| **B · Medium** (~10–16 units) **[recommended]** | kernel + core cut into cohesive domains + feature modules; `db.js` carved per-domain | AI-scoping works for core work; lines from the measured graph; UIs first-class | more boundaries to enforce; carve the lifecycle carefully |
| **C · Fine** (~22+ units) | a module per route-group | smallest blast-radius; max parallelism | fights cohesion (tasks/claims/credits belong together); manifest sprawl; over-engineered |

**Recommendation: sequence A → B, stop before C.** Ship A (proves the loader), then peel the clean, scan-confirmed modules off one at a time (most self-contained first), carving `db.js` per-domain as you go. **Don't split the lifecycle state machine.**

## 4. The one warning: don't cut through the lifecycle

The GDS lifecycle — **claim → work → ship → grade → credit** — is the most coupled part, and the graph proves it (`tasks` imports `grader`, `github-push`, `ship-broadcast`). Keep the **state machine** (tasks/claims/versions) as one module; extract the *capabilities it invokes* (grade, reward) as separate modules behind kernel seams ([04](04-module-lifecycle.md)). Forcing the state machine apart with a strict "import the kernel only" rule would break the rule constantly or bloat the kernel.

## 5. Cross-cutting code (e.g. "security")

Two different things: **security-the-property** (authz, audit, rank ladder — `permission-path-check`/`route-rank-check`, imported everywhere) is **kernel**, enforced by composition + fitness functions, never "called"; **security-the-feature** (red-team reports, bounty, `/builder-redteam` — self-contained) is a **module**, optional + rank-gated, reached through its routes/skill/UI. Every cross-cutting concern (audit, logging, rate-limit) splits the same way.

## 6. The decided roster (~16 modules + kernel)

```mermaid
graph TD
    K["KERNEL: auth · rank · db-pool · loader · seam registry ·<br/>audit · live-channel · config/identity · analytics · trusted publish path"]
    LC[lifecycle] --> K
    EC[economy] --> K
    GR[grading] --> K
    ME[memory] --> K
    ON[onboarding] --> K
    ID[ideas] --> K
    BS[builder-settings] --> K
    SE[sessions/BFG] --> K
    AU[autonomy/MAS] --> K
    SC[security] --> K
    HU[hall-UI] --> K
    SU[status-UI] --> K
    GA[game] --> K
    AR[art-pipeline] --> K
    DC[discord] --> K
    DB[dev-box] --> K
```

| Module | Owns |
|---|---|
| lifecycle | the build state machine — tasks, claims, versions, done-when, ship orchestration |
| economy | the credit-allocation **model** + ledger + pricing + gamification (streak/achievements/leaderboard) |
| grading | grade-a-diff (adversarial panel), invoked via the seam |
| memory | memory · recall · search · learnings |
| onboarding | admission · setup · newcomer floor |
| ideas | inbox · capture · triage · blockers |
| builder-settings | prefs (wandering/skill/sound/render) · builder-needs (`me`/`public` = facades) |
| sessions/BFG | session records · cost/eval/digest · transcript corpus · BFG |
| autonomy/MAS | conductor dispatch · architect audits · autonomy-gate · scheduled routines |
| security | red-team reports · bounty (rank-gated Metic+) |
| hall-UI · status-UI | the two web surfaces |
| game · art-pipeline · discord · dev-box | feature modules |

> **~16 is the target ceiling, not a day-one requirement.** Start coarser; split as the coupling scan + fitness demand. Every one is a real cohesive cluster (the scan proved it), but a small team should be "as modular as the evidence supports, no finer." Merging two modules is cheap; the fitness ratchet makes splitting them safe — you're never locked into the first cut.
