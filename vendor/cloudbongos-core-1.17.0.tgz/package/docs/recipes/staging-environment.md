---
track: internal
scope: shared-infra (droplet, Caddy, Postgres, Cloudflare DNS + cert)
---

# Staging environment — provision and operate

> ⚠️ **Currently FROZEN as of 2026-05-29.** Staging was provisioned + verified end-to-end (see `https://staging.example.com` history in audit_log) and then immediately frozen pending real use. The systemd unit is **stopped + disabled** — incoming requests get a 502 from Caddy because the Node process isn't listening. All other scaffolding (DB, .env with OAuth creds, Caddy block, DNS record, cert SAN, separate GitHub OAuth app) is intact.
>
> **Revive with two commands**:
> ```bash
> ssh lars@REDACTED_IP "sudo systemctl enable example-staging && \
>                            sudo systemctl start example-staging"
> # Then verify:
> curl -sS https://staging.example.com/healthz   # → "ok"
> ```
> No re-provisioning needed unless you've rebuilt the droplet or wiped `/home/lars/example-staging`. The full first-time setup (DNS, cert, OAuth app, env file) is below for reference + for the next staging spin-up.
>
> **Why frozen instead of torn down?** Provisioning costs an hour the first time (DNS propagation, OAuth app, cert SAN check, debugging migration data gaps). A frozen environment is `~30MB RAM idle on the droplet` for free, vs. paying the setup cost again later. See the decision discussion at end-of-session 2026-05-29 — defer-not-delete was the call.

> The staging environment lives at `https://staging.example.com`. It runs on the SAME droplet as prod but as a separate Node process on port 3001, against a separate Postgres database (`example_staging`), with separate GitHub OAuth credentials, and pointing at a separate Discord channel for broadcasts.

V3.R39 ([#260](https://example.com/builders#/task/260)) shipped the scaffolding; this recipe is how to bring it live for the first time and how to operate it once it's up. Follow-up tasks V3.R40 ([#261](https://example.com/builders#/task/261)) and V3.R41 ([#262](https://example.com/builders#/task/262)) will land deploy automation and data seeding on top.

## First-time provisioning (Lars — one-time)

Four pre-conditions Lars must satisfy before the provisioning script can run end-to-end. Each is a manual step in a Cloudflare or GitHub UI; none can be automated from a laptop.

### 1. DNS A record

In Cloudflare → DNS → Records, add:

| Type | Name | Content | Proxy | TTL |
|---|---|---|---|---|
| A | `staging` | `REDACTED_IP` | ☑ Proxied (orange cloud) | Auto |

Verify from a laptop:

```bash
dig +short staging.example.com
# Should return a Cloudflare-edge IP (proxied), not REDACTED_IP directly.
```

### 2. Origin Cert SAN

Caddy is using `/etc/caddy/origin.crt` issued by Cloudflare's Origin CA. Confirm the cert covers `*.example.com`:

```bash
ssh lars@REDACTED_IP \
  "openssl x509 -in /etc/caddy/origin.crt -noout -text" \
  | awk '/Subject Alternative Name/{getline; print}'
```

If `*.example.com` is **not** in the output:

1. Cloudflare → SSL/TLS → Origin Server → Create Certificate.
2. Hostnames: `example.com, *.example.com` (cover apex + all subdomains).
3. Validity: 15 years (Cloudflare's max).
4. Save the certificate + private key.
5. On the droplet: replace `/etc/caddy/origin.crt` + `/etc/caddy/origin.key` (chmod 600 on the key).
6. `sudo systemctl reload caddy`.

### 3. Separate GitHub OAuth app

The prod OAuth app points its callback at `example.com/api/gds/auth/web/callback`. Staging needs its own:

1. github.com → Settings → Developer settings → OAuth Apps → New OAuth App.
2. Application name: `Off the Boats — staging`.
3. Homepage URL: `https://staging.example.com`.
4. Authorization callback URL: `https://staging.example.com/api/gds/auth/web/callback`.
5. Note the **Client ID** and **Client Secret** — they go into `/home/lars/example-staging/.env` (see step 4 of the provisioning script).

### 4. Separate Discord channel + webhook

Staging ships should NOT announce to the real team channel. Either:

- (recommended) Create a parallel Discord channel "Example Staging Builds." Add an incoming webhook on it + paste the URL into `.env` as `DISCORD_SHIP_NEWS_WEBHOOK` (see `scripts/discord/README.md`).
- (acceptable) Leave `DISCORD_SHIP_NEWS_WEBHOOK` blank in staging `.env` — the build broadcast will skip silently.

## Running the provisioning script

```bash
# scp the script to the droplet (or run it inline over ssh)
scp scripts/deploy/provision-staging.sh lars@REDACTED_IP:/tmp/
ssh lars@REDACTED_IP "bash /tmp/provision-staging.sh"

# OR — inline:
ssh lars@REDACTED_IP "bash -s" < scripts/deploy/provision-staging.sh
```

The script is **idempotent** — re-running it is the recovery path on partial failure. It walks 8 steps:

1. Verify DNS + cert SAN.
2. Create the staging Postgres DB if missing.
3. Clone the repo to `/home/lars/example-staging` (or git-pull if it already exists).
4. Drop a `.env` **template** with the staging-specific fields; **exit early** if the OAuth secrets are still blank, so Lars can fill them in and re-run.
5. Install + enable + start the systemd unit `example-staging.service`.
6. Apply pending migrations against the staging DB.
7. Verify localhost:3001/healthz.
8. Verify https://staging.example.com/healthz.

If any step fails, the script bails with a clear diagnostic. Fix the underlying issue, re-run.

## Day-to-day operation

### Restarting

```bash
ssh lars@REDACTED_IP "sudo systemctl restart example-staging"
```

The systemd unit will revive automatically on droplet reboot (it's `WantedBy=multi-user.target`).

### Logs

```bash
ssh lars@REDACTED_IP "sudo journalctl -u example-staging -f"
```

### Deploying to staging

**Automated (V3.R40 / [#261](https://example.com/builders#/task/261)) — the normal path.** Push to the `staging` branch and GitHub Actions deploys it:

```bash
# From any checkout — ship a feature branch (or main) to staging:
git push origin <your-branch>:staging --force
```

`.github/workflows/deploy-staging.yml` fires on the push: it scp's the latest `scripts/deploy/deploy-staging.sh` to `~/deploy-staging.sh` on the droplet, then runs it (reset to `origin/staging` → conditional `npm ci` → migrate `example_staging` → restart the service → smoke). A green run means `https://staging.example.com` reflects the push within ~2 minutes. Force-push is expected — `staging` is a disposable pointer at whatever release candidate you want to test, and the deploy script does a `git reset --hard origin/staging` to match.

> **One-time setup required before auto-deploy works — BOTH secrets (no insecure fallback):**
> 1. `STAGING_SSH_KEY` — a dedicated deploy keypair whose public half is in the droplet's `~/.ssh/authorized_keys`.
> 2. `DROPLET_KNOWN_HOSTS` — the droplet's SSH host key in `known_hosts` format, captured once from a trusted machine with `ssh-keyscan -t ed25519 REDACTED_IP`. The workflow connects with `StrictHostKeyChecking=yes` against this pin, so a MITM can't substitute its own host key. Pinning is **mandatory** — there is deliberately no trust-on-first-use fallback.
>
> Until **both** are set the workflow **skips cleanly** (no red X) and you fall back to the manual path below. Tracked in `blockers/`.

**Manual fallback** (no secret set yet, or deploying by hand):

```bash
# Push the ref you want, then run the deploy script on the droplet:
git push origin <your-branch>:staging --force
ssh lars@REDACTED_IP "bash ~/deploy-staging.sh"

# Or, if ~/deploy-staging.sh isn't installed yet, install it first:
scp scripts/deploy/deploy-staging.sh lars@REDACTED_IP:~/deploy-staging.sh
ssh lars@REDACTED_IP "chmod +x ~/deploy-staging.sh && bash ~/deploy-staging.sh"
```

`~/deploy-staging.sh` always operates on the `staging` branch and the `example_staging` DB — never `main`, never the prod DB.

### Wiping staging data

Safe — staging is a sandbox.

```bash
ssh lars@REDACTED_IP \
  "sudo -u postgres dropdb example_staging && \
   sudo -u postgres createdb -O lars example_staging && \
   cd /home/lars/example-staging && \
   PGDATABASE=example_staging bash scripts/migrate.sh && \
   sudo systemctl restart example-staging"
```

### Rotating staging secrets

Same model as prod (see [ADR 0022](../adr/0022-secrets-policy.md)) but the rotation only touches the staging GitHub OAuth app + the staging webhook. Production credentials are unaffected.

## What's intentionally NOT separated

These resources are shared between prod and staging by design — separating them would multiply cost without buying meaningful isolation for a $5K-budget project:

- **The droplet itself** — `REDACTED_IP`. Both processes co-exist on this one host. If we ever hit memory pressure or noisy-neighbor effects, splitting is a future architecture decision.
- **The Postgres server** — same `postgresql` daemon, separate databases. Postgres's per-database isolation is enough for the use case.
- **Caddy** — same Caddy instance routes both via the Host header.
- **The Cloudflare zone** — same `example.com` zone, different DNS records.
- **The Origin Cert** — the wildcard `*.example.com` SAN covers both, so one cert is enough.

The things that ARE separated (process, port, DB, OAuth app, env, chat webhook) are exactly the things that would cause a confused-with-prod incident if shared.

## Smoke-test recipe (for /merge-mode or manual checks)

```bash
# Full staging smoke from a laptop
HOST=https://staging.example.com
for path in /healthz /api/gds/healthz /api/gds/public/versions; do
  status=$(curl -o /dev/null -sS -w '%{http_code}' "${HOST}${path}")
  printf "  %-40s %s\n" "${HOST}${path}" "${status}"
done
# Expect three 200s.
```

The same shape as `scripts/gds/smoke-gds.js` but pointed at staging. A future task could parameterize `smoke-gds.js` to accept a host arg — filed as a follow-up.

## Freezing staging again (when you stop using it actively)

The mirror of the revival commands at the top of this doc:

```bash
ssh lars@REDACTED_IP "sudo systemctl stop example-staging && \
                           sudo systemctl disable example-staging"
# Verify it stays down:
curl -sS -o /dev/null -w '%{http_code}\n' https://staging.example.com/healthz   # → 502
```

The freeze preserves:

- The systemd unit file at `/etc/systemd/system/example-staging.service`
- The repo checkout at `/home/lars/example-staging`
- The `.env` file at chmod 600 with the staging OAuth credentials
- The `example_staging` Postgres database
- The Caddy block, DNS record, Origin Cert SAN, separate GitHub OAuth app

Idle resource cost on the droplet: ~0. The freeze is what you reach for instead of teardown when you might want staging back within months — re-provisioning the full chain (especially the DNS + cert + OAuth app dance) is more friction than leaving the scaffolding in place.

If you want a HARD teardown (e.g. droplet is going away, project pivoting), the sequence is in [§"The 'tear it down' option" in CLAUDE.md handoff for this work](../session-logs/) — drop the DB, remove the unit file, remove the checkout, revert the Caddy block. The GitHub OAuth app + the Cloudflare DNS record are free to leave around even after teardown.
