---
track: internal
scope: shared-infra (production droplet, Postgres) — used by Archons during forensic investigation
---

# Audit replay — reconstruct everything a builder did

> The forensic question this recipe answers: **"Given a builder_id and a date range, can we reconstruct every action they took against the city?"** If yes, the audit trail is complete. If no, the gap is a bug.

Run by an Archon when investigating an incident, a suspected compromise, or a "what exactly happened during that 4-hour overnight session?" question. The output is one chronological feed merging six tables.

## What it surfaces

| Kind | Source table | What it means |
|---|---|---|
| `CLAIM` | `claims.claimed_at` | Builder claimed a task — task locked to this session. |
| `CLAIM_END` | `claims.released_at` + `outcome` | Claim resolved — `outcome` says whether the work shipped, was abandoned, partially completed, or expired. |
| `CREDIT` | `credit_log.recorded_at` | Drachmae moved (`task.confirmed`, `ship.net_negative`, rank-change audit, etc.) — `delta` is the integer amount. |
| `COST` | `cost_log.recorded_at` | The builder logged a USD spend — `category` (api / compute / infra / domain / art / other) + `source`. |
| `SESSION_START` / `SESSION_END` | `session_logs.started_at` / `ended_at` | Claim-scoped working session boundaries. Pair with `outcome` for "shipped / partial / abandoned." |
| `HTTP_<METHOD>` | `audit_log.recorded_at` | Every authenticated POST / PATCH / PUT / DELETE the builder made — route, status, IP. The forensic fine-grain. |

Notably absent — and worth knowing about so you can ask follow-up questions if needed:

- **GET requests** are not in `audit_log` (by design; high volume, low signal). Read patterns aren't part of this replay.
- **Builder rank changes** show up as `HTTP_PATCH route=/api/gds/builders/:id/rank` rows and as `CREDIT` rows when the rank change carries a drachmae adjustment. The new rank value lives in `audit_log.request_body_redacted`.
- **Game-server WebSocket events** (movement, world state) live in `world_events` and are NOT included here — this script is GDS-scoped. If a game-side investigation is needed, query `world_events` separately.

## Running the script

```bash
bash scripts/gds/audit-replay.sh <builder_id> <start_iso> <end_iso>
```

The builder_id is the integer from the `builders` table. Look it up with:

```bash
ssh lars@REDACTED_IP \
  "psql -h /var/run/postgresql -d example -c \"SELECT id, github_login, rank FROM builders ORDER BY id\""
```

Timestamps are inclusive on both ends. Format is RFC 3339 / ISO 8601 — `2026-05-28T00:00:00Z` works; `2026-05-28` also works (interpreted as midnight UTC).

### Two modes — automatic

The script auto-detects whether it's running on the droplet (Postgres reachable on the local Unix socket) or on a builder's laptop. From a laptop it `exec`s itself over SSH to `lars@REDACTED_IP`, runs there, streams the TSV back. You don't need to think about it — but you DO need `lars@<droplet>` SSH access (Archon-only).

```bash
# laptop
bash scripts/gds/audit-replay.sh 1 2026-05-28T00:00:00Z 2026-05-28T23:59:59Z
# (silently SSHes to the droplet, runs psql there)
```

### Output

TSV, three columns: `when_utc`, `kind`, `detail`. Already sorted chronologically. Pipe to `column -t -s $'\t'` for visual padding, or to `wc -l` for a quick activity count, or to `awk -F'\t' '{print $2}' | sort | uniq -c | sort -rn` for an event-type histogram.

```bash
# Pretty-print
bash scripts/gds/audit-replay.sh 1 2026-05-28T00:00:00Z 2026-05-28T23:59:59Z \
  | column -t -s $'\t' \
  | less -S

# Histogram of event kinds for the day
bash scripts/gds/audit-replay.sh 1 2026-05-28T00:00:00Z 2026-05-28T23:59:59Z \
  | awk -F'\t' '{print $2}' | sort | uniq -c | sort -rn
```

## Identifying gaps

A "gap" is something the builder did that does NOT appear in the output. The replay is complete when every meaningful action threads through one of the six tables. Known classes of gap (file as a task and fix):

- **Direct DB writes via psql.** If an Archon runs `psql … UPDATE tasks SET …` directly, that bypasses the API and produces NO `audit_log` row. Mitigation: don't do that without documenting in the corresponding claim's `session_logs.notes_md`. (See CLAUDE.md §8 working rules — direct DB writes need a claim too.)
- **Game-server side effects** (player position updates, WorldRoom state). These intentionally live in `world_events` and are out of scope here; a separate game-side replay would be needed for that.
- **Webhooks / scheduled tasks** that act as a builder identity. Each scheduled task runs as `example-owner` (the droplet's service identity); its actions ARE captured as that builder's audit log entries, but a forensic reader needs to know to filter them by `route` shape (e.g. routes that no human ever hits).
- **Build-broadcast posts** to Discord `#ship-news` (`scripts/discord/`, webhook — replaced the retired Google Chat `scripts/chat/` on 2026-06-05). The broadcast itself is not in `audit_log`, but the *trigger* (which task shipped) IS, as a `POST /api/gds/tasks/:id/ship`. So the chain is reconstructable: the audit-replay shows "X shipped at T"; the Discord `#ship-news` channel shows the broadcast went out shortly after.

If you find a class of action that produces NEITHER a row in any of the six tables NOR a record elsewhere, file it as a task — that's a real audit-trail gap.

## Performance notes

The script issues one SQL statement (a multi-CTE `UNION ALL`). Indices already in place:

- `claims (builder_id) WHERE released_at IS NULL` — fast active-claim filter.
- `credit_log (builder_id, recorded_at)` — point-in-time by builder.
- `audit_log (builder_id, recorded_at DESC)` — same.

`cost_log` does NOT have a builder_id column (cost is task-attributed); the script joins through `claims` to find cost rows for tasks this builder ever claimed. That join is the slowest leg; for a wide date range it can take seconds. For typical "one builder, one day" queries it returns in ~50ms.

If a future need emerges to surface costs even when the builder didn't claim the task (e.g. an automated cost logger that ran outside any claim), we'd need a `builder_id` column on `cost_log`. File as a follow-up task at that time.

## Extending the script

The script is structured as one CTE per source table. To add a new table:

1. Add a new `UNION ALL` clause in `all_events` selecting the same three columns (`when_utc`, `kind`, `detail`).
2. Update the table in the "What it surfaces" section above.
3. Re-run the script against a known date range to sanity-check the new rows appear.

Don't add tables that don't carry a builder-attributable timestamp — they don't fit the replay model and should be queried separately.
