-- GDS-V4 Medusa Planning Session seed (2026-06-17)
-- Applied under claim 982 (task 1188 — "V4 — Medusa Planning Session").
-- Idempotent on re-run.
--
-- Adds the "Medusa" scope to GDS-V4: decouple the GDS from the Amazonprimea
-- game into a standalone, configurable, self-hostable, AGPL open-source,
-- non-profit, AI-first build platform. Amazonprimea becomes instance 1.
--
-- What this migration does:
--   1. Appends a Medusa clause to versions.GDS-V4 done_when (guarded so it
--      only appends once).
--   2. Seeds 2 done_when_criteria rows (C8 + C9) for version_id='GDS-V4'
--      at sort_order 8 and 9 (after the 7 existing criteria).
--
-- Net-new tasks (R50–R73, 24 of them) are created via
-- scripts/gds/seed-medusa-tasks.js which runs AFTER this migration is applied,
-- so the positional "C8"/"C9" criterion refs resolve. Same split as the
-- V4 Planning Session #1 seed (migration 080 + seed-gds-v4-tasks.js).
--
-- Locked owner decisions (this session): one project per install (no
-- multi-tenant project_id retrofit); migrate in place (OTB = instance 1, live
-- prod never breaks); AGPL-3.0 (anti-monopoly); keep the Greek rank ladder
-- (xenos<thetes<metic<archon) as the canonical enum (no rename); branding is a
-- per-instance config layer an owner's own LLM fills; feature-module selection
-- per instance; self-host canonical, managed hosting an optional later layer;
-- mobile contribution deferred to a later version; AI-first as a documented
-- norm (not a technical gate).
--
-- Source: 2026-06-17 Medusa decoupling codebase sweep (8-dimension audit +
-- synthesis + critique).

BEGIN;

-- ============================================================================
-- 1. Append a Medusa clause to the version-level done_when (once only).
-- ============================================================================
UPDATE versions
SET done_when = done_when ||
  ' And the build system itself becomes Medusa — a standalone, configurable, self-hostable, AGPL-licensed, non-profit, AI-first platform decoupled from any one project, with Amazonprimea running as its first instance.'
WHERE id = 'GDS-V4'
  AND done_when NOT LIKE '%Medusa%';

-- ============================================================================
-- 2. Seed the 2 Medusa done_when_criteria rows for GDS-V4 (C8 + C9).
--    UPSERT via ON CONFLICT (version_id, criterion_id).
--    sort_order 8/9 → positional refs "C8"/"C9" for the seed script.
-- ============================================================================
INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, sort_order)
SELECT * FROM (VALUES
  ('GDS-V4', 'medusa-standalone-instance',
   '**Medusa runs as a configurable, self-hostable, branded instance — Amazonprimea is instance 1.** The build system is no longer a fixture of the game: it boots with no game code in the process, runs on its own database, and takes its identity, branding, and feature selection from per-instance config — Amazonprimea becomes instance 1, its surfaces (status/builders) unchanged because their look now comes from config rather than hard-coding. Done when: a Medusa-only entrypoint boots with no Colyseus/Phaser/game routes; a fresh instance''s database holds only build-system tables (game tables only when the game module is enabled); one command (docker compose) stands an instance up with zero hard-coded server IP / service name / deploy script; product name, domain, sign-in origin, repo binding, currency label and the full branding pack resolve from one config with a neutral starter an owner''s own LLM fills; the first admin is set at install time, not in a migration; core carries no hard-coded project branding (the deploy-time diagram generator reads instance branding too; Greek rank names stay by decision); an instance turns feature modules (game, art pipeline, Discord, dev boxes) on/off; an instance declares its core version and `medusa upgrade` applies new migrations + code while preserving instance config; and a second, differently-branded non-game instance is created via a generic init flow and ships one task claim->grade->ship end-to-end. Live Amazonprimea is unaffected throughout.',
   8),
  ('GDS-V4', 'medusa-open-and-protected',
   '**Medusa is open, free, and protected from capture.** The platform is released to the public as open source on a deliberate delay so the live edge stays ahead of would-be cloners, under a license that stops a company from running a closed hosted fork, with non-profit, AI-first governance so it cannot be quietly captured. Done when: an AGPL-3.0 LICENSE ships in the repo; a public mirror repository carries only the publishable subset (the build system — not the game, infra secrets, or trust-boundary internals); an automated pipeline publishes to the mirror on a ~6-month delay with a redaction layer that strips secrets and prod topology even from old commits; GOVERNANCE, CONTRIBUTING, and CODE_OF_CONDUCT define the non-profit, AI-first (AI always writes the code) anti-monopoly stance; and the private<->public lineages stay consistent (migration numbering and enum values do not diverge), verified by a no-leak check on the published mirror.',
   9)
) AS v(version_id, criterion_id, criterion_md, sort_order)
WHERE EXISTS (SELECT 1 FROM versions WHERE id = 'GDS-V4')
ON CONFLICT (version_id, criterion_id) DO UPDATE
  SET criterion_md = EXCLUDED.criterion_md,
      sort_order   = EXCLUDED.sort_order;

-- ============================================================================
-- 3. Self-register so migrate.sh skips this file on the next deploy (it was
--    hot-applied via psql under the planning session). ON CONFLICT keeps it
--    safe if migrate.sh also registers it.
-- ============================================================================
INSERT INTO schema_migrations (version) VALUES ('110_medusa_planning_seed')
ON CONFLICT DO NOTHING;

COMMIT;
