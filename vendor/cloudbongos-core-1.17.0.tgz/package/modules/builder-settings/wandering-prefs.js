// src/bongos/wandering-prefs.js — the per-builder "wandering" knob (task 1268).
//
// Wandering governs how readily an agent opens a NEW THREAD of work — a
// tangent, an investigation, an unsolicited suggestion — instead of staying on
// its claimed task. It does NOT touch in-task initiative: even a locked
// newcomer still does whatever it takes to finish their claimed task well
// (chasing a real blocker is in-task, not wandering). The knob suppresses
// SPAWNING new threads beyond the claim, never the quality of work on the claim.
//
// Motivating failure: a newcomer session finished an ideator chore, then
// invented a phantom "credit discrepancy" (a running balance grows every ship —
// nothing was wrong) and invited the user to investigate, derailing a focused
// newcomer. The knob targets the escalation, not the noticing.
//
// Storage. One reserved key ('wandering') inside the `behavior_prefs` jsonb
// column on `builders` (migration 119) — the same single-jsonb-column pattern
// as skill_model_prefs (037) and sound_prefs (075). behavior_prefs is the
// blob; future behavior knobs add their own reserved keys. A missing key falls
// back to the rank-derived default below, so the column stays sparse.
//
// Resolution = default-by-rank, capped-by-rank, server-enforced.
//   - DEFAULT level rides the trust ladder (Xenos→Locked … Archon→Exploratory).
//   - MAX (ceiling) per rank: Xenos and Thetes are capped at their default (they
//     may dial DOWN for more focus, never UP); Metic and Archon may set any
//     level (their rank is a starting default, not a ceiling). Owner decision
//     2026-06-19: "Thetes is gated; Metic is just a starting default."
//   - effectiveLevel = clamp(override ?? default, 0, maxForRank). So a Xenos who
//     stores Exploratory is still resolved to Locked — opening the setting up
//     for self-service later stays safe because the clamp is the enforcement,
//     not the UI.
//
// Prior art: OpenAI's GPT-5 guide ships this exact knob as "agentic eagerness"
// (low = stay focused / minimize tangents; high = explore broadly). The
// per-level contracts below are phrased POSITIVELY ("when the task is done, stop
// and report") — negative framing ("don't suggest tangents") measurably
// backfires with LLMs.
//
// This module is the single source of truth: the /me API surfaces it, the
// /settings UI reads it, and the Conductor hook resolves the contract against
// it before injecting focus guidance into the session.

// Ordered low→high; the array index IS the level number (0..3).
const LEVELS = Object.freeze(['locked', 'focused', 'balanced', 'exploratory']);

// Human-facing copy + the behavior contract injected into the agent. `inject`
// marks the levels whose contract actively CONSTRAINS behavior and is worth
// spending session context on (the Conductor emits only these — see
// shouldInject). The permissive top levels read as "do what you'd naturally
// do", so injecting them would be noise.
const LEVEL_META = Object.freeze({
  locked: {
    n: 0,
    label: 'Locked',
    blurb: 'Strictly the claimed task. Off-task notes are filed silently, never raised.',
    inject: true,
  },
  focused: {
    n: 1,
    label: 'Focused',
    blurb: 'On task, full in-task initiative; at most one captured follow-up at the end.',
    inject: true,
  },
  balanced: {
    n: 2,
    label: 'Balanced',
    blurb: 'May surface a high-value tangent mid-task as "capture or pursue?" — your call.',
    inject: false,
  },
  exploratory: {
    n: 3,
    label: 'Exploratory',
    blurb: 'A thinking partner — actively surfaces adjacent work and investigations.',
    inject: false,
  },
});

// The positive-framed behavior contract per level. Injected verbatim by the
// Conductor + surfaced on /me. Kept here so there is exactly one copy.
const LEVEL_CONTRACT = Object.freeze({
  locked:
    'Focus mode (wandering: Locked — the newcomer floor). Work only your claimed task. '
    + 'The instant its done-when is met, report what you did and stop; your only forward '
    + 'pointer is `/builder-start` for the next task. If you notice anything beyond the claim '
    + '(a bug, an oddity, a number that looks off, an improvement), file it in one line with '
    + '`node scripts/gds/capture.js "…"` and move on — do not raise it, explain it, or offer to '
    + 'investigate. In-task work is unaffected: do whatever it takes to finish the claim well.',
  focused:
    'Focus mode (wandering: Focused). Stay on your claimed task; in-task initiative is full. '
    + 'At a natural stopping point you may note at most ONE adjacent, in-version follow-up — as a '
    + 'single line, captured with `capture.js`, not pursued now. Don\'t open investigations into '
    + 'anomalies; file them and move on.',
  balanced:
    'Wandering: Balanced. Stay anchored to your claim, but if you hit a genuinely high-value or '
    + 'blocking tangent you may surface it briefly and ask "capture or pursue?" — leave the call to '
    + 'the user. Note anomalies as observations; don\'t rabbit-hole.',
  exploratory:
    'Wandering: Exploratory. Act as a thinking partner — surface adjacent improvements and '
    + 'investigations worth the user\'s attention as you go, while still landing the claimed task.',
});

// Default level per rank (the array index in LEVELS). Rides the live rank
// ladder (xenos<thetes<metic<archon — db.RANKS / boxes.RANK_ORDER). A rank not
// listed (e.g. a reserved/penalty rank, or an unknown string) falls back to the
// safest floor: Locked.
const RANK_DEFAULT = Object.freeze({ xenos: 0, thetes: 1, metic: 2, archon: 3 });

// Ceiling per rank. Below Metic the default IS the ceiling (dial down only);
// Metic+ may pick any level. Unknown rank → floor (0).
const RANK_MAX = Object.freeze({ xenos: 0, thetes: 1, metic: 3, archon: 3 });

const TOP_LEVEL = LEVELS.length - 1; // 3
const RESERVED_KEY = 'wandering';

// ---- load-time self-assertions (catch drift at deploy, not runtime) ----
if (LEVELS.length !== 4) throw new Error('wandering-prefs: LEVELS must have exactly 4 entries');
for (const key of LEVELS) {
  if (!LEVEL_META[key]) throw new Error(`wandering-prefs: LEVELS has '${key}' but LEVEL_META has no entry`);
  if (typeof LEVEL_CONTRACT[key] !== 'string') throw new Error(`wandering-prefs: no contract for level '${key}'`);
}
for (let i = 0; i < LEVELS.length; i++) {
  if (LEVEL_META[LEVELS[i]].n !== i) throw new Error(`wandering-prefs: LEVEL_META.${LEVELS[i]}.n must equal its index ${i}`);
}
for (const rank of Object.keys(RANK_DEFAULT)) {
  if (!(rank in RANK_MAX)) throw new Error(`wandering-prefs: RANK_DEFAULT has '${rank}' but RANK_MAX does not`);
  if (RANK_DEFAULT[rank] > RANK_MAX[rank]) throw new Error(`wandering-prefs: default > max for rank '${rank}'`);
}

// ---- pure helpers ----

function isLevelInt(n) {
  return Number.isInteger(n) && n >= 0 && n <= TOP_LEVEL;
}

function levelKey(n) {
  return isLevelInt(n) ? LEVELS[n] : null;
}

function levelIndex(key) {
  const i = LEVELS.indexOf(key);
  return i === -1 ? null : i;
}

function defaultLevelForRank(rank) {
  return Object.prototype.hasOwnProperty.call(RANK_DEFAULT, rank) ? RANK_DEFAULT[rank] : 0;
}

function maxLevelForRank(rank) {
  return Object.prototype.hasOwnProperty.call(RANK_MAX, rank) ? RANK_MAX[rank] : 0;
}

// The override a builder has stored (the raw 'wandering' key off behavior_prefs),
// or null when unset/invalid. Kept separate from the effective level so the UI
// can show "you chose X" vs "resolved to Y (capped by rank)".
function overrideLevel(behaviorPrefs) {
  const raw = behaviorPrefs && behaviorPrefs[RESERVED_KEY];
  return isLevelInt(raw) ? raw : null;
}

// The resolved level for a builder: their override if set, else the rank
// default — then clamped to [0, maxForRank]. This is the enforcement point.
function effectiveLevel(behaviorPrefs, rank) {
  const base = overrideLevel(behaviorPrefs);
  const want = base === null ? defaultLevelForRank(rank) : base;
  const max = maxLevelForRank(rank);
  return Math.max(0, Math.min(want, max));
}

// The behavior-contract text for a level (by int or key). Used by the Conductor
// + surfaced on /me. Returns '' for an out-of-range level.
function contractFor(level) {
  const key = typeof level === 'string' ? level : levelKey(level);
  return key && LEVEL_CONTRACT[key] ? LEVEL_CONTRACT[key] : '';
}

// Should the Conductor spend session context injecting this level's contract?
// Only the constraining (low) levels — the permissive ones already match the
// agent's default behavior, so emitting them would be noise.
function shouldInject(level) {
  const key = typeof level === 'string' ? level : levelKey(level);
  return !!(key && LEVEL_META[key] && LEVEL_META[key].inject);
}

// The full catalog the UI renders (every level + whether this rank may pick it).
function levelCatalog(rank) {
  const max = maxLevelForRank(rank);
  return LEVELS.map((key, n) => ({
    n,
    key,
    label: LEVEL_META[key].label,
    blurb: LEVEL_META[key].blurb,
    allowed: n <= max,
  }));
}

// Everything the /me payload + the /settings UI need in one object.
function describeForApi(behaviorPrefs, rank) {
  const def = defaultLevelForRank(rank);
  const max = maxLevelForRank(rank);
  const override = overrideLevel(behaviorPrefs);
  const eff = effectiveLevel(behaviorPrefs, rank);
  return {
    rank: rank || null,
    levels: levelCatalog(rank),
    default_level: def,
    default_key: levelKey(def),
    max_level: max,
    max_key: levelKey(max),
    override_level: override,
    effective_level: eff,
    effective_key: levelKey(eff),
    effective_label: LEVEL_META[levelKey(eff)].label,
    contract: contractFor(eff),
    inject: shouldInject(eff),
  };
}

// Validate a PATCH body: { wandering: <0..3> | null }. `null` clears the
// override (fall back to the rank default). opts.maxLevel (default = top) caps
// the accepted value — the route passes maxLevelForRank(rank) so a builder
// can't store a level above their rank ceiling and get a confusing silent
// clamp. Unknown keys → 422. Returns { ok, patch } or { ok:false, errors }.
function validatePatch(body, opts = {}) {
  if (body == null || typeof body !== 'object' || Array.isArray(body)) {
    return { ok: false, errors: [{ error: 'body_must_be_object' }] };
  }
  const cap = isLevelInt(opts.maxLevel) ? opts.maxLevel : TOP_LEVEL;
  const errors = [];
  const patch = {};
  for (const [key, value] of Object.entries(body)) {
    if (key !== RESERVED_KEY) {
      errors.push({ key, error: 'unknown_key', allowed: [RESERVED_KEY] });
      continue;
    }
    if (value === null) { patch[RESERVED_KEY] = null; continue; } // clear → default
    if (!isLevelInt(value)) {
      errors.push({ key, error: 'invalid_level', value, allowed: `integer 0..${TOP_LEVEL}` });
      continue;
    }
    if (value > cap) {
      errors.push({ key, error: 'above_rank_cap', value, max: cap });
      continue;
    }
    patch[RESERVED_KEY] = value;
  }
  if (errors.length > 0) return { ok: false, errors };
  return { ok: true, patch };
}

// Apply a validated patch to a builder's existing behavior_prefs. Pure. null
// deletes the key (fall back to default); a valid int overwrites. Other keys in
// the blob (future behavior knobs) are left untouched.
function applyPatch(existing, patch) {
  const next = { ...(existing || {}) };
  for (const [key, value] of Object.entries(patch)) {
    if (value === null) delete next[key];
    else next[key] = value;
  }
  return next;
}

module.exports = {
  LEVELS,
  LEVEL_META,
  LEVEL_CONTRACT,
  RANK_DEFAULT,
  RANK_MAX,
  TOP_LEVEL,
  RESERVED_KEY,
  isLevelInt,
  levelKey,
  levelIndex,
  defaultLevelForRank,
  maxLevelForRank,
  overrideLevel,
  effectiveLevel,
  contractFor,
  shouldInject,
  levelCatalog,
  describeForApi,
  validatePatch,
  applyPatch,
};
