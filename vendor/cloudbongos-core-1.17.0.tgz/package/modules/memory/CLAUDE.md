# `memory` module — builder memory, recall/search, learnings

> The **first CORE-domain** carved into a module (BV1.R72, [ADR 0091](../../docs/adr/<redacted>.md) §2) — not an optional feature like dev-box/discord/art/game, but a core methodology domain extracted to prove the kernel↔core-domain boundary. It is the reference every later core-domain carve (grading R73, …) copies.

Owns per-builder session **memory** (the BFG-scoped store the hall syncs), the lexical **recall/search** retrieval layer ([ADR 0060](../../docs/adr/0060-gds-retrieval-layer.md): Postgres FTS + trigram/RRF), and durable **learnings**. `default: true` in `module.json` — the build system's memory ships to **every** instance (unlike the default-off feature modules), so it mounts unconditionally unless an instance explicitly disables it.

## The boundary (the one rule)

This module reaches core **only** through the published doorway `../../src/module-api.js` (`coreVersion ^1.5.0`). It must **never** `require()` a core internal (`../../src/bongos/db`, `../../src/bongos/auth`, `../../src/bongos/pool`, …) directly, and never another module. Core, in turn, must never `require()` a file in here — the route mounts left `src/bongos/routes.js`; `moduleLoader.mountModuleRoutes` discovers + mounts them now. Both directions are enforced by the BV1.R44/R45 fitness checks; R70's `kernel-imports-no-domain` check additionally keeps the kernel from reaching back in.

## Files

| File | What |
|---|---|
| `memory.js` | per-builder memory store (quotas, BFG namespace, store/fetch/list). Manages its own transactions via the doorway `pool`. |
| `search.js` | the recall query engine — FTS + trigram, RRF fusion, rank-scoped (ADR 0060). |
| `search-chunker.js` | pure markdown→chunk splitter (no DB). Also used by the `search-ingest-*` CLIs (memory-owned scripts). |
| `learnings.js` | durable paid-once knowledge capture (the `learnings` table). |
| `routes/memory.js` | `/memory/*` — sync/read/forensic. Carries its own larger `express.json` for `/memory/sync` (1 MB batches); core `routes.js` still skips the global parser for that path. |
| `routes/search.js` | `/search` (recall) + `/search/mark` (the ADR 0095 C3 usefulness vote — `POST {chunk_id, useful?}`, session-scoped). |
| `routes/learnings.js` | `/learnings` (POST capture + GET). |

All four lib files reach Postgres through the doorway `pool`; the routes reach auth gates + the kernel db helpers (`getBuilderById`, `insertAuditLog`) + the shared request validators (`validateOrRespond`/`LIMITS`) off the doorway `api`, and the lib files via intra-module relative requires.

## Tables (owned, not moved)

`builder_memory`, `memory_search_chunks`, `learnings` (+ their migrations) were created before the module system and stay in core `migrations/` (the schema-migrations stem-key makes a later relocation a no-op). The module owns the *queries*; any **new** memory migration belongs in `modules/memory/migrations/` namespaced `memory_*` (the additive rule).

## Seams

None yet — memory neither provides nor consumes a port/event. Core reads memory only through its HTTP routes (the hall's sync/recall), never a direct import.

## NOT in this module

- **`bfg.js`** — the BFG memory-hygiene evaluator stays core (it scores memory quality across builders); it touches memory through the routes/store contract, not a sibling import.
- **`migrations/`** — the memory tables' creating migrations stay in core `migrations/` (pre-module-system; see Tables above).

## Tests

`tests/memory_isolation.mjs`, `tests/bfg*.mjs`, `tests/search_*.mjs`, `tests/search_chunker.mjs`, `tests/diff_derived_signals.mjs`, `tests/recall_*.mjs` import from `modules/memory/…`. The ADR 0095 C3 mark/rank loop's DB-backed cases live in the `tests/search_isolation.mjs` Layer C class (integration gate); the pure ranker-factor + scope logic is exercised by the in-module assertions in `markChunkUsefulness`.
