-- core_189_core_upgrades_ledger.sql — the per-instance core-upgrade ledger
-- (task 1690, ADR 0100 §2 / ADR 0103 §4 — the `bongos upgrade` channel).
--
-- When a two-repo consumer pulls the Cloud Bongos core from version N to N+1 via
-- `bongos upgrade`, the channel records the event here: which version it came
-- from, which it went to, the core source commit (from the pin manifest), and an
-- optional note. This is a small, per-instance audit trail — each consumer's own
-- DB carries its own upgrade history — and doubles as the migration the first
-- real bump actually APPLIES, so the channel's "runs additive migrations" step is
-- exercised end-to-end rather than being a no-op on a consumer with no pending
-- schema changes.
--
-- This is a CORE-owned table (it ships in the core package and every consumer
-- gets it), so it lives in core migrations/, core_-namespaced (ADR 0108 §5: a new
-- core migration numbered above LEGACY_BARE_CORE_MAX=187 must be core_-prefixed,
-- else the fitness namespacing check reds the build).
--
-- PURELY ADDITIVE + idempotent (CREATE ... IF NOT EXISTS): fresh-DB-replay safe,
-- no hard-coded builder ids (learning 1238). migrate.sh records this file's stem
-- in schema_migrations (the modern 187/188 pattern — the file does not
-- self-insert).

BEGIN;

CREATE TABLE IF NOT EXISTS core_upgrades (
  id            bigserial PRIMARY KEY,
  from_version  text,                                   -- the core version upgraded FROM (null if unknown / first pin)
  to_version    text NOT NULL,                          -- the core version upgraded TO
  source_commit text,                                   -- the core's source commit (from the pin manifest), when known
  note          text,                                   -- optional free-text (e.g. who ran it / why)
  applied_at    timestamptz NOT NULL DEFAULT now()
);

-- Cheap "what's the latest applied upgrade" lookup.
CREATE INDEX IF NOT EXISTS core_upgrades_applied_at_idx ON core_upgrades (applied_at DESC);

COMMIT;
