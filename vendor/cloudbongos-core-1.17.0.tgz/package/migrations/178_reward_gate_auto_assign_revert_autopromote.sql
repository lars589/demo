-- 178 reward gate: AUTO-ASSIGN at the gate, revert the migration-177 auto-promote
-- reward clause.
--
-- Applied under task 1673 (GDS-V4 — amend task 1670 / ADR 0096). See the dated
-- 2026-06-28 amendment in docs/adr/0096-require-reward-before-workable.md.
-- Idempotent on re-run.
--
-- The gate no longer BLOCKS an unrewarded task from becoming workable — it
-- AUTO-ASSIGNS a capped, audited credits_reward at the promote route + the claim
-- path (both in modules/lifecycle/{routes/tasks.js,db.js}). Because claim-time
-- auto-assign covers every task, the auto-promotion predicate no longer needs a
-- reward clause: migration 177 added `(reward_gate_exempt OR credits_reward > 0)`
-- to task_is_fully_unblocked; this migration REVERTS that, restoring the
-- dependency-doneness check ONLY (the migration-163 definition). A deps-shipped
-- task now auto-promotes backlog->ready even at 0 reward; the claim path assigns a
-- real value before any work starts.
--
-- The reward_gate_exempt column (added by 177) becomes INERT: nothing reads it
-- anymore (the gate auto-assigns regardless of the flag, so the grandfathered
-- ~27 tasks earn a fair value when claimed). We leave the column in place — a
-- later migration may drop it once the backfill (task 1672) is complete. See the
-- ADR amendment.
--
-- No data backfill, no demotion: CREATE OR REPLACE only swaps the predicate body;
-- the auto-promotion triggers (migration 163) reference the same function and pick
-- up the reverted body on their next fire. Rows already in 'ready' are never
-- re-evaluated, so nothing moves.

BEGIN;

-- Revert task_is_fully_unblocked to the migration-163 deps-doneness predicate
-- (drop the 177 reward-gate clause). TRUE iff NONE of the task's gating edges
-- (own + goal + criterion) points at an un-done node. An orphaned `to` yields no
-- EXISTS match -> counts as un-done -> task stays blocked (fail-closed). This is
-- byte-identical to the 163 body.
CREATE OR REPLACE FUNCTION task_is_fully_unblocked(p_task_id bigint)
RETURNS boolean AS $$
  SELECT NOT EXISTS (
    WITH gating AS (
      SELECT d.to_kind, d.to_id
        FROM dependencies d
        JOIN tasks t ON t.id = p_task_id
       WHERE (d.from_kind = 'task'      AND d.from_id = t.id)
          OR (d.from_kind = 'goal'      AND d.from_id = t.goal_id)
          OR (d.from_kind = 'criterion' AND d.from_id IN (
                SELECT tc.criterion_id FROM task_criteria tc WHERE tc.task_id = t.id))
    )
    SELECT 1
      FROM gating g
     WHERE NOT (
          (g.to_kind = 'task'      AND EXISTS (SELECT 1 FROM tasks              x WHERE x.id = g.to_id AND x.status = 'shipped'))
       OR (g.to_kind = 'criterion' AND EXISTS (SELECT 1 FROM done_when_criteria x WHERE x.id = g.to_id AND x.satisfied))
       OR (g.to_kind = 'goal'      AND EXISTS (SELECT 1 FROM goals              x WHERE x.id = g.to_id AND x.status = 'achieved'))
     )
  );
$$ LANGUAGE sql STABLE;

INSERT INTO schema_migrations (version) VALUES ('178_reward_gate_auto_assign_revert_autopromote')
  ON CONFLICT (version) DO NOTHING;

COMMIT;
