const express = require('express');
// Intra-module + the published doorway — a module never requires a core internal.
const api = require('../../../src/module-api');
const auth = api;
const db = require('../db');
const versionClose = require('../version-close');
const doneWhen = require('../done-when');
const { asyncHandler, validateOrRespond } = api;

// versions.status CHECK (migration 003). A new version starts 'planning' or
// 'building'; 'shipped'/'frozen' are end states reached via the close flow.
const VALID_VERSION_STATUSES = new Set(['planning', 'building', 'shipped', 'frozen']);

module.exports = function buildVersionsRouter() {
  const router = express.Router();

  // rank: public — read-only version list; mirrors /public/versions. Preserved
  // unauthenticated per CRITICAL §1 (matches current production behavior).
  router.get('/versions', async (req, res) => {
    // R14 (#2001 / ADR 0119): adopt the shared pagination contract (was unbounded).
    // The version list is small, so fetch + slice; `page` is additive (readers of
    // .versions are unchanged).
    const { limit, offset } = api.parsePagination(req);
    const all = await db.listVersions();
    res.json({ versions: all.slice(offset, offset + limit), page: api.pageMeta(limit, offset, all.length) });
  });

  // rank: public — read-only progress aggregate; mirrors /public/progress.
  router.get('/versions/progress', async (_req, res) => {
    const progress = await db.versionProgress();
    res.json({ progress });
  });

  // Close-flow gate suggestions for every version still 'building'.
  // Used by /builder-start to surface the "ready to close" banner.
  // rank: public — read-only close-flow hints; consumed by /builder-start banner.
  // Preserved unauthenticated to match current behavior; non-sensitive aggregate.
  router.get('/versions/close-suggestions', asyncHandler('GET /versions/close-suggestions', async (_req, res) => {
    const suggestions = await versionClose.getCloseSuggestionsForBuildingVersions();
    res.json({ suggestions });
  }, { errorCode: 'close_suggestions_failed' }));

  // Per-criterion progress rollup: each done-when criterion → the tasks that
  // gate it (task_criteria, migration 055) → live statuses → what remains.
  // Powers `scripts/gds/status.js` + the /status skill (#435) and is reusable
  // by the public status dashboard. Registered AFTER the static /versions/*
  // routes above so ':id' can't swallow them.
  // rank: public — read-only aggregate, same posture as /versions/:id/done-when.
  // Public endpoint — asyncHandler logs the detail server-side but, with
  // message:false, never leaks err.message (SQL/internal text) to unauthenticated
  // callers (preserves the leak-safe 500 the hand-written catch produced).
  router.get('/versions/:id/progress', asyncHandler('GET /versions/:id/progress', async (req, res) => {
    const versionId = String(req.params.id || '').trim();
    if (!versionId) return res.fail('version_id_required', 400);
    const progress = await doneWhen.criterionProgress(versionId);
    res.set('Cache-Control', 'public, max-age=60');
    res.json(progress);
  }, { message: false, errorCode: 'progress_failed' }));

  // POST /versions — create a version + its done-when criteria in one call. The
  // seed primitive `bongos init` (task 1204 / R65) uses so a fresh instance needs
  // no hand-written seed-*.js script. Archon-only: creating a version is a
  // plan/scope mutation, same gate as POST /tasks (ADR 0016).
  // rank: archon — creates a version + its done-when criteria.
  router.post('/versions', auth.requireBuilder, auth.requireRank('archon'), asyncHandler('POST /versions', async (req, res) => {
    if (validateOrRespond(req, res, {
      id: { required: true, type: 'string', maxLength: 64, minLength: 1 },
      name: { required: true, type: 'string', maxLength: 200, minLength: 1 },
      status: { type: 'string', maxLength: 32 },
      done_when: { type: 'string', maxLength: 8000 },
      scope_doc_path: { type: 'string', maxLength: 256 },
      criteria: { type: 'array', maxItems: 100 },
    })) return;
    const body = req.body || {};
    const id = String(body.id).trim();
    const name = String(body.name).trim();
    if (!id || !name) return res.fail('id_and_name_required', 400);

    const status = body.status || 'planning';
    if (!VALID_VERSION_STATUSES.has(status)) {
      return res.fail('bad_status', 400, { valid: Array.from(VALID_VERSION_STATUSES) });
    }

    if (await db.getVersion(id)) {
      return res.fail('version_exists', { status: 409, message: `Version '${id}' already exists.` });
    }

    // Normalize criteria: each { criterion_id, criterion_md } (+ optional sort_order).
    const rawCriteria = Array.isArray(body.criteria) ? body.criteria : [];
    const criteria = [];
    for (let i = 0; i < rawCriteria.length; i++) {
      const c = rawCriteria[i];
      if (!c || typeof c !== 'object') return res.fail('bad_criterion', 400, { index: i });
      const criterionId = String(c.criterion_id || '').trim();
      const criterionMd = String(c.criterion_md || '').trim();
      if (!criterionId || !criterionMd) return res.fail('criterion_needs_id_and_md', 400, { index: i });
      criteria.push({
        criterion_id: criterionId,
        criterion_md: criterionMd,
        sort_order: Number.isFinite(c.sort_order) ? c.sort_order : (i + 1) * 10,
      });
    }

    let version, created;
    try {
      ({ version, criteria: created } = await db.createVersion({
        id, name, status,
        doneWhen: body.done_when ?? null,
        scopeDocPath: body.scope_doc_path ?? null,
        criteria,
      }));
    } catch (err) {
      // TOCTOU: the getVersion() pre-check above runs outside the insert
      // transaction, so two concurrent creates of the same id can both clear it;
      // the versions primary key is the real guard. Translate the race-loser's
      // unique-violation (Postgres 23505) into the same clean 409 the pre-check
      // returns, instead of letting asyncHandler surface a 500 (hacker dispatch,
      // task 1204).
      if (err && err.code === '23505') {
        return res.fail('version_exists', { status: 409, message: `Version '${id}' already exists.` });
      }
      throw err;
    }
    res.status(201).json({ version, criteria: created });
  }, { errorCode: 'create_version_failed' }));

  return router;
};
