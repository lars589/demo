-- 175_task_grades_diff_hash.sql — store a diff fingerprint alongside each grade (V4.R08).
--
-- Adds diff_hash TEXT to task_grades so ship.js can detect "same diff as the
-- last PASS" and skip re-running the adversarial panel. NULL for rows written
-- before this migration (pre-R08 grades).
--
-- Idempotent: safe to re-run.

ALTER TABLE task_grades ADD COLUMN IF NOT EXISTS diff_hash TEXT;
