# Recipe — deploying a Cloud Bongos instance on a pinned core (`git reset` → `npm ci`)

> ADR [0108](../adr/<redacted>.md) §4 (configurable-root W4, task [#1884](https://example.com/builders#/task/1884)). How a **consumer instance** — one that installs `@bongos/core` as a versioned npm dependency rather than living in the monorepo — deploys. This is the target the live droplet deploy converts to; the reference implementation is [`scripts/deploy/deploy-instance.sh`](../../scripts/deploy/deploy-instance.sh).

## The two models

| | Pre-split (today, `example`) | Post-split (consumer instance) |
|---|---|---|
| Core code | in-tree (the monorepo) | `node_modules/@bongos/core` (a pinned version) |
| Deploy | [`deploy-prod.sh`](../../scripts/deploy/deploy-prod.sh): `git reset --hard origin/main` on a shared checkout | [`deploy-instance.sh`](../../scripts/deploy/deploy-instance.sh): `git pull` the instance repo → `npm ci` → migrate → restart |
| Upgrade the core | (n/a — one tree) | bump the pin in `package.json` → `npm ci` → migrate → restart (ADR 0108 §4; the R86 channel, task [#1690](https://example.com/builders#/task/1690)) |
| `cloudbongos.com` | a 2nd service on the **same** checkout (why it ran stale) | its **own** consumer repo + its own `deploy-instance.sh` |

## The flow (`deploy-instance.sh`)

1. **`git pull --ff-only origin main`** the *instance* repo — host content only: `config/`, `migrations/instance/`, and the pinned core version in `package.json`.
2. **`npm ci --omit=dev`** — installs the pinned `@bongos/core` + instance deps. This is what replaces `git reset --hard`: the core is a dependency, so an upgrade is a pin bump + `npm ci`, not a source merge.
3. **`bash <core>/scripts/migrate.sh`** — the core's **three-root** migrate (W5 / ADR 0108 §5) merges `<core>/migrations` + `<instance>/migrations/instance` + each enabled module's migrations, keyed by namespaced filename stems (`core_NNN_`, `<key>_NNN_`, bare instance) so the two repos never collide. It resolves core-root vs instance-root via `src/instance-config.js`.
4. **restart the platform** — a systemd unit runs `node <core>/src/platform-server.js` (GDS-only) with `WorkingDirectory` = the instance root (so `resolveInstanceRoot()` resolves to the instance) + `PORT`/`HOST` env; then poll `/healthz`.

`docker-compose.yml` + `.github/workflows/selfhost-boot.yml` already model this shape (fresh Postgres → `npm ci` → `migrate.sh` → `platform-server`), so the flow is validated end-to-end there.

## Status — ready, not yet the live path

`deploy-instance.sh` is **additive and inactive**: the live `example` droplet still deploys via `deploy-prod.sh` (`git reset --hard`). The cutover is deliberately deferred:

- **First run: Mercury (R85, task [#1689](https://example.com/builders#/task/1689))** — a greenfield consumer on a pinned core proves the flow.
- **`example` cutover: R89 (task [#1728](https://example.com/builders#/task/1728))** — "Example splits last", **behind a security review** (ADR 0108 §6). It **must** land in lockstep with cutting the shared-checkout dual-instance deploy, or `cloudbongos.com` breaks (ADR 0108 §Consequences item 2).

`ship.js` needs no change: its deploy **trigger** SSHes `~/deploy.sh` (or fires the CI workflow) and is agnostic to what that script does internally — a consumer instance installs `deploy-instance.sh` as its `~/deploy.sh`.

## Wiring it on a consumer host (R85/R89)

1. Install the script as the droplet's `~/deploy.sh` (the CI deploy key is forced-command-locked to `~/deploy.sh` — ADR 0043 — so it stays hand-installed, like `deploy-prod.sh`).
2. Create a systemd unit for the instance: `ExecStart=/usr/bin/node <instanceRoot>/node_modules/@bongos/core/src/platform-server.js`, `WorkingDirectory=<instanceRoot>`, `Environment=PORT=… HOST=127.0.0.1 <PREFIX>_INSTANCE_ROOT=<instanceRoot>`.
3. Set `INSTANCE_SERVICE=<unit>` + `PORT=<port>` in the deploy environment.
4. Front it with TLS and point the origins at the real domain (see [self-host.md](self-host.md)).
