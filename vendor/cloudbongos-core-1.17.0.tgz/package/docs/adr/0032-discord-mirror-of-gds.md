# ADR 0032 — Discord as a one-way mirror of the GDS (outbound broadcast moves off Google Chat)

**Date:** 2026-06-04
**Context:** GDS-V3, task [#607](https://example.com/builders#/task/607) (claim `#482`). Stands up a Discord server for Off the Boats / Example — one server, permission-walled into a player wing and a builder wing — and moves the ship-broadcast off Google Chat. Companion to [ADR 0016](<redacted>.md) (the trust boundary — the load-bearing constraint here), [ADR 0018](<redacted>.md) (Xenos → Metic → Archon, the ranks Discord roles mirror), [ADR 0022](0022-secrets-policy.md) (webhook URLs are secrets, kept out of the repo), and [ADR 0008](0008-google-chat-oauth-user-auth.md) (the Google Chat broadcast this supersedes for outbound).
**Status:** Accepted. Phase 2 (outbound ship broadcast → Discord) implemented in [#607](https://example.com/builders#/task/607). Phases 3+ (interaction bot, inbound retirement, role sync) scoped below, not yet built.
**Track:** `internal` (dev-system / team communication).

## Problem

The project is opening to multiple builders (GDS-V3) and will eventually have players (the game is live; the purchase loop lands in V3-product). We want one community home with two audiences — builders and players — and a single legible place where build progress is announced and where the community can react.

Two existing surfaces are relevant:

- The **ship broadcast** posts a plain-language "what shipped" summary to the Example team **Google Chat** space ([ADR 0008](0008-google-chat-oauth-user-auth.md); fired from `scripts/gds/ship.js` on deploy). Google Chat is a closed business space — fine for the Example owners, wrong as a builder+player community hub.
- The **GDS** already holds all authoritative state: ranks, tasks, karma (`peer_upvote` is an existing reason), idea_inbox, drachmae, the builders' hall.

The temptation, standing up Discord, is to let it *own* things — roles that grant power, votes that live in Discord, a second scoreboard. That would fracture the source of truth and — for roles — quietly punch a hole in the trust boundary.

## Decision

**Discord is a one-way mirror of, and input surface for, the GDS — never a source of authority or truth.**

1. **One server, two role families, permission-walled.** A public (player) wing and a builder-only wing in a single server. Builder roles **mirror** the live GDS ranks (Xenos / Metic / Archon) and gate the builder wing; players get a `Citizen` baseline (a `Patron` tier later, once purchases ship).

2. **Discord roles are cosmetic, never authoritative ([ADR 0016](<redacted>.md)).** A Discord "Archon" badge unlocks Discord *channels* and nothing else. Authority stays in `builders.rank` on the prod DB, re-checked server-side per request. A Discord role is a *sticker*; the GDS holds the *keys*. Roles reflect what the DB already says — they never decide it. When a future bot auto-assigns roles, it reads `builders.rank` and writes the Discord role, never the reverse.

3. **The GDS stays the single source of truth.** Logs mirror *into* Discord (webhooks, one-way). "Upvotes" arrive as Discord reactions that a bot writes *back* to the GDS as `peer_upvote` karma / idea votes — Discord is the input device, the GDS records the fact. No state's canonical home moves to Discord.

4. **Outbound ship broadcast moves from Google Chat to Discord `#ship-news`** (this task, [#607](https://example.com/builders#/task/607)). `scripts/gds/ship.js` posts the task `--summary` to a Discord webhook via `scripts/discord/`. Same posting rules as before (plain-language, business-facing, no jargon — see [`../google-chat-broadcast.md`](../google-chat-broadcast.md)). Webhook URLs are secrets ([ADR 0022](0022-secrets-policy.md)) at `~/.config/otb/discord-webhooks.json` (mode 600), never committed; the broadcast runs on the operator's machine during `/builder-ship`, so the droplet needs no secret.

### Phasing

- **Phase 2 (this task, [#607](https://example.com/builders#/task/607)):** outbound `#ship-news` broadcast. **Done.**
- **Phase 3:** a Discord bot on the droplet for reactions → `peer_upvote` karma / idea votes, and retirement of the Google Chat **inbound** path (team messages → idea pipeline). Reading messages needs a bot, not a webhook. Account-linking (Discord user ↔ GDS builder) must be UI-first — browser clicks, no terminal token paste.
- **Later:** auto-sync `builders.rank` → Discord role; build out the player wing when the purchase loop ships.

## Consequences

- The team's "what shipped" updates now land in a community Discord that builders and players can share, instead of a closed business chat.
- The trust boundary stays intact and legible: exactly zero authority lives in Discord; the one rule to defend in review is "roles mirror the DB, never grant."
- Google Chat is **half-retired**: outbound is gone (Discord), inbound (`chat-intake-daily`) still runs until Phase 3. `scripts/chat/` stays in the tree until then.
- A leaked webhook URL is low blast-radius (write-only to one channel) and rotated with one click in Discord — no code change.

## Alternatives considered

- **Separate servers for builders vs players.** Rejected — one server with a permission-walled builder wing is the standard pattern and keeps the community in one place.
- **Discord roles grant real permissions.** Rejected outright — violates [ADR 0016](<redacted>.md). Anything a builder's Discord membership could grant must be re-derived server-side from `builders.rank`.
- **Move idea votes / karma canonical into Discord.** Rejected — the GDS stays source of truth; Discord is an input surface whose reactions a bot writes back.
- **Mirror outbound to both Google Chat and Discord.** Rejected — replace, don't double-post; the community consolidates on Discord. Google Chat keeps only its inbound role until Phase 3.
- **A Discord bot (gateway) for outbound too.** Rejected for Phase 2 — a webhook is a one-line HTTP POST with no token or process to host; the bot is only needed for *reading* (Phase 3).
