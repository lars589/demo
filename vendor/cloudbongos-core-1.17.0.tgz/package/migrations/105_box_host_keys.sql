-- 105_box_host_keys.sql — task 1187 (idea 235): authoritative box SSH host keys.
--
-- Why
-- ---
-- A re-provision is a FRESH droplet with brand-new /etc/ssh/ssh_host_* keys.
-- ssh_deletekeys:false (task 1040) only preserves them across park->wake (the
-- snapshot restores the disk); the idle-reaper DEPROVISIONS (destroys droplet +
-- snapshot), so the key changes on every reap->reprovision cycle — now routine.
-- The laptop/Desktop SSH path then throws "Host denied (verification failed)"
-- because known_hosts still pins the old box's key. Today's only recovery is TOFU
-- accept-new (which REJECTS a changed key) or the OTB Dev Box app's ssh-keyscan
-- re-pin (TOFU + racey — the 925/926 ed25519 partial-scan flakiness).
--
-- Fix: the box reports its own PUBLIC host keys UP to the GDS at provision (the
-- same report-up / serve-to-owner shape as the terminal_* columns in migration
-- 073), and the connect path WRITES known_hosts from this authoritative value —
-- no TOFU, no keyscan race. `host_keys` is newline-joined bare `<keytype> <base64>`
-- pairs (NO hostname prefix — the consumer prepends the host it dials).
--
-- PUBLIC KEYS ONLY. The box reporter reads only *.pub files; the PRIVATE half is
-- NEVER stored here. A host's public key is non-secret and is served to the box's
-- own builder via GET /box/me (no new read route, no allowBoxScope read surface).
--
-- Staleness model (same as 073): WRITTEN only when state='active'
-- (boxes.setBoxHostKeys gates on it); the value persists across park/wake (the
-- host identity survives a snapshot wake) and is replaced wholesale by the next
-- report after a re-provision. No NULL-clear on park.
--
-- Idempotent: safe to re-run.

ALTER TABLE builder_boxes ADD COLUMN IF NOT EXISTS host_keys    text;
ALTER TABLE builder_boxes ADD COLUMN IF NOT EXISTS host_keys_at timestamptz;

INSERT INTO schema_migrations (version) VALUES ('105_box_host_keys')
  ON CONFLICT (version) DO NOTHING;
