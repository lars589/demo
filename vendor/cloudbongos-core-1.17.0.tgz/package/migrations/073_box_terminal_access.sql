-- 073_box_terminal_access.sql — #760 (ADR 0038): the Chromebook on-ramp redesign.
--
-- Context
-- -------
-- Migration 070 added builder_boxes.remote_pairing_url/_at for the `claude rc`
-- Remote-Control on-ramp: the box published a claude.ai pairing link UP to the
-- GDS so a Chromebook builder could read it from the browser. #745 leg-5 then
-- proved `claude rc` CANNOT run on a headless box — Anthropic gates Remote
-- Control behind interactive Trusted-Devices enrollment + a controlling TTY +
-- full-scope OAuth, and every non-interactive auth path (ANTHROPIC_API_KEY,
-- setup-token, apiKeyHelper) is excluded from RC by design. No plumbing fixes it.
--
-- ADR 0038 replaces that path: the box serves its OWN browser session — ttyd (a
-- basic-auth web terminal) on 127.0.0.1:7681, exposed via an outbound-only
-- Cloudflare Tunnel (cloudflared). Inside it the builder runs NORMAL interactive
-- `claude` in a real PTY, so /login + workspace-trust + device enrollment all
-- work (there IS a human at a browser-backed terminal). The box reports its
-- current terminal URL AND a per-box basic-auth credential UP to the GDS (the
-- same up-report/serve-to-owner shape migration 070 built), and the builder
-- reads BOTH from the browser (GET /box/terminal).
--
-- This migration adds the terminal_* columns. Unlike the RC pairing link (a
-- bare handle), the terminal needs a CREDENTIAL too — hence the extra column.
-- The remote_pairing_url/_at columns from 070 are now DEPRECATED and left in
-- place (non-destructive); nothing writes them after this ships.
--
-- Staleness model (unchanged from 070): the value is only ever SERVED when the
-- box is state='active' (GET /box/terminal gates on it) and only ever WRITTEN
-- when active (boxes.setTerminalAccess gates on it), so a parked box's stale URL
-- is simply never returned — no explicit NULL-clear needed. The credential
-- persists in the box snapshot across park/wake (stable); the quick-tunnel URL
-- changes on each cloudflared restart, so the box re-reports it after a wake.
--
-- Sensitivity: terminal_credential IS a secret (basic-auth password to a live
-- shell). Like remote_pairing_url it is returned ONLY to the box's own builder
-- (GET /box/terminal, requireBuilder, own resource). It never appears in any
-- public surface or in box_events detail.
--
-- Idempotent: safe to re-run.

ALTER TABLE builder_boxes ADD COLUMN IF NOT EXISTS terminal_url        text;
ALTER TABLE builder_boxes ADD COLUMN IF NOT EXISTS terminal_credential text;
ALTER TABLE builder_boxes ADD COLUMN IF NOT EXISTS terminal_at         timestamptz;

INSERT INTO schema_migrations (version) VALUES ('073_box_terminal_access')
  ON CONFLICT (version) DO NOTHING;
