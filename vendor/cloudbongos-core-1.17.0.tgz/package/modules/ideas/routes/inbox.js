const express = require('express');
// Carved into modules/ideas/ (BV1.R78 / ADR 0093 §1+§5): auth gates + request
// validators reach through the published doorway; `inbox` is an intra-module
// sibling — a module never requires a core internal.
const api = require('../../../src/module-api');
const inbox = require('../inbox');
const { validateOrRespond, LIMITS, parseId } = api;

const INBOX_STATUS_VALUES = ['open', 'promoted', 'discarded', 'merged'];

// The `ideas.capture` kernel PORT (ADR 0093 §5) — captureIdea's permanent home,
// which retired the temporary `module-api.captureIdea` doorway leak (ADR 0091
// §3). The discord module's #ideas inbound (`discord-inbound.js`) resolves it
// instead of importing core. Registered here (the route factory is the one boot
// hook that runs both in the live server AND when a test rebuilds the GDS
// router) and hasProvider-guarded so re-instantiation never trips the seam's
// single-provider guard. Mirrors modules/economy/routes/reward.js.
function registerSeams() {
  if (!api.hasProvider('ideas.capture')) {
    api.registerProvider('ideas.capture', inbox.captureIdea);
  }
}

module.exports = function buildInboxRouter() {
  registerSeams();
  const router = express.Router();

  // rank: any-builder for ordinary ideas; metic+ for kind='criterion-proposal'.
  // Anyone can file a general contribution (the open-to-all path that
  // idea-triage's "Xenos can still file" line guarantees). But kind=
  // 'criterion-proposal' is the marker the /planning-session skill writes from
  // Metic-mode, and a planning-session proposal reshapes the next version's
  // scope-truth — that's a trusted-builder operation (V3.R87 / #306). Gate it
  // here so a Xenos can't slip a criterion proposal in via raw curl after the
  // skill itself refuses to run for them.
  router.post('/inbox', api.requireBuilder, async (req, res) => {
    if (validateOrRespond(req, res, {
      title: { required: true, type: 'string', maxLength: LIMITS.TITLE, minLength: 1 },
      body_md: { type: 'string', maxLength: LIMITS.DESCRIPTION },
      kind: { type: 'string', maxLength: 64 },
      suggested_version: { type: 'string', maxLength: 64 },
      suggested_priority: { type: 'integer', min: 0, max: 100 },
    })) return;
    const body = req.body || {};
    if (body.kind === 'criterion-proposal') {
      const rank = (req.builder?.rank || '').toLowerCase();
      if (rank && rank !== 'metic' && rank !== 'archon') {
        return res.fail('rank_forbidden', 403, { required: ['metic', 'archon'], actual: rank, reason: "kind='criterion-proposal' is a planning-session write; Metic+ only." });
      }
    }
    try {
      const idea = await inbox.captureIdea({
        title: body.title,
        bodyMd: body.body_md ?? '',
        kind: body.kind ?? null,
        suggestedVersion: body.suggested_version ?? null,
        suggestedPriority: body.suggested_priority ?? null,
        capturedBy: req.builder.id,
      });
      const open_count = await inbox.countOpenIdeas({ viewerRank: req.builder?.rank ?? null });
      res.status(201).json({ idea, open_count, kind_auto: !body.kind });
    } catch (err) {
      if (err && err.code) {
        const status =
          err.code === 'TITLE_REQUIRED' ? 400 :
          err.code === 'BAD_KIND' ? 400 :
          err.code === 'BAD_PRIORITY' ? 400 :
          500;
        return res.fail(err.code, status, { ...err });
      }
      console.error('[gds] POST /inbox', err);
      res.fail('capture_failed', { status: 500, message: 'internal error' });
    }
  });

  // rank: any-builder — read open ideas; skill-friction rows filtered by viewer rank.
  router.get('/inbox', api.requireBuilder, async (req, res) => {
    const { kind, limit } = req.query;
    const limitNum = Number(limit);
    // Number.isFinite guard: a non-numeric ?limit (e.g. "abc") → NaN, which the
    // listOpenIdeas({limit=50}) default does NOT catch (defaults fire only on
    // undefined), so NaN would reach the SQL LIMIT and 500. Fall back to 50.
    const parsedLimit = limit && Number.isFinite(limitNum) ? Math.max(1, Math.min(500, limitNum)) : 50;
    try {
      // Pass the viewer's rank so the skill-friction visibility gate (V3.R70)
      // is live: Xenos-rank builders don't see [skill-friction] rows. The
      // builders.rank column is populated (V3.R04), so req.builder.rank gates
      // for real here; a null rank (unknown/pre-R04 row) still sees everything.
      const viewerRank = req.builder?.rank ?? null;
      const ideas = await inbox.listOpenIdeas({
        kind: kind || null,
        limit: parsedLimit,
        viewerRank,
      });
      // Count under the same gate so open_count matches the rows the viewer can
      // actually see — a Xenos must not be told there are more open ideas than
      // their filtered list shows.
      const open_count = await inbox.countOpenIdeas({ viewerRank });
      res.json({ ideas, open_count });
    } catch (err) {
      console.error('[gds] GET /inbox', err);
      res.fail('list_failed', { status: 500, message: 'internal error' });
    }
  });

  // rank: any-builder — single idea read for the "#NNN" deep-link resolver
  // (#1047). Mirrors GET /blockers/:id. The hall resolves /#/idea/N by id, but
  // the /inbox LIST returns only the open-first-50, so a closed/older idea ref
  // would dead-end at a "no such idea" card. getIdea() reads any idea by id.
  // Authed: a logged-out resolve hits the hall's softAuth "sign in" card, so no
  // idea text is exposed publicly (the linked refs are public, the bodies aren't).
  router.get('/inbox/:id', api.requireBuilder, async (req, res) => {
    const id = parseId(req, res, { code: 'bad_id', positiveInt: true });
    if (id === null) return;
    try {
      const idea = await inbox.getIdea(id);
      if (!idea) return res.fail('idea_not_found', 404);
      res.json({ idea });
    } catch (err) {
      console.error('[gds] GET /inbox/:id', err);
      res.fail('idea_read_failed', { status: 500, message: 'internal error' });
    }
  });

  // Metic+ (#360 / ADR 0018): idea triage (promote/discard/merge) shapes the
  // backlog. Criterion C2 assigns triage to Metic, so this widened from
  // archon-only to metic+archon when the three-rank model went live. Any
  // builder can still FILE an idea (POST /inbox above); a Xenos cannot triage.
  // rank: metic+archon — idea triage shapes the backlog; criterion C2 / #360 / ADR 0018.
  router.patch('/inbox/:id', api.requireBuilder, api.requireRank('metic', 'archon'), async (req, res) => {
    if (validateOrRespond(req, res, {
      // Enum kept light — inbox.updateIdea returns a structured BAD_STATUS
      // error if the value falls outside the accepted set, and the supervisor
      // doesn't hit this endpoint, so we're free to be strict.
      status: { type: 'string', enum: INBOX_STATUS_VALUES },
      kind: { type: 'string', maxLength: 64 },
      promoted_to_task_id: { type: 'integer', min: 1 },
      // reviewed_at accepts ISO string OR null OR numeric timestamp — type
      // check stays open (declared untyped so strict-mode accepts it); the
      // inline `new Date()` parse handles the rest.
      reviewed_at: {},
    })) return;
    const id = parseId(req, res, { code: 'bad_id' });
    if (id === null) return;
    const body = req.body || {};
    const patch = {};
    if (body.status !== undefined) patch.status = body.status;
    if (body.kind !== undefined) patch.kind = body.kind;
    if (body.promoted_to_task_id !== undefined) patch.promoted_to_task_id = body.promoted_to_task_id;
    if (body.reviewed_at !== undefined) {
      const d = body.reviewed_at ? new Date(body.reviewed_at) : null;
      if (d && Number.isNaN(d.getTime())) {
        return res.fail('bad_reviewed_at', 400);
      }
      patch.reviewed_at = d;
    } else if (body.status !== undefined && body.status !== 'open') {
      // Auto-stamp on transition to a terminal status (promoted, discarded,
      // merged). Lets callers PATCH without bookkeeping the timestamp.
      patch.reviewed_at = new Date();
    }
    try {
      const idea = await inbox.updateIdea(id, patch);
      res.json({ idea });
    } catch (err) {
      if (err && err.code) {
        const status =
          err.code === 'IDEA_NOT_FOUND' ? 404 :
          err.code === 'BAD_STATUS' ? 400 :
          err.code === 'BAD_KIND' ? 400 :
          500;
        return res.fail(err.code, status, { ...err });
      }
      console.error('[gds] PATCH /inbox/:id', err);
      res.fail('update_failed', { status: 500, message: 'internal error' });
    }
  });

  // V3.R31 (#252) — Archon ratifies a criterion-proposal idea, atomically:
  //   - INSERT done_when_criteria row on the target version
  //   - UPDATE idea_inbox SET status='promoted', reviewed_at=now()
  //   - INSERT karma_log (delta=+3, reason='proposal_ratified') for proposer
  //     (V3.R28 / #248 tuned the delta from +5 → +3; tunable.)
  //   - INSERT criterion_proposal_audit row capturing who/when/what
  //
  // Archon-only — done_when_criteria writes are scope-shaping (criterion C2
  // in canonical-permissions.md). The kind='criterion-proposal' POST is
  // Metic+ (gated above), but the ratification is the Archon decision.
  //
  // Returns 400 if the source idea isn't kind='criterion-proposal' or its
  // body_md isn't a parseable {target_version, criterion_md, sort_order_hint}
  // JSON object. Returns 404 if the idea doesn't exist. Returns 409 if the
  // idea is already promoted/discarded/merged (status != 'open'). All four
  // writes happen in one transaction — partial failures roll back cleanly.
  router.post(
    '/inbox/:id/ratify',
    api.requireBuilder,
    api.requireRank('archon'),
    async (req, res) => {
      const id = parseId(req, res, { code: 'bad_id' });
      if (id === null) return;
      const notes = (req.body && typeof req.body.notes_md === 'string') ? req.body.notes_md : '';
      try {
        const result = await inbox.ratifyCriterionProposal(id, req.builder.id, {
          notesMd: notes,
        });
        res.status(201).json({ ok: true, ...result });
      } catch (err) {
        if (err && err.code) {
          const status =
            err.code === 'IDEA_NOT_FOUND' ? 404 :
            err.code === 'WRONG_KIND' ? 400 :
            err.code === 'IDEA_NOT_OPEN' ? 409 :
            err.code === 'BAD_BODY' ? 400 :
            err.code === 'BAD_ID' ? 400 :
            err.code === 'VERSION_NOT_FOUND' ? 400 :
            500;
          return res.fail(err.code, status, { ...err });
        }
        // Surface unique-constraint trip on (version_id, criterion_id) as a 409.
        if (err && err.code === '23505') {
          return res.fail('CRITERION_ALREADY_RATIFIED', 409, { detail: 'A criterion with this proposal ref already exists on the target version.' });
        }
        console.error('[gds] POST /inbox/:id/ratify', err);
        res.fail('ratify_failed', { status: 500, message: 'internal error' });
      }
    }
  );

  return router;
};
