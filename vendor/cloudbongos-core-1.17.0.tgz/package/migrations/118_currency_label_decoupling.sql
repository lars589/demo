-- Migration 118 — document that the currency COLUMN NAMES are decoupled from the
-- configurable display LABEL (R56 / task 1195, ADR 0062 §3).
--
-- R56 makes the reward unit's *display label* instance config (branding.currency.label;
-- OTB = "drachmae", the neutral starter = "credits"), resolved at render time. The DB
-- COLUMN NAMES below keep the historical "drachmae" stem ON PURPOSE — they are fixed
-- schema identifiers, NOT user-facing copy. Renaming them would churn every query +
-- the wire field names the front-end reads, and — for token_reward_drachmae — risks
-- disturbing the migration-091 idempotency key (credit_log uniqueness on
-- reason='session.token_reward'). The cost-plus reward MATH is unchanged by R56.
--
-- These COMMENTs are the durable signpost so a future builder doesn't "tidy" the
-- column names to match a re-branded label and break the ledger. Metadata-only +
-- idempotent (COMMENT ON overwrites); changes no data and no behaviour.

COMMENT ON COLUMN session_records.drachmae_earned IS
  'Reward earned for the session, in the instance reward unit. FIXED identifier — the user-facing unit LABEL is config (branding.currency.label, R56/task 1195); do not rename to match a re-branded label.';

COMMENT ON COLUMN session_records.token_reward_drachmae IS
  'Per-session token reward (cost-plus, ADR 0054), in the instance reward unit. FIXED identifier — display label is config (R56). Do NOT rename: the migration-091 idempotency key (credit_log reason=''session.token_reward'') and the reward math depend on this column.';

COMMENT ON COLUMN vulnerability_reports.drachmae_awarded IS
  'Bounty paid for a confirmed report, in the instance reward unit. FIXED identifier — the user-facing unit LABEL is config (branding.currency.label, R56/task 1195); do not rename to match a re-branded label.';
