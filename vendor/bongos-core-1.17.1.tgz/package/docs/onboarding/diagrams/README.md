# How the GDS works — visual diagrams

Five flowcharts that explain the Game Development System (GDS) to a new builder at a glance. Each diagram is committed as **Mermaid source** (`.mmd`) plus a rendered **`.svg`** (the crisp, pannable/zoomable asset) and **`.png`** (a static fallback / external-embed image), embedded in the `/builders` hall at `/builders/diagrams` and the builder primer ([V3.R13 / #237](../../../CLAUDE.md)). On those pages the diagrams are **pan-and-zoom canvases** (drag to pan, scroll to zoom, fullscreen) — see [`modules/hall-ui/public/diagram-viewer.js`](../../../modules/hall-ui/public/diagram-viewer.js).

> Built under **V3.R76 ([#295](https://example.com/builders#/task/295))**; auto-regeneration + drift detection added under **[#356](https://example.com/builders#/task/356)/[#357](https://example.com/builders#/task/357)**; conceptual diagrams (03/04) made auto-generated under **[#436](https://example.com/builders#/task/436)**; a dev-box topology diagram (06) added under **[#1031](https://example.com/builders#/task/1031)** and then **merged with 04 into the single `04-architecture` map + SVG pan/zoom viewer under [#1059](https://example.com/builders#/task/1059)**.

### Auto-generated vs hand-authored (important)

**All five diagrams are now AUTO-GENERATED** from live facts by [`scripts/gds/gen-diagrams.js`](../../../scripts/gds/gen-diagrams.js). **Do not hand-edit any `.mmd`** — to change *layout/wording*, edit the matching template in `gen-diagrams.js`; to change *state*, change the underlying system and it regenerates.

| Diagram | What drives its state |
|---|---|
| `01-task-lifecycle` · `02-rank-ladder` · `05-versioning` (**mechanical**) | The task-status set + rank enum/wiring (read from `migrations/` + `src/bongos/`) and the live version set (production API). No auth needed — always regenerate. |
| `03-drachmae-karma` · `04-architecture` (**conceptual**) | Each feature-piece is **LIVE iff its backing GDS task is `shipped`**, plus 03's "N seeded" count from the achievements seed in `migrations/`. These read the **authenticated** `/tasks/:id` status, so when no GDS session is available (headless run, no creds) the generator **skips** 03/04 and leaves them untouched rather than emit wrong data. (04's device/box/server/GitHub *topology* is structural; only its LIVE/PLANNED markers — the memory chain + the box→prod ship-flow legs — are task-gated.) |

The mechanical diagrams regenerate **on every deploy** (`ship.js` / `/merge-mode` run `gen-diagrams.js` before deploying; a changed diagram is committed and shipped automatically). The conceptual diagrams regenerate the same way whenever a session is present (the deploy host has one). The `diagram-drift` routine remains as a belt-and-braces backstop. So `/builders/diagrams` is never more than one deploy behind the live architecture.

## Reading the diagrams — live vs planned

The GDS is mid-build. These diagrams deliberately distinguish **what exists today** from **what GDS-V3 plans to add**, so they double as a "where are we at" snapshot:

| Marker | Meaning |
|---|---|
| **LIVE** / solid box / solid arrow | Implemented and enforced right now |
| **PLANNED** / dashed arrow / "PLANNED: R##" | Designed and task-tracked, not yet built (the `R##` is the GDS-V3 task) |
| `○` reserved | An enum value that exists in schema but has no behavior wired to it yet |

## The five diagrams

### 1. Task lifecycle — backlog → shipped
How a task moves from creation to production, and the exact edge where **credits/drachmae are awarded** (`completed → confirmed`, *not* at ship).

![Task lifecycle](01-task-lifecycle.png)

Source: [`01-task-lifecycle.mmd`](01-task-lifecycle.mmd)

### 2. Builder rank ladder
The 16-value reserved rank enum (migration 023) in three Greek bands, which ranks are **live today** (`archon` + `thetes`, plus `xenos` on exit), the GDS-V3 target of three write-gating ranks (Xenos / Metic / Archon), and the server-enforced permissions per rank ([ADR 0016](../../adr/<redacted>.md)).

![Rank ladder](02-rank-ladder.png)

Source: [`02-rank-ladder.mmd`](02-rank-ladder.mmd)

### 3. Drachmae & karma — sourcing and spending
Where each comes from and where each goes. Key facts: **drachmae = credits** (same thing, in-world name), they are **equity, not a spendable currency**, and the **primary source is now a cost-plus reward on each shipped session** — `round(true_cost × 1.20)` ([ADR 0054](../../adr/<redacted>.md)) — alongside per-task `credits_reward × kind multiplier` ([ADR 0023](../../adr/<redacted>.md)), achievements, and the (rate-card-live) security bounty. Karma is a separate peer-trust signal that does **not** gate rank promotions; its LIVE/PLANNED state tracks its backing tasks (R25/R32/R26). The full write-up is [`docs/onboarding/drachmae-and-karma.md`](../drachmae-and-karma.md).

![Drachmae and karma](03-drachmae-karma.png)

Source: [`03-drachmae-karma.mmd`](03-drachmae-karma.mmd)

### 4. The complete architecture — where your work runs and how code reaches production
One map of the whole system, merging the old "server ↔ repo ↔ memory" three-layer view with the dev-box → production ship flow. The four places Claude Code splits across — your **device** (screen only) · the **dev box** (the worker, the code, *and* your local memory dir) · the **server/droplet** (authority *and* production: Postgres, the server-side memory store, the push credential) · **GitHub** (branch-protected main + Actions) — plus two flows woven through it: the **per-builder memory layer** (ADR 0024 — local ↔ server, sync-on-ship / pull-on-start) and the **box → prod ship path** (a credential-less box re-auths and uploads its branch as a git bundle; the server pushes it with a GitHub App credential; the PR auto-merges and GitHub Actions deploys — no droplet key on any box). Every feature-piece + flow edge is LIVE/solid iff its backing task is `shipped`. Backing tasks: memory chain [#273](https://example.com/builders#/task/273)–[#276](https://example.com/builders#/task/276); dev box [#904](https://example.com/builders#/task/904)/[#774](https://example.com/builders#/task/774)/[#897](https://example.com/builders#/task/897)/[#919](https://example.com/builders#/task/919); box→prod [#1025](https://example.com/builders#/task/1025)/[#859](https://example.com/builders#/task/859)/[#1028](https://example.com/builders#/task/1028)/[#1027](https://example.com/builders#/task/1027) (all shipped → the map reads all-LIVE today). See [ADR 0024](../../adr/<redacted>.md) (cloneable memory), [ADR 0055](../../adr/<redacted>.md) (server-mediated publish), [ADR 0053](../../adr/0053-scoped-dev-box-session.md) (scoped box token), [ADR 0042](../../adr/<redacted>.md) (CI self-deploy), [ADR 0016](../../adr/<redacted>.md) (trust boundary).

![The complete architecture](04-architecture.png)

Source: [`04-architecture.mmd`](04-architecture.mmd) (the `/builders` hall serves the `.svg` for crisp pan/zoom; this PNG is the GitHub-render fallback)

### 5. Versioning + planning sessions
How a `/planning-session` seeds a version's task pool, and the close → archive → guided-review loop. Each version is a named scope milestone — some user-facing (V1, V2, V3), some improving the dev system (the platform versions).

![Versioning](05-versioning.png)

Source: [`05-versioning.mmd`](05-versioning.mmd)

## Where builders see these

The diagrams are surfaced inside the authenticated **builders' hall** at
[`/builders/diagrams`](https://example.com/builders/diagrams) (linked from the hall home page) and inlined in the primer. `modules/hall-ui/public/diagrams.html` references each diagram's `.png`, and [`diagram-viewer.js`](../../../modules/hall-ui/public/diagram-viewer.js) progressively enhances it: it fetches the matching `.svg`, injects it inline, and turns it into a pan-and-zoom canvas (drag to pan, scroll to zoom, fullscreen). If the SVG can't be fetched it falls back to the static PNG. `server.js` serves `docs/onboarding/diagrams/` at `/builders/diagrams/` (both `.svg` and `.png`), so there's a single source of truth and no duplicated binaries.

## Staying current (auto-update)

Two mechanisms keep these honest as the system changes (added under [#356](https://example.com/builders#/task/356)):

1. **Render-on-deploy** — all five diagrams auto-regenerate on deploy: `scripts/gds/gen-diagrams.js` re-renders every `.mmd` to its `.svg` + `.png` and rebuilds `assertions.json` in lockstep, so the committed images never drift from their source. (Do **not** hand-edit the `.mmd`/`.svg`/`.png`/`assertions.json` — edit the template in `gen-diagrams.js` and re-run it.)
2. **Drift detection** — the `diagram-drift` scheduled task (`.claude/scheduled-tasks/diagram-drift/`) runs a deterministic checker that compares `assertions.json` (below) against the live DB/code. Since all five diagrams auto-regenerate on deploy, this is a **belt-and-braces backstop** (it should find nothing in normal operation); on divergence it files an `idea_inbox` entry. Run it manually any time:
   ```bash
   node .claude/scheduled-tasks/diagram-drift/check.js          # report only
   node .claude/scheduled-tasks/diagram-drift/check.js --file-idea
   ```

`assertions.json` is the machine-readable record of what these diagrams claim about the live system (rank enum + wired ranks, task-status set, live versions, and the conceptual `architecture` + `drachmae_karma` piece→task slices). It is **rebuilt by `gen-diagrams.js` in lockstep with the diagrams**, so you no longer hand-maintain it; it stays as the drift checker's reference.

## Regenerating the diagrams by hand

When the system changes, edit the `.mmd` source and re-render. No global install needed (uses `npx`); the convenience script renders all sources or a given subset to **both `.svg` and `.png`**:

```bash
scripts/render-diagrams.sh                        # render every *.mmd here
scripts/render-diagrams.sh docs/onboarding/diagrams/02-rank-ladder.mmd   # just one
```

The first run downloads a headless Chromium (one-time, ~minutes). Avoid `[]` in node labels — the renderer's font shows it as a missing-glyph box; write "dependencies" / "touches" instead.

When a **PLANNED** item ships, you do **not** hand-edit anything: the next `gen-diagrams.js` run (on deploy, or manually) re-reads the backing task's status, flips its marker to **LIVE**, rebuilds `assertions.json`, and re-renders. This applies to all five diagrams now, including 03/04. If you want to change layout/wording, edit the template in `gen-diagrams.js` (not the `.mmd`).
