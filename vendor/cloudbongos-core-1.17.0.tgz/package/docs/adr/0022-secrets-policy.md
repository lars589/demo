# ADR 0022 — Secrets policy

**Date:** 2026-05-28
**Context:** Task [#279](https://example.com/builders#/task/279) (V3.R60), GDS-V3 criterion C8. Builds on the pre-commit hook + CI scan shipped by [#257](https://example.com/builders#/task/257) (V3.R36) and pairs with [ADR 0020](<redacted>.md) (security model — public stub) and [ADR 0016](<redacted>.md) (trust boundary). Companion to [`docs/security-baseline.md`](../security-baseline.md) item 6.
**Status:** Accepted.

## Problem

A secret committed to a public repo is a credential someone else can use within minutes — even after a force-push to remove it, the value survives in forks, GitHub's commit cache, and any clone made between the commit and the removal. The right model is **defense in depth**: each layer assumes the next one will fail.

We already have parts of this:

- Pre-commit hook in `.husky/pre-commit` blocks the obvious shapes locally.
- `.github/workflows/secrets-scan.yml` re-scans full history in CI on every PR.
- `.gitignore` lists `.env.local`.
- Live credentials resolve from `/etc/example/` on the droplet or `~/.config/otb/env` on builder laptops — neither path is tracked.

What's missing — and what this ADR adds — is a written **policy** that defines:

1. What counts as a secret (so the scan can be tuned).
2. Where secrets are allowed to live (so a builder spinning up a fresh worktree knows the recipe).
3. How rotation works (so a leak is recoverable, not catastrophic).
4. What to do when a hit is found (so the response is mechanical, not improvised).

Without this document, every new builder reinvents the answers. Some answers will be wrong.

## Decision

This ADR is **the policy**. The pre-commit hook + the CI workflow are the **enforcement**. The `docs/security-baseline.md` check is the **assertion that both still exist**. Each layer is independently maintained but consistent with this document.

## What counts as a secret

A "secret" for the purposes of this policy is any string that, if disclosed, would let an attacker act on behalf of the project or a builder.

**In scope** (the scan looks for these shapes; treat any leak as a credential compromise):

- GitHub Personal Access Tokens (`ghp_`, `gho_`, `ghu_`, `ghs_`, `ghr_`)
- GitHub OAuth client secrets (40-char hex)
- AWS access key IDs (`AKIA…` + the matching secret on the same line or nearby)
- Google API keys (`AIza…` + 35 chars), Google service-account JSON bodies (look for `"private_key": "<redacted> PRIVATE KEY"`)
- Slack tokens (`xoxa-`, `xoxb-`, `xoxp-`, `xoxr-`, `xoxs-`)
- Stripe live + test secret keys (`sk_live_`, `sk_test_`)
- Any RSA / EC / DSA / Ed25519 private key (`-----BEGIN … PRIVATE KEY-----`)
- TLS private keys (`-----BEGIN PRIVATE KEY-----`)
- Cloudflare Origin Certificate private halves (lives on droplet only — see [ADR 0003](<redacted>.md))
- Postgres passwords (if peer-auth ever gets replaced with password auth — see [`docs/recipes/ops-gotchas.md`](../recipes/ops-gotchas.md) for the current peer-auth setup)
- GDS session bearer tokens (any value of `gds_session` / `pms_session`)

**Out of scope** (these are *config*, not secrets — they may live in the repo):

- Public URLs, droplet IP `REDACTED_IP` (it's the A record's target — already published)
- Cloudflare zone IDs, GitHub OAuth Client *IDs* (the matching *secret* is in scope)
- Postgres database / user names (`example`, the deploy user), CORS-allowed origins
- Public Stripe publishable keys (`pk_live_…`, `pk_test_…`) — these are *meant* to ship in client code

## Where secrets are allowed to live

Three lanes, each with explicit access controls. **Nothing else** is sanctioned; if a fourth lane appears, this ADR is the bug.

| Lane | Path | Tracked? | Permissions | Used by |
|---|---|---|---|---|
| Droplet long-lived | `/etc/example/secrets.env` (chmod 600, owned by `lars`) | no — outside the repo | only the `lars` user + root | systemd service file sources it before exec |
| Droplet rotating | `/etc/example/secrets/<name>` (chmod 600, per-secret file) | no | only the `lars` user + root | individual services that read one file at startup |
| Builder laptop | `~/.config/otb/env` AND `.env.local` (gitignored, lives at the repo root in the main checkout and copies into worktrees on session start) | no — explicitly gitignored | the builder's macOS user account | `art/pipeline/gen_api.py` reads `~/.config/otb/env`; everything else reads `.env.local` |

> **Multi-line secrets (e.g. a GitHub App private key, PEM).** Store in the droplet long-lived lane as a single line with literal `\n` escapes — `GITHUB_APP_PRIVATE_KEY="<redacted>"` — and the reader restores the newlines (`src/bongos/github-push.js normalizePem`). The GitHub App credential for server-mediated publish (`GITHUB_APP_ID` + `GITHUB_APP_INSTALLATION_ID` + `GITHUB_APP_PRIVATE_KEY`, [ADR 0055](<redacted>.md) / task 1028) lives here alongside the `GITHUB_PUSH_TOKEN` PAT it replaces.

Notably **not allowed**:

- Anywhere under the repo root that is not gitignored.
- A "convenience" copy on the droplet outside `/etc/example/`.
- An environment variable exported in a builder's `.zshrc` (it ends up in shell history; it isn't auditable).
- Cloud "secrets managers" (AWS Secrets Manager, GCP Secret Manager, 1Password Connect, etc.) — out of budget for a $5K/year project and adds a single point of failure that's not worth it at this scale.

## How rotation works

When a credential is rotated — either because we found a leak or because the credential is reaching its TTL — the operation is:

1. **Generate the new credential** at the issuing service (GitHub, Google, Stripe, Cloudflare, etc.).
2. **Update the droplet** — `ssh lars@REDACTED_IP`, edit `/etc/example/secrets.env` (or the per-secret file), restart the affected service. Time gap: ≤ 5 minutes.
3. **Update each builder laptop's local copy** — Lars notifies the team (chat broadcast or in-person); builders update `~/.config/otb/env` or `.env.local`. Builders who don't update can't run pipelines that need the rotated credential; they'll discover this when their next `art/` run fails.
4. **Revoke the old credential** at the issuing service. Do this AFTER step 2; the brief overlap is intentional so a slow-rolling service catches both keys.
5. **Log the rotation** — a one-line entry to [`docs/recipes/ops-gotchas.md`](../recipes/ops-gotchas.md) (date + which credential + why), so the next builder spinning up knows what changed when.

GDS session tokens rotate automatically — they're 30-day-TTL, refresh-on-use, revocable per session or per builder (migration `<redacted>.sql`, ADR-aligned with [ADR 0016](<redacted>.md)). No manual rotation needed for those except in a leak scenario, which falls under "What to do on a hit" below.

## What to do when the scan finds a hit

If `.husky/pre-commit` blocks a commit, OR `.github/workflows/secrets-scan.yml` fails on a PR, OR a one-off TruffleHog run finds a hit in history, OR `scripts/gds/security-baseline-check.sh` item 6 flips to FAIL:

1. **Stop**. Do not push, do not merge, do not delete the offending file from the working tree (yet).
2. **Identify the credential** — what service, what scope, was it ever active in production.
3. **Rotate the credential first** (steps 1-4 above). Treat the leaked value as compromised even if the scan was a pre-commit catch — the same value may have been pasted into a chat or a sibling file.
4. **Then** rewrite the offending file (remove the credential) and commit. If the credential was already in pushed history, run `git filter-repo --replace-text <pattern>` to scrub it from every commit. This rewrites SHAs; force-push is required; CI scan re-validates afterward.
5. **Document** — add an entry to [`docs/recipes/ops-gotchas.md`](../recipes/ops-gotchas.md) with the date, what happened, and what changed in the response so the next time it goes faster.
6. **Forks + clones** — the rewrite doesn't reach existing clones. Anyone with an outdated clone gets a `git fetch` warning about non-fast-forward; they re-clone. Forks that mirror via GitHub's mirror feature need a manual `git push --force` from the upstream-aware operator.

The cost of skipping step 3 is "the leaked credential keeps being a leaked credential, just out of sight." The cost of skipping step 5 is "next time, this is a 20-minute incident again."

## Historical sweep

A one-time scan of the full git history happened as part of this ADR (V3.R60, 2026-05-28). The repo was scanned for all in-scope secret shapes; **no hits were found**. The scan was performed with built-in tooling (`git rev-list --all --objects` piped through pattern grep) rather than TruffleHog because trufflehog was not yet installed on the builder's laptop at scan time and the CI scan covers the trufflehog-shape case continuously. The all-clear is documented here so a future operator doesn't repeat the sweep without cause.

If a future audit *does* find a hit, follow "What to do when the scan finds a hit" above. The all-clear is point-in-time; a credential that lands tomorrow needs the same response.

## Scrubbing secrets OUT of session uploads (the BFG corpus)

The enforcement above keeps secrets out of the **repo**. A second egress exists: the BFG session-inefficiency evaluator ([ADR 0027](<redacted>.md)) uploads a digest of each Claude Code session to the GDS `sessions` corpus. A transcript contains every file read, command output, and pasted value — so the upload path is scrubbed by **the same policy, applied client-side at upload time**, in `scrubSecrets()` (`scripts/gds/ship.js`, used by both `ship.js` and `session-digest.js`).

This scrubber is **transcript-grade** and **recall-first** (task 1003, which also completed the open token-redaction of task 723): a missed secret is a credential compromise, while over-redacting a non-secret in a BFG digest is merely cosmetic, so when in doubt it redacts. Five layers: (1) literal dynamic values — this run's GDS session token + every secret-shaped **env value** (`collectEnvSecrets()`, e.g. the `MAC_*`/`APPLE_*` signing creds, a baked GDS/DO token); (2) multi-line PEM private-key blocks; (3) the in-scope known shapes from this ADR (provider key prefixes, Stripe `sk_`/`rk_`/`whsec_`, our `gds_`/`pms_` tokens, `Authorization`/`Bearer` headers, JWTs, credentialed DSNs, Apple app-specific passwords); (4) recognised-key `key=value` / JSON-field assignments; (5) a **high-entropy catch-all** (`looksHighEntropySecret()`) over base64url/hex runs ≥20 chars — the net for an *unknown* secret shape. The accepted cost of layer 5 is that high-entropy non-secrets (git SHAs, UUIDs, a 40-hex value shape-identical to a GitHub OAuth client secret) are redacted too; the structured BFG metrics that matter (token/turn counts, tool names, error flags) are separate fields and untouched. The planted-secret corpus in `tests/scrubber_corpus.mjs` is the regression gate — every planted secret must be fully redacted, every benign line must survive — and **gates the full-transcript capture task**: capture must not ship until this passes.

This scrubber is now a load-bearing enforcement surface alongside the pre-commit hook + CI scan; a change to the in-scope secret shapes above should update it (and its corpus) too, or the policy and the enforcement will drift.

## Alternatives considered

- **Use a cloud secrets manager.** Rejected: cost (~$0.40/secret-month at AWS), latency (an extra network hop on cold start), single point of failure (the manager being down blocks deploys). At ~10 secrets and one operator, the filesystem-permissions model is cheaper and not meaningfully less secure.
- **Encrypt secrets in the repo (SOPS, git-crypt).** Rejected: shifts the problem from "don't commit the secret" to "don't lose the decryption key." The decryption key has to live somewhere; if it lives in the same repo, we've solved nothing; if it lives outside, we've reinvented the current `/etc/example/` model with extra steps.
- **Skip the pre-commit hook; rely on CI alone.** Rejected: CI catches the leak after the secret has already been pushed to GitHub (where it's now in their cache, even if the PR closes). The pre-commit hook is the fast feedback that prevents the leak from leaving the laptop.

## Consequences

- New builders go through a one-line orientation: "creds live in /etc/example on the droplet, in ~/.config/otb/env or .env.local on your laptop, nowhere else." If they ask "but what if I want to commit one?" — the hook blocks them; if they push past the hook, CI blocks the merge.
- The pre-commit hook + CI workflow + security-baseline-check item 6 are now load-bearing. A change to any of them needs to update this ADR too, or the policy and the enforcement will drift.
- Rotation is the operator's responsibility (Lars). The team is informed via the chat broadcast; there is no automatic distribution of new secrets to builder laptops. This is a deliberate accept-the-friction choice — automatic distribution requires a secrets manager.
