-- 176_promotion_respects_open_blockers.sql — dep-ship auto-promotion must not
-- un-block a task with an open blocker (V4.R15 / task 953, promotes idea 226).
--
-- Bug: the dependency auto-promotion triggers (163) promote a backlog task to
-- 'ready' the moment its full dep set is done. But a task can sit in 'backlog'
-- while ALSO carrying an open blocker link (task_blockers -> blockers, status
-- 'open') — e.g. idea 226: task #859 was backlog + linked to operator-cutover
-- blocker #13; when its deps shipped, promotion flipped it to 'ready'
-- (claimable) and silently bypassed the open blocker. A task waiting on a
-- blocker must stay un-promoted until the blocker resolves (009's
-- blocker-resolve trigger is what should release it, not a dep ship).
--
-- Fix: fold an "no open blocker" check into task_is_fully_unblocked — the shared
-- predicate every promotion trigger (163: ship / criterion-satisfy /
-- goal-achieve) re-checks before flipping backlog -> ready. One CREATE OR
-- REPLACE fixes all three paths and fail-closes any future promotion caller.
-- The blocker check matches the resolve trigger (009): a blocker is "open" iff
-- blockers.status = 'open'; legacy markdown-anchor links (blocker_ref text, no
-- blocker_id row) are not tracked here and behave exactly as before.
--
-- Promotion still only ever flips backlog -> ready, so the AFTER triggers can't
-- recurse. Idempotent: pure CREATE OR REPLACE of the predicate function.

BEGIN;

CREATE OR REPLACE FUNCTION task_is_fully_unblocked(p_task_id bigint)
RETURNS boolean AS $$
  SELECT
    -- (1) no gating dependency edge points at an un-done node …
    NOT EXISTS (
      WITH gating AS (
        SELECT d.to_kind, d.to_id
          FROM dependencies d
          JOIN tasks t ON t.id = p_task_id
         WHERE (d.from_kind = 'task'      AND d.from_id = t.id)
            OR (d.from_kind = 'goal'      AND d.from_id = t.goal_id)
            OR (d.from_kind = 'criterion' AND d.from_id IN (
                  SELECT tc.criterion_id FROM task_criteria tc WHERE tc.task_id = t.id))
      )
      SELECT 1
        FROM gating g
       WHERE NOT (
            (g.to_kind = 'task'      AND EXISTS (SELECT 1 FROM tasks              x WHERE x.id = g.to_id AND x.status = 'shipped'))
         OR (g.to_kind = 'criterion' AND EXISTS (SELECT 1 FROM done_when_criteria x WHERE x.id = g.to_id AND x.satisfied))
         OR (g.to_kind = 'goal'      AND EXISTS (SELECT 1 FROM goals              x WHERE x.id = g.to_id AND x.status = 'achieved'))
       )
    )
    -- … AND (2) the task has no open blocker linked via task_blockers (V4.R15).
    AND NOT EXISTS (
      SELECT 1
        FROM task_blockers tb
        JOIN blockers b ON b.id = tb.blocker_id
       WHERE tb.task_id = p_task_id
         AND b.status = 'open'
    );
$$ LANGUAGE sql STABLE;

COMMIT;
