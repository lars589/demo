// modules/builder-settings/interaction-prefs.js — the per-builder INTERACTION
// PROFILE (task 2010 / BONGOS-V1).
//
// Principle (2026-07-04 review, bullets 85/87/92): there is NO special "owner"
// entity — an owner is just a builder with elevated permissions + a profile. So
// "how to work with me" (the old CLAUDE.md §2 "The Prompter" defaults) is NOT
// portable-core prose; it's a PER-BUILDER profile — tone, technical level, and
// local-toolchain familiarity — captured at onboarding and injected each
// session, exactly like the `wandering` knob (wandering-prefs.js is the sibling
// this mirrors). CLAUDE.md keeps only the PORTABLE DEFAULTS as the fallback.
//
// Storage. One reserved key ('interaction') inside the `behavior_prefs` jsonb
// (migration 119, shared with wandering/sound). Its value is a small object of
// field → chosen value; unset/invalid fields fall back to the field default.
//
// The defaults below are the portable §2 defaults verbatim: assume the reader
// may not be a software engineer, define jargon on first use, treat local
// toolchains as new, frame trade-offs as cost/time/what-the-user-sees, be
// concise. An engineer builder overrides to a more technical profile; the
// injected contract then tells the agent how to pitch its replies for THAT
// builder.

const RESERVED_KEY = 'interaction';

// Each field: allowed values (first = default), a short label per value, and a
// one-line contract fragment injected when the value is NON-default (the default
// already matches the portable baseline, so injecting it would be noise —
// mirrors wandering's `inject` idea).
const FIELDS = {
  technical_level: {
    label: 'Technical level',
    blurb: 'How much software-engineering vocabulary to assume.',
    values: {
      non_technical: {
        label: 'Non-technical (default)',
        // default — matches the portable baseline; not injected.
        contract: '',
      },
      mixed: {
        label: 'Some technical background',
        contract: 'Technical level: mixed — plain language by default, but light SWE vocabulary is fine without defining every term.',
      },
      engineer: {
        label: 'Engineer',
        contract: 'Technical level: engineer — assume software-engineering fluency; skip basic explanations and speak in code/architecture terms.',
      },
    },
  },
  toolchain_familiarity: {
    label: 'Local-toolchain familiarity',
    blurb: 'Whether local dev tools (package managers, ports, env vars) need step-by-step help.',
    values: {
      new: {
        label: 'New to local tooling (default)',
        contract: '',
      },
      comfortable: {
        label: 'Comfortable with local tooling',
        contract: 'Toolchain familiarity: comfortable — no need to walk through local toolchains (Homebrew, ports, env vars) step by step.',
      },
    },
  },
  verbosity: {
    label: 'Reply length',
    blurb: 'How much prose to return by default.',
    values: {
      concise: {
        label: 'Concise (default)',
        contract: '',
      },
      detailed: {
        label: 'Detailed',
        contract: 'Verbosity: detailed — this builder wants fuller explanations and context, not just the short answer.',
      },
    },
  },
};

const FIELD_KEYS = Object.keys(FIELDS);

// The default value for a field is its FIRST declared value.
function defaultValue(field) {
  return Object.keys(FIELDS[field].values)[0];
}

function isValidValue(field, value) {
  return typeof value === 'string' && Object.prototype.hasOwnProperty.call(FIELDS[field].values, value);
}

// The raw stored profile (the `interaction` object off behavior_prefs), sanitized
// to only known fields/values. Unknown keys/values are dropped (not an error —
// the effective profile falls back to defaults).
function storedProfile(behaviorPrefs) {
  const raw = (behaviorPrefs && typeof behaviorPrefs[RESERVED_KEY] === 'object' && behaviorPrefs[RESERVED_KEY]) || {};
  const out = {};
  for (const f of FIELD_KEYS) {
    if (isValidValue(f, raw[f])) out[f] = raw[f];
  }
  return out;
}

// The effective profile: stored override per field, else the field default.
function effectiveProfile(behaviorPrefs) {
  const stored = storedProfile(behaviorPrefs);
  const out = {};
  for (const f of FIELD_KEYS) out[f] = stored[f] || defaultValue(f);
  return out;
}

// The session-injected contract: the non-default fragments joined into one
// paragraph. Empty string when the builder is on all defaults (the portable
// baseline already covers that — nothing to inject).
function contractFor(behaviorPrefs) {
  const eff = effectiveProfile(behaviorPrefs);
  const parts = [];
  for (const f of FIELD_KEYS) {
    const frag = FIELDS[f].values[eff[f]].contract;
    if (frag) parts.push(frag);
  }
  if (!parts.length) return '';
  return 'Interaction profile for this builder — pitch replies accordingly:\n- ' + parts.join('\n- ');
}

function shouldInject(behaviorPrefs) {
  return contractFor(behaviorPrefs) !== '';
}

// The full catalog the /settings UI renders.
function fieldCatalog() {
  return FIELD_KEYS.map((f) => ({
    field: f,
    label: FIELDS[f].label,
    blurb: FIELDS[f].blurb,
    default_value: defaultValue(f),
    values: Object.entries(FIELDS[f].values).map(([value, meta]) => ({ value, label: meta.label })),
  }));
}

// Everything the /me payload + the /settings UI need in one object.
function describeForApi(behaviorPrefs) {
  return {
    fields: fieldCatalog(),
    stored: storedProfile(behaviorPrefs),
    effective: effectiveProfile(behaviorPrefs),
    contract: contractFor(behaviorPrefs),
    inject: shouldInject(behaviorPrefs),
  };
}

// Validate a PATCH body: { <field>: <value> | null }. `null` clears a field
// (fall back to its default). Unknown fields/values → 422. Returns
// { ok, patch } or { ok:false, errors }. The route merges `patch` into the
// stored `interaction` object.
function validatePatch(body) {
  if (body == null || typeof body !== 'object' || Array.isArray(body)) {
    return { ok: false, errors: [{ error: 'body_must_be_object' }] };
  }
  const errors = [];
  const patch = {};
  for (const [key, value] of Object.entries(body)) {
    if (!FIELD_KEYS.includes(key)) {
      errors.push({ error: 'unknown_field', field: key });
      continue;
    }
    if (value === null) { patch[key] = null; continue; }
    if (!isValidValue(key, value)) {
      errors.push({ error: 'bad_value', field: key, allowed: Object.keys(FIELDS[key].values) });
      continue;
    }
    patch[key] = value;
  }
  if (errors.length) return { ok: false, errors };
  return { ok: true, patch };
}

// Merge a validated patch into an existing stored profile (null clears). Pure —
// the route persists the result into behavior_prefs.interaction.
function applyPatch(stored, patch) {
  const next = { ...(stored || {}) };
  for (const [k, v] of Object.entries(patch)) {
    if (v === null) delete next[k];
    else next[k] = v;
  }
  return next;
}

module.exports = {
  RESERVED_KEY,
  FIELDS,
  FIELD_KEYS,
  defaultValue,
  isValidValue,
  storedProfile,
  effectiveProfile,
  contractFor,
  shouldInject,
  fieldCatalog,
  describeForApi,
  validatePatch,
  applyPatch,
};
