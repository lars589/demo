# Drachmae & karma — how you get paid, and how you earn trust

*The complete reference for the two reputation tracks in the GDS. The [primer](primer.md) gives you the one-paragraph version; this is the full picture, kept honest against the live system. ~8 minutes.*

> **Source of truth.** The numbers live in the production database (`builders.total_credits`, `builders.karma`) and the rules live in code (`src/bongos/db.js`, `src/bongos/cost.js`). This doc *describes* them; where they disagree, the code wins. The two diagrams that visualize this — [task lifecycle](diagrams/01-task-lifecycle.png) and [drachmae & karma](diagrams/03-drachmae-karma.png) — are auto-generated from the same live facts.

---

## The 30-second version

- **Drachmae** (the code calls them *credits*) are your **equity** in Off the Boats. You earn them by shipping work, and they only ever go up. They are a score and a stake — **not** a currency you spend on anything in-game.
- The **headline change (June 2026):** most of your drachmae now come from a **cost-plus reward on each shipped session** — we pay you the real API cost of the work you did, **plus 20%**. Expensive, real work pays more than declaring a big number ever did.
- **Karma** is a *separate* signal. It measures **peer trust** — how other trusted builders rate your work — not how much you shipped. It is surfaced on your profile and the leaderboard, and it feeds your "builder strength" score. It is **not** a gate on rank promotions.
- A **monthly budget cap** ($50 by default) limits how much you can *spend*; it's the cost side of the same coin the reward is computed from.

---

## Part 1 — Drachmae (credits)

### What they are

Drachmae are the in-world name for the `total_credits` counter on your builder row. The owner's framing ([ADR 0054](../adr/<redacted>.md)) is that **drachmae are equity** — units of ownership in the thing you're helping build. Practically, today, they are:

- **Append-only.** Every award is a row in `credit_log`; the `total_credits` counter is maintained by a database trigger. History is never rewritten — a correction is a new (sometimes negative) row, never an edit.
- **Persistent across exit.** If you leave and come back, your drachmae are still there (migration 025). They are reputation, not a session balance.
- **Not spendable.** There is no shop, no sink, nothing to buy with them. They are a *score and a stake*. (This may change in a future version; today it does not.)
- **Public.** Your total is visible on the [builders' hall](https://example.com/builders) leaderboard.

### How you earn them

There are several sources. They all land in the same `credit_log` and roll up into one `total_credits` number.

#### 1. The cost-plus session reward — *the main one* ([ADR 0054](../adr/<redacted>.md))

When you **ship** a session, the server looks at the LLM tokens that session actually burned, prices them, and pays you:

```
drachmae = round( true_cost_usd × 1.20 )            // whole drachmae (1 drachma = $1)
                                  └─ REWARD_MARGIN_PCT = 20 (a code constant in src/bongos/db.js)
```

The important details, because they're designed to be fair *and* un-gameable:

- **The cost is computed server-side**, from the per-model token counts your ship uploads (`session_records.model_usage`), priced via the locked list-price table in `src/bongos/llm-pricing.js`. **You never send a dollar figure** — a client can't inflate its own payout.
- **It's the API *list* price, deliberately** — not your discounted subscription cost. If you got those tokens cheaply (e.g. on a flat Claude Code subscription), the spread between list price and what you actually paid is routed to *you* as profit, on top of the 20%. That's intentional: it's how the reward funds your time and your ideas.
- **PASS-gated.** Only a *successful ship* uploads a session record. A session that burned tokens and shipped nothing earns nothing.
- **Idempotent per session.** Re-shipping or retrying the same session is a true no-op — keyed on `session_id`, you can't get paid twice.
- **Reversible.** A bad award is undone with a compensating negative `credit_log` row; the trigger nets it out. History stays intact.

> **Why pay for cost at all — doesn't that reward waste?** It can, and that was accepted on purpose ([ADR 0054](../adr/<redacted>.md)). The guardrails are: you only get paid for sessions that *ship*; drachmae are *equity*, so padding your own cost dilutes a pool you hold (early builders self-police); and the [BFG session-inefficiency evaluator](../adr/<redacted>.md) already flags wasteful sessions, so a future version can discount the reward by an efficiency factor. The stated direction is to move toward market/bidding pricing once there's a real multi-builder pool.

#### 2. Per-task credits, adjusted by *kind* ([ADR 0023](../adr/<redacted>.md))

Every task carries a `credits_reward` an author set when scoping it. When the task is **confirmed** (verification passes — see the [lifecycle](#where-in-the-lifecycle-credits-land)), you're paid that reward **times a multiplier for the kind of work**:

| Kind | × | Why |
|---|---|---|
| `learning-capture` | **1.5** | One captured learning saves many future debugging sessions. |
| `blocker-resolution` | **1.5** | A resolved blocker unblocks every task that depended on it. |
| `decision` (ADRs) | **1.3** | Durable; outlives any single feature. |
| `bug` | **1.2** | Stops compounding failure. |
| `spike` | **1.1** | Produces knowledge (ADRs, follow-ups). |
| `feature` / `infra` / `unclassified` | **1.0** | The baseline. |
| `refactor` | **0.9** | Useful as a precursor; dead weight otherwise. |
| `cleanup` | **0.8** | Necessary housekeeping, but not what we want more of right now. |

The math is written inline into the `credit_log` row (e.g. `40c × 1.5 = 60c (learning-capture)`) so an auditor can reconstruct any payout. The multipliers live in a *frozen constant* in `src/bongos/db.js` on purpose — changing them takes a code review and commit, not a quiet DB edit.

#### 3. The idea-promotion bonus ([ADR 0023](../adr/<redacted>.md))

If you **captured an idea** that later became a task, and **someone else ships it**, you get **25% of that task's (multiplier-adjusted) reward** — paid as a separate `idea_promotion_bonus` row, *on top of* what the shipper earns (it isn't deducted from them). No bonus if you ship your own idea (you already got the full reward). Capturing good ideas is real, paid work.

#### 4. Achievements

Unlocking an achievement pays its `credit_bonus`. There are **9 seeded** today (e.g. your first ship, three ships, a *net-negative* ship that deletes more than it adds). They're small, one-time, and motivational.

#### 5. The net-negative ship bonus

A ship whose committed diff **removes more lines than it adds** earns a small `ship.net_negative` bonus — a nudge toward deleting code, not just adding it.

#### 6. Red-team / security bounty *(rate card live; awarding still landing)*

There's a published payout rate-card by severity for red-team / security findings (shown on the hall, `src/bongos/security.js`). The **automatic** drachmae payout for a filed-and-confirmed vulnerability is still being wired up (tracked by [#286](https://example.com/builders#/task/286) + [#282](https://example.com/builders#/task/282)); the rates are real, the auto-pay isn't switched on yet.

### Where in the lifecycle credits land

Drachmae are awarded at the **`completed → confirmed`** edge — when verification (smoke tests, and the grader when it's enabled) passes — **not** at the final ship/deploy. Releasing a task with `/builder-release` pays nothing.

```
active ──▶ completed ──▶ confirmed ──▶ shipped
           (declared      (verified —    (merged to main
            done +          CREDITS        + deployed)
            smoke)          LAND HERE)
```

> **Note:** the old up-front `touches[]` *drift scanner* that used to run at ship time is **gone** (task [#879](https://example.com/builders#/task/879), [ADR 0049](../adr/<redacted>.md)). The ship gate is **smoke tests only**; `git merge` at land time is the real collision detector.

### One honest caveat: a drachma means two things

We knowingly run two conventions on the same ledger ([ADR 0054](../adr/<redacted>.md)): a *unitless author estimate* (the per-task path) and a *whole-dollar drachma of real cost + 20%* (the session-reward path). That inconsistency is a deliberate MVP trade-off, recorded so it's a known decision and not a latent bug. A future version may reconcile them.

---

## Part 2 — The monthly budget cap (the cost side)

Drachmae are what you *earn*; the budget cap limits what you *spend*. They're linked, because the reward is computed from the same true cost the cap meters.

Defined in `src/bongos/cost.js` (criterion C3, [#302](https://example.com/builders#/task/302)):

Builders are **uncapped by default** ([ADR 0085](../adr/<redacted>.md)) — your month-to-date spend is tracked and shown, but it never blocks you. An Archon can set a per-builder cap as a manual brake; **when a cap is set**, these levels apply:

| Month-to-date spend | Level | What happens |
|---|---|---|
| no cap set (the default) | `ok` | nothing — uncapped |
| under 80% of the cap | `ok` | nothing |
| **≥ 80%** | `warn` | a CLI ping at session start + a banner on the hall |
| **≥ 100%** | `over` | **hard refuse** — `/builder-ship` and the art pipeline stop |

- **No default cap.** `monthly_budget_usd` is unset for most builders, which means uncapped. The MTD figure still resets at the start of each calendar month.
- A cap, when set, is there to **catch a runaway**, not to ration normal work — the **$50 default was removed** ([ADR 0085](../adr/<redacted>.md)) because a new builder's own session cost crossed it within a day or two, freezing the very work it was meant to enable.
- An **Archon** can set or clear a specific builder's ceiling (`PATCH /api/gds/builders/:id/budget`); clearing it (`null`) returns the builder to uncapped.

If a cap is set and you hit `over`, you're not in trouble — you've just reached the month's ceiling. Ask an Archon to raise or clear it if the work justifies it.

---

## Part 3 — Karma

Karma (added in migration 040) is a **completely separate** counter from drachmae. Where drachmae measure *output* (work shipped), karma measures **peer trust** — how other builders, and the project's good-citizenship signals, rate the *way* you work.

### How karma is earned (and lost)

- **Peer votes on confirmed work.** Builders upvote/downvote each other's confirmed tasks. Only **Metic-and-above** can cast a vote (`POST /api/gds/tasks/:id/vote` is rank-gated). Votes are **tallied weekly** into one net `peer_vote_weekly` karma entry per builder. There's an **anti-self-vote** guard and an anti-retaliation rule (a downvote can't dent your karma within the same week).
- **Proposal ratification.** When a criterion-proposal you made is ratified, you get **+3 karma** (`proposal_ratified`).
- **Idea promotion.** Promoting an idea into a real task awards karma to the capturer.
- **It can go down.** The [BFG](../adr/<redacted>.md) good-citizenship corrections can apply a *non-positive* karma delta. Karma is a slower, more reflective signal than drachmae — you can ship fast and still lose karma if you break things.

> Discord cheers don't count. Reaction "applause" in Discord is cosmetic and **never** mints karma — only rank-gated peer votes do ([ADR 0033](../adr/<redacted>.md)). Unranked enthusiasm can't manufacture trust.

### Where karma shows up

- **Your profile card** on the hall shows your karma and its **30-day trend**, plus your recent karma feed (last 10 entries).
- **The leaderboard** is sortable by karma (it still defaults to drachmae order).
- **Builder strength.** Karma is one input (weight ~0.15) into the BFG's 0–100 "builder strength" score (`src/bongos/bfg.js`), alongside ship volume, grader pass-rate, and reliability.

### What karma is *not*

Karma does **not** mechanically gate rank promotions. The two promotions that exist are:

- **Xenos → Thetes:** automatic after your **3rd confirmed task** — by ship count, not karma.
- **→ Metic** and **→ Archon:** deliberate **Archon** decisions.

Karma is evidence an Archon *can weigh* when deciding a discretionary promotion, but no threshold of karma promotes you on its own. (See the [rank ladder](primer.md#the-rank-ladder).)

---

## Drachmae vs karma, side by side

| | **Drachmae** (credits) | **Karma** |
|---|---|---|
| Measures | Output — work shipped | Peer trust — how others rate your work |
| Earned by | Shipping (cost-plus reward, per-task credits, bonuses) | Metic+ peer votes, ratification, idea promotion |
| Direction | Only goes up | Can go up or down |
| Who can grant | The system, automatically, on a successful ship | Metic+ builders (votes) + system signals |
| Spendable? | No — equity/score | No — trust signal |
| Gates promotions? | No (Xenos→Thetes is by ship count) | No (informs, doesn't gate) |
| Lives in | `builders.total_credits` / `credit_log` | `builders.karma` / `karma_log` |

Both are reputation. Neither is a spendable currency today. You don't have to *do* anything special to start earning either — claim a task, do good work, ship it, and both tracks take care of themselves.

---

## See it / dig deeper

- **Your numbers:** [builders' hall](https://example.com/builders) (profile card + leaderboard), or `/builder-start` (shows your credit total).
- **The diagram:** [`diagrams/03-drachmae-karma.png`](diagrams/03-drachmae-karma.png) — sources and sinks at a glance.
- **The decisions:** [ADR 0054](../adr/<redacted>.md) (cost-plus reward), [ADR 0023](../adr/<redacted>.md) (kind multipliers + idea bonus), [ADR 0028](../adr/<redacted>.md) (token→USD pricing).
- **The code:** `src/bongos/db.js` (`REWARD_MARGIN_PCT`, `KIND_MULTIPLIERS`, `computeSessionTokenReward`), `src/bongos/llm-pricing.js` (pricing), `src/bongos/cost.js` (budget cap), `src/bongos/bfg.js` (builder strength).
