# ADR 0036 — Builders subdomain + builder-UI reorganization (hall / watch / settings / status)

**Date:** 2026-06-06
**Context:** GDS-V3, task [#726](https://example.com/builders#/task/726). Builds on [ADR 0016](<redacted>.md) (server-enforced permissions), [ADR 0029](<redacted>.md) / [ADR 0030](<redacted>.md) (the status + hall surfaces being reorganized), and the asset-stamping serving model in `server.js` / `src/asset-version.js`.
**Status:** Accepted. Shipped under [#726](https://example.com/builders#/task/726) (grader skipped at Lars's instruction — UI/infra reorg, no logic the grader gates).
**Track:** `internal` (dev-system / builder UI).

## Problem

The builder-facing web had grown into one overloaded surface. The authenticated hall (`example.com/builders`) carried *everything*: a builder's personal standing, the per-skill model picker, AND three Archon-only monitoring panels (security watch, the access-request gate, the roster). Meanwhile the public status dashboard (`status.example.com`) carried operational engineering detail (the Stonemason's Mark grade aggregate, the Surveyor's estimation drift, the Mason's Ledger repo health) that is really *builder* monitoring, not something a public visitor needs. There was no single, easily-gated home for "the builder surface," and no dedicated place for an Archon to watch the GDS and the other builders.

## Decision

Three surfaces, cleanly separated by audience:

1. **`builders.example.com` — a dedicated subdomain for the entire builder surface.** It serves the same `public-builders/` tree, rooted at `/`, so the whole authenticated builder UI sits behind one host that is easy to reason about and gate. Implemented as a thin **rewrite shim** in `server.js` (`isBuildersHost`): every non-API path on the builders host is rewritten onto the existing `/builders/*` tree, so all the established serving + sign-in gating + asset-stamping logic is reused verbatim — zero duplication. The legacy `example.com/builders/*` paths keep working unchanged, so the subdomain is **purely additive**: nothing breaks before DNS + cert land, and existing links / primer nudges / the OAuth callback (`→ /builders`) are untouched.

2. **`builders.example.com/watch` — a new Archon-only monitoring page** ("The Watch"). Sections, in order: **GATE** (pending access requests), **WATCH** (security: open vuln reports + override requests + the audit log), **ROSTER** (the citizen-roll with rank/status actions), **MARKS** (per-builder grade breakdown — new endpoint), **STONEMASON'S MARK** (project-wide grade aggregate, moved off status), **SURVEYOR** (estimation drift, moved off status), **MASON'S LEDGER** (repo health, moved off status), **BFG** (session-ledger tally + link). Gated server-side by `requireArchonPage` on the shared `/builders/watch` path (one matcher covers both hosts since the subdomain rewrites `/watch` → `/builders/watch`); every data endpoint it reads is independently `requireRank('archon')`, so the page gate is defense-in-depth, not the only wall.

3. **`builders.example.com/settings` — a new personal-preferences page.** Holds **VOICES** (the per-skill model picker, moved off the hall) and **CRAFT** (discipline preferences, moved off the now-read-only Standing card). Open to any authenticated builder.

The **hall** (`builders.example.com`) is now a citizen's *personal* dashboard, reordered to: STANDING, HONOURS, KARMA (with the peer-acclaim feed folded under it), WORKS (ships wrought), CLAIM, then MARKS, BOUNTY, ROLL — onboarding WELCOME/PATH still lead for newcomers. The Archon panels and the model picker are gone from it (moved to /watch and /settings respectively); their nav links live in the header gated-nav (the Watch link reveals only for Archons).

The **status dashboard** (`status.example.com`) is slimmed to what a public visitor cares about, reordered to: PULSE, WATCH (uptime), ARCHITECTS, WORKS, TREASURY, LATELY INSCRIBED, THE WORLD. The three engineering tablets moved to /watch.

### Cross-subdomain auth

A single sign-in must span `example.com`, `builders.`, and `status.`. The `gds_session` cookie is now scoped to **`.example.com`** on the production-facing hosts (enumerated allowlist: apex, www, builders, status) and stays **host-only** on localhost and `staging.example.com` — staging is a separate process + DB, so an apex cookie there would bleed a token across environments. The OAuth handshake still runs on the canonical origin (the builders subdomain links sign-in at the apex), so GitHub's fixed redirect_uri registration is unaffected. A validated `?return=` parameter (open-redirect guarded to relative paths + `*.example.com` https URLs only) lets the subdomain bounce a stranger through the apex handshake and land them back on the subdomain. Logout clears both the host-only and apex-scoped cookie forms.

## Alternatives considered

- **Duplicate the serving logic for the subdomain.** Rejected — the rewrite shim reuses the whole `/builders/*` pipeline; a second copy would drift.
- **Hard-redirect `/builders/*` → the subdomain.** Rejected (for now) — the subdomain needs DNS + cert first; redirecting before that would dark the hall. The subdomain is additive; a redirect can come later once it's verified live.
- **`/watch` WATCH = uptime (mirror status).** Considered (the status spec called WATCH a status-mirror), but Lars chose `/watch` WATCH = the *security* watch — the Archon's real monitoring concern. Status keeps its own uptime WATCH for the public.

## Consequences

- **Operator one-time setup** (until then everything stays reachable at `example.com/builders/*`): add a Cloudflare DNS A record `builders` → `REDACTED_IP` (proxy ON); confirm the origin cert's `*.example.com` SAN covers it; `caddy reload`. The `builders.example.com` Caddy block ships in `infra/Caddyfile`.
- New endpoint `GET /api/gds/grades/by-builder?days=` (Archon-only) backs the MARKS section.
- Dead render functions for the moved hall sections remain defined-but-unreferenced in `builders.js` (all guarded); a follow-up cleanup can delete them.
