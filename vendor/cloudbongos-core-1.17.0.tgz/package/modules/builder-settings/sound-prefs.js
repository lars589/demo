// src/bongos/sound-prefs.js — per-builder per-sound on/off preferences (V3.R91
// / #786). Follow-up to the #781 sound system.
//
// One jsonb column on `builders` (sound_prefs, migration 075) stores each
// builder's mutes as { <sound-name>: false }. A missing key falls back to the
// system default in SOUND_DEFAULTS below (every sound ON), so the column stays
// sparse. This module is the single source of truth the API surfaces, the
// /settings UI reads from, and the local fetch-sound-prefs.js hook resolves
// against before mirroring to disk for the offline player.
//
// Mirrors skill-prefs.js intentionally — same shape, same validate/apply
// contract — so the two settings surfaces behave identically.

// The complete set of sounds the toggle exposes — must match the .wav files in
// .claude/sounds/ and the event names play.js is called with. Add a new sound =
// add one line here + one in SOUND_DEFAULTS + the .wav. Ordered to match the
// /settings UI grouping (routine first, then the celebratory ones).
const KNOWN_SOUNDS = Object.freeze([
  'chime',   // Claude finished a turn (routine)
  'alert',   // Claude needs user input
  'ship',    // a task shipped
  'triumph', // a big ship / celebration
  'fanfare', // a rank promotion
]);

// Human-facing labels + descriptions for the UI (so the settings page doesn't
// mirror this copy from a second source).
const SOUND_META = Object.freeze({
  chime:   { label: 'Chime',   desc: 'When Claude finishes a turn' },
  alert:   { label: 'Alert',   desc: 'When Claude needs your input' },
  ship:    { label: 'Ship',    desc: 'When a task ships' },
  triumph: { label: 'Triumph', desc: 'When a big task ships' },
  fanfare: { label: 'Fanfare', desc: 'When you earn a rank promotion' },
});

// System default per sound: every sound is ON unless the builder mutes it.
const SOUND_DEFAULTS = Object.freeze({
  chime: true,
  alert: true,
  ship: true,
  triumph: true,
  fanfare: true,
});

// Master volume (#788). Stored as a reserved key inside the SAME sound_prefs
// jsonb (not a sound name — KNOWN_SOUNDS never contains it), so no extra column
// is needed. Integer percent 0-100; 100 = full (default, current behaviour),
// 0 = silent. The local player (.claude/sounds/play.js) scales the WAV by
// volume/100 before playing.
const VOLUME_KEY = 'volume';
const VOLUME_DEFAULT = 100;

function clampVolume(v) {
  if (typeof v !== 'number' || !Number.isFinite(v)) return VOLUME_DEFAULT;
  return Math.max(0, Math.min(100, Math.round(v)));
}

// Resolve a builder's effective master volume (0-100). Defaults to 100 when
// unset. `builderPrefs` is the raw jsonb off builders.sound_prefs.
function getVolume(builderPrefs) {
  const raw = builderPrefs && builderPrefs[VOLUME_KEY];
  return typeof raw === 'number' ? clampVolume(raw) : VOLUME_DEFAULT;
}

// Sanity assertion at module-load: every KNOWN_SOUNDS entry has a default + meta.
for (const s of KNOWN_SOUNDS) {
  if (!Object.prototype.hasOwnProperty.call(SOUND_DEFAULTS, s)) {
    throw new Error(`sound-prefs: KNOWN_SOUNDS lists '${s}' but SOUND_DEFAULTS has no entry`);
  }
  if (!Object.prototype.hasOwnProperty.call(SOUND_META, s)) {
    throw new Error(`sound-prefs: KNOWN_SOUNDS lists '${s}' but SOUND_META has no entry`);
  }
}

function isKnownSound(value) {
  return typeof value === 'string' && KNOWN_SOUNDS.includes(value);
}

// Resolve a builder's effective enabled-state for one sound: their override if
// set (a boolean), else the system default (ON). Returns null for unknown sounds.
// `builderPrefs` is the raw jsonb value off builders.sound_prefs.
function getForBuilder(builderPrefs, soundName) {
  if (!isKnownSound(soundName)) return null;
  const override = builderPrefs && builderPrefs[soundName];
  if (typeof override === 'boolean') return override;
  return SOUND_DEFAULTS[soundName];
}

// Build the per-builder effective list shown in the UI. Each row carries the
// sound name, label/desc, the system default, the builder's override (or null
// if unset), and the effective enabled-state. Ordered to match KNOWN_SOUNDS.
function listEffective(builderPrefs) {
  return KNOWN_SOUNDS.map((sound) => ({
    sound,
    label: SOUND_META[sound].label,
    desc: SOUND_META[sound].desc,
    default_enabled: SOUND_DEFAULTS[sound],
    override_enabled: typeof builderPrefs?.[sound] === 'boolean' ? builderPrefs[sound] : null,
    enabled: getForBuilder(builderPrefs, sound),
  }));
}

// Collapse a builder's prefs to a flat { <sound>: <bool> } map of EFFECTIVE
// states for every known sound — the shape the local player file wants. Every
// known sound gets an explicit boolean (default applied), so the offline player
// needs no defaults table of its own.
function effectiveMap(builderPrefs) {
  const out = {};
  for (const sound of KNOWN_SOUNDS) out[sound] = getForBuilder(builderPrefs, sound);
  return out;
}

// Validate a PATCH body: { <sound>: <bool>, ... } where every sound is in
// KNOWN_SOUNDS and every value is a boolean OR null (null = clear the override
// and fall back to the system default). Returns { ok, patch } or { ok, errors }.
// Empty body is allowed (no-op).
function validatePatch(body) {
  if (body == null || typeof body !== 'object' || Array.isArray(body)) {
    return { ok: false, errors: [{ error: 'body_must_be_object' }] };
  }
  const errors = [];
  const patch = {};
  for (const [key, value] of Object.entries(body)) {
    // Reserved 'volume' key: a number 0-100, or null to clear (→ default 100).
    if (key === VOLUME_KEY) {
      if (value === null) { patch[VOLUME_KEY] = null; continue; }
      if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 100) {
        errors.push({ key: VOLUME_KEY, error: 'volume_out_of_range', value, range: [0, 100] });
        continue;
      }
      patch[VOLUME_KEY] = clampVolume(value);
      continue;
    }
    if (!isKnownSound(key)) {
      errors.push({ sound: key, error: 'unknown_sound' });
      continue;
    }
    if (value === null) {
      patch[key] = null; // sentinel: clear the override
      continue;
    }
    if (typeof value !== 'boolean') {
      errors.push({ sound: key, error: 'not_a_boolean', value });
      continue;
    }
    patch[key] = value;
  }
  if (errors.length > 0) return { ok: false, errors };
  return { ok: true, patch };
}

// Apply a validated patch to a builder's existing prefs. Pure — does not touch
// the DB. Returns a new object suitable for writing back. null values delete
// keys (fall back to default); booleans overwrite.
function applyPatch(existing, patch) {
  const next = { ...(existing || {}) };
  for (const [sound, value] of Object.entries(patch)) {
    if (value === null) delete next[sound];
    else next[sound] = value;
  }
  return next;
}

module.exports = {
  KNOWN_SOUNDS,
  SOUND_META,
  SOUND_DEFAULTS,
  VOLUME_KEY,
  VOLUME_DEFAULT,
  isKnownSound,
  getForBuilder,
  listEffective,
  effectiveMap,
  getVolume,
  clampVolume,
  validatePatch,
  applyPatch,
};
