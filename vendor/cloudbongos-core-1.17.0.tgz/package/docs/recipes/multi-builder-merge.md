# Multi-builder merge safety — audit + serialization model

> **Deploy-mode note (current state).** This recipe documents the **`laptop`** merge path (operator merges `main` + SSHes the droplet). Since the 2026-06-13 cutover `config/deploy.json` is **`mode: ci`** — the merge + deploy run **server-side** (PR auto-merge + `.github/workflows/deploy-prod.yml`), and credential-less dev boxes ship via server-mediated publish ([ADR 0055](../adr/<redacted>.md)). The local-`main`-worktree + merge-lock model below applies only if `deploy.json` is reverted to `mode: laptop`.

> **Task:** V3.R50 / [#269](https://example.com/builders#/task/269) (criterion **C6 — parallel-safe-under-load**).
> **Question it answers:** when N>1 builders ship and merge concurrently, where do `ship.js` and `/merge-mode` assume "I am the only builder," and what serializes the shared state so they don't collide?

This recipe is the audit deliverable for [#269](https://example.com/builders#/task/269). It enumerates every shared-state surface in the merge/ship path, marks which assume serialized access, names every git operation that could race, and documents the mutex that now covers them.

---

## TL;DR

- **Claim side is already deterministic.** `claimTask()` runs in a single transaction with `SELECT … FOR UPDATE` on the task row, a touches-overlap check, and the `uniq_active_claim_per_task` partial unique index. A lost race surfaces as `ALREADY_CLAIMED` (Postgres `23505`), never as corruption. No change needed.
- **Merge side is the risk, and it has ONE shared resource:** the single `main` worktree (`REPO_ROOT`) on the build machine. Every ship's auto-merge and every `/merge-mode` run checks out `main`, fetches, merges, pushes, and deploys *there*.
- **[#462](https://example.com/builders#/task/462) (criterion C4)** added a lockfile so two concurrent **ships** couldn't collide — but the lock lived *inside* `ship.js`, so `/merge-mode` (which mutates the same tree by hand) never took it. That left two races open: **ship-vs-merge-mode** and **merge-mode-vs-merge-mode**.
- **[#269](https://example.com/builders#/task/269) (this task)** extracts the lock into [`src/bongos/merge-lock.js`](../../src/bongos/merge-lock.js) and has **both** surfaces acquire the **same** mutex. `/merge-mode` takes it via the [`scripts/gds/merge-lock.js`](../../scripts/gds/merge-lock.js) CLI before it touches `main`, and releases it after deploy.

---

## The shared-state surfaces

| Surface | Shared across builders? | Serialized by | Notes |
|---|---|---|---|
| **`main` worktree** (`REPO_ROOT`): checkout, `git fetch`, `git merge`, `git push origin main`, post-merge smoke, `~/deploy.sh` | **Yes — the single hot resource.** One checkout, one HEAD. | **`merge-lock` mutex** (`.git/otb-automerge.lock`) — held by `ship.js` auto-merge AND `/merge-mode`. | This is the surface [#269](https://example.com/builders#/task/269) closes end-to-end. |
| **`claims` table** (claim/release) | Yes | Postgres txn + `uniq_active_claim_per_task` unique index + touches-overlap check (`db.js claimTask`) | Deterministic. `ALREADY_CLAIMED` / `TOUCHES_CONFLICT` are clean refusals, not corruption. |
| **`creator_session_id` on claims** | Yes | `CLAIM_SESSION_MISMATCH` (migration 013) | Only the session that created a claim may ship/release it — prevents cross-session interference. |
| **`worktree_name` uniqueness** | Yes | Server-side disambiguation in `claimTask` (V3.R51 / [#270](https://example.com/builders#/task/270)) | Two claims with the same worktree name → second gets a suffix. |
| **`migration_counter`** (migration number allocation) | Yes | `UPDATE … RETURNING` inside the claim txn | Atomic; each claim that signals `migrations/` gets a distinct number. |
| **Feature worktree** (`.claude/worktrees/<name>`) | No — per-builder | n/a | Each builder's feature branch work is isolated. The collision only appears at merge time, on `main`. |
| **`origin/main` on GitHub** | Yes | `git push origin main` is atomic server-side; a stale push is rejected (non-fast-forward) | The local mutex makes the local merge serialized so the push is fast-forward; a rejected push bails the ship to `confirmed`. |
| **The droplet deploy** (`ssh … ~/deploy.sh`) | Yes | Runs *inside* the merge-lock critical section | Two deploys can't overlap because each holds the mutex through merge→push→deploy. |

---

## Every place the merge path assumed "I am the only builder"

1. **`ship.js autoMerge()` — `git merge --ff-only origin/main` on `REPO_ROOT`.**
   If another session left `main` mid-merge or moved it, this failed and bailed with the misleading *"main is ahead of origin somehow."* — **Fixed in [#462](https://example.com/builders#/task/462)** with the in-`ship.js` lock + `mainWorktreeBusy()` guard (refuses to mutate `REPO_ROOT` when `MERGE_HEAD` exists or the tree is dirty).

2. **`/merge-mode` — `git checkout main; git pull; git merge …` on `REPO_ROOT`, with no lock.** ← **the gap [#269](https://example.com/builders#/task/269) closes.**
   `/merge-mode` mutated the exact same worktree `ship.js` does, but never acquired [#462](https://example.com/builders#/task/462)'s lock (the lock was a private function inside `ship.js`). A ship auto-merging while an operator ran `/merge-mode` could interleave checkouts/merges on one HEAD. **Fixed in [#269](https://example.com/builders#/task/269):** `/merge-mode` now runs `node scripts/gds/merge-lock.js acquire` before Step 2 and `release` in Step 5c.

3. **macOS Finder/iCloud `* 2` duplicate refs.**
   Both surfaces clean these before fetching (`cleanupMacFinderDupRefs` / `find .git -name "* 2" -delete`). Not a concurrency bug, but a shared-filesystem hazard worth listing — it broke every auto-merge on 2026-05-10.

---

## The mutex, precisely

[`src/bongos/merge-lock.js`](../../src/bongos/merge-lock.js) is a portable, advisory file lock at `<REPO_ROOT>/.git/otb-automerge.lock`. **Not `flock(2)`** — ships run on macOS over an iCloud-synced filesystem where `flock` is unreliable, and the manual `/merge-mode` holder is a short-lived CLI process with no long-lived owner.

Lockfile format (3 lines): `pid` · `epoch-ms timestamp` · `mode` (`auto` | `manual`).

| | `auto` (a ship — process stays alive through its merge) | `manual` (`/merge-mode` via the CLI — no long-lived owner) |
|---|---|---|
| Recorded pid | `process.pid` of the ship | `0` (the CLI process exits immediately) |
| Reclaimed when | holder pid is dead **OR** stamp older than `AUTO_STALE_MS` (10 min) | stamp older than `MANUAL_STALE_MS` (30 min) — **time only** |
| Released by | the owning ship process (pid match), in a `finally` | whoever runs `merge-lock.js release` (any process, since mode=manual) |

A ship that can't get the lock within 30s bails cleanly to `confirmed` (the task is safe; `/merge-mode` lands it later). An operator who sees `acquire` exit `3` is told to wait — never to force past a live holder. The two stale windows differ on purpose: an automated ship that crashes should free up fast (10 min), while a human resolving conflicts mid-merge gets a generous 30 min before the lock is presumed abandoned.

Behavior is pinned by [`tests/merge_lock.mjs`](../../tests/merge_lock.mjs) (auto-vs-auto wait, dead-pid + time-based reclaim, manual-window survival, owner-guarded release, two-line legacy-lockfile back-compat).

---

## Known residual limitation (filed, not blocking C6)

**The mutex is machine-local.** `.git/otb-automerge.lock` serializes everything that mutates the *one* `main` worktree on the *one* build machine. Today that is correct and complete: all ships and merges run from worktrees under the single shared checkout on Lars's Mac. If a future version lets builders ship from *different physical machines* against *different* checkouts of `main`, a filesystem lock won't serialize them — that needs a server-side lease (e.g. an advisory lock row / `pg_advisory_lock` keyed on `main`, handed out by the API at merge time). Captured as an idea for GDS-V4; out of scope for C6, which targets parallel safety on the current single-machine, multi-session model.

---

## Related

- [ADR 0024](../adr/<redacted>.md) — multi-agent system (the reason N>1 builders exist).
- [#462](https://example.com/builders#/task/462) — the C4 auto-merge lock this task generalizes.
- [#270](https://example.com/builders#/task/270) (V3.R51) — server-side worktree-name uniqueness (a sibling parallel-safety fix).
- [#272](https://example.com/builders#/task/272) — the parallel-load smoke test that *exercises* this serialization under 5 simulated builders (the other open C6 task). Its **DB rank is R53** (the DB is king); the original planning-seed cross-ref text called it "R54", but the live rank renumbering settled it at R53/[#272](https://example.com/builders#/task/272).
