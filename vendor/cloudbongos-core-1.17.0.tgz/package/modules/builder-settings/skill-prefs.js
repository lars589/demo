// src/bongos/skill-prefs.js — per-builder model preferences per skill (V3.R85
// / #304).
//
// One jsonb column on `builders` (skill_model_prefs, migration 037) stores
// each builder's overrides as { <skill-name>: <model-token> }. Missing keys
// fall back to the system defaults in SKILL_DEFAULTS below. This module is
// the single source of truth that the API surfaces, the /builders UI reads
// from, and any future skill-execution-time hook resolves against.
//
// The audit that produced SKILL_DEFAULTS lives in ADR 0021 — each skill is
// classified as one of:
//
//   - 'script'         — pure mechanism; no LLM judgment needed. Slash
//                        command shells out to a script in scripts/gds/ and
//                        formats the output. No model selection meaningful.
//   - 'opus'  (default for heavy judgment) — design/strategy work the
//                        builder really wants right.
//   - 'sonnet'         — middle tier; judgment is involved but not load-
//                        bearing. Cheaper than opus, more capable than
//                        haiku.
//   - 'haiku'          — light judgment; classification, sorting, brief
//                        framing.
//
// A skill listed here as default 'script' still appears in the UI matrix so
// a builder can deliberately upgrade it (e.g. someone using /builder-cost
// wants Opus to suggest the right cost category) — the system default just
// signals "no LLM judgment is structurally needed."

const ALLOWED_MODELS = Object.freeze(['opus', 'sonnet', 'haiku', 'script']);

// The complete set of skills the matrix exposes. Drives both the UI render
// and the PATCH validation — any pref for a skill not in this set is
// rejected. Add a new skill = add one line here + one line in
// SKILL_DEFAULTS. (Keeping these in code, not in a table, so that the
// allowlist is reviewed alongside the skill SKILL.md itself.)
//
// Ordered to match the /builders UI grouping: methodology + workflow
// builders first, then otb-art at the bottom.
const KNOWN_SKILLS = Object.freeze([
  // Methodology / workflow
  'builder-start',
  'builder-claim',
  'builder-ship',
  'builder-release',
  'builder-exit',
  'builder-cost',
  // Daily cadence (heavy judgment)
  'idea-triage',
  'blocker-review',
  'merge-mode',
  // Planning (heavy judgment)
  'planning-session',
  'priority-session',
  // Setup / one-shot
  'builder-setup',
  // Art pipeline
  'otb-tile-generate',
  'otb-design-review',
  'otb-feedback-capture',
  'otb-figma-sync',
]);

// System default per skill. The audit's verdict — what runs when the
// builder hasn't expressed a preference.
const SKILL_DEFAULTS = Object.freeze({
  // Pure mechanism — script wrappers around scripts/gds/*.js. No LLM
  // judgment needed for the wrapped operation; the slash command just
  // routes input → script → formatted output.
  'builder-start': 'script',
  'builder-claim': 'script',
  'builder-release': 'script',
  'builder-exit': 'script',
  'builder-cost': 'script',
  'otb-figma-sync': 'script',
  // Mechanism with a small judgment moment (drafting the handoff notes
  // and value summary). Default Sonnet — Opus is overkill for short note
  // drafting, Haiku would weaken the value summary.
  'builder-ship': 'sonnet',
  // Heavy judgment — the skill IS the LLM walking through verdicts,
  // proposals, conflict resolution, criterion design. Defaults Opus per
  // the project-wide subagent-routing rule (CLAUDE.md §2).
  'idea-triage': 'opus',
  'blocker-review': 'opus',
  'merge-mode': 'opus',
  'planning-session': 'opus',
  'priority-session': 'opus',
  // One-shot setup — long-form environment walk-through, but mechanical
  // once the steps are clear. Sonnet is enough.
  'builder-setup': 'sonnet',
  // Art pipeline — generation + design review + feedback capture all use
  // an EXTERNAL model (Gemini for the image gen + review). The 'model'
  // here refers to the orchestrating Claude subagent, not the image
  // model. Sonnet is sufficient for orchestration.
  'otb-tile-generate': 'sonnet',
  'otb-design-review': 'sonnet',
  'otb-feedback-capture': 'sonnet',
});

// Sanity assertion at module-load: every KNOWN_SKILLS entry has a default.
// Catches drift between the two lists at deploy time, not at runtime.
for (const s of KNOWN_SKILLS) {
  if (!Object.prototype.hasOwnProperty.call(SKILL_DEFAULTS, s)) {
    throw new Error(`skill-prefs: KNOWN_SKILLS lists '${s}' but SKILL_DEFAULTS has no entry`);
  }
}

function isAllowedModel(value) {
  return typeof value === 'string' && ALLOWED_MODELS.includes(value);
}

function isKnownSkill(value) {
  return typeof value === 'string' && KNOWN_SKILLS.includes(value);
}

// Resolve a builder's effective preference for one skill: the override if
// they've set one, else the system default. Returns null for unknown
// skills (caller should treat as "not configurable").
//
// `builderPrefs` is the raw jsonb value off builders.skill_model_prefs.
// We accept it as a plain object so callers can pass it in once (e.g. the
// API endpoint resolves it once per request) rather than hitting the DB
// per-skill.
function getForBuilder(builderPrefs, skillName) {
  if (!isKnownSkill(skillName)) return null;
  const override = builderPrefs && builderPrefs[skillName];
  if (isAllowedModel(override)) return override;
  return SKILL_DEFAULTS[skillName];
}

// Build the per-builder effective-preference list shown in the UI matrix.
// Each row carries the skill name, the system default, the builder's
// override (or null if unset), and the effective pick. Ordered to match
// KNOWN_SKILLS for stable UI rendering.
function listEffective(builderPrefs) {
  return KNOWN_SKILLS.map((skill) => ({
    skill,
    default_model: SKILL_DEFAULTS[skill],
    override_model: isAllowedModel(builderPrefs?.[skill]) ? builderPrefs[skill] : null,
    effective_model: getForBuilder(builderPrefs, skill),
  }));
}

// Validate a PATCH body: { <skill>: <model>, ... } where every skill is
// KNOWN_SKILLS and every model is ALLOWED_MODELS OR null (null = clear
// the override and fall back to the system default).
//
// Returns { ok: true, patch } on success, { ok: false, errors } on
// failure. Empty body is allowed (no-op).
function validatePatch(body) {
  if (body == null || typeof body !== 'object' || Array.isArray(body)) {
    return { ok: false, errors: [{ error: 'body_must_be_object' }] };
  }
  const errors = [];
  const patch = {};
  for (const [skill, model] of Object.entries(body)) {
    if (!isKnownSkill(skill)) {
      errors.push({ skill, error: 'unknown_skill' });
      continue;
    }
    if (model === null) {
      patch[skill] = null; // sentinel: clear the override
      continue;
    }
    if (!isAllowedModel(model)) {
      errors.push({ skill, error: 'unknown_model', value: model, allowed: ALLOWED_MODELS });
      continue;
    }
    patch[skill] = model;
  }
  if (errors.length > 0) return { ok: false, errors };
  return { ok: true, patch };
}

// Apply a validated patch to a builder's existing prefs. Pure — does not
// touch the DB. Returns a new object suitable for writing back. null
// values delete keys; defined string values overwrite.
function applyPatch(existing, patch) {
  const next = { ...(existing || {}) };
  for (const [skill, model] of Object.entries(patch)) {
    if (model === null) delete next[skill];
    else next[skill] = model;
  }
  return next;
}

module.exports = {
  ALLOWED_MODELS,
  KNOWN_SKILLS,
  SKILL_DEFAULTS,
  isAllowedModel,
  isKnownSkill,
  getForBuilder,
  listEffective,
  validatePatch,
  applyPatch,
};
