-- 035_auth_token_hygiene.sql
--
-- V3.R38 / task #259 — short-lived auth sessions with refresh-on-use, plus
-- Archon-only revocation endpoints. The SCHEMA side is small: builder_sessions
-- already has the columns we need (expires_at, last_used_at, revoked_at since
-- 003_pms.sql). What this migration does is:
--
--   1. BACKFILL existing rows' expires_at with a GENEROUS 24-hour grace runway
--      from migration time. This is intentional: the live autonomous overnight
--      supervisor (and any builder mid-flow) holds a long-lived CLI token. If
--      we retroactively expired it, the very session running this migration
--      would die. The 24h grace gives every active session a window to either
--      (a) hit a route, refresh-on-use, and roll forward into the new 1h TTL
--      regime, or (b) sit idle and expire naturally after 24h.
--
--      Formula: expires_at = GREATEST(NOW() + INTERVAL '24 hours',
--                                     last_used_at + INTERVAL '24 hours').
--
--      Worked example: last_used_at = NOW() - 1h → new expires_at = NOW() + 24h.
--      Worked example: last_used_at = NOW() + 5m (clock skew) → new expires_at
--                       = (NOW()+5m) + 24h ≈ NOW() + 24h05m. Always future.
--
--      Worked example: existing expires_at was NULL (the CLI-never-expires
--                       default from 003_pms.sql) → backfilled to a future
--                       timestamp; refresh-on-use will keep it rolling.
--
--   2. Add an index on (builder_id, revoked_at) so revoke-all-for-builder is
--      cheap (touches only rows for that builder, filters out already-revoked).
--
-- The 1-HOUR TTL itself is enforced in code (src/bongos/db.js): createSession
-- defaults expiresAt to NOW()+1h, and lookupSession bumps last_used_at AND
-- expires_at = NOW()+1h on every authenticated request. We do NOT enforce the
-- 1h cap at the SQL level — that would risk the migration retroactively
-- punching existing sessions, and the code-level enforcement is sufficient for
-- C7 (rank-change-near-instant: a demoted builder's tokens are revoked-all
-- explicitly, not waited-out via TTL).
--
-- Idempotent: safe to re-run. The UPDATE only touches rows where the formula
-- would push expires_at FORWARD — it never shortens an existing future expiry.

BEGIN;

-- 1. Backfill: every row where the current expires_at is null OR earlier than
--    the grace window gets pushed out. Never shortens.
UPDATE builder_sessions
   SET expires_at = GREATEST(
     NOW() + INTERVAL '24 hours',
     last_used_at + INTERVAL '24 hours'
   )
 WHERE revoked_at IS NULL
   AND (
     expires_at IS NULL
     OR expires_at < GREATEST(
       NOW() + INTERVAL '24 hours',
       last_used_at + INTERVAL '24 hours'
     )
   );

-- 2. Helpful index for revoke-all-for-builder (and for filtering active
--    sessions in admin reads). Already-revoked rows are skipped by the partial
--    predicate so revoke-all only touches the relevant rows.
CREATE INDEX IF NOT EXISTS idx_builder_sessions_builder_active
  ON builder_sessions (builder_id)
  WHERE revoked_at IS NULL;

COMMIT;
