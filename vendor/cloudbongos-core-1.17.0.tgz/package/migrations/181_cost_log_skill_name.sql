-- 181_cost_log_skill_name.sql — task #385 / V3.R85 follow-up C.
--
-- Add skill_name to cost_log so per-skill spend is measurable.
--
-- Background
-- ----------
-- ADR #304 committed to a cost-per-skill-invocation measurement, but
-- cost_log has no skill_name column, making it impossible to aggregate
-- "how much does /idea-triage cost vs /builder-ship". This migration
-- adds the column. The --skill flag on /builder-cost and the
-- resolve-skill-model.js helper (task #385 parts A+B) wire it up at the
-- call site, so a week of data after those land gives us the delta ADR
-- #304's consequences section requires.
--
-- Design
-- ------
-- * Nullable. Historical rows and non-skill-invocation costs (infra,
--   domain, art) carry no skill_name — NULL is correct, not a gap.
-- * Text, unconstrained to a skills enum. New skills are added to
--   skill-prefs.js/KNOWN_SKILLS without a migration; the cost_log column
--   should not require a parallel schema change for each one.
-- * Index on (skill_name, recorded_at DESC) for the "cost by skill over
--   time" query shape the ADR #304 consequences analysis will run.

ALTER TABLE cost_log
  ADD COLUMN IF NOT EXISTS skill_name text;

CREATE INDEX IF NOT EXISTS idx_cost_log_skill_name_recorded
  ON cost_log (skill_name, recorded_at DESC)
  WHERE skill_name IS NOT NULL;

INSERT INTO schema_migrations (version) VALUES ('181_cost_log_skill_name')
  ON CONFLICT (version) DO NOTHING;
