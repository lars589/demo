-- BONGOS-V1 — module-system done-when criterion (C5) — 2026-06-21
-- Owner-directed (archon), task 1405 (BV1.R36) / ADR 0083.
--
-- Adds a 5th done_when_criterion to BONGOS-V1: the project-extensible module
-- system (the design scoped in docs/design/modular-architecture/, epic #1388 /
-- BV1.R34). The module-system child tasks are seeded AFTER this is applied via
-- scripts/gds/seed-bongos-module-system-tasks.js, so the positional ref C5
-- resolves at task-create. (Same migration+seed split as 120 + seed-bongos-app-tasks.js.)
--
-- Idempotent on re-run: UPSERT on (version_id, criterion_id). The companion
-- migration 120 already seeded C1..C4 (sort_order 1..4); this adds sort_order 5.

BEGIN;

INSERT INTO done_when_criteria (version_id, criterion_id, criterion_md, sort_order)
SELECT * FROM (VALUES
  ('BONGOS-V1', 'module-system-live',
   '**The project-extensible module system is live — the whole product is `core + modules`.** Cloud Bongos''s closed four-module registry becomes self-describing packages the platform discovers, validates, and mounts; a host can ADD or CONFIGURE modules without forking core, and the trust boundary (ADR 0016) is ENFORCED across module routes, not trusted. Built as an incremental strangler migration (ADR 0083) — reorganize, not rewrite; single-package, single-process, no-bundler preserved. Done when: (1) `src/module-api.js` is the stable, semver''d doorway and the only core file a module may import; (2) a loader discovers/validates/mounts `modules/*/module.json` behind kernel-composed auth and replaces the hardcoded `KNOWN_MODULES` registry, with a kernel seam registry (ports + events) for cross-module capability; (3) the four feature modules (dev-box, game, discord, art-pipeline) are moved into `modules/<key>/` and the inline `if (isModuleEnabled())` gates are deleted, with OTB behaving byte-identically (the proof); (4) fitness functions fail the build on any boundary violation (core never imports a module, modules import only the published API, every module write-route is rank-gated, core carries no module code, module migrations are additive + namespaced); (5) module-owned migrations generalize the `migrations/game/` precedent to `modules/<key>/migrations/` (enabled-gated apply, disable-preserves-data); (6) `bongos module new <key>` scaffolds a module and `bongos upgrade` pre-checks coreVersion; and (7) docs/modules-contract.md documents the plugin-API contract + a module-author recipe.',
   5)
) AS v(version_id, criterion_id, criterion_md, sort_order)
WHERE EXISTS (SELECT 1 FROM versions WHERE id = 'BONGOS-V1')
ON CONFLICT (version_id, criterion_id) DO UPDATE
  SET criterion_md = EXCLUDED.criterion_md,
      sort_order   = EXCLUDED.sort_order;

COMMIT;
