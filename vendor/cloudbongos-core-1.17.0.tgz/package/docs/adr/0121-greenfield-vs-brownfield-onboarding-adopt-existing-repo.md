# ADR 0121 — Greenfield vs. brownfield onboarding: scope `bongos init --adopt` (adopt an existing repo)

- **Status:** Accepted (the split + the adopt-mode requirements are decided; the build is task-pending — see §Consequences for the seeded breakdown). **No adopt-mode code ships in this ADR — it is scope-only.**
- **Date:** 2026-07-04
- **Track:** internal (a portable Cloud Bongos platform capability)
- **Task:** [#1986](https://example.com/builders#/task/1986) (BONGOS-V1, goal 35 — *Project creation flow*, the `adopt-existing-repo` criterion) — "SCOPE what an adopt mode must do; deliver an ADR + a task breakdown. Do NOT build adopt-mode here."
- **Deciders:** Lars (Archon), Claude
- **Builds on:** [ADR 0108](<redacted>.md) (configurable-root / core-as-npm-dep — the "layer, don't clone" substrate), [ADR 0111](<redacted>.md) (the `provisioning` module + the greenfield `bongos init` → provisioning-request wiring), [ADR 0062](<redacted>.md) (core↔host instance model), [ADR 0100](<redacted>.md) (two-repo instance model), [ADR 0105](<redacted>.md) (instance seeds out of core migrations), [ADR 0016](<redacted>.md) (server-enforced trust boundary), [ADR 0083](<redacted>.md) + [ADR 0108](<redacted>.md) §5 (module system + cross-repo migration namespacing).
- **Raised while** abandoning task 1689 (2026-07-04): the standalone two-repo model is already proven by Emersonian Circles (task 1917), so the missing piece is not *"can core run standalone"* but *"how does an owner who **already has a repo** adopt it."*

---

## Context

Goal 35 ("Project creation flow") has two done-when criteria:

- **`project-creation-flow`** (greenfield) — a new owner goes zero-to-live on a fresh, empty project.
- **`adopt-existing-repo`** (brownfield) — an owner with an *existing* repository (app code, git history, a backlog) brings Cloud Bongos onto it.

**Today the flow is greenfield-only.** `scripts/gds/init.js`:

- opens with *"Let's stand up a new Cloud Bongos instance."* (`init.js:325`) — the mental model is a blank slate;
- **refuses to run where `config/branding.json` already exists** unless `--force`, and `--force` *overwrites* (`init.js:408–409`) — there is no "merge onto what's here" path;
- **seeds a synthetic first version** — default id `V1`, name `"V1 — Prove the loop"` (`init.js:341–342`) + starter/kickoff tasks — rather than reflecting the repo's real current version, goal, or backlog;
- **inspects nothing** about the existing tree: not its stack, not its layout, not its CI, not its migration numbering.

So an owner with a real repo has only two bad options today: run `init` in a throwaway directory and hand-merge, or `--force` and clobber their config. Neither is a guided flow, and neither preserves their real state. That is the gap `adopt-existing-repo` names — and the reason this ADR complements the greenfield criterion rather than replacing it.

---

## Decision

### 1. Two explicit onboarding modes over one canonical step sequence

Goal 35's canonical runbook (task [#1981](https://example.com/builders#/task/1981)) is the source of truth for the *sequence*: name+address → init → scaffold → provision → OAuth app + verified secret + first sign-in → verify → brand. The runbook branches at **exactly one leg — scaffold** — into:

- **greenfield** (`bongos init`, today's behavior): scaffold a fresh standalone repo + a synthetic first version.
- **brownfield** (`bongos init --adopt`): **layer** onto the existing tree and reflect its real state.

Every other leg (provision, OAuth, verify, brand) is **identical** across the two modes. `--adopt` is a mode of the *same* `init`, not a separate command — so the CLI form (task [#1982](https://example.com/builders#/task/1982)) and the hall wizard form (task [#1983](https://example.com/builders#/task/1983)) inherit it for free.

### 2. LAYER, never scaffold or clobber (the core requirement)

In `--adopt`, `init`:

- adds the pinned `@cloudbongos/core` dependency + `config/` overrides + `.claude/` **additively** onto the existing tree;
- for any file that already exists (an owner's `package.json`, a pre-existing `.claude/`, a CI workflow), it **merges or leaves-and-reports** — it **never overwrites**. The `--force`-overwrites code path is explicitly *not* reused;
- writes only the *lean* `config/branding.json` overrides ADR 0108 defines (the rest resolves from `*.neutral.json`), so the owner's existing files stay theirs.

### 3. Reflect REAL state, not a synthetic V1

`--adopt`:

- does **not** seed `"V1 — Prove the loop"`; it captures (by interview + detection) the repo's actual current version/milestone and open goal;
- **imports the existing backlog** into GDS tasks — GitHub issues (via the GitHub auth the flow already establishes), a `TODO`/`ROADMAP`/`BACKLOG.md`, or an interview fallback — so the ledger starts truthful rather than empty.

### 4. DETECT the existing stack + layout

Before writing anything, `--adopt` inspects the tree — language/runtime, package manager, test + CI setup, directory layout — so the enabled modules, the generated repo-map, and the **core↔host fitness boundary** (ADR 0062 §1) fit what is already there instead of assuming the reference layout.

### 5. A CONFLICT PRE-FLIGHT report — the owner sees the blast radius before committing

`--adopt --dry-run` (the default first pass) produces a report covering at least:

- **migration namespace** — do the repo's existing migration numbers collide with core's namespace (ADR 0108 §5)?
- **the fitness boundary** — would adopting flag existing imports as core↔host violations (ADR 0062 §1)?
- **protected-path / rank gates** — which incoming files land on protected paths (ADR 0043)?
- **existing CI** — does core's expected `unit`/gate check collide with the repo's own workflows?

**Nothing is written until the owner accepts the pre-flight.** This accept-gate is the safety the greenfield path does not need (a blank slate cannot be clobbered).

### 6. What `--adopt` does NOT change

The trust boundary (ADR 0016), the provisioning path (ADR 0111 — an adopted instance provisions exactly like a greenfield one), and the standalone composition model (ADR 0108) are all unchanged. Adopt is a *front door* onto the same substrate, not a new substrate.

---

## Alternatives considered

- **Extend `--force` to "merge."** Rejected — `--force` means *overwrite*; overloading it to sometimes-merge is a footgun on exactly the repos where a mistake is expensive. A distinct `--adopt` mode with a dry-run pre-flight is legible.
- **A separate `bongos adopt` command.** Rejected — it would duplicate the init/provision/verify legs and drift from them. Adopt is one branch of `init`'s *scaffold* leg; the CLI + hall forms then get it for free.
- **Auto-import everything (issues + TODOs + CI) with no pre-flight.** Rejected — brownfield repos are exactly where silent clobbering hurts most; the pre-flight + accept step is mandatory, not optional.
- **Build adopt-mode now.** Out of scope by the task's own charter — 1986 is scope-only. This ADR + the seeded breakdown *is* the deliverable.

---

## Consequences

- **`adopt-existing-repo` gets a concrete, buildable shape** — the criterion is no longer a one-line aspiration; it has a governing decision and a dependency-wired task breakdown.
- **The greenfield criterion is untouched** — today's `bongos init` *is* the greenfield mode; `--adopt` is purely additive to it.
- **Sequencing:** the adopt build depends on goal 35's canonical runbook (task 1981) existing, because `--adopt` is a branch of it; the detection + pre-flight pieces are independent and can start first.
- **Follow-up tasks seeded** under BONGOS-V1 / goal 35, linked to the `adopt-existing-repo` criterion (idempotent seeder `scripts/gds/seed-adopt-tasks.js`, `source_ref = BONGOS-V1-adopt-*`). Seeded as **`backlog`** — the owner schedules the adopt build deliberately; nothing auto-promotes:
  1. [#2042](https://example.com/builders#/task/2042) **`bongos init --adopt` skeleton + config layering** — add the mode; layer the `@cloudbongos/core` dep + lean `config/` + `.claude/` additively; merge-or-report on every pre-existing file; never overwrite. *(deps: none — the substrate is shipped)*
  2. [#2043](https://example.com/builders#/task/2043) **Stack + layout detection** — inspect runtime / package-manager / test / CI / layout; feed enabled modules + repo-map + the fitness boundary. *(deps: none)*
  3. [#2044](https://example.com/builders#/task/2044) **Real-state capture + backlog import** — replace the synthetic V1 with the repo's actual version/goal; import GitHub issues / TODO / roadmap into GDS tasks. *(deps: [#2042](https://example.com/builders#/task/2042))*
  4. [#2045](https://example.com/builders#/task/2045) **Conflict pre-flight report** — migration-namespace + fitness-boundary + protected-path + CI-collision report, `--dry-run` default, gated behind an accept step. *(deps: [#2042](https://example.com/builders#/task/2042), [#2043](https://example.com/builders#/task/2043))*
  5. [#2046](https://example.com/builders#/task/2046) **Wire `--adopt` into the canonical runbook + both forms** — the /new-project skill, `bongos onboard`, and the hall wizard offer greenfield-vs-adopt at the scaffold leg. *(deps: [#2042](https://example.com/builders#/task/2042), [#2044](https://example.com/builders#/task/2044), [#2045](https://example.com/builders#/task/2045), and goal-35 runbook task [#1981](https://example.com/builders#/task/1981))*
