'use strict';

// Server-owned publish reconciler (task 1134) — the durable cure for the
// "strands at confirmed" failure class.
//
// WHY THIS EXISTS
// A server-mediated publish (ADR 0055) is ASYNCHRONOUS: a dev box uploads its
// branch, the server pushes + opens the PR + arms auto-merge, then GitHub runs
// the required checks, merges, and Actions deploys to prod. The box's ship.js
// only POLLS for ~9 min (pollServerPublish) and then EXITS, printing "it flips to
// shipped on its own". But the confirmed→shipped transition lived in exactly ONE
// place — the GET /tasks/:id/publish-status reconcile-on-read (routes/tasks.js).
// That flip can ONLY happen while a client keeps issuing that GET. Real CI (check
// queue + merge queue + deploy) routinely finishes AFTER the box has stopped
// polling, so nothing ever re-checks and the task row freezes at 'confirmed'
// forever — even though prod is live. Every prior point-fix (1025/1027/1037/1041/
// 1045/1046/1049/1050/1052/1068) compensated for a symptom of this one gap:
// "the box must stay alive and keep polling to finish its OWN ship."
//
// THE FIX. Move the last mile to the SERVER, where it belongs. A periodic sweep
// (this module) finds every 'confirmed' task, derives its branch from the latest
// claim's worktree_name, asks the server's own publish-status (PR merged + deploy
// succeeded?), and on a confirmed land runs the EXACT db.shipTask +
// ship-broadcast.postShipBroadcast the publish-status route already runs. The land
// no longer depends on the shipper's CLI being alive — it works for EVERY builder,
// on a box, a laptop, or a desktop session, and retroactively heals strands left
// by a session that exited early. Idempotent: shipTask throws TASK_NOT_CONFIRMED
// if a client poll (or a prior sweep) already flipped it, so a sweep racing the
// route never double-ships nor double-broadcasts.
//
// task 1313 — close the residual strand class the PR-keyed land-check still missed.
// getPublishStatus finds a land by looking up the head branch's PR. Three shapes
// defeat that and stranded tasks at 'confirmed' even though the work was live on
// main: (1) a merge that DELETES the branch leaves no PR discoverable by head, so
// pr_state stays 'none' forever; (2) a claim with no worktree_name has no branch to
// look up at all (these were dropped from the feed entirely); (3) a corrupt head_sha
// / branch-name mismatch. The fix adds a head_sha land-check — is the claim's commit
// an ancestor of origin/main (github-push.isAncestorOfDefaultBranch)? — that proves
// the land from the COMMIT, not the PR. The feed now also returns no-worktree rows.
// An 8-strand backlog (incl. a Xenos's onboarding ships that never counted) is what
// surfaced this.
//
// Mirrors the in-process poller precedent (src/bongos/uptime-poller.js) and the
// Discord reconcile timers (src/bongos/discord-bot.js): unref'd timers (never hold
// the process open), best-effort (a GitHub/DB hiccup logs and waits for the next
// sweep), and a no-op when the server holds no push credential (local dev, tests).

const githubPush = require('./github-push');
const seams = require('../../src/module-api');
const conflictResolve = require('./conflict-resolve');

// 5-min cadence: frequent enough that a strand heals within minutes of CI
// finishing, cheap enough that the GitHub API cost is negligible (2 calls per
// confirmed task per sweep, a handful of tasks). Override for tests/ops.
const INTERVAL_MS = Number(process.env.PUBLISH_RECONCILE_MS) || 5 * 60_000;
// A first sweep shortly after boot so a strand left by the previous process (e.g.
// a deploy that restarted the server mid-poll) heals fast, not on the next tick.
const FIRST_SWEEP_DELAY_MS = Number(process.env.PUBLISH_RECONCILE_FIRST_MS) || 30_000;
// Bound the per-sweep work. There are rarely more than a handful of confirmed
// tasks; this is a runaway guard, not an expected limit.
const SWEEP_LIMIT = 100;
// Observability (task 1546 / blocker 47): a confirmed task the sweep cannot prove
// landed and that is OLDER than this is a strand — credited but with no provable
// land — and gets a WARN. Default 30 min; tune/disable via env.
const STALE_CONFIRMED_MS = Number(process.env.PUBLISH_RECONCILE_STALE_MS) || 30 * 60_000;
// task 1915: cap the speculative regen-heal per branch so a genuine treadmill (main
// churning faster than CI clears a re-freshened branch) can't loop forever. In-memory
// per process — a restart resets the guard, which is fine (heals are idempotent and
// a persistently-red branch surfaces via the STALE strand WARN above).
const MAX_STALE_HEAL_ATTEMPTS = Number(process.env.PUBLISH_RECONCILE_MAX_HEAL) || 3;
const healAttempts = new Map(); // branch -> regen-heal attempts this process

let intervalTimer = null;
let firstTimer = null;

// task 1915 — is this mergeIfGreen result the "mergeable but a check is RED" shape
// whose commonest cause is a STALE generated index (see refreshStaleGenerated)? Only
// a PR GitHub reports as MERGEABLE (no conflict — a CONFLICTING PR is the
// resolveBranchConflicts path) whose block reason is a failing check qualifies; a
// pending/among-computing/review-gated PR is left to settle on its own.
function couldBeStaleGenerated(m) {
  if (!m || m.merged || m.merged_now) return false;
  if (m.pr_state !== 'open') return false;
  if (m.mergeable !== 'MERGEABLE') return false;
  const reason = String(m.reason || '');
  return /^failing_check:/.test(reason) || /^non_required_check_failing:/.test(reason);
}

// One sweep. Pure w.r.t. injected deps (db / githubPush / emit / loggers)
// so the whole thing is unit-tested with no DB and no network. Returns a summary
// { skipped?, checked, reconciled, errors } for observability + tests.
async function runSweep(deps = {}) {
  const db = deps.db || require('./db');
  const push = deps.githubPush || githubPush;
  const emit = deps.emit || seams.emitAsync;
  const resolver = deps.conflictResolve || conflictResolve;
  const logFn = deps.log || console.log;
  const errFn = deps.error || console.error;

  // No server push credential (local dev, tests, an un-provisioned host) → there
  // is nothing to reconcile against, and getPublishStatus would 503. No-op.
  if (!push.isConfigured()) {
    return { skipped: 'unconfigured', checked: 0, reconciled: 0, merged: 0, resolvedConflicts: 0, errors: 0 };
  }

  let rows;
  try {
    rows = await db.listConfirmedTasksForReconcile({ limit: deps.limit || SWEEP_LIMIT });
  } catch (e) {
    errFn(`[publish-reconciler] could not list confirmed tasks: ${e && e.message}`);
    return { skipped: 'list_failed', checked: 0, reconciled: 0, merged: 0, resolvedConflicts: 0, errors: 1 };
  }

  // Safety: a worktree_name can be reused across sequential (released) claims, so
  // two confirmed tasks could derive the SAME branch. We can't tell which task a
  // merged PR belongs to, so we skip ambiguous branches (logged) and leave them
  // for manual handling rather than risk shipping the wrong task's row.
  const branchCount = new Map();
  for (const r of rows) {
    if (!r.worktree_name) continue;
    const b = `claude/${r.worktree_name}`;
    branchCount.set(b, (branchCount.get(b) || 0) + 1);
  }

  let reconciled = 0;
  let merged = 0;
  let resolvedConflicts = 0;
  let refreshedStale = 0; // task 1915: PRs whose stale generated indexes we regen+pushed
  let errors = 0;
  let unprovable = 0;   // confirmed tasks the sweep could not prove landed this pass
  let staleStrands = 0; // of those, the ones older than STALE_CONFIRMED_MS (WARN'd)
  const attempts = deps.healAttempts || healAttempts; // injectable for deterministic tests
  const branchesSeen = new Set();                     // to prune the attempts map post-sweep
  const nowMs = Date.now();
  for (const r of rows) {
    const branch = r.worktree_name ? `claude/${r.worktree_name}` : null;
    if (branch) branchesSeen.add(branch);
    const branchUsable = !!branch && push.isSafeBranch(branch) && branchCount.get(branch) === 1;
    if (branch && branchCount.get(branch) > 1) {
      // A reused worktree_name maps a branch to >1 confirmed task, so a merged PR is
      // ambiguous — but each task's OWN head_sha is not, so we skip only the branch/PR
      // path and let the head_sha ancestry land-check below resolve it unambiguously.
      logFn(`[publish-reconciler] task ${r.task_id}: branch ${branch} maps to >1 confirmed task — using head_sha land-check only`);
    }

    let landed = false;
    let landNote = '';
    let branchStatus = null;

    if (branchUsable) {
      // Active merge driver (task 1162): GitHub's auto-merge fires on check-completion
      // EVENTS, so a PR whose auto-merge was re-armed AFTER its checks already went
      // green can sit open forever (the PR #125 stall). Before checking for a land,
      // NUDGE the merge — if the PR is mergeable + CLEAN the server merges it itself.
      // Best-effort: a miss (mergeability still computing, a transient API error)
      // just waits for the next sweep; a non-green PR is reported via publish-status,
      // never forced here. Guarded so an older injected deps bundle can't crash.
      if (typeof push.mergeIfGreen === 'function') {
        try {
          const m = await push.mergeIfGreen({ branch });
          if (m && m.merged_now) {
            merged++;
            logFn(
              `[publish-reconciler] task ${r.task_id} (${branch}) PR #${m.number} was green but unmerged — server-merged it (auto-merge stall)`
            );
          } else if (
            m && !m.merged && m.reason === 'merge_conflict' &&
            typeof resolver.resolveBranchConflicts === 'function'
          ) {
            // task 1385 (ADR 0082): GitHub's own auto-merge cannot run our custom
            // otb-regen driver, so a PR that conflicts ONLY on generated files /
            // the docs/adr/README.md append-index strands here forever. Do the
            // regenerating merge locally (temp clone, driver + union active) and
            // push the resolution; the PR's required checks re-run on the new head
            // and the NEXT sweep's mergeIfGreen lands it. Best-effort: a genuine
            // hand-written conflict is left untouched for a human.
            try {
              const rr = await resolver.resolveBranchConflicts({ branch });
              if (rr && rr.resolved) {
                resolvedConflicts++;
                logFn(
                  `[publish-reconciler] task ${r.task_id} (${branch}) PR #${m.number} conflicted only on generated/index files — server-resolved + pushed; checks re-run, lands next sweep`
                );
              } else if (rr && rr.skipped === 'unresolvable_conflict') {
                logFn(
                  `[publish-reconciler] task ${r.task_id} (${branch}) PR #${m.number} has a hand-written conflict (${(rr.conflicted || []).join(', ') || 'unknown'}) — left for a human`
                );
              }
            } catch (e) {
              errFn(`[publish-reconciler] conflict-resolve for task ${r.task_id} (non-blocking): ${e && e.message}`);
            }
          } else if (
            m && couldBeStaleGenerated(m) &&
            typeof resolver.refreshStaleGenerated === 'function'
          ) {
            // task 1915 (idea 499; the ADR 0082 gap): the PR is mergeable (no
            // conflict) but a check is RED — commonest cause on a busy fleet is a
            // STALE generated index (CI runs gen-*-map --check on the MERGE REF, so a
            // main merge during the CI window re-stales the branch's committed
            // docs/repo-map.md). mergeIfGreen won't fire (merge_state != CLEAN) and the
            // reason is a failing check, never merge_conflict, so resolveBranchConflicts
            // above never runs. Speculatively heal: merge origin/main + REGENERATE in a
            // temp clone; a regen diff → commit + push (checks re-run, next sweep lands
            // it); NO diff → a real check failure, left for a human. Capped per branch
            // so a genuine treadmill can't loop forever. NEVER ships (the land still
            // goes through landProvenForTask below) — no phantom-ship (idea 359).
            const n = attempts.get(branch) || 0;
            if (n >= MAX_STALE_HEAL_ATTEMPTS) {
              logFn(
                `[publish-reconciler] task ${r.task_id} (${branch}) PR #${m.number} still red after ${n} regen-heal attempt(s) (${m.reason}) — capped (persistent staleness treadmill or a real check failure); left for a human`
              );
            } else {
              try {
                const rr = await resolver.refreshStaleGenerated({ branch });
                // Burn a cap slot ONLY on a tree-level determination (a real push, or a
                // proven no-staleness); a transient/environmental miss (clone/fetch/
                // checkout/merge_conflict/push_failed/…) must NOT count — it just retries
                // next sweep — so infra flakiness can't wrongly cap a branch as "human".
                if (rr && rr.refreshed) {
                  refreshedStale++;
                  attempts.set(branch, n + 1);
                  logFn(
                    `[publish-reconciler] task ${r.task_id} (${branch}) PR #${m.number} was mergeable but red (${m.reason}) — regenerated stale generated indexes + pushed; checks re-run, lands next sweep`
                  );
                } else if (rr && rr.skipped === 'no_regen_diff') {
                  attempts.set(branch, n + 1);
                  logFn(
                    `[publish-reconciler] task ${r.task_id} (${branch}) PR #${m.number} red (${m.reason}) but regeneration produced no diff — a real check failure, left for a human`
                  );
                }
              } catch (e) {
                errFn(`[publish-reconciler] regen-heal for task ${r.task_id} (non-blocking): ${e && e.message}`);
              }
            }
          }
        } catch (_) {
          /* best-effort: a merge-driver miss waits for the next sweep */
        }
      }

      let status = null;
      try {
        status = await push.getPublishStatus({ branch });
      } catch (_) {
        status = null; // transient miss → fall through to the per-task land proof
      }
      if (!push.landConfirmed(status) && status && status.pr_state !== 'none') {
        // A PR exists but hasn't fully landed yet (open / merged-but-deploy-pending /
        // blocked). Respect it — wait for the deploy — rather than risk shipping early.
        continue;
      }
      branchStatus = status;
    }

    // task 1547 — prove the land belongs to THIS task before shipping. landConfirmed
    // (a branch PR merged+deployed) and the old task-1313 head-on-main ancestry check
    // both key on signals a REUSED worktree branch can satisfy for the WRONG task — and
    // claims.head_sha is the claim-TIME base (already on main for an R03-based task), so
    // an ancestry check on it false-positives (the BV1.R04/R05 strand). The robust
    // per-task proof is the SERVER-pushed tip (claims.published_head_sha) being an
    // ancestor of main; the fallback, when no tip was recorded, is that the matched PR
    // references this task id. landProvenForTask still cures the task-1313 strand class
    // (PR deleted post-merge / no worktree_name / ambiguous branch) — now keyed on the
    // unambiguous published tip rather than the base.
    if (!landed && typeof push.landProvenForTask === 'function') {
      try {
        const proof = await push.landProvenForTask({
          taskId: r.task_id, publishedSha: r.published_head_sha, status: branchStatus,
        });
        if (proof && proof.proven) {
          landed = true;
          landNote = proof.reason;
        }
      } catch (_) {
        /* transient compare-API miss → next sweep */
      }
    }

    if (!landed) {
      // Observability (task 1546 / blocker 47): the sweep could not prove this
      // confirmed task landed. Every such miss USED to be a silent `continue`, so
      // blocker 47's 15 strands sat invisible for up to 66h. Count them, and WARN
      // on the ones older than STALE_CONFIRMED_MS — a credited-but-unlanded task
      // (codeless confirm, or a land whose published tip was never recorded on the
      // claim) now surfaces in the logs instead of stranding silently.
      unprovable++;
      const reason = (!branch && !r.published_head_sha) ? 'no_branch_no_tip' : 'land_not_proven';
      const ageMs = r.confirmed_at ? (nowMs - new Date(r.confirmed_at).getTime()) : null;
      if (ageMs != null && ageMs > STALE_CONFIRMED_MS) {
        staleStrands++;
        errFn(
          `[publish-reconciler] STRAND task ${r.task_id}: confirmed ~${Math.round(ageMs / 3_600_000)}h ago, unprovable (${reason}) — credited but no landed proof; needs owner triage`
        );
      }
      continue;
    }

    try {
      const shipped = await db.shipTask({ taskId: r.task_id, builderId: r.builder_id });
      reconciled++;
      logFn(
        `[publish-reconciler] task ${r.task_id} (${landNote}) landed → shipped`
      );
      // The box that published could not post the Discord broadcast (no webhook
      // secret — ADR 0053). The server holds the secrets, so it fires it here,
      // exactly ONCE on the confirmed→shipped transition. Best-effort: never let
      // a broadcast hiccup turn a successful reconcile into a failure.
      try {
        await emit('task.shipped', shipped);
      } catch (e) {
        errFn(`[publish-reconciler] ship broadcast for task ${r.task_id} (non-blocking): ${e && e.message}`);
      }
    } catch (e) {
      // TASK_NOT_CONFIRMED = a client poll (or a prior sweep) already flipped it
      // in the race window — expected + idempotent, NOT an error.
      if (e && e.code !== 'TASK_NOT_CONFIRMED') {
        errors++;
        errFn(`[publish-reconciler] shipTask ${r.task_id} failed: ${e && e.message}`);
      }
    }
  }

  // Prune the treadmill guard so it can't leak: a branch that left the confirmed set
  // (landed, or released) never returns under the same name, so drop it.
  for (const b of attempts.keys()) {
    if (!branchesSeen.has(b)) attempts.delete(b);
  }

  if (reconciled || merged || resolvedConflicts || refreshedStale) {
    logFn(
      `[publish-reconciler] swept ${rows.length} confirmed task(s); merged ${merged} stalled PR(s); auto-resolved ${resolvedConflicts} generated/index conflict(s); regen-healed ${refreshedStale} stale-generated PR(s); reconciled ${reconciled} → shipped`
    );
  }
  if (staleStrands) {
    errFn(
      `[publish-reconciler] ${staleStrands} stale strand(s): confirmed >${Math.round(STALE_CONFIRMED_MS / 60_000)}min with no provable land — credited but unlanded; see STRAND lines above`
    );
  }
  return { checked: rows.length, reconciled, merged, resolvedConflicts, refreshedStale, errors, unprovable, staleStrands };
}

// task 1366 — server-side session-cost reconcile, piggybacked on the same 5-min
// sweep. System 1's client cost hook silently skips the MAJORITY of sessions (a
// cloud box / cowork VM / overnight agent runs with no GDS token, so the
// SessionEnd hook quiet-skips), so a server pass re-prices the model_usage we
// ALREADY stored on session_records into a cost_log row — keyed on the SAME
// (source, source_ref) the client would use, so logCost's ON CONFLICT DO NOTHING
// prevents any double-count if the client also posted. Unlike the confirmed→
// shipped work, this is PURE DB — it needs no push credential — so it runs even
// on a host where getPublishStatus would 503. Best-effort + injected-deps pure.
async function runCostSweep(deps = {}) {
  const logFn = deps.log || console.log;
  const errFn = deps.error || console.error;
  // reconcileSessionCosts carved into modules/economy/ (BV1.R77 / ADR 0093 §1-2):
  // prefer an injected deps.db (the test seam — tests inject a db with the
  // method), else resolve the `reward` kernel port (production; economy default-on).
  const reconciler = (deps.db && typeof deps.db.reconcileSessionCosts === 'function')
    ? deps.db
    : (seams.resolveOptional('reward') || {});
  if (typeof reconciler.reconcileSessionCosts !== 'function') return { skipped: 'unsupported' };
  try {
    const cost = await reconciler.reconcileSessionCosts();
    if (cost && cost.reconciled > 0) {
      const unk = cost.unknownModels && cost.unknownModels.length
        ? ` [unpriced→opus: ${cost.unknownModels.join(',')}]`
        : '';
      logFn(
        `[publish-reconciler] session-cost: scanned ${cost.scanned}, reconciled ${cost.reconciled} cost_log row(s) totalling $${Number(cost.totalUsd || 0).toFixed(4)}${unk}`
      );
    }
    return cost;
  } catch (e) {
    errFn(`[publish-reconciler] session-cost reconcile (non-blocking): ${e && e.message}`);
    return { skipped: 'error', error: e && e.message };
  }
}

// Start the periodic sweep. Idempotent (a second call is a no-op). Kill-switched
// by PUBLISH_RECONCILER_DISABLED=1 (purely additive bookkeeping, so it's ON by
// default whenever a push credential is configured; the route's getPublishStatus
// 503s without one, so runSweep already no-ops there too). Timers are unref'd so
// they never hold the process open on a systemd restart.
function start(deps = {}) {
  if (process.env.PUBLISH_RECONCILER_DISABLED === '1') {
    console.log('[publish-reconciler] disabled (PUBLISH_RECONCILER_DISABLED=1)');
    return;
  }
  if (intervalTimer) return; // already started

  const tick = () => {
    runSweep(deps).catch((e) => console.error(`[publish-reconciler] sweep crashed: ${e && e.message}`));
    // task 1366 — runs independently of the confirmed→shipped sweep (pure DB, no
    // push credential) and never lets a cost-reconcile error touch that sweep.
    runCostSweep(deps).catch((e) => console.error(`[publish-reconciler] cost sweep crashed: ${e && e.message}`));
  };

  firstTimer = setTimeout(tick, FIRST_SWEEP_DELAY_MS);
  if (firstTimer.unref) firstTimer.unref();
  intervalTimer = setInterval(tick, INTERVAL_MS);
  if (intervalTimer.unref) intervalTimer.unref();

  console.log(
    `[publish-reconciler] started — sweeping confirmed→shipped every ${Math.round(INTERVAL_MS / 1000)}s`
  );
}

function stop() {
  if (firstTimer) {
    clearTimeout(firstTimer);
    firstTimer = null;
  }
  if (intervalTimer) {
    clearInterval(intervalTimer);
    intervalTimer = null;
  }
}

module.exports = { start, stop, runSweep, runCostSweep, couldBeStaleGenerated, INTERVAL_MS };
