// modules/discord/auth.js — the discord module's auth surface (BV1.R47 / task 1416).
//
// One `auth` namespace behind which the moved discord-*.js files keep their
// `const auth = require('./auth')` call sites unchanged:
//
//   • KERNEL gates, re-exported off the published doorway — requireBuilder /
//     requireRank (the same rank machinery every route uses; ADR 0016).
//
//   • DISCORD-SPECIFIC helpers VENDORED here — the snowflake validator + the bot-
//     token loader. These are deliberately NOT on the kernel doorway: the doorway
//     stays module-agnostic (the "core carries no module code" fitness check
//     forbids naming a module in src/module-api.js). Core's src/bongos/auth.js keeps
//     its OWN copies for the OAuth account-LINK flow (routes/auth.js, which is not
//     part of this module); these are byte-identical twins — keep them in sync.
//
// The boundary: this file requires ONLY src/module-api.js.

'use strict';

const api = require('../../src/module-api');

// PURE — a Discord user id is a numeric snowflake (17–20 digits). Reject anything
// else BEFORE it reaches a link/insert. (Twin of src/bongos/auth.js's copy, kept for
// the link flow; this module no longer reaches into core auth.)
function isValidDiscordUserId(id) {
  return typeof id === 'string' && /^\d{17,20}$/.test(id);
}

// Bot-token loader (ADR 0033 §F3). The bot authenticates to the Discord GATEWAY
// with a bot token. env DISCORD_BOT_TOKEN wins (the systemd path ADR 0022 prefers
// for the always-on droplet), else the bot_token field of the local
// discord-bot.json (mode 600). The token is a secret — never log it. Reads config
// through the doorway's instance-config accessor. (Twin of src/bongos/auth.js's copy.)
function loadDiscordBotToken() {
  const envToken = process.env.DISCORD_BOT_TOKEN;
  if (envToken) return envToken;
  try {
    const raw = api.readConfigFileSync('discord-bot.json');
    if (raw) {
      const creds = JSON.parse(raw);
      if (creds.bot_token) return creds.bot_token;
    }
  } catch (_) { /* not configured */ }
  return null;
}

module.exports = {
  // kernel gates (doorway)
  requireBuilder: api.requireBuilder,
  requireRank: api.requireRank,
  // vendored discord-specific helpers
  isValidDiscordUserId,
  loadDiscordBotToken,
};
