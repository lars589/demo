'use strict';

// The grading module's kernel PORT registration (BV1.R73 / ADR 0091 §4).
//
// Grading has no HTTP endpoints of its own. The grade-a-diff capability is
// consumed by CORE files that must NOT import a module:
//   • the LIFECYCLE (routes/tasks.js, POST /tasks/:id/grade) — validateAndScore +
//     serverSideGuards on the confirm/ship path;
//   • the public dashboard (routes/public.js, GET /public/grades) — RUBRIC meta.
// Both reach grading WITHOUT importing it by resolving the `grade` kernel PORT
// this factory registers (ADR 0091 §4: keep the state machine whole, extract the
// capability behind a seam). The provider IS the grader module surface
// (validateAndScore / serverSideGuards / RUBRIC / …).
//
// Why a route factory for a routeless module: `mountModuleRoutes` (the loader) is
// the one boot hook that runs BOTH in the live server AND whenever a test rebuilds
// the GDS router — so registering here (not in a poller) is what keeps the port
// present for the route-building tests too. Registration is hasProvider-guarded so
// re-instantiation never trips the seam's single-provider duplicate guard.
//
// The 4-worker adversarial PANEL (grader.gradeSubagent) runs in the CLI/box
// (scripts/gds/ship.js), not in-process — it posts its scored output to
// POST /tasks/:id/grade, where the server-side guards re-run the deterministic
// pre-passes. So the in-process port surface the lifecycle needs is the grader
// module itself.

const express = require('express');
const api = require('../../../src/module-api');
const grader = require('../grader');
const db = require('../db'); // the grade-trend read carved from core db.js (ADR 0102)

function registerSeams() {
  if (!api.hasProvider('grade')) {
    api.registerProvider('grade', grader);
  }
  // The grade-TREND read (builderRollingAvgGrade) carved from core db.js (ADR 0102)
  // — core me.js + the sessions BFG resolve it here instead of the doorway. Degrades
  // to a zero-grade shape when grading is off (a vanilla instance).
  if (!api.hasProvider('grade.builderRollingAvgGrade')) {
    api.registerProvider('grade.builderRollingAvgGrade', db.builderRollingAvgGrade);
  }
}

module.exports = function buildGradeRouter() {
  registerSeams();
  // No HTTP surface — grading is a pure capability behind the `grade` port. The
  // empty router is only the loader's contributes.routes mount vehicle; returning
  // a valid express.Router() keeps mountModuleRoutes' `router.use(sub)` happy
  // without exposing any endpoint.
  return express.Router();
};
