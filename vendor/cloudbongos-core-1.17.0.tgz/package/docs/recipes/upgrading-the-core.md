# Recipe — upgrading a consumer instance's Cloud Bongos core (`bongos upgrade`)

> The R86 update-consumption channel ([ADR 0100](../adr/<redacted>.md) §2, [ADR 0103](../adr/<redacted>.md) §4, task [#1690](https://example.com/builders#/task/1690)). How a **two-repo consumer instance** — one that installs `@cloudbongos/core` as a vendored-tarball dependency — pulls the core from version N → N+1. Tooling: [`scripts/gds/upgrade.js`](../../scripts/gds/upgrade.js) (`bongos upgrade`). First proven live on emersonian-circles 1.15.0 → 1.16.0 (task [#1976](https://example.com/builders#/task/1976)).

## What the channel does

`bongos upgrade --to <version> --from <tgz>` runs, from a consumer instance root:

1. **pre-flight** — module-compat vs the target core + a clean git tree (skip with `--force`).
2. **bump the pin** — vendor the new `cloudbongos-core-<version>.tgz` and rewrite the `"@cloudbongos/core": "file:vendor/…"` dependency.
3. **`npm install`** — `node_modules/@cloudbongos/core` becomes the new version.
4. **`npm run migrate`** — the core's `migrate.sh` applies additive `core_*` migrations (merged three-root: core + instance + modules).
5. **materialize `.claude/`** — refresh skills/settings/hooks from the new core (`materializeClaude`), rewriting invocations to the `bongos` bin.
6. **restart** — `--service <unit>` or `--restart-cmd "<cmd>"`.
7. **verify** — installed version == target (+ optional `--health-url`).

Run bare (`bongos upgrade`, no `--to`) it stays the module-compat **pre-check** only.

## The bootstrap (first bump)

The channel ships *in* the core. On the FIRST bump, the consumer's installed core is the OLD version (whose `bongos upgrade` may be the pre-check stub or lack a fix). So drive the first bump with the **new version's** `upgrade.js`, run out of its extracted package against `--instance <consumer>`:

```bash
cd /tmp && rm -rf pkg && mkdir pkg && tar xzf cloudbongos-core-<version>.tgz -C pkg
node /tmp/pkg/package/scripts/gds/upgrade.js --to <version> --from /tmp/cloudbongos-core-<version>.tgz --instance <consumer-root> …
```

Once a consumer is on a core that carries the channel, its own `bongos upgrade` drives later bumps.

## Live procedure (as run for emersonian-circles 1.15.0 → 1.16.0)

The instance runs on the droplet (co-tenant): systemd `emersonian-circles.service`, `WorkingDirectory=/home/lars/emersonian-circles`, port `:3004`, DB `emersonian_circles`. The consumer repo also has a laptop clone (`~/dev/emersonian-circles`) + origin (`example-owner/emersonian-circles`).

1. **Cut the canonical tarball from `main`** (after the core change has merged, so the pin is a real release):
   ```bash
   node scripts/gds/package-core.js --version <version>   # → dist/cloudbongos-core-<version>.tgz (+ manifest)
   ```
   `package-core` archives committed `HEAD`, **not the working tree** — commit + merge first, then verify the artifact (`ls dist/cloudbongos-core-<version>/…`).
2. **Back up the instance DB** — `pg_dump emersonian_circles | gzip > /tmp/…sql.gz`.
3. **`scp` the tarball to the droplet**, verify `sha256sum` matches.
4. **`--dry-run` first**, then the real run — extracted-package bootstrap, with the instance DB pinned:
   ```bash
   PGDATABASE=emersonian_circles CLOUDBONGOS_INSTANCE_ROOT=/home/lars/emersonian-circles \
     node /tmp/pkg/package/scripts/gds/upgrade.js --to <version> --from /tmp/cloudbongos-core-<version>.tgz \
       --instance /home/lars/emersonian-circles \
       --restart-cmd "sudo systemctl restart emersonian-circles.service" \
       --health-url http://127.0.0.1:3004/healthz
   ```
5. **Verify** — `systemctl is-active`, local + public `/healthz` 200, `/version`, `installed core == <version>`, the `core_upgrades` row.
6. **Update the repo of record** — run the channel on the laptop clone (`--skip-migrate`, no DB there), commit the pin bump (drop the superseded tarball), `git push origin`.
7. **Align the droplet checkout** — the droplet has no deploy key (`git pull` fails; idea 509), so `git bundle` the new commit on the laptop, `scp`, `git fetch <bundle> && git reset --hard FETCH_HEAD`. `node_modules` is already the new version, so no re-`npm ci`; a final restart makes `/version` report the new commit.

## Gotchas

- **`PGDATABASE` is load-bearing on a co-tenant droplet.** `migrate.sh` defaults `PGDATABASE` to `example` — **production**. Always set `PGDATABASE=<instance-db>` explicitly, or you migrate the wrong database.
- **The health check polls the restart** (fixed in task [#1984](https://example.com/builders#/task/1984)). The service binds its port ~1s after `systemctl restart`, so `--health-url` now polls up to ~30s for a 2xx before reporting a warning — an immediate `fetch failed` no longer means a failed upgrade. (Pre-1984 cores fetched once and spuriously reported `fetch failed`; there, confirm with `is-active` + a manual `curl`.)
- **The ledger auto-inserts via `PGDATABASE` too** (fixed in task [#1984](https://example.com/builders#/task/1984)). A consumer on `PGDATABASE` + peer auth now gets its `core_upgrades` row written automatically — the channel delegates the insert to `psql -d "$PGDATABASE"`, exactly like `migrate.sh`, so no manual `psql INSERT` is needed. (`DATABASE_URL` still works, via the `pg` driver.) Pre-1984 cores only auto-wrote with `DATABASE_URL`; on those, record the row manually.
- **No deploy key on the droplet** → deploys/upgrades ride a `git bundle`, not `git pull` (idea 509).
