# ADR 0045 — The Dev Box desktop app: a native switch, app-pairing auth, and off-repo distribution

- **Status:** accepted
- **Date:** 2026-06-10
- **Task:** [#904](https://example.com/builders#/task/904)
- **Track:** internal
- **Extends:** ADR 0031 (cloud dev environments), ADR 0035 (onboarding three paths), ADR 0038 (browser terminal), ADR 0039 (setup-first onboarding UX)
- **Related:** ADR 0004 (trademark posture), ADR 0016 (trust boundary), ADR 0029 (off-box static hosting precedent)

## Context

The Claude-Desktop onboarding path told a newcomer to paste a prompt that
makes Claude download and run `connect.sh`. Two exported sessions from the
same Windows newcomer (2026-06-10, @largekristensen-svg — both attempts in one
day, both failed) showed the flow is structurally broken, not just rough:

1. **No Windows branch.** `connect.sh` installs the Claude Desktop
   managed-settings file on macOS (sudo) or falls through to "save it in
   $HOME" with a Linux-worded message — on Windows. Claude Desktop never sees
   the SSH config; its logs show `discovered 0 workspace SSH config(s)`.
2. **The agent cannot finish its own flow.** Claude Desktop's auto-mode
   classifier hard-blocked even a read of `C:\ProgramData\ClaudeCode\
   managed-settings.json` ("permission-machinery modification"). The platform
   we onboard into forbids its agent from completing step 5, by design.
3. **Phishing-shaped trust hurdle.** Every newcomer's Claude re-litigates
   `curl | bash` + an Amazon-look-alike domain + a server-fetched
   highest-precedence config — ~6.5 minutes of security ceremony and three
   user confirmations per attempt, forever.
4. **Zero post-run observability.** The script holds the GDS token in memory
   only; once it exits, checking box state means a full GitHub device-flow
   re-auth. The user waited 10h40m on the first-box approval gate with no way
   to see anything.
5. Assorted platform cuts: git-bash `/tmp` invisible to the native Read tool,
   browser never auto-opens on Windows, private key left 644, and the
   `StrictHostKeyChecking` mitigation lands in `~/.ssh/config`, which Claude
   Desktop's embedded ssh2 **does not read** — it reads only
   `~/.ssh/known_hosts` (the known knownhosts bug).

Meanwhile the server side is already right: own-scoped `/box/ensure`,
`/box/me`, `/box/close`, `/box/terminal`, `/box/ssh-key`,
`/box/managed-settings` (ADR 0031/0035/0038) — the failures are all in the
local last mile.

## Decision

### 1. A native tray app owns the local last mile

`devbox-app/` — an Electron menu-bar (macOS) / system-tray (Windows) app,
"OTB Dev Box". One switch: on = `POST /box/ensure`, off = `POST /box/close`,
live state from polling `GET /box/me` (+ `/box/terminal` when active), native
notifications on ready / awaiting-approval / idle-close. Because it is a
human-launched native app, it can do everything the agent-driven flow could
not: generate `~/.ssh/otb_builder` with real 600 perms (icacls ACL on
Windows), register it, **replace** the box's lines in `~/.ssh/known_hosts` on
every activation (host keys change on each re-provision), and install the
managed-settings file to the system path behind the OS's own elevation prompt
(osascript / UAC). The app never sends `claude_active` heartbeats: the
droplet idle sweep stays the cost authority, and an unused box still reclaims
itself.

Electron over Tauri: no Rust toolchain for future builders, one runtime for
both targets, and the project's existing JS-only skill set — size (~100MB)
is the accepted cost. Zero runtime npm deps; the renderer is sandboxed,
contextIsolated, and reachable only through named IPC verbs.

### 2. App-pairing auth (browser clicks only)

The app signs in by pairing against the GDS itself (`src/bongos/app-pair.js`,
routes in `routes/auth.js`):

    app: POST /auth/app-pair/start          → { pair_code, poll_token }
    app: opens /builders/pair?code=…        (builders' hall approve page)
    human: ONE Approve click                (cookie-gated, like cli-token/issue)
    server: mints a source='cli' session, parks it on the pairing
    app: POST /auth/app-pair/poll           → { token }   (delivered once)

Two credentials with separated powers: the short `pair_code` (visible in the
browser) can only *approve from an authenticated browser cookie session*; the
long secret `poll_token` is the only thing that can *collect* the token, once.
GitHub's device flow was rejected because it makes the human type a code;
riding the web OAuth to a loopback was rejected because `safeReturnTo`
deliberately blocks non-apex targets and we refuse to weaken it. Pairing
state is an in-memory Map (10-min TTL, size-capped) — same posture as the
existing device-flow pendings; no migration, restart voids in-flight pairings
harmlessly. The minted session writes to `~/.config/otb/gds-session.json` —
the SAME file the CLI uses, so pairing the app also signs in the `/builder-*`
skills on that machine.

### 3. Distribution: CI builds, public releases repo, branded redirects

Installers cannot ride the git deploy (private repo, no LFS, GitHub 100MB
cap). `.github/workflows/build-devbox-app.yml` builds dmg (arm64+x64) + NSIS
exe on every `devbox-app/**` push and uploads artifacts; the operator
publishes them as release assets on the PUBLIC releases repo named in
`config/devbox-app.json` (`example-owner/example-devbox` — the ADR 0029
status-mirror pattern, $0). The server serves branded URLs that 302 to those
assets — `GET /downloads/devbox/{mac-arm64,mac-x64,win-x64}` +
`latest.json` (`src/devbox-downloads.js`) — so every link a builder sees
stays on example.com and a release bump is a one-file config change.
The app checks `latest.json` daily and shows a download banner (no
auto-update: meaningless without code signing).

### 4. Unsigned, for now

No Apple Developer ID ($99/yr) or Windows cert yet — a recurring cost that
needs Lars's explicit go-ahead (CLAUDE.md §4); filed as a blocker. Until
then macOS shows "Apple could not verify…" (System Settings → Privacy &
Security → Open Anyway) and SmartScreen shows "unrecognized app". The
onboarding copy walks through both honestly. electron-builder ad-hoc signs
the mac build (required for arm64 to launch).

### 5. Trademark posture (ADR 0004)

Product name, appId, artifact filenames carry "OTB Dev Box" /
`com.offtheboats.devbox` — never the civilization name. "Example" is
rendered at runtime only, from the single constant in
`devbox-app/src/brand.js`.

## Consequences

- The hall's Claude-Desktop onboarding pane drops the paste-a-prompt script
  for: download app → approve → flip switch → open Claude Desktop. The
  Claude Online (browser terminal) pane is unchanged. `/builders/settings`
  gains a download section. `connect.sh`/`connect.ps1` remain for the
  SSH-comfortable (ADR 0035's guide path) but are no longer the newcomer
  front door.
- New auth surface: 2 public + 2 any-builder routes, all classified by the
  route-rank pre-pass; approve is cookie-gated so a leaked bearer cannot mint
  siblings (mirrors `cli-token/issue`).
- The signing-cert decision (and with it SmartScreen/Gatekeeper smoothness +
  real auto-update) is deliberately deferred to the operator.
- A future `box_connect` onboarding tick still clears through the box's own
  `claude_active` heartbeat — unchanged by the app (which never heartbeats).
