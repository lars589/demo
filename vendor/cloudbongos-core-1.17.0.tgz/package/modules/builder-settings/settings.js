'use strict';

// modules/builder-settings/settings.js — the `builder-settings` kernel PORT
// provider surface (BV1.R80 / ADR 0093 §1).
//
// builder-settings owns the per-builder preference domain (wandering · skill ·
// sound · render) + builder-needs. Most of that surface is reached HTTP-side
// through the module's own routes (routes/settings.js mounts the `/me/*-prefs`
// endpoints). But two CORE files legitimately need a sliver of it and must NOT
// `require()` a module (the one-way boundary, ADR 0083):
//   • routes/me.js — the `GET /me` aggregator builds the `wandering` / `render` /
//     `needs` slices of the profile payload inline (alongside the economy/discord
//     slices it already resolves through ports). It resolves THIS port for them.
//   • cascade-dispatch.js — the dormant System-3 cascade router clamps a spawn to
//     the builder's configured model ceiling (`skillPrefs.getForBuilder`). It
//     resolves THIS port's `skillCeiling`.
//
// So this port is the narrow read surface those two core consumers resolve via
// `seams.resolveOptional('builder-settings')`. builder-settings is default-on, so
// the provider is present in prod; the consumers degrade gracefully when it isn't
// (a vanilla instance without the module): me.js's slices are best-effort and
// cascade's ceiling falls back to 'opus' (its existing `|| 'opus'` default).
//
// We DELEGATE (do not spread) every method so a test that stubs a function on the
// live db/pref module object still bites at call time (the economy reward.js
// precedent — a spread captures the original reference at module-load).

const db = require('./db');
const skillPrefs = require('./skill-prefs');
const wanderingPrefs = require('./wandering-prefs');
const interactionPrefs = require('./interaction-prefs');
const modelAllocPrefs = require('./model-alloc-prefs');
const renderPrefs = require('./render-prefs');
const builderNeeds = require('./builder-needs');

module.exports = {
  // --- the raw behavior_prefs blob read (GET /me resolves this once, then shapes
  //     the wandering + render slices from the same blob — one DB round-trip).
  getBuilderBehaviorPrefs: (...a) => db.getBuilderBehaviorPrefs(...a),

  // --- effective-value shapers the GET /me aggregator renders inline (the SSOT
  //     for each knob's API shape lives in the corresponding pref lib).
  describeWandering: (...a) => wanderingPrefs.describeForApi(...a),
  describeInteraction: (...a) => interactionPrefs.describeForApi(...a),
  describeModelAllocation: (...a) => modelAllocPrefs.describeForApi(...a),
  describeRender: (...a) => renderPrefs.describeForApi(...a),
  computeNeeds: (...a) => builderNeeds.computeNeeds(...a),

  // --- the per-builder model ceiling for a skill (cascade-dispatch clamps to it;
  //     never exceeds it). Mirrors the former `skillPrefs.getForBuilder` call.
  skillCeiling: (builderPrefs, skillName) => skillPrefs.getForBuilder(builderPrefs, skillName),
};
