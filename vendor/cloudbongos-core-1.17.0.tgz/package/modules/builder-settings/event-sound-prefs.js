'use strict';
// src/bongos/event-sound-prefs.js — per-builder per-event sound variant selection
// (task 582). Extends the mute-toggle system (sound-prefs.js) with variant
// picking: for each of 5 build events a builder can choose which world-themed
// sound variant plays. Each variant maps to an EXISTING .wav in .claude/sounds/;
// the dedicated world-themed audio assets (lyre-pluck.wav etc.) ship separately.

// 5 build events, ordered for the UI. Each has a world-themed default variant
// plus alternates. `wav` is the existing .claude/sounds/<name>.wav that backs
// the variant until dedicated audio ships.
const EVENTS = Object.freeze([
  {
    id:    'user-input',
    label: 'Awaiting Thy Counsel',
    desc:  'Claude has paused and needs thy response',
    variants: [
      { id: 'lyre-pluck',  label: 'Lyre Pluck',  wav: 'alert', isDefault: true },
      { id: 'chime-soft',  label: 'Chime Soft',  wav: 'chime' },
    ],
  },
  {
    id:    'task-shipped',
    label: 'Task Shipped',
    desc:  'A task has been confirmed and merged',
    variants: [
      { id: 'bronze-fanfare', label: 'Bronze Fanfare', wav: 'ship',    isDefault: true },
      { id: 'triumph-call',   label: 'Triumph Call',   wav: 'triumph' },
    ],
  },
  {
    id:    'credits-awarded',
    label: 'Drachmae Awarded',
    desc:  'Drachmae have been credited to thy treasury',
    variants: [
      { id: 'coin-clink',   label: 'Coin Clink',   wav: 'chime', isDefault: true },
      { id: 'herald-short', label: 'Herald Short', wav: 'alert' },
    ],
  },
  {
    id:    'rank-promoted',
    label: 'Rank Promotion',
    desc:  'Thou hast advanced to a new rank',
    variants: [
      { id: 'herald-call',   label: 'Herald Call',   wav: 'fanfare', isDefault: true },
      { id: 'grand-fanfare', label: 'Grand Fanfare', wav: 'triumph' },
    ],
  },
  {
    id:    'achievement',
    label: 'Achievement Unlocked',
    desc:  'A badge or milestone has been earned',
    variants: [
      { id: 'harp-flourish',  label: 'Harp Flourish',  wav: 'triumph', isDefault: true },
      { id: 'brass-flourish', label: 'Brass Flourish', wav: 'fanfare' },
    ],
  },
]);

// flat: variantId → wav file name
const VARIANT_WAV = Object.freeze(
  Object.fromEntries(EVENTS.flatMap(e => e.variants.map(v => [v.id, v.wav])))
);

// flat: eventId → default variant id
const EVENT_DEFAULT = Object.freeze(
  Object.fromEntries(
    EVENTS.map(e => [e.id, e.variants.find(v => v.isDefault)?.id ?? e.variants[0].id])
  )
);

// Sets for fast membership checks
const KNOWN_EVENT_IDS   = Object.freeze(new Set(EVENTS.map(e => e.id)));
const KNOWN_VARIANT_IDS = Object.freeze(new Set(EVENTS.flatMap(e => e.variants.map(v => v.id))));

// Map: eventId → Set of valid variant ids for that event
const EVENT_VARIANTS = Object.freeze(
  Object.fromEntries(EVENTS.map(e => [e.id, new Set(e.variants.map(v => v.id))]))
);

function resolveVariant(eventId, builderPrefs) {
  const stored = builderPrefs && builderPrefs[eventId];
  if (typeof stored === 'string' && KNOWN_VARIANT_IDS.has(stored)) return stored;
  return EVENT_DEFAULT[eventId];
}

function resolveWav(eventId, builderPrefs) {
  return VARIANT_WAV[resolveVariant(eventId, builderPrefs)] ?? 'chime';
}

// Full list for the API/UI — every event with variants, current selection,
// and the resolved wav file name.
function listEffective(builderPrefs) {
  return EVENTS.map(event => ({
    event:    event.id,
    label:    event.label,
    desc:     event.desc,
    variants: event.variants.map(v => ({
      id:        v.id,
      label:     v.label,
      wav:       v.wav,
      is_default: !!v.isDefault,
    })),
    selected: resolveVariant(event.id, builderPrefs),
    wav:      resolveWav(event.id, builderPrefs),
  }));
}

// Compact event→wav map written to the local prefs file so the offline hook
// can play the right sound without a network call.
function effectiveWavMap(builderPrefs) {
  const out = {};
  for (const e of EVENTS) out[e.id] = resolveWav(e.id, builderPrefs);
  return out;
}

// Validate a PATCH body: { <eventId>: <variantId|null>, ... }
// null = clear override → fall back to default.
function validatePatch(body) {
  if (body == null || typeof body !== 'object' || Array.isArray(body)) {
    return { ok: false, errors: [{ error: 'body_must_be_object' }] };
  }
  const errors = [];
  const patch = {};
  for (const [eventId, variantId] of Object.entries(body)) {
    if (!KNOWN_EVENT_IDS.has(eventId)) {
      errors.push({ event: eventId, error: 'unknown_event' });
      continue;
    }
    if (variantId === null) {
      patch[eventId] = null;
      continue;
    }
    if (typeof variantId !== 'string') {
      errors.push({ event: eventId, variant: variantId, error: 'variant_must_be_string_or_null' });
      continue;
    }
    if (!EVENT_VARIANTS[eventId].has(variantId)) {
      errors.push({ event: eventId, variant: variantId, error: 'variant_not_for_event' });
      continue;
    }
    patch[eventId] = variantId;
  }
  if (errors.length > 0) return { ok: false, errors };
  return { ok: true, patch };
}

function applyPatch(existing, patch) {
  const next = { ...(existing || {}) };
  for (const [eventId, variantId] of Object.entries(patch)) {
    if (variantId === null) delete next[eventId];
    else next[eventId] = variantId;
  }
  return next;
}

module.exports = {
  EVENTS,
  VARIANT_WAV,
  EVENT_DEFAULT,
  KNOWN_EVENT_IDS,
  KNOWN_VARIANT_IDS,
  EVENT_VARIANTS,
  resolveVariant,
  resolveWav,
  listEffective,
  effectiveWavMap,
  validatePatch,
  applyPatch,
};
