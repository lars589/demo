# Cursor (Anysphere) — Competitive-Threat Analysis for Cloud Bongos

**A competitor-research document for Cloud Bongos / Off the Boats**
Prepared 2026-06-22 · the **first committed competitor doc** in this repo · companion to the (uncommitted) `component-based-dev-research.md` deep-research doc · task [#1403](https://example.com/builders#/task/1403)

---

## 0. How to read this document (provenance)

This was produced by the project's deep-research harness (fan-out web search → fetch 22 sources → 99 extracted claims → 3-vote adversarial verification), **then completed by a main-loop verification round**, and synthesized here against our own positioning docs. As with the prior research doc, **the harness itself was cut off by the org's monthly Claude spend limit** at the *verify + synthesize* step — 13 claims had finished adversarial verification; the rest abstained. After it stopped, I re-fetched the key funding and economics sources **directly in the main loop** (which was *not* subject to the subagent spend cutoff) and firmed up most of the abstained claims. Every claim carries an explicit confidence mark:

- **✅ Verified** — passed 3-0 / 2-1 adversarial verification in the harness, **or** I confirmed it against a named primary/reputable source in the 2026-06-22 main-loop round.
- **📄 Sourced** — from a reputable source, but single-pass (not adversarially cross-checked). Cite with normal care.
- **🔧 Synthesis** — my analysis, framing, or mapping to Cloud Bongos. Not a cited external fact.
- **⚠️ Contested** — a claim that *failed* verification, or where sources disagree. Flagged so it is never repeated as fact.

> **Operational note for the owner:** this is the **second** harness run in a row truncated by the org's monthly Claude spend limit (the module-system doc was the first). The *subagents* die on it; the *main loop* still works, which is how the verification round below got done. To get full unattended verification + auto-synthesis on the next deep dive, raise the limit at `claude.ai/admin-settings/usage`.

Full bibliography in [§10](#10-bibliography). Our positioning is from a direct read of [`docs/adr/<redacted>.md`](../adr/<redacted>.md), [`docs/adr/<redacted>.md`](../adr/<redacted>.md), and [`GOVERNANCE.md`](../../GOVERNANCE.md).

---

## 1. Executive summary

**Your premise — "Cursor is our largest competitor" — is half right, and the half that's wrong is the important half.** Cursor is the biggest, best-funded, most-recognized *brand* in the adjacent space, so as a mindshare/narrative rival it is unquestionably the giant in the room. But as a **direct product competitor to Cloud Bongos, aiming at "Cursor the editor" is aiming at the wrong thing** — *and* the company is sprinting away from being just an editor. Three findings frame everything below:

1. **Today you are on different layers of the stack.** Cursor *was* a per-seat, human-in-the-loop AI code **editor** (a VS Code fork: autocomplete/Tab, chat). Cloud Bongos is an agent-authored orchestration / project-management **layer** (claim→build→ship→grade, multi-builder, instance-model, BYO-LLM). A free tool where you bring your own API key does **not** remove the reasons people pay Cursor — bundled model access, the polished editor, enterprise compliance. At the *editor* layer, direct revenue threat in either direction is near zero. 🔧

2. **But the overlap is no longer hypothetical — it is shipping.** ✅ **Cursor 3 (April 2026) was "built from scratch rather than extending Cursor's VS Code fork," prioritizing *agent orchestration over direct code editing*** — a unified view of all running agents (local + cloud), **parallel agents across repos**, local↔cloud handoff, and **private team plugin/skill marketplaces "addressing governance needs for organizational deployment"** ([InfoQ](https://www.infoq.com/news/2026/04/cursor-3-agent-first-interface/)). Usage has **inverted**: as of March 2025 tab-completion dominated; now "twice as many users run autonomous agents." This is Cursor walking directly onto the orchestration layer. The gap is closing, not theoretical. 🔧

3. **Cursor's economics both fund the threat and define the weakness you should exploit.** ✅ Cursor ran **negative gross margins** — ~$0.40–0.70 of model-inference cost per revenue dollar, ~30–50% structural gross margin vs 80%+ for normal software. Its owned model (Composer, a fine-tune of the open Kimi K2.5) + cheaper models pushed it to *slightly* positive — but **positive only on enterprise; still loss-making on individual developers.** And its COGS is **rented from the very suppliers (Anthropic, OpenAI) who now compete with it** — vividly, in Jan 2026 Anthropic *blocked third-party tools (including header-spoofing for favorable pricing) and cut off xAI's use of Claude via the Cursor IDE.* Cloud Bongos is BYO-key, takes no markup, and is model-agnostic — so the structural squeeze that pins Cursor's pricing **does not exist for you.** 🔧

**The crisp bottom line** (full version in [§9](#<redacted>)): treat **Anthropic Claude Code, OpenAI Codex, GitHub Copilot's coding agent, Devin, and Replit Agent** as the *direct* product threats to an orchestration platform, and treat **Cursor as the dominant adjacent brand that is now actively entering your layer (Cursor 3).** Don't fight on Cursor's axes (editor UX, model quality, distribution, enterprise polish). Compete on the axes its funding + margin structure *forbid* it to match: open/AGPL, no lock-in, self-host + data control, model-agnostic/BYO, and the governance/methodology layer.

---

## 2. What Cursor is — and the "same layer?" question

| | **Cursor** | **Cloud Bongos** |
|---|---|---|
| **What it is** | AI code **editor** → now an **agent-orchestration workspace** (Cursor 3) | AI-first build **platform / orchestration + PM layer** |
| **Primary user** | A human developer supervising agents | AI agents authoring under a human owner's gates |
| **Unit of work** | A keystroke / chat turn / a supervised agent run | A *task*: claim → build → ship → grade → credit |
| **Monetization** | Per-seat subscription + usage-based inference + enterprise | **Free, non-profit, AGPL-3.0**; instance owner brings their own LLM spend |
| **Distribution** | Download the app; SaaS account | Self-host an instance (Docker); instance-model, not multi-tenant SaaS |
| **Model relationship** | Resells Anthropic/OpenAI/Google + building its own (Composer) | Model-agnostic, bring-your-own-key; takes no markup |
| **Lock-in** | Editor habit, team admin, codebase index, bundled credits, team marketplaces | By design *none* (AGPL §13 forbids the hosted-closed-fork) |

🔧 **The layer distinction is the whole analysis — but the layers are converging.** An editor sells *a better way for a human to write code*; an orchestration platform sells *a way to run, govern, and account for AI agents that write the code*. These were complementary in 2024–25. As of Cursor 3 (April 2026), Cursor is explicitly repositioning as "a unified workspace for building software with agents" where "autonomous agent fleets independently ship changes" — i.e., it is moving *onto* the orchestration layer. So "different layers" is the right frame for *legacy Cursor*, and a *narrowing* frame going forward.

---

## 3. Business model — how Cursor makes money

### Pricing tiers (current)

✅ **Verified, primary source [cursor.com/docs/models-and-pricing](https://cursor.com/docs/models-and-pricing) + [cloudzero.com](https://www.cloudzero.com/blog/cursor-ai-pricing/):**

| Tier | Price | Bundled usage / notes |
|---|---|---|
| **Hobby** | Free | Free forever, no card required |
| **Pro** | **$20/mo** (~$16/mo billed annually) | Includes **$20** of API usage |
| **Pro+** | **$60/mo** | Includes **$70** of API usage |
| **Ultra** | **$200/mo** | Includes **$400** of API usage |
| **Teams (Standard)** | **$40/user/mo** (~$32 annual) | Team admin |
| **Teams (Premium)** | **$120/user/mo** | |
| **Enterprise** | Custom (annual) | Compliance, SSO, privacy |

### The June 2025 pricing earthquake

- ✅ **On June 16, 2025, Cursor moved Pro from request-based to usage-based pricing.** Before: "500 fast responses … then unlimited responses at a slower rate." After: "**$20 worth of usage per month, billed at API rates**" ([TechCrunch](https://techcrunch.com/2025/07/07/cursor-apologizes-for-unclear-pricing-changes-that-upset-users/), 3-0).
- ✅ **Pricing is now token/usage-based** ("per million tokens"); the docs mark older request-based plans **legacy** ([cursor.com/docs](https://cursor.com/docs/models-and-pricing), 3-0).
- ✅ **It triggered widespread backlash** — users were "unexpectedly charged additional costs" beyond the $20 cap; Cursor issued a **public apology on July 4, 2025 and offered refunds** for charges between June 16 and July 4 ([TechCrunch](https://techcrunch.com/2025/07/07/cursor-apologizes-for-unclear-pricing-changes-that-upset-users/) + [cloudzero.com](https://www.cloudzero.com/blog/cursor-ai-pricing/), 3-0).

🔧 **Why this matters to you:** the pricing blow-up is the visible symptom of the inference-margin problem below. When you resell someone else's metered compute you either eat the overage (margin pain) or pass it on (trust pain). Cursor hit the trust wall publicly. **A BYO-key tool never has this problem** — the user's bill goes straight to the model provider; there is no markup to defend and no surprise overage to apologize for.

### Inference economics & margin — the heart of the model ✅ (main-loop round, 2026-06-22)

This is the most important section for understanding why Cursor does what it does. The picture is now well-sourced (no longer contested):

- **Inference is largely a pass-through.** When a user selects a specific frontier model, "usage is drawn from the API pool at that model's API rate" ([cursor.com/docs](https://cursor.com/docs/models-and-pricing), ✅ 2-1) — so the $20 Pro sub roughly *buys $20 of model usage*. Margin can't come from reselling tokens.
- **Cursor ran negative gross margins.** Through 2025 it spent an estimated **$0.40–$0.70 of model-inference cost per $1 of revenue** (Anthropic + OpenAI API costs), making structural gross margin **~30–50% vs the 80%+ of normal software** — the "token tax" that "locks AI-agent gross margins ~30 points below the SaaS baseline" ([Contrary Research](https://research.contrary.com/company/cursor); [TechTimes](https://www.techtimes.com/articles/317542/20260601/<redacted>.htm); [Yahoo Finance — "high costs and thin margins threatening AI coding startups"](https://finance.yahoo.com/news/<redacted>.html)). Contrary quotes the criticism directly: Cursor charges "lower or equivalent pricing to Anysphere's own costs of accessing foundation models."
- **The owned model is the margin fix — and it's partly working.** Composer (Nov 2025) + cheaper models like Kimi moved Cursor to **slight gross-margin profitability — positive on large enterprise, but still losing money on individual developer accounts** ([market reporting via search, 2026](https://mktclarity.com/blogs/news/is-cursor-profitable)). Internal telemetry reportedly showed Composer handling **~half of autocomplete requests** while matching Claude Sonnet on common tasks. 📄
- **Forward pressure:** Cursor reportedly forecasts ending **2026 at a >$6B annualized run-rate** ([letsdatascience](https://letsdatascience.com/blog/<redacted>)) — i.e., it expects to roughly triple again. 📄 (forecast; treat as a target, not a fact.)

### Revenue & ARR trajectory ✅

- ✅ **ARR path:** ~**$100M** (Jan 2025) → ~**$300M** (mid-April 2025) → **$500M+** (June 2025, "doubling ~every two months") → **$1B** (Nov 2025) ([TechCrunch June 2025](https://techcrunch.com/2025/06/05/<redacted>/); [cursor.com/blog/series-d](https://cursor.com/blog/series-d); [Contrary](https://research.contrary.com/company/cursor)).
- ⚠️ **Contested — do not state as fact:** "$2B ARR / 1M+ subscribers by Feb 2026" was **refuted (1-2)** in the harness; some 2026 outlets assert ~$2B but they are speculative. The last firmly-verified figure is **$1B (Nov 2025).**

---

## 4. Funding, valuation & investor incentives

✅ Full history (Contrary Research + the round announcements; Series C/D cross-checked):

| Round | Amount | Valuation | When | Lead / notable investors | Confidence |
|---|---|---|---|---|---|
| Pre-seed | $400K | — | Apr 2022 | — | 📄 |
| Seed | $8M | — | Oct 2023 | **OpenAI Startup Fund** | 📄 |
| Series B | $100M | **$2.5B** | Dec 2024 | a16z, Thrive | 📄 |
| Series C | **$900M** | **$9.9B** | **June 5, 2025** | **Thrive** (lead); a16z, Accel, DST Global | ✅ ([TechCrunch](https://techcrunch.com/2025/06/05/<redacted>/)) |
| **Series D** | **$2.3B** | **$29.3B** post-money | **Nov 2025** | Coatue, **NVIDIA**, **Google** (new); Accel, Thrive, a16z | ✅ 3-0 ([cursor.com/blog/series-d](https://cursor.com/blog/series-d), [CNBC](https://www.cnbc.com/2025/11/13/cursor-ai-startup-funding-round-valuation.html)) |
| In talks | ~$2B+ | ~**$50B** | ~April 2026 | a16z / Thrive, NVIDIA strategic | 📄 ([TechCrunch 2026-04-17](https://techcrunch.com/2026/04/17/<redacted>/) — *"as enterprise growth surges"*) |

Total raised through end-2025: **~$3.5B across seven rounds.**

> ⚠️ A "$60B valuation / SpaceX-xAI acquisition" claim surfaced from low-quality sources and I'm **excluding it as not credible.** The credible April-2026 datapoint is the *TechCrunch "$2B at ~$50B, in talks, enterprise-driven"* line above.

🔧 **What the valuation demands, and why it drives everything:** $29.3B on ~$1B ARR is **~29× revenue**; the rumored ~$50B raise pushes the multiple higher still. Growing into that means **5–10×-ing revenue** — and you can't do that on $20 consumer seats at pass-through (or negative) margin. So every move points the same way: **(1) go upmarket to enterprise** (where margin is *actually* positive), **(2) repair COGS via owned models**, **(3) lock in teams.** Tellingly, the rumored 2026 raise is explicitly framed around **enterprise growth** — the consumer base that built the brand is now the *loss-leader*. None of these imperatives points at "go fight a free non-profit tool."

---

## 5. Moat & strategic position

### What actually locks customers in 🔧/📄

1. **The Tab / autocomplete model** (their own Fusion/Composer model) — fast, habit-forming; the genuine moat, and now ~half-served by their cheaper owned model.
2. **Editor UX + muscle memory** — low cost to adopt (VS Code fork), higher cost to leave once a team's workflow lives there.
3. **Agent mode, background/parallel agents, Bugbot** (automated PR review), whole-repo indexing — and, with Cursor 3, **team plugin/skill marketplaces** with governance for org deployment.
4. **Enterprise: admin, SSO, privacy mode, compliance** — where the margin *and* the stickiness actually are, and where the company is steering.

### The contrarian core — supplier-disintermediation risk ✅ (vivid, now well-sourced)

This is the most strategically important thing about Cursor, and it is the inverse of a moat:

- **Cursor's cost of goods is rented from its own competitors.** It pays Anthropic and OpenAI for the inference it resells. Those suppliers now ship **first-party coding agents** — **Claude Code**, **OpenAI Codex** — that don't pay the markup, get model improvements *first*, and can price below Cursor indefinitely.
- ✅ **The supplier can simply cut you off — and did.** In **January 2026 Anthropic added safeguards blocking third-party tools** (e.g. OpenCode, and tools spoofing the Claude Code client's headers) from accessing Claude at favorable Pro/Max pricing, and **specifically blocked xAI staff who were using Claude *via the Cursor IDE*** ([VentureBeat](https://venturebeat.com/technology/<redacted>); [The Register, 2026-02-20](https://www.theregister.com/2026/02/20/anthropic_clarifies_ban_third_party_claude_access/); [WinBuzzer, 2026-01-10](https://winbuzzer.com/2026/01/10/<redacted>/)). The economics behind the crackdown: a **$200/mo Claude Max sub ≈ $1,000+ of the same usage at API rates** — so reselling/spoofing that access is exactly what a model owner will shut down.
- **This is precisely *why* Cursor is building owned models** (Composer on Kimi K2.5, [§3](#<redacted>)): simultaneously a **margin play** (escape the markup) and a **disintermediation hedge** (reduce dependence on suppliers-turned-rivals).

🔧 **Read against Cloud Bongos:** the dependency that constrains Cursor's pricing and leaves it at a supplier's discretion **does not exist for you.** Cloud Bongos is BYO-key, takes no markup, and is model-agnostic — it can route to whatever model is best/cheapest (including the very first-party agents that threaten Cursor) with no business-model conflict.

---

## 6. Direct threat assessment vs a free / AGPL / self-hosted orchestration platform

This is the heart of your question. The honest answer has three parts.

### A. Where a free BYO-key tool does **not** threaten Cursor 🔧

A free, self-hostable, non-profit tool does **not remove any reason people pay Cursor**:
- **Bundled frontier access** — "free" doesn't make the model free; BYO-key just *moves the bill* to the provider. For most buyers, one Cursor invoice is *less* friction.
- **The editor + Tab UX** — the daily value; an orchestration layer doesn't replace it.
- **Enterprise compliance/admin** — procurement buys a vendor with SOC2, SSO, an MSA, a throat to choke. A self-hosted non-profit OSS project is the *opposite* of that for a risk-averse buyer.
- **Self-host is more work, not less,** for the median Cursor user.

→ **At the editor / per-seat layer, the direct revenue threat in either direction is near zero.**

### B. Where the overlap is real — and now actively shipping 🔧

The axis where the layers collide is **autonomous / multi-agent orchestration** — "the agent owns the task; the human sets gates." That is Cloud Bongos's core, and **Cursor 3 (April 2026) is Cursor moving onto exactly this axis**: built from scratch as an agent-first workspace, a unified view of all running agents (local + cloud), **parallel agents across repos**, local↔cloud handoff, **private team plugin/skill marketplaces with governance**, and usage that has **inverted** from autocomplete to autonomous agents ([InfoQ](https://www.infoq.com/news/2026/04/cursor-3-agent-first-interface/)). This is no longer a "future roadmap" caveat — it is the product direction *today*. The remaining differences from Cloud Bongos are real but narrowing: Cursor's orchestration is still **developer-supervised, per-seat, SaaS, and closed**, whereas Cloud Bongos is **agent-authored, multi-builder, self-hosted, open, with a formal claim→ship→grade + rank/permission governance model.**

### C. Verdict on "Cursor is our largest competitor" 🔧

**Calibrate it on two scoreboards:**

- **As a *product* competitor to an orchestration platform *today*:** Cursor is *not* the most direct threat. The closer ones are the **first-party autonomous agents** (Claude Code, Codex, Copilot coding agent) and **autonomous-SWE platforms** (Devin/Cognition, Replit Agent) — see [§8](#<redacted>). Those *are* orchestration-shaped.
- **As a *brand / trajectory* competitor:** Cursor is the **heavyweight** — the category-defining name, ~$29–50B of capital, and (with Cursor 3) an explicit push onto the orchestration layer. On *that* axis your instinct is right, and the trajectory makes Cursor a *rising* threat, not a static adjacent one.

And the reframe that matters most: **Cloud Bongos is free and non-profit, so it isn't competing for Cursor's *revenue* at all.** The contest is for **developer attention** and the **narrative of how teams *should* build with AI** — winnable for a credible open alternative, but a community/distribution game, not a feature-for-feature fight.

---

## 7. Likely competitive responses & incentives

🔧 **Would Cursor bother competing with a free non-profit tool? Almost certainly not, directly.** Their incentives ([§4](#<redacted>)) point entirely at enterprise revenue and margin repair; fighting free OSS yields no ARR and burns goodwill. Expect them to **ignore** a non-profit tool as a revenue threat.

**What they *will* do — each of which incidentally crowds your space:**
1. **Move upmarket to enterprise** (the dominant motion; the only segment where their margin is positive).
2. **Lock in teams** — admin, shared context, team marketplaces, seat-based billing that compounds.
3. **Push autonomous / background / parallel agents** (Cursor 3) — the vector that directly encroaches on orchestration.
4. **Build owned models** (Composer line) — to escape the inference markup and the supplier squeeze; already shifting enterprise margin positive.

🔧 **If forced to compete on an axis, it would be on** distribution, brand, model/Tab quality, polish, enterprise trust — *all of which a bootstrapped non-profit cannot win head-on.* So **don't fight there.** Your defensible axes are the inverse, and they map onto things Cursor's funding + margin structure *forbid* it to match:

| Cloud Bongos's defensible axis | Why Cursor structurally can't match it |
|---|---|
| **Open / AGPL-3.0, no lock-in** ([ADR 0065](../adr/<redacted>.md)) | A $29B+ venture co. *sells* lock-in; AGPL §13 anti-capture is antithetical to its model |
| **Self-host + full data control** ([ADR 0062](../adr/<redacted>.md) instance model) | SaaS multi-tenant is how it gets margin + telemetry; self-host canonical is the opposite |
| **Model-agnostic / BYO-key, zero markup** | Its economics *depend* on the inference relationship; BYO-key removes the revenue and the supplier risk |
| **Governance / methodology layer** (claim→ship→grade, multi-builder, trust boundary) | Cursor 3 is *starting* on team governance — but for closed, per-seat, supervised use, not agent-authored multi-builder accountability |
| **Non-profit** | Investors require the opposite; it can't credibly be "not monetizing you" |

---

## 8. Calibrating the field — the broader competitive set

For an AI-first **orchestration** platform, rank threats by *"does it manage autonomous agents doing whole tasks?"* — not *"is it a popular AI tool?"* 🔧

| Competitor | What it is | Threat to an *orchestration* platform vs Cursor |
|---|---|---|
| **GitHub Copilot coding agent** | Issue→PR autonomous agent inside the dominant SCM ([docs](https://docs.github.com/copilot/concepts/agents/coding-agent/about-coding-agent), [noqta.tn](https://noqta.tn/en/blog/<redacted>)) | **MORE.** Autonomous, task-scoped, lands a PR through review gates — orchestration-shaped *and* riding GitHub's distribution + enterprise relationships. |
| **Anthropic Claude Code** | Terminal-native autonomous coding agent ([mindstudio](https://www.mindstudio.ai/blog/claude-code-vs-openai-codex-comparison)) | **MORE — and special.** Closest to "agents author the code," *and it is Cloud Bongos's own substrate.* The most-competitive system is the one you're built on. It also showed (Jan 2026) it will police who resells its access. |
| **OpenAI Codex** | Cloud autonomous agent, parallel tasks | **MORE / EQUAL.** Same orchestration encroachment from the other frontier lab. |
| **Devin / Cognition** | Autonomous "AI software engineer" + agent-management UI | **MORE.** The most direct *conceptual* competitor to "agents own tasks end-to-end," with its own session/management layer. |
| **Replit Agent** | Full build+host platform with built-in agents | **EQUAL / MORE.** Closest "platform where you don't bring your own editor"; prosumer/education skew vs your team-governance angle. |
| **Windsurf** | Cursor-like AI editor (post-2025 acquisition turmoil) | **LESS / EQUAL.** Same *layer* as legacy Cursor (an editor) → near-zero direct overlap, plus organizational disruption. |
| **Lovable / v0 / Bolt** | Prompt-to-app generators (web UI / prototypes) | **LESS.** Different buyer, different output (ship a small app/UI from a prompt). Overlap only at "describe → app." |

🔧 **Takeaway:** the orchestration-layer threats are the **first-party autonomous agents** (Claude Code, Codex, Copilot's agent) and the **autonomous-SWE platforms** (Devin, Replit) — *not* the editors (legacy Cursor, Windsurf). The irony worth sitting with: the system most competitive with an AI-first orchestration platform is **Claude Code**, which is *also what Cloud Bongos runs on.* Your relationship to the frontier labs is simultaneously **dependency, substrate, and competitor** — the same position Cursor is in, except you don't resell their tokens, so you don't carry the margin risk *or* the cut-off risk that hit Cursor in Jan 2026.

---

## 9. Strategic bottom line for the owner

1. **Re-rank the threat board.** Cursor = biggest *brand* in the adjacent space and now *entering your layer* (Cursor 3), but the most *direct product* threats to an orchestration platform are the **first-party autonomous agents** (Claude Code, Codex, Copilot coding agent) and **autonomous-SWE platforms** (Devin, Replit Agent). Plan against *those*; watch Cursor as the well-funded incumbent crossing over from the editor side.

2. **Never compete on Cursor's axes** (editor UX, Tab quality, model performance, distribution, enterprise polish). A bootstrapped non-profit loses every one. Compete on the axes their funding + margin structure *forbid* them to match: **open/AGPL, no lock-in, self-host + data control, model-agnostic/BYO, and the governance/methodology layer** ([§7 table](#<redacted>)).

3. **The inference-markup squeeze is their structural weakness and your structural strength — and it's now proven, not theoretical.** Cursor ran negative margins, rents COGS from suppliers who compete with it, and got *cut off* by Anthropic in Jan 2026. Cloud Bongos rents nothing, takes no markup, and is model-agnostic. Make "no markup, no lock-in, no model captivity, no supplier can switch you off" an explicit part of the pitch.

4. **The agent-first pivot is happening now — Cursor 3 is the entry point.** This is the one place adjacency is becoming competition. Re-assess hard if Cursor (or Copilot/Devin) ships **team-level *agent-authored* orchestration with real governance** (dispatch control, approval gates, accounting across many agents) — Cursor 3's team marketplaces are the first step in that direction.

5. **You're not competing for their revenue — so they won't fight you.** Free + non-profit means the contest is for **developer attention** and the **"right way to build with AI" narrative.** That's winnable for a credible open alternative, but it's a **community + distribution game**, not a feature war. Invest in proof, dogfooding, openness, and ecosystem rather than chasing editor or agent-UX parity.

---

## 10. Bibliography

**Verified (✅ — adversarially confirmed in-harness and/or confirmed against a named source in the 2026-06-22 main-loop round):**
- Cursor — Models & Pricing (primary): https://cursor.com/docs/models-and-pricing
- Cursor — Series D announcement (primary): https://cursor.com/blog/series-d
- TechCrunch — Cursor apologizes for unclear pricing changes (2025-07-07): https://techcrunch.com/2025/07/07/cursor-apologizes-for-unclear-pricing-changes-that-upset-users/
- TechCrunch — Anysphere nabs $9.9B valuation, past $500M ARR (2025-06-05): https://techcrunch.com/2025/06/05/<redacted>/
- CloudZero — Cursor AI pricing breakdown: https://www.cloudzero.com/blog/cursor-ai-pricing/
- the-decoder — Cursor Composer 2, code-only model built on Kimi K2.5: https://the-decoder.com/<redacted>/
- CNBC — Cursor funding round / valuation (2025-11-13): https://www.cnbc.com/2025/11/13/cursor-ai-startup-funding-round-valuation.html
- Contrary Research — Cursor profile (ARR trajectory, funding history, margin criticism): https://research.contrary.com/company/cursor
- InfoQ — Cursor 3 agent-first interface (2026-04): https://www.infoq.com/news/2026/04/cursor-3-agent-first-interface/
- VentureBeat / The Register / WinBuzzer — Anthropic crackdown on third-party Claude harnesses & xAI (Jan–Feb 2026): https://venturebeat.com/technology/<redacted> · https://www.theregister.com/2026/02/20/anthropic_clarifies_ban_third_party_claude_access/ · https://winbuzzer.com/2026/01/10/<redacted>/
- TechCrunch — Cursor in talks to raise $2B at $50B as enterprise growth surges (2026-04-17): https://techcrunch.com/2026/04/17/<redacted>/

**Sourced (📄 — reputable, single-pass; cite with care):**
- TechTimes — AI-agent economics / token-tax 30 points below SaaS: https://www.techtimes.com/articles/317542/20260601/<redacted>.htm
- Yahoo Finance — high costs and thin margins threatening AI coding startups: https://finance.yahoo.com/news/<redacted>.html
- Market Clarity — is Cursor profitable (enterprise-positive / individual-negative margins): https://mktclarity.com/blogs/news/is-cursor-profitable
- TheRouter — Cursor Bugbot, Composer 2.5, model block-list governance: https://therouter.ai/news/<redacted>/
- ValueAdd VC — how a code editor became a $9B company: https://valueaddvc.com/blog/<redacted>
- GetPanto — Cursor AI statistics 2026: https://www.getpanto.ai/blog/cursor-ai-statistics
- Wikipedia — Anysphere / Cursor (company): https://en.wikipedia.org/wiki/Anysphere · https://en.wikipedia.org/wiki/Cursor_(company)
- MindStudio — Claude Code vs OpenAI Codex: https://www.mindstudio.ai/blog/claude-code-vs-openai-codex-comparison
- GitHub — About Copilot coding agent: https://docs.github.com/copilot/concepts/agents/coding-agent/about-coding-agent · noqta.tn (autonomous PR): https://noqta.tn/en/blog/<redacted>
- Coder — Compare Cursor / "is the IDE dead": https://coder.com/solutions/agents/compare-cursor · https://coder.com/blog/is-the-ide-dead-the-rise-of-agentic-ai-in-software-development
- MarkTechPost — AI coding agents & dev platforms 2026: https://www.marktechpost.com/2026/06/10/<redacted>/

**Contested (⚠️ — failed verification or excluded):**
- "$2B ARR + 1M paying subscribers by Feb 2026" — **refuted 1-2** (verified figure: $1B, Nov 2025); some 2026 outlets assert ~$2B speculatively.
- "$60B valuation / SpaceX-xAI acquisition (2026)" — **excluded as not credible** (low-quality sources). The credible April-2026 datapoint is the TechCrunch "$2B at ~$50B, in talks" line.
- "$200/mo plan ≈ $5,000 in real compute" — abstained; directionally consistent with negative-margin reporting, specific figure unverified.

**Internal (our positioning, read 2026-06-22):** [ADR 0065](../adr/<redacted>.md) (AGPL / non-profit / AI-first), [ADR 0062](../adr/<redacted>.md) (instance model, core↔host split), [`GOVERNANCE.md`](../../GOVERNANCE.md) (anti-capture principles); companion deep-research doc `component-based-dev-research.md` (uncommitted, module-system research, 2026-06-21).

---

*Harness stats: 5 angles · 22 sources fetched · 99 claims extracted · 25 verified (13 confirmed 3-0/2-1, 1 refuted 1-2, 11 abstained at the org spend-limit cutoff). Main-loop verification round (2026-06-22): 6 sources re-fetched/searched after the harness stopped, firming up funding history, the negative-margin/owned-model economics, the Anthropic supplier crackdown, and the Cursor 3 agent-orchestration pivot. Synthesis, threat-framing, and Cloud Bongos mapping by Claude (Opus 4.8).*
