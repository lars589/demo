# Authoring a migration

Schema and data changes live here as `NNN_short_name.sql` files, applied in
filename order by [`scripts/migrate.sh`](../scripts/migrate.sh) on every deploy
and tracked by filename stem in the `schema_migrations` table.

**The one rule that has actually bitten us:** a migration may be re-applied
against a database whose data has *moved on since you wrote it* — a fresh
restore + replay, or a later migration that renamed a row your migration
references. So every migration must be a clean no-op on re-run, and any write
keyed on a **hardcoded natural key** must guard for that key still existing.

## Checklist

- [ ] **Name it with the number reserved by your claim.** `/builder-claim` prints
      `Migration number reserved for you: NNN`. Use exactly that — the allocator
      (migration 008) prevents two parallel claims from colliding on a number.
      Never guess the next number from `ls`.
- [ ] **Wrap the whole file in `BEGIN; … COMMIT;`** so a mid-file failure rolls
      back rather than leaving the schema half-migrated.
- [ ] **Make every statement idempotent.** `migrate.sh` skips files already in
      `schema_migrations`, but a fresh restore replays the whole folder — and the
      file must survive that. Use `CREATE TABLE IF NOT EXISTS`,
      `ALTER TABLE … ADD COLUMN IF NOT EXISTS`, `CREATE OR REPLACE`,
      `DROP … IF EXISTS`, and `INSERT … ON CONFLICT DO NOTHING`.
- [ ] **Guard hardcoded natural keys with `WHERE EXISTS`.** Any `INSERT`/`UPDATE`
      that hardcodes a renameable natural key — a `version_id` like `'GDS-V3'`, a
      builder login, a criterion slug — must guard on that key still existing, so
      it's a clean no-op if a later migration renamed or removed it:

      ```sql
      -- Guarded so a fresh restore + replay (or a post-rename DB) is a no-op,
      -- never a FK violation.
      INSERT INTO done_when_criteria (version_id, cnum, criterion_md)
      SELECT 'GDS-V3', 1, '…'
      WHERE EXISTS (SELECT 1 FROM versions WHERE id = 'GDS-V3')
      ON CONFLICT DO NOTHING;

      UPDATE versions SET done_when = '…'
      WHERE id = 'GDS-V3'
        AND EXISTS (SELECT 1 FROM versions WHERE id = 'GDS-V3');
      ```

      Why this is a real rule and not paranoia: migration `<redacted>`
      hardcoded `version_id = 'PMS-V3'`; migration `019` then renamed that id to
      `'GDS-V3'`. On the next fresh replay, 018 ran against a DB where `PMS-V3` no
      longer existed and the deploy broke. The fix was a `WHERE EXISTS` guard on
      every statement (see the head of
      [`<redacted>.sql`](<redacted>.sql)). Prefer a
      per-statement `WHERE EXISTS` over a `DO`-block guard — a `DO` block can't
      short-circuit the rest of the file.
- [ ] **Don't `DELETE` rows that other tables reference.** Soft-revoke instead
      (e.g. set `revoked_at = now()` on sessions rather than deleting — `claims`
      has an FK). See the LarsCode reset session log for the pattern.
- [ ] **Self-registration is automatic.** `migrate.sh` writes the
      `schema_migrations` row itself with `ON CONFLICT DO NOTHING` after a
      successful apply, so you do **not** need a trailing
      `INSERT INTO schema_migrations …` — but one is harmless if you copy an old
      file that has it.
- [ ] **ASCII only in files read by cloud-init / shell wrappers.** Not a migration
      issue per se, but the same "silently discarded on a stray byte" failure mode
      bit `builder-box-cloud-init.yaml` (learning 48) — keep migrations ASCII too.
- [ ] **Test idempotence locally before shipping.** Apply, then apply again:

      ```sh
      scripts/migrate.sh        # apply NNN
      scripts/migrate.sh        # must print "skip NNN (already applied)" and exit 0
      ```

      For the restore-replay path, drop the `schema_migrations` row for your file
      and re-run — it must be a clean no-op, not an error.

## Anatomy of a migration file

```sql
-- NNN short human description
-- Applied under claim <id> (task <id>, <rank prefix> — <title>).
-- Idempotent on re-run.

BEGIN;

-- … guarded, idempotent statements …

COMMIT;
```

The header comment is convention, not enforced — but it's how `git blame` and the
audit trail tie a schema change back to the task that justified it.
