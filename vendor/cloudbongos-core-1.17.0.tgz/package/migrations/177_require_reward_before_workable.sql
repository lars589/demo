-- 177 require a credits_reward (drachmae) before a task is workable
-- Applied under task 1670 (GDS-V4 — Require a credits_reward value before a task
-- can become READY / be CLAIMED). See docs/adr/0096-require-reward-before-workable.md.
-- Idempotent on re-run.
--
-- Problem: tasks.credits_reward defaults to 0 (migration 003). A task could be
-- promoted to 'ready' and claimed+shipped while paying 0 drachmae. This migration
-- closes the auto-promote half of the gate (the route + claim halves live in
-- modules/lifecycle/routes/tasks.js + db.js) and GRANDFATHERS every task that is
-- ALREADY workable so no currently-claimable work is stranded.
--
-- Grandfathering (the critical invariant): there are ~57 'ready' tasks with
-- credits_reward=0 right now. We must NOT make any of them unclaimable, and must
-- NOT retro-demote any 'ready' task to backlog.
--   1. We add a reward_gate_exempt boolean and set it TRUE for every task that is
--      already at or past 'ready' (ready/active/completed/confirmed/shipped). The
--      route + claim backstop honor this flag, so existing claimable + in-flight
--      work is permanently exempt. NEW tasks default the column to FALSE, so the
--      gate applies only to future promotions/claims.
--   2. The auto-promote predicate change below only affects FUTURE backlog->ready
--      evaluations (the triggers fire on later ship/satisfy/achieve events) — it
--      never re-evaluates a row already in 'ready', so no demotion can occur.

BEGIN;

-- (1) The grandfather flag. Idempotent: ADD COLUMN IF NOT EXISTS.
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS reward_gate_exempt boolean NOT NULL DEFAULT false;

-- Stamp every task that is already workable (or beyond) as exempt. A clean no-op
-- on re-run (it only ever sets false->true on the snapshot of already-advanced
-- rows; a fresh replay re-marks the same set). Backlog/blocked rows are NOT
-- exempted — going forward they must carry a reward to advance.
UPDATE tasks
   SET reward_gate_exempt = true
 WHERE reward_gate_exempt = false
   AND status IN ('ready', 'active', 'completed', 'confirmed', 'shipped');

-- (2) The auto-promotion predicate. A task is auto-promotable to 'ready' only when
-- it is fully dependency-unblocked AND it has something to pay (a positive
-- credits_reward) OR it is grandfathered. Adding the reward clause here (the single
-- predicate shared by all three promotion triggers — promote_dependents_on_ship /
-- _criterion_satisfy / _goal_achieve) keeps unrewarded backlog tasks OUT of 'ready'
-- without touching any row already in 'ready' (triggers never re-evaluate those).
CREATE OR REPLACE FUNCTION task_is_fully_unblocked(p_task_id bigint)
RETURNS boolean AS $$
  SELECT
    -- reward gate (task 1670 / ADR 0096): present + positive, or grandfathered.
    EXISTS (
      SELECT 1 FROM tasks t
       WHERE t.id = p_task_id
         AND (t.reward_gate_exempt = true OR COALESCE(t.credits_reward, 0) > 0)
    )
    -- dependency gate (migration 163): NONE of the task's gating edges (own + goal
    -- + criterion) points at an un-done node. An orphaned `to` yields no EXISTS
    -- match -> counts as un-done -> task stays blocked (fail-closed).
    AND NOT EXISTS (
      WITH gating AS (
        SELECT d.to_kind, d.to_id
          FROM dependencies d
          JOIN tasks t ON t.id = p_task_id
         WHERE (d.from_kind = 'task'      AND d.from_id = t.id)
            OR (d.from_kind = 'goal'      AND d.from_id = t.goal_id)
            OR (d.from_kind = 'criterion' AND d.from_id IN (
                  SELECT tc.criterion_id FROM task_criteria tc WHERE tc.task_id = t.id))
      )
      SELECT 1
        FROM gating g
       WHERE NOT (
            (g.to_kind = 'task'      AND EXISTS (SELECT 1 FROM tasks              x WHERE x.id = g.to_id AND x.status = 'shipped'))
         OR (g.to_kind = 'criterion' AND EXISTS (SELECT 1 FROM done_when_criteria x WHERE x.id = g.to_id AND x.satisfied))
         OR (g.to_kind = 'goal'      AND EXISTS (SELECT 1 FROM goals              x WHERE x.id = g.to_id AND x.status = 'achieved'))
       )
    );
$$ LANGUAGE sql STABLE;

COMMIT;
