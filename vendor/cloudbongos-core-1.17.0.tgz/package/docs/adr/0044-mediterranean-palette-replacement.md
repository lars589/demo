# 0044 — Full Mediterranean palette replacement (not a split)

- **Status:** Accepted (direction). Implementation tracked separately.
- **Date:** 2026-06-10
- **Deciders:** Lars
- **Area:** the game world's look (the locked palette governs the colors of every game tile a player sees; the decision is about the world's look, not the pipeline tooling).

## Context

The art pipeline's locked palette is 64 colors extracted from the Pokémon FireRed
reference corpus (`art/template/palette.json`), per [ADR 0008](./<redacted>.md)
and the hard constraint in `art/template/style_guide.md` ([#3](https://example.com/builders#/task/3) "Locked palette"). Every
output pixel must quantize to one of those 64 colors. Per CLAUDE.md §7.1, **any palette
change is an ADR-level decision** because it ripples through every existing tile and the
quantizer.

The FireRed-derived palette carries the *structural* style well (it's why the clusters
read as "Pokémon"), but it is a temperate / "Poke Mart" palette: spring greens, primary
blues, the bright interior-shop colors. The project's north star is a **sun-bleached
Mediterranean coast** — olive/sage greens, warm tan sand, turquoise (not navy) sea,
weathered marble. The style guide already biases generations *toward* Mediterranean within
the FireRed palette ("Mediterranean palette bias" rule), but the underlying locked colors
still pull the wrong direction, especially for greens and water.

Blocker [#8](https://example.com/builders#/blocker/8) asked the structural question: **keep the FireRed/"Poke Mart" palette and add a
separate Mediterranean sub-palette (a split), or replace the locked palette wholesale with a
Mediterranean-tuned one (full replacement)?**

## Decision

**Full replacement.** Replace the locked 64-color palette with a single Mediterranean-tuned
palette. Do **not** maintain two coexisting palettes.

Rationale (Lars's call, 2026-06-10):

- **One source of truth.** A split palette means every generation, the quantizer, the
  deterministic family checks (palette Jaccard, dominant-color overlap), and every reviewer
  prompt must reason about *which* palette applies to *which* tile. That branching is exactly
  the kind of pipeline complexity the bootstrapped budget and the single-maintainer reality
  can't carry. One palette = one set of rules everywhere.
- **The world has one look.** Off the Boats is a single, persistent, coherent world. There is
  no "Poke Mart interior" context that needs the temperate palette — the FireRed colors were
  only ever scaffolding for the *structure*, never the intended final hues.
- **The bias rule becomes the palette.** Today the style guide *nudges* generations toward
  Mediterranean within a temperate palette; replacement bakes that intent into the colors
  themselves, so tiles land Mediterranean by construction instead of by reviewer correction.

## Consequences

- **Re-quantization is required.** Existing committed tiles were quantized against the old
  palette; some will shift when re-quantized to the new one, and a few may need regeneration.
  This is the bulk of the implementation work and is tracked as a **separate task** (filed
  from this ADR) — this ADR records the *direction*, not the swap.
- **The structure-vs-color split is preserved.** The FireRed *reference corpus and clusters*
  (`art/references/`, `art/template/cluster_overview.png`) stay — they carry silhouette and
  rhythm discipline, which is independent of hue. Only `art/template/palette.json` and the
  downstream quantize/check steps change.
- **Deterministic family checks need re-baselining.** Palette-Jaccard / dominant-color-overlap
  thresholds were tuned against the old palette and should be re-checked after the swap.
- **Reversible.** The old palette is preserved in git history; if the Mediterranean palette
  proves too narrow (e.g. not enough value steps for shading), we revert the one file and
  re-quantize back. No data is destroyed.
- **Container color (blocker [#7](https://example.com/builders#/blocker/7)) composes with this.** The container is now weathered
  black/charcoal (style-guide rule, 2026-06-10); the replacement palette must carry enough
  cool-neutral charcoal/grey value steps to render it. Captured as a constraint on the
  implementation task.

## Implementation

This ADR is the **decision**. The actual work — build the Mediterranean 64-color palette,
swap `art/template/palette.json`, re-quantize the committed tile set, re-baseline the
deterministic checks, and visually review — is tracked as its own GDS task (filed alongside
this ADR from the 2026-06-10 blocker review).
