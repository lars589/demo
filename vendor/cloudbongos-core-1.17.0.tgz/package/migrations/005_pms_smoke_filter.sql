-- 005_pms_smoke_filter.sql
-- Filter synthetic smoke-test tasks (title LIKE '__smoke__%') from public surfaces
-- so the smoke harness can exercise the write path in production without
-- polluting the dashboard, the claimable-tasks list, or the progress meter.

DROP VIEW IF EXISTS claimable_tasks;
DROP VIEW IF EXISTS version_progress;

CREATE VIEW version_progress AS
SELECT v.id AS version_id,
       v.name,
       v.track,
       v.status,
       count(*) FILTER (WHERE t.status = 'shipped') AS shipped_count,
       count(*) AS total_count,
       COALESCE(sum(
         CASE WHEN t.status = 'shipped' THEN 6 - COALESCE(t.priority, 5) ELSE 0 END
       ), 0)::bigint AS shipped_weight,
       COALESCE(sum(6 - COALESCE(t.priority, 5)), 0)::bigint AS total_weight
  FROM versions v
  LEFT JOIN tasks t
    ON t.version_id = v.id
   AND (t.title IS NULL OR t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\')
 GROUP BY v.id, v.name, v.track, v.status;

CREATE VIEW claimable_tasks AS
SELECT id, version_id, title, description, status, touches,
       est_minutes, est_cost_usd, manual_degree, priority,
       automation_tag, credits_reward, source, source_ref,
       promoted_at, shipped_at, shipped_by, value_summary,
       created_at, updated_at
  FROM tasks t
 WHERE status = 'ready'
   AND title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
   AND NOT EXISTS (SELECT 1 FROM task_blockers tb WHERE tb.task_id = t.id)
   AND NOT EXISTS (
     SELECT 1 FROM claims c
       JOIN tasks t2 ON t2.id = c.task_id
      WHERE c.released_at IS NULL
        AND t2.touches && t.touches
   );

INSERT INTO schema_migrations (version) VALUES ('005_pms_smoke_filter')
  ON CONFLICT (version) DO NOTHING;
