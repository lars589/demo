-- 143_cost_calibration.sql — cost calibration medians (cost-per-task / cost-per-credit).
--
-- The cost-side analogue of migration 015's pms_calibrated_minutes. Recommended
-- by the 2026-05-30 spend audit, finding F6: "migration 015's calibration is the
-- model the COST side should imitate: collect real samples, derive a ratio,
-- expose a calibrated figure. Extend the same pattern to cost-per-task and
-- cost-per-credit once real api spend lands." That spend has now landed (ADR 0028
-- session-cost capture → cost_log.category='api'), so this exposes the medians.
--
-- Unlike est calibration there is no per-row input to calibrate (a task has no
-- "cost estimate" to multiply by a ratio), so the deliverable is the SUMMARY
-- function only — mirroring pms_calibration_summary(), not pms_calibrated_minutes.
--
-- cost_calibration_summary() returns one row per task kind PLUS an overall '(all)'
-- row (GROUPING SETS), each carrying:
--   median_cost_per_task   — median of SUM(amount_usd) per task, in USD.
--   median_cost_per_credit — median of (task cost / credits_reward), USD per credit;
--                            NULL when a kind has no credit-bearing samples.
--   sample_size            — number of tasks contributing (judge confidence by it,
--                            the same way pms_calibrated_minutes gates on n).
--
-- Sample set mirrors migration 015 exactly: shipped+confirmed tasks only, smoke
-- rows excluded, and only tasks that actually incurred cost (HAVING cost > 0).
-- Idempotent: CREATE OR REPLACE.

CREATE OR REPLACE FUNCTION cost_calibration_summary()
RETURNS TABLE (
  kind text,
  median_cost_per_task numeric,
  median_cost_per_credit numeric,
  sample_size integer
)
LANGUAGE sql
STABLE
AS $$
  WITH task_costs AS (
    SELECT t.id,
           t.kind,
           t.credits_reward,
           SUM(cl.amount_usd) AS task_cost
      FROM cost_log cl
      JOIN tasks t ON t.id = cl.task_id
     WHERE t.status IN ('shipped', 'confirmed')
       AND t.title NOT LIKE '\_\_smoke\_\_%' ESCAPE '\'
     GROUP BY t.id, t.kind, t.credits_reward
    HAVING SUM(cl.amount_usd) > 0
  )
  SELECT COALESCE(kind, '(all)') AS kind,
         ROUND((percentile_cont(0.5) WITHIN GROUP (ORDER BY task_cost))::numeric, 4)
           AS median_cost_per_task,
         ROUND(
           (percentile_cont(0.5) WITHIN GROUP (ORDER BY task_cost / credits_reward)
             FILTER (WHERE credits_reward > 0))::numeric,
           4
         ) AS median_cost_per_credit,
         COUNT(*)::integer AS sample_size
    FROM task_costs
   GROUP BY GROUPING SETS ((kind), ())
   ORDER BY (kind IS NULL) DESC, sample_size DESC, kind;
$$;

INSERT INTO schema_migrations (version) VALUES ('143_cost_calibration')
  ON CONFLICT (version) DO NOTHING;
