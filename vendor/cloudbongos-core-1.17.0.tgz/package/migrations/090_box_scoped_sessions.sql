-- migration 090: box-scoped dev-box sessions (task 919, security_reports SR#2 + SR#11)
--
-- The dev-box provisioner (scripts/gds/box.js) bakes a GDS session into cloud-init
-- so box-source-fetch can clone the rank-scoped repo on first boot (#818). Until
-- now that baked token was source='cli' — a FULL-authority builder session (it can
-- claim/grade/ship/hit every requireBuilder route). source was purely informational;
-- no scope gate existed. SR#2 (HIGH): any on-box process or the metadata endpoint
-- could read it and act as the full builder, breaking the ADR 0016 trust boundary
-- (the box is OUTSIDE it).
--
-- Fix: a third session source, 'box'. auth.requireBuilder denies a 'box' session on
-- every route EXCEPT the handful the on-box crons need (allow-listed via
-- auth.allowBoxScope), so a leaked box credential can do nothing but bootstrap.
--
-- 1) Widen the source CHECK to admit 'box'. The constraint was created inline in
--    migration 003 (builder_sessions.source CHECK (source IN ('cli','web'))), so
--    Postgres auto-named it builder_sessions_source_check. Drop-if-exists keeps this
--    idempotent across environments where the name might differ.
ALTER TABLE builder_sessions
  DROP CONSTRAINT IF EXISTS builder_sessions_source_check;
ALTER TABLE builder_sessions
  ADD CONSTRAINT builder_sessions_source_check CHECK (source IN ('cli', 'web', 'box'));

-- 2) Retroactively scope sessions already baked onto LIVE boxes. box.js stamps the
--    baked session with user_agent='box-provision' (and only that path does), so
--    this targets exactly those tokens and downgrades them to box scope in place.
--    Safe: a running box only ever calls the 4 allow-listed bootstrap endpoints, and
--    a builder who re-authed ON the box (interactive /builder-reauth) holds a
--    SEPARATE cli/web session with a different user_agent, untouched here.
UPDATE builder_sessions
   SET source = 'box'
 WHERE source = 'cli'
   AND user_agent = 'box-provision'
   AND revoked_at IS NULL;

-- Counter hygiene: keep the migration-number allocator above this file so the next
-- reservation can't collide with 090 (per the planning-session learning).
UPDATE migration_counter SET next_number = GREATEST(next_number, 91) WHERE id = 1;
